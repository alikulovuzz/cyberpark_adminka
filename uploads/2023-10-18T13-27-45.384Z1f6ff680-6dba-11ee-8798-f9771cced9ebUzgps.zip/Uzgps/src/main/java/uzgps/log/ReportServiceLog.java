package uzgps.log;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;
import uzgps.admin.AdminJournal;
import uzgps.common.UZGPS_CONST;
import uzgps.dto.POIDTO;
import uzgps.dto.ReportGetDTO;
import uzgps.persistence.POI;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Locale;

/**
 * Created by NETEX on 15.06.2017.
 */
@Aspect
@Component
public class ReportServiceLog {

    @Autowired
    private AdminJournal adminJournal;

    @After(value = "execution(* uzgps.report.ReportService.getReportById(..)) && args(id)")
    public void getReport(Long id) {

        if (id != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_GET,
                    UZGPS_CONST.JOURNAL_REPORT_GET,
                    UZGPS_CONST.JOURNAL_REPORT,
                    new ReportGetDTO(id, "", "", "", ""));
        }
    }

}
