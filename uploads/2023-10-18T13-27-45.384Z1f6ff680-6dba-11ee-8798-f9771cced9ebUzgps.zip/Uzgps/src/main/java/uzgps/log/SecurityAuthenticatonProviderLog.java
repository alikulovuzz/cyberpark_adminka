package uzgps.log;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import uzgps.security.AdminJournalSignIn;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.User;
import uzgps.security.SecurityService;

/**
 * Created by NETEX on 15.06.2017.
 */
@Aspect
@Component
public class SecurityAuthenticatonProviderLog {

    @Autowired
    private AdminJournalSignIn adminJournalSignIn;

    @Autowired
    private SecurityService securityService;

    @After("execution(* uzgps.security.SecurityAuthenticatonProvider.authenticate(..)) && args(authentication)")
    public void authenticateLog(Authentication authentication) {
        String login;

        if (authentication.getPrincipal() != null) {
            login = authentication.getPrincipal().toString();

            login = login.toLowerCase();

            User user = securityService.getUserByLogin(login);
            adminJournalSignIn.logSingIn(
                    UZGPS_CONST.JOURNAL_ACT_LOGIN,
                    UZGPS_CONST.JOURNAL_LOGIN_SUCCESS,
                    UZGPS_CONST.JOURNAL_LOGIN,
                    user);// todo put userId
        }
    }

    @AfterThrowing("execution(* uzgps.security.SecurityAuthenticatonProvider.authenticate(..)) && args(authentication)")
    public void authenticateFailLog(Authentication authentication) {
        String login = null;

        if (authentication.getPrincipal() != null) {
            login = authentication.getPrincipal().toString();
            login = login.toLowerCase();

            uzgps.persistence.User user = securityService.getUserByLogin(login);
            adminJournalSignIn.logSingInError(
                    UZGPS_CONST.JOURNAL_ACT_LOGIN,
                    UZGPS_CONST.JOURNAL_LOGIN_FAIL,
                    UZGPS_CONST.JOURNAL_LOGIN,
                    login);
        }
    }


}
