package uzgps.log;


import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uzgps.admin.AdminJournal;
import uzgps.common.UZGPS_CONST;
import uzgps.dto.*;
import uzgps.persistence.*;

/**
 * Created by NETEX on 15.06.2017.
 */
@Aspect
@Component
public class AdminServiceLog {

    @Autowired
    private AdminJournal adminJournal;

    @After("execution(* uzgps.admin.AdminService.saveUser(..)) && args(user)")
    public void saveUserLog(User user) {
        if (user.getId() != null) {
            if (user.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_USER_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_USER,
                        new UserDTO(user));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_USER_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_USER,
                        new UserDTO(user));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ADMIN_USER_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER,
                    new UserDTO(user));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveUseRole(..)) && args(userRole)")
    public void saveUseRoleLog(UserRole userRole) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER_ROLE_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER,
                    new UserRoleDTO(userRole));
    }

    @After("execution(* uzgps.admin.AdminService.saveProfile(..)) && args(profile)")
    public void saveProfileLog(Profile profile) {
        if (profile.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_ADMIN_PROFILE_UPDATED,
                    UZGPS_CONST.JOURNAL_ADMIN_USER,
                    new ProfileDTO(profile));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_PROFILE_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER,
                    new ProfileDTO(profile));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveContract(..)) && args(contract)")
    public void saveContractLog(Contract contract) {
        if (contract.getId() != null) {
            if (contract.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                        new ContractDTO(contract));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                        new ContractDTO(contract));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                    new ContractDTO(contract));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveContractSettings(..)) && args(contractSettings)")
    public void saveContractSettingsLog(ContractSettings contractSettings) {
        if (contractSettings.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_SETTINGS_UPDATED,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                    new ContractSettingsDTO(contractSettings));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_SETTINGS_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                    new ContractSettingsDTO(contractSettings));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveGPSUnit(..)) && args(gpsUnit)")
    public void saveGPSUnitLog(GPSUnit gpsUnit) {
        if (gpsUnit.getId() != null) {
            if (gpsUnit.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitDTO(gpsUnit));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitDTO(gpsUnit));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new GPSUnitDTO(gpsUnit));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveGPSUniteType(..)) && args(gpsUnitType)")
    public void saveGPSUniteTypeLog(GPSUnitType gpsUnitType) {
        if (gpsUnitType.getId() != null) {
            if (gpsUnitType.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_TYPE_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitTypeDTO(gpsUnitType));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_TYPE_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitTypeDTO(gpsUnitType));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_TYPE_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new GPSUnitTypeDTO(gpsUnitType));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveCompany(..)) && args(company)")
    public void saveCompanyLog(Company company) {
        if (company.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_UPDATED,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                    new CompanyDTO(company));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                    new CompanyDTO(company));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveMObject(..)) && args(mObject)")
    public void saveMObjectLog(MObject mObject) {
        if (mObject.getId() != null) {
            if (mObject.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new MObjectDTO(mObject));
            else // todo
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new MObjectDTO(mObject));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectDTO(mObject));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveMObjectSettings(..)) && args(mObjectSettings)")
    public void saveMObjectSettingsLog(MObjectSettings mObjectSettings) {
        if (mObjectSettings.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_SETTINGS_UPDATED,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectSettingsDTO(mObjectSettings));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_SETTINGS_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectSettingsDTO(mObjectSettings));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveMObjectGPSUnit(..)) && args(mObjectGPSUnit)")
    public void saveMObjectGPSUnitLog(MObjectGPSUnit mObjectGPSUnit) {
        if (mObjectGPSUnit.getId() != null) {
            if (mObjectGPSUnit.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GPSUNIT_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new MObjectGPSUnitDTO(mObjectGPSUnit));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GPSUNIT_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new MObjectGPSUnitDTO(mObjectGPSUnit));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GPSUNIT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectGPSUnitDTO(mObjectGPSUnit));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveSim(..)) && args(sim)")
    public void saveSimLog(Sim sim) {
        if (sim.getId() != null) {
            if (sim.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_SIM_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new SimDTO(sim));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_SIM_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new SimDTO(sim));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_SIM_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new SimDTO(sim));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveGPSUnitSim(..)) && args(gpsUnitSim)")
    public void saveGPSUnitSimLog(GPSUnitSim gpsUnitSim) {
        if (gpsUnitSim.getId() != null) {
            if (gpsUnitSim.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_SIM_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitSimDTO(gpsUnitSim));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_SIM_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitSimDTO(gpsUnitSim));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_SIM_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new GPSUnitSimDTO(gpsUnitSim));
        }
    }

    @After("execution(* uzgps.admin.AdminService.saveMObjectNotifications(..)) && args(mObjectNotifications)")
    public void saveMObjectNotificationsLog(MObjectNotifications mObjectNotifications) {
        if (mObjectNotifications.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_NOTIFICATION_UPDATED,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectNotificationsDTO(mObjectNotifications));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_NOTIFICATION_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectNotificationsDTO(mObjectNotifications));
        }
    }
}
