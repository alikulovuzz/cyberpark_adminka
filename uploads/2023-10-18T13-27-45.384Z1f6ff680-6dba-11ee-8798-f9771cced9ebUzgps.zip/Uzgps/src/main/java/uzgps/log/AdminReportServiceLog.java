package uzgps.log;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import uzgps.admin.AdminJournal;
import uzgps.common.UZGPS_CONST;
import uzgps.dto.ReportDTO;
import uzgps.persistence.Report;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 * Created by NETEX on 15.06.2017.
 */
@Aspect
@Component
public class AdminReportServiceLog {

    @Autowired
    private AdminJournal adminJournal;

    @PersistenceContext
    private EntityManager em;

    @After("execution(* uzgps.admin.AdminReportService.saveReport(..)) && args(report)")
    public void saveReportLog(Report report) {
        if (report == null)
            throw new IllegalArgumentException("report object is null");

        if (report.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_REPORT_UPDATED,
                    UZGPS_CONST.JOURNAL_REPORT,
                    new ReportDTO(report));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_REPORT_INSERT,
                    UZGPS_CONST.JOURNAL_REPORT,
                    new ReportDTO(report));
        }
    }

    @After("execution(* uzgps.admin.AdminReportService.removeReport(..)) && args(id)")
    public void removeReportLog(Long id) {

        Report report = getReportById(id);
        if (report != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_DELETE,
                    UZGPS_CONST.JOURNAL_REPORT_DELETED,
                    UZGPS_CONST.JOURNAL_REPORT,
                    new ReportDTO(report));
        }
    }

    @Transactional(readOnly = true)
    public Report getReportById(Long id) {

        TypedQuery<Report> query;
        query = em.createNamedQuery("Report.getById", Report.class);
        query.setParameter("id", id);
        return query.getSingleResult();
    }

}
