package uzgps.log;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uzgps.admin.AdminJournal;
import uzgps.common.UZGPS_CONST;
import uzgps.dto.*;
import uzgps.persistence.*;

/**
 * Created by E. Shek on 13.06.2017.
 */
@Aspect
@Component
public class SettingServiceLog {

    @Autowired
    private AdminJournal adminJournal;

    @After("execution(* uzgps.settings.SettingsService.saveMObjectSettings(..)) && args(mObjectSettings)")
    public void saveMObjectSettingsLog(MObjectSettings mObjectSettings){

        if (mObjectSettings.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_SETTINGS_UPDATED,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectSettingsDTO(mObjectSettings));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_SETTINGS_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectSettingsDTO(mObjectSettings));
        }
    }

    @After("execution(* uzgps.settings.SettingsService.saveMObject(..)) && args(mObject)")
    public void saveMObjectLog(MObject mObject){

        if (mObject.getId() != null) {

            if (mObject.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new MObjectDTO(mObject));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new MObjectDTO(mObject));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new MObjectDTO(mObject));
        }

    }

    @After("execution(* uzgps.settings.SettingsService.saveMobileTrackerSettings(..)) && args(mobileTrackerSettings)")
    public void saveMobileTrackerSettingsLog(MobileTrackerSettings mobileTrackerSettings) {

        if (mobileTrackerSettings.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBILE_TRACKER_SETTINGS_UPDATED,
                    UZGPS_CONST.JOURNAL_ADMIN_COMPANY,
                    new MobileTrackerSettingsDTO(mobileTrackerSettings));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_MOBILE_TRACKER_SETTINGS_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_COMPANY,
                    new MobileTrackerSettingsDTO(mobileTrackerSettings));
        }
    }

    @After("execution(* uzgps.settings.SettingsService.saveGPSUnit(..)) && args(gpsUnit)")
    public void saveGPSUnitLog(GPSUnit gpsUnit) {

        if (gpsUnit.getId() != null) {
            if (gpsUnit.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitDTO(gpsUnit));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                        new GPSUnitDTO(gpsUnit));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                    new GPSUnitDTO(gpsUnit));
        }
    }

    @After("execution(* uzgps.settings.SettingsService.saveGroup(..)) && args(group)")
    public void saveGroupLog(Group group) {
        if (group.getId() != null) {
            if (group.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_GROUP_DELETE,
                        UZGPS_CONST.JOURNAL_GROUP,
                        new GroupDTO(group));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_GROUP_UPDATE,
                        UZGPS_CONST.JOURNAL_GROUP,
                        new GroupDTO(group));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_GROUP_INSERT,
                    UZGPS_CONST.JOURNAL_GROUP,
                    new GroupDTO(group));
        }
    }

    @After("execution(* uzgps.settings.SettingsService.saveStaff(..)) && args(staff)")
    public void saveStaffLog(Staff staff) {
        if (staff.getId() != null) {
            if (staff.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_STAFF_DELETE,
                        UZGPS_CONST.JOURNAL_STAFF,
                        new StaffDTO(staff));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_STAFF_UPDATE,
                        UZGPS_CONST.JOURNAL_STAFF,
                        new StaffDTO(staff));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_STAFF_INSERT,
                    UZGPS_CONST.JOURNAL_STAFF,
                    new StaffDTO(staff));
        }
    }

    @After("execution(* uzgps.settings.SettingsService.saveMObjectStaff(..)) && args(mObjectStaff)")
    public void saveMObjectStaffLog(MObjectStaff mObjectStaff) {
        if (mObjectStaff.getId() != null) {
            if (mObjectStaff.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_MOBJECT_STAFF_DELETE,
                        UZGPS_CONST.JOURNAL_MOBJECT_STAFF,
                        new MObjectStaffDTO(mObjectStaff));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_MOBJECT_STAFF_UPDATE,
                        UZGPS_CONST.JOURNAL_MOBJECT_STAFF,
                        new MObjectStaffDTO(mObjectStaff));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_MOBJECT_STAFF_INSERT,
                    UZGPS_CONST.JOURNAL_MOBJECT_STAFF,
                    new MObjectStaffDTO(mObjectStaff));
        }
    }

    @After("execution(* uzgps.settings.SettingsService.saveUser(..)) && args(user)")
    public void saveUserLog(User user) {
        if (user.getId() != null) {
            if (user.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_USER_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_USER,
                        new UserDTO(user));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_USER_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_USER,
                        new UserDTO(user));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER,
                    new UserDTO(user));
        }
    }

    @After("execution(* uzgps.settings.SettingsService.saveUserMObjectAccess(..)) && args(userMObjectAccessList)")
    public void saveUserMObjectAccessLog(UserMObjectAccessList userMObjectAccessList) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_USER_MOBJECT_ACCESS_LIST_UPDATE,
                UZGPS_CONST.JOURNAL_USER_MOBJECT_ACCESS_LIST,
                new UserMObjectAccessListDTO(userMObjectAccessList));
    }

    @After("execution(* uzgps.settings.SettingsService.saveUserAccessList(..)) && args(userAccessList)")
    public void saveUserAccessListLog(UserAccessList userAccessList) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_USER_ACCESS_LIST_UPDATE,
                UZGPS_CONST.JOURNAL_USER_ACCESS_LIST,
                new UserAccessListDTO(userAccessList));
    }

    @After("execution(* uzgps.settings.SettingsService.saveContractSettings(..)) && args(contractSettings)")
    public void saveContractSettingsLog(ContractSettings contractSettings) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_SETTINGS_UPDATED,
                UZGPS_CONST.JOURNAL_ADMIN_CONTRACT,
                new ContractSettingsDTO(contractSettings));
    }

    @After("execution(* uzgps.settings.SettingsService.savemMObjectNotifications(..)) && args(mObjectNotifications)")
    public void savemMObjectNotificationsLog(MObjectNotifications mObjectNotifications) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_NOTIFICATION_UPDATED,
                UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT,
                new MObjectNotificationsDTO(mObjectNotifications));
    }

    @After("execution(* uzgps.settings.SettingsService.saveMobileTrackerStatus(..)) && args(mobileTrackerStatus)")
    public void saveMobileTrackerStatusLog(MobileTrackerStatus mobileTrackerStatus) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_ADMIN_MOBILE_TRACKER_STATUS_UPDATED,
                UZGPS_CONST.JOURNAL_ADMIN_MOBILE_TRACKER_STATUS,
                new MobileTrackerStatusDTO(mobileTrackerStatus));
    }

    @After("execution(* uzgps.settings.SettingsService.saveMObjectGeoFence(..)) && args(mObjectGeoFence)")
    public void saveMObjectGeoFenceLog(MObjectGeoFence mObjectGeoFence) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GEOFENCE_UPDATED,
                UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GEOFENCE,
                new MObjectGeoFenceDTO(mObjectGeoFence));

    }

    @After("execution(* uzgps.settings.SettingsService.saveMObjectPoI(..)) && args(mObjectPoI)")
    public void saveMObjectPoILog(MObjectPoI mObjectPoI) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_POI_UPDATED,
                UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_POI,
                new MObjectPoIDTO(mObjectPoI));
    }

    @After("execution(* uzgps.settings.SettingsService.saveProfile(..)) && args(profile)")
    public void saveProfileLog(Profile profile) {
        adminJournal.logging(
                UZGPS_CONST.JOURNAL_ACT_UPDATE,
                UZGPS_CONST.JOURNAL_PROFILE_UPDATED,
                UZGPS_CONST.JOURNAL_PROFILE,
                new ProfileDTO(profile));
    }

    @After("execution(* uzgps.settings.SettingsService.saveUseRole(..)) && args(userRole)")
    public void saveUseRoleLog(UserRole userRole) {
        if (userRole.getId() != null) {
            if (userRole.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_ADMIN_USER_ROLE_DELETED,
                        UZGPS_CONST.JOURNAL_ADMIN_USER,
                        new UserRoleDTO(userRole));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_ADMIN_USER_ROLE_UPDATED,
                        UZGPS_CONST.JOURNAL_ADMIN_USER,
                        new UserRoleDTO(userRole));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER_ROLE_INSERT,
                    UZGPS_CONST.JOURNAL_ADMIN_USER,
                    new UserRoleDTO(userRole));
        }
    }

}
