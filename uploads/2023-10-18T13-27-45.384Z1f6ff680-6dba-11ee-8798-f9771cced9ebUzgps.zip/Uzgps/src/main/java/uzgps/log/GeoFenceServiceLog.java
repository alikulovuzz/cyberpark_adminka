package uzgps.log;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import uzgps.admin.AdminJournal;
import uzgps.common.UZGPS_CONST;
import uzgps.dto.GeoFenceDTO;
import uzgps.dto.GeoFencePointDTO;
import uzgps.persistence.GeoFence;
import uzgps.persistence.GeoFencePoint;

/**
 * Created by NETEX on 15.06.2017.
 */
@Aspect
@Component
public class GeoFenceServiceLog {
    @Autowired
    private AdminJournal adminJournal;

    @After("execution(* uzgps.map.GeoFenceService.saveGeoFence(..)) && args(geoFence)")
    public void saveGeoFenceLog(GeoFence geoFence) {
        if (geoFence.getId() != null) {
            if (geoFence.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_DELETE,
                        UZGPS_CONST.JOURNAL_GEOFANCE_DELETED,
                        UZGPS_CONST.JOURNAL_GEOFANCE,
                        new GeoFenceDTO(geoFence));
            else
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_UPDATE,
                        UZGPS_CONST.JOURNAL_GEOFANCE_UPDATED,
                        UZGPS_CONST.JOURNAL_GEOFANCE,
                        new GeoFenceDTO(geoFence));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_GEOFANCE_INSERT,
                    UZGPS_CONST.JOURNAL_GEOFANCE,
                    new GeoFenceDTO(geoFence));
        }
    }

    @After("execution(* uzgps.map.GeoFenceService.saveGeoFencePoint(..)) && args(geoFencePoint)")
    public void saveGeoFencePointLog(GeoFencePoint geoFencePoint) {
        if (geoFencePoint.getId() != null) {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_UPDATE,
                    UZGPS_CONST.JOURNAL_GEOFANCE_POINT_UPDATED,
                    UZGPS_CONST.JOURNAL_GEOFANCE,
                    new GeoFencePointDTO(geoFencePoint));
        } else {
            adminJournal.logging(
                    UZGPS_CONST.JOURNAL_ACT_INSERT,
                    UZGPS_CONST.JOURNAL_GEOFANCE_POINT_INSERT,
                    UZGPS_CONST.JOURNAL_GEOFANCE,
                    new GeoFencePointDTO(geoFencePoint));
        }
    }
}
