package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by Stanislav on 25.03.2016 17:57.
 */

@Entity
@Table(name = "uzgps_role")
public class Role implements Serializable {
    public static final String sequenceName = "SEQ_UZGPS_ROLE_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "lowered_name", nullable = true)
    private String loweredName;

    @Column(name = "description", nullable = true)
    private String description;

    @Column(name = "assigned_role", nullable = false)
    private Boolean assignedRole;

    @Column(name = "status", nullable = false, length = 1)
    private String status;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLoweredName() {
        return loweredName;
    }

    public void setLoweredName(String loweredName) {
        this.loweredName = loweredName;
    }

    public Boolean getAssignedRole() {
        return assignedRole;
    }

    public void setAssignedRole(Boolean assignedRole) {
        this.assignedRole = assignedRole;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Role{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", loweredName='" + loweredName + '\'' +
                ", description='" + description + '\'' +
                ", assignedRole=" + assignedRole +
                ", status='" + status + '\'' +
                '}';
    }
}
