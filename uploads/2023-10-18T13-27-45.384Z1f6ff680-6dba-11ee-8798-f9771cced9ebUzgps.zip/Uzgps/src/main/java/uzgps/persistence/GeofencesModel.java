package uzgps.persistence;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.File;
import java.io.Serializable;

public class GeofencesModel implements Serializable {

    private final String DEFAULT_GEOMETRY_NAME = "No name Geometry";
    private final String DEFAULT_GEOMETRY_DESCRIPTION = "";
    private final Double DEFAULT_GEOMETRY_OPACITY = 0.6d;
    private final String DEFAULT_GEOMETRY_COLOR = "#00CC33";
    private final String DEFAULT_FONT_COLOR = "#222222";
    private final Integer DEFAULT_FONT_SIZE = 12;
    private final String DEFAULT_CIRCLE_COLOR = "#00CC33";
    private final Float DEFAULT_RADIUS = 100.0f;

    public GeofencesModel() {
        this.setName(DEFAULT_GEOMETRY_NAME);
        this.setDescription(DEFAULT_GEOMETRY_DESCRIPTION);
        this.setGeometryOpacity(DEFAULT_GEOMETRY_OPACITY);
        this.setGeometryColor(DEFAULT_GEOMETRY_COLOR);
        this.setFontColor(DEFAULT_FONT_COLOR);
        this.setFontSize(DEFAULT_FONT_SIZE);
        this.setRadius(DEFAULT_RADIUS);
        this.setCircleColor(DEFAULT_CIRCLE_COLOR);
        this.setType("Polygon");
        this.setGroupId(0L);
    }

    private Long id;
    private String name;
    private String fontColor;
    private Integer fontSize;
    private Long groupId;
    private Long imageId;
    private String description;

    @JsonProperty("color")
    private String geometryColor;

    @JsonProperty("circleColor")
    private String circleColor;

    private String fill;

    private Float radius;
    private Double geometryOpacity;
    private String geometryWKT;

    private Boolean hasLine;
    private String lineCap;
    private Float opacity;
    private String stroke;
    private String type;

    @JsonProperty("fill-opacity")
    private Float fillOpacity;

    @JsonProperty("marker-color")
    private String markerColor;

    @JsonProperty("stroke-opacity")
    private Float strokeOpacity;

    @JsonProperty("stroke-width")
    private Float strokeWidth;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public void setFontSize(Integer fontSize) {
        this.fontSize = fontSize;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public Long getImageId() {
        return imageId;
    }

    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGeometryColor() {
        if (geometryColor == null && circleColor != null) {
            geometryColor = circleColor;
        }

        return geometryColor;
    }

    public void setGeometryColor(String geometryColor) {
        this.geometryColor = geometryColor;
    }

    public Float getRadius() {
        return radius;
    }

    public void setRadius(Float radius) {
        this.radius = radius;
    }

    public Double getGeometryOpacity() {
        return geometryOpacity;
    }

    public void setGeometryOpacity(Double geometryOpacity) {
        this.geometryOpacity = geometryOpacity;
    }

    public String getGeometryWKT() {
        return geometryWKT;
    }

    public void setGeometryWKT(String geometryWKT) {
        this.geometryWKT = geometryWKT;
    }

    public String getFill() {
        return fill;
    }

    public void setFill(String fill) {
        this.fill = fill;
    }

    public Boolean getHasLine() {
        return hasLine;
    }

    public void setHasLine(Boolean hasLine) {
        this.hasLine = hasLine;
    }

    public String getLineCap() {
        return lineCap;
    }

    public void setLineCap(String lineCap) {
        this.lineCap = lineCap;
    }

    public Float getOpacity() {
        return opacity;
    }

    public void setOpacity(Float opacity) {
        this.opacity = opacity;
    }

    public String getStroke() {
        return stroke;
    }

    public void setStroke(String stroke) {
        this.stroke = stroke;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Float getFillOpacity() {
        return fillOpacity;
    }

    public void setFillOpacity(Float fillOpacity) {
        this.fillOpacity = fillOpacity;
    }

    public String getMarkerColor() {
        return markerColor;
    }

    public void setMarkerColor(String markerColor) {
        this.markerColor = markerColor;
    }

    public Float getStrokeOpacity() {
        return strokeOpacity;
    }

    public void setStrokeOpacity(Float strokeOpacity) {
        this.strokeOpacity = strokeOpacity;
    }

    public Float getStrokeWidth() {
        return strokeWidth;
    }

    public void setStrokeWidth(Float strokeWidth) {
        this.strokeWidth = strokeWidth;
    }

    public String getCircleColor() {
        return circleColor;
    }

    public void setCircleColor(String circleColor) {
        this.circleColor = circleColor;
    }

}
