package uzgps.persistence;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class PoiModel implements Serializable {

    private final Float DEFAULT_RADIUS = 50.0f;
    private final Float DEFAULT_GEOMETRY_OPACITY = 0.6f;
    private final String DEFAULT_CIRCLE_COLOR = "#00CC33";
    private final String DEFAULT_FONT_COLOR = "#222222";
    private final Integer DEFAULT_FONT_SIZE = 12;
    private final String DEFAULT_GEOMETRY_NAME = "No name Geometry";

    public PoiModel() {
        this.setName(DEFAULT_GEOMETRY_NAME);
        this.setGeometryOpacity(DEFAULT_GEOMETRY_OPACITY);
        this.setRadius(DEFAULT_RADIUS);
        this.setCircleDisplayed(true);
        this.setType("Point");

        this.setCircleColor(DEFAULT_CIRCLE_COLOR);
        this.setGeometryColor(DEFAULT_CIRCLE_COLOR);
        this.setFill(DEFAULT_CIRCLE_COLOR);
        this.setMarkerColor(DEFAULT_CIRCLE_COLOR);

        this.setFontColor(DEFAULT_FONT_COLOR);
        this.setFontSize(DEFAULT_FONT_SIZE);
        this.setStrokeOpacity(1.0f);
        this.setOpacity(1.0f);
        this.setFillOpacity(1.0f);
        this.setStrokeWidth(getRadius() / 2);
        this.setGroupId(0L);
    }

    private Long id;
    private String name;
    private Long groupId;
    private String fontColor;
    private Integer fontSize;

    private Double longitude;
    private Double latitude;
    private String circleColor;
    private Float circleOpacity;
    private String description;

    @JsonProperty("isCircleDisplayed")
    private Boolean isCircleDisplayed;

    private Integer width;
    private Integer height;
    private Integer xOffset;
    private Integer yOffset;

    @JsonProperty("color")
    private String geometryColor;

    private String fill;
    private Float radius;
    private Float geometryOpacity;
    private String geometryWKT;

    private Boolean hasLine;
    private String lineCap;
    private Float opacity;
    private String stroke;
    private String type;

    @JsonProperty("fill-opacity")
    private Float fillOpacity;

    @JsonProperty("marker-color")
    private String markerColor;

    @JsonProperty("stroke-opacity")
    private Float strokeOpacity;

    @JsonProperty("stroke-width")
    private Float strokeWidth;

    public Float getDEFAULT_RADIUS() {
        return DEFAULT_RADIUS;
    }

    public Float getDEFAULT_GEOMETRY_OPACITY() {
        return DEFAULT_GEOMETRY_OPACITY;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getGroupId() { return groupId; }

    public void setGroupId(Long groupId) { this.groupId = groupId; }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public void setFontSize(Integer fontSize) {
        this.fontSize = fontSize;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public String getCircleColor() {
        return circleColor;
    }

    public void setCircleColor(String circleColor) {
        this.circleColor = circleColor;
    }

    public Float getCircleOpacity() {
        return circleOpacity;
    }

    public void setCircleOpacity(Float circleOpacity) {
        this.circleOpacity = circleOpacity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Boolean getCircleDisplayed() {
        return isCircleDisplayed;
    }

    public void setCircleDisplayed(Boolean circleDisplayed) {
        isCircleDisplayed = circleDisplayed;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getxOffset() {
        return xOffset;
    }

    public void setxOffset(Integer xOffset) {
        this.xOffset = xOffset;
    }

    public Integer getyOffset() {
        return yOffset;
    }

    public void setyOffset(Integer yOffset) {
        this.yOffset = yOffset;
    }

    public String getGeometryColor() {
        return geometryColor;
    }

    public void setGeometryColor(String geometryColor) {
        this.geometryColor = geometryColor;
    }

    public String getFill() {
        return fill;
    }

    public void setFill(String fill) {
        this.fill = fill;
    }

    public Float getRadius() {
        return radius;
    }

    public void setRadius(Float radius) {
        this.radius = radius;
    }

    public Float getGeometryOpacity() {
        return geometryOpacity;
    }

    public void setGeometryOpacity(Float geometryOpacity) {
        this.geometryOpacity = geometryOpacity;
    }

    public String getGeometryWKT() {
        return geometryWKT;
    }

    public void setGeometryWKT(String geometryWKT) {
        this.geometryWKT = geometryWKT;
    }

    public Boolean getHasLine() {
        return hasLine;
    }

    public void setHasLine(Boolean hasLine) {
        this.hasLine = hasLine;
    }

    public String getLineCap() {
        return lineCap;
    }

    public void setLineCap(String lineCap) {
        this.lineCap = lineCap;
    }

    public Float getOpacity() {
        return opacity;
    }

    public void setOpacity(Float opacity) {
        this.opacity = opacity;
    }

    public String getStroke() {
        return stroke;
    }

    public void setStroke(String stroke) {
        this.stroke = stroke;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Float getFillOpacity() {
        return fillOpacity;
    }

    public void setFillOpacity(Float fillOpacity) {
        this.fillOpacity = fillOpacity;
    }

    public String getMarkerColor() {
        return markerColor;
    }

    public void setMarkerColor(String markerColor) {
        this.markerColor = markerColor;
    }

    public Float getStrokeOpacity() {
        return strokeOpacity;
    }

    public void setStrokeOpacity(Float strokeOpacity) {
        this.strokeOpacity = strokeOpacity;
    }

    public Float getStrokeWidth() {
        return strokeWidth;
    }

    public void setStrokeWidth(Float strokeWidth) {
        this.strokeWidth = strokeWidth;
    }


}