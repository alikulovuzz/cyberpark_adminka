package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_extra_contract")
public class ExtraContract implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_EXTRA_CONTRACT_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "contrct_id", nullable=false, insertable = false, updatable = false)
    private long companyId;
    @ManyToOne
    @JoinColumn(name = "contract_id")
    private Contract contract;

    @Column(name = "extra_contract_number", nullable = false, length = 40)
    private String extraContractNumber;

    @Column(name = "max_unit_count", nullable=false)
    private long maxUnitCount;

    @Column(name = "max_user_count", nullable=false)
    private long maxUserCount;

    @Column(name = "max_poi_count", nullable=false)
    private long maxPoiCount;

    @Column(name = "max_geo_fance_count", nullable=false)
    private long maxGeoFanceCount;

    @Column(name = "c_reg_date", nullable=true)
    private Timestamp registrationDate;

    @Column(name = "c_mod_date", nullable=true)
    private Timestamp modificationDate;

    @Column(name = "c_exp_date", nullable=true)
    private Timestamp expiredDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public String getExtraContractNumber() {
        return extraContractNumber;
    }

    public void setExtraContractNumber(String extraContractNumber) {
        this.extraContractNumber = extraContractNumber;
    }

    public long getMaxUnitCount() {
        return maxUnitCount;
    }

    public void setMaxUnitCount(long maxUnitCount) {
        this.maxUnitCount = maxUnitCount;
    }

    public long getMaxUserCount() {
        return maxUserCount;
    }

    public void setMaxUserCount(long maxUserCount) {
        this.maxUserCount = maxUserCount;
    }

    public long getMaxPoiCount() {
        return maxPoiCount;
    }

    public void setMaxPoiCount(long maxPoiCount) {
        this.maxPoiCount = maxPoiCount;
    }

    public long getMaxGeoFanceCount() {
        return maxGeoFanceCount;
    }

    public void setMaxGeoFanceCount(long maxGeoFanceCount) {
        this.maxGeoFanceCount = maxGeoFanceCount;
    }

    public Timestamp getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Timestamp registrationDate) {
        this.registrationDate = registrationDate;
    }

    public Timestamp getModificationDate() {
        return modificationDate;
    }

    public void setModificationDate(Timestamp modificationDate) {
        this.modificationDate = modificationDate;
    }

    public Timestamp getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Timestamp expiredDate) {
        this.expiredDate = expiredDate;
    }
}
