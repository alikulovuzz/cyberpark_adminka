package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

@Entity
@Table(name = "uzgps_user")
public class User implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_USER_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "manager_id", nullable = false)
    private Long managerId;

    @Column(name = "profile_id", nullable = true, insertable = false, updatable = false)
    private Long profileId;
    @OneToOne
    @JoinColumn(name = "profile_id")
    private Profile profile;

    @Column(name = "user_type_id")
    private Long userTypeId;

    @Column(name = "login", unique = false)
    private String login;

    @Column(name = "password")
    private String password;

    @Column(name = "surname")
    private String surName;

    //    @NotEmpty(message = "Please enter name")
    @Column(name = "name")
    private String name;

    @Column(name = "middlename")
    private String middleName;

    @Column(name = "photo_id", nullable = true, insertable = false, updatable = false)
    private Long photoId;
    @ManyToOne
    @JoinColumn(name = "photo_id")
    private FileStorage photo;

    @Column(name = "contract_id", nullable = true, insertable = false, updatable = false)
    private Long contractId;
    @ManyToOne
    @JoinColumn(name = "contract_id")
    private Contract contract;

    @Column(name = "last_logged_in", nullable = true)
    private Timestamp lastLoggedIn;

    @Column(name = "u_recovery_key", nullable = true)
    private String recoveryKey;

    @Column(name = "u_recovery_exp", nullable = true)
    private Timestamp recoveryExp;

    @Column(name = "u_block", length = 1)
    private String block;

    @Column(name = "u_login_attemp", nullable = true)
    private Integer loginAttemp;

    @Column(name = "role_id", nullable = true, insertable = false, updatable = false)
    private Long roleId;
    @ManyToOne
    @JoinColumn(name = "role_id")
    private Role role;

    @Column(name = "u_status", length = 1)
    private String status;

    @Column(name = "u_reg_date")
    private Timestamp regDate;

    @Column(name = "u_mod_date")
    private Timestamp modDate;

    @Column(name = "u_exp_date")
    private Timestamp expDate;

    @Column(name = "auth_token")
    private String authToken;

    @Column(name = "sys_admin_note")
    private String sysAdminNote;

    @Column(name = "api_token")
    private String apiToken;

    @Column(name = "token_exp_date")
    private Timestamp tokenExpDate;

    @Transient
    private String operatorLogin;

    @Transient
    private Long interfaceUserId;

    @Transient
    private Long interfaceContractId;

    @Transient
    private String interfaceAuthToken;

    @Transient
    private UserRole userRole;

    public User() {
        this.managerId = 0L;
        this.profileId = 0L;
        this.profile = null;
        this.userTypeId = 0L;
        this.login = null;
        this.password = null;
        this.surName = null;
        this.name = null;
        this.middleName = null;
        this.photoId = null;
        this.photo = null;
        this.contractId = null;
        this.contract = null;
        this.lastLoggedIn = null;
        this.recoveryKey = null;
        this.recoveryExp = null;
        this.block = "A";
        this.loginAttemp = null;
        this.role = null;
        this.roleId = 1L;
        this.status = "A";
        this.regDate = new Timestamp(System.currentTimeMillis());
        this.modDate = null;
        this.expDate = null;
        this.operatorLogin = null;
        this.interfaceUserId = null;
        this.interfaceContractId = null;
        this.interfaceAuthToken = null;

        this.tokenExpDate = null;
    }

    public Long getContractId() {
        return contractId;
    }

    /* ----------- GETTER & SETTERs ----------- >> */
    public String getRecoveryKey() {
        return recoveryKey;
    }

    public void setRecoveryKey(String recoveryKey) {
        this.recoveryKey = recoveryKey;
    }

    public Timestamp getRecoveryExp() {
        return recoveryExp;
    }

    public void setRecoveryExp(Timestamp recoveryExp) {
        this.recoveryExp = recoveryExp;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getInterfaceUserId() {
        if (this.interfaceUserId == null)
            return this.id;

        return this.interfaceUserId;
    }

    public void setInterfaceUserId(Long interfaceUserId) {
        this.interfaceUserId = interfaceUserId;
    }

    public Long getInterfaceContractId() {
        return interfaceContractId;
    }

    public void setInterfaceContractId(Long interfaceContractId) {
        this.interfaceContractId = interfaceContractId;
    }

    public String getInterfaceAuthToken() {
        return interfaceAuthToken;
    }

    public void setInterfaceAuthToken(String interfaceAuthToken) {
        this.interfaceAuthToken = interfaceAuthToken;
    }

    public Long getManagerId() {
        return managerId;
    }

    public void setManagerId(Long managerId) {
        this.managerId = managerId;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Profile getProfile() {
        return profile;
    }

    public void setProfile(Profile profile) {
        this.profile = profile;
    }

    public Long getUserTypeId() {
        return userTypeId;
    }

    public void setUserTypeId(Long userTypeId) {
        this.userTypeId = userTypeId;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public Long getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Long photoId) {
        this.photoId = photoId;
    }

    public FileStorage getPhoto() {
        return photo;
    }

    public void setPhoto(FileStorage photo) {
        this.photo = photo;
    }

//    public Long getContractId() {
//        return contractId;
//    }
//
//    public void setContractId(Long contractId) {
//        this.contractId = contractId;
//    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
        if (contract != null)
            this.contractId = contract.getId();
    }

    public Timestamp getLastLoggedIn() {
        return lastLoggedIn;
    }

    public void setLastLoggedIn(Timestamp lastLoggedIn) {
        this.lastLoggedIn = lastLoggedIn;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public String getRegDateFormatteed() {
        if (regDate == null) return "";
        else {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            return df.format(regDate);
        }
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Integer getLoginAttemp() {
        return loginAttemp;
    }

    public void setLoginAttemp(Integer loginAttemp) {
        this.loginAttemp = loginAttemp;
    }

    public String getOperatorLogin() {
        return operatorLogin;
    }

    public void setOperatorLogin(String operatorLogin) {
        this.operatorLogin = operatorLogin;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getSysAdminNote() {
        return sysAdminNote;
    }

    public void setSysAdminNote(String sysAdminNote) {
        this.sysAdminNote = sysAdminNote;
    }

    public UserRole getUserRole() {
        return userRole;
    }

    public void setUserRole(UserRole userRole) {
        this.userRole = userRole;
    }

    public String getApiToken() {
        return apiToken;
    }

    public void setApiToken(String apiToken) {
        this.apiToken = apiToken;
    }

    public Timestamp getTokenExpDate() {
        return tokenExpDate;
    }

    public String getTokenExpDatePretty() {
        if (tokenExpDate != null) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
            return simpleDateFormat.format(tokenExpDate);
        }
        return null;
    }

    public Long getTokenExpDateTime() {
        if (tokenExpDate != null) {
            return tokenExpDate.getTime();
        }
        return null;
    }

    public void setTokenExpDate(Timestamp tokenExpDate) {
        this.tokenExpDate = tokenExpDate;
    }

    /* ----------- GETTER & SETTERs ----------- >> */

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", managerId=" + managerId +
                ", profileId=" + profileId +
                ", profile=" + profile +
                ", userTypeId=" + userTypeId +
                ", login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", surName='" + surName + '\'' +
                ", name='" + name + '\'' +
                ", middleName='" + middleName + '\'' +
                ", photoId=" + photoId +
                ", photo=" + photo +
                ", contractId=" + contractId +
                ", contract=" + contract +
                ", lastLoggedIn=" + lastLoggedIn +
                ", recoveryKey='" + recoveryKey + '\'' +
                ", recoveryExp=" + recoveryExp +
                ", block='" + block + '\'' +
                ", loginAttemp=" + loginAttemp +
                ", roleId=" + roleId +
                ", role=" + role +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                ", operatorLogin='" + operatorLogin + '\'' +
                ", interfaceUserId=" + interfaceUserId +
                ", authToken=" + authToken +
                ", sysAdminNote=" + sysAdminNote +
                '}';
    }


}
