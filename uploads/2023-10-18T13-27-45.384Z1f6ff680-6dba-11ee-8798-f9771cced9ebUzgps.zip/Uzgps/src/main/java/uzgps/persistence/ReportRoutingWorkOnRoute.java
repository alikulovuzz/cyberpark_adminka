package uzgps.persistence;

import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Immutable
@Table(name = "uzgps_routing_report_3")
public class ReportRoutingWorkOnRoute implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", updatable = false, nullable = false)
    private Long id;

    @Column(name = "t_contract_id", updatable = false, nullable = false)
    private Long contractId;

    @Column(name = "company_id", updatable = false, nullable = false)
    private Long companyId;

    @Column(name = "company_name", updatable = false, nullable = false)
    private String companyName;

    @Column(name = "t_route_id", updatable = false, nullable = false)
    private Long routeId;

    @Column(name = "route_name")
    private String routeName;

    @Column(name = "t_mobject_id")
    private Long mobjectId;

    @Column(name = "mobject_name")
    private String mobjectName;

    @Column(name = "mo_platenumber")
    private String plateNumber;

    @Column(name = "date_block")
    private Timestamp dateBlock;


    @Column(name = "trip_started_first")
    private Timestamp tripStartedFirst;

    @Column(name = "trip_finished_last")
    private Timestamp tripFinishedLast;

    @Column(name = "trip_work_time")
    private String tripWorkTime;

    @Column(name = "trip_work_time_seconds")
    private Long tripWorkTimeSeconds;

    @Column(name = "trip_deviation")
    private String tripDeviation;

    @Column(name = "trip_deviation_seconds")
    private Long tripDeviationSeconds;

    @Column(name = "trip_planned_count")
    private Long tripPlannedCount;

    @Column(name = "trip_status_with_narusheniye")
    private Long tripStatusWithDeviation;

    @Column(name = "trip_status_no_narusheniye")
    private Long tripStatusNoDeviation;

    @Column(name = "trip_status_regular")
    private Long tripStatusRegular;

    @Column(name = "trip_status_total_passed")
    private Long tripStatusTotalPassed;

    @Column(name = "trip_status_not_finished")
    private Long tripStatusNotFinished;

    @Column(name = "trip_distance_on_trip")
    private Double tripDistanceOnTrip;

    @Column(name = "trip_distance_out_trip")
    private Double tripDistanceOutTrip;

    @Column(name = "trip_distance_total")
    private Double tripDistanceTotal;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Long getRouteId() {
        return routeId;
    }

    public void setRouteId(Long routeId) {
        this.routeId = routeId;
    }

    public String getRouteName() {
        return routeName;
    }

    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public Timestamp getDateBlock() {
        return dateBlock;
    }

    public void setDateBlock(Timestamp dateBlock) {
        this.dateBlock = dateBlock;
    }

    public Timestamp getTripStartedFirst() {
        return tripStartedFirst;
    }

    public void setTripStartedFirst(Timestamp tripStartedFirst) {
        this.tripStartedFirst = tripStartedFirst;
    }

    public Timestamp getTripFinishedLast() {
        return tripFinishedLast;
    }

    public void setTripFinishedLast(Timestamp tripFinishedLast) {
        this.tripFinishedLast = tripFinishedLast;
    }

    public String getTripWorkTime() {
        return tripWorkTime;
    }

    public void setTripWorkTime(String tripWorkTime) {
        this.tripWorkTime = tripWorkTime;
    }

    public Long getTripWorkTimeSeconds() {
        return tripWorkTimeSeconds;
    }

    public void setTripWorkTimeSeconds(Long tripWorkTimeSeconds) {
        this.tripWorkTimeSeconds = tripWorkTimeSeconds;
    }

    public String getTripDeviation() {
        return tripDeviation;
    }

    public void setTripDeviation(String tripDeviation) {
        this.tripDeviation = tripDeviation;
    }

    public Long getTripDeviationSeconds() {
        return tripDeviationSeconds;
    }

    public void setTripDeviationSeconds(Long tripDeviationSeconds) {
        this.tripDeviationSeconds = tripDeviationSeconds;
    }

    public Long getTripPlannedCount() {
        return tripPlannedCount;
    }

    public void setTripPlannedCount(Long tripPlannedCount) {
        this.tripPlannedCount = tripPlannedCount;
    }

    public Long getTripStatusWithDeviation() {
        return tripStatusWithDeviation;
    }

    public void setTripStatusWithDeviation(Long tripStatusWithDeviation) {
        this.tripStatusWithDeviation = tripStatusWithDeviation;
    }

    public Long getTripStatusNoDeviation() {
        return tripStatusNoDeviation;
    }

    public void setTripStatusNoDeviation(Long tripStatusNoDeviation) {
        this.tripStatusNoDeviation = tripStatusNoDeviation;
    }

    public Long getTripStatusRegular() {
        return tripStatusRegular;
    }

    public void setTripStatusRegular(Long tripStatusRegular) {
        this.tripStatusRegular = tripStatusRegular;
    }

    public Long getTripStatusTotalPassed() {
        return tripStatusTotalPassed;
    }

    public void setTripStatusTotalPassed(Long tripStatusTotalPassed) {
        this.tripStatusTotalPassed = tripStatusTotalPassed;
    }

    public Long getTripStatusNotFinished() {
        return tripStatusNotFinished;
    }

    public void setTripStatusNotFinished(Long tripStatusNotFinished) {
        this.tripStatusNotFinished = tripStatusNotFinished;
    }

    public Double getTripDistanceOnTrip() {
        return tripDistanceOnTrip;
    }

    public void setTripDistanceOnTrip(Double tripDistanceOnTrip) {
        this.tripDistanceOnTrip = tripDistanceOnTrip;
    }

    public Double getTripDistanceOutTrip() {
        return tripDistanceOutTrip;
    }

    public void setTripDistanceOutTrip(Double tripDistanceOutTrip) {
        this.tripDistanceOutTrip = tripDistanceOutTrip;
    }

    public Double getTripDistanceTotal() {
        return tripDistanceTotal;
    }

    public void setTripDistanceTotal(Double tripDistanceTotal) {
        this.tripDistanceTotal = tripDistanceTotal;
    }

    @Override
    public String toString() {
        return "ReportRoutingWorkOnRoute{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", companyId=" + companyId +
                ", companyName='" + companyName + '\'' +
                ", routeId=" + routeId +
                ", routeName='" + routeName + '\'' +
                ", mobjectId=" + mobjectId +
                ", mobjectName='" + mobjectName + '\'' +
                ", plateNumber='" + plateNumber + '\'' +
                ", dateBlock=" + dateBlock +
                ", tripStartedFirst=" + tripStartedFirst +
                ", tripFinishedLast=" + tripFinishedLast +
                ", tripWorkTime=" + tripWorkTime +
                ", tripWorkTimeSeconds=" + tripWorkTimeSeconds +
                ", tripDeviation=" + tripDeviation +
                ", tripDeviationSeconds=" + tripDeviationSeconds +
                ", tripPlannedCount=" + tripPlannedCount +
                ", tripStatusWithDeviation=" + tripStatusWithDeviation +
                ", tripStatusNoDeviation=" + tripStatusNoDeviation +
                ", tripStatusRegular=" + tripStatusRegular +
                ", tripStatusTotalPassed=" + tripStatusTotalPassed +
                ", tripStatusNotFinished=" + tripStatusNotFinished +
                ", tripDistanceOnTrip=" + tripDistanceOnTrip +
                ", tripDistanceOutTrip=" + tripDistanceOutTrip +
                ", tripDistanceTotal=" + tripDistanceTotal +
                '}';
    }
}
