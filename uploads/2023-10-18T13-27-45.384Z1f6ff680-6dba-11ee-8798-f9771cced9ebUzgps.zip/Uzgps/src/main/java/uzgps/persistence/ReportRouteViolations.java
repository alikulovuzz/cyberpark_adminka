package uzgps.persistence;

import org.hibernate.annotations.Immutable;
import uzgps.excel.tripReports.AbstractTripItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Immutable
@Table(schema = "reporting")
public class ReportRouteViolations extends AbstractTripItem implements Serializable {

    @Id
    private Long id;

    @Column(name = "trip_name")
    private String tripName;

    @Column(name = "trip_direction")
    private String tripDirection;

    @Column(name = "trip_description")
    private String tripDescription;

    @Column(name = "mobject_name")
    private String mobjectName;

    @Column(name = "mo_platenumber")
    private String plateNumber;

    @Column(name = "staff_name")
    private String staffName;

    @Column(name = "trip_num")
    private Integer tripNum;

    @Column(name = "trip_period")
    private String tripPeriod;

    @Column(name = "violation_type")
    private Integer violationType;

    @Column(name = "max_speed")
    private Integer maxSpeed;

    @Column(name = "violation_time")
    private Timestamp violationTime;

    @Column(name = "violation_longitude")
    private Double violationLongitude;

    @Column(name = "violation_latitude")
    private Double violationLatitude;

    @Column(name = "violation_place")
    private String violationPlace;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getTripName() {
        return tripName;
    }

    @Override
    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    @Override
    public String getTripDirection() {
        return tripDirection;
    }

    @Override
    public void setTripDirection(String tripDirection) {
        this.tripDirection = tripDirection;
    }

    @Override
    public String getTripDescription() {
        return tripDescription;
    }

    @Override
    public void setTripDescription(String tripDescription) {
        this.tripDescription = tripDescription;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public Integer getTripNum() {
        return tripNum;
    }

    public void setTripNum(Integer tripNum) {
        this.tripNum = tripNum;
    }

    public String getTripPeriod() {
        return tripPeriod;
    }

    public void setTripPeriod(String tripPeriod) {
        this.tripPeriod = tripPeriod;
    }

    public Integer getViolationType() {
        return violationType;
    }

    public void setViolationType(Integer violationType) {
        this.violationType = violationType;
    }

    public Integer getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(Integer maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public Timestamp getViolationTime() {
        return violationTime;
    }

    public void setViolationTime(Timestamp violationTime) {
        this.violationTime = violationTime;
    }

    public Double getViolationLongitude() {
        return violationLongitude;
    }

    public void setViolationLongitude(Double violationLongitude) {
        this.violationLongitude = violationLongitude;
    }

    public Double getViolationLatitude() {
        return violationLatitude;
    }

    public void setViolationLatitude(Double violationLatitude) {
        this.violationLatitude = violationLatitude;
    }

    public String getViolationPlace() {
        return violationPlace;
    }

    public void setViolationPlace(String violationPlace) {
        this.violationPlace = violationPlace;
    }

    @Override
    public String toString() {
        return "ReportRouteViolations{" +
                "id=" + id +
                ", tripName='" + tripName + '\'' +
                ", tripDirection='" + tripDirection + '\'' +
                ", tripDescription='" + tripDescription + '\'' +
                ", mobjectName='" + mobjectName + '\'' +
                ", plateNumber='" + plateNumber + '\'' +
                ", staffName='" + staffName + '\'' +
                ", tripNum=" + tripNum +
                ", tripPeriod='" + tripPeriod + '\'' +
                ", violationType=" + violationType +
                ", maxSpeed=" + maxSpeed +
                ", violationTime=" + violationTime +
                ", violationLongitude=" + violationLongitude +
                ", violationLatitude=" + violationLatitude +
                ", violationPlace='" + violationPlace + '\'' +
                '}';
    }
}
