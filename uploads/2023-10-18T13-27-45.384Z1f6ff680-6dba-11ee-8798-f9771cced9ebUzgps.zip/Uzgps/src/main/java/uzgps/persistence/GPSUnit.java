package uzgps.persistence;

import org.hibernate.annotations.WhereJoinTable;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "uzgps_gps_unit")
public class GPSUnit implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_GPS_UNIT_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "gu_name", nullable = false, length = 255)
    private String name;

    @Column(name = "gu_imei", nullable = false, length = 256)
    private String imei;

//    @Basic
//    @Column(name = "gu_sim_id", nullable = true, insertable = false, updatable = false)
//    private Long simId;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "uzgps_gps_unit_sim",
            joinColumns = @JoinColumn(name = "gus_gps_unit_id"),
            inverseJoinColumns = @JoinColumn(name = "gus_sim_id")
    )
    @WhereJoinTable(clause = "gus_status='A'")
    private List<Sim> sim1List;

    @OneToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "uzgps_gps_unit_sim",
            joinColumns = @JoinColumn(name = "gus_gps_unit_id"),
            inverseJoinColumns = @JoinColumn(name = "gus_sim_2_id")
    )
    @WhereJoinTable(clause = "gus_status='A'")
    private List<Sim> sim2List;

    @Column(name = "gu_gpsunit_type_id", nullable = true, insertable = false, updatable = false)
    private Long gpsUnitTypId;

    @ManyToOne
    @JoinColumn(name = "gu_gpsunit_type_id")
    private GPSUnitType gpsUnitType;

    @OneToMany()
    @JoinTable(
            name = "uzgps_mobject_gps_units",
            joinColumns = @JoinColumn(name = "mogu_mobject_id"),
            inverseJoinColumns = @JoinColumn(name = "mogu_gps_unit_id")
    )
    private List<MObject> mobjectList;

    @Basic
    @Column(name = "gu_login", nullable = true)
    private String gpsUnitLogin;

    @Basic
    @Column(name = "gu_password", nullable = true)
    private String gpsUnitPassword;

    @Column(name = "gu_block", nullable = false, length = 1)
    private String block;

    @Basic
    @Column(name = "gu_d_min", nullable = true)
    private Integer dMin;

    @Basic
    @Column(name = "gu_d_big", nullable = true)
    private Integer dBig;

    @Basic
    @Column(name = "gu_t_big", nullable = true)
    private Integer tBig;

    @Basic
    @Column(name = "is_mobile", nullable = true)
    private Integer isMobile;

    @Column(name = "gu_status", nullable = false, length = 1)
    private String status;

    @Column(name = "gu_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "gu_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "gu_exp_date", nullable = true)
    private Timestamp expDate;

    @Column(name = "sys_admin_note")
    private String sysAdminNote;

    public GPSUnit() {
        this.block = "A";
        this.regDate = new Timestamp(System.currentTimeMillis());
        this.status = "A";
        this.name = "";
        this.imei = "";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public List<Sim> getSim1List() {

        return sim1List;
    }

    public void setSim1List(List<Sim> sim1List) {
        this.sim1List = sim1List;
    }

    public Sim getSim1() {
        return (sim1List != null && sim1List.size() > 0) ? sim1List.get(0) : null;
    }

    public void setSim1(Sim sim1) {
        if (sim1List == null) sim1List = new ArrayList<>();
        sim1List.clear();
        sim1List.add(sim1);
    }

    public List<Sim> getSim2List() {
        return sim2List;
    }

    public void setSim2List(List<Sim> sim2List) {
        this.sim2List = sim2List;
    }

    public Sim getSim2() {
        return (sim2List != null && sim2List.size() > 0) ? sim2List.get(0) : null;
    }

    public void setSim2(Sim sim2) {
        if (sim2List == null) {
            sim2List = new ArrayList<>();
        }

        sim2List.clear();
        sim2List.add(sim2);
    }

    public Long getGpsUnitTypId() {
        return gpsUnitTypId;
    }

    public void setGpsUnitTypId(Long gpsUnitTypId) {
        this.gpsUnitTypId = gpsUnitTypId;
    }

    //
    public GPSUnitType getGpsUnitType() {
        return gpsUnitType;
    }

    public void setGpsUnitType(GPSUnitType gpsUnitType) {
        this.gpsUnitType = gpsUnitType;
    }

    public List<MObject> getMobjectList() {
        return mobjectList;
    }

    public void setMobjectList(List<MObject> mobjectList) {
        this.mobjectList = mobjectList;
    }

    public String getGpsUnitLogin() {
        return gpsUnitLogin;
    }

    public void setGpsUnitLogin(String gpsUnitLogin) {
        this.gpsUnitLogin = gpsUnitLogin;
    }

    public String getGpsUnitPassword() {
        return gpsUnitPassword;
    }

    public void setGpsUnitPassword(String gpsUnitPassword) {
        this.gpsUnitPassword = gpsUnitPassword;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public Integer getdMin() {
        return dMin;
    }

    public void setdMin(Integer dMin) {
        this.dMin = dMin;
    }

    public Integer getdBig() {
        return dBig;
    }

    public void setdBig(Integer dBig) {
        this.dBig = dBig;
    }

    public Integer gettBig() {
        return tBig;
    }

    public void settBig(Integer tBig) {
        this.tBig = tBig;
    }

    public Integer getIsMobile() {
        return isMobile;
    }

    public void setIsMobile(Integer isMobile) {
        this.isMobile = isMobile;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public String getSysAdminNote() {
        return sysAdminNote;
    }

    public void setSysAdminNote(String sysAdminNote) {
        this.sysAdminNote = sysAdminNote;
    }

    public String toString() {

        return "GPSUnit{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", imei='" + imei + '\'' +
//                ", simId=" + simId +
                ", sim1List=" + sim1List +
                ", sim2List=" + sim2List +
                ", gpsUnitTypId=" + gpsUnitTypId +
                ", gpsUnitType=" + gpsUnitType +
                ", mobjectList=" + mobjectList +
                ", gpsUnitLogin='" + gpsUnitLogin + '\'' +
                ", gpsUnitPassword='" + gpsUnitPassword + '\'' +
                ", block='" + block + '\'' +
                ", dMin=" + dMin +
                ", dBig=" + dBig +
                ", tBig=" + tBig +
                ", isMobile=" + isMobile +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                ", sysAdminNote='" + sysAdminNote + '\'' +
                '}';
    }
}
