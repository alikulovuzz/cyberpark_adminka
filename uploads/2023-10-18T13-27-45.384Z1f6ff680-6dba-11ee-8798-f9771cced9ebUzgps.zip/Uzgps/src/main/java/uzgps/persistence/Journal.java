package uzgps.persistence;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by Saidolim on 02.04.14.
 */

@Entity
@Table(name = "uzgps_journal")

public class Journal implements Serializable {
    public static final String sequenceName = "SEQ_JOURNAL_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "j_classname", nullable = true, length = 256)
    private String className;

    @Basic
    @Column(name = "j_action", nullable = false)
    private Integer action;

    @Basic
    @Column(name = "j_comment", nullable = false)
    private Integer comment;

    @Column(name = "j_date", nullable = false)
    private Timestamp date;

    @Basic
    @Column(name = "j_user_id", nullable = false)
    private Long userId;

    @Basic
    @Column(name = "j_object_id", nullable = false)
    private Long objectId;

    @Basic
    @Column(name = "j_editor")
    private String editor;

    @Basic
    @Column(name = "j_type")
    private Integer type;

    @Lob
    @Type(type = "org.hibernate.type.StringClobType")
    @Column(name = "j_object", nullable = true)
    private String jobject;

    @Column(name = "j_status", nullable = false, length = 1)
    private String status;

    @Column(name = "j_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "j_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "j_exp_date", nullable = true)
    private Timestamp expDate;


    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public String getEditor() {
        return editor;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public int getComment() {
        return comment;
    }

    public void setComment(int comment) {
        this.comment = comment;
    }

    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobject() {
        return jobject;
    }

    public void setJobject(String jobject) {
        this.jobject = jobject;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
