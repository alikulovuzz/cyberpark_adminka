package uzgps.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Type;
import uzgps.common.FileStorageService;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Gayratjon on 3/31/14.
 */

@Entity
@Table(name = "uzgps_geo_fence")
public class GeoFence {

    public static final String sequenceName = "SEQ_UZGPS_GEO_FENCE_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "contract_id", nullable = true)
    private Long contractId;

    @Column(name = "status", nullable = false, length = 1)
    private String status;

    @Column(name = "name", nullable = true, length = 256)
    private String name;

    @Column(name = "font_color", nullable = false, length = 8)
    private String fontColor;

    @Column(name = "font_size", nullable = false)
    private Integer fontSize;

    @Column(name = "group_id", nullable = false, insertable = false, updatable = false)
    private Long groupId;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "group_id")
    private ZoiGroup group;

    @JsonIgnore
    @Column(name = "image_id", nullable = true, insertable = false, updatable = false)
    private Long imageId;
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "image_id")
    private FileStorage image;

    @JsonIgnore
    @Column(name = "file_id", nullable = true, insertable = false, updatable = false)
    private Long fileId;
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "file_id")
    private FileStorage file;

    @Lob
    @Type(type = "org.hibernate.type.StringClobType")
    @Column(name = "description", nullable = true)
    private String description;


    @Column(name = "type", nullable = false, length = 25)
    private String type;

    @Column(name = "color", nullable = false, length = 8)
    private String color;

    @Column(name = "radius", nullable = true)
    private Float radius;

    @Column(name = "area", nullable = true)
    private Double area;

    @Column(name = "perimeter", nullable = true)
    private Double perimeter;

    @Column(name = "geometry_opacity", nullable = true)
    private Double geometryOpacity;

    @Column(name = "wkt_string", nullable = true)
    private String wktString;

    @Column(name = "gf_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "gf_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "gf_exp_date", nullable = true)
    private Timestamp expDate;

    @OneToMany(mappedBy = "geoFence", cascade = {CascadeType.REMOVE}, orphanRemoval = true)
    @OrderBy(value = "id")
    private List<GeoFencePoint> geoFencePointList;

    @Transient
    private Byte userPermission;

    @Transient
    private boolean isMonitored = false;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public void setFontSize(Integer fontSize) {
        this.fontSize = fontSize;
    }

    public Long getGroupId() { return groupId; }

    public void setGroupId(Long groupId) { this.groupId = groupId; }

    public ZoiGroup getGroup() {
        return group;
    }

    public void setGroup(ZoiGroup group) {
        this.group = group;
    }

    public FileStorage getImage() {
        return image;
    }

    public void setImage(FileStorage image) {
        this.image = image;
    }

    public Long getImageId() {
        return imageId;
    }

    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }

    public FileStorage getFile() {
        return image;
    }

    public void setFile(FileStorage file) {
        this.file = file;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    public String getUrlImage() {
        return (image != null) ? FileStorageService.generateFileName(image.getId(), image.getFilename()) : null;
    }
    public String getUrlFile() {
        return (file != null) ? FileStorageService.generateFileName(file.getId(), file.getFilename()) : null;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Float getRadius() {
        return radius;
    }

    public void setRadius(Float radius) {
        this.radius = radius;
    }

    public Double getArea() {
        return area;
    }

    public void setArea(Double area) {
        this.area = area;
    }

    public Double getPerimeter() {
        return perimeter;
    }

    public void setPerimeter(Double perimeter) {
        this.perimeter = perimeter;
    }

    public Double getGeometryOpacity() {
        return geometryOpacity;
    }

    public void setGeometryOpacity(Double geometryOpacity) {
        this.geometryOpacity = geometryOpacity;
    }

    public String getWktString() {
        return wktString;
    }

    public void setWktString(String wktString) {
        if (wktString == null) wktString = "";
        this.wktString = wktString;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public List<GeoFencePoint> getGeoFencePointList() {
        return geoFencePointList;
    }

    public void setGeoFencePointList(List<GeoFencePoint> geoFencePointList) {
        this.geoFencePointList = geoFencePointList;
    }

    public Byte getUserPermission() {
        return userPermission;
    }

    public void setUserPermission(Byte userPermission) {
        this.userPermission = userPermission;
    }

    public boolean isMonitored() {
        return isMonitored;
    }

    public void setMonitored(boolean monitored) {
        isMonitored = monitored;
    }

    @Override
    public String toString() {
        return "GeoFence{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", status='" + status + '\'' +
                ", name='" + name + '\'' +
                ", fontColor='" + fontColor + '\'' +
                ", fontSize=" + fontSize +
                ", groupId=" + groupId +
                ", fileId=" + fileId +
                ", imageId=" + imageId +
                ", description='" + description + '\'' +
                ", type='" + type + '\'' +
                ", color='" + color + '\'' +
                ", radius=" + radius +
                ", area=" + area +
                ", perimeter=" + perimeter +
                ", geometryOpacity=" + geometryOpacity +
                ", wktString='" + wktString + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                ", geoFencePointList=" + geoFencePointList +
                ", userPermission=" + userPermission +
                '}';
    }
}

