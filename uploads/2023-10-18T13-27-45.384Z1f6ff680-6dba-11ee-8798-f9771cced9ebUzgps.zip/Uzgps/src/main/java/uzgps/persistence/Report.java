package uzgps.persistence;

import org.springframework.context.i18n.LocaleContextHolder;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Locale;

/**
 * User: Sheroz Khaydarov
 * Date: 21.02.13 Time: 19:31
 */
@Entity
@Table(name = "uzgps_report")
public class Report implements Serializable {

    private static final int LANG_RU = 0;
    private static final int LANG_EN = 1;
    private static final int LANG_UZC = 2;
    private static final int LANG_UZL = 3;
    private static int languageId = LANG_RU;


    public static final int DB_REPORT = 0; // DB Report
    public static final int DB_MAIN = 1; // DB Uzgps
    public static final int DB_DEFAULT = DB_REPORT; // Default Database, can be controlled here

    public static final String sequenceName = "SEQ_UZGPS_REPORT_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    @Column(name = "id", nullable = false, precision = 19)
    private Long id;

    @Column(name = "name", length = 255)
    private String name;

    @Column(name = "name_en", length = 255)
    private String nameEn;

    @Column(name = "name_uzc", length = 255)
    private String nameUzc;

    @Column(name = "name_uzl", length = 255)
    private String nameUzl;

    @Column(name = "description", nullable = true, length = 255)
    private String description;

    @Column(name = "file_ext", length = 16)
    private String fileExtention;

    @Column(name = "file_size", precision = 19)
    private Long FileSize;

    @Column(name = "original_filename", length = 255)
    private String OriginalFileName;

    @Column(name = "export_filename", nullable = true, length = 64)
    private String ExportFileName;

    @Column(name = "has_param_script", nullable = true)
    private Boolean hasParameterScript;

    @Column(name = "has_generator_script", nullable = true)
    private Boolean hasGeneratorScript;

    @Column(name = "tenant_id", nullable = true)
    private Long tenantId;

    @Column(name = "report_type", nullable = true)
    private Long reportType;

    @Column(name = "visible", nullable = true)
    private Boolean visible;

    @Column(name = "language", nullable = true)
    private String language;

    @Column(name = "working_database", nullable = true)
    private Integer workingDb;


    @Transient
    private Long aclId;

    @Transient
    private Integer aclValue;

    public Report() {
        languageId = LANG_RU;
        Locale locale = LocaleContextHolder.getLocale();
        String lang = locale.getLanguage();
        if (lang != null && !lang.isEmpty()) {
            if (lang.equals("uz")) {
                languageId = LANG_UZL;
            } else if (lang.equals("en")) {
                languageId = LANG_EN;
            } else if (lang.equals("uzc")) {
                languageId = LANG_UZC;
            }
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        switch (languageId) {
            case LANG_EN:
                return nameEn;
            case LANG_UZL:
                return nameUzl;
            case LANG_UZC:
                return nameUzc;
        }
        return name;
    }

    public void setReportname(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileExtention() {
        return fileExtention;
    }

    public void setFileExtention(String fileExtention) {
        this.fileExtention = fileExtention;
    }

    public String getOriginalFileName() {
        return OriginalFileName;
    }

    public Long getFileSize() {
        return FileSize;
    }

    public void setFileSize(Long fileSize) {
        FileSize = fileSize;
    }

    public void setOriginalFileName(String originalFileName) {
        OriginalFileName = originalFileName;
    }

    public String getExportFileName() {
        return ExportFileName;
    }

    public void setExportFileName(String exportFileName) {
        ExportFileName = exportFileName;
    }

    public Boolean getHasParameterScript() {
        return hasParameterScript;
    }

    public void setHasParameterScript(Boolean hasParameterScript) {
        this.hasParameterScript = hasParameterScript;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTenantId() {
        return tenantId;
    }

    public void setTenantId(Long tenantId) {
        this.tenantId = tenantId;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Boolean getHasGeneratorScript() {
        return hasGeneratorScript;
    }

    public void setHasGeneratorScript(Boolean hasGeneratorScript) {
        this.hasGeneratorScript = hasGeneratorScript;
    }

    public Long getAclId() {
        return aclId;
    }

    public void setAclId(Long aclId) {
        this.aclId = aclId;
    }

    public Integer getAclValue() {
        return aclValue;
    }

    public void setAclValue(Integer aclValue) {
        this.aclValue = aclValue;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Long getReportType() {
        return reportType;
    }

    public void setReportType(Long reportType) {
        this.reportType = reportType;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getNameRu() {
        return name;
    }

    public void setNameRu(String name) {
        this.name = name;
    }

    public String getNameUzc() {
        return nameUzc;
    }

    public void setNameUzc(String nameUzc) {
        this.nameUzc = nameUzc;
    }

    public String getNameUzl() {
        return nameUzl;
    }

    public void setNameUzl(String nameUzl) {
        this.nameUzl = nameUzl;
    }

    public Integer getWorkingDb() {
        return workingDb;
    }

    public void setWorkingDb(Integer workingDb) {
        this.workingDb = workingDb;
    }

    public int getConstantDbReport() {
        return Report.DB_REPORT;
    }

    public int getConstantDbMain() {
        return Report.DB_MAIN;
    }

    public int getConstantDbDefault() {
        return Report.DB_DEFAULT;
    }

    @Override
    public String toString() {
        return "Report{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", nameEn='" + nameEn + '\'' +
                ", nameUzc='" + nameUzc + '\'' +
                ", nameUzl='" + nameUzl + '\'' +
                ", description='" + description + '\'' +
                ", fileExtention='" + fileExtention + '\'' +
                ", FileSize=" + FileSize +
                ", OriginalFileName='" + OriginalFileName + '\'' +
                ", ExportFileName='" + ExportFileName + '\'' +
                ", hasParameterScript=" + hasParameterScript +
                ", hasGeneratorScript=" + hasGeneratorScript +
                ", tenantId=" + tenantId +
                ", reportType=" + reportType +
                ", visible=" + visible +
                ", workingDb=" + workingDb +
                ", language='" + language + '\'' +
                ", languageId=" + languageId +
                ", aclId=" + aclId +
                ", aclValue=" + aclValue +
                '}';
    }
}