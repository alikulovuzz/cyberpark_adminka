package uzgps.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.context.i18n.LocaleContextHolder;
import uz.netex.uzgps.core.models.sensor.SensorDataType;
import uz.netex.uzgps.core.models.sensor.Translator;

public class SensorDisplay {
        private String name;
        private SensorDataType type;
        private boolean message;
        private boolean tracking;
        private boolean monitoring;

        public SensorDisplay() {
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public SensorDataType getType() {
            return type;
        }

        public void setType(SensorDataType type) {
            this.type = type;
        }

        public boolean isMessage() {
            return message;
        }

        public void setMessage(boolean message) {
            this.message = message;
        }

        public boolean isTracking() {
            return tracking;
        }

        public void setTracking(boolean tracking) {
            this.tracking = tracking;
        }

        public boolean isMonitoring() {
            return monitoring;
        }

        public void setMonitoring(boolean monitoring) {
            this.monitoring = monitoring;
        }

        @JsonIgnore
        public String getTranslatedHeader() {
            String header = name.toUpperCase() + " " +
                    Translator.getName(type, LocaleContextHolder.getLocale());
            if (!type.getUnit().isEmpty()) {
                header += " (" + type.getUnit() + ")";
            }
            return header;
        }
}
