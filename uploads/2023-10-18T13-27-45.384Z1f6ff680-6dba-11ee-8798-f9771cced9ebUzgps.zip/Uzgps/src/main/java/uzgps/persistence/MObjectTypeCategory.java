package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_mobject_type_category")
public class MObjectTypeCategory implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_TYPE_CATEGORY_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "name_en")
    private String nameEn;
    @Column(name = "name_ru")
    private String nameRu;
    @Column(name = "name_uz_cyr")
    private String nameUzCyr;
    @Column(name = "name_uz_lat")
    private String nameUzLat;

    @Column(name = "status", length = 1)
    private String status;

    @Column(name = "reg_date")
    private Timestamp regDate;

    @Column(name = "mod_date")
    private Timestamp modDate;

    @Column(name = "exp_date")
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getNameRu() {
        return nameRu;
    }

    public void setNameRu(String nameRu) {
        this.nameRu = nameRu;
    }

    public String getNameUzCyr() {
        return nameUzCyr;
    }

    public void setNameUzCyr(String nameUzCyr) {
        this.nameUzCyr = nameUzCyr;
    }

    public String getNameUzLat() {
        return nameUzLat;
    }

    public void setNameUzLat(String nameUzLat) {
        this.nameUzLat = nameUzLat;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "MObjectTypeCategory{" +
                "id=" + id +
                ", nameEn='" + nameEn + '\'' +
                ", NameRu='" + nameRu + '\'' +
                ", nameUzCyr='" + nameUzCyr + '\'' +
                ", nameUzLat='" + nameUzLat + '\'' +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
