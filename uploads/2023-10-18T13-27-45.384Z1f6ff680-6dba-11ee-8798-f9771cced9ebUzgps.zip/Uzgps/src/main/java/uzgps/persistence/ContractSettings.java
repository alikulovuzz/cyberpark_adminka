package uzgps.persistence;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import uzgps.common.Converters;
import uzgps.persistence.type.SDListJsonType;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "uzgps_contract_settings")
@TypeDef(name = "sdListJson", typeClass = SDListJsonType.class)
public class ContractSettings implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_CONTRACT_SETTINGS_ID";

    public static final int VM_DATE = 1;
    public static final int VM_TIME = 2;
    //    public static final int VM_SPEED = 3;
    public static final int VM_HIEGHT = 4;
    public static final int VM_ODOMETR = 5;
    public static final int VM_MOVEMENT_VALUE = 6;
    public static final int VM_ANGLE = 7;
    public static final int VM_DIGITAL = 8;
    public static final int VM_INT_BAT_V = 9;
    public static final int VM_INT_BAT_MA = 10;
    public static final int VM_EXT_BAT = 11;
    public static final int VM_OPERATOR = 12;
    public static final int VM_GSM = 13;
    public static final int VM_CELL = 14;
    public static final int VM_LAC = 15;
    public static final int VM_SAT = 16;
    public static final int VM_GNSS = 17;
    public static final int VM_PDOP = 18;
    public static final int VM_HDOP = 19;
    public static final int VM_PCB = 20;
    public static final int VM_P = 21;
    public static final int VM_DEEP_SLEEP = 22;
    public static final int VM_LEVEL_FUEL1 = 23;
    public static final int VM_CAN_SPEED = 24;
    public static final int VM_ENGINE_RPM = 25;
    public static final int VM_ACCELERATOR = 26;
    public static final int VM_ENGINE_HOUR = 27;
    public static final int VM_TOTAL_DISTANCE = 28;
    public static final int VM_SERVICE = 29;
    public static final int VM_FUEL_CONSUPTION = 3;
    public static final int VM_HEGH_RESOLITION = 1;
    public static final int VM_CAN_LEVEL_FUEL = 2;
    public static final int VM_FUEL_ECONOMY = 3;
    public static final int VM_ENGINE_TEMPERATURE = 4;
    public static final int VM_AMBIENT_AIR = 5;
    public static final int VM_VIN = 6;
    public static final int VM_DATE_RECEIVED = 7;
    public static final int VM_TIME_RECEIVED = 8;
    public static final int VM_COM1 = 9;
    public static final int VM_COM2 = 10;
    public static final int VM_LATITUDE = 11;
    public static final int VM_LONGITUDE = 12;
    public static final int VM_SPEED_TRACK = 13;
    public static final int VM_SPEED_IO = 14;
    public static final int VM_DIGITAL1 = 15;
    public static final int VM_DIGITAL2 = 16;
    public static final int VM_DIGITAL3 = 17;
    public static final int VM_DIGITAL4 = 18;
    public static final int VM_ANALOG1 = 19;
    public static final int VM_ANALOG2 = 20;
    public static final int VM_ANALOG3 = 21;
    public static final int VM_ANALOG4 = 22;
    public static final int VM_LEVEL_FUEL2 = 23;
    public static final int VM_COM12 = 24;
    public static final int VM_COM22 = 25;
    public static final int VM_CAN_LEVEL_FUEL2 = 26;
    public static final int VM_FUEL_ECONOMY2 = 27;

    public static final int VT_DATE = 1;
    public static final int VT_TIME = 2;
    //    public static final int VT_SPEED = 3;
    public static final int VT_HIEGHT = 4;
    public static final int VT_ODOMETR = 5;
    public static final int VT_MOVEMENT_VALUE = 6;
    public static final int VT_ANGLE = 7;
    public static final int VT_DIGITAL = 8;
    public static final int VT_INT_BAT_V = 9;
    public static final int VT_INT_BAT_MA = 10;
    public static final int VT_EXT_BAT = 11;
    public static final int VT_OPERATOR = 12;
    public static final int VT_GSM = 13;
    public static final int VT_CELL = 14;
    public static final int VT_LAC = 15;
    public static final int VT_SAT = 16;
    public static final int VT_GNSS = 17;
    public static final int VT_PDOP = 18;
    public static final int VT_HDOP = 19;
    public static final int VT_PCB = 20;
    public static final int VT_P = 21;
    public static final int VT_DEEP_SLEEP = 22;
    public static final int VT_LEVEL_FUEL1 = 23;
    public static final int VT_CAN_SPEED = 24;
    public static final int VT_ENGINE_RPM = 25;
    public static final int VT_ACCELERATOR = 26;
    public static final int VT_ENGINE_HOUR = 27;
    public static final int VT_TOTAL_DISTANCE = 28;
    public static final int VT_SERVICE = 29;
    public static final int VT_FUEL_CONSUPTION = 3;
    public static final int VT_HEGH_RESOLITION = 1;
    public static final int VT_CAN_LEVEL_FUEL = 2;
    public static final int VT_FUEL_ECONOMY = 3;
    public static final int VT_ENGINE_TEMPERATURE = 4;
    public static final int VT_AMBIENT_AIR = 5;
    public static final int VT_VIN = 6;
    public static final int VT_DATE_RECEIVED = 7;
    public static final int VT_TIME_RECEIVED = 8;
    public static final int VT_COM1 = 9;
    public static final int VT_COM2 = 10;
    public static final int VT_LATITUDE = 11;
    public static final int VT_LONGITUDE = 12;
    public static final int VT_SPEED_TRACK = 13;
    public static final int VT_SPEED_IO = 14;
    public static final int VT_DIGITAL1 = 15;
    public static final int VT_DIGITAL2 = 16;
    public static final int VT_DIGITAL3 = 17;
    public static final int VT_DIGITAL4 = 18;
    public static final int VT_ANALOG1 = 19;
    public static final int VT_ANALOG2 = 20;
    public static final int VT_ANALOG3 = 21;
    public static final int VT_ANALOG4 = 22;
    public static final int VT_LEVEL_FUEL2 = 23;
    public static final int VT_COM12 = 24;
    public static final int VT_COM22 = 25;
    public static final int VT_CAN_LEVEL_FUEL2 = 26;
    public static final int VT_FUEL_ECONOMY2 = 27;

    public static final int TRACKING_VALUES_PART1_DEFAULT = 103288576;
    public static final int TRACKING_VALUES_PART2_DEFAULT = 533216;
    public static final int TRACKING_VALUES_PART3_DEFAULT = 0;

    public static final int MESSAGE_VALUES_PART1_DEFAULT = 237604610;
    public static final int MESSAGE_VALUES_PART2_DEFAULT = 67052256;
    public static final int MESSAGE_VALUES_PART3_DEFAULT = 131072;

    public static final int MONITORING_VALUES_PART1_DEFAULT = 31985410;
    public static final int MONITORING_VALUES_PART2_DEFAULT = 33563136;
    public static final int MONITORING_VALUES_PART3_DEFAULT = 28672;

    public static final int TRACK_POPUP_VALUES_PART1_DEFAULT = 103288576;
    public static final int TRACK_POPUP_VALUES_PART2_DEFAULT = 8704;
    public static final int TRACK_POPUP_VALUES_PART3_DEFAULT = 0;

    public static final int PARKING_POPUP_VALUES_PART1_DEFAULT = 4202240;

    public static final int SOS_POPUP_VALUES_PART1_DEFAULT = 4198208;
    public static final int SOS_POPUP_VALUES_PART2_DEFAULT = 8736;
    public static final int SOS_POPUP_VALUES_PART3_DEFAULT = 28672;

    // Value #1
    public static final int OBJECT_NAME = 1;                //	Наименование объекта
    public static final int OBJECT_MODEL = 2;               //	Марка объекта
    public static final int OBJECT_PLATENUMBER = 3;         //	Госномер
    public static final int OBJECT_LIFTING_CAPACITY = 4;    //	Грузоподъемность
    public static final int TRACKER_TYPE = 5;               //	Тип трекера
    public static final int TRACKER_SIM_NUMBER = 6;         //	Телефонный номер трекера
    public static final int IMEA = 7;                       //	IMEA
    public static final int TRACK_DATE = 8;                 //	Дата трека
    public static final int TRACK_TIME = 9;                 //	Время трека
    public static final int DATE_RECEIVED = 10;             //	Дата получения
    public static final int TIME_RECEIVED = 11;             //	Время получения
    public static final int PARKING_TIME = 12;              //	Время парковки
    public static final int PARKING_DATE_START = 13;        //	Начало парковки
    public static final int PARKING_DATE_END = 14;          //	Окончание парковки
    public static final int LATITUDE = 15;                  //	Широта
    public static final int LONGITUDE = 16;                 //	Долгота
    public static final int ALTITUDE = 17;                  //	Высота (м)
    public static final int ANGLE = 18;                     //	Угол (гр)
    public static final int SPEED_TRACK = 19;               //	Скорость трека (км/ч)
    public static final int SPEED_IO = 20;                  //	Скорость IO (км/ч)
    public static final int ODOMETR = 21;                   //	Одометр (м)
    public static final int ADDRESS = 22;                   //	Адрес
    public static final int LOCATED_ZONES = 23;             //	Нахождение в Геозонах
    public static final int ASSIGNED_ROUTES = 24;           //	Назначенные маршруты
    public static final int MOTION_SENSOR = 25;             //	Датчик движения
    public static final int IGNITION_SENSOR = 26;           //	Датчик зажигания
    public static final int ALARM_BUTTON = 27;              //	Тревожная кнопка
    public static final int DIGITAL_INPUT_3 = 28;           //	Цифровой вход 3
    public static final int DIGITAL_INPUT_4 = 29;           //	Цифровой вход 4
    public static final int OBJECT_ADDITIONAL_INFO = 30;    //	Дополнительная информация
    // Value #2
    public static final int ANALOG_INPUT_1 = 1;             //	Аналоговый вход 1 (мВ)
    public static final int ANALOG_INPUT_2 = 2;             //	Аналоговый вход 2 (мВ)
    public static final int ANALOG_INPUT_3 = 3;             //	Аналоговый вход 3 (мВ)
    public static final int ANALOG_INPUT_4 = 4;             //	Аналоговый вход 4 (мВ)
    public static final int TRACKER_BATTERY = 5;            //	Батарея трекера (В)
    public static final int TRACKER_CHARGING_CURRENT = 6;   //	Ток заряда трекера (мА)
    public static final int EXTERNAL_POWER = 7;             //	Внешнее питание (В)
    public static final int GSM_OPERATOR_CODE = 8;          //	Код оператора GSM
    public static final int GSM_SIGNAL_LEVEL = 9;           //	Уровень сигнала GSM
    public static final int CELL_ID = 10;                   //	Cell ID
    public static final int LAC = 11;                       //	LAC
    public static final int GNSS = 12;                      //	GNSS
    public static final int SATELLITE_COUNT = 13;           //	Количество спутников
    public static final int PDOP = 14;                      //	PDOP
    public static final int HDOP = 15;                      //	HDOP
    public static final int PCB = 16;                       //	PCB t°C
    public static final int TRACKER_PROFILE = 17;           //	Профиль трекера
    public static final int DEEP_SLEEP = 18;                //	Deep Sleep
    public static final int INDICATION_DUT_1 = 19;          //	Показания ДУТ 1 (л)
    public static final int COM_1_1 = 20;                   //	COM 1 (квант)
    public static final int COM_1_2 = 21;                   //	COM 1 (t°C)
    public static final int INDICATION_DUT_2 = 22;          //	Показания ДУТ 2 (л)
    public static final int COM_2_1 = 23;                   //	COM 2 (квант)
    public static final int COM_2_2 = 24;                   //	COM 2 (t°C)
    public static final int TOTAL_INDICATION_DUT = 25;      //	Суммарно показания ДУТ (л)
    public static final int CAN_SPEED = 26;                 //	Скорость CAN (км/ч)
    public static final int CAN_DISTANCE = 27;              //	Пробег CAN (км)
    public static final int CAN_DISTANCE_TILL_SERVICE = 28; //	Пробег до обслуживания CAN (км)
    public static final int CAN_FUEL_CONSUMPTION = 29;      //	Расход топлива CAN (л)
    // Value #3
    public static final int CAN_FUEL_LEVEL_PERCENTAGE = 1;  //	Уровень топлива CAN (%)
    public static final int CAN_FUEL_LEVEL_LITER = 2;       //	Уровень топлива CAN (л)
    public static final int EXACT_FUEL_CONSUMPTION = 3;     //	Точный расход топлива (л)
    public static final int ENGINE_SPEED = 4;               //	Обороты двигателя (об/мин)
    public static final int ACCELATOR_PEDAL = 5;            //	Педаль акселератора (%)
    public static final int WORKING_TIME = 6;               //	Время работы двигатля (ч)
    public static final int FEUL_CONSUMPTION_100KM = 7;     //	Относительный расход топлива (км/л)
    public static final int FEUL_CONSUMPTION_HOUR = 8;      //	Относительный расход топлива (л/ч)
    public static final int ENGINE_TEMPERATURE = 9;         //	Температура двигателя (t°C)
    public static final int CAB_TEMPERATURE = 10;           //	Температура окружающего воздуха (t°C)
    public static final int VIN = 11;                       //	VIN
    public static final int STAFF_NAME = 12;                //	Имя персонала
    public static final int STAFF_PHONE_NUMBER = 13;        //	Телефон персонала
    public static final int STAFF_PHOTO = 14;               //	Фото персонала
    public static final int DIGITAL_INPUT_1 = 15;           //	Цифровой вход 1
    public static final int DIGITAL_INPUT_2 = 16;           //	Цифровой вход 2
    public static final int PRIORITY = 17;                  //  Приоритет трека
    public static final int SHORT_TERM_FUEL_TRIM = 18;      //  Топливный баланс (%)
    public static final int FUEL_INJECTION_TIMING = 19;     //  Частота впрыска топлива (°)
    public static final int ENGINE_THROTTLE_POSITION = 20;  //  Положение дроссельной заслонки (%)
    public static final int ENGINE_LOAD_PERCENT = 21;       //  Расчетное значение нагрузки на двигатель (%)
    public static final int LOAD_ABSOLUTE_VALUE = 22;       //  Абсолютное значение нагрузки (%)
    public static final int TIME_ENGINE_START = 23;         //  Время, с запуска двигателя (ч)
    public static final int TIMING_ADVANCE = 24;            //  Угол опережения зажигания (гр)
    public static final int ENGINE_OIL_TEMPERATURE = 25;    //  Температура масла двигателя (t°C)
    public static final int DTC_COUNT = 26;                 //  Количество кодов неисправностей
    public static final int DISTANCE_AFTER_CODES_CLEAR = 27;//  Пробег со времени сброса кодов (км)
    public static final int TIME_CODES_CLEARED = 28;        //  Время с момента сброса кодов нейсправностей (ч)
    public static final int DISTANCE_WITH_MIL_ON = 29;      //  Пробег с MIL ON (км)
    public static final int TIME_WITH_MIL_ON = 30;          //  Время с момента MIL ON (ч)
    // Value #4
    public static final int INDICATION_DUT_3 = 1;          //	Показания ДУТ 2 (л)
    public static final int INDICATION_DUT_4 = 2;          //	Показания ДУТ 3 (л)
    public static final int COM_3_level = 3;               //	COM 3 (квант)
    public static final int COM_3_temp = 4;                //	COM 3 (t°C)
    public static final int COM_3_code = 5;                //	COM 3 Code
    public static final int COM_4_level = 6;               //	COM 4 (квант)
    public static final int COM_4_temp = 7;                //	COM 4 (t°C)
    public static final int COM_4_code = 8;                //	COM 4 Code
    public static final int COM_5_level = 9;               //	COM 5 (квант)
    public static final int COM_5_temp = 10;               //	COM 5 (t°C)
    public static final int COM_5_code = 11;               //	COM 5 Code
    public static final int COM_6_level = 12;              //	COM 6 (квант)
    public static final int COM_6_temp = 13;               //	COM 6 (t°C)
    public static final int COM_6_code = 14;               //	COM 6 Code
    public static final int COM_7_level = 15;              //	COM 7 (квант)
    public static final int COM_7_temp = 16;               //	COM 7 (t°C)
    public static final int COM_7_code = 17;               //	COM 7 Code
    public static final int COM_8_level = 18;              //	COM 8 (квант)
    public static final int COM_8_temp = 19;               //	COM 8 (t°C)
    public static final int COM_8_code = 20;               //	COM 8 Code
    public static final int COM_1_code = 21;               //	COM 1 Code
    public static final int COM_2_code = 22;               //	COM 2 Code
    public static final int POWER_BATTERY_PERCENT = 23;    // Уровень заряда батареи

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "contract_id", nullable = false, insertable = false, updatable = false)
    private Long contractId;
    @OneToOne
    @JoinColumn(name = "contract_id")
    private Contract contract;

    @Column(name = "map_type", nullable = false)
    private Long mapType;

    @Column(name = "save_current_position")
    private Boolean saveCurrentPosition;

    @Column(name = "show_name_poi")
    private Boolean showNamePoi;

    @Column(name = "binding_tracks_to_map")
    private Boolean bindingTracksToMap;

    @Column(name = "show_name_geozone")
    private Boolean showNameGeoZone;

    @Column(name = "object_label")
    private Long objectLabel;

    @Column(name = "object_name_monitoring")
    private Boolean objectNameMonitoring;

    @Column(name = "object_name_tracking")
    private Boolean objectNameTracking;

    @Column(name = "type_tracker_monitoring")
    private Boolean typeTrackerMonitoring;

    @Column(name = "type_tracker_tracking")
    private Boolean typeTrackerTracking;

    @Column(name = "tracker_id_monitoring")
    private Boolean trackerIdMonitoring;

    @Column(name = "tracker_id_tracking")
    private Boolean trackerIdTracking;

    @Column(name = "tracker_phone_number_monitoring")
    private Boolean trackerPhoneNumberMonitoring;

    @Column(name = "tracker_phone_number_tracking")
    private Boolean trackerPhoneNumberTracking;

    @Column(name = "object_type_monitoring")
    private Boolean objectTypeMonitoring;

    @Column(name = "object_type_tracking")
    private Boolean objectTypeTracking;

    @Column(name = "object_plate_number_monitoring")
    private Boolean objectPlateNumberMonitoring;

    @Column(name = "object_plate_number_tracking")
    private Boolean objectPlateNumberTracking;

    @Column(name = "object_capacity_monitoring")
    private Boolean objectCapacityMonitoring;

    @Column(name = "object_capacity_tracking")
    private Boolean objectCapacityTracking;

    @Column(name = "object_fuel_monitoring")
    private Boolean objectFuelMonitoring;

    @Column(name = "object_fuel_tracking")
    private Boolean objectFuelTracking;

    @Column(name = "object_address_monitoring")
    private Boolean objectAddressMonitoring;

    @Column(name = "object_address_tracking")
    private Boolean objectAddressTracking;

    @Column(name = "object_coordinates_monitoring")
    private Boolean objectCoordinatesMonitoring;

    @Column(name = "object_coordinates_tracking")
    private Boolean objectCoordinatesTracking;

    @Column(name = "object_speed_monitoring")
    private Boolean objectSpeedMonitoring;

    @Column(name = "object_speed_tracking")
    private Boolean objectSpeedTracking;

    @Column(name = "object_satellite_monitoring")
    private Boolean objectSatelliteMonitoring;

    @Column(name = "object_satellite_tracking")
    private Boolean objectSatelliteTracking;

    @Column(name = "object_odometer_monitoring")
    private Boolean objectOdometerMonitoring;

    @Column(name = "object_odometer_tracking")
    private Boolean objectOdometerTracking;

    @Column(name = "object_hourmeter_monitoring")
    private Boolean objectHourmeterMonitoring;

    @Column(name = "object_hourmeter_tracking")
    private Boolean objectHourmeterTracking;

    @Column(name = "being_geozon_monitoring")
    private Boolean beingGeozonMonitoring;

    @Column(name = "being_geozon_tracking")
    private Boolean beingGeozonTracking;

    @Column(name = "design_rout_monitoring")
    private Boolean designRoutMonitoring;

    @Column(name = "design_rout_tracking")
    private Boolean designRoutTracking;

    @Column(name = "name_staff_monitoring")
    private Boolean nameStaffMonitoring;

    @Column(name = "name_staff_tracking")
    private Boolean nameStaffTracking;

    @Column(name = "photo_staff_monitoring")
    private Boolean photoStaffMonitoring;

    @Column(name = "photo_staff_tracking")
    private Boolean photoStaffTracking;

    @Column(name = "phone_staff_monitoring")
    private Boolean phoneStaffMonitoring;

    @Column(name = "phone_staff_tracking")
    private Boolean phoneStaffTracking;

    @Column(name = "object_status_view")
    private Boolean objectStatusView;

    @Column(name = "object_status_position")
    private Integer objectStatusPosition;

    @Column(name = "ignition_sensor_view")
    private Boolean ignitionSensorView;

    @Column(name = "ignition_sensor_position")
    private Integer ignitionSensorPosition;

    @Column(name = "object_link_view")
    private Boolean objectLinkView;

    @Column(name = "object_link_position")
    private Integer objectLinkPosition;

    @Column(name = "satellite_visibility_view")
    private Boolean satelliteVisibilityView;

    @Column(name = "satellite_visibility_position")
    private Integer satelliteVisibilityPosition;

    @Column(name = "object_driver_view")
    private Boolean objectDriverView;

    @Column(name = "object_driver_position")
    private Integer objectDriverPosition;

    @Column(name = "sensor_state_view")
    private Boolean sensorStateView;

    @Column(name = "sensor_state_position")
    private Integer sensorStatePosition;

    @Column(name = "object_massage_view")
    private Boolean objectMassageView;

    @Column(name = "object_massage_position")
    private Integer objectMassagePosition;

    @Column(name = "build_track_view")
    private Boolean buildTrackView;

    @Column(name = "build_track_position")
    private Integer buildTrackPosition;

    @Column(name = "report_view")
    private Boolean reportView;

    @Column(name = "report_position")
    private Integer reportPosition;

    @Column(name = "sms_send_view")
    private Boolean smsSendView;

    @Column(name = "sms_send_position")
    private Integer smsSendPosition;

    @Column(name = "object_properties_view")
    private Boolean objectPropertiesView;

    @Column(name = "object_properties_position")
    private Integer objectPropertiesPosition;

    @Column(name = "fast_track_type")
    private Long fastTrackType;

    @Column(name = "fast_track_value")
    private Long fastTrackValue;

    @Column(name = "delete_prev_track")
    private Boolean deletePrevTrack;

    @Column(name = "dotted_line_thickness")
    private Integer dottedLineThickness;

    @Column(name = "linear_line_thickness")
    private Integer linearLineThickness;

    @Column(name = "track_length_type")
    private Long trackLengthType;

    @Column(name = "track_length_value")
    private Long trackLengthValue;

    @Column(name = "track_length_color", length = 7)
    private String trackLengthColor;

    @Column(name = "mapping_object_type")
    private Long mappingObjectType;

    @Column(name = "object_movement_type")
    private Integer objectMovementType;

    @Column(name = "is_show_suspended_objects")
    private Boolean isShowSuspendedObjects;

    @Column(name = "is_show_tracking_table")
    private Boolean isShowTrackingTable;

    @Column(name = "is_show_tracking_chart")
    private Boolean isShowTrackingChart;

    @Column(name = "tooltips_view_quantity")
    private Long tooltipsViewQuantity;

    @Column(name = "tooltips_massages_view")
    private Boolean tooltipsMassagesView;

    @Column(name = "tooltips_massages_color", length = 7)
    private String tooltipsMassagesColor;

    @Column(name = "tooltips_sms_view")
    private Boolean tooltipsSmsView;

    @Column(name = "tooltips_sms_color", length = 7)
    private String tooltipsSmsColor;

    @Column(name = "tooltips_command_view")
    private Boolean tooltipsCommandView;

    @Column(name = "tooltips_command_color", length = 7)
    private String tooltipsCommandColor;

    @Column(name = "tooltips_event_view")
    private Boolean tooltipsEventView;

    @Column(name = "tooltips_event_color", length = 7)
    private String tooltipsEventColor;

    @Column(name = "monitoring_refresh_interval")
    private Integer monitoringRefreshInterval;

    @Column(name = "last_track_timestamp")
    private Boolean lastTrackTimestamp;

    @Column(name = "fuel_monitoring")
    private Boolean fuelMonitoring;

    @Column(name = "fuel_tracking")
    private Boolean fuelTracking;

    @Column(name = "assigned_route_monitoring")
    private Boolean assignedRouteMonitoring;

    @Column(name = "assigned_route_tracking")
    private Boolean assignedRouteTracking;

    @Column(name = "bak_position_view")
    private Boolean bakPositionView;

    @Column(name = "bak_position")
    private Integer bakPosition;

    @Column(name = "tracked_objects_min_zoom")
    private Integer trackedObjectsMinZoom;

    @Column(name = "tracked_objects_max_zoom")
    private Integer trackedObjectsMaxZoom;

    // Object Battery
    @Column(name = "obj_battery_view")
    private Boolean objBatteryView;

    @Column(name = "obj_battery_position")
    private Integer objBatteryPosition;

    // EPV
    @Column(name = "external_power_voltage_view")
    private Boolean externalPowerVoltageView;

    @Column(name = "external_power_voltage_position")
    private Integer externalPowerVoltagePosition;

    // Last Msg Time
    @Column(name = "last_msg_time_view")
    private Boolean lastMsgTimeView;

    @Column(name = "last_msg_time_position")
    private Integer lastMsgTimePosition;

    @Column(name = "view_messege")
    private Integer viewMessage;

    @Column(name = "view_next_message")
    private Integer viewNextMessage;

    @Column(name = "view_treck")
    private Integer viewTrack;

    @Column(name = "view_next_track")
    private Integer viewNextTrack;

    /* ------------------ SETTINGS DISPLAY DATA ------------------ >> */
    @Column(name = "tracking_values_part1")
    private Integer trackingValuesPart1;

    @Column(name = "tracking_values_part2")
    private Integer trackingValuesPart2;

    @Column(name = "tracking_values_part3")
    private Integer trackingValuesPart3;

    @Column(name = "tracking_values_part4")
    private Integer trackingValuesPart4;

    @Column(name = "tracking_values_part5")
    private Integer trackingValuesPart5;

    @Column(name = "message_values_part1")
    private Integer messageValuesPart1;

    @Column(name = "message_values_part2")
    private Integer messageValuesPart2;

    @Column(name = "message_values_part3")
    private Integer messageValuesPart3;

    @Column(name = "message_values_part4")
    private Integer messageValuesPart4;

    @Column(name = "message_values_part5")
    private Integer messageValuesPart5;

    @Column(name = "monitoring_values_part1")
    private Integer monitoringValuesPart1;

    @Column(name = "monitoring_values_part2")
    private Integer monitoringValuesPart2;

    @Column(name = "monitoring_values_part3")
    private Integer monitoringValuesPart3;

    @Column(name = "monitoring_values_part4")
    private Integer monitoringValuesPart4;

    @Column(name = "track_popup_values_part1")
    private Integer trackPopupValuesPart1;

    @Column(name = "track_popup_values_part2")
    private Integer trackPopupValuesPart2;

    @Column(name = "track_popup_values_part3")
    private Integer trackPopupValuesPart3;

    @Column(name = "track_popup_values_part4")
    private Integer trackPopupValuesPart4;

    @Column(name = "parking_popup_values_part1")
    private Integer parkingPopupValuesPart1;

    @Column(name = "sos_popup_values_part1")
    private Integer sosPopupValuesPart1;

    @Column(name = "sos_popup_values_part2")
    private Integer sosPopupValuesPart2;

    @Column(name = "sos_popup_values_part3")
    private Integer sosPopupValuesPart3;

    @Column(name = "sos_popup_values_part4")
    private Integer sosPopupValuesPart4;

    @Column(name = "object_additional_info_monitoring")
    private Boolean objectAdditionalInfoMonitoring;

    @Column(name = "show_objects_in_cluster")
    private Boolean showObjectsInCluster;

    @Column(name = "poi_load_startup")
    private Boolean poiLoadStartup;

    @Column(name = "geozone_load_startup")
    private Boolean geozoneLoadStartup;

    @Type(type = "sdListJson")
    @Column(name = "sensors", columnDefinition = "json")
    private List<SensorDisplay> sensorDisplayList;


    /* ------------------ SETTINGS DISPLAY DATA ------------------ << */

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Long getMapType() {
        return mapType;
    }

    public void setMapType(Long mapType) {
        this.mapType = mapType;
    }

    public Boolean getSaveCurrentPosition() {
        return saveCurrentPosition;
    }

    public void setSaveCurrentPosition(Boolean saveCurrentPosition) {
        this.saveCurrentPosition = saveCurrentPosition;
    }

    public Boolean getShowNamePoi() {
        return showNamePoi;
    }

    public void setShowNamePoi(Boolean showNamePoi) {
        this.showNamePoi = showNamePoi;
    }

    public Boolean getBindingTracksToMap() {
        return bindingTracksToMap;
    }

    public void setBindingTracksToMap(Boolean bindingTracksToMap) {
        this.bindingTracksToMap = bindingTracksToMap;
    }

    public Boolean getShowNameGeoZone() {
        return showNameGeoZone;
    }

    public void setShowNameGeoZone(Boolean showNameGeoZone) {
        this.showNameGeoZone = showNameGeoZone;
    }

    public Long getObjectLabel() {
        return objectLabel;
    }

    public void setObjectLabel(Long objectLabel) {
        this.objectLabel = objectLabel;
    }

    public Boolean getObjectNameMonitoring() {
        return objectNameMonitoring;
    }

    public void setObjectNameMonitoring(Boolean objectNameMonitoring) {
        this.objectNameMonitoring = objectNameMonitoring;
    }

    public Boolean getObjectNameTracking() {
        return objectNameTracking;
    }

    public void setObjectNameTracking(Boolean objectNameTracking) {
        this.objectNameTracking = objectNameTracking;
    }

    public Boolean getTypeTrackerMonitoring() {
        return typeTrackerMonitoring;
    }

    public void setTypeTrackerMonitoring(Boolean typeTrackerMonitoring) {
        this.typeTrackerMonitoring = typeTrackerMonitoring;
    }

    public Boolean getTypeTrackerTracking() {
        return typeTrackerTracking;
    }

    public void setTypeTrackerTracking(Boolean typeTrackerTracking) {
        this.typeTrackerTracking = typeTrackerTracking;
    }

    public Boolean getTrackerIdMonitoring() {
        return trackerIdMonitoring;
    }

    public void setTrackerIdMonitoring(Boolean trackerIdMonitoring) {
        this.trackerIdMonitoring = trackerIdMonitoring;
    }

    public Boolean getTrackerIdTracking() {
        return trackerIdTracking;
    }

    public void setTrackerIdTracking(Boolean trackerIdTracking) {
        this.trackerIdTracking = trackerIdTracking;
    }

    public Boolean getTrackerPhoneNumberMonitoring() {
        return trackerPhoneNumberMonitoring;
    }

    public void setTrackerPhoneNumberMonitoring(Boolean trackerPhoneNumberMonitoring) {
        this.trackerPhoneNumberMonitoring = trackerPhoneNumberMonitoring;
    }

    public Boolean getTrackerPhoneNumberTracking() {
        return trackerPhoneNumberTracking;
    }

    public void setTrackerPhoneNumberTracking(Boolean trackerPhoneNumberTracking) {
        this.trackerPhoneNumberTracking = trackerPhoneNumberTracking;
    }

    public Boolean getObjectTypeMonitoring() {
        return objectTypeMonitoring;
    }

    public void setObjectTypeMonitoring(Boolean objectTypeMonitoring) {
        this.objectTypeMonitoring = objectTypeMonitoring;
    }

    public Boolean getObjectTypeTracking() {
        return objectTypeTracking;
    }

    public void setObjectTypeTracking(Boolean objectTypeTracking) {
        this.objectTypeTracking = objectTypeTracking;
    }

    public Boolean getObjectPlateNumberMonitoring() {
        return objectPlateNumberMonitoring;
    }

    public void setObjectPlateNumberMonitoring(Boolean objectPlateNumberMonitoring) {
        this.objectPlateNumberMonitoring = objectPlateNumberMonitoring;
    }

    public Boolean getObjectPlateNumberTracking() {
        return objectPlateNumberTracking;
    }

    public void setObjectPlateNumberTracking(Boolean objectPlateNumberTracking) {
        this.objectPlateNumberTracking = objectPlateNumberTracking;
    }

    public Boolean getObjectCapacityMonitoring() {
        return objectCapacityMonitoring;
    }

    public void setObjectCapacityMonitoring(Boolean objectCapacityMonitoring) {
        this.objectCapacityMonitoring = objectCapacityMonitoring;
    }

    public Boolean getObjectCapacityTracking() {
        return objectCapacityTracking;
    }

    public void setObjectCapacityTracking(Boolean objectCapacityTracking) {
        this.objectCapacityTracking = objectCapacityTracking;
    }

    public Boolean getObjectFuelMonitoring() {
        return objectFuelMonitoring;
    }

    public void setObjectFuelMonitoring(Boolean objectFuelMonitoring) {
        this.objectFuelMonitoring = objectFuelMonitoring;
    }

    public Boolean getObjectFuelTracking() {
        return objectFuelTracking;
    }

    public void setObjectFuelTracking(Boolean objectFuelTracking) {
        this.objectFuelTracking = objectFuelTracking;
    }

    public Boolean getObjectAddressMonitoring() {
        return objectAddressMonitoring;
    }

    public void setObjectAddressMonitoring(Boolean objectAddressMonitoring) {
        this.objectAddressMonitoring = objectAddressMonitoring;
    }

    public Boolean getObjectAddressTracking() {
        return objectAddressTracking;
    }

    public void setObjectAddressTracking(Boolean objectAddressTracking) {
        this.objectAddressTracking = objectAddressTracking;
    }

    public Boolean getObjectCoordinatesMonitoring() {
        return objectCoordinatesMonitoring;
    }

    public void setObjectCoordinatesMonitoring(Boolean objectCoordinatesMonitoring) {
        this.objectCoordinatesMonitoring = objectCoordinatesMonitoring;
    }

    public Boolean getObjectCoordinatesTracking() {
        return objectCoordinatesTracking;
    }

    public void setObjectCoordinatesTracking(Boolean objectCoordinatesTracking) {
        this.objectCoordinatesTracking = objectCoordinatesTracking;
    }

    public Boolean getObjectSpeedMonitoring() {
        return objectSpeedMonitoring;
    }

    public void setObjectSpeedMonitoring(Boolean objectSpeedMonitoring) {
        this.objectSpeedMonitoring = objectSpeedMonitoring;
    }

    public Boolean getObjectSpeedTracking() {
        return objectSpeedTracking;
    }

    public void setObjectSpeedTracking(Boolean objectSpeedTracking) {
        this.objectSpeedTracking = objectSpeedTracking;
    }

    public Boolean getObjectSatelliteMonitoring() {
        return objectSatelliteMonitoring;
    }

    public void setObjectSatelliteMonitoring(Boolean objectSatelliteMonitoring) {
        this.objectSatelliteMonitoring = objectSatelliteMonitoring;
    }

    public Boolean getObjectSatelliteTracking() {
        return objectSatelliteTracking;
    }

    public void setObjectSatelliteTracking(Boolean objectSatelliteTracking) {
        this.objectSatelliteTracking = objectSatelliteTracking;
    }

    public Boolean getObjectOdometerMonitoring() {
        return objectOdometerMonitoring;
    }

    public void setObjectOdometerMonitoring(Boolean objectOdometerMonitoring) {
        this.objectOdometerMonitoring = objectOdometerMonitoring;
    }

    public Boolean getObjectOdometerTracking() {
        return objectOdometerTracking;
    }

    public void setObjectOdometerTracking(Boolean objectOdometerTracking) {
        this.objectOdometerTracking = objectOdometerTracking;
    }

    public Boolean getObjectHourmeterMonitoring() {
        return objectHourmeterMonitoring;
    }

    public void setObjectHourmeterMonitoring(Boolean objectHourmeterMonitoring) {
        this.objectHourmeterMonitoring = objectHourmeterMonitoring;
    }

    public Boolean getObjectHourmeterTracking() {
        return objectHourmeterTracking;
    }

    public void setObjectHourmeterTracking(Boolean objectHourmeterTracking) {
        this.objectHourmeterTracking = objectHourmeterTracking;
    }

    public Boolean getBeingGeozonMonitoring() {
        return beingGeozonMonitoring;
    }

    public void setBeingGeozonMonitoring(Boolean beingGeozonMonitoring) {
        this.beingGeozonMonitoring = beingGeozonMonitoring;
    }

    public Boolean getBeingGeozonTracking() {
        return beingGeozonTracking;
    }

    public void setBeingGeozonTracking(Boolean beingGeozonTracking) {
        this.beingGeozonTracking = beingGeozonTracking;
    }

    public Boolean getDesignRoutMonitoring() {
        return designRoutMonitoring;
    }

    public void setDesignRoutMonitoring(Boolean designRoutMonitoring) {
        this.designRoutMonitoring = designRoutMonitoring;
    }

    public Boolean getDesignRoutTracking() {
        return designRoutTracking;
    }

    public void setDesignRoutTracking(Boolean designRoutTracking) {
        this.designRoutTracking = designRoutTracking;
    }

    public Boolean getNameStaffMonitoring() {
        return nameStaffMonitoring;
    }

    public void setNameStaffMonitoring(Boolean nameStaffMonitoring) {
        this.nameStaffMonitoring = nameStaffMonitoring;
    }

    public Boolean getNameStaffTracking() {
        return nameStaffTracking;
    }

    public void setNameStaffTracking(Boolean nameStaffTracking) {
        this.nameStaffTracking = nameStaffTracking;
    }

    public Boolean getPhotoStaffMonitoring() {
        return photoStaffMonitoring;
    }

    public void setPhotoStaffMonitoring(Boolean photoStaffMonitoring) {
        this.photoStaffMonitoring = photoStaffMonitoring;
    }

    public Boolean getPhotoStaffTracking() {
        return photoStaffTracking;
    }

    public void setPhotoStaffTracking(Boolean photoStaffTracking) {
        this.photoStaffTracking = photoStaffTracking;
    }

    public Boolean getPhoneStaffMonitoring() {
        return phoneStaffMonitoring;
    }

    public void setPhoneStaffMonitoring(Boolean phoneStaffMonitoring) {
        this.phoneStaffMonitoring = phoneStaffMonitoring;
    }

    public Boolean getPhoneStaffTracking() {
        return phoneStaffTracking;
    }

    public void setPhoneStaffTracking(Boolean phoneStaffTracking) {
        this.phoneStaffTracking = phoneStaffTracking;
    }

    public Boolean getObjectStatusView() {
        return objectStatusView;
    }

    public void setObjectStatusView(Boolean objectStatusView) {
        this.objectStatusView = objectStatusView;
    }

    public Integer getObjectStatusPosition() {
        return objectStatusPosition;
    }

    public void setObjectStatusPosition(Integer objectStatusPosition) {
        this.objectStatusPosition = objectStatusPosition;
    }

    public Boolean getIgnitionSensorView() {
        return ignitionSensorView;
    }

    public void setIgnitionSensorView(Boolean ignitionSensorView) {
        this.ignitionSensorView = ignitionSensorView;
    }

    public Integer getIgnitionSensorPosition() {
        return ignitionSensorPosition;
    }

    public void setIgnitionSensorPosition(Integer ignitionSensorPosition) {
        this.ignitionSensorPosition = ignitionSensorPosition;
    }

    public Boolean getObjectLinkView() {
        return objectLinkView;
    }

    public void setObjectLinkView(Boolean objectLinkView) {
        this.objectLinkView = objectLinkView;
    }

    public Integer getObjectLinkPosition() {
        return objectLinkPosition;
    }

    public void setObjectLinkPosition(Integer objectLinkPosition) {
        this.objectLinkPosition = objectLinkPosition;
    }

    public Boolean getSatelliteVisibilityView() {
        return satelliteVisibilityView;
    }

    public void setSatelliteVisibilityView(Boolean satelliteVisibilityView) {
        this.satelliteVisibilityView = satelliteVisibilityView;
    }

    public Integer getSatelliteVisibilityPosition() {
        return satelliteVisibilityPosition;
    }

    public void setSatelliteVisibilityPosition(Integer satelliteVisibilityPosition) {
        this.satelliteVisibilityPosition = satelliteVisibilityPosition;
    }

    public Boolean getObjectDriverView() {
        return objectDriverView;
    }

    public void setObjectDriverView(Boolean objectDriverView) {
        this.objectDriverView = objectDriverView;
    }

    public Integer getObjectDriverPosition() {
        return objectDriverPosition;
    }

    public void setObjectDriverPosition(Integer objectDriverPosition) {
        this.objectDriverPosition = objectDriverPosition;
    }

    public Boolean getSensorStateView() {
        return sensorStateView;
    }

    public void setSensorStateView(Boolean sensorStateView) {
        this.sensorStateView = sensorStateView;
    }

    public Integer getSensorStatePosition() {
        return sensorStatePosition;
    }

    public void setSensorStatePosition(Integer sensorStatePosition) {
        this.sensorStatePosition = sensorStatePosition;
    }

    public Boolean getObjectMassageView() {
        return objectMassageView;
    }

    public void setObjectMassageView(Boolean objectMassageView) {
        this.objectMassageView = objectMassageView;
    }

    public Integer getObjectMassagePosition() {
        return objectMassagePosition;
    }

    public void setObjectMassagePosition(Integer objectMassagePosition) {
        this.objectMassagePosition = objectMassagePosition;
    }

    public Boolean getBuildTrackView() {
        return buildTrackView;
    }

    public void setBuildTrackView(Boolean buildTrackView) {
        this.buildTrackView = buildTrackView;
    }

    public Integer getBuildTrackPosition() {
        return buildTrackPosition;
    }

    public void setBuildTrackPosition(Integer buildTrackPosition) {
        this.buildTrackPosition = buildTrackPosition;
    }

    public Boolean getReportView() {
        return reportView;
    }

    public void setReportView(Boolean reportView) {
        this.reportView = reportView;
    }

    public Integer getReportPosition() {
        return reportPosition;
    }

    public void setReportPosition(Integer reportPosition) {
        this.reportPosition = reportPosition;
    }

    public Boolean getSmsSendView() {
        return smsSendView;
    }

    public void setSmsSendView(Boolean smsSendView) {
        this.smsSendView = smsSendView;
    }

    public Integer getSmsSendPosition() {
        return smsSendPosition;
    }

    public void setSmsSendPosition(Integer smsSendPosition) {
        this.smsSendPosition = smsSendPosition;
    }

    public Boolean getObjectPropertiesView() {
        return objectPropertiesView;
    }

    public void setObjectPropertiesView(Boolean objectPropertiesView) {
        this.objectPropertiesView = objectPropertiesView;
    }

    public Integer getObjectPropertiesPosition() {
        return objectPropertiesPosition;
    }

    public void setObjectPropertiesPosition(Integer objectPropertiesPosition) {
        this.objectPropertiesPosition = objectPropertiesPosition;
    }

    public Long getFastTrackType() {
        return fastTrackType;
    }

    public void setFastTrackType(Long fastTrackType) {
        this.fastTrackType = fastTrackType;
    }

    public Long getFastTrackValue() {
        return fastTrackValue;
    }

    public void setFastTrackValue(Long fastTrackValue) {
        this.fastTrackValue = fastTrackValue;
    }

    public Boolean getDeletePrevTrack() {
        return deletePrevTrack;
    }

    public void setDeletePrevTrack(Boolean deletePrevTrack) {
        this.deletePrevTrack = deletePrevTrack;
    }

    public Integer getDottedLineThickness() {
        return dottedLineThickness;
    }

    public void setDottedLineThickness(Integer dottedLineThickness) {
        this.dottedLineThickness = dottedLineThickness;
    }

    public Integer getLinearLineThickness() {
        return linearLineThickness;
    }

    public void setLinearLineThickness(Integer linearLineThickness) {
        this.linearLineThickness = linearLineThickness;
    }

    public Long getTrackLengthType() {
        return trackLengthType;
    }

    public void setTrackLengthType(Long trackLengthType) {
        this.trackLengthType = trackLengthType;
    }

    public Long getTrackLengthValue() {
        return trackLengthValue;
    }

    public void setTrackLengthValue(Long trackLengthValue) {
        this.trackLengthValue = trackLengthValue;
    }

    public String getTrackLengthColor() {
        return trackLengthColor;
    }

    public void setTrackLengthColor(String trackLengthColor) {
        this.trackLengthColor = trackLengthColor;
    }

    public Long getMappingObjectType() {
        return mappingObjectType;
    }

    public void setMappingObjectType(Long mappingObjectType) {
        this.mappingObjectType = mappingObjectType;
    }

    public Integer getObjectMovementType() {
        return objectMovementType;
    }

    public void setObjectMovementType(Integer objectMovementType) {
        this.objectMovementType = objectMovementType;
    }

    public Boolean getIsShowSuspendedObjects() {
        return isShowSuspendedObjects;
    }

    public void setIsShowSuspendedObjects(Boolean isShowSuspendedObjects) {
        this.isShowSuspendedObjects = isShowSuspendedObjects;
    }

    public Long getTooltipsViewQuantity() {
        return tooltipsViewQuantity;
    }

    public void setTooltipsViewQuantity(Long tooltipsViewQuantity) {
        this.tooltipsViewQuantity = tooltipsViewQuantity;
    }

    public Boolean getTooltipsMassagesView() {
        return tooltipsMassagesView;
    }

    public void setTooltipsMassagesView(Boolean tooltipsMassagesView) {
        this.tooltipsMassagesView = tooltipsMassagesView;
    }

    public String getTooltipsMassagesColor() {
        return tooltipsMassagesColor;
    }

    public void setTooltipsMassagesColor(String tooltipsMassagesColor) {
        this.tooltipsMassagesColor = tooltipsMassagesColor;
    }

    public Boolean getTooltipsSmsView() {
        return tooltipsSmsView;
    }

    public void setTooltipsSmsView(Boolean tooltipsSmsView) {
        this.tooltipsSmsView = tooltipsSmsView;
    }

    public String getTooltipsSmsColor() {
        return tooltipsSmsColor;
    }

    public void setTooltipsSmsColor(String tooltipsSmsColor) {
        this.tooltipsSmsColor = tooltipsSmsColor;
    }

    public Boolean getTooltipsCommandView() {
        return tooltipsCommandView;
    }

    public void setTooltipsCommandView(Boolean tooltipsCommandView) {
        this.tooltipsCommandView = tooltipsCommandView;
    }

    public String getTooltipsCommandColor() {
        return tooltipsCommandColor;
    }

    public void setTooltipsCommandColor(String tooltipsCommandColor) {
        this.tooltipsCommandColor = tooltipsCommandColor;
    }

    public Boolean getTooltipsEventView() {
        return tooltipsEventView;
    }

    public void setTooltipsEventView(Boolean tooltipsEventView) {
        this.tooltipsEventView = tooltipsEventView;
    }

    public String getTooltipsEventColor() {
        return tooltipsEventColor;
    }

    public void setTooltipsEventColor(String tooltipsEventColor) {
        this.tooltipsEventColor = tooltipsEventColor;
    }

    public Integer getMonitoringRefreshInterval() {
        return monitoringRefreshInterval;
    }

    public void setMonitoringRefreshInterval(Integer monitoringRefreshInterval) {
        this.monitoringRefreshInterval = monitoringRefreshInterval;
    }

    public Boolean getLastTrackTimestamp() {
        return lastTrackTimestamp;
    }

    public void setLastTrackTimestamp(Boolean lastTrackTimestamp) {
        this.lastTrackTimestamp = lastTrackTimestamp;
    }

    public Boolean getFuelTracking() {
        return fuelTracking;
    }

    public void setFuelTracking(Boolean fuelTracking) {
        this.fuelTracking = fuelTracking;
    }

    public Boolean getFuelMonitoring() {
        return fuelMonitoring;
    }

    public void setFuelMonitoring(Boolean fuelMonitoring) {
        this.fuelMonitoring = fuelMonitoring;
    }

    public Boolean getAssignedRouteMonitoring() {
        return assignedRouteMonitoring;
    }

    public void setAssignedRouteMonitoring(Boolean assignedRouteMonitoring) {
        this.assignedRouteMonitoring = assignedRouteMonitoring;
    }

    public Boolean getAssignedRouteTracking() {
        return assignedRouteTracking;
    }

    public void setAssignedRouteTracking(Boolean assignedRouteTracking) {
        this.assignedRouteTracking = assignedRouteTracking;
    }

    public Boolean getBakPositionView() {
        return bakPositionView;
    }

    public void setBakPositionView(Boolean bakPositionView) {
        this.bakPositionView = bakPositionView;
    }

    public Integer getBakPosition() {
        return bakPosition;
    }

    public void setBakPosition(Integer bakPosition) {
        this.bakPosition = bakPosition;
    }

    //- EPV
    public Boolean getExternalPowerVoltageView() {
        return externalPowerVoltageView;
    }

    public void setExternalPowerVoltageView(Boolean externalPowerVoltageView) {
        this.externalPowerVoltageView = externalPowerVoltageView;
    }

    public Integer getExternalPowerVoltagePosition() {
        return externalPowerVoltagePosition;
    }

    public void setExternalPowerVoltagePosition(Integer externalPowerVoltagePosition) {
        this.externalPowerVoltagePosition = externalPowerVoltagePosition;
    }

    public Boolean getObjBatteryView() {
        return objBatteryView;
    }

    public void setObjBatteryView(Boolean objBatteryView) {
        this.objBatteryView = objBatteryView;
    }

    public Integer getObjBatteryPosition() {
        return objBatteryPosition;
    }

    public void setObjBatteryPosition(Integer objBatteryPosition) {
        this.objBatteryPosition = objBatteryPosition;
    }

    //- LastMsgTime
    public Boolean getLastMsgTimeView() {
        return lastMsgTimeView;
    }

    public void setLastMsgTimeView(Boolean lastMsgTimeView) {
        this.lastMsgTimeView = lastMsgTimeView;
    }

    public Integer getLastMsgTimePosition() {
        return lastMsgTimePosition;
    }

    public void setLastMsgTimePosition(Integer lastMsgTimePosition) {
        this.lastMsgTimePosition = lastMsgTimePosition;
    }

    public Integer getViewMessage() {
        return viewMessage;
    }

    public void setViewMessage(Integer viewMessage) {
        this.viewMessage = viewMessage;
        if (this.viewMessage == null)
            this.viewMessage = 0;
    }

    public Integer getViewNextMessage() {
        return viewNextMessage;
    }

    public void setViewNextMessage(Integer viewNextMessage) {
        this.viewNextMessage = viewNextMessage;
        if (this.viewNextMessage == null)
            this.viewNextMessage = 0;
    }

    public Integer getViewTrack() {
        return viewTrack;
    }

    public void setViewTrack(Integer viewTrack) {
        this.viewTrack = viewTrack;
        if (this.viewTrack == null)
            this.viewTrack = 0;
    }

    public Integer getViewNextTrack() {
        return viewNextTrack;
    }

    public void setViewNextTrack(Integer viewNextTrack) {
        this.viewNextTrack = viewNextTrack;
        if (this.viewNextTrack == null)
            this.viewNextTrack = 0;
    }

    public Integer getTrackingValuesPart1() {
        return trackingValuesPart1;
    }

    public void setTrackingValuesPart1(Integer trackingValuesPart1) {
        this.trackingValuesPart1 = trackingValuesPart1;
    }

    public Integer getTrackingValuesPart2() {
        return trackingValuesPart2;
    }

    public void setTrackingValuesPart2(Integer trackingValuesPart2) {
        this.trackingValuesPart2 = trackingValuesPart2;
    }

    public Integer getTrackingValuesPart3() {
        return trackingValuesPart3;
    }

    public void setTrackingValuesPart3(Integer trackingValuesPart3) {
        this.trackingValuesPart3 = trackingValuesPart3;
    }

    public Integer getMessageValuesPart1() {
        return messageValuesPart1;
    }

    public void setMessageValuesPart1(Integer messageValuesPart1) {
        this.messageValuesPart1 = messageValuesPart1;
    }

    public Integer getMessageValuesPart2() {
        return messageValuesPart2;
    }

    public void setMessageValuesPart2(Integer messageValuesPart2) {
        this.messageValuesPart2 = messageValuesPart2;
    }

    public Integer getMessageValuesPart3() {
        return messageValuesPart3;
    }

    public void setMessageValuesPart3(Integer messageValuesPart3) {
        this.messageValuesPart3 = messageValuesPart3;
    }

    public Integer getMonitoringValuesPart1() {
        return monitoringValuesPart1;
    }

    public void setMonitoringValuesPart1(Integer monitoringValuesPart1) {
        this.monitoringValuesPart1 = monitoringValuesPart1;
    }

    public Integer getMonitoringValuesPart2() {
        return monitoringValuesPart2;
    }

    public void setMonitoringValuesPart2(Integer monitoringValuesPart2) {
        this.monitoringValuesPart2 = monitoringValuesPart2;
    }

    public Integer getMonitoringValuesPart3() {
        return monitoringValuesPart3;
    }

    public void setMonitoringValuesPart3(Integer monitoringValuesPart3) {
        this.monitoringValuesPart3 = monitoringValuesPart3;
    }

    public Integer getTrackPopupValuesPart1() {
        return trackPopupValuesPart1;
    }

    public void setTrackPopupValuesPart1(Integer trackPopupValuesPart1) {
        this.trackPopupValuesPart1 = trackPopupValuesPart1;
    }

    public Integer getTrackPopupValuesPart2() {
        return trackPopupValuesPart2;
    }

    public void setTrackPopupValuesPart2(Integer trackPopupValuesPart2) {
        this.trackPopupValuesPart2 = trackPopupValuesPart2;
    }

    public Integer getTrackPopupValuesPart3() {
        return trackPopupValuesPart3;
    }

    public void setTrackPopupValuesPart3(Integer trackPopupValuesPart3) {
        this.trackPopupValuesPart3 = trackPopupValuesPart3;
    }

    public Integer getParkingPopupValuesPart1() {
        return parkingPopupValuesPart1;
    }

    public void setParkingPopupValuesPart1(Integer parkingPopupValuesPart1) {
        this.parkingPopupValuesPart1 = parkingPopupValuesPart1;
    }

    public Integer getSosPopupValuesPart1() {
        return sosPopupValuesPart1;
    }

    public void setSosPopupValuesPart1(Integer sosPopupValuesPart1) {
        this.sosPopupValuesPart1 = sosPopupValuesPart1;
    }

    public Integer getSosPopupValuesPart2() {
        return sosPopupValuesPart2;
    }

    public void setSosPopupValuesPart2(Integer sosPopupValuesPart2) {
        this.sosPopupValuesPart2 = sosPopupValuesPart2;
    }

    public Integer getSosPopupValuesPart3() {
        return sosPopupValuesPart3;
    }

    public void setSosPopupValuesPart3(Integer sosPopupValuesPart3) {
        this.sosPopupValuesPart3 = sosPopupValuesPart3;
    }

    /* ------------------ FUNCTIONS SETTINGS DISPLAY DATA ------------------ >> */

    public int hasValueInPosition(Integer value, int position) {
        value = (value == null) ? 0 : value;

        return Converters.getBitValue(value, position);
    }
    /* ------------------ FUNCTIONS SETTINGS DISPLAY DATA ------------------ >> */

    /* ---------- FUNCTIONS FOR VIEW MESSAGE ---------- >> */
    public int getVmValue(int VM_TYPE) {
        return Converters.getBitValue(getViewMessage(), VM_TYPE);
    }

    public int getNextVmValue(int VM_TYPE) {
        return Converters.getBitValue(getViewNextMessage(), VM_TYPE);
    }

    public void setVmValue(int VM_TYPE, int value) {
        setViewMessage(Converters.setBitValue(getViewMessage(), VM_TYPE, value));
    }

    public void setNextVmValue(int VM_TYPE, int value) {
        setViewNextMessage(Converters.setBitValue(getViewNextMessage(), VM_TYPE, value));
    }

    public int getVmDate() {
        return Converters.getBitValue(getViewMessage(), VM_DATE);
    }

    public int getVmTime() {
        return Converters.getBitValue(getViewMessage(), VM_TIME);
    }

//    public int getVmSpeed() {
//        return Converters.getBitValue(getViewMessage(), VM_SPEED);
//    }

    public int getVmHieght() {
        return Converters.getBitValue(getViewMessage(), VM_HIEGHT);
    }

    public int getVmOdometr() {
        return Converters.getBitValue(getViewMessage(), VM_ODOMETR);
    }

    public int getVmMovementValue() {
        return Converters.getBitValue(getViewMessage(), VM_MOVEMENT_VALUE);
    }

    public int getVmAngle() {
        return Converters.getBitValue(getViewMessage(), VM_ANGLE);
    }

    public int getVmDigital() {
        return Converters.getBitValue(getViewMessage(), VM_DIGITAL);
    }

    public int getVmIntBatV() {
        return Converters.getBitValue(getViewMessage(), VM_INT_BAT_V);
    }

    public int getVmIntBatMa() {
        return Converters.getBitValue(getViewMessage(), VM_INT_BAT_MA);
    }

    public int getVmExtBat() {
        return Converters.getBitValue(getViewMessage(), VM_EXT_BAT);
    }

    public int getVmOperator() {
        return Converters.getBitValue(getViewMessage(), VM_OPERATOR);
    }

    public int getVmGsm() {
        return Converters.getBitValue(getViewMessage(), VM_GSM);
    }

    public int getVmCell() {
        return Converters.getBitValue(getViewMessage(), VM_CELL);
    }

    public int getVmLac() {
        return Converters.getBitValue(getViewMessage(), VM_LAC);
    }

    public int getVmSat() {
        return Converters.getBitValue(getViewMessage(), VM_SAT);
    }

    public int getVmGnss() {
        return Converters.getBitValue(getViewMessage(), VM_GNSS);
    }

    public int getVmPdop() {
        return Converters.getBitValue(getViewMessage(), VM_PDOP);
    }

    public int getVmHdop() {
        return Converters.getBitValue(getViewMessage(), VM_HDOP);
    }

    public int getVmPcb() {
        return Converters.getBitValue(getViewMessage(), VM_PCB);
    }

    public int getVmP() {
        return Converters.getBitValue(getViewMessage(), VM_P);
    }

    public int getVmDeepSleep() {
        return Converters.getBitValue(getViewMessage(), VM_DEEP_SLEEP);
    }

    public int getVmLevelFuel() {
        return Converters.getBitValue(getViewMessage(), VM_LEVEL_FUEL1);
    }

    public int getVmCanSpeed() {
        return Converters.getBitValue(getViewMessage(), VM_CAN_SPEED);
    }

    public int getVmEngineRpm() {
        return Converters.getBitValue(getViewMessage(), VM_ENGINE_RPM);
    }

    public int getVmAccelerator() {
        return Converters.getBitValue(getViewMessage(), VM_ACCELERATOR);
    }

    public int getVmEngineHour() {
        return Converters.getBitValue(getViewMessage(), VM_ENGINE_HOUR);
    }

    public int getVmTotalDistance() {
        return Converters.getBitValue(getViewMessage(), VM_TOTAL_DISTANCE);
    }

    public int getVmService() {
        return Converters.getBitValue(getViewMessage(), VM_SERVICE);
    }

    public int getVmFuelConsuption() {
        return Converters.getBitValue(getViewMessage(), VM_FUEL_CONSUPTION);
    }

    public int getVmHighResolition() {
        return Converters.getBitValue(getViewNextMessage(), VM_HEGH_RESOLITION);
    }

    public int getVmCanLevelFuel() {
        return Converters.getBitValue(getViewNextMessage(), VM_CAN_LEVEL_FUEL);
    }

    public int getVmFuelEconomy() {
        return Converters.getBitValue(getViewNextMessage(), VM_FUEL_ECONOMY);
    }

    public int getVmEngineTemperature() {
        return Converters.getBitValue(getViewNextMessage(), VM_ENGINE_TEMPERATURE);
    }

    public int getVmAmbientAir() {
        return Converters.getBitValue(getViewNextMessage(), VM_AMBIENT_AIR);
    }

    public int getVmVin() {
        return Converters.getBitValue(getViewNextMessage(), VM_VIN);
    }

    public int getVmDateReceived() {
        return Converters.getBitValue(getViewNextMessage(), VM_DATE_RECEIVED);
    }

    public int getVmTimeReceived() {
        return Converters.getBitValue(getViewNextMessage(), VM_TIME_RECEIVED);
    }

    public int getVmCom1() {
        return Converters.getBitValue(getViewNextMessage(), VM_COM1);
    }

    public int getVmCom2() {
        return Converters.getBitValue(getViewNextMessage(), VM_COM2);
    }

    public int getVmLatitude() {
        return Converters.getBitValue(getViewNextMessage(), VM_LATITUDE);
    }

    public int getVmLongitude() {
        return Converters.getBitValue(getViewNextMessage(), VM_LONGITUDE);
    }

    public int getVmSpeedTrack() {
        return Converters.getBitValue(getViewNextMessage(), VM_SPEED_TRACK);
    }

    public int getVmSpeedIo() {
        return Converters.getBitValue(getViewNextMessage(), VM_SPEED_IO);
    }

    public int getVmDigital1() {
        return Converters.getBitValue(getViewNextMessage(), VM_DIGITAL1);
    }

    public int getVmDigital2() {
        return Converters.getBitValue(getViewNextMessage(), VM_DIGITAL2);
    }

    public int getVmDigital3() {
        return Converters.getBitValue(getViewNextMessage(), VM_DIGITAL3);
    }

    public int getVmDigital4() {
        return Converters.getBitValue(getViewNextMessage(), VM_DIGITAL4);
    }

    public int getVmAnalog1() {
        return Converters.getBitValue(getViewNextMessage(), VM_ANALOG1);
    }

    public int getVmAnalog2() {
        return Converters.getBitValue(getViewNextMessage(), VM_ANALOG2);
    }

    public int getVmAnalog3() {
        return Converters.getBitValue(getViewNextMessage(), VM_ANALOG3);
    }

    public int getVmAnalog4() {
        return Converters.getBitValue(getViewNextMessage(), VM_ANALOG4);
    }

    public int getVmCom12() {
        return Converters.getBitValue(getViewNextMessage(), VM_COM12);
    }

    public int getVmCom22() {
        return Converters.getBitValue(getViewNextMessage(), VM_COM22);
    }

    public int getVmCanLevelFuel2() {
        return Converters.getBitValue(getViewNextMessage(), VM_CAN_LEVEL_FUEL2);
    }

    public int getVmFuelEconomy2() {
        return Converters.getBitValue(getViewNextMessage(), VM_FUEL_ECONOMY2);
    }

    public int getVmLevelFuel2() {
        return Converters.getBitValue(getViewNextMessage(), VM_LEVEL_FUEL2);
    }

    /* ---------- FUNCTIONS FOR VIEW MESSAGE ---------- << */


    /* ---------- FUNCTIONS FOR VIEW TRACK ---------- >> */

    public int getVtValue(int VT_TYPE) {
        return Converters.getBitValue(getViewTrack(), VT_TYPE);
    }

    public int getNextVtValue(int VT_TYPE) {
        return Converters.getBitValue(getViewNextTrack(), VT_TYPE);
    }

    public void setVtValue(int VT_TYPE, int value) {
        setViewTrack(Converters.setBitValue(getViewTrack(), VT_TYPE, value));
    }

    public void setNextVtValue(int VT_TYPE, int value) {
        setViewNextTrack(Converters.setBitValue(getViewNextTrack(), VT_TYPE, value));
    }


    public int getVtDate() {
        return Converters.getBitValue(getViewTrack(), VT_DATE);
    }

    public int getVtTime() {
        return Converters.getBitValue(getViewTrack(), VT_TIME);
    }

//    public int getVtSpeed() {
//        return Converters.getBitValue(getViewTrack(), VT_SPEED);
//    }

    public int getVtHieght() {
        return Converters.getBitValue(getViewTrack(), VT_HIEGHT);
    }

    public int getVtOdometr() {
        return Converters.getBitValue(getViewTrack(), VT_ODOMETR);
    }

    public int getVtMovementValue() {
        return Converters.getBitValue(getViewTrack(), VT_MOVEMENT_VALUE);
    }

    public int getVtAngle() {
        return Converters.getBitValue(getViewTrack(), VT_ANGLE);
    }

    public int getVtDigital() {
        return Converters.getBitValue(getViewTrack(), VT_DIGITAL);
    }

    public int getVtIntBatV() {
        return Converters.getBitValue(getViewTrack(), VT_INT_BAT_V);
    }

    public int getVtIntBatMa() {
        return Converters.getBitValue(getViewTrack(), VT_INT_BAT_MA);
    }

    public int getVtExtBat() {
        return Converters.getBitValue(getViewTrack(), VT_EXT_BAT);
    }

    public int getVtOperator() {
        return Converters.getBitValue(getViewTrack(), VT_OPERATOR);
    }

    public int getVtGsm() {
        return Converters.getBitValue(getViewTrack(), VT_GSM);
    }

    public int getVtCell() {
        return Converters.getBitValue(getViewTrack(), VT_CELL);
    }

    public int getVtLac() {
        return Converters.getBitValue(getViewTrack(), VT_LAC);
    }

    public int getVtSat() {
        return Converters.getBitValue(getViewTrack(), VT_SAT);
    }

    public int getVtGnss() {
        return Converters.getBitValue(getViewTrack(), VT_GNSS);
    }

    public int getVtPdop() {
        return Converters.getBitValue(getViewTrack(), VT_PDOP);
    }

    public int getVtHdop() {
        return Converters.getBitValue(getViewTrack(), VT_HDOP);
    }

    public int getVtPcb() {
        return Converters.getBitValue(getViewTrack(), VT_PCB);
    }

    public int getVtP() {
        return Converters.getBitValue(getViewTrack(), VT_P);
    }

    public int getVtDeepSleep() {
        return Converters.getBitValue(getViewTrack(), VT_DEEP_SLEEP);
    }

    public int getVtLevelFuel() {
        return Converters.getBitValue(getViewTrack(), VT_LEVEL_FUEL1);
    }

    public int getVtCanSpeed() {
        return Converters.getBitValue(getViewTrack(), VT_CAN_SPEED);
    }

    public int getVtEngineRpm() {
        return Converters.getBitValue(getViewTrack(), VT_ENGINE_RPM);
    }

    public int getVtAccelerator() {
        return Converters.getBitValue(getViewTrack(), VT_ACCELERATOR);
    }

    public int getVtEngineHour() {
        return Converters.getBitValue(getViewTrack(), VT_ENGINE_HOUR);
    }

    public int getVtTotalDistance() {
        return Converters.getBitValue(getViewTrack(), VT_TOTAL_DISTANCE);
    }

    public int getVtService() {
        return Converters.getBitValue(getViewTrack(), VT_SERVICE);
    }

    public int getVtFuelConsuption() {
        return Converters.getBitValue(getViewTrack(), VT_FUEL_CONSUPTION);
    }

    public int getVtHighResolition() {
        return Converters.getBitValue(getViewNextTrack(), VT_HEGH_RESOLITION);
    }

    public int getVtCanLevelFuel() {
        return Converters.getBitValue(getViewNextTrack(), VT_CAN_LEVEL_FUEL);
    }

    public int getVtFuelEconomy() {
        return Converters.getBitValue(getViewNextTrack(), VT_FUEL_ECONOMY);
    }

    public int getVtEngineTemperature() {
        return Converters.getBitValue(getViewNextTrack(), VT_ENGINE_TEMPERATURE);
    }

    public int getVtAmbientAir() {
        return Converters.getBitValue(getViewNextTrack(), VT_AMBIENT_AIR);
    }

    public int getVtVin() {
        return Converters.getBitValue(getViewNextTrack(), VT_VIN);
    }

    public int getVtDateReceived() {
        return Converters.getBitValue(getViewNextTrack(), VT_DATE_RECEIVED);
    }

    public int getVtTimeReceived() {
        return Converters.getBitValue(getViewNextTrack(), VT_TIME_RECEIVED);
    }

    public int getVtCom1() {
        return Converters.getBitValue(getViewNextTrack(), VT_COM1);
    }

    public int getVtCom2() {
        return Converters.getBitValue(getViewNextTrack(), VT_COM2);
    }

    public int getVtLatitude() {
        return Converters.getBitValue(getViewNextTrack(), VT_LATITUDE);
    }

    public int getVtLongitude() {
        return Converters.getBitValue(getViewNextTrack(), VT_LONGITUDE);
    }

    public int getVtSpeedTrack() {
        return Converters.getBitValue(getViewNextTrack(), VT_SPEED_TRACK);
    }

    public int getVtSpeedIo() {
        return Converters.getBitValue(getViewNextTrack(), VT_SPEED_IO);
    }

    public int getVtDigital1() {
        return Converters.getBitValue(getViewNextTrack(), VT_DIGITAL1);
    }

    public int getVtDigital2() {
        return Converters.getBitValue(getViewNextTrack(), VT_DIGITAL2);
    }

    public int getVtDigital3() {
        return Converters.getBitValue(getViewNextTrack(), VT_DIGITAL3);
    }

    public int getVtDigital4() {
        return Converters.getBitValue(getViewNextTrack(), VT_DIGITAL4);
    }

    public int getVtAnalog1() {
        return Converters.getBitValue(getViewNextTrack(), VT_ANALOG1);
    }

    public int getVtAnalog2() {
        return Converters.getBitValue(getViewNextTrack(), VT_ANALOG2);
    }

    public int getVtAnalog3() {
        return Converters.getBitValue(getViewNextTrack(), VT_ANALOG3);
    }

    public int getVtAnalog4() {
        return Converters.getBitValue(getViewNextTrack(), VT_ANALOG4);
    }

    public int getVtCom12() {
        return Converters.getBitValue(getViewNextTrack(), VT_COM12);
    }

    public int getVtCom22() {
        return Converters.getBitValue(getViewNextTrack(), VT_COM22);
    }

    public int getVtCanLevelFuel2() {
        return Converters.getBitValue(getViewNextTrack(), VT_CAN_LEVEL_FUEL2);
    }

    public int getVtFuelEconomy2() {
        return Converters.getBitValue(getViewNextTrack(), VT_FUEL_ECONOMY2);
    }

    public int getVtLevelFuel2() {
        return Converters.getBitValue(getViewNextTrack(), VT_LEVEL_FUEL2);
    }

    public Integer getTrackedObjectsMinZoom() {
        return trackedObjectsMinZoom;
    }

    public void setTrackedObjectsMinZoom(Integer trackedObjectsMinZoom) {
        this.trackedObjectsMinZoom = trackedObjectsMinZoom;
    }

    public Integer getTrackedObjectsMaxZoom() {
        return trackedObjectsMaxZoom;
    }

    public void setTrackedObjectsMaxZoom(Integer trackedObjectsMaxZoom) {
        this.trackedObjectsMaxZoom = trackedObjectsMaxZoom;
    }

    public Integer getTrackingValuesPart4() {
        return trackingValuesPart4;
    }

    public void setTrackingValuesPart4(Integer trackingValuesPart4) {
        this.trackingValuesPart4 = trackingValuesPart4;
    }

    public Integer getMessageValuesPart4() {
        return messageValuesPart4;
    }

    public void setMessageValuesPart4(Integer messageValuesPart4) {
        this.messageValuesPart4 = messageValuesPart4;
    }

    public Integer getMonitoringValuesPart4() {
        return monitoringValuesPart4;
    }

    public void setMonitoringValuesPart4(Integer monitoringValuesPart4) {
        this.monitoringValuesPart4 = monitoringValuesPart4;
    }

    public Integer getTrackPopupValuesPart4() {
        return trackPopupValuesPart4;
    }

    public void setTrackPopupValuesPart4(Integer trackPopupValuesPart4) {
        this.trackPopupValuesPart4 = trackPopupValuesPart4;
    }

    public Integer getSosPopupValuesPart4() {
        return sosPopupValuesPart4;
    }

    public void setSosPopupValuesPart4(Integer sosPopupValuesPart4) {
        this.sosPopupValuesPart4 = sosPopupValuesPart4;
    }

    public Integer getTrackingValuesPart5() {
        return trackingValuesPart5;
    }

    public void setTrackingValuesPart5(Integer trackingValuesPart5) {
        this.trackingValuesPart5 = trackingValuesPart5;
    }

    public Integer getMessageValuesPart5() {
        return messageValuesPart5;
    }

    public void setMessageValuesPart5(Integer messageValuesPart5) {
        this.messageValuesPart5 = messageValuesPart5;
    }

    public Boolean getIsShowTrackingTable() {
        return isShowTrackingTable;
    }

    public void setIsShowTrackingTable(Boolean showTrackingTable) {
        isShowTrackingTable = showTrackingTable;
    }

    public Boolean getIsShowTrackingChart() {
        return isShowTrackingChart;
    }

    public void setIsShowTrackingChart(Boolean showTrackingChart) {
        isShowTrackingChart = showTrackingChart;
    }

    public Boolean getObjectAdditionalInfoMonitoring() {
        return objectAdditionalInfoMonitoring;
    }

    public void setObjectAdditionalInfoMonitoring(Boolean objectAdditionalInfoMonitoring) {
        this.objectAdditionalInfoMonitoring = objectAdditionalInfoMonitoring;
    }

    public Boolean getShowObjectsInCluster() {
        return showObjectsInCluster;
    }

    public void setShowObjectsInCluster(Boolean showObjectsInCluster) {
        this.showObjectsInCluster = showObjectsInCluster;
    }

    public Boolean getPoiLoadStartup() {
        return poiLoadStartup;
    }

    public void setPoiLoadStartup(Boolean poiLoadStartup) {
        this.poiLoadStartup = poiLoadStartup;
    }

    public Boolean getGeozoneLoadStartup() {
        return geozoneLoadStartup;
    }

    public void setGeozoneLoadStartup(Boolean geozoneLoadStartup) {
        this.geozoneLoadStartup = geozoneLoadStartup;
    }

    public List<SensorDisplay> getSensorDisplayList() {
        return sensorDisplayList;
    }

    public void setSensorDisplayList(List<SensorDisplay> sensorsDisplayList) {
        this.sensorDisplayList = sensorsDisplayList;
    }

    /* ---------- FUNCTIONS FOR VIEW TRACK ---------- << */

    public static ContractSettings createDefault() {
        ContractSettings contractSettings = new ContractSettings();
//        contractSettings.setContract(contract);
        contractSettings.setMapType(1L);
        contractSettings.setSaveCurrentPosition(true);
        contractSettings.setShowNamePoi(true);
        contractSettings.setShowObjectsInCluster(true);
        contractSettings.setPoiLoadStartup(true);
        contractSettings.setGeozoneLoadStartup(true);
        contractSettings.setBindingTracksToMap(false);
        contractSettings.setShowNameGeoZone(true);
        contractSettings.setObjectLabel(1L);
        contractSettings.setObjectNameMonitoring(true);
        contractSettings.setObjectNameTracking(true);
        contractSettings.setTypeTrackerMonitoring(false);
        contractSettings.setTypeTrackerTracking(true);
        contractSettings.setTrackerIdMonitoring(false);
        contractSettings.setTrackerIdTracking(false);
        contractSettings.setTrackerPhoneNumberMonitoring(true);
        contractSettings.setTrackerPhoneNumberTracking(false);
        contractSettings.setObjectTypeMonitoring(true);
        contractSettings.setObjectTypeTracking(false);
        contractSettings.setObjectPlateNumberMonitoring(true);
        contractSettings.setObjectPlateNumberTracking(false);
        contractSettings.setObjectAdditionalInfoMonitoring(false);
        contractSettings.setObjectCapacityMonitoring(false);
        contractSettings.setObjectCapacityTracking(false);
        contractSettings.setObjectFuelMonitoring(false);
        contractSettings.setObjectFuelTracking(false);
        contractSettings.setObjectAddressMonitoring(true);
        contractSettings.setObjectAddressTracking(true);
        contractSettings.setObjectCoordinatesMonitoring(true);
        contractSettings.setObjectCoordinatesTracking(true);
        contractSettings.setObjectSpeedMonitoring(true);
        contractSettings.setObjectSpeedTracking(true);
        contractSettings.setObjectSatelliteMonitoring(true);
        contractSettings.setObjectSatelliteTracking(true);
        contractSettings.setObjectOdometerMonitoring(false);
        contractSettings.setObjectOdometerTracking(true);
        contractSettings.setObjectHourmeterMonitoring(false);
        contractSettings.setObjectHourmeterTracking(true);
        contractSettings.setBeingGeozonMonitoring(false);
        contractSettings.setBeingGeozonTracking(false);
        contractSettings.setDesignRoutMonitoring(false);
        contractSettings.setDesignRoutTracking(false);
        contractSettings.setNameStaffMonitoring(true);
        contractSettings.setNameStaffTracking(false);
        contractSettings.setPhotoStaffMonitoring(true);
        contractSettings.setPhotoStaffTracking(false);
        contractSettings.setPhoneStaffMonitoring(true);
        contractSettings.setPhoneStaffTracking(false);
        contractSettings.setObjectStatusPosition(0);
        contractSettings.setObjectStatusView(true);
        contractSettings.setIgnitionSensorPosition(1);
        contractSettings.setIgnitionSensorView(true);
        contractSettings.setSatelliteVisibilityPosition(2);
        contractSettings.setSatelliteVisibilityView(true);
        contractSettings.setObjectLinkPosition(3);
        contractSettings.setObjectLinkView(true);
        contractSettings.setBuildTrackPosition(4);
        contractSettings.setBuildTrackView(true);
        contractSettings.setSmsSendPosition(5);
        contractSettings.setSmsSendView(false);
        contractSettings.setObjectDriverPosition(6);
        contractSettings.setObjectDriverView(true);
        contractSettings.setSensorStatePosition(7);
        contractSettings.setSensorStateView(false);
        contractSettings.setObjectMassagePosition(8);
        contractSettings.setObjectMassageView(false);
        contractSettings.setReportPosition(9);

        contractSettings.setExternalPowerVoltageView(true);
        contractSettings.setExternalPowerVoltagePosition(12);

        contractSettings.setLastMsgTimeView(true);
        contractSettings.setLastMsgTimePosition(13);

        contractSettings.setReportView(false);
        contractSettings.setObjectPropertiesPosition(10);
        contractSettings.setObjectPropertiesView(true);
        // Quick track building default
        contractSettings.setFastTrackType(1L);
        contractSettings.setFastTrackValue(1L);
        contractSettings.setDeletePrevTrack(true);
        contractSettings.setDottedLineThickness(3);
        contractSettings.setLinearLineThickness(3);

        contractSettings.setTrackLengthType(1L);
        contractSettings.setTrackLengthValue(3L);
        contractSettings.setTrackLengthColor("#0033FF");
        contractSettings.setTrackedObjectsMinZoom(4);
        contractSettings.setTrackedObjectsMaxZoom(18);
        contractSettings.setMappingObjectType(2L);
        contractSettings.setObjectMovementType(0);
        contractSettings.setIsShowSuspendedObjects(false);
        contractSettings.setIsShowTrackingTable(false);
        contractSettings.setIsShowTrackingChart(true);
        contractSettings.setTooltipsViewQuantity(5L);
        contractSettings.setTooltipsMassagesView(true);
        contractSettings.setTooltipsMassagesColor("#1eb050");
        contractSettings.setTooltipsSmsView(true);
        contractSettings.setTooltipsSmsColor("#0618f9");
        contractSettings.setTooltipsCommandView(true);
        contractSettings.setTooltipsCommandColor("#F80000");
        contractSettings.setTooltipsEventView(true);
        contractSettings.setTooltipsEventColor("#f20303");
        contractSettings.setMonitoringRefreshInterval(10);
        contractSettings.setBakPositionView(false);
        contractSettings.setBakPosition(11);
        contractSettings.setViewTrack(77798);
        contractSettings.setViewNextTrack(108928);
        contractSettings.setViewMessage(2965478);
        contractSettings.setViewNextMessage(129408);
        // Set default tracking values
        contractSettings.setTrackingValuesPart1(ContractSettings.TRACKING_VALUES_PART1_DEFAULT);
        contractSettings.setTrackingValuesPart2(ContractSettings.TRACKING_VALUES_PART2_DEFAULT);
        contractSettings.setTrackingValuesPart3(ContractSettings.TRACKING_VALUES_PART3_DEFAULT);

        // Set default message values
        contractSettings.setMessageValuesPart1(ContractSettings.MESSAGE_VALUES_PART1_DEFAULT);
        contractSettings.setMessageValuesPart2(ContractSettings.MESSAGE_VALUES_PART2_DEFAULT);
        contractSettings.setMessageValuesPart3(ContractSettings.MESSAGE_VALUES_PART3_DEFAULT);

        // Set default monitoring values
        contractSettings.setMonitoringValuesPart1(ContractSettings.MONITORING_VALUES_PART1_DEFAULT);
        contractSettings.setMonitoringValuesPart2(ContractSettings.MONITORING_VALUES_PART2_DEFAULT);
        contractSettings.setMonitoringValuesPart3(ContractSettings.MONITORING_VALUES_PART3_DEFAULT);

        // Set default track popup values
        contractSettings.setTrackPopupValuesPart1(ContractSettings.TRACK_POPUP_VALUES_PART1_DEFAULT);
        contractSettings.setTrackPopupValuesPart2(ContractSettings.TRACK_POPUP_VALUES_PART2_DEFAULT);
        contractSettings.setTrackPopupValuesPart3(ContractSettings.TRACK_POPUP_VALUES_PART3_DEFAULT);

        // Set default parking popup values
        contractSettings.setParkingPopupValuesPart1(ContractSettings.PARKING_POPUP_VALUES_PART1_DEFAULT);

        // Set default sos popup values
        contractSettings.setSosPopupValuesPart1(ContractSettings.SOS_POPUP_VALUES_PART1_DEFAULT);
        contractSettings.setSosPopupValuesPart2(ContractSettings.SOS_POPUP_VALUES_PART2_DEFAULT);
        contractSettings.setSosPopupValuesPart3(ContractSettings.SOS_POPUP_VALUES_PART3_DEFAULT);

        return contractSettings;
    }

    @Override
    public String toString() {
        return "ContractSettings{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", contract=" + contract +
                ", mapType=" + mapType +
                ", saveCurrentPosition=" + saveCurrentPosition +
                ", showNamePoi=" + showNamePoi +
                ", showObjectsInCluster=" + showObjectsInCluster +
                ", poiLoadStartup=" + poiLoadStartup +
                ", geozoneLoadStartup=" + geozoneLoadStartup +
                ", bindingTracksToMap=" + bindingTracksToMap +
                ", showNameGeoZone=" + showNameGeoZone +
                ", objectLabel=" + objectLabel +
                ", objectNameMonitoring=" + objectNameMonitoring +
                ", objectNameTracking=" + objectNameTracking +
                ", typeTrackerMonitoring=" + typeTrackerMonitoring +
                ", typeTrackerTracking=" + typeTrackerTracking +
                ", trackerIdMonitoring=" + trackerIdMonitoring +
                ", trackerIdTracking=" + trackerIdTracking +
                ", trackerPhoneNumberMonitoring=" + trackerPhoneNumberMonitoring +
                ", trackerPhoneNumberTracking=" + trackerPhoneNumberTracking +
                ", objectTypeMonitoring=" + objectTypeMonitoring +
                ", objectTypeTracking=" + objectTypeTracking +
                ", objectPlateNumberMonitoring=" + objectPlateNumberMonitoring +
                ", objectPlateNumberTracking=" + objectPlateNumberTracking +
                ", objectAdditionalInfoMonitoring=" + objectAdditionalInfoMonitoring +
                ", objectCapacityMonitoring=" + objectCapacityMonitoring +
                ", objectCapacityTracking=" + objectCapacityTracking +
                ", objectFuelMonitoring=" + objectFuelMonitoring +
                ", objectFuelTracking=" + objectFuelTracking +
                ", objectAddressMonitoring=" + objectAddressMonitoring +
                ", objectAddressTracking=" + objectAddressTracking +
                ", objectCoordinatesMonitoring=" + objectCoordinatesMonitoring +
                ", objectCoordinatesTracking=" + objectCoordinatesTracking +
                ", objectSpeedMonitoring=" + objectSpeedMonitoring +
                ", objectSpeedTracking=" + objectSpeedTracking +
                ", objectSatelliteMonitoring=" + objectSatelliteMonitoring +
                ", objectSatelliteTracking=" + objectSatelliteTracking +
                ", objectOdometerMonitoring=" + objectOdometerMonitoring +
                ", objectOdometerTracking=" + objectOdometerTracking +
                ", objectHourmeterMonitoring=" + objectHourmeterMonitoring +
                ", objectHourmeterTracking=" + objectHourmeterTracking +
                ", beingGeozonMonitoring=" + beingGeozonMonitoring +
                ", beingGeozonTracking=" + beingGeozonTracking +
                ", designRoutMonitoring=" + designRoutMonitoring +
                ", designRoutTracking=" + designRoutTracking +
                ", nameStaffMonitoring=" + nameStaffMonitoring +
                ", nameStaffTracking=" + nameStaffTracking +
                ", photoStaffMonitoring=" + photoStaffMonitoring +
                ", photoStaffTracking=" + photoStaffTracking +
                ", phoneStaffMonitoring=" + phoneStaffMonitoring +
                ", phoneStaffTracking=" + phoneStaffTracking +
                ", objectStatusView=" + objectStatusView +
                ", objectStatusPosition=" + objectStatusPosition +
                ", ignitionSensorView=" + ignitionSensorView +
                ", ignitionSensorPosition=" + ignitionSensorPosition +
                ", objectLinkView=" + objectLinkView +
                ", objectLinkPosition=" + objectLinkPosition +
                ", satelliteVisibilityView=" + satelliteVisibilityView +
                ", satelliteVisibilityPosition=" + satelliteVisibilityPosition +
                ", objectDriverView=" + objectDriverView +
                ", objectDriverPosition=" + objectDriverPosition +
                ", sensorStateView=" + sensorStateView +
                ", sensorStatePosition=" + sensorStatePosition +
                ", objectMassageView=" + objectMassageView +
                ", objectMassagePosition=" + objectMassagePosition +
                ", buildTrackView=" + buildTrackView +
                ", buildTrackPosition=" + buildTrackPosition +
                ", reportView=" + reportView +
                ", reportPosition=" + reportPosition +
                ", smsSendView=" + smsSendView +
                ", smsSendPosition=" + smsSendPosition +
                ", objectPropertiesView=" + objectPropertiesView +
                ", objectPropertiesPosition=" + objectPropertiesPosition +
                ", fastTrackType=" + fastTrackType +
                ", fastTrackValue=" + fastTrackValue +
                ", trackLengthType=" + trackLengthType +
                ", trackLengthValue=" + trackLengthValue +
                ", trackLengthColor='" + trackLengthColor + '\'' +
                ", mappingObjectType=" + mappingObjectType +
                ", objectMovementType=" + objectMovementType +
                ", isShowSuspendedObjects=" + isShowSuspendedObjects +
                ", isShowTrackingTable=" + isShowTrackingTable +
                ", isShowTrackingChart=" + isShowTrackingChart +
                ", tooltipsViewQuantity=" + tooltipsViewQuantity +
                ", tooltipsMassagesView=" + tooltipsMassagesView +
                ", tooltipsMassagesColor='" + tooltipsMassagesColor + '\'' +
                ", tooltipsSmsView=" + tooltipsSmsView +
                ", tooltipsSmsColor='" + tooltipsSmsColor + '\'' +
                ", tooltipsCommandView=" + tooltipsCommandView +
                ", tooltipsCommandColor='" + tooltipsCommandColor + '\'' +
                ", tooltipsEventView=" + tooltipsEventView +
                ", tooltipsEventColor='" + tooltipsEventColor + '\'' +
                ", monitoringRefreshInterval=" + monitoringRefreshInterval +
                ", lastTrackTimestamp=" + lastTrackTimestamp +
                ", fuelMonitoring=" + fuelMonitoring +
                ", fuelTracking=" + fuelTracking +
                ", assignedRouteMonitoring=" + assignedRouteMonitoring +
                ", assignedRouteTracking=" + assignedRouteTracking +
                ", bakPositionView=" + bakPositionView +
                ", bakPosition=" + bakPosition +
                ", trackedObjectsMinZoom=" + trackedObjectsMinZoom +
                ", trackedObjectsMaxZoom=" + trackedObjectsMaxZoom +
                '}';
    }
}
