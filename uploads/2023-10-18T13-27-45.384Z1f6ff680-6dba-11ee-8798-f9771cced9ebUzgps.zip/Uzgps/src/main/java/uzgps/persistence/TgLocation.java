package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "uzgps_tg_bot_location")
public class TgLocation implements Serializable {

    public static final String sequenceName = "seq_uzgps_tg_bot_location";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "chat_id")
    private Long chatId;

    @Column(name = "message_id")
    private Long messageId;

    @Column(name = "mobject_id")
    private Long mobjectId;

    @Column(name = "time_expire_date")
    private Timestamp timeExpireDate;

    @Column(name = "status", length = 1)
    private String status;

    @Column(name = "reg_date")
    private Timestamp regDate;

    @Column(name = "mod_date")
    private Timestamp modDate;

    @Column(name = "exp_date")
    private Timestamp expDate;

    public TgLocation(Long chatId, Long messageId, Long mobjectId, Timestamp timeExpireDate) {
        this.chatId = chatId;
        this.messageId = messageId;
        this.mobjectId = mobjectId;
        this.timeExpireDate = timeExpireDate;
        this.status = "A";
        this.regDate = new Timestamp(System.currentTimeMillis());
    }

    public TgLocation() {
        this.regDate = new Timestamp(System.currentTimeMillis());
        this.status = "A";
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getChatId() {
        return chatId;
    }

    public void setChatId(Long chatId) {
        this.chatId = chatId;
    }

    public Long getMessageId() {
        return messageId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }

    public Timestamp getTimeExpireDate() {
        return timeExpireDate;
    }

    public void setTimeExpireDate(Timestamp timeExpireDate) {
        this.timeExpireDate = timeExpireDate;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "TgLocation{" +
                "id=" + id +
                ", chatId=" + chatId +
                ", messageId=" + messageId +
                ", mobjectId=" + mobjectId +
                ", timeExpireDate=" + timeExpireDate +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
