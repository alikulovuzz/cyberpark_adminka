package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * User: Sheroz
 * Date: 17.12.12
 * Time: 16:31
 */

@Entity
@Table(name = "uzgps_user_role")
public class UserRole implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_USER_ROLE_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "user_id", nullable = false, insertable = false, updatable = false)
    private Long userId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @Basic
    @Column(name = "role_id", nullable = false)
    private Long roleId;

    @Basic
    @Column(name = "contract_id", nullable = true, insertable = false, updatable = false)
    private Long contractId;
    @ManyToOne
    @JoinColumn(name = "contract_id")
    private Contract contract;

    @Column(name = "status", length = 1)
    private String status;

    @Column(name = "reg_date")
    private Timestamp regDate;

    @Column(name = "mod_date")
    private Timestamp modDate;

    @Column(name = "exp_date")
    private Timestamp expDate;

    @Column(name = "default_customer_admin")
    private Boolean defaultCustomerAdmin;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Boolean getDefaultCustomerAdmin() {
        return defaultCustomerAdmin;
    }

    public void setDefaultCustomerAdmin(Boolean defaultCustomerAdmin) {
        this.defaultCustomerAdmin = defaultCustomerAdmin;
    }

    @Override
    public String toString() {
        return "UserRole{" +
                "id=" + id +
                ", userId=" + userId +
                ", user=" + user +
                ", roleId=" + roleId +
                ", contractId=" + contractId +
                ", contract=" + contract +
                ", defaultCustomerAdmin=" + defaultCustomerAdmin +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
