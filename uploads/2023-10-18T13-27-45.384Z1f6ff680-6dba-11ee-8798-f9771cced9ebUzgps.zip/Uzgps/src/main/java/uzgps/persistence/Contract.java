package uzgps.persistence;

import org.hibernate.validator.constraints.NotEmpty;
import uz.netex.uzgps.billing.lib.common.Config;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


@Entity
@Table(name = "uzgps_contract")
public class Contract implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_CONTRACT_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "company_id", nullable = false, insertable = false, updatable = false)
    private long companyId;
    @OneToOne
    @JoinColumn(name = "company_id")
    private Company company;

    @NotEmpty(message = "Please enter contract number")
    @Column(name = "contract_number", nullable = false, length = 40)
    private String contractNumber;

    @Column(name = "contract_reg_date")
    private Timestamp contractRegDate;

    @Column(name = "contract_type", nullable = false, length = 1)
    private String contractType;

    @Column(name = "exist_unit_count", nullable = false)
    private Long existUnitCount;

    @Column(name = "a_max_unit_count", nullable = false)
    private Long activeMaxUnitCount;

    @Column(name = "a_max_user_count", nullable = false)
    private Long activeMaxUserCount;

    @Column(name = "a_max_staff_count", nullable = false)
    private Long activeMaxStaffCount;

    @Column(name = "a_max_poi_count", nullable = false)
    private Long activeMaxPoiCount;

    @Column(name = "a_max_geo_fance_count", nullable = false)
    private Long activeMaxGeoFanceCount;

    @Column(name = "max_unit_count", nullable = false)
    private Long maxUnitCount;

    @Column(name = "max_user_count", nullable = false)
    private Long maxUserCount;

    @Column(name = "max_staff_count", nullable = false)
    private Long maxStaffCount;

    @Column(name = "max_poi_count", nullable = false)
    private Long maxPoiCount;

    @Column(name = "max_geo_fance_count", nullable = false)
    private Long maxGeoFanceCount;

    @Column(name = "max_report_count", nullable = false)
    private Long maxReportCount;

    @Column(name = "max_email_count", nullable = false)
    private Long maxEmailCount;

    @Column(name = "max_sms_count", nullable = false)
    private Long maxSmsCount;

    @Column(name = "max_sms_cmd_count", nullable = false)
    private Long maxSmsCmdCount;

    @Column(name = "test_contract", nullable = true)
    private Boolean testContract;

    @Column(name = "customer_company_name", nullable = true)
    private String customerCompanyName;

    @Column(name = "acts_on_the_basis", nullable = true)
    private String customerActsOnTheBasis;

    @Column(name = "customer_region", nullable = true)
    private Long customerRegion;

    @Column(name = "customer_legal_address", nullable = true)
    private String customerLegalAddress;

    @Column(name = "customer_postal_address", nullable = true)
    private String customerPostalAddress;

    @Column(name = "customer_phone", nullable = true)
    private String customerPhone;

    @Column(name = "customer_phoneMobile", nullable = true)
    private String customerPhoneMobile;

    @Column(name = "customer_fax", nullable = true)
    private String customerFax;

    @Column(name = "customer_email", nullable = true)
    private String customerEmail;

    @Column(name = "customer_bank_name", nullable = true)
    private String customerBankName;

    @Column(name = "customer_bank_code", nullable = true)
    private String customerBankCode;

    @Column(name = "customer_account", nullable = true)
    private String customerAccount;

    @Column(name = "customer_account_treasury", nullable = true)
    private String customerAccountTreasury;

    @Column(name = "customer_inn", nullable = true)
    private String customerINN;

    @Column(name = "customer_okonh", nullable = true)
    private String customerOKONH;

    @Column(name = "customer_oked", nullable = true)
    private String customerOKED;

    @Column(name = "taxpayer_reg_number", nullable = true)
    private String taxpayerRegNumber;


    @Column(name = "position", nullable = true)
    private String position;

    @Column(name = "director_surname", nullable = true)
    private String directorSurname;

    @Column(name = "director_name", nullable = true)
    private String directorName;

    @Column(name = "director_middlename", nullable = true)
    private String directorMiddlename;

    @Column(name = "director_phone", nullable = true)
    private String directorPhone;

    @Column(name = "director_email", nullable = true)
    private String directorEmail;

    @Column(name = "note", nullable = true)
    private String note;

    @Column(name = "customer_surname", nullable = true)
    private String customerSurname;

    @Column(name = "customer_name", nullable = true)
    private String customerName;

    @Column(name = "customer_middlename", nullable = true)
    private String customerMiddlename;

    @Column(name = "customer_gender", nullable = true)
    private Long customerGender;

    @Column(name = "customer_document_type", nullable = true)
    private String customerDocumentType;

    @Column(name = "customer_birth_date", nullable = true)
    private Timestamp customerBirthDate;

    @Column(name = "customer_citizenship", nullable = true)
    private Long customerCitizenship;

    @Column(name = "customer_passport_series", nullable = true)
    private String customerPassportSeries;

    @Column(name = "customer_passport_number", nullable = true)
    private String customerPassportNumber;

    @Column(name = "customer_passport_issued_by", nullable = true)
    private String customerPassportIssuedBy;

    @Column(name = "customer_passport_expire_date", nullable = true)
    private Timestamp customerPassportExpireDate;

    @Column(name = "customer_registration_address", nullable = true)
    private String customerRegistrationAddress;

    @Column(name = "status_id", nullable = true, insertable = false, updatable = false)
    private Long statusId;

    @ManyToOne
    @JoinColumn(name = "status_id")
    private ContractStatus contractStatus;

    @Column(name = "c_exp_date", nullable = true)
    private Timestamp expiredDate;

    @Column(name = "c_block", nullable = false, length = 1)
    private String block;

    @Column(name = "c_status", nullable = false, length = 1)
    private String status;

    @Column(name = "c_reg_date", nullable = true)
    private Timestamp registrationDate;

    @Column(name = "c_mod_date", nullable = true)
    private Timestamp modificationDate;

    @Column(name = "before_blocking_date", nullable = true)
    private Timestamp beforeBlockingDate;

    @Column(name = "locked_date", nullable = true)
    private Timestamp lockedDate;

    @Column(name = "suspended_system_date", nullable = true)
    private Timestamp suspendedSystemDate;

    @Column(name = "pretension_date", nullable = true)
    private Timestamp pretensionDate;

    @Column(name = "expiry_date", nullable = true)
    private Timestamp expiryDate;

    @Transient
    private String registrationDateFormatted;

    @Transient
    private Long balance;

    @Transient
    private Long paymentsInCurrentPeriod;

    @Transient
    private Long chargesInCurrentPeriod;

    @Transient
    private Timestamp lastPaymentDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(long companyId) {
        this.companyId = companyId;
    }

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public Timestamp getContractRegDate() {
        return contractRegDate;
    }

    public String getRegistrationDateFormatted() {
        if (contractRegDate == null) return "";
        else {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            return df.format(contractRegDate);
        }
    }

    public String getExpiryDateFormatted() {
        if (expiryDate == null) return "";
        else {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            return df.format(expiryDate);
        }
    }

    public void setContractRegDate(Timestamp contractRegDate) {
        this.contractRegDate = contractRegDate;
    }

    public Long getActiveMaxUnitCount() {
        return activeMaxUnitCount;
    }

    public void setActiveMaxUnitCount(Long activeMaxUnitCount) {
        this.activeMaxUnitCount = activeMaxUnitCount;
    }

    public Long getActiveMaxUserCount() {
        return activeMaxUserCount;
    }

    public void setActiveMaxUserCount(Long activeMaxUserCount) {
        this.activeMaxUserCount = activeMaxUserCount;
    }

    public Long getActiveMaxStaffCount() {
        return activeMaxStaffCount;
    }

    public void setActiveMaxStaffCount(Long activeMaxStaffCount) {
        this.activeMaxStaffCount = activeMaxStaffCount;
    }

    public Long getActiveMaxPoiCount() {
        return activeMaxPoiCount;
    }

    public void setActiveMaxPoiCount(Long activeMaxPoiCount) {
        this.activeMaxPoiCount = activeMaxPoiCount;
    }

    public Long getActiveMaxGeoFanceCount() {
        return activeMaxGeoFanceCount;
    }

    public void setActiveMaxGeoFanceCount(Long activeMaxGeoFanceCount) {
        this.activeMaxGeoFanceCount = activeMaxGeoFanceCount;
    }

    public Long getMaxUnitCount() {
        return maxUnitCount;
    }

    public void setMaxUnitCount(Long maxUnitCount) {
        this.maxUnitCount = maxUnitCount;
    }

    public Long getMaxUserCount() {
        return maxUserCount;
    }

    public void setMaxUserCount(Long maxUserCount) {
        this.maxUserCount = maxUserCount;
    }

    public Long getMaxStaffCount() {
        return maxStaffCount;
    }

    public void setMaxStaffCount(Long maxStaffCount) {
        this.maxStaffCount = maxStaffCount;
    }

    public Long getMaxPoiCount() {
        return maxPoiCount;
    }

    public void setMaxPoiCount(Long maxPoiCount) {
        this.maxPoiCount = maxPoiCount;
    }

    public Long getMaxGeoFanceCount() {
        return maxGeoFanceCount;
    }

    public void setMaxGeoFanceCount(Long maxGeoFanceCount) {
        this.maxGeoFanceCount = maxGeoFanceCount;
    }

    public Boolean getTestContract() {
        return testContract;
    }

    public void setTestContract(Boolean testContract) {
        this.testContract = testContract;
    }

    public String getCustomerCompanyName() {
        return customerCompanyName;
    }

    public void setCustomerCompanyName(String customerCompanyName) {
        this.customerCompanyName = customerCompanyName;
    }

    public String getCustomerActsOnTheBasis() {
        return customerActsOnTheBasis;
    }

    public void setCustomerActsOnTheBasis(String customerActsOnTheBasis) {
        this.customerActsOnTheBasis = customerActsOnTheBasis;
    }

    public Long getCustomerRegion() {
        return customerRegion;
    }

    public void setCustomerRegion(Long customerRegion) {
        this.customerRegion = customerRegion;
    }

    public String getCustomerLegalAddress() {
        return customerLegalAddress;
    }

    public void setCustomerLegalAddress(String customerLegalAddress) {
        this.customerLegalAddress = customerLegalAddress;
    }

    public String getCustomerPostalAddress() {
        return customerPostalAddress;
    }

    public void setCustomerPostalAddress(String customerPostalAddress) {
        this.customerPostalAddress = customerPostalAddress;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public String getCustomerPhoneMobile() {
        return customerPhoneMobile;
    }

    public void setCustomerPhoneMobile(String customerPhoneMobile) {
        this.customerPhoneMobile = customerPhoneMobile;
    }

    public String getCustomerFax() {
        return customerFax;
    }

    public void setCustomerFax(String customerFax) {
        this.customerFax = customerFax;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getCustomerBankName() {
        return customerBankName;
    }

    public void setCustomerBankName(String customerBankName) {
        this.customerBankName = customerBankName;
    }

    public String getCustomerBankCode() {
        return customerBankCode;
    }

    public void setCustomerBankCode(String customerBankCode) {
        this.customerBankCode = customerBankCode;
    }

    public String getCustomerAccount() {
        return customerAccount;
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount;
    }

    public String getCustomerAccountTreasury() {
        return customerAccountTreasury;
    }

    public void setCustomerAccountTreasury(String customerAccountTreasury) {
        this.customerAccountTreasury = customerAccountTreasury;
    }


    public String getCustomerINN() {
        return customerINN;
    }

    public void setCustomerINN(String customerINN) {
        this.customerINN = customerINN;
    }

    public String getCustomerOKONH() {
        return customerOKONH;
    }

    public void setCustomerOKONH(String customerOKONH) {
        this.customerOKONH = customerOKONH;
    }

    public String getCustomerOKED() {
        return customerOKED;
    }

    public void setCustomerOKED(String customerOKED) {
        this.customerOKED = customerOKED;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getDirectorSurname() {
        return directorSurname;
    }

    public void setDirectorSurname(String directorSurname) {
        this.directorSurname = directorSurname;
    }

    public String getDirectorName() {
        return directorName;
    }

    public void setDirectorName(String directorName) {
        this.directorName = directorName;
    }

    public String getDirectorMiddlename() {
        return directorMiddlename;
    }

    public void setDirectorMiddlename(String directorMiddlename) {
        this.directorMiddlename = directorMiddlename;
    }

    public String getDirectorPhone() {
        return directorPhone;
    }

    public void setDirectorPhone(String directorPhone) {
        this.directorPhone = directorPhone;
    }

    public String getDirectorEmail() {
        return directorEmail;
    }

    public void setDirectorEmail(String directorEmail) {
        this.directorEmail = directorEmail;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getCustomerSurname() {
        return customerSurname;
    }

    public void setCustomerSurname(String customerSurname) {
        this.customerSurname = customerSurname;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerMiddlename() {
        return customerMiddlename;
    }

    public void setCustomerMiddlename(String customerMiddlename) {
        this.customerMiddlename = customerMiddlename;
    }

    public Long getCustomerGender() {
        return customerGender;
    }

    public void setCustomerGender(Long customerGender) {
        this.customerGender = customerGender;
    }

    public String getCustomerDocumentType() {
        return customerDocumentType;
    }

    public void setCustomerDocumentType(String customerDocumentType) {
        this.customerDocumentType = customerDocumentType;
    }

    public Timestamp getCustomerBirthDate() {
        return customerBirthDate;
    }

    public void setCustomerBirthDate(Timestamp customerBirthDate) {
        this.customerBirthDate = customerBirthDate;
    }

    public String getCustomerBirthDateFormatted() {
        if (customerBirthDate == null) return "";
        else {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            return df.format(customerBirthDate);
        }
    }

    public Long getCustomerCitizenship() {
        return customerCitizenship;
    }

    public void setCustomerCitizenship(Long customerCitizenship) {
        this.customerCitizenship = customerCitizenship;
    }

    public String getCustomerPassportSeries() {
        return customerPassportSeries;
    }

    public void setCustomerPassportSeries(String customerPassportSeries) {
        this.customerPassportSeries = customerPassportSeries;
    }

    public String getCustomerPassportNumber() {
        return customerPassportNumber;
    }

    public void setCustomerPassportNumber(String customerPassportNumber) {
        this.customerPassportNumber = customerPassportNumber;
    }

    public String getCustomerPassportIssuedBy() {
        return customerPassportIssuedBy;
    }

    public void setCustomerPassportIssuedBy(String customerPassportIssuedBy) {
        this.customerPassportIssuedBy = customerPassportIssuedBy;
    }

    public Timestamp getCustomerPassportExpireDate() {
        return customerPassportExpireDate;
    }

    public void setCustomerPassportExpireDate(Timestamp customerPassportExpireDate) {
        this.customerPassportExpireDate = customerPassportExpireDate;
    }

    public String getCustomerPassportExpireDateFormatted() {
        if (customerPassportExpireDate == null) return "";
        else {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            return df.format(customerPassportExpireDate);
        }
    }

    public String getCustomerRegistrationAddress() {
        return customerRegistrationAddress;
    }

    public void setCustomerRegistrationAddress(String customerRegistrationAddress) {
        this.customerRegistrationAddress = customerRegistrationAddress;
    }

    public void setRegistrationDateFormatted(String registrationDateFormatted) {
        this.registrationDateFormatted = registrationDateFormatted;
    }


    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Timestamp registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public Timestamp getModificationDate() {
        return modificationDate;
    }

    public void setModificationDate(Timestamp modificationDate) {
        this.modificationDate = modificationDate;
    }

    public Timestamp getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Timestamp expiredDate) {
        this.expiredDate = expiredDate;
    }

    public Long getExistUnitCount() {
        return existUnitCount;
    }

    public void setExistUnitCount(Long existUnitCount) {
        this.existUnitCount = existUnitCount;
    }

    public Long getMaxReportCount() {
        return maxReportCount;
    }

    public void setMaxReportCount(Long maxReportCount) {
        this.maxReportCount = maxReportCount;
    }

    public Long getMaxEmailCount() {
        return maxEmailCount;
    }

    public void setMaxEmailCount(Long maxEmailCount) {
        this.maxEmailCount = maxEmailCount;
    }

    public Long getMaxSmsCount() {
        return maxSmsCount;
    }

    public void setMaxSmsCount(Long maxSmsCount) {
        this.maxSmsCount = maxSmsCount;
    }

    public Long getMaxSmsCmdCount() {
        return maxSmsCmdCount;
    }

    public void setMaxSmsCmdCount(Long maxSmsCmdCount) {
        this.maxSmsCmdCount = maxSmsCmdCount;
    }

    public Long getStatusId() {
        return statusId;
    }

    public void setStatusId(Long statusId) {
        this.statusId = statusId;
    }

    public ContractStatus getContractStatus() {
        return contractStatus;
    }

    public void setContractStatus(ContractStatus contractStatus) {
        this.contractStatus = contractStatus;
    }

    public Long getBalance() {
        return balance;
    }

    public void setBalance(Long balance) {
        this.balance = balance;
    }

    public Double getBalanceCurr() {
        return Config.convertCurr(balance);
    }

    public void setBalanceCurr(Double balance) {
        this.balance = Config.convertCurr(balance);
    }

    public Timestamp getLastPaymentDate() {
        return lastPaymentDate;
    }

    public void setLastPaymentDate(Timestamp lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    public String getLastPaymentDateFormatted() {
        if (lastPaymentDate == null) return "";
        else {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            return df.format(lastPaymentDate);
        }
    }

    public Long getPaymentsInCurrentPeriod() {
        return paymentsInCurrentPeriod;
    }

    public void setPaymentsInCurrentPeriod(Long paymentsInCurrentPeriod) {
        this.paymentsInCurrentPeriod = paymentsInCurrentPeriod;
    }

    public Long getChargesInCurrentPeriod() {
        return chargesInCurrentPeriod;
    }

    public void setChargesInCurrentPeriod(Long chargesInCurrentPeriod) {
        this.chargesInCurrentPeriod = chargesInCurrentPeriod;
    }

    public Timestamp getBeforeBlockingDate() {
        return beforeBlockingDate;
    }

    public void setBeforeBlockingDate(Timestamp beforeBlockingDate) {
        this.beforeBlockingDate = beforeBlockingDate;
    }

    public Timestamp getLockedDate() {
        return lockedDate;
    }

    public void setLockedDate(Timestamp lockedDate) {
        this.lockedDate = lockedDate;
    }

    public Timestamp getSuspendedSystemDate() {
        return suspendedSystemDate;
    }

    public void setSuspendedSystemDate(Timestamp suspendedSystemDate) {
        this.suspendedSystemDate = suspendedSystemDate;
    }

    public Timestamp getPretensionDate() {
        return pretensionDate;
    }

    public void setPretensionDate(Timestamp pretensionDate) {
        this.pretensionDate = pretensionDate;
    }

    public Timestamp getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Timestamp expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getTaxpayerRegNumber() {
        return taxpayerRegNumber;
    }

    public void setTaxpayerRegNumber(String taxpayerRegNumber) {
        this.taxpayerRegNumber = taxpayerRegNumber;
    }

    @Override
    public String toString() {
        return "Contract{" +
                "id=" + id +
                ", companyId=" + companyId +
                ", company=" + company +
                ", contractNumber='" + contractNumber + '\'' +
                ", contractRegDate=" + contractRegDate +
                ", contractType='" + contractType + '\'' +
                ", existUnitCount=" + existUnitCount +
                ", activeMaxUnitCount=" + activeMaxUnitCount +
                ", activeMaxUserCount=" + activeMaxUserCount +
                ", activeMaxStaffCount=" + activeMaxStaffCount +
                ", activeMaxPoiCount=" + activeMaxPoiCount +
                ", activeMaxGeoFanceCount=" + activeMaxGeoFanceCount +
                ", maxUnitCount=" + maxUnitCount +
                ", maxUserCount=" + maxUserCount +
                ", maxStaffCount=" + maxStaffCount +
                ", maxPoiCount=" + maxPoiCount +
                ", maxGeoFanceCount=" + maxGeoFanceCount +
                ", maxReportCount=" + maxReportCount +
                ", maxEmailCount=" + maxEmailCount +
                ", maxSmsCount=" + maxSmsCount +
                ", maxSmsCmdCount=" + maxSmsCmdCount +
                ", testContract=" + testContract +
                ", customerCompanyName='" + customerCompanyName + '\'' +
                ", customerActsOnTheBasis='" + customerActsOnTheBasis + '\'' +
                ", customerRegion=" + customerRegion +
                ", customerLegalAddress='" + customerLegalAddress + '\'' +
                ", customerPostalAddress='" + customerPostalAddress + '\'' +
                ", customerPhone='" + customerPhone + '\'' +
                ", customerPhoneMobile='" + customerPhoneMobile + '\'' +
                ", customerFax='" + customerFax + '\'' +
                ", customerEmail='" + customerEmail + '\'' +
                ", customerBankName='" + customerBankName + '\'' +
                ", customerBankCode='" + customerBankCode + '\'' +
                ", customerAccount='" + customerAccount + '\'' +
                ", customerAccountTreasury='" + customerAccountTreasury + '\'' +
                ", customerINN='" + customerINN + '\'' +
                ", customerOKONH='" + customerOKONH + '\'' +
                ", customerOKED='" + customerOKED + '\'' +
                ", taxpayerRegNumber='" + taxpayerRegNumber + '\'' +
                ", position='" + position + '\'' +
                ", directorSurname='" + directorSurname + '\'' +
                ", directorName='" + directorName + '\'' +
                ", directorMiddlename='" + directorMiddlename + '\'' +
                ", directorPhone='" + directorPhone + '\'' +
                ", directorEmail='" + directorEmail + '\'' +
                ", note='" + note + '\'' +
                ", customerSurname='" + customerSurname + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerMiddlename='" + customerMiddlename + '\'' +
                ", customerGender=" + customerGender +
                ", customerDocumentType='" + customerDocumentType + '\'' +
                ", customerBirthDate=" + customerBirthDate +
                ", customerCitizenship=" + customerCitizenship +
                ", customerPassportSeries='" + customerPassportSeries + '\'' +
                ", customerPassportNumber='" + customerPassportNumber + '\'' +
                ", customerPassportIssuedBy='" + customerPassportIssuedBy + '\'' +
                ", customerPassportExpireDate=" + customerPassportExpireDate +
                ", customerRegistrationAddress='" + customerRegistrationAddress + '\'' +
                ", statusId=" + statusId +
                ", contractStatus=" + contractStatus +
                ", expiredDate=" + expiredDate +
                ", block='" + block + '\'' +
                ", status='" + status + '\'' +
                ", registrationDate=" + registrationDate +
                ", modificationDate=" + modificationDate +
                ", registrationDateFormatted='" + registrationDateFormatted + '\'' +
                ", balance=" + balance +
                ", paymentsInCurrentPeriod=" + paymentsInCurrentPeriod +
                ", chargesInCurrentPeriod=" + chargesInCurrentPeriod +
                ", lastPaymentDate=" + lastPaymentDate +
                ", beforeBlockingDate=" + beforeBlockingDate +
                ", lockedDate=" + lockedDate +
                ", suspendedSystemDate=" + suspendedSystemDate +
                ", pretensionDate=" + pretensionDate +
                ", expiryDate=" + expiryDate +
                '}';
    }
}
