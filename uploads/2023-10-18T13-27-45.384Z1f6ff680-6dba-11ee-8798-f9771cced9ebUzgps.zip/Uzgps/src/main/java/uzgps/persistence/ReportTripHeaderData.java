package uzgps.persistence;

import org.hibernate.annotations.Immutable;
import uzgps.excel.tripReports.AbstractTripItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
@Immutable
public class ReportTripHeaderData extends AbstractTripItem implements Serializable {

    //    public static final String sequenceName = "SEQ_REPORT_TRACK_STATISTICS_ID";
//
    @Id
    private Long id;

    @Column(name = "route_id")
    private Integer routeId;

    @Column(name = "count")
    private Integer tripsCount;

    ///////////////////////////////////////////////////////////////////////////

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getRouteId() {
        return routeId;
    }

    public void setRouteId(Integer routeId) {
        this.routeId = routeId;
    }

    public Integer getTripsCount() {
        return tripsCount;
    }

    public void setTripsCount(Integer tripsCount) {
        this.tripsCount = tripsCount;
    }

    @Override
    public String toString() {
        return "ReportTrip{" +
                "id=" + id +
                ", route_id=" + routeId +
                ", tripsCount='" + tripsCount + '\'' +
                '}';
    }
}
