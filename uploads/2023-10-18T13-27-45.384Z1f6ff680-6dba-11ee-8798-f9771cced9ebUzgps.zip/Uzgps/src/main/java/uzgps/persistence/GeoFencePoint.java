package uzgps.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;

/**
 * Created by Gayratjon on 3/31/14.
 */

@Entity
@Table(name = "uzgps_geo_fence_point")
public class GeoFencePoint {
    public static final String sequenceName = "SEQ_UZGPS_GEO_FENCE_POINT_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "longitude", nullable = false)
    private Double longitude;

    @Column(name = "latitude", nullable = false)
    private Double latitude;

    @Column(name = "geo_fence_id", nullable = true, insertable = false, updatable = false)
    private Long geoFenceId;
    @ManyToOne
    @JoinColumn(name = "geo_fence_id")
    private GeoFence geoFence;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Long getGeoFenceId() {
        return geoFenceId;
    }

    public void setGeoFenceId(Long geoFenceId) {
        this.geoFenceId = geoFenceId;
    }

    public GeoFence getGeoFence() {
        return geoFence;
    }

    public void setGeoFence(GeoFence geoFence) {
        this.geoFence = geoFence;
    }
}
