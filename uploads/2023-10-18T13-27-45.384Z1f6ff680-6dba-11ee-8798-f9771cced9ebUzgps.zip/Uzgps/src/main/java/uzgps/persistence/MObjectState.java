package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_mobject_state")
public class MObjectState implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_STATE_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "name_en")
    private String nameEn;
    @Column(name = "name_ru")
    private String nameRu;
    @Column(name = "name_uz_cyr")
    private String nameUzCyr;
    @Column(name = "name_uz_lat")
    private String nameUzLat;

    @Column(name = "_status", length = 1)
    private String status;

    @Column(name = "_reg_date")
    private Timestamp regDate;

    @Column(name = "_mod_date")
    private Timestamp modDate;

    @Column(name = "_exp_date")
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public String getNameRu() {
        return nameRu;
    }

    public void setNameRu(String nameRu) {
        this.nameRu = nameRu;
    }

    public String getNameUzCyr() {
        return nameUzCyr;
    }

    public void setNameUzCyr(String nameUzCyr) {
        this.nameUzCyr = nameUzCyr;
    }

    public String getNameUzLat() {
        return nameUzLat;
    }

    public void setNameUzLat(String nameUzLat) {
        this.nameUzLat = nameUzLat;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "MObjectState{" +
                "id=" + id +
                ", nameEn='" + nameEn + '\'' +
                ", NameRu='" + nameRu + '\'' +
                ", nameUzCyr='" + nameUzCyr + '\'' +
                ", nameUzLat='" + nameUzLat + '\'' +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}