package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "billing_catalog_subdivision")
public class CatalogSubdivision implements Serializable {

    public static final String sequenceName = "seq_billing_catalog_subdivision";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @Column(name = "description")
    private String description;

    @JoinColumn(name = "catalog_company_id")
    @ManyToOne
    private CatalogCompany catalogCompany;

    @Column(name = "catalog_company_id", insertable = false, updatable = false)
    private Long catalogCompanyId;

    @Column(name = "_status", nullable = false, length = 1)
    private String status;

    @Column(name = "_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "_exp_date", nullable = true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CatalogCompany getCatalogCompany() {
        return catalogCompany;
    }

    public void setCatalogCompany(CatalogCompany catalogCompany) {
        this.catalogCompany = catalogCompany;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Long getCatalogCompanyId() {
        return catalogCompanyId;
    }

    public void setCatalogCompanyId(Long catalogCompanyId) {
        this.catalogCompanyId = catalogCompanyId;
    }

    @Override
    public String toString() {
        return "CatalogSubdivision{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", catalogCompany=" + catalogCompany +
                '}';
    }
}
