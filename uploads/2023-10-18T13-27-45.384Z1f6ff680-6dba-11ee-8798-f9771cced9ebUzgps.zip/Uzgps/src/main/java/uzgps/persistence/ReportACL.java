package uzgps.persistence;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_report_access_list")

public class ReportACL implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_REPORT_ACCESS_LIST_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "contract_id", nullable = false, insertable = false, updatable = false)
    private Long contractId;
    @ManyToOne
    @JoinColumn(name = "contract_id")
    private Contract contract;

    @Basic
    @Column(name = "report_id", nullable = false, insertable = false, updatable = false)
    private Long reportId;
    @ManyToOne
    @JoinColumn(name = "report_id")
    private Report report;

    @Column(name = "access", nullable = false)
    private Integer access;

    @Column(name = "status", nullable = false, length = 1)
    private String status;

    @Column(name = "reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "exp_date", nullable = true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Long getReportId() {
        return reportId;
    }

    public void setReportId(Long reportId) {
        this.reportId = reportId;
    }

    public Integer getAccess() {
        return access;
    }

    public void setAccess(Integer access) {
        this.access = access;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    @Override
    public String toString() {
        return "id=" + this.id +  " contractId= " + this.contractId + " reportId= " + this.reportId + " access= " + this.access;
    }
}
