package uzgps.persistence;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_mobject_geo_fence")

public class MObjectGeoFence implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_GEO_FENCE_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "mobject_id", nullable = false)
    private Long mObjectId;

    @Column(name = "geo_fence_id", nullable = false, insertable = false, updatable = false)
    private Long geoFenceId;
    @ManyToOne
    @JoinColumn(name = "geo_fence_id")
    private GeoFence geoFence;

    @Column(name = "control_type", nullable = false)
    private Integer controlType;

    @Column(name = "mgf_status", nullable = false, length = 1)
    private String status;

    @Column(name = "mgf_reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "mgf_mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "mgf_exp_date", nullable=true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public Long getGeoFenceId() {
        return geoFenceId;
    }

    public void setGeoFenceId(Long geoFenceId) {
        this.geoFenceId = geoFenceId;
    }

    public GeoFence getGeoFence() {
        return geoFence;
    }

    public void setGeoFence(GeoFence geoFence) {
        this.geoFence = geoFence;
    }

    public Integer getControlType() {
        return controlType;
    }

    public void setControlType(Integer controlType) {
        this.controlType = controlType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }
}
