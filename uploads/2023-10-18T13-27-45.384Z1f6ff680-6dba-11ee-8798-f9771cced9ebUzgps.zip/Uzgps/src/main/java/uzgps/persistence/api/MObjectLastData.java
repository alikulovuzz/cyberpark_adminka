package uzgps.persistence.api;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "mobject_last_data")
public class MObjectLastData implements Serializable {

    public static final String sequenceName = "seq_mobject_last_data";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "contract_id")
    private Long contractId;

    @Basic
    @Column(name = "mobject_id")
    private Long mobjectId;

    @Basic
    @Column(name = "mobject_name")
    private String mobjectName;

    @Basic
    @Column(name = "plate_number")
    private String plateNumber;

    @Column(name = "imei")
    private String imei;

    @Column(name = "tp_timestamp")
    private Timestamp tpTimestamp;
    @Transient
    private String tpTimestampFmt;

    @Column(name = "last_track_sec")
    private Integer lastTrackSec;

    @Column(name = "lat")
    private Double lat;

    @Column(name = "lon")
    private Double lon;

    @Column(name = "alt")
    private Double alt;

    @Column(name = "tp_speed")
    private Integer speed;

    @Column(name = "tp_angle")
    private Integer angle;

    @Column(name = "tp_movement")
    private Integer movement;

    @Column(name = "tp_engine_on")
    private Integer engineOn;

    @Column(name = "tp_satellites")
    private Integer satellites;

    @Column(name = "group_id")
    private Long groupId;

    @Column(name = "group_name")
    private String groupName;

    @Column(name = "brand_name")
    private String brandName;

//    @Column(name = "reg_date")
//    private Timestamp regDate;
//    @Transient
//    private String regDateFmt;
//
//    @Column(name = "mod_date")
//    private Timestamp modDate;
//
//    @Transient
//    private String modDateFmt;

//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Timestamp getTpTimestamp() {
        return tpTimestamp;
    }

    public void setTpTimestamp(Timestamp tpTimestamp) {
        this.tpTimestamp = tpTimestamp;
    }

    public Integer getLastTrackSec() {
        return lastTrackSec;
    }

    public void setLastTrackSec(Integer lastTrackSec) {
        this.lastTrackSec = lastTrackSec;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    public Double getAlt() {
        return alt;
    }

    public void setAlt(Double alt) {
        this.alt = alt;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Integer getAngle() {
        return angle;
    }

    public void setAngle(Integer angle) {
        this.angle = angle;
    }

    public Integer getMovement() {
        return movement;
    }

    public void setMovement(Integer movement) {
        this.movement = movement;
    }

    public Integer getEngineOn() {
        return engineOn;
    }

    public void setEngineOn(Integer engineOn) {
        this.engineOn = engineOn;
    }

    public Integer getSatellites() {
        return satellites;
    }

    public void setSatellites(Integer satellites) {
        this.satellites = satellites;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    //    public Timestamp getRegDate() {
//        return regDate;
//    }
//
//    public void setRegDate(Timestamp regDate) {
//        this.regDate = regDate;
//        setRegDateFmt(this.regDate);
//    }
//
//    public void setRegDateFmt(Timestamp regDate) {
//        this.regDateFmt = regDate.toLocalDateTime().toString();
//    }
//
//    public String getRegDateFmt() {
//        return regDateFmt;
//    }
//
//
//    public void setModDateFmt(Timestamp modDate) {
//        this.modDateFmt = modDate.toLocalDateTime().toString();
//    }
//
//    public String getModDateFmt() {
//        return modDateFmt;
//    }
//
//    public Timestamp getModDate() {
//        return modDate;
//    }
//
//    public void setModDate(Timestamp modDate) {
//        this.modDate = modDate;
//    }


    public String getTpTimestampFmt() {
        return tpTimestampFmt;
    }

    public void setTpTimestampFmt(Timestamp tpTimestamp) {
        this.tpTimestampFmt = tpTimestamp.toLocalDateTime().toString();
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    @Override
    public String toString() {
        return "MObjectLastData{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", mobjectId=" + mobjectId +
                ", mobjectName='" + mobjectName + '\'' +
                ", imei='" + imei + '\'' +
                ", tpTimestamp=" + tpTimestamp +
                ", lastTrackSec=" + lastTrackSec +
                ", lat=" + lat +
                ", lon=" + lon +
                ", alt=" + alt +
                ", speed=" + speed +
                ", angle=" + angle +
                ", movement=" + movement +
                ", engineOn=" + engineOn +
                ", satellites=" + satellites +
                ", groupId=" + groupId +
                ", groupName=" + groupName +
//                ", regDate=" + regDate +
//                ", modDate=" + modDate +
                '}';
    }
}
