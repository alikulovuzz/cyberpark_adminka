package uzgps.persistence;

import org.hibernate.annotations.Immutable;
import uzgps.excel.tripReports.AbstractTripItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Immutable
@Table(schema = "reporting")
public class ReportObjectMovement extends AbstractTripItem implements Serializable {

    @Id
    private Long id;

    @Column(name = "contract_id")
    private Long contractId;

    @Column(name = "trip_id")
    private Long tripId;

    @Column(name = "trip_description")
    private String tripDescription;

    @Column(name = "trip_name")
    private String tripName;

    @Column(name = "trip_type")
    private Integer tripType;

    @Column(name = "trip_status")
    private Integer tripStatus;

    @Column(name = "trip_direction")
    private String tripDirection;

    @Column(name = "station_priority")
    private Integer stationPriority;

    @Column(name = "station_name")
    private String stationName;

    @Column(name = "station_id")
    private Long stationId;

    @Column(name = "sts_distance")
    private Double stationDistance;

    @Column(name = "mobject_name")
    private String mobjectName;

    @Column(name = "mobject_id")
    private Long mobjectId;

    @Column(name = "station_enter_planned")
    private Timestamp stationEnterPlanned;

    @Column(name = "station_enter_real")
    private Timestamp stationEnterReal;

    @Column(name = "station_enter_deviation")
    private Timestamp stationEnterDeviation;

    @Column(name = "station_parking_planned")
    private Timestamp stationParkingPlanned;

    @Column(name = "station_parking_real")
    private Timestamp stationParkingReal;

    @Column(name = "station_parking_deviation")
    private Timestamp stationParkingDeviation;

    @Column(name = "station_exit_planned")
    private Timestamp stationExitPlanned;

    @Column(name = "station_exit_real")
    private Timestamp stationExitReal;

    @Column(name = "station_exit_deviation")
    private Timestamp stationExitDeviation;

    @Column(name = "station_time_travel")
    private Long stationTimeTravel;

    @Column(name = "station_travel_planned")
    private Timestamp stationTravelPlanned;

    @Column(name = "station_travel_real")
    private Timestamp stationTravelReal;

    @Column(name = "station_travel_deviation")
    private Timestamp stationTravelDeviation;

    @Column(name = "station_deviation_norm")
    private Timestamp stationDeviationNorm;

    @Column(name = "station_trip_distance")
    private Double stationTripDistance;

    @Column(name = "event_route_exit_count")
    private Integer eventRouteExitCount;

    @Column(name = "event_route_return_count")
    private Integer eventRouteReturnCount;

    @Column(name = "event_station_enter_early")
    private Timestamp eventStationEnterEarly;

    @Column(name = "event_station_enter_late")
    private Timestamp eventStationEnterLate;

    @Column(name = "event_station_exit_early")
    private Timestamp eventStationExitEarly;

    @Column(name = "event_station_exit_late")
    private Timestamp eventStationExitLate;

    @Column(name = "event_station_skipped")
    private Boolean eventStationSkipped;

    @Column(name = "event_in_station_parking_more")
    private Long eventInStationParkingMore;

    @Column(name = "event_out_station_parking_more")
    private Timestamp eventOutStationParkingMore;

    @Column(name = "event_station_stopped")
    private Boolean eventStationStopped;

    @Column(name = "event_overspeed_count")
    private Integer eventOverspeedCount;

    @Column(name = "event_overspeed_max_speed")
    private Integer eventOverspeedMaxSpeed;

    ///////////////////////////////////////////////////////////////////////////

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    @Override
    public Long getTripId() {
        return tripId;
    }

    @Override
    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getTripDescription() {
        return tripDescription;
    }

    public void setTripDescription(String tripDescription) {
        this.tripDescription = tripDescription;
    }

    @Override
    public String getTripName() {
        return tripName;
    }

    @Override
    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public String getTripDirection() {
        return tripDirection;
    }

    public void setTripDirection(String tripDirection) {
        this.tripDirection = tripDirection;
    }

    public Long getStationId() {
        return stationId;
    }

    public void setStationId(Long stationId) {
        this.stationId = stationId;
    }

    public Double getStationDistance() {
        return stationDistance;
    }

    public void setStationDistance(Double stationDistance) {
        this.stationDistance = stationDistance;
    }

    public Timestamp getStationEnterPlanned() {
        return stationEnterPlanned;
    }

    public void setStationEnterPlanned(Timestamp stationEnterPlanned) {
        this.stationEnterPlanned = stationEnterPlanned;
    }

    public Timestamp getStationEnterReal() {
        return stationEnterReal;
    }

    public void setStationEnterReal(Timestamp stationEnterReal) {
        this.stationEnterReal = stationEnterReal;
    }

    public Timestamp getStationEnterDeviation() {
        return stationEnterDeviation;
    }

    public void setStationEnterDeviation(Timestamp stationEnterDeviation) {
        this.stationEnterDeviation = stationEnterDeviation;
    }

    public Timestamp getStationParkingPlanned() {
        return stationParkingPlanned;
    }

    public void setStationParkingPlanned(Timestamp stationParkingPlanned) {
        this.stationParkingPlanned = stationParkingPlanned;
    }

    public Timestamp getStationParkingReal() {
        return stationParkingReal;
    }

    public void setStationParkingReal(Timestamp stationParkingReal) {
        this.stationParkingReal = stationParkingReal;
    }

    public Timestamp getStationParkingDeviation() {
        return stationParkingDeviation;
    }

    public void setStationParkingDeviation(Timestamp stationParkingDeviation) {
        this.stationParkingDeviation = stationParkingDeviation;
    }

    public Timestamp getStationExitPlanned() {
        return stationExitPlanned;
    }

    public void setStationExitPlanned(Timestamp stationExitPlanned) {
        this.stationExitPlanned = stationExitPlanned;
    }

    public Timestamp getStationExitReal() {
        return stationExitReal;
    }

    public void setStationExitReal(Timestamp stationExitReal) {
        this.stationExitReal = stationExitReal;
    }

    public Timestamp getStationExitDeviation() {
        return stationExitDeviation;
    }

    public void setStationExitDeviation(Timestamp stationExitDeviation) {
        this.stationExitDeviation = stationExitDeviation;
    }

    public Timestamp getStationTravelPlanned() {
        return stationTravelPlanned;
    }

    public void setStationTravelPlanned(Timestamp stationTravelPlanned) {
        this.stationTravelPlanned = stationTravelPlanned;
    }

    public Timestamp getStationTravelReal() {
        return stationTravelReal;
    }

    public void setStationTravelReal(Timestamp stationTravelReal) {
        this.stationTravelReal = stationTravelReal;
    }

    public Timestamp getStationTravelDeviation() {
        return stationTravelDeviation;
    }

    public void setStationTravelDeviation(Timestamp stationTravelDeviation) {
        this.stationTravelDeviation = stationTravelDeviation;
    }

    public Timestamp getStationDeviationNorm() {
        return stationDeviationNorm;
    }

    public void setStationDeviationNorm(Timestamp stationDeviationNorm) {
        this.stationDeviationNorm = stationDeviationNorm;
    }

    public Timestamp getEventStationEnterEarly() {
        return eventStationEnterEarly;
    }

    public void setEventStationEnterEarly(Timestamp eventStationEnterEarly) {
        this.eventStationEnterEarly = eventStationEnterEarly;
    }

    public Timestamp getEventStationEnterLate() {
        return eventStationEnterLate;
    }

    public void setEventStationEnterLate(Timestamp eventStationEnterLate) {
        this.eventStationEnterLate = eventStationEnterLate;
    }

    public Timestamp getEventStationExitEarly() {
        return eventStationExitEarly;
    }

    public void setEventStationExitEarly(Timestamp eventStationExitEarly) {
        this.eventStationExitEarly = eventStationExitEarly;
    }

    public Timestamp getEventStationExitLate() {
        return eventStationExitLate;
    }

    public void setEventStationExitLate(Timestamp eventStationExitLate) {
        this.eventStationExitLate = eventStationExitLate;
    }

    public Boolean getEventStationSkipped() {
        return eventStationSkipped;
    }

    public void setEventStationSkipped(Boolean eventStationSkipped) {
        this.eventStationSkipped = eventStationSkipped;
    }

    public Timestamp getEventOutStationParkingMore() {
        return eventOutStationParkingMore;
    }

    public void setEventOutStationParkingMore(Timestamp eventOutStationParkingMore) {
        this.eventOutStationParkingMore = eventOutStationParkingMore;
    }

    public Boolean getEventStationStopped() {
        return eventStationStopped;
    }

    public void setEventStationStopped(Boolean eventStationStopped) {
        this.eventStationStopped = eventStationStopped;
    }

    public Integer getEventOverspeedCount() {
        return eventOverspeedCount;
    }

    public void setEventOverspeedCount(Integer eventOverspeedCount) {
        this.eventOverspeedCount = eventOverspeedCount;
    }

    public Integer getEventOverspeedMaxSpeed() {
        return eventOverspeedMaxSpeed;
    }

    public void setEventOverspeedMaxSpeed(Integer eventOverspeedMaxSpeed) {
        this.eventOverspeedMaxSpeed = eventOverspeedMaxSpeed;
    }

    public Integer getStationPriority() {
        return stationPriority;
    }

    public void setStationPriority(Integer stationPriority) {
        this.stationPriority = stationPriority;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public Double getStationTripDistance() {
        return stationTripDistance;
    }

    public void setStationTripDistance(Double stationTripDistance) {
        this.stationTripDistance = stationTripDistance;
    }

    public Integer getEventRouteExitCount() {
        return eventRouteExitCount;
    }

    public void setEventRouteExitCount(Integer eventRouteExitCount) {
        this.eventRouteExitCount = eventRouteExitCount;
    }

    public Integer getEventRouteReturnCount() {
        return eventRouteReturnCount;
    }

    public void setEventRouteReturnCount(Integer eventRouteReturnCount) {
        this.eventRouteReturnCount = eventRouteReturnCount;
    }

    public Long getEventInStationParkingMore() {
        return eventInStationParkingMore;
    }

    public void setEventInStationParkingMore(Long eventStationInParkingMore) {
        this.eventInStationParkingMore = eventStationInParkingMore;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }

    public Long getStationTimeTravel() {
        return stationTimeTravel;
    }

    public void setStationTimeTravel(Long stationTimeTravel) {
        this.stationTimeTravel = stationTimeTravel;
    }

    public Integer getTripStatus() {
        return tripStatus;
    }

    public void setTripStatus(Integer tripStatus) {
        this.tripStatus = tripStatus;
    }

    @Override
    public String toString() {
        return "ReportObjectMovement{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", tripId=" + tripId +
                ", tripDescription='" + tripDescription + '\'' +
                ", tripName='" + tripName + '\'' +
                ", tripType=" + tripType +
                ", tripStatus=" + tripStatus +
                ", tripDirection='" + tripDirection + '\'' +
                ", stationPriority='" + stationPriority + '\'' +
                ", stationName='" + stationName + '\'' +
                ", stationId=" + stationId +
                ", stationDistance=" + stationDistance +
                ", mobjectName='" + mobjectName + '\'' +
                ", mobjectId='" + mobjectId + '\'' +
                ", stationEnterPlanned=" + stationEnterPlanned +
                ", stationEnterReal=" + stationEnterReal +
                ", stationEnterDeviation=" + stationEnterDeviation +
                ", stationParkingPlanned=" + stationParkingPlanned +
                ", stationParkingReal=" + stationParkingReal +
                ", stationParkingDeviation=" + stationParkingDeviation +
                ", stationExitPlanned=" + stationExitPlanned +
                ", stationExitReal=" + stationExitReal +
                ", stationExitDeviation=" + stationExitDeviation +
                ", stationTravelPlanned=" + stationTravelPlanned +
                ", stationTravelReal=" + stationTravelReal +
                ", stationTravelDeviation=" + stationTravelDeviation +
                ", stationDeviationNorm=" + stationDeviationNorm +
                ", distance=" + stationTripDistance +
                ", eventRouteExitCount=" + eventRouteExitCount +
                ", eventRouteReturnCount=" + eventRouteReturnCount +
                ", eventStationEnterEarly=" + eventStationEnterEarly +
                ", eventStationEnterLate=" + eventStationEnterLate +
                ", eventStationExitEarly=" + eventStationExitEarly +
                ", eventStationExitLate=" + eventStationExitLate +
                ", eventStationSkipped=" + eventStationSkipped +
                ", eventStationInParkingMore=" + eventInStationParkingMore +
                ", eventStationOutParkingMore=" + eventOutStationParkingMore +
                ", eventStationStopped=" + eventStationStopped +
                ", eventOverspeedCount=" + eventOverspeedCount +
                ", eventOverspeedMaxSpeed=" + eventOverspeedMaxSpeed +
                ", stationTimeTravel=" + stationTimeTravel +
                '}';
    }
}
