package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_monitored_zoi")
public class MonitoredZoi implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MONITORED_ZOI_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "contract_id", nullable = false, insertable = false, updatable = false)
    private Long contractId;
    @ManyToOne
    @JoinColumn(name = "contract_id")
    private Contract contract;

    @Column(name = "zoi_id", nullable = false, insertable = false, updatable = false)
    private Long zoiId;
    @ManyToOne
    @JoinColumn(name = "zoi_id")
    private GeoFence zoi;

    @Column(name = "status", length = 1)
    private String status;

    @Column(name = "reg_date")
    private Timestamp regDate;

    @Column(name = "mod_date")
    private Timestamp modDate;

    @Column(name = "exp_date")
    private Timestamp expDate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Long getZoiId() {
        return zoiId;
    }

    public void setZoiId(Long zoiId) {
        this.zoiId = zoiId;
    }

    public GeoFence getZoi() {
        return zoi;
    }

    public void setZoi(GeoFence zoi) {
        this.zoi = zoi;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "MonitoredZoi{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", contract=" + contract +
                ", zoiId=" + zoiId +
                ", zoi=" + zoi +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
