package uzgps.persistence;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_mobject_poi")

public class MObjectPoI implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_POI_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "mobject_id", nullable = false)
    private Long mObjectId;

    @Column(name = "poi_id", nullable = false, insertable = false, updatable = false)
    private Long poiId;
    @ManyToOne
    @JoinColumn(name = "poi_id")
    private POI poi;

    @Column(name = "control_type", nullable = false)
    private Integer controlType;

    @Column(name = "mp_status", nullable = false, length = 1)
    private String status;

    @Column(name = "mp_reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "mp_mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "mp_exp_date", nullable=true)
    private Timestamp expDate;

    public Long getId() {

        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public Long getPoiId() {
        return poiId;
    }

    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }

    public POI getPoi() {
        return poi;
    }

    public void setPoi(POI poi) {
        this.poi = poi;
    }

    public Integer getControlType() {
        return controlType;
    }

    public void setControlType(Integer controlType) {
        this.controlType = controlType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }
}
