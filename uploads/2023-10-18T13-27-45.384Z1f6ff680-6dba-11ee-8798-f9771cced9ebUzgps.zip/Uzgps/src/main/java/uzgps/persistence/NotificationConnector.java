package uzgps.persistence;

import javax.persistence.*;


@Entity
@Table(schema = "reporting")
public class NotificationConnector {

    @Id private Long id;

    private Long cId;

    private String cName;

    private Long cObj2Id;

    private Integer cType;

    public Long getcId() {
        return cId;
    }

    public void setcId(Long cId) {
        this.cId = cId;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public Long getcObj2Id() {
        return cObj2Id;
    }

    public void setcObj2Id(Long cObj2Id) {
        this.cObj2Id = cObj2Id;
    }

    public Integer getcType() {
        return cType;
    }

    public void setcType(Integer cType) {
        this.cType = cType;
    }

}
