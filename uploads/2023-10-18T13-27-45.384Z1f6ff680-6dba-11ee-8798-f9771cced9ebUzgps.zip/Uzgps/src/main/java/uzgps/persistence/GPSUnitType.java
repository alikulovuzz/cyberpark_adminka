package uzgps.persistence;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "uzgps_gps_unit_type")

public class GPSUnitType implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_GPS_UNIT_TYPE_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    @Column(name = "id_gps_unit_type", nullable = false)
    private Long id;

    @Basic
    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @Column(name = "status", nullable = false, length = 1)
    private String status;

    @Column(name = "reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "exp_date", nullable = true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "GPSUnitType{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
