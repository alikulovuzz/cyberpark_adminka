package uzgps.persistence;

import io.vertx.core.json.JsonObject;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "uzgps_tg_bot_user")
public class TgUser  implements Serializable  {

    public static final String sequenceName = "SEQ_UZGPS_TG_BOT_USER_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "lang")
    private String language;

    @Column(name = "phone_num")
    private String phoneNumber;

    @Column(name = "tg_user_id")
    private long userId;

    @Column(name = "chat_id")
    private long chatId;

    @Column(name = "user_token")
    private String userToken;

    @Column(name = "state")
    private int state;

    @Column(name = "status", length = 1)
    private String status;

    @Column(name = "reg_date")
    private Timestamp regDate;

    @Column(name = "mod_date")
    private Timestamp modDate;

    @Column(name = "exp_date")
    private Timestamp expDate;

    public TgUser(String firstName, String lastName, String language,long userId, long chatId,int state, String status) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.language = language;
        this.phoneNumber = phoneNumber;
        this.userId = userId;
        this.chatId = chatId;
        this.userToken = userToken;
        this.state = state;
        this.status = status;
    }

    public TgUser(String firstName, String lastName, String language, long userId, long chatId, int state) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.language = language;
        this.userId = userId;
        this.chatId = chatId;
        this.state = state;
        this.regDate = new Timestamp(System.currentTimeMillis());
        this.status = "A";
    }

    public TgUser() {
        this.regDate = new Timestamp(System.currentTimeMillis());
        this.status = "A";
    }

    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getChatId() {
        return chatId;
    }

    public void setChatId(long chatId) {
        this.chatId = chatId;
    }

    public String getUserToken() {
        return userToken;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public String toJsonObject(){
        JsonObject jsonObject = new JsonObject();
        jsonObject.put("firstName",firstName);
        jsonObject.put("lastName",lastName);
        jsonObject.put("language",language);
        jsonObject.put("phoneNumber",phoneNumber);
        jsonObject.put("userId",userId);
        jsonObject.put("chatId",chatId);
        jsonObject.put("userToken",userToken);
        jsonObject.put("state",state);
        jsonObject.put("status",status);
        return jsonObject.toString();
    }

    @Override
    public String toString() {
        return "TgUser{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", language='" + language + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", userId=" + userId +
                ", chatId=" + chatId +
                ", userToken='" + userToken + '\'' +
                ", state=" + state +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
