package uzgps.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Type;
import uzgps.common.FileStorageService;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * Created by Gayratjon on 2/4/14.
 */

@Entity
@Table(name = "uzgps_poi")
public class POI implements Comparable<POI> {

    public static final String sequenceName = "SEQ_UZGPS_POI_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "contract_id", nullable = true)
    private Long contractId;

    @Column(name = "status", nullable = false, length = 1)
    private String status;

    @Column(name = "name", nullable = false, length = 256)
    private String name;

    @Column(name = "group_id", nullable = false, insertable = false, updatable = false)
    private Long groupId;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "group_id")
    private PoiGroup group;

    @Column(name = "font_color", nullable = false, length = 8)
    private String fontColor;

    @Column(name = "font_size", nullable = false)
    private Integer fontSize;

    @JsonIgnore
    @Column(name = "image_id", nullable = true, insertable = false, updatable = false)
    private Long imageId;
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "image_id")
    private FileStorage image;

    @Lob
    @Type(type = "org.hibernate.type.StringClobType")
    @Column(name = "description", nullable = true)
    private String description;

    @Column(name = "longitude", nullable = false)
    private Double longitude;

    @Column(name = "latitude", nullable = false)
    private Double latitude;

    @Column(name = "radius", nullable = true)
    private Float radius;

    @Column(name = "is_circle_displayed", nullable = true)
    private Boolean isCircleDisplayed;

    @Column(name = "circle_color", nullable = true, length = 8)
    private String circleColor;

    @Column(name = "circle_opacity", nullable = true)
    private Float circleOpacity;

    @Column(name = "poi_reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "poi_mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "poi_exp_date", nullable=true)
    private Timestamp expDate;

    @Transient
    private String url;

    @Transient
    private Long tempId;

    @Transient
    private Byte userPermission;

    public Long getId() {
        return id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public PoiGroup getGroup() {
        return group;
    }

    public void setGroup(PoiGroup group) {
        this.group = group;
    }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public void setFontSize(Integer fontSize) {
        this.fontSize = fontSize;
    }

    public Long getImageId() {
        return imageId;
    }

    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }

    public FileStorage getImage() {
        return image;
    }

    public void setImage(FileStorage image) {
        this.image = image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Float getRadius() {
        return radius;
    }

    public void setRadius(Float radius) {
        this.radius = radius;
    }

    public Boolean getIsCircleDisplayed() {
        return isCircleDisplayed;
    }

    public void setIsCircleDisplayed(Boolean isCircleDisplayed) {
        this.isCircleDisplayed = (isCircleDisplayed == null) ? false : true;
    }

    public String getCircleColor() {
        return circleColor;
    }

    public void setCircleColor(String circleColor) {
        this.circleColor = circleColor;
    }

    public Boolean getCircleDisplayed() {
        return isCircleDisplayed;
    }

    public void setCircleDisplayed(Boolean circleDisplayed) {
        isCircleDisplayed = circleDisplayed;
    }

    public Float getCircleOpacity() {
        return circleOpacity;
    }

    public void setCircleOpacity(Float circleOpacity) {
        this.circleOpacity = circleOpacity;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public String getUrl() {
        return (image != null) ? FileStorageService.generateFileName(image.getId(), image.getFilename()) : null;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Long getTempId() {
        return tempId;
    }

    public void setTempId(Long tempId) {
        this.tempId = tempId;
    }

    public Byte getUserPermission() {
        return userPermission;
    }

    public void setUserPermission(Byte userPermission) {
        this.userPermission = userPermission;
    }

    @Override
    public String toString() {
        return "POI{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", fontColor='" + fontColor + '\'' +
                ", fontSize=" + fontSize +
                ", imageId=" + imageId +
                ", groupId=" + groupId +
                ", description='" + description + '\'' +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                ", radius=" + radius +
                ", isCircleDisplayed=" + isCircleDisplayed +
                ", circleColor='" + circleColor + '\'' +
                ", circleOpacity='" + circleOpacity + '\'' +
                ", userPermission='" + userPermission + '\'' +
                '}';
    }

    @Override
    public int compareTo(POI p) {
        return this.name.compareToIgnoreCase(p.getName());
    }
}
