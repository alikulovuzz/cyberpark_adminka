package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by Gayratjon on 1/7/2015.
 */

@Entity
@Table(name = "uzgps_mtracker_status")
public class MobileTrackerStatus implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MTRACKER_STATUS_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "st_index", nullable = false)
    private Integer index;

    @Column(name = "st_name", nullable = true)
    private String name;

    @Column(name = "st_color", nullable = true)
    private String color;

    @Column(name = "mobile_serial", nullable = false, length = 200)
    private String mobileSerial;

    @Column(name = "status", nullable = false, length = 1)
    private String status;

    @Column(name = "reg_date", nullable = true)
    private Timestamp regDate;

    @Column(name = "mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "exp_date", nullable = true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMobileSerial() {
        return mobileSerial;
    }

    public void setMobileSerial(String mobileSerial) {
        this.mobileSerial = mobileSerial;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "MobileTrackerStatus{" +
                "mobileSerial='" + mobileSerial + '\'' +
                ", color='" + color + '\'' +
                ", name='" + name + '\'' +
                ", index=" + index +
                '}';
    }
}
