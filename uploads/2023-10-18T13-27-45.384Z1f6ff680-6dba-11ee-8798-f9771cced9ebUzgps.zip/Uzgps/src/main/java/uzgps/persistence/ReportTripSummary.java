package uzgps.persistence;

import org.hibernate.annotations.Immutable;
import uzgps.excel.tripReports.AbstractTripItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Immutable
@Table(schema = "reporting")
public class ReportTripSummary extends AbstractTripItem implements Serializable {

    @Id
    private Long id;

    @Column(name = "contract_id")
    private Long contractId;

    @Column(name = "trip_name")
    private String tripName;

    @Column(name = "count_trips")
    private Integer countTrips;

    @Column(name = "trip_100")
    private Integer trip_100;

    @Column(name = "trip_200")
    private Integer trip_200;

    @Column(name = "trip_300")
    private Integer trip_300;

    @Column(name = "plan_count_mobjects")
    private Integer planCountMobjects;

    @Column(name = "real_count_mobjects")
    private Integer factCountMobjects;

    @Column(name = "deviation_count_mobjects")
    private Integer diffCountMobjects;

    ///////////////////////////////////////////////////////////////////////////

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    @Override
    public String getTripName() {
        return tripName;
    }

    @Override
    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public Integer getCountTrips() {
        return countTrips;
    }

    public void setCountTrips(Integer countTrips) {
        this.countTrips = countTrips;
    }

    public Integer getTrip_100() {
        return trip_100;
    }

    public void setTrip_100(Integer trip_100) {
        this.trip_100 = trip_100;
    }

    public Integer getTrip_200() {
        return trip_200;
    }

    public void setTrip_200(Integer trip_200) {
        this.trip_200 = trip_200;
    }

    public Integer getTrip_300() {
        return trip_300;
    }

    public void setTrip_300(Integer trip_300) {
        this.trip_300 = trip_300;
    }

    public Integer getPlanCountMobjects() {
        return planCountMobjects;
    }

    public void setPlanCountMobjects(Integer planCountMobjects) {
        this.planCountMobjects = planCountMobjects;
    }

    public Integer getFactCountMobjects() {
        return factCountMobjects;
    }

    public void setFactCountMobjects(Integer factCountMobjects) {
        this.factCountMobjects = factCountMobjects;
    }

    public Integer getDiffCountMobjects() {
        return diffCountMobjects;
    }

    public void setDiffCountMobjects(Integer diffCountMobjects) {
        this.diffCountMobjects = diffCountMobjects;
    }

    @Override
    public String toString() {
        return "ReportTripSummary{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", tripName='" + tripName + '\'' +
                ", countTrips=" + countTrips +
                ", trip_100=" + trip_100 +
                ", trip_200=" + trip_200 +
                ", trip_300=" + trip_300 +
                ", planCountMobjects=" + planCountMobjects +
                ", factCountMobjects=" + factCountMobjects +
                ", diffCountMobjects=" + diffCountMobjects +
                '}';
    }
}
