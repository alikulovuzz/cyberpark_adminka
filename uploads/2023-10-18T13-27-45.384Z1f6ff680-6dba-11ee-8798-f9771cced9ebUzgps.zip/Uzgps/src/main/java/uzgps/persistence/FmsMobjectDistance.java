package uzgps.persistence;

import org.apache.kafka.common.protocol.types.Field;
import org.hibernate.annotations.Immutable;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Immutable
@Table(schema = "reporting")
public class FmsMobjectDistance implements Serializable {

    @Id
    @Column(name = "mobject_id")
    private Long mobject_id;

    @Column(name = "distance_date")
    private Timestamp distance_date;

    @Column(name = "distance")
    private Double distance;

    @Transient
    private Long returning_id;

    @Transient
    private String returning_date;

    @Transient
    private Double returning_current_odometer;

    ///////////////////////////////////////////////////////////////////////////

    public Long getMobject_id() {
        return mobject_id;
    }

    public void setMobject_id(Long mobject_id) {
        this.mobject_id = mobject_id;
    }

    public Timestamp getDistance_date() {
        return distance_date;
    }

    public void setDistance_date(Timestamp startDate) {
        this.distance_date = startDate;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Long getReturning_id() {
        return returning_id;
    }

    public void setReturningId(Long orderId) {
        this.returning_id = orderId;
    }

    public String getReturning_date() {
        return returning_date;
    }

    public void setReturningDate(String orderId) {
        this.returning_date = orderId;
    }

    public Double getReturning_current_odometer() {
        return returning_current_odometer;
    }

    public void setReturningCurrentOdometer(Double returning_current_odometer) {
        this.returning_current_odometer = returning_current_odometer;
    }

    @Override
    public String toString() {
        return "FmsMobjectDistance{" +
                "mobject_id=" + mobject_id +
                "returning_id=" + returning_id +
                ", distance_date=" + distance_date +
                ", distance=" + distance +
                '}';
    }
}
