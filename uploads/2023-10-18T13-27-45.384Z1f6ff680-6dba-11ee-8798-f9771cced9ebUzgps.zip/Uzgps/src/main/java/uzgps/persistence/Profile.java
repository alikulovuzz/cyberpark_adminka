package uzgps.persistence;

import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_profile")
public class Profile implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_PROFILE_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "p_position", nullable=true, length = 255)
    private String position;

    @Column(name = "p_mobile_phone", nullable = true, length = 50)
    private String mobilePhone;

    @Column(name = "p_line_phone", nullable = true, length = 50)
    private String linePhone;

    @Column(name = "p_email", nullable = true, length = 128)
    private String email;

    @Lob
    @Type(type="org.hibernate.type.StringClobType")
    @Column(name = "p_description", nullable=true)
    private String description;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public void setMobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    public String getLinePhone() {
        return linePhone;
    }

    public void setLinePhone(String linePhone) {
        this.linePhone = linePhone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Profile{" +
                "id=" + id +
                ", position='" + position + '\'' +
                ", mobilePhone='" + mobilePhone + '\'' +
                ", linePhone='" + linePhone + '\'' +
                ", email='" + email + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
