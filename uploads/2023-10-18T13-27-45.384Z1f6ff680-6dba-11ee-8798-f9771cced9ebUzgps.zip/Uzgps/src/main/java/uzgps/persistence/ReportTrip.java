package uzgps.persistence;

import org.hibernate.annotations.Immutable;
import uzgps.excel.tripReports.AbstractTripItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Immutable
@Table(schema = "reporting")
public class ReportTrip extends AbstractTripItem implements Serializable {

    //    public static final String sequenceName = "SEQ_REPORT_TRACK_STATISTICS_ID";
//
    @Id
    private Long id;

    @Column(name = "contract_id")
    private Integer contractId;

    @Column(name = "trip_ab")
    private String tripAB;

    @Column(name = "trip_description")
    private String tripDescription;

    @Column(name = "trip_distance")
    private Double tripDistance;

    @Column(name = "trip_time_planned")
    private Timestamp tripTimePlanned;

    @Column(name = "trip_id")
    private Long tripId;

    @Column(name = "trip_name")
    private String tripName;

    @Column(name = "trip_type")
    private Integer tripType;

    @Column(name = "mobject")
    private String mobject;

    @Column(name = "time_start_planned")
    private Timestamp timeStartPlanned;

    @Column(name = "time_start_real")
    private Timestamp timeStartReal;

    @Column(name = "time_start_deviation")
    private Timestamp timeStartDeviation;

    @Column(name = "time_end_planned")
    private Timestamp timeEndPlanned;

    @Column(name = "time_end_real")
    private Timestamp timeEndReal;

    @Column(name = "time_end_deviation")
    private Timestamp timeEndDeviation;

    @Column(name = "trip_status")
    private Integer tripStatus;

    @Column(name = "trip_time_travel")
    private Timestamp tripTimeTravel;

    @Column(name = "trip_distance_travel")
    private Double tripDistanceTravel;

    @Column(name = "event_route_exit_count")
    private Integer eventRouteExitCount;

    @Column(name = "event_route_return_count")
    private Integer eventRouteReturnCount;

    @Column(name = "event_station_enter_early")
    private Integer eventStationEnterEarly;

    @Column(name = "event_station_enter_late")
    private Integer eventStationEnterLate;

    @Column(name = "event_station_exit_early")
    private Integer eventStationExitEarly;

    @Column(name = "event_station_exit_late")
    private Integer eventStationExitLate;

    @Column(name = "event_station_skipped")
    private Integer eventStationSkipped;

    @Column(name = "event_station_in_parking_more_count")
    private Integer eventStationParkingMoreCount;

    @Column(name = "event_station_out_parking_more_time")
    private Timestamp eventStationOutParkingMoreTime;

    @Column(name = "event_station_not_stopped")
    private Integer eventStationNotStopped;

    @Column(name = "event_overspeed_count")
    private Integer eventOverspeedCount;

    @Column(name = "event_overspeed_max_speed")
    private Integer eventOverspeedMaxSpeed;

    ///////////////////////////////////////////////////////////////////////////

    public Long getId() {
        return id;
    }

    public Integer getContractId() {
        return contractId;
    }

    @Override
    public Long getTripId() {
        return tripId;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setContractId(Integer contractId) {
        this.contractId = contractId;
    }

    @Override
    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public String getMobject() {
        return mobject;
    }

    public void setMobject(String mobject) {
        this.mobject = mobject;
    }

    public Timestamp getTimeStartPlanned() {
        return timeStartPlanned;
    }

    public void setTimeStartPlanned(Timestamp timeStartPlanned) {
        this.timeStartPlanned = timeStartPlanned;
    }

    public Timestamp getTimeStartReal() {
        return timeStartReal;
    }

    public void setTimeStartReal(Timestamp timeStartReal) {
        this.timeStartReal = timeStartReal;
    }

    public Timestamp getTimeStartDeviation() {
        return timeStartDeviation;
    }

    public void setTimeStartDeviation(Timestamp timeStartDeviation) {
        this.timeStartDeviation = timeStartDeviation;
    }

    public Timestamp getTimeEndPlanned() {
        return timeEndPlanned;
    }

    public void setTimeEndPlanned(Timestamp timeEndPlanned) {
        this.timeEndPlanned = timeEndPlanned;
    }

    public Timestamp getTimeEndReal() {
        return timeEndReal;
    }

    public void setTimeEndReal(Timestamp timeEndReal) {
        this.timeEndReal = timeEndReal;
    }

    public Timestamp getTimeEndDeviation() {
        return timeEndDeviation;
    }

    public void setTimeEndDeviation(Timestamp timeEndDeviation) {
        this.timeEndDeviation = timeEndDeviation;
    }

    public Integer getTripStatus() {
        return tripStatus;
    }

    public void setTripStatus(Integer tripStatus) {
        this.tripStatus = tripStatus;
    }

    public Timestamp getTripTimeTravel() {
        return tripTimeTravel;
    }

    public void setTripTimeTravel(Timestamp tripTimeTravel) {
        this.tripTimeTravel = tripTimeTravel;
    }

    public Double getTripDistanceTravel() {
        return tripDistanceTravel;
    }

    public void setTripDistanceTravel(Double tripDistanceTravel) {
        this.tripDistanceTravel = tripDistanceTravel;
    }

    public Integer getEventRouteExitCount() {
        return eventRouteExitCount;
    }

    public void setEventRouteExitCount(Integer eventExitRoute) {
        this.eventRouteExitCount = eventExitRoute;
    }

    public Integer getEventStationEnterEarly() {
        return eventStationEnterEarly;
    }

    public void setEventStationEnterEarly(Integer eventStationEnterEarly) {
        this.eventStationEnterEarly = eventStationEnterEarly;
    }

    public Integer getEventStationEnterLate() {
        return eventStationEnterLate;
    }

    public void setEventStationEnterLate(Integer event_stationEnterLate) {
        this.eventStationEnterLate = event_stationEnterLate;
    }

    public Integer getEventStationExitEarly() {
        return eventStationExitEarly;
    }

    public void setEventStationExitEarly(Integer eventStationExitEarly) {
        this.eventStationExitEarly = eventStationExitEarly;
    }

    public Integer getEventStationExitLate() {
        return eventStationExitLate;
    }

    public void setEventStationExitLate(Integer eventStationExitLate) {
        this.eventStationExitLate = eventStationExitLate;
    }

    public Integer getEventStationSkipped() {
        return eventStationSkipped;
    }

    public void setEventStationSkipped(Integer eventStationSkipped) {
        this.eventStationSkipped = eventStationSkipped;
    }

    public Integer getEventStationParkingMoreCount() {
        return eventStationParkingMoreCount;
    }

    public void setEventStationParkingMoreCount(Integer eventStationParkingMoreCount) {
        this.eventStationParkingMoreCount = eventStationParkingMoreCount;
    }

    public Integer getEventStationNotStopped() {
        return eventStationNotStopped;
    }

    public void setEventStationNotStopped(Integer eventStationNotStopped) {
        this.eventStationNotStopped = eventStationNotStopped;
    }

    public Integer getEventOverspeedCount() {
        return eventOverspeedCount;
    }

    public void setEventOverspeedCount(Integer eventOverspeedCount) {
        this.eventOverspeedCount = eventOverspeedCount;
    }

    public Integer getEventOverspeedMaxSpeed() {
        return eventOverspeedMaxSpeed;
    }

    public void setEventOverspeedMaxSpeed(Integer eventOverspeedMaxSpeed) {
        this.eventOverspeedMaxSpeed = eventOverspeedMaxSpeed;
    }

    public Integer getEventRouteReturnCount() {
        return eventRouteReturnCount;
    }

    public void setEventRouteReturnCount(Integer eventRouteReturnCount) {
        this.eventRouteReturnCount = eventRouteReturnCount;
    }

    public Timestamp getEventStationOutParkingMoreTime() {
        return eventStationOutParkingMoreTime;
    }

    public void setEventStationOutParkingMoreTime(Timestamp eventStationOutParkingMore) {
        this.eventStationOutParkingMoreTime = eventStationOutParkingMore;
    }

    public String getTripDirection() {
        return tripAB;
    }

    public void setTripDirection(String tripAB) {
        this.tripAB = tripAB;
    }

    public String getTripDescription() {
        return tripDescription;
    }

    public void setTripDescription(String tripDescription) {
        this.tripDescription = tripDescription;
    }

    public Double getTripDistance() {
        return tripDistance;
    }

    public void setTripDistance(Double tripDistance) {
        this.tripDistance = tripDistance;
    }

    public Timestamp getTripTimePlanned() {
        return tripTimePlanned;
    }

    public void setTripTimePlanned(Timestamp tripTimePlanned) {
        this.tripTimePlanned = tripTimePlanned;
    }

    public String getTripAB() {
        return tripAB;
    }

    public void setTripAB(String tripAB) {
        this.tripAB = tripAB;
    }

    @Override
    public String toString() {
        return "ReportTrip{" +
                "id=" + id +
                ", contractId=" + contractId +
                ", tripAB='" + tripAB + '\'' +
                ", tripDescription='" + tripDescription + '\'' +
                ", tripDistance=" + tripDistance +
                ", tripTimePlanned=" + tripTimePlanned +
                ", tripId=" + tripId +
                ", tripName='" + tripName + '\'' +
                ", tripType=" + tripType +
                ", mobject='" + mobject + '\'' +
                ", timeStartPlanned=" + timeStartPlanned +
                ", timeStartReal=" + timeStartReal +
                ", timeStartDeviation=" + timeStartDeviation +
                ", timeEndPlanned=" + timeEndPlanned +
                ", timeEndReal=" + timeEndReal +
                ", timeEndDeviation=" + timeEndDeviation +
                ", tripStatus=" + tripStatus +
                ", tripTimeTravel=" + tripTimeTravel +
                ", tripDistanceTravel=" + tripDistanceTravel +
                ", eventRouteExitCount=" + eventRouteExitCount +
                ", eventRouteReturnCount=" + eventRouteReturnCount +
                ", eventStationEnterEarly=" + eventStationEnterEarly +
                ", eventStationEnterLate=" + eventStationEnterLate +
                ", eventStationExitEarly=" + eventStationExitEarly +
                ", eventStationExitLate=" + eventStationExitLate +
                ", eventStationSkipped=" + eventStationSkipped +
                ", eventStationParkingMoreCount=" + eventStationParkingMoreCount +
                ", eventStationOutParkingMore=" + eventStationOutParkingMoreTime +
                ", eventStationNotStopped=" + eventStationNotStopped +
                ", eventOverspeedCount=" + eventOverspeedCount +
                ", eventOverspeedMaxSpeed=" + eventOverspeedMaxSpeed +
                '}';
    }
}
