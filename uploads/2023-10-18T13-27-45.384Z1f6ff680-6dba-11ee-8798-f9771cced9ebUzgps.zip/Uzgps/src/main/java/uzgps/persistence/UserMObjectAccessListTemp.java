package uzgps.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(schema = "reporting")
public class UserMObjectAccessListTemp {

    @Id private Long id;

    private Long aid;

    private Long mobjectID;

    private Long user_id;

    private Integer per;

    private String mobjectName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAid() {
        return aid;
    }

    public void setAid(Long aid) {
        this.aid = aid;
    }

    public Long getMobjectID() {
        return mobjectID;
    }

    public void setMobjectID(Long mobjectID) {
        this.mobjectID = mobjectID;
    }

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public Integer getPer() {
        return per;
    }

    public void setPer(Integer per) {
        this.per = per;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }
}
