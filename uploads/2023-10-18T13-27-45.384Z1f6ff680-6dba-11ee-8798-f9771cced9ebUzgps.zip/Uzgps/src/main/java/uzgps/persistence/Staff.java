package uzgps.persistence;

import org.hibernate.annotations.Where;
import org.hibernate.annotations.WhereJoinTable;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "uzgps_staff")
public class Staff implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_STAFF_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "contract_id", nullable=false)
    private Long contractId;

    @Column(name = "s_surname", nullable=false, length = 32)
    private String surName;

    @Column(name = "s_name", nullable=false, length = 32)
    private String name;

    @Column(name = "s_middlename", nullable=false, length = 32)
    private String middleName;

    @Column(name = "photo_id", nullable=true, insertable = false, updatable = false)
    private Long photoId;
    @ManyToOne
    @JoinColumn(name = "photo_id")
    private FileStorage photo;

    @Column(name = "s_position", nullable=true, length = 50)
    private String position;

    @Column(name = "s_phone_mobile", nullable=true, length = 20)
    private String phoneMobile;

    @Column(name = "s_phone_line", nullable=true, length = 20)
    private String phoneLine;

    @OneToMany
    @JoinColumn(name = "staff_id")
    @Where(clause = "so_status = 'A' " +
            "    and ((so_start_date <= now() and so_end_date >= now() and so_endless = (1=2)) or " +
            "         (so_endless = (1=1) and so_start_date <= now()))")
    private List<MObjectStaff> mObjectStaffList = new ArrayList<>();

    @ManyToOne
    @JoinColumn(name = "subdivision_id")
    private CatalogSubdivision catalogSubdivision;

    @ManyToOne
    @JoinColumn(name = "company_id")
    private CatalogCompany catalogCompany;

    @Column(name = "s_status", nullable = false, length = 1)
    private String status;

    @Column(name = "s_reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "s_mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "s_exp_date", nullable=true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public Long getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Long photoId) {
        this.photoId = photoId;
    }

    public FileStorage getPhoto() {
        return photo;
    }

    public void setPhoto(FileStorage photo) {
        this.photo = photo;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getPhoneMobile() {
        return phoneMobile;
    }

    public void setPhoneMobile(String phoneMobile) {
        this.phoneMobile = phoneMobile;
    }

    public String getPhoneLine() {
        return phoneLine;
    }

    public void setPhoneLine(String phoneLine) {
        this.phoneLine = phoneLine;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public List<MObjectStaff> getmObjectStaffList() {
        return mObjectStaffList;
    }

    public void setmObjectStaffList(List<MObjectStaff> mObjectStaffList) {
        this.mObjectStaffList = mObjectStaffList;
    }

    public CatalogSubdivision getCatalogSubdivision() {
        return catalogSubdivision;
    }

    public void setCatalogSubdivision(CatalogSubdivision catalogSubdivision) {
        this.catalogSubdivision = catalogSubdivision;
    }

    public CatalogCompany getCatalogCompany() {
        return catalogCompany;
    }

    public void setCatalogCompany(CatalogCompany catalogCompany) {
        this.catalogCompany = catalogCompany;
    }
}
