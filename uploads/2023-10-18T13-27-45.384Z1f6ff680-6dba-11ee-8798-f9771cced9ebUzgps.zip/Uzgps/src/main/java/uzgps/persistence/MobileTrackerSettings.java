package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by Gayratjon on 12/11/2014.
 */

@Entity
@Table(name = "uzgps_mtracker_settings")
public class MobileTrackerSettings implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MTRACKER_SETTINGS_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "mobject_id", nullable = false)
    private Long mObjectId;

    @Column(name = "mobile_serial", nullable = false, length = 200)
    private String mobileSerial;

    @Column(name = "has_password", nullable = true)
    private Boolean hasPassword;

    @Column(name = "password", nullable = true)
    private Integer password;

    @Transient
    private Integer locationProfile;

    @Column(name = "location_update_time", nullable = true)
    private Integer locationUpdateTime;

    @Column(name = "location_update_distance", nullable = true)
    private Integer locationUpdateDistance;

    @Column(name = "location_update_accuracy", nullable = true)
    private Integer locationUpdateAccuracy;

    @Column(name = "location_update_angle", nullable = true)
    private Integer locationUpdateAngle;

    @Column(name = "should_change_status", nullable = true)
    private Boolean shouldChangeStatus;

    @Column(name = "record_limit", nullable = true)
    private Integer recordLimit;

    @Column(name = "location_send_time", nullable = true)
    private Integer locationSendTime;

    @Column(name = "should_send_3g", nullable = true)
    private Boolean shouldSend3G;

    @Column(name = "should_send_wifi", nullable = true)
    private Boolean shouldSendWiFi;

    @Column(name = "track_length", nullable = true)
    private Integer trackLength;

    @Column(name = "sos_number1", nullable = true, length = 200)
    private String sosNumber1;

    @Column(name = "sos_number2", nullable = true, length = 200)
    private String sosNumber2;

    @Column(name = "sos_number3", nullable = true, length = 200)
    private String sosNumber3;

    @Column(name = "sos_number4", nullable = true, length = 200)
    private String sosNumber4;

    @Column(name = "sos_number5", nullable = true, length = 200)
    private String sosNumber5;

    @Column(name = "sos_number6", nullable = true, length = 200)
    private String sosNumber6;

    @Column(name = "sos_number7", nullable = true, length = 200)
    private String sosNumber7;

    @Column(name = "hide_icon", nullable = true)
    private Integer hideIcon;

    @Column(name = "server_port", nullable = true)
    private Integer serverPort;

    @Column(name = "server_ip", nullable = true)
    private String serverIp;

    @Column(name = "settings_update_time", nullable = true)
    private Integer settingsUpdateTime;

    @Column(name = "map_type", nullable = true)
    private Integer mapType;

    @Column(name = "so_status", nullable = false, length = 1)
    private String status;

    @Column(name = "so_reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "so_mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "so_exp_date", nullable=true)
    private Timestamp expDate;

    public Integer getServerPort() {
        return serverPort;
    }

    public void setServerPort(Integer serverPort) {
        this.serverPort = serverPort;
    }

    public String getServerIp() {
        return serverIp;
    }

    public void setServerIp(String serverIp) {
        this.serverIp = serverIp;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public String getMobileSerial() {
        return mobileSerial;
    }

    public void setMobileSerial(String mobileSerial) {
        this.mobileSerial = mobileSerial;
    }

    public Boolean getHasPassword() {
        return hasPassword;
    }

    public void setHasPassword(Boolean hasPassword) {
        this.hasPassword = hasPassword;
    }

    public Integer getPassword() {
        return password;
    }

    public void setPassword(Integer password) {
        this.password = password;
    }

    public Integer getLocationProfile() {
        return locationProfile;
    }

    public void setLocationProfile(Integer locationProfile) {
        this.locationProfile = locationProfile;
    }

    public Integer getLocationUpdateTime() {
        return locationUpdateTime;
    }

    public void setLocationUpdateTime(Integer locationUpdateTime) {
        this.locationUpdateTime = locationUpdateTime;
    }

    public Integer getLocationUpdateDistance() {
        return locationUpdateDistance;
    }

    public void setLocationUpdateDistance(Integer locationUpdateDistance) {
        this.locationUpdateDistance = locationUpdateDistance;
    }

    public Integer getLocationUpdateAccuracy() {
        return locationUpdateAccuracy;
    }

    public void setLocationUpdateAccuracy(Integer locationUpdateAccuracy) {
        this.locationUpdateAccuracy = locationUpdateAccuracy;
    }

    public Integer getHideIcon() {
        return hideIcon;
    }

    public void setHideIcon(Integer hideIcon) {
        this.hideIcon = hideIcon;
    }

    public Integer getSettingsUpdateTime() {
        return settingsUpdateTime;
    }

    public void setSettingsUpdateTime(Integer settingsUpdateTime) {
        this.settingsUpdateTime = settingsUpdateTime;
    }

    public Integer getLocationUpdateAngle() {
        return locationUpdateAngle;
    }

    public void setLocationUpdateAngle(Integer locationUpdateAngle) {
        this.locationUpdateAngle = locationUpdateAngle;
    }

    public Boolean getShouldChangeStatus() {
        return shouldChangeStatus;
    }

    public void setShouldChangeStatus(Boolean shouldChangeStatus) {
        this.shouldChangeStatus = shouldChangeStatus;
    }

    public Integer getRecordLimit() {
        return recordLimit;
    }

    public void setRecordLimit(Integer recordLimit) {
        this.recordLimit = recordLimit;
    }

    public Integer getLocationSendTime() {
        return locationSendTime;
    }

    public void setLocationSendTime(Integer locationSendTime) {
        this.locationSendTime = locationSendTime;
    }

    public Boolean getShouldSend3G() {
        return shouldSend3G;
    }

    public void setShouldSend3G(Boolean shouldSend3G) {
        this.shouldSend3G = shouldSend3G;
    }

    public Boolean getShouldSendWiFi() {
        return shouldSendWiFi;
    }

    public void setShouldSendWiFi(Boolean shouldSendWiFi) {
        this.shouldSendWiFi = shouldSendWiFi;
    }

    public Integer getTrackLength() {
        return trackLength;
    }

    public void setTrackLength(Integer trackLength) {
        this.trackLength = trackLength;
    }

    public String getSosNumber1() {
        return sosNumber1;
    }

    public void setSosNumber1(String sosNumber1) {
        this.sosNumber1 = sosNumber1;
    }

    public String getSosNumber2() {
        return sosNumber2;
    }

    public void setSosNumber2(String sosNumber2) {
        this.sosNumber2 = sosNumber2;
    }

    public String getSosNumber3() {
        return sosNumber3;
    }

    public void setSosNumber3(String sosNumber3) {
        this.sosNumber3 = sosNumber3;
    }

    public String getSosNumber4() {
        return sosNumber4;
    }

    public void setSosNumber4(String sosNumber4) {
        this.sosNumber4 = sosNumber4;
    }

    public String getSosNumber5() {
        return sosNumber5;
    }

    public void setSosNumber5(String sosNumber5) {
        this.sosNumber5 = sosNumber5;
    }

    public String getSosNumber6() {
        return sosNumber6;
    }

    public void setSosNumber6(String sosNumber6) {
        this.sosNumber6 = sosNumber6;
    }

    public String getSosNumber7() {
        return sosNumber7;
    }

    public void setSosNumber7(String sosNumber7) {
        this.sosNumber7 = sosNumber7;
    }

    public Integer getMapType() {
        return mapType;
    }

    public void setMapType(Integer mapType) {
        this.mapType = mapType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {


        return "MobileTrackerSettings{" +
                "id=" + id +
                ", mObjectId=" + mObjectId +
                ", mobileSerial='" + mobileSerial + '\'' +
                ", hasPassword=" + hasPassword +
                ", password=" + password +
                ", locationUpdateTime=" + locationUpdateTime +
                ", locationUpdateDistance=" + locationUpdateDistance +
                ", locationUpdateAccuracy=" + locationUpdateAccuracy +
                ", locationUpdateAngle=" + locationUpdateAngle +
                ", shouldChangeStatus=" + shouldChangeStatus +
                ", recordLimit=" + recordLimit +
                ", locationSendTime=" + locationSendTime +
                ", shouldSend3G=" + shouldSend3G +
                ", shouldSendWiFi=" + shouldSendWiFi +
                ", trackLength=" + trackLength +
                ", sosNumber1='" + sosNumber1 + '\'' +
                ", sosNumber2='" + sosNumber2 + '\'' +
                ", sosNumber3='" + sosNumber3 + '\'' +
                ", sosNumber4='" + sosNumber4 + '\'' +
                ", sosNumber5='" + sosNumber5 + '\'' +
                ", sosNumber6='" + sosNumber6 + '\'' +
                ", sosNumber7='" + sosNumber7 + '\'' +
                ", mapType=" + mapType +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
