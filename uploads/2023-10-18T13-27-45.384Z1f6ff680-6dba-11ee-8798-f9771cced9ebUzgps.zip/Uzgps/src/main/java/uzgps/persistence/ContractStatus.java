package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by gayratjon on 5/12/16.
 */
@Entity
@Table(name = "contract_status")
public class ContractStatus implements Serializable {

    public static final String sequenceName = "SEQ_CONTRACT_STATUS_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "ContractStatus{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
}
