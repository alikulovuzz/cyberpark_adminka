package uzgps.persistence;

import uzgps.common.UZGPS_CONST;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "uzgps_user_access_list")

public class UserAccessList implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_USER_ACCESS_LIST_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "ual_user_id", nullable = false, insertable = false, updatable = false)
    private Long userId;
    @ManyToOne
    @JoinColumn(name = "ual_user_id")
    private User user;

    @Column(name = "ual_contractId", nullable = false, insertable = false, updatable = false)
    private Long contractId;
    @ManyToOne
    @JoinColumn(name = "ual_contractId")
    private Contract contract;

    @Column(name = "ual_map", nullable = true)
    private Integer map;

    @Column(name = "ual_monitoring", nullable = false)
    private Integer monitoring;

    @Column(name = "ual_tracker", nullable = false)
    private Integer tracker;

    @Column(name = "ual_poi", nullable = false)
    private Integer poi;

    @Column(name = "ual_geozone", nullable = false)
    private Integer geoZone;

    @Column(name = "ual_message", nullable = false)
    private Integer message;

    @Column(name = "ual_report", nullable = false)
    private Integer report;

    @Column(name = "ual_settings", nullable = true)
    private Integer settings;

    @Column(name = "ual_settings_map", nullable = true)
    private Integer settingsMap;

    @Column(name = "ual_settings_monitoring", nullable = true)
    private Integer settingsMonitoring;

    @Column(name = "ual_settings_object", nullable = true)
    private Integer settingsObject;

    @Column(name = "ual_settings_group", nullable = true)
    private Integer settingsGroup;

    @Column(name = "ual_settings_staff", nullable = true)
    private Integer settingsStaff;

    @Column(name = "ual_settings_users", nullable = true)
    private Integer settingsUsers;

    @Column(name = "ual_settings_notifications", nullable = true)
    private Integer settingsNotifications;

    @Column(name = "ual_settings_display_data", nullable = true)
    private Integer settingsDisplayData;

    @Column(name = "ual_settings_user_poi_zoi_access", nullable = true)
    private Integer settingsUserPoiZoiAccess;

    @Column(name = "ual_settings_dashboard", nullable = true)
    private Integer settingsDashboard;

    @Column(name = "ual_settings_ext_services", nullable = true)
    private Integer settingsExternalServices;

    @Column(name = "ual_routing", nullable = true)
    private Integer routing;

    @Column(name = "ual_routing_dashboard")
    private Integer routingDashboard;

    @Column(name = "ual_agro", nullable = true)
    private Integer agro;
//
//    @Column(name = "ual_track_statistics", nullable = true)
//    private Integer trackStatistics;

    @Column(name = "ual_dashboard", nullable = true)
    private Integer dashboard;

    @Column(name = "ual_camera", nullable = true)
    private Integer camera;

    @Column(name = "ual_fms", nullable = true)
    private Integer fms;

    @Column(name = "ual_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "ual_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "ual_exp_date", nullable = true)
    private Timestamp expDate;


    @Transient
    private Integer userAccessFull;

    @Transient
    private Integer userAccessNone;

    @Transient
    private Integer userAccessView;

    @Transient
    private Integer userAccessEdit;

    public UserAccessList() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Integer getMap() {
        return map;
    }

    public void setMap(Integer map) {
        this.map = map;
    }

    public Integer getMonitoring() {
        return monitoring;
    }

    public void setMonitoring(Integer monitoring) {
        this.monitoring = monitoring;
    }

    public Integer getTracker() {
        return tracker;
    }

    public void setTracker(Integer tracker) {
        this.tracker = tracker;
    }

    public Integer getPoi() {
        return poi;
    }

    public void setPoi(Integer poi) {
        this.poi = poi;
    }

    public Integer getGeoZone() {
        return geoZone;
    }

    public void setGeoZone(Integer geoZone) {
        this.geoZone = geoZone;
    }

    public Integer getMessage() {
        return message;
    }

    public void setMessage(Integer message) {
        this.message = message;
    }

    public Integer getReport() {
        return report;
    }

    public Integer getTrafficSchedule() {
        return 1;
    }

    public void setReport(Integer report) {
        this.report = report;
    }

    public Integer getSettings() {
        return settings;
    }

    public void setSettings(Integer settings) {
        this.settings = settings;
    }

    public Integer getSettingsMap() {
        return settingsMap;
    }

    public void setSettingsMap(Integer settingsMap) {
        this.settingsMap = settingsMap;
    }

    public Integer getSettingsMonitoring() {
        return settingsMonitoring;
    }

    public void setSettingsMonitoring(Integer settingsMonitoring) {
        this.settingsMonitoring = settingsMonitoring;
    }

    public Integer getSettingsObject() {
        return settingsObject;
    }

    public void setSettingsObject(Integer settingsObject) {
        this.settingsObject = settingsObject;
    }

    public Integer getSettingsGroup() {
        return settingsGroup;
    }

    public void setSettingsGroup(Integer settingsGroup) {
        this.settingsGroup = settingsGroup;
    }

    public Integer getSettingsStaff() {
        return settingsStaff;
    }

    public void setSettingsStaff(Integer settingsStaff) {
        this.settingsStaff = settingsStaff;
    }

    public Integer getSettingsUsers() {
        return settingsUsers;
    }

    public void setSettingsUsers(Integer settingsUsers) {
        this.settingsUsers = settingsUsers;
    }

    public Integer getSettingsNotifications() {
        return settingsNotifications;
    }

    public void setSettingsNotifications(Integer settingsNotifications) {
        this.settingsNotifications = settingsNotifications;
    }

    public Integer getSettingsDisplayData() {
        return settingsDisplayData;
    }

    public void setSettingsDisplayData(Integer settingsDisplayData) {
        this.settingsDisplayData = settingsDisplayData;
    }

    public Integer getSettingsUserPoiZoiAccess() {
        return settingsUserPoiZoiAccess;
    }

    public void setSettingsUserPoiZoiAccess(Integer settingsUserPoiZoiAccess) {
        this.settingsUserPoiZoiAccess = settingsUserPoiZoiAccess;
    }

    public Integer getSettingsDashboard() {
        return settingsDashboard;
    }

    public void setSettingsDashboard(Integer settingsDashboard) {
        this.settingsDashboard = settingsDashboard;
    }

    public Integer getSettingsExternalServices() {
        return settingsExternalServices;
    }

    public void setSettingsExternalServices(Integer settingsExternalServices) {
        this.settingsExternalServices = settingsExternalServices;
    }

    public Integer getRouting() {
        return routing;
    }

    public boolean hasRoutingAccess(int access) {
        return (routing & access) > 0;
    }

    public void setRouting(Integer routing) {
        this.routing = routing;
    }

    public Integer getAgro() {
        return agro;
    }

    public void setAgro(Integer agro) {
        this.agro = agro;
    }

    public Integer getDashboard() {
        return dashboard;
    }

    public boolean hasDashboardAccess(int access) {
        return (dashboard & access) > 0;
    }

    public void setDashboard(Integer dashboard) {
        this.dashboard = dashboard;
    }
//
//    public Integer getTrackStatistics() {
//        return trackStatistics;
//    }
//
//    public void setTrackStatistics(Integer trackStatistics) {
//        this.trackStatistics = trackStatistics;
//    }

    public Integer getCamera() {
        return camera;
    }

    public void setCamera(Integer camera) {
        this.camera = camera;
    }

    public Integer getRoutingDashboard() {
        return routingDashboard;
    }

    public void setRoutingDashboard(Integer routingDashboard) {
        this.routingDashboard = routingDashboard;
    }

    public Integer getFms() {
        return fms;
    }

    public void setFms(Integer fms) {
        this.fms = fms;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Integer getUserAccessFull() {
        return UZGPS_CONST.USER_ACCESS_FULL;
    }

    public Integer getUserAccessNone() {
        return UZGPS_CONST.USER_ACCESS_NONE;
    }

    public Integer getUserAccessView() {
        return UZGPS_CONST.USER_ACCESS_VIEW;
    }

    public Integer getUserAccessEdit() {
        return UZGPS_CONST.USER_ACCESS_EDIT;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Contract getContract() {
        return contract;
    }

    @Override
    public String toString() {
        return "UserAccessList{" +
                "id=" + id +
                ", userId=" + userId +
                ", user=" + user +
                ", contractId=" + contractId +
                ", map=" + map +
                ", monitoring=" + monitoring +
                ", tracker=" + tracker +
                ", poi=" + poi +
                ", geoZone=" + geoZone +
                ", message=" + message +
                ", report=" + report +
                ", settings=" + settings +
                ", settingsMap=" + settingsMap +
                ", settingsMonitoring=" + settingsMonitoring +
                ", settingsObject=" + settingsObject +
                ", settingsGroup=" + settingsGroup +
                ", settingsStaff=" + settingsStaff +
                ", settingsUsers=" + settingsUsers +
                ", settingsNotifications=" + settingsNotifications +
                ", settingsDisplayData=" + settingsDisplayData +
                ", settingsDashboard=" + settingsDashboard +
                ", settingsUserPoiZoiAccess=" + settingsUserPoiZoiAccess +
                ", settingsExternalServices=" + settingsExternalServices +

                ", routing=" + routing +
                ", routingDashboard" + routingDashboard +
                ", agro=" + agro +
//                ", trackStatistics=" + trackStatistics +
                ", dashboard=" + dashboard +
                ", camera=" + camera +
                ", fms=" + fms +

                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                ", userAccessFull=" + userAccessFull +
                ", userAccessNone=" + userAccessNone +
                ", userAccessView=" + userAccessView +
                ", userAccessEdit=" + userAccessEdit +
                '}';
    }
}
