package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "uzgps_mobject_notifications")

public class MObjectNotifications implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_NOTIFICATIONS_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "mobject_id", nullable = false)
    private Long mObjectId;

    @Column(name = "panic_button", nullable = false)
    private Boolean panicButton;

    @Column(name = "min_speed", nullable = false)
    private Integer minSpeed;

    @Column(name = "max_speed", nullable = false)
    private Integer maxSpeed;

    @Column(name = "send_sms", nullable = false)
    private Boolean sendSms;

    @Column(name = "phone_number", nullable = true, length = 20)
    private String phoneNumber;

    @Column(name = "send_mail", nullable = false)
    private Boolean sendMail;

    @Column(name = "mail", nullable = true, length = 50)
    private String mail;

    @Column(name = "mail_second", nullable = true, length = 50)
    private String mailSecond;

    @Column(name = "mail_third", nullable = true, length = 50)
    private String mailThird;

    @Column(name = "pop_up_window", nullable = true)
    private Boolean popUpWindow;

    @Column(name = "n_popup_window", nullable = true)
    private Boolean nPopUpWindow;

    @Column(name = "register_database", nullable = true)
    private Boolean registerDatabase;

    @Column(name = "register_database_violation", nullable = true)
    private Boolean registerDatabaseViolation;

    // Notification (UVEDOMLENIYE) == SOS button
    @Column(name = "u_sos", nullable = true)
    private Boolean uSos;

    // Notification sos sound
    @Column(name = "u_sos_sound", nullable = true)
    private Integer uSosSound;

    // Notification sos color
    @Column(name = "u_sos_color", nullable = true, length = 7)
    private String uSosColor;

    // Notification (UVEDOMLENIYE) == Engine On (Zajiganiye)
    @Column(name = "u_engine", nullable = true)
    private Boolean uEngine;

    // Notification engine sound
    @Column(name = "u_engine_sound", nullable = true)
    private Integer uEngineSound;

    // Notification engine color
    @Column(name = "u_engine_color", nullable = true, length = 7)
    private String uEngineColor;

    // Notification (UVEDOMLENIYE) == External power on (External power)
    @Column(name = "u_ext_power", nullable = true)
    private Boolean uExternalPower;

    // Notification external power sound
    @Column(name = "u_ext_power_sound", nullable = true)
    private Integer uExternalPowerSound;

    // Notification external power color
    @Column(name = "u_ext_power_color", nullable = true, length = 7)
    private String uExternalPowerColor;

    // Notification (UVEDOMLENIYE) == Speed MIN
    @Column(name = "u_speed_min", nullable = true)
    private Boolean uSpeedMin;

    // Notification speed min sound
    @Column(name = "u_speed_min_sound", nullable = true)
    private Integer uSpeedMinSound;

    // Notification speed min color
    @Column(name = "u_speed_min_color", nullable = true, length = 7)
    private String uSpeedMinColor;

    // Notification (UVEDOMLENIYE) == Speed MAX
    @Column(name = "u_speed_max", nullable = true)
    private Boolean uSpeedMax;

    // Notification speed max sound
    @Column(name = "u_speed_max_sound", nullable = true)
    private Integer uSpeedMaxSound;

    // Notification speed max color
    @Column(name = "u_speed_max_color", nullable = true, length = 7)
    private String uSpeedMaxColor;

    // Notification (UVEDOMLENIYE) == Online
    @Column(name = "u_online", nullable = true)
    private Boolean uOnline;

    // Notification online sound
    @Column(name = "u_online_sound", nullable = true)
    private Integer uOnlineSound;

    // Notification online color
    @Column(name = "u_online_color", nullable = true, length = 7)
    private String uOnlineColor;

    // Notification (UVEDOMLENIYE) == Staff (personal)
    @Column(name = "u_staff", nullable = true)
    private Boolean uStaff;

    // Notification staff sound
    @Column(name = "u_staff_sound", nullable = true)
    private Integer uStaffSound;

    // Notification staff color
    @Column(name = "u_staff_color", nullable = true, length = 7)
    private String uStaffColor;

    // Notification (UVEDOMLENIYE) == Object Settings changed
    @Column(name = "u_settings", nullable = true)
    private Boolean uSettings;

    // Notification settings sound
    @Column(name = "u_settings_sound", nullable = true)
    private Integer uSettingsSound;

    // Notification settings color
    @Column(name = "u_settings_color", nullable = true, length = 7)
    private String uSettingsColor;

    // Notification (UVEDOMLENIYE) == Poi
    @Column(name = "u_poi", nullable = true)
    private Boolean uPoi;

    // Notification poi sound
    @Column(name = "u_poi_sound", nullable = true)
    private Integer uPoiSound;

    // Notification poi color
    @Column(name = "u_poi_color", nullable = true, length = 7)
    private String uPoiColor;

    // Notification (UVEDOMLENIYE) == Zoi
    @Column(name = "u_zoi", nullable = true)
    private Boolean uZoi;

    // Notification zoi sound
    @Column(name = "u_zoi_sound", nullable = true)
    private Integer uZoiSound;

    // Notification zoi color
    @Column(name = "u_zoi_color", nullable = true, length = 7)
    private String uZoiColor;

    // Notification (UVEDOMLENIYE) == Audio Call
    @Column(name = "u_audiocall", nullable = true)
    private Boolean uAudioCall;

    // Notification audio call sound
    @Column(name = "u_audio_call_sound", nullable = true)
    private Integer uAudioCallSound;

    // Notification audio call color
    @Column(name = "u_audio_call_color", nullable = true, length = 7)
    private String uAudioCallColor;

    // Notification (UVEDOMLENIYE) == Door Open
    @Column(name = "u_dooropen", nullable = true)
    private Boolean uDoorOpen;

    // Notification door open sound
    @Column(name = "u_door_open_sound", nullable = true)
    private Integer uDoorOpenSound;

    // Notification door open color
    @Column(name = "u_door_open_color", nullable = true, length = 7)
    private String uDoorOpenColor;

    // Event (Sobitiye) == SOS button
    @Column(name = "s_sos", nullable = true)
    private Boolean sSos;

    // Event (Sobitiye) == Engine On (Zajiganiye)
    @Column(name = "s_engine", nullable = true)
    private Boolean sEngine;

    // Event (Sobitiye) == External power Off (Otkyucheniye pitaniya)
    @Column(name = "s_ext_power", nullable = true)
    private Boolean sExternalPower;

    // Event (Sobitiye) == Speed MIN
    @Column(name = "s_speed_min", nullable = true)
    private Boolean sSpeedMin;

    // Event (Sobitiye) == Speed MAX
    @Column(name = "s_speed_max", nullable = true)
    private Boolean sSpeedMax;

    // Event (Sobitiye) == Online
    @Column(name = "s_online", nullable = true)
    private Boolean sOnline;

    // Event (Sobitiye) == Staff (personal)
    @Column(name = "s_staff", nullable = true)
    private Boolean sStaff;

    // Event (Sobitiye) == Object Settings changed
    @Column(name = "s_settings", nullable = true)
    private Boolean sSettings;

    // Event (Sobitiye) == Poi
    @Column(name = "s_poi", nullable = true)
    private Boolean sPoi;

    // Event (Sobitiye) == Zoi
    @Column(name = "s_zoi", nullable = true)
    private Boolean sZoi;

    // Event (Sobitiye) == Audio Call
    @Column(name = "s_audiocall", nullable = true)
    private Boolean sAudioCall;

    // Event (Sobitiye) == Door Open
    @Column(name = "s_dooropen", nullable = true)
    private Boolean sDoorOpen;

    // Disturbance (Narusheniye) == SOS button
    @Column(name = "n_sos", nullable = true)
    private Boolean nSos;

    // Disturbance (Narusheniye) == Engine On (Zajiganiye)
    @Column(name = "n_engine", nullable = true)
    private Boolean nEngine;

    // Disturbance (Narusheniye) == External power Off (Otkyucheniye pitaniya)
    @Column(name = "n_ext_power", nullable = true)
    private Boolean nExternalPower;

    // Disturbance (Narusheniye) == Speed MIN
    @Column(name = "n_speed_min", nullable = true)
    private Boolean nSpeedMin;

    // Disturbance (Narusheniye) == Speed MAX
    @Column(name = "n_speed_max", nullable = true)
    private Boolean nSpeedMax;

    // Disturbance (Narusheniye) == Online
    @Column(name = "n_online", nullable = true)
    private Boolean nOnline;

    // Disturbance (Narusheniye) == Staff (personal)
//    @Column(name = "n_staff", nullable = true)
//    private Boolean nStaff;

    // Disturbance (Narusheniye) == Object Settings changed
//    @Column(name = "n_settings", nullable = true)
//    private Boolean nSettings;

    // Disturbance (Narusheniye) == Poi
    @Column(name = "n_poi", nullable = true)
    private Boolean nPoi;

    // Disturbance (Narusheniye) == Zoi
    @Column(name = "n_zoi", nullable = true)
    private Boolean nZoi;

    // Disturbance (Narusheniye) == Audio Call
    @Column(name = "n_audiocall", nullable = true)
    private Boolean nAudioCall;

    // Disturbance (Narusheniye) == Door Open
    @Column(name = "n_dooropen", nullable = true)
    private Boolean nDoorOpen;

    // send by E-mail == SOS button
    @Column(name = "e_sos", nullable = true)
    private Boolean eSos;

    // send by E-mail == Engine On (Zajiganiye)
    @Column(name = "e_engine", nullable = true)
    private Boolean eEngine;

    // send by E-mail == External Power Off (Otkyucheniye pitaniya)
    @Column(name = "e_ext_power", nullable = true)
    private Boolean eExternalPower;

    // send by E-mail == Speed MIN
    @Column(name = "e_speed_min", nullable = true)
    private Boolean eSpeedMin;

    // send by E-mail == Speed MAX
    @Column(name = "e_speed_max", nullable = true)
    private Boolean eSpeedMax;

    // send by E-mail == Online
    @Column(name = "e_online", nullable = true)
    private Boolean eOnline;

    // send by E-mail == Staff (personal)
    @Column(name = "e_staff", nullable = true)
    private Boolean eStaff;

    // send by E-mail == Object Settings changed
    @Column(name = "e_settings", nullable = true)
    private Boolean eSettings;

    // send by E-mail == Poi
    @Column(name = "e_poi", nullable = true)
    private Boolean ePoi;

    // send by E-mail == Zoi
    @Column(name = "e_zoi", nullable = true)
    private Boolean eZoi;

    // send by E-mail == Audio Call
    @Column(name = "e_audiocall", nullable = true)
    private Boolean eAudioCall;

    // send by E-mail == Door Open
    @Column(name = "e_dooropen", nullable = true)
    private Boolean eDoorOpen;

    // send by sMs == SOS button
    @Column(name = "m_sos", nullable = true)
    private Boolean mSos;

    // send by sMs == Engine On (Zajiganiye)
    @Column(name = "m_engine", nullable = true)
    private Boolean mEngine;

    // send by sMs == External power Off (Otkyucheniye pitaniya)
    @Column(name = "m_ext_power", nullable = true)
    private Boolean mExternalPower;

    // send by sMs == Speed MIN
    @Column(name = "m_speed_min", nullable = true)
    private Boolean mSpeedMin;

    // send by sMs == Speed MAX
    @Column(name = "m_speed_max", nullable = true)
    private Boolean mSpeedMax;

    // send by sMs == Online
    @Column(name = "m_online", nullable = true)
    private Boolean mOnline;

    // send by sMs == Staff (personal)
    @Column(name = "m_staff", nullable = true)
    private Boolean mStaff;

    // send by sMs == Object Settings changed
    @Column(name = "m_settings", nullable = true)
    private Boolean mSettings;

    // send by sMs == Poi
    @Column(name = "m_poi", nullable = true)
    private Boolean mPoi;

    // send by sMs == Zoi
    @Column(name = "m_zoi", nullable = true)
    private Boolean mZoi;

    // send by sMs == Audio Call
    @Column(name = "m_audiocall", nullable = true)
    private Boolean mAudioCall;

    // send by sMs == Door Open
    @Column(name = "m_dooropen", nullable = true)
    private Boolean mDoorOpen;

    @Column(name = "mn_status", nullable = false, length = 1)
    private String status;

    @Column(name = "mn_reg_date", nullable = true)
    private Timestamp regDate;

    @Column(name = "mn_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "mn_exp_date", nullable = true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public Boolean getPanicButton() {
        return panicButton;
    }

    public void setPanicButton(Boolean panicButton) {
        this.panicButton = panicButton;
    }

    public Integer getMinSpeed() {
        return minSpeed;
    }

    public void setMinSpeed(Integer minSpeed) {
        this.minSpeed = minSpeed;
    }

    public Integer getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(Integer maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public Boolean getSendSms() {
        return sendSms;
    }

    public void setSendSms(Boolean sendSms) {
        this.sendSms = sendSms;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Boolean getSendMail() {
        return sendMail;
    }

    public void setSendMail(Boolean sendMail) {
        this.sendMail = sendMail;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public Boolean getPopUpWindow() {
        return popUpWindow;
    }

    public void setPopUpWindow(Boolean popUpWindow) {
        this.popUpWindow = popUpWindow;
    }

    public Boolean getnPopUpWindow() {
        return nPopUpWindow;
    }

    public void setnPopUpWindow(Boolean nPopUpWindow) {
        this.nPopUpWindow = nPopUpWindow;
    }

    public Boolean getRegisterDatabase() {
        return registerDatabase;
    }

    public void setRegisterDatabase(Boolean registerDatabase) {
        this.registerDatabase = registerDatabase;
    }

    public Boolean getRegisterDatabaseViolation() {
        return registerDatabaseViolation;
    }

    public void setRegisterDatabaseViolation(Boolean registerDatabaseViolation) {
        this.registerDatabaseViolation = registerDatabaseViolation;
    }

    public Boolean getuSos() {
        return uSos;
    }

    public void setuSos(Boolean uSos) {
        this.uSos = uSos;
    }

    public Boolean getuEngine() {
        return uEngine;
    }

    public void setuEngine(Boolean uEngine) {
        this.uEngine = uEngine;
    }

    public Boolean getuSpeedMin() {
        return uSpeedMin;
    }

    public void setuSpeedMin(Boolean uSpeedMin) {
        this.uSpeedMin = uSpeedMin;
    }

    public Boolean getuSpeedMax() {
        return uSpeedMax;
    }

    public void setuSpeedMax(Boolean uSpeedMax) {
        this.uSpeedMax = uSpeedMax;
    }

    public Boolean getuOnline() {
        return uOnline;
    }

    public void setuOnline(Boolean uOnline) {
        this.uOnline = uOnline;
    }

    public Boolean getuStaff() {
        return uStaff;
    }

    public void setuStaff(Boolean uStaff) {
        this.uStaff = uStaff;
    }

    public Boolean getuSettings() {
        return uSettings;
    }

    public void setuSettings(Boolean uSettings) {
        this.uSettings = uSettings;
    }

    public Boolean getuPoi() {
        return uPoi;
    }

    public void setuPoi(Boolean uPoi) {
        this.uPoi = uPoi;
    }

    public Boolean getuZoi() {
        return uZoi;
    }

    public void setuZoi(Boolean uZoi) {
        this.uZoi = uZoi;
    }

    public Boolean getsSos() {
        return sSos;
    }

    public void setsSos(Boolean sSos) {
        this.sSos = sSos;
    }

    public Boolean getsEngine() {
        return sEngine;
    }

    public void setsEngine(Boolean sEngine) {
        this.sEngine = sEngine;
    }

    public Boolean getsSpeedMin() {
        return sSpeedMin;
    }

    public void setsSpeedMin(Boolean sSpeedMin) {
        this.sSpeedMin = sSpeedMin;
    }

    public Boolean getsSpeedMax() {
        return sSpeedMax;
    }

    public void setsSpeedMax(Boolean sSpeedMax) {
        this.sSpeedMax = sSpeedMax;
    }

    public Boolean getsOnline() {
        return sOnline;
    }

    public void setsOnline(Boolean sOnline) {
        this.sOnline = sOnline;
    }

    public Boolean getsStaff() {
        return sStaff;
    }

    public void setsStaff(Boolean sStaff) {
        this.sStaff = sStaff;
    }

    public Boolean getsSettings() {
        return sSettings;
    }

    public void setsSettings(Boolean sSettings) {
        this.sSettings = sSettings;
    }

    public Boolean getsPoi() {
        return sPoi;
    }

    public void setsPoi(Boolean sPoi) {
        this.sPoi = sPoi;
    }

    public Boolean getsZoi() {
        return sZoi;
    }

    public void setsZoi(Boolean sZoi) {
        this.sZoi = sZoi;
    }

    public Boolean getnSos() {
        return nSos;
    }

    public void setnSos(Boolean nSos) {
        this.nSos = nSos;
    }

    public Boolean getnEngine() {
        return nEngine;
    }

    public void setnEngine(Boolean nEngine) {
        this.nEngine = nEngine;
    }

    public Boolean getnSpeedMin() {
        return nSpeedMin;
    }

    public void setnSpeedMin(Boolean nSpeedMin) {
        this.nSpeedMin = nSpeedMin;
    }

    public Boolean getnSpeedMax() {
        return nSpeedMax;
    }

    public void setnSpeedMax(Boolean nSpeedMax) {
        this.nSpeedMax = nSpeedMax;
    }

    public Boolean getnOnline() {
        return nOnline;
    }

    public void setnOnline(Boolean nOnline) {
        this.nOnline = nOnline;
    }

    public Boolean getnPoi() {
        return nPoi;
    }

    public void setnPoi(Boolean nPoi) {
        this.nPoi = nPoi;
    }

    public Boolean getnZoi() {
        return nZoi;
    }

    public void setnZoi(Boolean nZoi) {
        this.nZoi = nZoi;
    }

    public Boolean geteSos() {
        return eSos;
    }

    public void seteSos(Boolean eSos) {
        this.eSos = eSos;
    }

    public Boolean geteEngine() {
        return eEngine;
    }

    public void seteEngine(Boolean eEngine) {
        this.eEngine = eEngine;
    }

    public Boolean geteSpeedMin() {
        return eSpeedMin;
    }

    public void seteSpeedMin(Boolean eSpeedMin) {
        this.eSpeedMin = eSpeedMin;
    }

    public Boolean geteSpeedMax() {
        return eSpeedMax;
    }

    public void seteSpeedMax(Boolean eSpeedMax) {
        this.eSpeedMax = eSpeedMax;
    }

    public Boolean geteOnline() {
        return eOnline;
    }

    public void seteOnline(Boolean eOnline) {
        this.eOnline = eOnline;
    }

    public Boolean geteStaff() {
        return eStaff;
    }

    public void seteStaff(Boolean eStaff) {
        this.eStaff = eStaff;
    }

    public Boolean geteSettings() {
        return eSettings;
    }

    public void seteSettings(Boolean eSettings) {
        this.eSettings = eSettings;
    }

    public Boolean getePoi() {
        return ePoi;
    }

    public void setePoi(Boolean ePoi) {
        this.ePoi = ePoi;
    }

    public Boolean geteZoi() {
        return eZoi;
    }

    public void seteZoi(Boolean eZoi) {
        this.eZoi = eZoi;
    }

    public Boolean getmSos() {
        return mSos;
    }

    public void setmSos(Boolean mSos) {
        this.mSos = mSos;
    }

    public Boolean getmEngine() {
        return mEngine;
    }

    public void setmEngine(Boolean mEngine) {
        this.mEngine = mEngine;
    }

    public Boolean getmSpeedMin() {
        return mSpeedMin;
    }

    public void setmSpeedMin(Boolean mSpeedMin) {
        this.mSpeedMin = mSpeedMin;
    }

    public Boolean getmSpeedMax() {
        return mSpeedMax;
    }

    public void setmSpeedMax(Boolean mSpeedMax) {
        this.mSpeedMax = mSpeedMax;
    }

    public Boolean getmOnline() {
        return mOnline;
    }

    public void setmOnline(Boolean mOnline) {
        this.mOnline = mOnline;
    }

    public Boolean getmStaff() {
        return mStaff;
    }

    public void setmStaff(Boolean mStaff) {
        this.mStaff = mStaff;
    }

    public Boolean getmSettings() {
        return mSettings;
    }

    public void setmSettings(Boolean mSettings) {
        this.mSettings = mSettings;
    }

    public Boolean getmPoi() {
        return mPoi;
    }

    public void setmPoi(Boolean mPoi) {
        this.mPoi = mPoi;
    }

    public Boolean getmZoi() {
        return mZoi;
    }

    public void setmZoi(Boolean mZoi) {
        this.mZoi = mZoi;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Boolean getuAudioCall() {
        return uAudioCall;
    }

    public void setuAudioCall(Boolean uAudioCall) {
        this.uAudioCall = uAudioCall;
    }

    public Boolean getuDoorOpen() {
        return uDoorOpen;
    }

    public void setuDoorOpen(Boolean uDoorOpen) {
        this.uDoorOpen = uDoorOpen;
    }

    public Boolean getsAudioCall() {
        return sAudioCall;
    }

    public void setsAudioCall(Boolean sAudioCall) {
        this.sAudioCall = sAudioCall;
    }

    public Boolean getsDoorOpen() {
        return sDoorOpen;
    }

    public void setsDoorOpen(Boolean sDoorOpen) {
        this.sDoorOpen = sDoorOpen;
    }

    public Boolean getnAudioCall() {
        return nAudioCall;
    }

    public void setnAudioCall(Boolean nAudioCall) {
        this.nAudioCall = nAudioCall;
    }

    public Boolean getnDoorOpen() {
        return nDoorOpen;
    }

    public void setnDoorOpen(Boolean nDoorOpen) {
        this.nDoorOpen = nDoorOpen;
    }

    public Boolean geteAudioCall() {
        return eAudioCall;
    }

    public void seteAudioCall(Boolean eAudioCall) {
        this.eAudioCall = eAudioCall;
    }

    public Boolean geteDoorOpen() {
        return eDoorOpen;
    }

    public void seteDoorOpen(Boolean eDoorOpen) {
        this.eDoorOpen = eDoorOpen;
    }

    public Boolean getmAudioCall() {
        return mAudioCall;
    }

    public void setmAudioCall(Boolean mAudioCall) {
        this.mAudioCall = mAudioCall;
    }

    public Boolean getmDoorOpen() {
        return mDoorOpen;
    }

    public void setmDoorOpen(Boolean mDoorOpen) {
        this.mDoorOpen = mDoorOpen;
    }

    public Integer getuSosSound() {
        return uSosSound;
    }

    public void setuSosSound(Integer uSosSound) {
        this.uSosSound = uSosSound;
    }

    public String getuSosColor() {
        return uSosColor;
    }

    public void setuSosColor(String uSosColor) {
        this.uSosColor = uSosColor;
    }

    public Integer getuEngineSound() {
        return uEngineSound;
    }

    public void setuEngineSound(Integer uEngineSound) {
        this.uEngineSound = uEngineSound;
    }

    public String getuEngineColor() {
        return uEngineColor;
    }

    public void setuEngineColor(String uEngineColor) {
        this.uEngineColor = uEngineColor;
    }

    public Integer getuSpeedMinSound() {
        return uSpeedMinSound;
    }

    public void setuSpeedMinSound(Integer uSpeedMinSound) {
        this.uSpeedMinSound = uSpeedMinSound;
    }

    public String getuSpeedMinColor() {
        return uSpeedMinColor;
    }

    public void setuSpeedMinColor(String uSpeedMinColor) {
        this.uSpeedMinColor = uSpeedMinColor;
    }

    public Integer getuSpeedMaxSound() {
        return uSpeedMaxSound;
    }

    public void setuSpeedMaxSound(Integer uSpeedMaxSound) {
        this.uSpeedMaxSound = uSpeedMaxSound;
    }

    public String getuSpeedMaxColor() {
        return uSpeedMaxColor;
    }

    public void setuSpeedMaxColor(String uSpeedMaxColor) {
        this.uSpeedMaxColor = uSpeedMaxColor;
    }

    public Integer getuOnlineSound() {
        return uOnlineSound;
    }

    public void setuOnlineSound(Integer uOnlineSound) {
        this.uOnlineSound = uOnlineSound;
    }

    public String getuOnlineColor() {
        return uOnlineColor;
    }

    public void setuOnlineColor(String uOnlineColor) {
        this.uOnlineColor = uOnlineColor;
    }

    public Integer getuStaffSound() {
        return uStaffSound;
    }

    public void setuStaffSound(Integer uStaffSound) {
        this.uStaffSound = uStaffSound;
    }

    public String getuStaffColor() {
        return uStaffColor;
    }

    public void setuStaffColor(String uStaffColor) {
        this.uStaffColor = uStaffColor;
    }

    public Integer getuSettingsSound() {
        return uSettingsSound;
    }

    public void setuSettingsSound(Integer uSettingsSound) {
        this.uSettingsSound = uSettingsSound;
    }

    public String getuSettingsColor() {
        return uSettingsColor;
    }

    public void setuSettingsColor(String uSettingsColor) {
        this.uSettingsColor = uSettingsColor;
    }

    public Integer getuPoiSound() {
        return uPoiSound;
    }

    public void setuPoiSound(Integer uPoiSound) {
        this.uPoiSound = uPoiSound;
    }

    public String getuPoiColor() {
        return uPoiColor;
    }

    public void setuPoiColor(String uPoiColor) {
        this.uPoiColor = uPoiColor;
    }

    public Integer getuZoiSound() {
        return uZoiSound;
    }

    public void setuZoiSound(Integer uZoiSound) {
        this.uZoiSound = uZoiSound;
    }

    public String getuZoiColor() {
        return uZoiColor;
    }

    public void setuZoiColor(String uZoiColor) {
        this.uZoiColor = uZoiColor;
    }

    public Integer getuAudioCallSound() {
        return uAudioCallSound;
    }

    public void setuAudioCallSound(Integer uAudioCallSound) {
        this.uAudioCallSound = uAudioCallSound;
    }

    public String getuAudioCallColor() {
        return uAudioCallColor;
    }

    public void setuAudioCallColor(String uAudioCallColor) {
        this.uAudioCallColor = uAudioCallColor;
    }

    public Integer getuDoorOpenSound() {
        return uDoorOpenSound;
    }

    public void setuDoorOpenSound(Integer uDoorOpenSound) {
        this.uDoorOpenSound = uDoorOpenSound;
    }

    public String getuDoorOpenColor() {
        return uDoorOpenColor;
    }

    public void setuDoorOpenColor(String uDoorOpenColor) {
        this.uDoorOpenColor = uDoorOpenColor;
    }

    public Boolean getuExternalPower() {
        return uExternalPower;
    }

    public void setuExternalPower(Boolean uExternalPower) {
        this.uExternalPower = uExternalPower;
    }

    public Integer getuExternalPowerSound() {
        return uExternalPowerSound;
    }

    public void setuExternalPowerSound(Integer uExternalPowerSound) {
        this.uExternalPowerSound = uExternalPowerSound;
    }

    public String getuExternalPowerColor() {
        return uExternalPowerColor;
    }

    public void setuExternalPowerColor(String uExternalPowerColor) {
        this.uExternalPowerColor = uExternalPowerColor;
    }

    public Boolean getsExternalPower() {
        return sExternalPower;
    }

    public void setsExternalPower(Boolean sExternalPower) {
        this.sExternalPower = sExternalPower;
    }

    public Boolean getnExternalPower() {
        return nExternalPower;
    }

    public void setnExternalPower(Boolean nExternalPower) {
        this.nExternalPower = nExternalPower;
    }

    public Boolean geteExternalPower() {
        return eExternalPower;
    }

    public void seteExternalPower(Boolean eExternalPower) {
        this.eExternalPower = eExternalPower;
    }

    public Boolean getmExternalPower() {
        return mExternalPower;
    }

    public void setmExternalPower(Boolean mExternalPower) {
        this.mExternalPower = mExternalPower;
    }

    public String getMailSecond() {
        return mailSecond;
    }

    public void setMailSecond(String mailSecond) {
        this.mailSecond = mailSecond;
    }

    public String getMailThird() {
        return mailThird;
    }

    public void setMailThird(String mailThird) {
        this.mailThird = mailThird;
    }

    @Override
    public String toString() {
        return "MObjectNotifications{" +
                "id=" + id +
                ", mObjectId=" + mObjectId +
                ", panicButton=" + panicButton +
                ", minSpeed=" + minSpeed +
                ", maxSpeed=" + maxSpeed +
                ", sendSms=" + sendSms +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", sendMail=" + sendMail +
                ", mail='" + mail + '\'' +
                ", mailSecond='" + mailSecond + '\'' +
                ", mailThird='" + mailThird + '\'' +
                ", popUpWindow=" + popUpWindow +
                ", nPopUpWindow=" + nPopUpWindow +
                ", registerDatabase=" + registerDatabase +
                ", registerDatabaseViolation=" + registerDatabaseViolation +
                ", uSos=" + uSos +
                ", uEngine=" + uEngine +
                ", uSpeedMin=" + uSpeedMin +
                ", uSpeedMax=" + uSpeedMax +
                ", uOnline=" + uOnline +
                ", uStaff=" + uStaff +
                ", uSettings=" + uSettings +
                ", uPoi=" + uPoi +
                ", uZoi=" + uZoi +
                ", uAudioCall=" + uAudioCall +
                ", uDoorOpen=" + uDoorOpen +
                ", sSos=" + sSos +
                ", sEngine=" + sEngine +
                ", sSpeedMin=" + sSpeedMin +
                ", sSpeedMax=" + sSpeedMax +
                ", sOnline=" + sOnline +
                ", sStaff=" + sStaff +
                ", sSettings=" + sSettings +
                ", sPoi=" + sPoi +
                ", sZoi=" + sZoi +
                ", sAudioCall=" + sAudioCall +
                ", sDoorOpen=" + sDoorOpen +
                ", nSos=" + nSos +
                ", nEngine=" + nEngine +
                ", nSpeedMin=" + nSpeedMin +
                ", nSpeedMax=" + nSpeedMax +
                ", nOnline=" + nOnline +
                ", nPoi=" + nPoi +
                ", nZoi=" + nZoi +
                ", nAudioCall=" + nAudioCall +
                ", nDoorOpen=" + nDoorOpen +
                ", eSos=" + eSos +
                ", eEngine=" + eEngine +
                ", eSpeedMin=" + eSpeedMin +
                ", eSpeedMax=" + eSpeedMax +
                ", eOnline=" + eOnline +
                ", eStaff=" + eStaff +
                ", eSettings=" + eSettings +
                ", ePoi=" + ePoi +
                ", eZoi=" + eZoi +
                ", eAudioCall=" + eAudioCall +
                ", eDoorOpen=" + eDoorOpen +
                ", mSos=" + mSos +
                ", mEngine=" + mEngine +
                ", mSpeedMin=" + mSpeedMin +
                ", mSpeedMax=" + mSpeedMax +
                ", mOnline=" + mOnline +
                ", mStaff=" + mStaff +
                ", mSettings=" + mSettings +
                ", mPoi=" + mPoi +
                ", mZoi=" + mZoi +
                ", mAudioCall=" + mAudioCall +
                ", mDoorOpen=" + mDoorOpen +
                ", uExternalPower=" + uExternalPower +
                ", sExternalPower=" + sExternalPower +
                ", nExternalPower=" + nExternalPower +
                ", eExternalPower=" + eExternalPower +
                ", mExternalPower=" + mExternalPower +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
