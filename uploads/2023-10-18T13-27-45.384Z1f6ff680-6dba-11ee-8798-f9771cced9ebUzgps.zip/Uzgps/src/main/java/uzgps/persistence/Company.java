package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "uzgps_company")
public class Company implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_COMPANY_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @Column(name = "address", nullable = false, length = 255)
    private String address;

    @Column(name = "email", nullable = true, length = 100)
    private String email;

    @Column(name = "phone_mobile", nullable = true, length = 100)
    private String phoneMobile;

    @Column(name = "phone_line", nullable = true, length = 100)
    private String phoneLine;

    @Column(name = "settlement_account", nullable = true, length = 100)
    private String settlementAccount;

    @Column(name = "bank_details", nullable = true, length = 100)
    private String bankDetails;

    @Column(name = "okonh", nullable = true, length = 100)
    private String okonh;

    @Column(name = "inn", nullable = true, length = 100)
    private String inn;

    @Column(name = "contact", nullable = true, length = 100)
    private String contact;

    @Column(name = "contact_phone_mobile", nullable = true, length = 100)
    private String contactPhoneMobile;

    @Column(name = "contact_email", nullable = true, length = 100)
    private String contactEmail;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneMobile() {
        return phoneMobile;
    }

    public void setPhoneMobile(String phoneMobile) {
        this.phoneMobile = phoneMobile;
    }

    public String getPhoneLine() {
        return phoneLine;
    }

    public void setPhoneLine(String phoneLine) {
        this.phoneLine = phoneLine;
    }

    public String getSettlementAccount() {
        return settlementAccount;
    }

    public void setSettlementAccount(String settlementAccount) {
        this.settlementAccount = settlementAccount;
    }

    public String getBankDetails() {
        return bankDetails;
    }

    public void setBankDetails(String bankDetails) {
        this.bankDetails = bankDetails;
    }

    public String getOkonh() {
        return okonh;
    }

    public void setOkonh(String okonh) {
        this.okonh = okonh;
    }

    public String getInn() {
        return inn;
    }

    public void setInn(String inn) {
        this.inn = inn;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContactPhoneMobile() {
        return contactPhoneMobile;
    }

    public void setContactPhoneMobile(String contactPhoneMobile) {
        this.contactPhoneMobile = contactPhoneMobile;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    @Override
    public String toString() {
        return "Company{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", email='" + email + '\'' +
                ", phoneMobile='" + phoneMobile + '\'' +
                ", phoneLine='" + phoneLine + '\'' +
                ", settlementAccount='" + settlementAccount + '\'' +
                ", bankDetails='" + bankDetails + '\'' +
                ", okonh='" + okonh + '\'' +
                ", inn='" + inn + '\'' +
                ", contact='" + contact + '\'' +
                ", contactPhoneMobile='" + contactPhoneMobile + '\'' +
                ", contactEmail='" + contactEmail + '\'' +
                '}';
    }
}
