package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


@Entity
@Table(name = "uzgps_mobject_staff")
public class MObjectStaff implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_STAFF_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "mobject_id", nullable=false, insertable = false, updatable = false)
    private Long mobjectId;
    @ManyToOne
    @JoinColumn(name = "mobject_id")
    private MObject mObject;

    @Column(name = "staff_id", nullable=false)
    private Long staffId;

    @Column(name = "so_start_date", nullable=false)
    private Timestamp startDate;

    @Column(name = "so_end_date", nullable=true)
    private Timestamp endDate;

    @Column(name = "so_endless", nullable=true)
    private Boolean endless;

    @Column(name = "so_status", nullable = false, length = 1)
    private String status;

    @Column(name = "so_reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "so_mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "so_exp_date", nullable=true)
    private Timestamp expDate;

    @Transient
    private String staffName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }

    public MObject getmObject() {
        return mObject;
    }

    public void setmObject(MObject mObject) {
        this.mObject = mObject;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public Timestamp getStartDate() {
        return startDate;
    }
    public String getStartDateToFormat() {
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        return df.format(startDate);
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public String getEndDateToFormat() {
        if(endDate != null)  {
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        return df.format(endDate);
        }
        else
        return "";
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public Boolean getEndless() {
        return endless;
    }

    public void setEndless(Boolean endless) {
        this.endless = endless;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }
}