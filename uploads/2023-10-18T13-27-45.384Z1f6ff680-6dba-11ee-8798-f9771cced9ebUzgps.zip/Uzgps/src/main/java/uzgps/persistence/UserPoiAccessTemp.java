package uzgps.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(schema = "reporting")
public class UserPoiAccessTemp {

    @Id private Long id;

    private Long aid;

    private Long user_id;

    private Long poi_id;

    private Integer permission;

    private String poi_name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAid() {
        return aid;
    }

    public void setAid(Long aid) {
        this.aid = aid;
    }

    public Long getPoi_id() {
        return poi_id;
    }

    public void setPoi_id(Long mobjectID) {
        this.poi_id = mobjectID;
    }

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public Integer getPermission() {
        return permission;
    }

    public void setPermission(Integer per) {
        this.permission = per;
    }

    public String getPoi_name() {
        return poi_name;
    }

    public void setPoi_name(String mobjectName) {
        this.poi_name = mobjectName;
    }
}
