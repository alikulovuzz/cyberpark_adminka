package uzgps.persistence;


import org.hibernate.annotations.WhereJoinTable;
import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "uzgps_sim")

public class Sim implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_SIM_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "s_phone", nullable = false, length = 20)
    private String simPhone;

    @OneToMany
    @JoinTable(
            name="uzgps_gps_unit_sim",
            joinColumns = @JoinColumn(name="gus_sim_id"),
            inverseJoinColumns = @JoinColumn(name="gus_gps_unit_id")
    )
    @WhereJoinTable(clause = "gus_status='A'")
    private List<GPSUnit> gpsUnitList;

    @Column(name = "s_status", nullable = false, length = 1)
    private String status;

    @Column(name = "s_reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "s_mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "s_exp_date", nullable=true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSimPhone() {
        return simPhone;
    }

    public void setSimPhone(String simPhone) {
        this.simPhone = simPhone;
    }

    public List<GPSUnit> getGpsUnitList() {
        return gpsUnitList;
    }

    public void setGpsUnitList(List<GPSUnit> gpsUnitList) {
        this.gpsUnitList = gpsUnitList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {


        return "Sim{" +
                "id=" + id +
                ", simPhone='" + simPhone + '\'' +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
