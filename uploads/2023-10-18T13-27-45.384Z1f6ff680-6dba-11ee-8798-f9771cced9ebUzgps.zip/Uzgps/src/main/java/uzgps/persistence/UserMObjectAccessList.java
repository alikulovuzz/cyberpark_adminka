package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "uzgps_user_mobject_access_list")
public class UserMObjectAccessList implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_USER_MOBJECT_ACCESS_LIST_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "mobject_id", nullable = false, insertable = false, updatable = false)
    private Long mObjectId;
    @ManyToOne
    @JoinColumn(name = "mobject_id")
    private MObject mObject;

    @Column(name = "permission", nullable = false)
    private Integer permission;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public MObject getmObject() {
        return mObject;
    }

    public void setmObject(MObject mObject) {
        this.mObject = mObject;
    }

    public Integer getPermission() {
        return permission;
    }

    public void setPermission(Integer permission) {
        this.permission = permission;
    }
}
