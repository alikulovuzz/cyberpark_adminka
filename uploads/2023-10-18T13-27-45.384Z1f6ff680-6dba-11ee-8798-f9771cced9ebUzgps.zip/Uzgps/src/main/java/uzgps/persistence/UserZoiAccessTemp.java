package uzgps.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(schema = "reporting")
public class UserZoiAccessTemp {

    @Id private Long id;

    private Long aid;

    private Long user_id;

    private Long zoi_id;

    private Integer permission;

    private String zoi_name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAid() {
        return aid;
    }

    public void setAid(Long aid) {
        this.aid = aid;
    }

    public Long getZoi_id() {
        return zoi_id;
    }

    public void setZoi_id(Long mobjectID) {
        this.zoi_id = mobjectID;
    }

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public Integer getPermission() {
        return permission;
    }

    public void setPermission(Integer per) {
        this.permission = per;
    }

    public String getZoi_name() {
        return zoi_name;
    }

    public void setZoi_name(String mobjectName) {
        this.zoi_name = mobjectName;
    }
}
