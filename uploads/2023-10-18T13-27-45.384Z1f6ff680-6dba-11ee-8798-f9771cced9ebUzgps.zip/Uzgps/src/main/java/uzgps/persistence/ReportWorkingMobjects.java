package uzgps.persistence;

import org.hibernate.annotations.Immutable;
import uzgps.excel.tripReports.AbstractTripItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Immutable
@Table(schema = "reporting")
public class ReportWorkingMobjects extends AbstractTripItem implements Serializable {

    @Id
    private Long id;

    @Column(name = "contract_name")
    private String contractName;

    @Column(name = "trip_name")
    private String tripName;

    @Column(name = "trip_ab")
    private String tripDirection;

    @Column(name = "count_mobject")
    private Integer countMobject;

    @Column(name = "trip_period_p6")
    private Integer tripPeriodP6;

    @Column(name = "trip_period_f6")
    private Integer tripPeriodF6;

    @Column(name = "trip_period_p8")
    private Integer tripPeriodP8;

    @Column(name = "trip_period_f8")
    private Integer tripPeriodF8;

    @Column(name = "trip_period_p3")
    private Integer tripPeriodP3;

    @Column(name = "trip_period_f3")
    private Integer tripPeriodF3;

    @Column(name = "trip_period_p14")
    private Integer tripPeriodP14;

    @Column(name = "trip_period_f14")
    private Integer tripPeriodF14;

    @Column(name = "trip_period_p17")
    private Integer tripPeriodP17;

    @Column(name = "trip_period_f17")
    private Integer tripPeriodF17;

    @Column(name = "trip_period_p19")
    private Integer tripPeriodP19;

    @Column(name = "trip_period_f19")
    private Integer tripPeriodF19;

    @Column(name = "trip_period_p21")
    private Integer tripPeriodP21;

    @Column(name = "trip_period_f21")
    private Integer tripPeriodF21;

    @Column(name = "trip_period_p23")
    private Integer tripPeriodP23;

    @Column(name = "trip_period_f23")
    private Integer tripPeriodF23;

    @Column(name = "violations_count")
    private Integer violationsCount;

    @Column(name = "trip_period_pAll")
    private Integer tripPeriodPAll;

    @Column(name = "trip_period_fAll")
    private Integer tripPeriodFAll;

    @Column(name = "all_routes_percent")
    private Double allRoutesPercent;

    @Column(name = "trips_without_violation_percent")
    private Double tripsWithoutViolationPercent;

    @Column(name = "trips_with_violation_percent")
    private Double tripsWithViolationPercent;

    @Column(name = "late_routes_count")
    private Integer lateRoutesCount;

    @Column(name = "late_routes_percent")
    private Double lateRoutesPercent;

    @Column(name = "count_trips_300")
    private Integer countTripsNotFinished;

    @Column(name = "routes_late_times")
    private Timestamp routesLateTimes;

    @Column(name = "all_route_exit_count")
    private Integer allRouteExitCount;

    @Column(name = "all_route_return_count")
    private Integer allRouteReturnCount;

    ///////////////////////////////////////////////////////////////////////////


    public String getContractName() {
        return contractName;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    @Override
    public String getTripName() {
        return tripName;
    }

    @Override
    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    @Override
    public String getTripDirection() {
        return tripDirection;
    }

    @Override
    public void setTripDirection(String tripDirection) {
        this.tripDirection = tripDirection;
    }

    public Integer getCountMobject() {
        return countMobject;
    }

    public void setCountMobject(Integer countMobject) {
        this.countMobject = countMobject;
    }

    public Integer getTripPeriodP6() {
        return tripPeriodP6;
    }

    public void setTripPeriodP6(Integer tripPeriodP6) {
        this.tripPeriodP6 = tripPeriodP6;
    }

    public Integer getTripPeriodF6() {
        return tripPeriodF6;
    }

    public void setTripPeriodF6(Integer tripPeriodF6) {
        this.tripPeriodF6 = tripPeriodF6;
    }

    public Integer getTripPeriodP8() {
        return tripPeriodP8;
    }

    public void setTripPeriodP8(Integer tripPeriodP8) {
        this.tripPeriodP8 = tripPeriodP8;
    }

    public Integer getTripPeriodF8() {
        return tripPeriodF8;
    }

    public void setTripPeriodF8(Integer tripPeriodF8) {
        this.tripPeriodF8 = tripPeriodF8;
    }

    public Integer getTripPeriodP3() {
        return tripPeriodP3;
    }

    public void setTripPeriodP3(Integer tripPeriodP3) {
        this.tripPeriodP3 = tripPeriodP3;
    }

    public Integer getTripPeriodF3() {
        return tripPeriodF3;
    }

    public void setTripPeriodF3(Integer tripPeriodF3) {
        this.tripPeriodF3 = tripPeriodF3;
    }

    public Integer getTripPeriodP14() {
        return tripPeriodP14;
    }

    public void setTripPeriodP14(Integer tripPeriodP14) {
        this.tripPeriodP14 = tripPeriodP14;
    }

    public Integer getTripPeriodF14() {
        return tripPeriodF14;
    }

    public void setTripPeriodF14(Integer tripPeriodF14) {
        this.tripPeriodF14 = tripPeriodF14;
    }

    public Integer getTripPeriodP17() {
        return tripPeriodP17;
    }

    public void setTripPeriodP17(Integer tripPeriodP17) {
        this.tripPeriodP17 = tripPeriodP17;
    }

    public Integer getTripPeriodF17() {
        return tripPeriodF17;
    }

    public void setTripPeriodF17(Integer tripPeriodF17) {
        this.tripPeriodF17 = tripPeriodF17;
    }

    public Integer getTripPeriodP19() {
        return tripPeriodP19;
    }

    public void setTripPeriodP19(Integer tripPeriodP19) {
        this.tripPeriodP19 = tripPeriodP19;
    }

    public Integer getTripPeriodF19() {
        return tripPeriodF19;
    }

    public void setTripPeriodF19(Integer tripPeriodF19) {
        this.tripPeriodF19 = tripPeriodF19;
    }

    public Integer getTripPeriodP21() {
        return tripPeriodP21;
    }

    public void setTripPeriodP21(Integer tripPeriodP21) {
        this.tripPeriodP21 = tripPeriodP21;
    }

    public Integer getTripPeriodF21() {
        return tripPeriodF21;
    }

    public void setTripPeriodF21(Integer tripPeriodF21) {
        this.tripPeriodF21 = tripPeriodF21;
    }

    public Integer getTripPeriodP23() {
        return tripPeriodP23;
    }

    public void setTripPeriodP23(Integer tripPeriodP23) {
        this.tripPeriodP23 = tripPeriodP23;
    }

    public Integer getTripPeriodF23() {
        return tripPeriodF23;
    }

    public void setTripPeriodF23(Integer tripPeriod23) {
        this.tripPeriodF23 = tripPeriod23;
    }

    public Integer getViolationsCount() {
        return violationsCount;
    }

    public void setViolationsCount(Integer violationsCount) {
        this.violationsCount = violationsCount;
    }

    public Integer getTripPeriodPAll() {
        return tripPeriodPAll;
    }

    public void setTripPeriodPAll(Integer tripPeriodAll) {
        this.tripPeriodPAll = tripPeriodAll;
    }

    public Integer getTripPeriodFAll() {
        return tripPeriodFAll;
    }

    public void setTripPeriodFAll(Integer tripPeriodFAll) {
        this.tripPeriodFAll = tripPeriodFAll;
    }

    public Double getAllRoutesPercent() {
        return allRoutesPercent;
    }

    public void setAllRoutesPercent(Double allRoutesPercent) {
        this.allRoutesPercent = allRoutesPercent;
    }

    public Double getTripsWithViolationPercent() {
        return tripsWithViolationPercent;
    }

    public void setTripsWithViolationPercent(Double tripsWithViolationPercent) {
        this.tripsWithViolationPercent = tripsWithViolationPercent;
    }

    public Double getTripsWithoutViolationPercent() {
        return tripsWithoutViolationPercent;
    }

    public void setTripsWithoutViolationPercent(Double tripsWithoutViolationPercent) {
        this.tripsWithoutViolationPercent = tripsWithoutViolationPercent;
    }

    public Integer getLateRoutesCount() {
        return lateRoutesCount;
    }

    public void setLateRoutesCount(Integer lateroutesCount) {
        this.lateRoutesCount = lateroutesCount;
    }

    public Double getLateRoutesPercent() {
        return lateRoutesPercent;
    }

    public void setLateRoutesPercent(Double lateRoutesPercent) {
        this.lateRoutesPercent = lateRoutesPercent;
    }

    public Integer getCountTripsNotFinished() {
        return countTripsNotFinished;
    }

    public void setCountTripsNotFinished(Integer countTripsNotFinished) {
        this.countTripsNotFinished = countTripsNotFinished;
    }

    public Timestamp getRoutesLateTimes() {
        return routesLateTimes;
    }

    public void setRoutesLateTimes(Timestamp routesLateTimes) {
        this.routesLateTimes = routesLateTimes;
    }

    public Integer getAllRouteExitCount() {
        return allRouteExitCount;
    }

    public void setAllRouteExitCount(Integer allRoute_exitCount) {
        this.allRouteExitCount = allRoute_exitCount;
    }

    public Integer getAllRouteReturnCount() {
        return allRouteReturnCount;
    }

    public void setAllRouteReturnCount(Integer allRouteReturnCount) {
        this.allRouteReturnCount = allRouteReturnCount;
    }

    @Override
    public String toString() {
        return "ReportWorkingMobjects{" +
                "id=" + id +
                ", contractName='" + contractName + '\'' +
                ", tripName='" + tripName + '\'' +
                ", tripDirection='" + tripDirection + '\'' +
                ", countMobject=" + countMobject +
                ", tripPeriodP6=" + tripPeriodP6 +
                ", tripPeriodF6=" + tripPeriodF6 +
                ", tripPeriodP8=" + tripPeriodP8 +
                ", tripPeriodF8=" + tripPeriodF8 +
                ", tripPeriodP3=" + tripPeriodP3 +
                ", tripPeriodF3=" + tripPeriodF3 +
                ", tripPeriodP14=" + tripPeriodP14 +
                ", tripPeriodF14=" + tripPeriodF14 +
                ", tripPeriodP17=" + tripPeriodP17 +
                ", tripPeriodF17=" + tripPeriodF17 +
                ", tripPeriodP19=" + tripPeriodP19 +
                ", tripPeriodF19=" + tripPeriodF19 +
                ", tripPeriodP21=" + tripPeriodP21 +
                ", tripPeriodF21=" + tripPeriodF21 +
                ", tripPeriodP23=" + tripPeriodP23 +
                ", tripPeriodF23=" + tripPeriodF23 +
                ", violationsCount=" + violationsCount +
                ", tripPeriodPAll=" + tripPeriodPAll +
                ", tripPeriodFAll=" + tripPeriodFAll +
                ", allRoutesPercent=" + allRoutesPercent +
                ", tripsWithViolationPercent=" + tripsWithViolationPercent +
                ", tripsWithoutViolationPercent=" + tripsWithoutViolationPercent +
                ", lateRoutesCount=" + lateRoutesCount +
                ", lateRoutesPercent=" + lateRoutesPercent +
                ", countTrips400=" + countTripsNotFinished +
                ", routesLateTimes=" + routesLateTimes +
                ", allRoute_exitCount=" + allRouteExitCount +
                ", allRouteReturnCount=" + allRouteReturnCount +
                '}';
    }
}
