package uzgps.persistence;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "uzgps_gps_unit_sim")
//@Table(name = "uzgps_gps_unit_sim", uniqueConstraints = {@UniqueConstraint(columnNames = {"gus_gps_unit_id", "gus_status"}),
//        @UniqueConstraint(columnNames = {"gus_sim_id", "gus_status"})})
public class GPSUnitSim implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_GPS_UNIT_SIM_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "gus_sim_id", nullable = false, insertable = false, updatable = false)
    private Long simId;
    @ManyToOne
    @JoinColumn(name = "gus_sim_id")
    private Sim sim;

    @Basic
    @Column(name = "gus_sim_2_id", nullable = false, insertable = false, updatable = false)
    private Long sim2Id;
    @ManyToOne
    @JoinColumn(name = "gus_sim_2_id")
    private Sim sim2;

    @Basic
    @Column(name = "gus_gps_unit_id", nullable = false, insertable = false, updatable = false)
    private Long gpsUnitId;
    @ManyToOne
    @JoinColumn(name = "gus_gps_unit_id")
    public GPSUnit gpsUnit;

    @Column(name = "gus_status", nullable = false, length = 1)
    private String status;

    @Column(name = "gus_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "gus_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "gus_exp_date", nullable = true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSimId() {
        return simId;
    }

    public void setSimId(Long simId) {
        this.simId = simId;
    }

    public Sim getSim() {
        return sim;
    }

    public void setSim(Sim sim) {
        this.sim = sim;
    }


    public Long getSim2Id() {
        return sim2Id;
    }

    public void setSim2Id(Long sim2Id) {
        this.sim2Id = sim2Id;
    }

    public Sim getSim2() {
        return sim2;
    }

    public void setSim2(Sim sim2) {
        this.sim2 = sim2;
    }

    public Long getGpsUnitId() {
        return gpsUnitId;
    }

    public void setGpsUnitId(Long gpsUnitId) {
        this.gpsUnitId = gpsUnitId;
    }

    public GPSUnit getGpsUnit() {
        return gpsUnit;
    }

    public void setGpsUnit(GPSUnit gpsUnit) {
        this.gpsUnit = gpsUnit;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "GPSUnitSim{" +
                "id=" + id +
                ", simId=" + simId +
                ", gpsUnitId=" + gpsUnitId +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
