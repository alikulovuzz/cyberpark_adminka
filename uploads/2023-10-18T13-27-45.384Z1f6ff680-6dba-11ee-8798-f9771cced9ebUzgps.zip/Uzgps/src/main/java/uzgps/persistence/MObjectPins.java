package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by G'ayrat on 20.03.15.
 */
@Entity
@Table(name = "uzgps_mobject_pins")
public class MObjectPins implements Serializable {

    public static final int ICON_TYPE_NONE = 0;
    public static final int ICON_TYPE_BASE = 1;
    public static final int ICON_TYPE_MASK = 2;
    public static final int ICON_TYPE_TEXT = 4;

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_PINS_ID";
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "icon_base")
    private String iconBase;

    @Column(name = "icon_mask")
    private String iconMask;

    @Column(name = "color_base")
    private String colorBase;

    @Column(name = "color_base_inner")
    private String colorBaseInner;

    @Column(name = "color_base_contour")
    private String colorBaseContour;

    @Column(name = "color_mask")
    private String colorMask;

    @Column(name = "inner_text")
    private String text;

    @Column(name = "icon_type", columnDefinition = "0")
    private Integer iconType;

    @Column(name = "priority", columnDefinition = "100")
    private Integer priority;

    @Column(name = "status")
    private String status;

    @Column(name = "reg_date")
    private Timestamp regDate;

    @Column(name = "mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "exp_date", nullable = true)
    private Timestamp expDate;

    @Transient
    private Integer maskRotate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public String getIconBase() {
        return iconBase;
    }

    public void setIconBase(String iconBase) {
        this.iconBase = iconBase;
    }

    public String getIconMask() {
        return iconMask;
    }

    public void setIconMask(String iconMask) {
        this.iconMask = iconMask;
    }

    public String getColorBase() {
        return colorBase;
    }

    public void setColorBase(String colorBase) {
        this.colorBase = colorBase;
    }

    public String getColorBaseInner() {
        return colorBaseInner;
    }

    public void setColorBaseInner(String colorBaseInner) {
        this.colorBaseInner = colorBaseInner;
    }

    public String getColorBaseContour() {
        return colorBaseContour;
    }

    public void setColorBaseContour(String colorBaseContour) {
        this.colorBaseContour = colorBaseContour;
    }

    public String getColorMask() {
        return colorMask;
    }

    public void setColorMask(String colorMask) {
        this.colorMask = colorMask;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer getIconType() {
        return iconType;
    }

    public void setIconType(Integer baseIcon) {
        this.iconType = baseIcon;
    }

    public Integer getMaskRotate() {
        return maskRotate;
    }

    public void setMaskRotate(Integer maskRotate) {
        this.maskRotate = maskRotate;
    }

    @Override
    public String toString() {
        return "MObjectPins{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", iconBase='" + iconBase + '\'' +
                ", iconMask='" + iconMask + '\'' +
                ", colorBase='" + colorBase + '\'' +
                ", colorBaseInner='" + colorBaseInner + '\'' +
                ", colorBaseContour='" + colorBaseContour + '\'' +
                ", colorMask='" + colorMask + '\'' +
                ", text='" + text + '\'' +
                ", iconType=" + iconType +
                ", priority=" + priority +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                ", maskRotate=" + maskRotate +
                '}';
    }
}
