package uzgps.persistence;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


@Entity
@Table(name = "uzgps_poi_group")

public class PoiGroup implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_POI_GROUP_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName, initialValue = 0)
    private Long id;

    @Basic
    @Column(name = "name", nullable = false, length = 255)
    private String name;

    @Column(name = "contract_id", nullable = false)
    private Long contractId;

    @Column(name = "status", nullable = false, length = 1)
    private String status;

    @Column(name = "reg_date", nullable=false)
    private Timestamp regDate;

    @Column(name = "mod_date", nullable=true)
    private Timestamp modDate;

    @Column(name = "exp_date", nullable=true)
    private Timestamp expDate;

    @Transient
    private Byte userPermission;

    public Byte getUserPermission() {
        return userPermission;
    }

    public void setUserPermission(Byte userPermission) {
        this.userPermission = userPermission;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }
}
