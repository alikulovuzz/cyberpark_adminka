package uzgps.persistence;

import org.hibernate.annotations.WhereJoinTable;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "uzgps_mobject")
public class MObject implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "mo_name", nullable = true, length = 256)
    private String mObjectName;

    @Basic
    @Column(name = "mo_group_id", nullable = true, insertable = false, updatable = false)
    private Long mObjectGroupId;
    @ManyToOne
    @JoinColumn(name = "mo_group_id")
    private Group group;

    @Basic
    @Column(name = "mo_contract_id", nullable = false, insertable = false, updatable = false)
    private Long mObjectContractId;
    @ManyToOne
    @JoinColumn(name = "mo_contract_id")
    private Contract contract;

    @Basic
    @Column(name = "mo_mtracker_status_id", nullable = true, insertable = false, updatable = false)
    private Long mobileTrackerStatusId;

    @ManyToOne
    @JoinColumn(name = "mo_mtracker_status_id")
    private MobileTrackerStatus mobileTrackerStatus;


    @OneToMany
    @JoinTable(
            name = "uzgps_mobject_gps_units",
            joinColumns = @JoinColumn(name = "mogu_mobject_id"),
            inverseJoinColumns = @JoinColumn(name = "mogu_gps_unit_id")
    )

    @WhereJoinTable(clause = "mogu_status='A'")
    private List<GPSUnit> gpsUnitList;

    @Column(name = "mo_type", nullable = false, length = 255)
    private String mObjectType;

    @Column(name = "mo_platenumber", nullable = false, length = 200)
    private String mObjectPlateNumber;

    @Column(name = "mo_photo_id", nullable = true, insertable = false, updatable = false)
    private Long photoId;
    @ManyToOne
    @JoinColumn(name = "mo_photo_id")
    private FileStorage photo;

    @Column(name = "mo_default_icon", nullable = false)
    private Boolean defaultIcon;

    @Column(name = "mo_pin_id")
    private Long pinId;

    @Column(name = "sys_admin_note")
    private String sysAdminNote;

    @Column(name = "mo_additional_info")
    private String additionalInfo;

    @Column(name = "mo_is_tracked")
    private Integer isTracked;

    @Column(name = "mo_status", nullable = false, length = 1)
    private String status;

    @Column(name = "mo_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "mo_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "mo_exp_date", nullable = true)
    private Timestamp expDate;

    public static String getSequenceName() {
        return sequenceName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getmObjectName() {
        return mObjectName;
    }

    public void setmObjectName(String mObjectName) {
        this.mObjectName = mObjectName;
    }

    public Long getmObjectGroupId() {
        return mObjectGroupId;
    }

    public void setmObjectGroupId(Long mObjectGroupId) {
        this.mObjectGroupId = mObjectGroupId;
    }

    public Group getGroup() {
        return group;
    }

    public void setGroup(Group group) {
        this.group = group;
    }

    public Long getmObjectContractId() {
        return mObjectContractId;
    }

    public void setmObjectContractId(Long mObjectContractId) {
        this.mObjectContractId = mObjectContractId;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Long getMobileTrackerStatusId() {
        return mobileTrackerStatusId;
    }

    public void setMobileTrackerStatusId(Long mobileTrackerStatusId) {
        this.mobileTrackerStatusId = mobileTrackerStatusId;
    }

    public MobileTrackerStatus getMobileTrackerStatus() {
        return mobileTrackerStatus;
    }

    public void setMobileTrackerStatus(MobileTrackerStatus mobileTrackerStatus) {
        this.mobileTrackerStatus = mobileTrackerStatus;
    }

    public List<GPSUnit> getGpsUnitList() {
        return gpsUnitList;
    }

    public void setGpsUnitList(List<GPSUnit> gpsUnitList) {
        this.gpsUnitList = gpsUnitList;
    }

    public String getmObjectType() {
        return mObjectType;
    }

    public void setmObjectType(String mObjectType) {
        this.mObjectType = mObjectType;
    }

    public String getmObjectPlateNumber() {
        return mObjectPlateNumber;
    }

    public void setmObjectPlateNumber(String mObjectPlateNumber) {
        this.mObjectPlateNumber = mObjectPlateNumber;
    }


    public Long getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Long photoId) {
        this.photoId = photoId;
    }

    public FileStorage getPhoto() {
        return photo;
    }

    public void setPhoto(FileStorage photo) {
        this.photo = photo;
    }

    public Boolean getDefaultIcon() {
        return defaultIcon;
    }

    public void setDefaultIcon(Boolean defaultIcon) {
        this.defaultIcon = defaultIcon;
    }

    public Long getPinId() {
        return pinId;
    }

    public void setPinId(Long pinId) {
        this.pinId = pinId;
    }

    public String getSysAdminNote() {
        return sysAdminNote;
    }

    public void setSysAdminNote(String sysAdminNote) {
        this.sysAdminNote = sysAdminNote;
    }

    public String getAdditionalInfo() { return additionalInfo; }

    public void setAdditionalInfo(String additionalInfo) { this.additionalInfo = additionalInfo; }

    public Integer getIsTracked() {
        return isTracked;
    }

    public void setIsTracked(Integer tracked) {
        isTracked = tracked;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {
        return "MObject{" +
                "id=" + id +
                ", mObjectName='" + mObjectName + '\'' +
                ", mObjectGroupId=" + mObjectGroupId +
                ", mObjectContractId=" + mObjectContractId +
                ", mObjectType='" + mObjectType + '\'' +
                ", mObjectPlateNumber='" + mObjectPlateNumber + '\'' +
                ", photoId=" + photoId +
                ", defaultIcon=" + defaultIcon +
                ", isTracked=" + isTracked +
                ", additionalInfo='" + additionalInfo + '\'' +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }
}
