package uzgps.persistence;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Entity
@Table(schema = "reporting")
public class CustomDistancesForTracking {
    @Id
    private Long id;
    private Long mobject_id;

    private Timestamp start_period_date;
    private Timestamp end_period_date;
    private Integer start_points;
    private Integer end_points;
    private Double distance;
    private Integer tracking_parts;

    public CustomDistancesForTracking() {
        this.id = null;
        this.mobject_id = 0L;
        this.start_period_date = null;
        this.end_period_date = null;
        this.start_points = 0;
        this.end_points = 0;
        this.distance = 0D;
        this.tracking_parts = 0;
    }

    public Long getId() {
        return id;
    }

    public void setMo(Long id) {
        this.id = id;
    }

    public Long getMobjectId() {
        return mobject_id;
    }

    public void setMobjectId(Long id) {
        this.mobject_id = id;
    }

    public Timestamp getStartDate() {
        return start_period_date;
    }

    public void setStartDate(Timestamp startDate) {
        this.start_period_date = startDate;
    }

    public Timestamp getEndDate() {
        return end_period_date;
    }

    public void setEndDate(Timestamp endDate) {
        this.end_period_date = endDate;
    }

    public Integer getStartPoints() {
        return start_points;
    }

    public void setStartPoints(Integer startPoints) {
        this.start_points = startPoints;
    }

    public Integer getEndPoints() {
        return end_points;
    }

    public void setEndPoints(Integer endPoints) {
        this.end_points = endPoints;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Integer getTrackingParts() {
        return tracking_parts;
    }

    public void setTrackingParts(Integer trackingParts) {
        this.tracking_parts = trackingParts;
    }

    @Override
    public String toString() {
        return "CustomDistancesForTracking{" +
                "id=" + id +
                "mobjectId=" + mobject_id +
                ", startDate=" + start_period_date +
                ", endDate=" + end_period_date +
                ", startPoints=" + start_points +
                ", endPoints=" + end_points +
                ", distance=" + distance +
                '}';
    }
}
