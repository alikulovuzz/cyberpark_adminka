package uzgps.persistence;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name = "uzgps_mobject_settings")
public class MObjectSettings implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_SETTINGS_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "mobject_id", nullable = false, insertable = false, updatable = false)
    private Long mObjectId;
    @OneToOne
    @JoinColumn(name = "mobject_id")
    private MObject mObject;

    @Column(name = "mobject_type_id", nullable = false, insertable = false, updatable = false)
    private Long mObjectTypeId;
    @ManyToOne
    @JoinColumn(name = "mobject_type_id")
    private MObjectType mObjectType;

    @Column(name = "mobject_state_id", nullable = false, insertable = false, updatable = false)
    private Long mObjectStateId;
    @ManyToOne
    @JoinColumn(name = "mobject_state_id")
    private MObjectState mObjectState;

    @Column(name = "mobject_appointment_id", nullable = false, insertable = false, updatable = false)
    private Long mObjectAppointmentId;
    @ManyToOne
    @JoinColumn(name = "mobject_appointment_id")
    private MObjectAppointment mObjectAppointment;

    @Column(name = "object_capacity", nullable = true, length = 255)
    private String objectCapacity;

    @Column(name = "object_fuel", nullable = true, length = 255)
    private String objectFuel;

    @Column(name = "default_track_color", nullable = false, length = 7)
    private String defaultTrackColor;

    @Column(name = "speed_color1", nullable = false, length = 7)
    private String speedColor1;

    @Column(name = "speed_value1", nullable = false)
    private Long speedValue1;

    @Column(name = "speed_color2", nullable = false, length = 7)
    private String speedColor2;

    @Column(name = "speed_value2", nullable = false)
    private Long speedValue2;

    @Column(name = "speed_color3", nullable = false, length = 7)
    private String speedColor3;

    @Column(name = "speed_value3", nullable = false)
    private Long speedValue3;

    @Column(name = "speed_color4", nullable = false, length = 7)
    private String speedColor4;

    @Column(name = "speed_value4", nullable = false)
    private Long speedValue4;

    @Column(name = "speed_color5", nullable = false, length = 7)
    private String speedColor5;

    @Column(name = "speed_value5", nullable = false)
    private Long speedValue5;

    @Column(name = "speed_color6", nullable = false, length = 7)
    private String speedColor6;

    @Column(name = "speed_value6", nullable = false)
    private Long speedValue6;

    @Column(name = "label_size", nullable = false)
    private Long labelSize;

    @Column(name = "max_speed", nullable = false)
    private Long maxSpeed;

    @Column(name = "average_speed", nullable = false)
    private Long averageSpeed;

    @Column(name = "online_time", nullable = false)
    private Long onlineTime;

    @Column(name = "parking_time", nullable = true)
    private Long parkingTime;

    @Column(name = "status", nullable = true, length = 1)
    private String status;

    @Column(name = "reg_date", nullable = true)
    private Timestamp regDate;

    @Column(name = "mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "exp_date", nullable = true)
    private Timestamp expDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public MObjectType getmObjectType() {
        return mObjectType;
    }

    public void setmObjectType(MObjectType mObjectType) {
        this.mObjectType = mObjectType;
    }

    public Long getMObjectTypeId() {
        return mObjectTypeId;
    }

    public void setMObjectTypeId(Long mObjectTypeId) {
        this.mObjectTypeId = mObjectTypeId;
    }

    public Long getMObjectStateId() {
        return mObjectStateId;
    }

    public void setMObjectStateId(Long mObjectStateId) {
        this.mObjectStateId = mObjectStateId;
    }

    public MObjectState getmObjectState() {
        return mObjectState;
    }

    public void setmObjectState(MObjectState mObjectState) {
        this.mObjectState = mObjectState;
    }

    public Long getMObjectAppointmentId() {
        return mObjectAppointmentId;
    }

    public void setMObjectAppointmentId(Long mObjectAppointmentId) {
        this.mObjectAppointmentId = mObjectAppointmentId;
    }

    public MObjectAppointment getmObjectAppointment() {
        return mObjectAppointment;
    }

    public void setmObjectAppointment(MObjectAppointment mObjectAppointment) {
        this.mObjectAppointment = mObjectAppointment;
    }

    public MObject getmObject() {
        return mObject;
    }

    public void setmObject(MObject mObject) {
        this.mObject = mObject;
    }

    public String getObjectCapacity() {
        return objectCapacity;
    }

    public void setObjectCapacity(String objectCapacity) {
        this.objectCapacity = objectCapacity;
    }

    public String getObjectFuel() {
        return objectFuel;
    }

    public void setObjectFuel(String objectFuel) {
        this.objectFuel = objectFuel;
    }

    public String getDefaultTrackColor() {
        return defaultTrackColor;
    }

    public void setDefaultTrackColor(String defaultTrackColor) {
        this.defaultTrackColor = defaultTrackColor;
    }

    public String getSpeedColor1() {
        return speedColor1;
    }

    public void setSpeedColor1(String speedColor1) {
        this.speedColor1 = speedColor1;
    }

    public Long getSpeedValue1() {
        return speedValue1;
    }

    public void setSpeedValue1(Long speedValue1) {
        this.speedValue1 = speedValue1;
    }

    public String getSpeedColor2() {
        return speedColor2;
    }

    public void setSpeedColor2(String speedColor2) {
        this.speedColor2 = speedColor2;
    }

    public Long getSpeedValue2() {
        return speedValue2;
    }

    public void setSpeedValue2(Long speedValue2) {
        this.speedValue2 = speedValue2;
    }

    public String getSpeedColor3() {
        return speedColor3;
    }

    public void setSpeedColor3(String speedColor3) {
        this.speedColor3 = speedColor3;
    }

    public Long getSpeedValue3() {
        return speedValue3;
    }

    public void setSpeedValue3(Long speedValue3) {
        this.speedValue3 = speedValue3;
    }

    public String getSpeedColor4() {
        return speedColor4;
    }

    public void setSpeedColor4(String speedColor4) {
        this.speedColor4 = speedColor4;
    }

    public Long getSpeedValue4() {
        return speedValue4;
    }

    public void setSpeedValue4(Long speedValue4) {
        this.speedValue4 = speedValue4;
    }

    public Long getAverageSpeed() {
        return averageSpeed;
    }

    public void setAverageSpeed(Long averageSpeed) {
        this.averageSpeed = averageSpeed;
    }

    public String getSpeedColor5() {
        return speedColor5;
    }

    public void setSpeedColor5(String speedColor5) {
        this.speedColor5 = speedColor5;
    }

    public Long getSpeedValue5() {
        return speedValue5;
    }

    public void setSpeedValue5(Long speedValue5) {
        this.speedValue5 = speedValue5;
    }

    public String getSpeedColor6() {
        return speedColor6;
    }

    public void setSpeedColor6(String speedColor6) {
        this.speedColor6 = speedColor6;
    }

    public Long getSpeedValue6() {
        return speedValue6;
    }

    public void setSpeedValue6(Long speedValue6) {
        this.speedValue6 = speedValue6;
    }

    public Long getLabelSize() {
        return labelSize;
    }

    public void setLabelSize(Long labelSize) {
        this.labelSize = labelSize;
    }

    public Long getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(Long maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public Long getOnlineTime() {
        return onlineTime;
    }

    public void setOnlineTime(Long onlineTime) {
        this.onlineTime = onlineTime;
    }

    public Long getParkingTime() {
        return parkingTime;
    }

    public void setParkingTime(Long parkingTime) {
        this.parkingTime = parkingTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    @Override
    public String toString() {

        return "MObjectSettings{" +
                "id=" + id +
                ", mObjectId=" + mObjectId +
                ", mObject=" + mObject +
                ", objectCapacity='" + objectCapacity + '\'' +
                ", objectFuel='" + objectFuel + '\'' +
                ", defaultTrackColor='" + defaultTrackColor + '\'' +
                ", speedColor1='" + speedColor1 + '\'' +
                ", speedValue1=" + speedValue1 +
                ", speedColor2='" + speedColor2 + '\'' +
                ", speedValue2=" + speedValue2 +
                ", speedColor3='" + speedColor3 + '\'' +
                ", speedValue3=" + speedValue3 +
                ", speedColor4='" + speedColor4 + '\'' +
                ", speedValue4=" + speedValue4 +
                ", speedColor5='" + speedColor5 + '\'' +
                ", speedValue5=" + speedValue5 +
                ", speedColor6='" + speedColor6 + '\'' +
                ", speedValue6=" + speedValue6 +
                ", labelSize=" + labelSize +
                ", maxSpeed=" + maxSpeed +
                ", onlineTime=" + onlineTime +
                ", parkingTime=" + parkingTime +
                ", mObjectType=" + mObjectType +
                ", mObjectTypeId=" + mObjectTypeId +
                ", mObjectAppointment=" + mObjectAppointment +
                ", mObjectAppointmentId=" + mObjectAppointmentId +
                ", mObjectStateId=" + mObjectStateId +
                '}';
    }
}
