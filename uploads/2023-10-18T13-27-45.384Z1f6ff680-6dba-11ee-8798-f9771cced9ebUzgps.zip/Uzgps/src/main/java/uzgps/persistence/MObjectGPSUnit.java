package uzgps.persistence;


import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;


/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "uzgps_mobject_gps_units")

public class MObjectGPSUnit implements Serializable {

    public static final String sequenceName = "SEQ_UZGPS_MOBJECT_GPS_UNITS_ID";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = sequenceName)
    @SequenceGenerator(name = sequenceName, sequenceName = sequenceName)
    private Long id;

    @Basic
    @Column(name = "mogu_mobject_id", nullable = false, insertable = false, updatable = false)
    private Long mObjectId;
    @ManyToOne
    @JoinColumn(name = "mogu_mobject_id")
    private MObject mObject;

    @Basic
    @Column(name = "mogu_gps_unit_id", nullable = false, insertable = false, updatable = false)
    private Long gpsUnitId;
    @ManyToOne
    @JoinColumn(name = "mogu_gps_unit_id")
    private GPSUnit gpsUnit;

    @Basic
    @Column(name = "mogu_movement_status", nullable = false)
    private Short movementStatus;

    @Basic
    @Column(name = "mogu_engineOn_status", nullable = false)
    private Short engineOnStatus;

    @Basic
    @Column(name = "mogu_online_status", nullable = false)
    private Short onlineStatus;

    @Basic
    @Column(name = "mogu_satellites_status", nullable = false)
    private Short satellitesStatus;

    @Basic
    @Column(name = "mogu_dat_status", nullable = false)
    private Short datStatus;

    @Column(name = "mogu_status", nullable = false, length = 1)
    private String status;

    @Column(name = "mogu_reg_date", nullable = false)
    private Timestamp regDate;

    @Column(name = "mogu_mod_date", nullable = true)
    private Timestamp modDate;

    @Column(name = "mogu_exp_date", nullable = true)
    private Timestamp expDate;

    @Basic
    @Column(name = "mogu_d_min", nullable = true)
    private Integer distanceMin;

    @Basic
    @Column(name = "mogu_d_big", nullable = true)
    private Integer distanceBig;

    @Basic
    @Column(name = "mogu_t_min", nullable = true)
    private Integer timeMin;

    @Basic
    @Column(name = "mogu_t_big", nullable = true)
    private Integer timeBig;

    @Basic
    @Column(name = "mogu_t_lost", nullable = true)
    private Integer timeLost;



    public Integer getDistanceMin() {
        return distanceMin;
    }

    public void setDistanceMin(Integer distanceMin) {
        this.distanceMin = distanceMin;
    }

    public Integer getDistanceBig() {
        return distanceBig;
    }

    public void setDistanceBig(Integer distanceBig) {
        this.distanceBig = distanceBig;
    }

    public Integer getTimeMin() {
        return timeMin;
    }

    public void setTimeMin(Integer timeBig) {
        this.timeMin = timeBig;
    }

    public Integer getTimeBig() {
        return timeBig;
    }

    public void setTimeBig(Integer timeMaxBig) {
        this.timeBig = timeMaxBig;
    }

    public Integer getTimeLost() {
        return timeLost;
    }

    public void setTimeLost(Integer timeLost) {
        this.timeLost = timeLost;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public MObject getmObject() {
        return mObject;
    }

    public void setmObject(MObject mObject) {
        this.mObject = mObject;
    }

    public Long getGpsUnitId() {
        return gpsUnitId;
    }

    public void setGpsUnitId(Long gpsUnitId) {
        this.gpsUnitId = gpsUnitId;
    }

    public GPSUnit getGpsUnit() {
        return gpsUnit;
    }

    public void setGpsUnit(GPSUnit gpsUnit) {
        this.gpsUnit = gpsUnit;
    }

    public Short getMovementStatus() {
        return movementStatus;
    }

    public void setMovementStatus(Short movementStatus) {
        this.movementStatus = movementStatus;
    }

    public Short getEngineOnStatus() {
        return engineOnStatus;
    }

    public void setEngineOnStatus(Short engineOnStatus) {
        this.engineOnStatus = engineOnStatus;
    }

    public Short getOnlineStatus() {
        return onlineStatus;
    }

    public void setOnlineStatus(Short onlineStatus) {
        this.onlineStatus = onlineStatus;
    }

    public Short getSatellitesStatus() {
        return satellitesStatus;
    }

    public void setSatellitesStatus(Short satellitesStatus) {
        this.satellitesStatus = satellitesStatus;
    }

    public Short getDatStatus() {
        return datStatus;
    }

    public void setDatStatus(Short datStatus) {
        this.datStatus = datStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }



    @Override
    public String toString() {
        return "MObjectGPSUnit{" +
                "id=" + id +
                ", mObjectId=" + mObjectId +
                ", mObject=" + mObject +
                ", gpsUnitId=" + gpsUnitId +
                ", gpsUnit=" + gpsUnit +
                ", movementStatus=" + movementStatus +
                ", engineOnStatus=" + engineOnStatus +
                ", onlineStatus=" + onlineStatus +
                ", satellitesStatus=" + satellitesStatus +
                ", datStatus=" + datStatus +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                ", distanceMin=" + distanceMin +
                ", distanceBig=" + distanceBig +
                ", timeMin=" + timeMin +
                ", timeBig=" + timeBig +
                ", timeLost=" + timeLost +

                '}';
    }
}
