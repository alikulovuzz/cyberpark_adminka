package uzgps.persistence.api;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created with IntelliJ IDEA.
 * User: Alisher
 * Date: 04.01.14
 * Time: 17:32
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "view_mobject_extended_data")
public class MObjectExtendedData implements Serializable {

    @Id
    private Long id;

    @Column(name = "mobject_id")
    private Long mobjectId;

    @Column(name = "staff_id")
    private Long staffId;

    @Column(name = "staff_first_name")
    private String staffFirstName;

    @Column(name = "staff_last_name")
    private String staffLastName;

    @Column(name = "staff_patronymic")
    private String staffPatronymic;

    @Column(name = "staff_position")
    private String staffPosition;

    @Column(name = "staff_phone_mobile")
    private String staffPhoneMobile;

    @Column(name = "staff_phone_line")
    private String staffPhoneLine;

    @Column(name = "staff_company_name")
    private String staffCompanyName;

    @Column(name = "staff_subdivision_name")
    private String staffSubdivisionName;

    @Column(name = "mobject_name")
    private String mobjectName;

    @Column(name = "mobject_plate_number")
    private String mobjectPlateNumber;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public String getStaffFirstName() {
        return staffFirstName;
    }

    public void setStaffFirstName(String staffFirstName) {
        this.staffFirstName = staffFirstName;
    }

    public String getStaffLastName() {
        return staffLastName;
    }

    public void setStaffLastName(String staffLastName) {
        this.staffLastName = staffLastName;
    }

    public String getStaffPatronymic() {
        return staffPatronymic;
    }

    public void setStaffPatronymic(String staffPatronymic) {
        this.staffPatronymic = staffPatronymic;
    }

    public String getStaffPosition() {
        return staffPosition;
    }

    public void setStaffPosition(String staffPosition) {
        this.staffPosition = staffPosition;
    }

    public String getStaffPhoneMobile() {
        return staffPhoneMobile;
    }

    public void setStaffPhoneMobile(String staffPhoneMobile) {
        this.staffPhoneMobile = staffPhoneMobile;
    }

    public String getStaffPhoneLine() {
        return staffPhoneLine;
    }

    public void setStaffPhoneLine(String staffPhoneLine) {
        this.staffPhoneLine = staffPhoneLine;
    }

    public String getStaffCompanyName() {
        return staffCompanyName;
    }

    public void setStaffCompanyName(String staffCompanyName) {
        this.staffCompanyName = staffCompanyName;
    }

    public String getStaffSubdivisionName() {
        return staffSubdivisionName;
    }

    public void setStaffSubdivisionName(String staffSubdivisionName) {
        this.staffSubdivisionName = staffSubdivisionName;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }

    public String getMobjectPlateNumber() {
        return mobjectPlateNumber;
    }

    public void setMobjectPlateNumber(String mobjectPlateNumber) {
        this.mobjectPlateNumber = mobjectPlateNumber;
    }

    @Override
    public String toString() {
        return "MObjectExtendedData{" +
                "id=" + id +
                ", mobjectId=" + mobjectId +
                ", staffId=" + staffId +
                ", staffFirstName='" + staffFirstName + '\'' +
                ", staffLastName='" + staffLastName + '\'' +
                ", staffPatronymic='" + staffPatronymic + '\'' +
                ", staffPosition='" + staffPosition + '\'' +
                ", staffPhoneMobile='" + staffPhoneMobile + '\'' +
                ", staffPhoneLine='" + staffPhoneLine + '\'' +
                ", staffCompanyName='" + staffCompanyName + '\'' +
                ", staffSubdivisionName=" + staffSubdivisionName +
                ", mobjectName='" + mobjectName + '\'' +
                ", mobjectPlateNumber='" + mobjectPlateNumber + '\'' +
                '}';
    }
}
