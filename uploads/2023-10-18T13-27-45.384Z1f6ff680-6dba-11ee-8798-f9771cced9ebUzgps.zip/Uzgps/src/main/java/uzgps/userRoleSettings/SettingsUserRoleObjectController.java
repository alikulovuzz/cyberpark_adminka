package uzgps.userRoleSettings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.common.FileStorageService;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.TrackingController;
import uzgps.persistence.*;
import uzgps.settings.AbstractSettingsController;
import uzgps.settings.SettingsService;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsUserRoleObjectController extends AbstractSettingsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_USER_ROLE_SETTINGS_OBJECT = "/user-role-settings/object.htm";

    private final static String URL_USER_ROLE_SETTINGS_OBJECT_PART_1_SAVE = "/user-role-settings/object-part-1-save.htm";

    private final static String VIEW_USER_ROLE_SETTINGS_OBJECT = "user-role-settings/user-role-settings-object";

    private final static int MOBJECT_SETTINGS_PART_1 = 1;

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    FileStorageService storageService;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_USER_ROLE_SETTINGS_OBJECT)
    public ModelAndView processSettingsObject(HttpSession session,
                                              @RequestParam(value = "object-id", required = false) Long objectId) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractsHasMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_USER_ROLE_SETTINGS_OBJECT);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_USER_ROLE_SETTINGS_OBJECT);

        List<MobjectBig> mobjectList = monitoringController.getMobjects(session, false);
        long userContractId = MainController.getUserContractId(session);

        if (mobjectList != null && mobjectList.size() > 0) {
            if (objectId == null) {
                if (mobjectList.get(0) != null) {
                    objectId = mobjectList.get(0).getId();
                }
            }
        }

        List<UserMObjectAccessList> userMObjectAccessList =
                settingsService.getUserMObjectAccessListByUserIdAndContractId(MainController.getUserId(), userContractId);

        boolean hasEditAccess = coreMain.isHasEditAccessToMobject(MainController.getUserId(), objectId);

        modelAndView.addObject("userMObjectAccessList", userMObjectAccessList);
        modelAndView.addObject("hasEditAccess", hasEditAccess);

        MObjectGPSUnit mObjectGPSUnit = settingsService.getObjectGPSUnitByObjectId(objectId);
        MObjectSettings mObjectSettings = settingsService.getObjectSettingsByObjectId(objectId);

        modelAndView.addObject("mObjectGPSUnit", mObjectGPSUnit);
        modelAndView.addObject("settings", mObjectSettings);

        modelAndView.addObject("cmd", "edit");
        modelAndView.addObject("objectId", objectId);

        modelAndView.addObject("userContractId", userContractId);
        modelAndView.addObject("mobjectList", mobjectList);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        modelAndView.addObject("selectedLeftMenu", "objects");

        return modelAndView;
    }


    @RequestMapping(value = URL_USER_ROLE_SETTINGS_OBJECT_PART_1_SAVE)
    public ModelAndView processSettingsObjectPart1Save(HttpSession session,
                                                       @RequestParam(value = "cmd", required = false) String cmd,
                                                       @RequestParam(value = "object-id", required = false) Long objectId,
                                                       @RequestParam(value = "id-list", required = false) Long[] idList,
                                                       @RequestParam(value = "object-name", required = false) String objectName) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractEqualsMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_USER_ROLE_SETTINGS_OBJECT);
        }

        ModelAndView modelAndView;

        if (cmd != null) {

            MObject mObject = settingsService.getObjectByObjectId(objectId);

            if (mObject != null) {
                boolean hasEditAccess = coreMain.isHasEditAccessToMobject(MainController.getUserId(), objectId);

                if (!hasEditAccess) {
                    return new ModelAndView("redirect:" + URL_USER_ROLE_SETTINGS_OBJECT + "?object-id=" + objectId + "#objects");
                }

                mObject.setmObjectName(objectName);
//                mObject.setmObjectPlateNumber(objectPlateNumber);
                mObject.setModDate(new Timestamp(System.currentTimeMillis()));

                settingsService.saveMObject(mObject);

                // Change tracker name too
                MObjectGPSUnit mObjectGPSUnit = settingsService.getObjectGPSUnitByObjectId(mObject.getId());
                if (mObjectGPSUnit != null) {
                    GPSUnit gpsUnit = mObjectGPSUnit.getGpsUnit();
                    if (gpsUnit != null) {
                        gpsUnit.setName(mObject.getmObjectName());
                        settingsService.saveGPSUnit(gpsUnit);
                        coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    }
                }

                updateMobjectInCoreById(objectId);
            }

            modelAndView = new ModelAndView("redirect:" + URL_USER_ROLE_SETTINGS_OBJECT + "?object-id=" + objectId + "#objects");
        } else {
            modelAndView = new ModelAndView(VIEW_USER_ROLE_SETTINGS_OBJECT);
        }

        return modelAndView;
    }

    /**
     * Update Mobject in core by Id
     *
     * @param objectId
     */
    private void updateMobjectInCoreById(Long objectId) {
        try {
            // Update core object
            coreMain.coreUpdater.updateMobjectBigById(objectId);
        } catch (Exception e) {
            logger.error("Error in updateMobjectInCoreById", e);
        }

    }


}
