package uzgps.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.database.helpers.DBEmail;
import uz.netex.dbtables.EmailOut;
import uzgps.common.EMailService;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.UrlConfiguration;
import uzgps.login.captcha.JPEGCreator;
import uzgps.persistence.User;
import uzgps.security.MD5;
import uzgps.security.SecurityService;

import javax.imageio.ImageIO;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.Random;
import java.util.regex.Pattern;

/**
 * @author Sheroz Khaydarov
 * @since 31.03.13 21:45
 */
@Controller
public class LoginController {

    public final static String URL_LOGIN = "/login.htm";
    public final static String VIEW_LOGIN = "login/login";

    public final static String URL_ACCESS_DENIED = "/accessDenied.htm";
    public final static String VIEW_ACCESS_DENIED = "login/accessDenied";

    public final static String URL_TIMEOUT = "/timeout.htm";
    public final static String VIEW_TIMEOUT = "login/timeout";

    public final static String URL_PASSWORD = "/password.htm";
    public final static String VIEW_PASSWORD = "login/password";
    public final static String VIEW_PASSWORD_DONE = "login/password-done";
    public final static String URL_PASSWORD_RESET = "/password-reset.htm";
    public final static String VIEW_PASSWORD_RESET = "login/password-reset";

    public final static String URL_CAPTCHA = "/captcha/captcha.jpg";

    private final static String URL_RESET_PASSWORD_EMAIL = "/api/reset-password-email.json";
//    private final static String URL_RESET_PASSWORD_EMAIL = "/api/email.json";

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    EMailService eMailService;

    @Autowired
    private SecurityService securityService;

    @RequestMapping(value = URL_LOGIN, method = RequestMethod.GET)
    public ModelAndView getLogin(HttpServletRequest request, HttpServletResponse response,
                                 @RequestParam(value = "login_error", required = false) Long loginError) {

        HttpSession session = request.getSession(true);
        session.setAttribute("userDetail", null);

        Integer loginAttempt = 0;
        try {
            loginAttempt = (Integer) session.getAttribute("loginAttempts");
            if (loginAttempt != null) {
                // loginAttempt++;
            } else {
                loginAttempt = 0;
            }
            //   session.setAttribute("loginAttempts", loginAttempt);

        } catch (Exception e) {
            //   session.setAttribute("loginAttempts", loginAttempt);
        }

        // If Login error, then capthca must work too
        if (loginError != null && loginError == 1) {
            loginAttempt++;
        }

        try {
            session.setAttribute("loginAttempts", loginAttempt);
        } catch (Exception e) {
        }


        ModelAndView modelAndView;

        modelAndView = new ModelAndView(VIEW_LOGIN);
        modelAndView.addObject("loginAttempt", loginAttempt);
        if (loginError != null)
            modelAndView.addObject("loginError", loginError);

        return modelAndView;
    }

    @RequestMapping(value = URL_ACCESS_DENIED, method = RequestMethod.GET)
    public ModelAndView getAccessDenied()
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ACCESS_DENIED);
        modelAndView.addObject("urlBilling", UrlConfiguration.getUrlBilling());

        return modelAndView;

    }

    @RequestMapping(value = URL_TIMEOUT, method = RequestMethod.GET)
    public ModelAndView getTimeout()
            throws ServletException, IOException {

        return new ModelAndView(VIEW_TIMEOUT);
    }

    @RequestMapping(value = URL_PASSWORD, method = RequestMethod.GET)
    public ModelAndView passwordRecovery(HttpServletRequest request, HttpServletResponse response,
                                         @RequestParam(value = "recovery", required = false, defaultValue = "") String recoveryKey,
                                         @RequestParam(value = "error", required = false, defaultValue = "") String errorMsg,
                                         @RequestParam(value = "errorUsername", required = false, defaultValue = "") String errorUsername)
            throws ServletException, IOException {

        ModelAndView modelAndView;

        try {
            if (recoveryKey != null && recoveryKey.length() > 10) {
                TypedQuery<User> query;
                query = entityManager.createNamedQuery("User.findByRecoveryKey", User.class);
                query.setParameter("recoveryKey", recoveryKey.trim());
                query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
                User user = query.getSingleResult();

                if (user != null) {
                    // user exists, let him change it's password.
                    modelAndView = new ModelAndView(VIEW_PASSWORD_RESET);
                    modelAndView.addObject("recoveryKey", recoveryKey);
                    modelAndView.addObject("errorMsg", errorMsg);
                    return modelAndView;
                }

            }
        } catch (Exception e) {
        }

        HttpSession session = request.getSession(true);
        session.setAttribute("userDetail", null);
        if (errorUsername != null)
            session.setAttribute("errorUsername", errorUsername);


        modelAndView = new ModelAndView(VIEW_PASSWORD);
        return modelAndView;
    }

    @RequestMapping(value = URL_PASSWORD, method = RequestMethod.POST)
    public ModelAndView passwordRecoveryDone(HttpServletRequest request, HttpSession session,
                                             @RequestParam(value = "p_username", required = false, defaultValue = "") String userName) {

        ModelAndView modelAndView = new ModelAndView(VIEW_PASSWORD_DONE);
        modelAndView.addObject("username", userName);

        User user = getUserByLogin(userName);

        if (user != null) {
            String email = user.getProfile().getEmail();
            if(isValidEmail(email) || isValidEmail(user.getLogin())){
                sendResetPasswordEmail(user, request);
            } else {
                modelAndView = new ModelAndView("redirect:" + URL_PASSWORD + "?errorNotValidEmail=1");
                return modelAndView;
            }
        } else {
            // username not found
            modelAndView = new ModelAndView("redirect:" + URL_PASSWORD + "?errorUsername=1");
            return modelAndView;

        }


        return modelAndView;
    }

    @RequestMapping(value = URL_RESET_PASSWORD_EMAIL)
    public ResponseEntity<User> processSendingEmailForResetPassword(HttpServletRequest request,
                                                                    @RequestParam(value = "username", required = false, defaultValue = "") String userName) {
        User user = getUserByLogin(userName);
        sendResetPasswordEmail(user, request);

        return new ResponseEntity<>(user, HttpStatus.OK);
    }

    private User getUserByLogin(String userName) {
        User user = null;

        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByLogin", User.class);
            query.setParameter("login", userName);
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            user = query.getSingleResult();
        } catch (Exception e) {
        }

        return user;
    }

    private void sendResetPasswordEmail(User user, HttpServletRequest request) {
        if (user != null) {

            // generate recovery key and expire time
            Timestamp expireTime = new Timestamp(System.currentTimeMillis() + 86400000);

            String keyString = "" + user.getId() + expireTime + user.getLogin();

            MD5 md5 = new MD5();
            keyString = md5.getMD5(keyString.trim()) + md5.getMD5(user.getLogin());

            // Save recovery key and time
            user.setRecoveryKey(keyString);
            user.setRecoveryExp(expireTime);

            //entityManager.merge(user)
            securityService.saveUser(user);

            // Send e-mail to client
            String fio = user.getName() + " " + user.getMiddleName();
            String linkEn = UrlConfiguration.getUrlUzgps() + "/password.htm?recovery=" + keyString + "&language=en";
            String linkRu = UrlConfiguration.getUrlUzgps() + "/password.htm?recovery=" + keyString + "&language=ru";
            String linkUz = UrlConfiguration.getUrlUzgps() + "/password.htm?recovery=" + keyString + "&language=uz_LAT";

            String emailMessage = eMailService.getEmailText();
            emailMessage = emailMessage.replace("<FIO>", fio);
            emailMessage = emailMessage.replace("<link.en>", linkEn);
            emailMessage = emailMessage.replace("<link.ru>", linkRu);
            emailMessage = emailMessage.replace("<link.uz>", linkUz);

            EmailOut emailOut = new EmailOut();

            String email = user.getProfile().getEmail();
            if(isValidEmail(email)){
                email = user.getLogin();
            }

            emailOut.setToEmail(email);
            emailOut.setSubject("Password recovery");
            emailOut.setMessage(emailMessage);
            emailOut.setStatus("A");
            emailOut.setRegDate(new Timestamp(System.currentTimeMillis()));

            DBEmail.getInstance().saveEmailOut(emailOut);
        }
    }

    @RequestMapping(value = URL_PASSWORD_RESET, method = RequestMethod.POST)
    public ModelAndView passwordReset(HttpServletResponse response, HttpSession session,
                                      @RequestParam(value = "recoveryKey", required = false, defaultValue = "") String recoveryKey,
                                      @RequestParam(value = "pass1", required = false, defaultValue = "") String pass1,
                                      @RequestParam(value = "pass2", required = false, defaultValue = "") String pass2)
            throws ServletException, IOException {

        ModelAndView modelAndView;

        if (recoveryKey != null && recoveryKey.length() > 10) {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByRecoveryKey", User.class);
            query.setParameter("recoveryKey", recoveryKey.trim());
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            User user = query.getSingleResult();

            if (user != null) {

                if (pass1 != null && pass2 != null && pass1.length() > 4 && pass2.length() > 4) {
                    MD5 md5 = new MD5();
                    pass1 = md5.getMD5(pass1);
                    pass2 = md5.getMD5(pass2);
                    if (pass1.equalsIgnoreCase(pass2)) {
                        user.setPassword(pass1);
                        user.setRecoveryKey(null);
                        user.setRecoveryExp(null);
                        securityService.saveUser(user);

                        modelAndView = new ModelAndView("redirect:" + URL_LOGIN);
                        return modelAndView;
                    }
                }
            }

        }

        String errorStr = "";
        // Set error number for Password length < 5
        if (pass1 == null || pass2 == null) {
            errorStr += ",errorPass";
        }
        // Set error number for Password Same
        if (pass1 != null && pass2 != null && !pass1.equalsIgnoreCase(pass2)) {
            errorStr += ",errorEqual";
        }
        // Set error number for Password Length
        if (pass1 != null && pass2 != null
                && (pass1.length() < 5 || pass2.length() < 5)) {
            errorStr += ",errorLength";
        }

        modelAndView = new ModelAndView("redirect:" + URL_PASSWORD + "?recovery=" + recoveryKey + "&error=pass" + errorStr);
        return modelAndView;
    }


    @RequestMapping(value = URL_CAPTCHA)
    public ModelAndView getFile(HttpServletRequest request, HttpServletResponse response) {

        // Value for captcha
        char[] CHARSET_AZ_09 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
        String captchaStr = randomString(CHARSET_AZ_09, 6);
        MD5 md5 = new MD5();
        String captchaStrMd5 = md5.getMD5(captchaStr);

        HttpSession session = request.getSession(true);
        session.setAttribute("captcha", captchaStrMd5);

        //Set the mime type of the image
        response.setContentType("image/jpeg");
        try {
            JPEGCreator jpegCreator = new JPEGCreator(120, 26);
            BufferedImage img = jpegCreator.captcha(captchaStr);

            ImageIO.write(img, "jpg", response.getOutputStream());
        } catch (IOException ex) {

        }
        return null;
    }

    public static String randomString(char[] characterSet, int length) {
        Random random = new SecureRandom();
        char[] result = new char[length];
        for (int i = 0; i < result.length; i++) {
            // picks a random index out of character set > random character
            int randomCharIndex = random.nextInt(characterSet.length);
            result[i] = characterSet[randomCharIndex];
        }
        return new String(result);
    }

    private boolean isValidEmail(String email){
        if(email == null)
            return false;
        String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
        return Pattern.matches(regex, email);
    }
}
