package uzgps.excel.tripReports;

import javax.persistence.Transient;
import java.sql.Timestamp;

public abstract class AbstractTripItem {

    @Transient
    private Long tripId;

    @Transient
    private String tripName;

    @Transient
    private String tripDirection;

    @Transient
    private String tripDescription;

    @Transient
    private Double tripDistance;

    @Transient
    private Timestamp tripTimePlanned;

    @Transient
    private Timestamp stationExitPlanned;

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }


    public String getTripDirection() {
        return tripDirection;
    }

    public void setTripDirection(String tripDirection) {
        this.tripDirection = tripDirection;
    }

    public String getTripDescription() {
        return tripDescription;
    }

    public void setTripDescription(String tripDescription) {
        this.tripDescription = tripDescription;
    }

    public Double getTripDistance() {
        return tripDistance;
    }

    public void setTripDistance(Double tripDistance) {
        this.tripDistance = tripDistance;
    }

    public Timestamp getTripTimePlanned() {
        return tripTimePlanned;
    }

    public void setTripTimePlanned(Timestamp tripTimePlanned) {
        this.tripTimePlanned = tripTimePlanned;
    }

    public Timestamp getStationExitPlanned() {
        return stationExitPlanned;
    }

    public void setStationExitPlanned(Timestamp stationExitPlanned) {
        this.stationExitPlanned = stationExitPlanned;
    }

}
