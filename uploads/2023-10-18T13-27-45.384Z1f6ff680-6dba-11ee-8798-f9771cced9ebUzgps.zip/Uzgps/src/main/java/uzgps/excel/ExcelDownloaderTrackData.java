package uzgps.excel;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import uzgps.common.excel.Writer;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Service for processing Apache POI-based reports
 *
 * @author Saidolim
 * @since 04.04.2016 11:32
 */
@Component
public abstract class ExcelDownloaderTrackData<T> {

    protected static final Logger logger = Logger.getLogger(ExcelDownloaderTrackData.class.getName());

    @Autowired
    private MessageSource messageSource;

    protected XSSFWorkbook workbook;
    protected XSSFSheet worksheet;
    protected XSSFSheet chartWorksheet;
    protected Locale locale;
    protected List<T> dbList;
    protected ExcelStyles excelStyles;

    /* -------------- Settings -------------- >> */
    protected int startRowIndex = 0;
    protected int startColIndex = 0;

    protected int chartStartRowIndex = 0;
    protected int chartStartColIndex = 0;

    public Long token = 0L;
    protected short rowHeight = 500;
    public String fileName = "";
    protected String title = "";
    protected String sheetName = "Worksheet 1";
    protected String chartSheetName = "Worksheet 2";
    protected int filedsCount = 5;
    /* -------------- Settings -------------- << */

    /**
     * Processes the download for Excel format.
     * It does the following steps:
     * <pre>
     * 1. Create new workbook
     * 2. Create new worksheet
     * 3. Define starting indices for rows and columns
     * 4. Build layout
     * 5. Fill report
     * 6. Set the HttpServletResponse properties
     * 7. Write to the output stream
     * </pre>
     */
    @SuppressWarnings("unchecked")
    public void downloadXLS(HttpServletResponse response) throws ClassNotFoundException {
        logger.debug("Downloading Excel report");

        // 1. Create new workbook
        workbook = new XSSFWorkbook();

        // 4. Build chart worksheet !!
        createChartWorksheet();

        // 2. Create new worksheet
        worksheet = workbook.createSheet(sheetName);
        // 2.1 Create styles
        ExcelStyles.createStyles(worksheet);

        // 3. Define starting indices for rows and columns
        startRowIndex = 0;
        startColIndex = 0;

        // 5. Build layout
        // Build title, date, and column headers
        buildReport();

        // 6. Fill report
        fillReport();

        // 7. Set the response properties

        try {
            response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8") + ".xlsx");
            response.setContentType("application/ms-excel; charset=UTF-8");
            response.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        Long responseTokenValue = token * -1;
        Cookie fileDownloadToken = new Cookie("fileDownloadToken", responseTokenValue.toString());
        final int expiryTime = 60 * 60 * 24;  // 24h in seconds
        final String cookiePath = "/";
        fileDownloadToken.setMaxAge(expiryTime);  // A negative value means that the cookie is not stored persistently and will be deleted when the Web browser exits. A zero value causes the cookie to be deleted.
        fileDownloadToken.setPath(cookiePath);  // The cookie is visible to all the pages in the directory you specify, and all the pages in that directory's subdirectories
        response.addCookie(fileDownloadToken);

        // 8. Write to the output stream
        if (chartWorksheet == null) {
            Writer.write(response, worksheet);
        } else {
            Writer.write(response, worksheet, chartWorksheet);
        }


    }

    /* --------------------- Layout --------------------- >> */

    /**
     * Builds the report layout.
     */
    public void buildReport() {
        // for language support
        locale = LocaleContextHolder.getLocale();

        // Build columns width
        buildColumnsWidth();

        // Build the column headers
        buildHeaders();

        // Build the column headers for chart worksheet
        buildChartHeaders();

        // 8. Write to the output stream
        if (chartWorksheet != null) {
            // Build chart title and date headers
            buildChartTitle();
        }

        // Build the title and date headers
        buildTitle();
    }

    /**
     * Builds the report layout.
     * <p/>
     * This doesn't have any data yet. This is your template.
     */
    public void buildColumnsWidth() {
        // Set column widths
        for (int k = 0; k < filedsCount; k++)
            worksheet.setColumnWidth(k, 5000);
    }

    /**
     * Builds the report title and the date header
     */
    public void buildTitle() {
        // Create report title
        XSSFRow rowTitle = worksheet.createRow(startRowIndex);
        rowTitle.setHeight(rowHeight);
        XSSFCell cellTitle = rowTitle.createCell(startColIndex);
        cellTitle.setCellValue(title);
        cellTitle.setCellStyle(ExcelStyles.cellStyleTitle);

        // Create merged region for the report title
        worksheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(startRowIndex, startRowIndex, 0, filedsCount));

        // Create date header
        XSSFRow dateTitle = worksheet.createRow(startRowIndex + 1);
        XSSFCell cellDate = dateTitle.createCell(startColIndex);
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        cellDate.setCellValue(translateText("excel.fileWasGeneratedAt") + " " + df.format(new Date()));
    }

    /**
     * Builds chart title and the date header
     */
    public void buildChartTitle() {
        // Create report title
        XSSFRow rowTitle = chartWorksheet.createRow(chartStartRowIndex);
        rowTitle.setHeight(rowHeight);
        XSSFCell cellTitle = rowTitle.createCell(chartStartColIndex);
        cellTitle.setCellValue(title);
        cellTitle.setCellStyle(ExcelStyles.cellStyleTitle);

        // Create merged region for the report title
        chartWorksheet.addMergedRegion(new org.apache.poi.ss.util.CellRangeAddress(chartStartRowIndex, chartStartRowIndex, 0, filedsCount
                + 19));

        // Create date header
        XSSFRow dateTitle = chartWorksheet.createRow(chartStartRowIndex + 1);
        XSSFCell cellDate = dateTitle.createCell(chartStartColIndex);
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        cellDate.setCellValue(translateText("excel.fileWasGeneratedAt") + " " + df.format(new Date()));
    }

    /**
     * Builds the chart worksheet
     */
    public void createChartWorksheet() {

    }

    /**
     * Builds the column headers
     */
    public void buildHeaders() {

    }

    /**
     * Builds the column headers for chart worksheet
     */
    public void buildChartHeaders() {

    }
    /* --------------------- MAIN --------------------- >> */

    /**
     * Fills the report Sims with content
     */
    public void fillReport() {
        // Create body
        int rowIndx = 3 + startRowIndex;
        int rowsCount = 0;
        if (dbList != null) {
            rowsCount = dbList.size();
            for (T item : dbList) {
                // Create a new row
                XSSFRow row = worksheet.createRow(rowIndx);
                XSSFRow chartRow = chartWorksheet.createRow(rowIndx);

                addChartRow(chartRow, item);
                addRow(row, item);

                rowIndx++;
            }
        }
        createChart(rowsCount);
    }

    public void addRow(XSSFRow row, T item) {

    }

    public void addChartRow(XSSFRow row, T item) {

    }

    public void createChart(Integer tracksCount) {

    }

    /**
     * Return translated string
     *
     * @param langCode
     * @return
     */
    protected String translateText(String langCode) {
        try {
            return messageSource.getMessage(langCode, null, locale);
        } catch (Exception ex) {
            return langCode;
        }
    }

    /* --------------------- GETTER & SETTER --------------------- >> */
    public XSSFWorkbook getWorkbook() {
        return workbook;
    }

    public int getStartRowIndex() {
        return startRowIndex;
    }

    public void setStartRowIndex(int startRowIndex) {
        this.startRowIndex = startRowIndex;
    }

    public int getStartColIndex() {
        return startColIndex;
    }

    public void setStartColIndex(int startColIndex) {
        this.startColIndex = startColIndex;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
        if (fileName == null)
            this.fileName = "";

        // Add current date/time
        this.fileName += "-" + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public short getRowHeight() {
        return rowHeight;
    }

    public void setRowHeight(short rowHeight) {
        this.rowHeight = rowHeight;
    }

    public String getSheetName() {
        return sheetName;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public int getFiledsCount() {
        return filedsCount;
    }

    public void setFiledsCount(int filedsCount) {
        this.filedsCount = filedsCount;
    }

    public List<T> getDbList() {
        return dbList;
    }

    public void setDbList(List<T> dbList) {
        this.dbList = dbList;
    }
    /* --------------------- GETTER & SETTER --------------------- << */
}
