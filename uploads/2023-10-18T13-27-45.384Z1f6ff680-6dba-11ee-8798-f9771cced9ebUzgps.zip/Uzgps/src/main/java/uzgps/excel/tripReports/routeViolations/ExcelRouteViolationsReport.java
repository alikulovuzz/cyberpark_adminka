package uzgps.excel.tripReports.routeViolations;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import uzgps.excel.ExcelDownloader;
import uzgps.persistence.ReportRouteViolations;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Stanislav on 08.08.2019 18:02
 */
@Component
public class ExcelRouteViolationsReport extends ExcelDownloader<ReportRouteViolations> {
    private Integer speedViolationsTotal = 0;
    private Integer tripNotFinishedViolationsTotal = 0;
    private Integer notStoppedViolationsTotal = 0;

    private String customerCompanyName;
    private Integer tripType;
    private String userLogin;
    private Timestamp startDate;
    private Timestamp endDate;
//    private Timestamp reportStartPeriod;
//    private Timestamp reportEndPeriod;

    public ExcelRouteViolationsReport() {
        setFileName("RouteViolationsReport"); // File name
        sheetName = "Отчет по нарушениям в рейсах";
        fieldsCount = 12;
    }

    public ExcelRouteViolationsReport(MessageSource msgSource) {
        this();
        this.messageSource = msgSource;
    }

    /**
     * Builds the column headers
     */
    @Override
    public void buildHeaders() {
        // Create the column headers
        title = translateText("Отчет по нарушениям в рейсах");

        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 16);
        rowHeader.setHeight((short) 550);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("№");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("Маршрут");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("Направление");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("Название конечной");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("Объект");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 5);
        cell6.setCellValue("Гос. номер");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 6);
        cell7.setCellValue("ФИО водителя");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 7);
        cell8.setCellValue("Номер рейса");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 8);
        cell9.setCellValue("Период времени рейса");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell_10 = rowHeader.createCell(startColIndex + 9);
        cell_10.setCellValue("Тип нарушения");
        cell_10.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell_11 = rowHeader.createCell(startColIndex + 10);
        cell_11.setCellValue("Скорость км/ч");
        cell_11.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell_12 = rowHeader.createCell(startColIndex + 11);
        cell_12.setCellValue("Время нарушения");
        cell_12.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell_13 = rowHeader.createCell(startColIndex + 12);
        cell_13.setCellValue("Детали нарушения");
        cell_13.setCellStyle(excelStyles.headerCellStyleBlue);

    }

    @Override
    public void addRow(XSSFRow row, ReportRouteViolations item) {
        String tripStatusStr = "";
        if (item.getViolationType() == 1) {
            tripStatusStr = "Скоростной режим";
            speedViolationsTotal += 1;
        } else if (item.getViolationType() == 2) {
            tripStatusStr = "Рейс не завершен";
            tripNotFinishedViolationsTotal += 1;
        } else if (item.getViolationType() == 3) {
            tripStatusStr = "Не остановился в КТ";
            notStoppedViolationsTotal += 1;
        }

        XSSFCell cell1 = row.createCell(startColIndex);
        cell1.setCellValue(item.getId());
        cell1.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell2 = row.createCell(startColIndex + 1);

        cell2.setCellValue(item.getTripName());
        cell2.setCellStyle(excelStyles.bodyCellStyleCenter);
        cell2.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell3 = row.createCell(startColIndex + 2);
        cell3.setCellValue(item.getTripDirection());
        cell3.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell3.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell4 = row.createCell(startColIndex + 3);
        cell4.setCellValue(item.getTripDescription());
        cell4.setCellStyle(excelStyles.bodyCellStyleLeft);
        cell4.setCellType(XSSFCell.CELL_TYPE_STRING);
        ///////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell5 = row.createCell(startColIndex + 4);
        cell5.setCellValue(item.getMobjectName());
        cell5.setCellStyle(excelStyles.bodyCellStyleCenter);
        cell5.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell6 = row.createCell(startColIndex + 5);
        cell6.setCellValue(item.getPlateNumber());
        cell6.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell6.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell7 = row.createCell(startColIndex + 6);
        cell7.setCellValue(item.getStaffName());
        cell7.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell7.setCellType(XSSFCell.CELL_TYPE_STRING);

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell8 = row.createCell(startColIndex + 7);
        cell8.setCellValue(item.getTripNum());
        cell8.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell8.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell9 = row.createCell(startColIndex + 8);
        cell9.setCellValue(item.getTripPeriod());
        cell9.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell9.setCellType(XSSFCell.CELL_TYPE_STRING);
        //////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell_10 = row.createCell(startColIndex + 9);
        cell_10.setCellValue(tripStatusStr);
        cell_10.setCellStyle(excelStyles.bodyCellStyleLeft);
        cell_10.setCellType(XSSFCell.CELL_TYPE_STRING);
        //////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell_11 = row.createCell(startColIndex + 10);
        cell_11.setCellValue(item.getMaxSpeed());
        cell_11.setCellStyle(excelStyles.bodyCellStyleCenter);
        cell_11.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell_12 = row.createCell(startColIndex + 11);
        cell_12.setCellValue(item.getViolationTime());
        cell_12.setCellStyle(excelStyles.DATE_TIME_STYLE);
        cell_12.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        String violationDetails = "";
        if (item.getViolationType() == 1) {
            violationDetails = item.getViolationPlace();
        } else if (item.getViolationType() == 2) {
            violationDetails = item.getViolationPlace();
        } else if (item.getViolationType() == 3) {
            violationDetails = item.getViolationPlace();
        }

        XSSFCell cell_13 = row.createCell(startColIndex + 12);
        cell_13.setCellValue(violationDetails);
        cell_13.setCellStyle(excelStyles.bodyCellStyleLeft);
        cell_13.setCellType(XSSFCell.CELL_TYPE_STRING);
    }

    private void buildDetails() {
        worksheet.setColumnWidth(0, 1500);
        worksheet.setColumnWidth(1, 9000);
        worksheet.setColumnWidth(2, 5000);
        worksheet.setColumnWidth(3, 12000);
        worksheet.setColumnWidth(4, 3000);
        worksheet.setColumnWidth(8, 10000);
        worksheet.setColumnWidth(12, 12000);

        worksheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 2));
        worksheet.addMergedRegion(new CellRangeAddress(2, 2, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(3, 3, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(4, 4, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(5, 5, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(6, 6, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(7, 7, 0, 2));
        worksheet.addMergedRegion(new CellRangeAddress(8, 8, 0, 1));

        worksheet.addMergedRegion(new CellRangeAddress(9, 9, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(11, 11, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(12, 12, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(13, 13, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(14, 14, 0, 1));
        worksheet.addMergedRegion(new CellRangeAddress(15, 15, 0, 1));

//        worksheet.addMergedRegion(new CellRangeAddress(9, 9, 1, 2));
//        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 1, 2));
//        worksheet.addMergedRegion(new CellRangeAddress(11, 11, 1, 2));
//        worksheet.addMergedRegion(new CellRangeAddress(12, 12, 1, 2));
//        worksheet.addMergedRegion(new CellRangeAddress(13, 13, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(14, 14, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(15, 15, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(16, 16, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(17, 17, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(19, 19, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(20, 20, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(21, 21, 1, 4));

        XSSFRow rowDetails1 = worksheet.createRow((short) startRowIndex + 1);
        rowDetails1.setHeight((short) 300);

        XSSFCell cell1 = rowDetails1.createCell(0);
        cell1.setCellValue("Детальная информация по типам нарушений");
        cell1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails3 = worksheet.createRow((short) startRowIndex + 3);
        rowDetails3.setHeight((short) 300);

        XSSFCell cell2 = rowDetails3.createCell(0);
        cell2.setCellValue("Номер автопарка:");
        cell2.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell3 = rowDetails3.createCell(2);
        cell3.setCellValue(getCustomerCompanyName());
        cell3.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails4 = worksheet.createRow((short) startRowIndex + 4);
        rowDetails4.setHeight((short) 300);

        XSSFCell cell4 = rowDetails4.createCell(0);
        cell4.setCellValue("Начало рейса:");
        cell4.setCellStyle(excelStyles.bodyCellStyleLeft);

        String tripTypeStr = "";
        if (getTripType() == 1) {
            tripTypeStr = "График";
        } else if (getTripType() == 2) {
            tripTypeStr = "Произвольно";
        }
        XSSFCell cell4_1 = rowDetails4.createCell(2);
        cell4_1.setCellValue(tripTypeStr);
        cell4_1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails6 = worksheet.createRow((short) startRowIndex + 6);
        rowDetails6.setHeight((short) 300);

        XSSFCell cell6_1 = rowDetails6.createCell(0);
        cell6_1.setCellValue("Период отчета:");
        cell6_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell6_2 = rowDetails6.createCell(2);
        cell6_2.setCellValue(getStartDate());
        cell6_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell6_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell6_3 = rowDetails6.createCell(3);
        cell6_3.setCellValue(getEndDate());
        cell6_3.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE_LEFT);
        cell6_3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails8 = worksheet.createRow(startRowIndex + 7);

        XSSFCell rowDetails8_1 = rowDetails8.createCell(startColIndex);
        rowDetails8_1.setCellValue(translateText("Время генерации отчета:"));

        XSSFCell rowDetails8_2 = rowDetails8.createCell(startColIndex + 2);
        rowDetails8_2.setCellValue(new Timestamp(new Date().getTime()));
        rowDetails8_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        rowDetails8_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails9 = worksheet.createRow((short) startRowIndex + 8);
        rowDetails9.setHeight((short) 300);

        XSSFCell cell9_1 = rowDetails9.createCell(0);
        cell9_1.setCellValue("Отчет сгенерировал:");
        cell9_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell9_2 = rowDetails9.createCell(2);
        cell9_2.setCellValue(getUserLogin());
        cell9_2.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails10 = worksheet.createRow((short) startRowIndex + 10);
        rowDetails10.setHeight((short) 300);

        XSSFCell cell110_1 = rowDetails10.createCell(0);
        cell110_1.setCellValue("Общее количество нарушений по типам:");
        cell110_1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails11 = worksheet.createRow((short) startRowIndex + 11);
        rowDetails11.setHeight((short) 300);

        XSSFCell cell11_1 = rowDetails11.createCell(0);
        cell11_1.setCellValue("Скоростной режим:");
        cell11_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell11_2 = rowDetails11.createCell(2);
        cell11_2.setCellValue(speedViolationsTotal);
        cell11_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell11_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails12 = worksheet.createRow((short) startRowIndex + 12);
        rowDetails12.setHeight((short) 300);

        XSSFCell cell112_1 = rowDetails12.createCell(0);
        cell112_1.setCellValue("Рейс не завершен:");
        cell112_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell112_2 = rowDetails12.createCell(2);
        cell112_2.setCellValue(tripNotFinishedViolationsTotal);
        cell112_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell112_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails13 = worksheet.createRow((short) startRowIndex + 13);
        rowDetails13.setHeight((short) 300);

        XSSFCell cell13_1 = rowDetails13.createCell(0);
        cell13_1.setCellValue("Не остановился на остановке:");
        cell13_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell13_2 = rowDetails13.createCell(2);
        cell13_2.setCellValue(notStoppedViolationsTotal);
        cell13_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell13_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails14 = worksheet.createRow((short) startRowIndex + 14);
        rowDetails11.setHeight((short) 300);

        XSSFCell cell14_1 = rowDetails14.createCell(0);
        cell14_1.setCellValue("Итого:");
        cell14_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell14_2 = rowDetails14.createCell(2);
        cell14_2.setCellValue(speedViolationsTotal + tripNotFinishedViolationsTotal + notStoppedViolationsTotal);
        cell14_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell14_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////
    }


    /**
     * Fills the report rows with content
     */
    @Override
    public void fillReport() {
        clearTotals();
        // Create body
        int rowIndx = 17;
        if (dbList != null) {
            for (ReportRouteViolations item : dbList) {

                XSSFRow row = worksheet.createRow(rowIndx);

                addRow(row, item);
                rowIndx++;
            }
            buildDetails();
        }
    }

    private void clearTotals() {
        speedViolationsTotal = 0;
        tripNotFinishedViolationsTotal = 0;
        notStoppedViolationsTotal = 0;
    }

    public String getCustomerCompanyName() {
        return customerCompanyName;
    }

    public void setCustomerCompanyName(String customerCompanyName) {
        this.customerCompanyName = customerCompanyName;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

}
