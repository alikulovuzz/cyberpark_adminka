package uzgps.excel.tripReports.objectMovement;


import org.apache.poi.xssf.usermodel.XSSFSheet;
import uzgps.common.excel.ExcelStyles;

public class CustomWorkSheetOM<T> {
    protected ExcelStyles excelStyles;
    protected int startRowIndex = 0;
    protected int startColIndex = 0;

    private XSSFSheet worksheet;
    private ObjectMovementData tripData;


    public CustomWorkSheetOM(XSSFSheet worksheet, ObjectMovementData tripData, int startRowIndex, int startColIndex) {
        setWorksheet(worksheet);
        setTripData(tripData);

        // 3. Define starting indices for rows and columns
        setStartRowIndex(startRowIndex);
        setStartColIndex(startColIndex);

    }

    public XSSFSheet getWorksheet() {
        return worksheet;
    }

    public void setWorksheet(XSSFSheet worksheet) {
        this.worksheet = worksheet;
    }

    public ObjectMovementData getTripData() {
        return tripData;
    }

    public void setTripData(ObjectMovementData tripData) {
        this.tripData = tripData;
    }

    public int getStartRowIndex() {
        return startRowIndex;
    }

    public void setStartRowIndex(int startRowIndex) {
        this.startRowIndex = startRowIndex;
    }

    public int getStartColIndex() {
        return startColIndex;
    }

    public void setStartColIndex(int startColIndex) {
        this.startColIndex = startColIndex;
    }


}
