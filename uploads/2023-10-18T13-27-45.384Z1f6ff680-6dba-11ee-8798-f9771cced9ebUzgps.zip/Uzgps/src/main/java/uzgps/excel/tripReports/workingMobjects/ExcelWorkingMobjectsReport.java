package uzgps.excel.tripReports.workingMobjects;

import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PatternFormatting;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import uzgps.excel.ExcelDownloader;
import uzgps.persistence.ReportWorkingMobjects;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import static uzgps.excel.utils.XSSFConditionalFormattingBeginsWith.createConditionalFormattingRuleBeginsWith;


/**
 * Created by Stanislav on 26.06.2016 09:54
 */
@Component
public class ExcelWorkingMobjectsReport extends ExcelDownloader<ReportWorkingMobjects> {

    private String customerCompanyName;
    private Integer tripType;
    private String userLogin;

    public ExcelWorkingMobjectsReport() {
        setFileName("WorkingMobjects"); // File name
        sheetName = "Работающие объекты";
        fieldsCount = 32;
    }

    public ExcelWorkingMobjectsReport(MessageSource msgSource, String iCustomerCompanyName, Integer iTripType, String iUserLogin) {
        this();
        this.messageSource = msgSource;
        this.customerCompanyName = iCustomerCompanyName;
        this.tripType = iTripType;
        this.userLogin = iUserLogin;
    }

    /**
     * Builds the column headers
     */
    @Override
    public void buildHeaders() {
        // Create the column headers
        title = translateText("Работающие объекты");

        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 10);
        rowHeader.setHeight((short) 550);

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 0, 0));
        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("Автопарк");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);
        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 1, 1));
        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("Наименование маршрута");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 2, 2));
        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("Направление маршрута");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 3, 3));
        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("Целодневный");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 4, 5));

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("6:00");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell5_1 = rowHeader.createCell(startColIndex + 5);
        cell5_1.setCellValue("");
        cell5_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell5_2 = rowHeader.createCell(startColIndex + 6);
//        cell5_2.setCellValue("");
//        cell5_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 6, 7));

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 6);
        cell6.setCellValue("8:00");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell6_1 = rowHeader.createCell(startColIndex + 7);
        cell6_1.setCellValue("");
        cell6_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell6_2 = rowHeader.createCell(startColIndex + 8);
//        cell6_2.setCellValue("");
//        cell6_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 8, 9));

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 8);
        cell7.setCellValue("08:05 общий выход");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_1 = rowHeader.createCell(startColIndex + 9);
        cell7_1.setCellValue("");
        cell7_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell7_2 = rowHeader.createCell(startColIndex + 11);
//        cell7_2.setCellValue("");
//        cell7_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 10, 11));

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 10);
        cell8.setCellValue("14:00");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8_1 = rowHeader.createCell(startColIndex + 11);
        cell8_1.setCellValue("");
        cell8_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell8_2 = rowHeader.createCell(startColIndex + 14);
//        cell8_2.setCellValue("");
//        cell8_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 12, 13));

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 12);
        cell9.setCellValue("17:00");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9_1 = rowHeader.createCell(startColIndex + 13);
        cell9_1.setCellValue("");
        cell9_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell9_2 = rowHeader.createCell(startColIndex + 14);
//        cell9_2.setCellValue("");
//        cell9_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 14, 15));

        XSSFCell cell10 = rowHeader.createCell(startColIndex + 14);
        cell10.setCellValue("19:00");
        cell10.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10_1 = rowHeader.createCell(startColIndex + 15);
        cell10_1.setCellValue("");
        cell10_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell10_2 = rowHeader.createCell(startColIndex + 17);
//        cell10_2.setCellValue("");
//        cell10_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 16, 17));

        XSSFCell cell11 = rowHeader.createCell(startColIndex + 16);
        cell11.setCellValue("21:00");
        cell11.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell11_1 = rowHeader.createCell(startColIndex + 17);
        cell11_1.setCellValue("");
        cell11_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell11_2 = rowHeader.createCell(startColIndex + 17);
//        cell11_2.setCellValue("");
//        cell11_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 18, 19));

        XSSFCell cell12 = rowHeader.createCell(startColIndex + 18);
        cell12.setCellValue("23:00");
        cell12.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12_1 = rowHeader.createCell(startColIndex + 19);
        cell12_1.setCellValue("");
        cell12_1.setCellStyle(excelStyles.headerCellStyleBlue);

//        XSSFCell cell12_2 = rowHeader.createCell(startColIndex + 17);
//        cell12_2.setCellValue("");
//        cell12_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 20, 20));

        XSSFCell cell13 = rowHeader.createCell(startColIndex + 20);
        cell13.setCellValue("Нарушения");
        cell13.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 21, 22));

        XSSFCell cell14 = rowHeader.createCell(startColIndex + 21);
        cell14.setCellValue("Рейсы");
        cell14.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell14_1 = rowHeader.createCell(startColIndex + 22);
        cell14_1.setCellValue("");
        cell14_1.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 23, 23));

        XSSFCell cell15 = rowHeader.createCell(startColIndex + 23);
        cell15.setCellValue("% вып.");
        cell15.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 24, 24));

        XSSFCell cell16 = rowHeader.createCell(startColIndex + 24);
        cell16.setCellValue("% рег.");
        cell16.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 25, 25));

        XSSFCell cell17 = rowHeader.createCell(startColIndex + 25);
        cell17.setCellValue("% нар.");
        cell17.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 26, 26));

        XSSFCell cell18 = rowHeader.createCell(startColIndex + 26);
        cell18.setCellValue("Опоздавшие");
        cell18.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 27, 27));

        XSSFCell cell19 = rowHeader.createCell(startColIndex + 27);
        cell19.setCellValue("% опоз.");
        cell19.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 28, 28));

        XSSFCell cell20 = rowHeader.createCell(startColIndex + 28);
        cell20.setCellValue("Потеря рейсов");
        cell20.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 29, 29));

        XSSFCell cell21 = rowHeader.createCell(startColIndex + 29);
        cell21.setCellValue("Неоправданное время");
        cell21.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 30, 31));

        XSSFCell cell22 = rowHeader.createCell(startColIndex + 30);
        cell22.setCellValue("Количество");
        cell22.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell22_1 = rowHeader.createCell(startColIndex + 31);
        cell22_1.setCellValue("");
        cell22_1.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        buildSecondHeaders();
    }

    private void buildSecondHeaders() {
        // Create second column headers
        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 11);
        rowHeader.setHeight((short) 570);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("План");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 5);
        cell6.setCellValue("Факт");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 6);
        cell7.setCellValue("План");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_1 = rowHeader.createCell(startColIndex + 7);
        cell7_1.setCellValue("Факт");
        cell7_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_2 = rowHeader.createCell(startColIndex + 8);
        cell7_2.setCellValue("План");
        cell7_2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_3 = rowHeader.createCell(startColIndex + 9);
        cell7_3.setCellValue("Факт");
        cell7_3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 10);
        cell8.setCellValue("План");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 11);
        cell9.setCellValue("Факт");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10 = rowHeader.createCell(startColIndex + 12);
        cell10.setCellValue("План");
        cell10.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell11 = rowHeader.createCell(startColIndex + 13);
        cell11.setCellValue("Факт");
        cell11.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12 = rowHeader.createCell(startColIndex + 14);
        cell12.setCellValue("План");
        cell12.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12_d1 = rowHeader.createCell(startColIndex + 15);
        cell12_d1.setCellValue("Факт");
        cell12_d1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12_d2 = rowHeader.createCell(startColIndex + 16);
        cell12_d2.setCellValue("План");
        cell12_d2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12_d3 = rowHeader.createCell(startColIndex + 17);
        cell12_d3.setCellValue("Факт");
        cell12_d3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13 = rowHeader.createCell(startColIndex + 18);
        cell13.setCellValue("План");
        cell13.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell14 = rowHeader.createCell(startColIndex + 19);
        cell14.setCellValue("Факт");
        cell14.setCellStyle(excelStyles.headerCellStyleBlue);


        XSSFCell cell15 = rowHeader.createCell(startColIndex + 20);
        cell15.setCellValue("");
        cell15.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell16 = rowHeader.createCell(startColIndex + 21);
        cell16.setCellValue("План");
        cell16.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell17 = rowHeader.createCell(startColIndex + 22);
        cell17.setCellValue("Факт");
        cell17.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell18 = rowHeader.createCell(startColIndex + 23);
        cell18.setCellValue("");
        cell18.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell19 = rowHeader.createCell(startColIndex + 24);
        cell19.setCellValue("");
        cell19.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell21 = rowHeader.createCell(startColIndex + 25);
        cell21.setCellValue("");
        cell21.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell22 = rowHeader.createCell(startColIndex + 26);
        cell22.setCellValue("");
        cell22.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell23 = rowHeader.createCell(startColIndex + 27);
        cell23.setCellValue("");
        cell23.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell24 = rowHeader.createCell(startColIndex + 28);
        cell24.setCellValue("");
        cell24.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell25 = rowHeader.createCell(startColIndex + 29);
        cell25.setCellValue("");
        cell25.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell26 = rowHeader.createCell(startColIndex + 30);
        cell26.setCellValue("Съездов");
        cell26.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell27 = rowHeader.createCell(startColIndex + 31);
        cell27.setCellValue("Возвратов");
        cell27.setCellStyle(excelStyles.headerCellStyleBlue);
    }

    private void buildDetails() {
        worksheet.setColumnWidth(0, 12000);

        worksheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 3));
        worksheet.addMergedRegion(new CellRangeAddress(3, 3, 1, 2));

        XSSFRow rowDetails1 = worksheet.createRow((short) startRowIndex + 1);
        rowDetails1.setHeight((short) 300);

        XSSFCell cell1 = rowDetails1.createCell(0);
        cell1.setCellValue("Оперативные данные по учету выполнения плана перевозок и регулярности движения");
        cell1.setCellStyle(excelStyles.bodyCellStyleLeft);

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails3 = worksheet.createRow((short) startRowIndex + 3);
        rowDetails3.setHeight((short) 300);

        XSSFCell cell2 = rowDetails3.createCell(0);
        cell2.setCellValue("Номер автопарка:");
        cell2.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell3 = rowDetails3.createCell(1);
        cell3.setCellValue(getCustomerCompanyName());
        cell3.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails10 = worksheet.createRow((short) startRowIndex + 4);
        rowDetails10.setHeight((short) 300);

        XSSFCell cell10_1 = rowDetails10.createCell(0);
        cell10_1.setCellValue("Начало рейса:");
        cell10_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        String tripTypeStr = "";
        if (getTripType() == 1) {
            tripTypeStr = "График";
        } else if (getTripType() == 2) {
            tripTypeStr = "Произвольно";
        }

        XSSFCell cell10_2_ = rowDetails10.createCell(1);
        cell10_2_.setCellValue(tripTypeStr);
        cell10_2_.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails13 = worksheet.createRow((short) startRowIndex + 6);
        rowDetails13.setHeight((short) 300);

        XSSFCell cell13_1 = rowDetails13.createCell(0);
        cell13_1.setCellValue("Период выборки данных:");
        cell13_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        DateFormat df = new SimpleDateFormat("dd.MM.yyyy");

        XSSFCell cell13_2 = rowDetails13.createCell(1);
        cell13_2.setCellValue(df.format(getReportDate().getTime()) + " 00:00");
        cell13_2.setCellStyle(excelStyles.DATE_STYLE);
        cell13_2.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell13_3 = rowDetails13.createCell(2);
        cell13_3.setCellValue(df.format(getReportDate().getTime() + 86400000L) + " 00:00");
        cell13_3.setCellStyle(excelStyles.DATE_STYLE);
        cell13_3.setCellType(XSSFCell.CELL_TYPE_STRING);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails14 = worksheet.createRow(startRowIndex + 7);

        XSSFCell rowDetails14_1 = rowDetails14.createCell(startColIndex);
        rowDetails14_1.setCellValue(translateText("Время генерации отчета:"));

        XSSFCell rowDetails14_2 = rowDetails14.createCell(startColIndex + 1);
        rowDetails14_2.setCellValue(new Timestamp(new Date().getTime()));
        rowDetails14_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        rowDetails14_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails15 = worksheet.createRow((short) startRowIndex + 8);
        rowDetails15.setHeight((short) 300);

        XSSFCell cell15_1 = rowDetails15.createCell(0);
        cell15_1.setCellValue("Отчет сгенерировал:");
        cell15_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell15_2 = rowDetails15.createCell(1);
        cell15_2.setCellValue(getUserLogin());
        cell15_2.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

    }

    @Override
    public void addRow(XSSFRow row, ReportWorkingMobjects item) {
        XSSFCell cell1 = row.createCell(startColIndex);
        cell1.setCellValue(item.getContractName());
        cell1.setCellStyle(excelStyles.bodyCellStyleLeft);
        cell1.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell2 = row.createCell(startColIndex + 1);
        cell2.setCellValue(item.getTripName());
        cell2.setCellStyle(excelStyles.bodyCellStyleLeft);
        cell2.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell3 = row.createCell(startColIndex + 2);
        cell3.setCellValue(item.getTripDirection());
        cell3.setCellStyle(excelStyles.bodyCellStyleLeft);
        cell3.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell4 = row.createCell(startColIndex + 3);
        cell4.setCellValue(item.getCountMobject());
        cell4.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell4.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell5 = row.createCell(startColIndex + 4);
        cell5.setCellValue(item.getTripPeriodP6());
        cell5.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell5.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell6 = row.createCell(startColIndex + 5);
        cell6.setCellValue(item.getTripPeriodF6());
        cell6.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell6.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell7 = row.createCell(startColIndex + 6);
        cell7.setCellValue(item.getTripPeriodP8());
        cell7.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell7.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell8 = row.createCell(startColIndex + 7);
        cell8.setCellValue(item.getTripPeriodF8());
        cell8.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell8.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell9 = row.createCell(startColIndex + 8);
        cell9.setCellValue(item.getTripPeriodP3());
        cell9.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell9.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell10 = row.createCell(startColIndex + 9);
        cell10.setCellValue(item.getTripPeriodF3());
        cell10.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell10.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell11 = row.createCell(startColIndex + 10);
        cell11.setCellValue(item.getTripPeriodP14());
        cell11.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell11.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell14 = row.createCell(startColIndex + 11);
        cell14.setCellValue(item.getTripPeriodF14());
        cell14.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell14.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell15 = row.createCell(startColIndex + 12);
        cell15.setCellValue(item.getTripPeriodP17());
        cell15.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell15.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell16 = row.createCell(startColIndex + 13);
        cell16.setCellValue(item.getTripPeriodF17());
        cell16.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell16.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell17 = row.createCell(startColIndex + 14);
        cell17.setCellValue(item.getTripPeriodP19());
        cell17.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell17.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell16_1 = row.createCell(startColIndex + 15);
        cell16_1.setCellValue(item.getTripPeriodF19());
        cell16_1.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell16_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell17_1 = row.createCell(startColIndex + 16);
        cell17_1.setCellValue(item.getTripPeriodP21());
        cell17_1.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell17_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell18 = row.createCell(startColIndex + 17);
        cell18.setCellValue(item.getTripPeriodF21());
        cell18.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell18.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell19 = row.createCell(startColIndex + 18);
        cell19.setCellValue(item.getTripPeriodP23());
        cell19.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell19.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell20 = row.createCell(startColIndex + 19);
        cell20.setCellValue(item.getTripPeriodF23());
        cell20.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell20.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell21 = row.createCell(startColIndex + 20);
        cell21.setCellValue(item.getViolationsCount());
        cell21.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell21.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell22 = row.createCell(startColIndex + 21);
        cell22.setCellValue(item.getTripPeriodPAll());
        cell22.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell22.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell23 = row.createCell(startColIndex + 22);
        cell23.setCellValue(item.getTripPeriodFAll());
        cell23.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell23.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell24 = row.createCell(startColIndex + 23);
        cell24.setCellValue(item.getAllRoutesPercent() / 100.0);
        cell24.setCellStyle(excelStyles.PERCENT_STYLE);
        cell24.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell25 = row.createCell(startColIndex + 24);
        cell25.setCellValue(item.getTripsWithoutViolationPercent() / 100);
        cell25.setCellStyle(excelStyles.PERCENT_STYLE);
        cell25.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell26 = row.createCell(startColIndex + 25);
        cell26.setCellValue(item.getTripsWithViolationPercent() / 100);
        cell26.setCellStyle(excelStyles.PERCENT_STYLE);
        cell26.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell27 = row.createCell(startColIndex + 26);
        cell27.setCellValue(item.getLateRoutesCount());
        cell27.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell27.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell28 = row.createCell(startColIndex + 27);
        cell28.setCellValue(item.getLateRoutesPercent() / 100);
        cell28.setCellStyle(excelStyles.PERCENT_STYLE);
        cell28.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell29 = row.createCell(startColIndex + 28);
        cell29.setCellValue(item.getCountTripsNotFinished());
        cell29.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell29.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell30 = row.createCell(startColIndex + 29);
        cell30.setCellValue(item.getRoutesLateTimes());
        cell30.setCellStyle(excelStyles.TIME_STYLE);
        cell30.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell31 = row.createCell(startColIndex + 30);
        cell31.setCellValue(item.getAllRouteExitCount());
        cell31.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell31.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell32 = row.createCell(startColIndex + 31);
        cell32.setCellValue(item.getAllRouteReturnCount());
        cell32.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell32.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

    }

    private void setConditionalFormatting(XSSFSheet worksheet, int maxRow) throws Exception {
        XSSFSheetConditionalFormatting sheetCF = worksheet.getSheetConditionalFormatting();

        CellRangeAddress[] regions1 = {CellRangeAddress.valueOf("H25:H" + maxRow)};

        XSSFConditionalFormattingRule ruleGreen = createConditionalFormattingRuleBeginsWith(sheetCF, "Завершен");
        XSSFConditionalFormattingRule ruleYellow = createConditionalFormattingRuleBeginsWith(sheetCF, "Активный");
        XSSFConditionalFormattingRule ruleRed = createConditionalFormattingRuleBeginsWith(sheetCF, "Не завершен");
        XSSFConditionalFormattingRule ruleBlue = createConditionalFormattingRuleBeginsWith(sheetCF, "Не начат");

//        ConditionalFormattingRule ruleYellow = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Активный");
//        ConditionalFormattingRule ruleRed = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Не завершен");
//        ConditionalFormattingRule ruleBlue = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Не начат");

        PatternFormatting patternFmtGreen = ruleGreen.createPatternFormatting();
        patternFmtGreen.setFillBackgroundColor(IndexedColors.LIGHT_GREEN.index);

        PatternFormatting patternFmtYellow = ruleYellow.createPatternFormatting();
        patternFmtYellow.setFillBackgroundColor(IndexedColors.YELLOW.index);

        PatternFormatting patternFmtRed = ruleRed.createPatternFormatting();
        patternFmtRed.setFillBackgroundColor(IndexedColors.RED.index);
//
        PatternFormatting patternFmtBlue = ruleBlue.createPatternFormatting();
        patternFmtBlue.setFillBackgroundColor(IndexedColors.LIGHT_BLUE.index);

        XSSFConditionalFormattingRule[] cfRules = new XSSFConditionalFormattingRule[]{ruleGreen, ruleYellow, ruleRed};

        sheetCF.addConditionalFormatting(regions1, cfRules);
        sheetCF.addConditionalFormatting(regions1, ruleBlue);
    }

    /**
     * Fills the report rows with content
     */
    @Override
    public void fillReport() {
        // Create body
        int rowIndx = 12;
        if (dbList != null) {
            for (ReportWorkingMobjects item : dbList) {

                XSSFRow row = worksheet.createRow(rowIndx);

                addRow(row, item);
                rowIndx++;
            }
            buildDetails();
        }
    }

    /**
     * Builds the report title and the date header
     */
    @Override
    public void buildTitle() {
        short rowHeight = 500;
        // Create report title
        XSSFRow rowTitle = worksheet.createRow(startRowIndex);
        rowTitle.setHeight(rowHeight);
        XSSFCell cellTitle = rowTitle.createCell(startColIndex);
        cellTitle.setCellValue(title);
        cellTitle.setCellStyle(excelStyles.cellStyleTitle);

        // Create merged region for the report title
        worksheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 2));

    }

    public String getCustomerCompanyName() {
        return customerCompanyName;
    }

    public void setCustomerCompanyName(String customerCompanyName) {
        this.customerCompanyName = customerCompanyName;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }
}
