package uzgps.excel;

import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.context.i18n.LocaleContextHolder;

import java.util.Locale;

/**
 * Created by Stanislav on 01.04.2016 17:25.
 */
public class ExcelStyles {

    static Locale locale;

    public static XSSFSheet worksheet;

    public static HSSFPalette palette;

    public static XSSFCellStyle headerCellStyle;
    public static XSSFCellStyle cellStyleTitle;

    public static XSSFCellStyle bodyCellStyle;
    public static XSSFCellStyle bodyCellStyleCenter;

    public static XSSFCellStyle NUMERIC_STYLE;
    public static XSSFCellStyle CURRENCY_STYLE;
    public static XSSFCellStyle DATE_STYLE;
    public static XSSFCellStyle DATE_TIME_STYLE;
    public static XSSFCellStyle TIME_HOUR_STYLE;
    public static XSSFCellStyle DOUBLE_STYLE;
    public static XSSFCellStyle NUMBER_STYLE;

    public ExcelStyles() {

    }

    public static void createStyles(XSSFSheet _worksheet) {
        worksheet = _worksheet;
        locale = LocaleContextHolder.getLocale();
//        palette = worksheet.getWorkbook().getCustomPalette();

        createTitleStyle();
        createHeaderStyle();
        createTypedStyles();
    }

    private static void createTitleStyle() {
        // Create font style for the report title
        Font fontTitle = worksheet.getWorkbook().createFont();
        fontTitle.setBoldweight(Font.BOLDWEIGHT_BOLD);
        fontTitle.setFontHeight((short) 280);

        // Create cell style for the report title
        cellStyleTitle = worksheet.getWorkbook().createCellStyle();
        cellStyleTitle.setAlignment(CellStyle.ALIGN_CENTER);
        cellStyleTitle.setWrapText(true);
        cellStyleTitle.setFont(fontTitle);
    }

    private static void createHeaderStyle() {
        // Create font style for the headers
        Font font = worksheet.getWorkbook().createFont();
        font.setBoldweight(Font.BOLDWEIGHT_BOLD);
//        font.setColor(HSSFColor.WHITE.index);

        // Create cell style for the headers
        headerCellStyle = worksheet.getWorkbook().createCellStyle();

//      headerCellStyle.setFillForegroundColor(IndexedColors.GREY_50_PERCENT.getIndex());
//        HSSFColor myColor = palette.findSimilarColor(0, 165, 236);
//        short palIndex = myColor.getIndex();
        headerCellStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(0, 165, 236)));

        headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
//      headerCellStyle.setFillPattern(CellStyle.);
        headerCellStyle.setAlignment(CellStyle.ALIGN_CENTER);
        headerCellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        headerCellStyle.setWrapText(true);
        headerCellStyle.setFont(font);
        headerCellStyle.setBorderBottom(CellStyle.BORDER_THIN);
    }

    private static void createTypedStyles() {
        XSSFDataFormat df = worksheet.getWorkbook().createDataFormat();

        // Create cell style for the body
        bodyCellStyle = worksheet.getWorkbook().createCellStyle();
        bodyCellStyle.setAlignment(CellStyle.ALIGN_CENTER);
        bodyCellStyle.setWrapText(true);

        // Create cell style for the body with center alignment
        bodyCellStyleCenter = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleCenter.setAlignment(CellStyle.ALIGN_CENTER);
        bodyCellStyleCenter.setWrapText(true);

        // Create font style for the report title
        Font numericFontTitle = worksheet.getWorkbook().createFont();
        numericFontTitle.setBoldweight(Font.BOLDWEIGHT_BOLD);
        numericFontTitle.setFontHeight((short) 180);
        numericFontTitle.setColor(HSSFColor.GREEN.index);

        // Create cell style for numeric format
//        numericCellStyle.setFont(numericFontTitle);
//        numericCellStyle.setFillBackgroundColor(IndexedColors.AQUA.getIndex());
//        numericCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
//        numericCellStyle.setFillForegroundColor(IndexedColors.ORANGE.getIndex());
        NUMERIC_STYLE = worksheet.getWorkbook().createCellStyle();
        NUMERIC_STYLE.setAlignment(CellStyle.ALIGN_CENTER);
        NUMERIC_STYLE.setWrapText(true);
        NUMERIC_STYLE.setDataFormat((short) 4); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        // Create cell style for currency format
        CURRENCY_STYLE = worksheet.getWorkbook().createCellStyle();
        CURRENCY_STYLE.setAlignment(CellStyle.ALIGN_CENTER);
        CURRENCY_STYLE.setWrapText(true);
        CURRENCY_STYLE.setDataFormat((short) 5);

        // Create cell style for date format
//        String excelFormatPattern = DateFormatConverter.convert(locale, "dd MM, yyyy");

        DATE_STYLE = worksheet.getWorkbook().createCellStyle();
        DATE_STYLE.setAlignment(CellStyle.ALIGN_CENTER);
        DATE_STYLE.setWrapText(true);
        DATE_STYLE.setDataFormat(df.getFormat("dd.MM.yyyy"));

        // Create cell style for date format
//        String excelFormatPattern = DateFormatConverter.convert(locale, "dd MM, yyyy");
//        HSSFDataFormat df = worksheet.getWorkbook().createDataFormat();
        DATE_TIME_STYLE = worksheet.getWorkbook().createCellStyle();
        DATE_TIME_STYLE.setAlignment(CellStyle.ALIGN_CENTER);
        DATE_TIME_STYLE.setWrapText(false);
        DATE_TIME_STYLE.setDataFormat(df.getFormat("dd.MM.yyyy HH:mm"));


        TIME_HOUR_STYLE = worksheet.getWorkbook().createCellStyle();
        TIME_HOUR_STYLE.setAlignment(CellStyle.ALIGN_CENTER);
        TIME_HOUR_STYLE.setWrapText(true);
        TIME_HOUR_STYLE.setDataFormat(df.getFormat("HH:mm:ss"));

        DOUBLE_STYLE = worksheet.getWorkbook().createCellStyle();
        DOUBLE_STYLE.setAlignment(CellStyle.ALIGN_CENTER);
        DOUBLE_STYLE.setWrapText(true);
        DOUBLE_STYLE.setDataFormat(df.getFormat("0.00"));

        NUMBER_STYLE = worksheet.getWorkbook().createCellStyle();
        NUMBER_STYLE.setAlignment(CellStyle.ALIGN_CENTER);
        NUMBER_STYLE.setWrapText(true);
        NUMBER_STYLE.setDataFormat(df.getFormat("#,##0_)"));
    }

}
