package uzgps.excel;

import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.ss.usermodel.charts.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.apache.poi.xssf.usermodel.charts.XSSFChartLegend;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTLineSer;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTPlotArea;
import org.openxmlformats.schemas.drawingml.x2006.chart.CTUnsignedInt;
import org.springframework.stereotype.Component;
import uz.netex.datatype.MobjectBig;
import uz.netex.uzgps.core.models.sensor.SensorDataType;
import uz.netex.uzgps.core.models.sensor.Translator;
import uzgps.map.models.Message;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.SensorDisplay;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

/**
 * Created by Gayratjon on 19.07.2016.
 */
@Component
public class ExcelDownloadTrackData extends ExcelDownloaderTrackData<Message> {

  private ContractSettings contractSettings;
  private MobjectBig mobjectBig;
  private Date startDate;
  private Date endDate;
  private static final Integer DEFAULT_CHART_COLUMNS = 30;
  private static final Integer DEFAULT_CHART_TRACKS_COUNT = 500;

  public ExcelDownloadTrackData() {
//        setFileName("TrackData"); // File name
    sheetName = "Tracks data";
    chartSheetName = "Tracks chart";
    filedsCount = 10;
  }

  @Override
  public void createChartWorksheet() {
    // 1. Create new chart worksheet
    chartWorksheet = workbook.createSheet(chartSheetName);
    // 2 Create styles
//        excelStyles = new ExcelStyles();
//        excelStyles.createStyles(chartWorksheet);

    chartStartRowIndex = 0;
    chartStartColIndex = 0;
  }

  public void setContractSettings(ContractSettings contractSettings) {
    this.contractSettings = contractSettings;
  }

  public void setToken(Long token) {
    this.token = token;
  }

  public void setDateInterval(Date startDate, Date endDate) {
    this.startDate = startDate;
    this.endDate = endDate;
    setFileName("TrackData"); // File name
  }

  public void setMobjectBig(MobjectBig mobjectBig) {
    this.mobjectBig = mobjectBig;
  }

  /**
   * Builds the column headers
   */
  @Override
  public void buildHeaders() {
    if (contractSettings != null) {
      // Create the column headers
      XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 2);
      rowHeader.setHeight((short) 500);

      title = "";

      if (mobjectBig != null) {
        title = mobjectBig.getName();
      }

      int cellIndex = 0;

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 8) == 1) {
        // Дата трека
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("tracks.data"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 9) == 1) {
        // Время трека
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("tracks.time"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 10) == 1) {
        // Дата получения
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.date.received"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 11) == 1) {
        // Время получения
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.time.received"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 15) == 1) {
        // Широта
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("report.latitude"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 16) == 1) {
        // Долгота
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("poi.longitude"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 17) == 1) {
        // Высота(м)
        String header = translateText("poi.height") + " (" + translateText("unit.m") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 18) == 1) {
        // Угол(гр)
        String header = translateText("track.angle") + " (" + translateText("unit.gr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 19) == 1) {
        // Скорость трека (км / ч)
        String header = translateText("tracks.seed") + " (" + translateText("unit.km.hr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 20) == 1) {
        // Скорость IO (км / ч)
        String header = translateText("label.speed") + " IO" + " (" + translateText("unit.km.hr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 21) == 1) {
        // Одометр(м)
        String header = translateText("track.odomert") + " (" + translateText("unit.m") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 25) == 1) {
        // Датчик движения
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.movementValue"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 26) == 1) {
        // Датчик зажигания
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("ignition.sensor"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 27) == 1) {
        // Тревожная кнопка
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("alarm.button"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 15) == 1) {
        // Цифровой вход 1
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.digital") + " 1");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 16) == 1) {
        // Цифровой вход 2
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.digital") + " 2");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 28) == 1) {
        // Цифровой вход 3
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.digital") + " 3");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 29) == 1) {
        // Цифровой вход 4
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.digital") + " 4");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 1) == 1) {
        // Аналоговый вход 1 (мВ)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("analog.input") + " 1 (мВ)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 2) == 1) {
        // Аналоговый вход 2 (мВ)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("analog.input") + " 2 (мВ)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 3) == 1) {
        // Аналоговый вход 3 (мВ)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("analog.input") + " 3 (мВ)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 4) == 1) {
        // Аналоговый вход 4 (мВ)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("analog.input") + " 4 (мВ)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 5) == 1) {
        // Батарея трекера (В)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("tracks.batary") + " (B)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 6) == 1) {
        // Ток заряда трекера(мА)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("change.current.tracker") + " (mA)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 7) == 1) {
        // Внешнее питание (В)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("external.power") + " (B)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 23) == 1) {
        // Уровень заряда батареи (%)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("battery.percent") + " (%)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 8) == 1) {
        // Код оператора GSM
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("code.operator"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 9) == 1) {
        // Уровень сигнала GSM
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("signal.level"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 10) == 1) {
        // Cell ID
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "Cell ID");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 11) == 1) {
        // LAC
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "LAC");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 12) == 1) {
        // GNSS
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "GNSS");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 13) == 1) {
        // Количество спутников
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("message.SAT"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 14) == 1) {
        // PDOP
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "PDOP");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 15) == 1) {
        // HDOP
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "HDOP");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 16) == 1) {
        // PCB t°C
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "PCB t°C");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 17) == 1) {
        // Профиль трекера
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("profile.trcker"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 17) == 1) {
        // Приоритет трека
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.priority"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 18) == 1) {
        // Deep Sleep
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "Deep Sleep");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 19) == 1) {
        // Показания ДУТ 1 (л)
        String header = translateText("indication.dut") + " 1 " + "(" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 22) == 1) {
        // Показания ДУТ 2 (л)
        String header = translateText("indication.dut") + " 2 " + "(" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 1) == 1) {
        // Показания ДУТ 3 (л)
        String header = translateText("indication.dut") + " 3 " + "(" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 2) == 1) {
        // Показания ДУТ 4 (л)
        String header = translateText("indication.dut") + " 4 " + "(" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 25) == 1) {
        // Суммарные показания ДУТ (л)
        String header = translateText("indication.dutTotal") + "(" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 20) == 1) {
        // COM 1 (квант)
        String header = "COM  1 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 21) == 1) {
        // COM 1 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 1 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 21) == 1) {
        // COM 1 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 1 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 23) == 1) {
        // COM 2 (квант)
        String header = "COM  2 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 24) == 1) {
        // COM 2 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 2 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 22) == 1) {
        // COM 2 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 2 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 3) == 1) {
        // COM 3 (квант)
        String header = "COM  3 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 4) == 1) {
        // COM 3 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 3 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 5) == 1) {
        // COM 3 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 3 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 6) == 1) {
        // COM 4 (квант)
        String header = "COM  4 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 7) == 1) {
        // COM 4 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 4 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 8) == 1) {
        // COM 4 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 4 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 9) == 1) {
        // COM 5 (квант)
        String header = "COM  5 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 10) == 1) {
        // COM 5 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 5 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 11) == 1) {
        // COM 5 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 5 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 12) == 1) {
        // COM 6 (квант)
        String header = "COM  6 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 13) == 1) {
        // COM 6 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 6 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 14) == 1) {
        // COM 6 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 6 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 15) == 1) {
        // COM 7 (квант)
        String header = "COM  7 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 16) == 1) {
        // COM 7 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 7 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 17) == 1) {
        // COM 7 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 7 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 18) == 1) {
        // COM 8 (квант)
        String header = "COM  8 " + "(" + translateText("unit.kvant") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 19) == 1) {
        // COM 8 (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 8 (t°C)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 20) == 1) {
        // COM 8 (code)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "COM 8 (code)");
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 26) == 1) {
        // Скорость CAN (км / ч)
        String header = translateText("label.speed") + " CAN (" + translateText("unit.km.hr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 27) == 1) {
        // Пробег CAN (км)
        String header = translateText("track.total.distanse") + " CAN (" + translateText("unit.km") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 28) == 1) {
        // Пробег до обслуживания CAN (км)
        String header = translateText("track.service") + " CAN (" + translateText("unit.km") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 29) == 1) {
        // Расход топлива CAN(л)
        String header = translateText("fuel.consumption") + " CAN (" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 1) == 1) {
        // Уровень топлива CAN( %)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("state.bak") + " CAN (%)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 2) == 1) {
        // Уровень топлива CAN(л)
        String header = translateText("state.bak") + " CAN (" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 3) == 1) {
        // Точный расход топлива(л)
        String header = translateText("high.resolution") + " (" + translateText("unit.litr") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 7) == 1) {
        // Средний расход топлива (л/100км)
        String header = translateText("iodata.fuelConsumption.average") + " (" + translateText("unit.litr.100km") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 8) == 1) {
        // Мгновенный расход топлива (л/100км)
        String header = translateText("iodata.fuelConsumption.instant") + " (" + translateText("unit.litr.100km") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 18) == 1) {
        // Топливный баланс (%)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.shortTermFuelTrim") + " (%)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 19) == 1) {
        // Частота впрыска топлива (°)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.fuelInjectionTiming") + " (°)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 4) == 1) {
        // Обороты двигателя (об / мин)
        String header = translateText("track.engine.rpm") + " (" + translateText("unit.ob.min") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 5) == 1) {
        // Педаль акселератора (%)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("track.accelerator") + " (%)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 20) == 1) {
        // Положение дроссельной заслонки (%)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.engineThrottlePosition") + " (%)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 21) == 1) {
        // Расчетное значение нагрузки на двигатель (%)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.engineLoadPercent") + " (%)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 22) == 1) {
        // Абсолютное значение нагрузки (%)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.loadAbsoluteValue") + " (%)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 6) == 1) {
        // Время работы двигатля (ч)
        String header = translateText("track.engine.hour") + " (" + translateText("unit.hour") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 23) == 1) {
        // Время, с запуска двигателя (ч)
        String header = translateText("iodata.timeEngineStart") + " (" + translateText("unit.hour") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 24) == 1) {
        // Угол опережения зажигания (гр)
        String header = translateText("iodata.timingAdvance") + " (" + translateText("unit.o") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 9) == 1) {
        // Температура двигателя (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("engine.temperature") + " (t°C)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 25) == 1) {
        // Температура масла двигателя (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.engineOilTemperature") + " (t°C)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 10) == 1) {
        // Температура окружающего воздуха (t°C)
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("temperature.cab") + " (t°C)");
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 26) == 1) {
        // Количество кодов неисправностей
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("iodata.dtcCount"));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 27) == 1) {
        // Пробег со времени сброса кодов (км)
        String header = translateText("iodata.distanceAfterCodesClear") + " (" + translateText("unit.km") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 28) == 1) {
        // Время с момента сброса кодов нейсправностей (ч)
        String header = translateText("iodata.timeCodesCleared") + " (" + translateText("unit.hour") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 29) == 1) {
        // Пробег с MIL ON (км)
        String header = translateText("iodata.distanceWithMILon") + " (" + translateText("unit.km") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 30) == 1) {
        // Время с момента MIL ON (ч)
        String header = translateText("iodata.timeWithMILon") + " (" + translateText("unit.hour") + ")";
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 11) == 1) {
        // VIN
        createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, "VIN");
      }

      if (contractSettings.getSensorDisplayList() != null) {
        for (SensorDisplay display : contractSettings.getSensorDisplayList()) {
          if (display.isTracking()) {
              String unitName = display.getType().getUnit();
              String header = display.getName().toUpperCase() + " " +
                      Translator.getName(display.getType(), locale);
              if (unitName != null && !unitName.isEmpty()) {
                  header += " (" + unitName + ")";
              }
              createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, header);
          }
        }
      }
    }
  }

  @Override
  public void buildChartHeaders() {
    if (contractSettings != null) {
      // Create the column headers
      XSSFRow rowHeader = chartWorksheet.createRow((short) chartStartRowIndex + 2);
      rowHeader.setHeight((short) 500);
      title = "";

      if (mobjectBig != null) {
        title = mobjectBig.getName();
      }

      int cellIndex = 0;

      // Data for chart
      // Дата трека
      createCell(rowHeader, ExcelStyles.bodyCellStyle, cellIndex++, translateText("tracks.data"));

      // Скорость трека (км / ч)
      String speedHeader = translateText("tracks.seed") + " (" + translateText("unit.km.hr") + ")";
      createCell(rowHeader, ExcelStyles.bodyCellStyle, cellIndex++, speedHeader);

      // Суммарно показания ДУТ (л)
      String bakHeader;
      bakHeader = translateText(translateText("total.reeading") + " (" + translateText("unit.litr") + ")");
      createCell(rowHeader, ExcelStyles.bodyCellStyle, cellIndex++, bakHeader);

      // Датчик зажигания
      createCell(rowHeader, ExcelStyles.bodyCellStyle, cellIndex++, translateText("ignition.sensor"));

      // Внешнее питание (В)
      createCell(rowHeader, ExcelStyles.headerCellStyle, cellIndex++, translateText("external.power") + " (B)");

      // Set columns width = 0, for chart
      chartWorksheet.setColumnWidth(0, 20);
      chartWorksheet.setColumnWidth(1, 20);
      chartWorksheet.setColumnWidth(2, 20);
      chartWorksheet.setColumnWidth(3, 20);
      chartWorksheet.setColumnWidth(4, 20);
    }
  }

  @Override
  public void addRow(XSSFRow row, Message item) {
    if (contractSettings != null) {
      int cellIndex = 0;

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 8) == 1) {
        // Дата трека
        createCell(row, ExcelStyles.DATE_TIME_STYLE, cellIndex++, new Date(item.getDate()));
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 9) == 1) {
        // Время трека
        createCell(row, ExcelStyles.TIME_HOUR_STYLE, cellIndex++, new Date(item.getDate()));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 10) == 1) {
        // Дата получения
        createCell(row, ExcelStyles.DATE_STYLE, cellIndex++, new Date(item.getRegDate()));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 11) == 1) {
        // Время получения
        createCell(row, ExcelStyles.TIME_HOUR_STYLE, cellIndex++, new Date(item.getRegDate()));
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 15) == 1) {
        // Широта
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLatitude());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 16) == 1) {
        // Долгота
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLongitude());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 17) == 1) {
        // Высота(м)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getAltitude());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 18) == 1) {
        // Угол(гр)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getAngle());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 19) == 1) {
        // Скорость трека (км / ч)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getSpeed());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 20) == 1) {
        // Скорость IO (км / ч)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getSpeedometer());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 21) == 1) {
        // Одометр(м)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getOdometer());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 25) == 1) {
        // Датчик движения
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getMovement());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 26) == 1) {
        // Датчик зажигания
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getEngineOn());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 27) == 1) {
        // Тревожная кнопка
        if (item.getSosButtonPressed() != null && item.getSosButtonPressed() == 1) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getSosButtonPressed());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 15) == 1) {
        // Цифровой вход 1
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getDigital1());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 16) == 1) {
        // Цифровой вход 2
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getDigital2());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 28) == 1) {
        // Цифровой вход 3
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getDigital3());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart1(), 29) == 1) {
        // Цифровой вход 4
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getDigital4());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 1) == 1) {
        // Аналоговый вход 1 (мВ)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getAnalog1());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 2) == 1) {
        // Аналоговый вход 2 (мВ)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getAnalog2());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 3) == 1) {
        // Аналоговый вход 3 (мВ)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getAnalog3());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 4) == 1) {
        // Аналоговый вход 4 (мВ)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getAnalog4());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 5) == 1) {
        // Батарея трекера (В)
        if (item.getInternalBatteryVoltageDouble() != null) {
          createCell(row, ExcelStyles.DOUBLE_STYLE, cellIndex++, item.getInternalBatteryVoltageDouble());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 6) == 1) {
        // Ток заряда трекера(мА)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getInternalBatteryCurrent());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 7) == 1) {
        // Внешнее питание (В)
        if (item.getExternalPowerVoltageDouble() != null) {
          createCell(row, ExcelStyles.DOUBLE_STYLE, cellIndex++, item.getExternalPowerVoltageDouble());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 23) == 1) {
        // Уровень заряда батареи (%)
        if (item.getBatteryPercent() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getBatteryPercent() / 10.0);
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 8) == 1) {
        // Код оператора GSM
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getCurrentOperatorCode());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 9) == 1) {
        // Уровень сигнала GSM
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getGsmSignalLevel());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 10) == 1) {
        // Cell ID
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getCellId());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 11) == 1) {
        // LAC
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getAreaCode());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 12) == 1) {
        // GNSS
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getGnssStatus());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 13) == 1) {
        // Количество спутников
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getSatellites());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 14) == 1) {
        // PDOP
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getGpsPdop());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 15) == 1) {
        // HDOP
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getGpsHdop());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 16) == 1) {
        // PCB t°C
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getPcbTemperature());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 17) == 1) {
        // Профиль трекера
        String value = "";
        if (item.getActualProfile() != null || item.getModeHomeRoaming() != null) {
          if (item.getActualProfile() != null) {
            value += item.getActualProfile();
          }

          value += "/";

          if (item.getModeHomeRoaming() != null) {
            value += item.getModeHomeRoaming();
          }
        }

        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, value);
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 17) == 1) {
        // Приоритет трека
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getPriority());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 18) == 1) {
        // Deep Sleep
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getDeepSleep());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 19) == 1) {
        // Показания ДУТ 1 (л)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getBak1());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 22) == 1) {
        // Показания ДУТ 2 (л)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getBak2());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 1) == 1) {
        // Показания ДУТ 3 (л)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getBak3());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 2) == 1) {
        // Показания ДУТ 4 (л)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getBak4());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 25) == 1) {
        // Суммарные показания ДУТ (л)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getBakTotal());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 20) == 1) {
        // COM 1 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getFuelLevelMeter1());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 21) == 1) {
        // COM 1 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getFuelTemperature1());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 21) == 1) {
        // COM 1 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls1Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 23) == 1) {
        // COM 2 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getFuelLevelMeter2());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 24) == 1) {
        // COM 2 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getFuelTemperature2());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 22) == 1) {
        // COM 2 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls2Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 3) == 1) {
        // COM 3 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls3Level());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 4) == 1) {
        // COM 3 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls3Temperature());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 5) == 1) {
        // COM 3 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls3Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 6) == 1) {
        // COM 4 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls4Level());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 7) == 1) {
        // COM 4 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls4Temperature());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 8) == 1) {
        // COM 4 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls4Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 9) == 1) {
        // COM 5 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls5Level());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 10) == 1) {
        // COM 5 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls5Temperature());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 11) == 1) {
        // COM 5 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls5Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 12) == 1) {
        // COM 6 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls6Level());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 13) == 1) {
        // COM 6 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls6Temperature());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 14) == 1) {
        // COM 6 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls6Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 15) == 1) {
        // COM 7 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls7Level());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 16) == 1) {
        // COM 7 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls7Temperature());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 17) == 1) {
        // COM 7 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls7Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 18) == 1) {
        // COM 8 (квант)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls8Level());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 19) == 1) {
        // COM 8 (t°C)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls8Temperature());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart4(), 20) == 1) {
        // COM 8 (code)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLls8Code());
      }

      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 26) == 1) {
        // Скорость CAN (км / ч)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getSpeedVechicle());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 27) == 1) {
        // Пробег CAN (км)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getDistanceTotal());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 28) == 1) {
        // Пробег до обслуживания CAN (км)
        if (item.getDistanceService() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getDistanceService());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart2(), 29) == 1) {
        // Расход топлива CAN(л)
        if (item.getFuelCounterTotal() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getFuelCounterTotal());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 1) == 1) {
        // Уровень топлива CAN( %)
        if (item.getFuelLevel() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getFuelLevel());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 2) == 1) {
        // Уровень топлива CAN(л)
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getFuelLevelLitr());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 3) == 1) {
        // Точный расход топлива(л)
        if (item.getFuelCounterTotalHigh() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getFuelCounterTotalHigh());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 7) == 1) {
        // Относительный расход топлива(км / л)
        if (item.getFuelEconomyDistPerLitr() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getFuelEconomyDistPerLitr());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 8) == 1) {
        // Относительный расход топлива(л / ч)
        if (item.getFuelEconomyLitrPerHour() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getFuelEconomyLitrPerHour());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 18) == 1) {
        // Топливный баланс (%)
        if (item.getShortTermFuelTrim() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getShortTermFuelTrim());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 19) == 1) {
        // Частота впрыска топлива (°)
        if (item.getFuelInjectionTiming() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getFuelInjectionTiming());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 4) == 1) {
        // Обороты двигателя (об / мин)
        if (item.getEngineRpm() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getEngineRpm());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 5) == 1) {
        // Педаль акселератора ( %)
        if (item.getEnginePedalAccelerator() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getEnginePedalAccelerator());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 20) == 1) {
        // Положение дроссельной заслонки (%)
        if (item.getEngineThrottlePosition() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getEngineThrottlePosition());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 21) == 1) {
        // Расчетное значение нагрузки на двигатель (%)
        if (item.getEngineLoadPercent() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getEngineLoadPercent());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 22) == 1) {
        // Абсолютное значение нагрузки (%)
        if (item.getLoadAbsoluteValue() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getLoadAbsoluteValue());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 6) == 1) {
        // Время работы двигатля (ч)
        if (item.getEngineWorkHour() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getEngineWorkHour());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 23) == 1) {
        // Время, с запуска двигателя (ч)
        if (item.getTimeEngineStart() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getTimeEngineStart());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 24) == 1) {
        // Угол опережения зажигания (гр)
        if (item.getTimingAdvance() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getTimingAdvance());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 9) == 1) {
        // Температура двигателя (t°C)
        if (item.getEngineCoolantTemperature() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getEngineCoolantTemperature());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 25) == 1) {
        // Температура масла двигателя (t°C)
        if (item.getEngineOilTemperature() != null) {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getEngineOilTemperature());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 10) == 1) {
        // Температура окружающего воздуха (t°C)
        if (item.getAirTemperature() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getAirTemperature());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 26) == 1) {
        // Количество кодов неисправностей
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getDtcCount());
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 27) == 1) {
        // Пробег со времени сброса кодов (км)
        if (item.getDistanceAfterCodesClear() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getDistanceAfterCodesClear());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 28) == 1) {
        // Время с момента сброса кодов нейсправностей (ч)
        if (item.getTimeCodesCleared() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getTimeCodesCleared());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 29) == 1) {
        // Пробег с MIL ON (км)
        if (item.getDistanceWithMilOn() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getDistanceWithMilOn());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 30) == 1) {
        // Время с момента MIL ON (ч)
        if (item.getTimeWithMILon() != null) {
          createCell(row, ExcelStyles.NUMBER_STYLE, cellIndex++, item.getTimeWithMILon());
        } else {
          createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
        }
      }
      if (contractSettings.hasValueInPosition(contractSettings.getTrackingValuesPart3(), 11) == 1) {
        // VIN
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getVinNumber());
      }

      if (contractSettings.getSensorDisplayList() != null) {
        for (SensorDisplay display : contractSettings.getSensorDisplayList()) {
          if (display.isTracking()) {
              Map<SensorDataType, Object> sensor = item.getSensorMap().getSensorByName(display.getName());
              Object value = sensor != null
                      ? sensor.get(display.getType())
                      : null;
              createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, value);
          }
        }
      }
    }
  }

  @Override
  public void addChartRow(XSSFRow row, Message item) {
    if (contractSettings != null) {
      int cellIndex = 0;

      // Data for chart
      // Дата трека
      createCellFromDateToString(row, ExcelStyles.DATE_TIME_STYLE, cellIndex++, new Date(item.getDate()));

      // Скорость трека (км / ч)
      createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getSpeed());

      // Суммарно показания ДУТ(л)
      Integer sumDut = item.getBakTotal();
      if (sumDut != null && sumDut > 0) {
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, sumDut);
      } else {
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
      }

      // Датчик зажигания
      createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, item.getEngineOn() * 5);

      // Внешнее питание (В)
      if (item.getExternalPowerVoltageDouble() != null) {
        createCell(row, ExcelStyles.DOUBLE_STYLE, cellIndex++, item.getExternalPowerVoltageDouble());
      } else {
        createCell(row, ExcelStyles.bodyCellStyleCenter, cellIndex++, "");
      }

    }
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, String value) {
    XSSFCell cell = row.createCell(chartStartColIndex + index);
    try {
      cell.setCellValue(value);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_STRING);
    } catch (Exception ex) {

    }

    return cell;
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, Object value) {
    if (value instanceof Byte) {
      return createCell(row, cellStyle, index, (Byte) value);
    } else if (value instanceof Short) {
      return createCell(row, cellStyle, index, (Short) value);
    } else if (value instanceof Integer) {
      return createCell(row, cellStyle, index, (Integer) value);
    } else if (value instanceof Long) {
      return createCell(row, cellStyle, index, (Long) value);
    } else if (value instanceof Double) {
      return createCell(row, cellStyle, index, (Double) value);
    } else if (value instanceof String) {
      return createCell(row, cellStyle, index, (String) value);
    }
    return null;
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, Long value) {
    XSSFCell cell = row.createCell(startColIndex + index);
    try {
      cell.setCellValue(value);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
    } catch (Exception ex) {

    }

    return cell;
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, Double value) {
    XSSFCell cell = row.createCell(startColIndex + index);
    try {
      cell.setCellValue(value);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
    } catch (Exception ex) {

    }

    return cell;
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, Integer value) {
    XSSFCell cell = row.createCell(startColIndex + index);
    try {
      cell.setCellValue(value);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
    } catch (Exception ex) {

    }

    return cell;
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, Short value) {
    XSSFCell cell = row.createCell(startColIndex + index);
    try {
      cell.setCellValue(value);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
    } catch (Exception ex) {

    }

    return cell;
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, Byte value) {
    XSSFCell cell = row.createCell(startColIndex + index);
    try {
      cell.setCellValue(value);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
    } catch (Exception ex) {

    }

    return cell;
  }

  private XSSFCell createCell(XSSFRow row, XSSFCellStyle cellStyle, int index, Date date) {
    XSSFCell cell = row.createCell(startColIndex + index);
    try {
      cell.setCellValue(date);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

    } catch (Exception ex) {
      ex.printStackTrace();
    }

    return cell;
  }

  private XSSFCell createCellFromDateToString(XSSFRow row, XSSFCellStyle cellStyle, int index, Date date) {
    XSSFCell cell = row.createCell(startColIndex + index);
    try {
      Format formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm");
      String dateStr = formatter.format(date);

      cell.setCellValue(dateStr);
      cell.setCellStyle(cellStyle);
      cell.setCellType(XSSFCell.CELL_TYPE_STRING);

    } catch (Exception ex) {
      ex.printStackTrace();
    }

    return cell;
  }

  @Override
  public void createChart(Integer tracksCount) {
        /* At the end of this step, we have a worksheet with test data, that we want to write into a chart */
        /* Create a drawing canvas on the worksheet */
    XSSFDrawing xlsx_drawing = chartWorksheet.createDrawingPatriarch();

         /* Define anchor points in the worksheet to position the chart */
    int col2Size = DEFAULT_CHART_COLUMNS;
    if (tracksCount > DEFAULT_CHART_TRACKS_COUNT) {
      col2Size = (tracksCount / 500) * DEFAULT_CHART_COLUMNS;
    }

    XSSFClientAnchor anchor = xlsx_drawing.createAnchor(0, 0, 0, 0, 5, 2, col2Size, 30);

        /* Create the chart object based on the anchor point */
    XSSFChart my_line_chart = xlsx_drawing.createChart(anchor);

        /* Define legends for the line chart and set the position of the legend */
    XSSFChartLegend legend = my_line_chart.getOrCreateLegend();

    if (col2Size > 50) {
      legend.setPosition(LegendPosition.LEFT);
    } else {
      legend.setPosition(LegendPosition.TOP);
    }

         /* Create data for the chart */
    LineChartData data = my_line_chart.getChartDataFactory().createLineChartData();

        /* Define chart AXIS */
    ChartAxis bottomAxis = my_line_chart.getChartAxisFactory().createCategoryAxis(AxisPosition.BOTTOM);
    bottomAxis.setNumberFormat(BuiltinFormats.getBuiltinFormat(0x16));

    ValueAxis leftAxis = my_line_chart.getChartAxisFactory().createValueAxis(AxisPosition.LEFT);
    leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
    leftAxis.setMinimum(0);

    if (dbList != null) {
      ChartDataSource<Number> xs = DataSources.fromNumericCellRange(chartWorksheet, new CellRangeAddress
        (3, dbList.size() + 3, 0, 0));

      ChartDataSource<Number> ys1 = DataSources.fromNumericCellRange(chartWorksheet, new CellRangeAddress(
        3, dbList.size() + 3, 1, 1));

      ChartDataSource<Number> ys2 = DataSources.fromNumericCellRange(chartWorksheet, new CellRangeAddress(
        3, dbList.size() + 3, 2, 2));

      ChartDataSource<Number> ys3 = DataSources.fromNumericCellRange(chartWorksheet, new CellRangeAddress(
        3, dbList.size() + 3, 3, 3));

      ChartDataSource<Number> ys4 = DataSources.fromNumericCellRange(chartWorksheet, new CellRangeAddress(
        3, dbList.size() + 3, 4, 4));

            /* Add chart data sources as data to the chart */
      LineChartSeries speedChartSerie = data.addSeries(xs, ys1);
      LineChartSeries DUTChartSerie = data.addSeries(xs, ys2);
      LineChartSeries engineChartSerie = data.addSeries(xs, ys3);
      LineChartSeries externalPowerVoltageChartSerie = data.addSeries(xs, ys4);

      speedChartSerie.setTitle(translateText("tracks.seed") + " (" + translateText("unit.km.hr") + ")");
//            if (getBakSize() == null) {
      DUTChartSerie.setTitle(translateText("total.reeading") + " (" + translateText("unit.litr") + ")");
//            } else {
//                DUTChartSerie.setTitle(translateText("indication.dut") + " 1 " + "(" + translateText("unit.litr") + ")" + " / " +
//                        getBakSize() / 100);
//            }
      engineChartSerie.setTitle(translateText("ignition.sensor"));
      externalPowerVoltageChartSerie.setTitle(translateText("external.power") + " (B)");

            /* Plot the chart with the inputs from data and chart axis */
      my_line_chart.plot(data, bottomAxis, leftAxis);

      CTPlotArea plotArea = my_line_chart.getCTChart().getPlotArea();
      int i = 0;
      for (CTLineSer ser : plotArea.getLineChartArray()[0].getSerArray()) {
//                ser.setSmooth(ctBool);
//                ser.setMarker(ctMarker);

        // Add green color for DI series
        if (i == 2) {
          CTUnsignedInt ctInt = CTUnsignedInt.Factory.newInstance();
          ctInt.setVal(5);
          ser.setIdx(ctInt);
        }
        // Add red color for power voltage series
        if (i == 3) {
          CTUnsignedInt ctInt = CTUnsignedInt.Factory.newInstance();
          ctInt.setVal(3);
          ser.setIdx(ctInt);
        }
        i++;
      }

//            CTMarker ctMarker = CTMarker.Factory.newInstance();
//            ctMarker.setSymbol(CTMarkerStyle.Factory.newInstance());

//            CTBoolean ctBool = CTBoolean.Factory.newInstance();
//            ctBool.setVal(false);


    }

  }

  @Override
  public void setFileName(String fileName) {
    this.fileName = fileName;
    if (fileName == null) {
      this.fileName = "";
    }

    // Add current date/time
    String objectId = "";
    if (mobjectBig != null) {
      objectId = mobjectBig.getId() + "-";
    }

    this.fileName += "-" + objectId + new SimpleDateFormat("yyyyMMddHHmmss").format(startDate) + "-" + new SimpleDateFormat
      ("yyyyMMddHHmmss").format(endDate);
  }

}
