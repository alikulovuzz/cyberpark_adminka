package uzgps.excel.tripReports.objectMovement;

import uzgps.persistence.ReportObjectMovement;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ObjectMovementData {
    private List<ReportObjectMovement> reportObjectMovementList = new ArrayList<>();

    private Long tripId;
    private String tripName;
    private String mobjectName;
    private String customerCompanyName;
    private Integer tripType;
    private String userLogin;
    private Timestamp startDate;
    private Timestamp endDate;

    private Timestamp reportDay;

    private Timestamp reportStartPeriod;
    private Timestamp reportEndPeriod;

    public ObjectMovementData() {
//        this.tripId = tripId;
//        this.tripName = tripName;
//        this.tripType = tripType;
    }

    public List<ReportObjectMovement> getReportObjectMovementList() {
        return reportObjectMovementList;
    }

    public void setReportTripList(List<ReportObjectMovement> reportObjectMovementList) {
        this.reportObjectMovementList = reportObjectMovementList;
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getCustomerCompanyName() {
        return customerCompanyName;
    }

    public void setCustomerCompanyName(String customerCompanyName) {
        this.customerCompanyName = customerCompanyName;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {
        this.tripName = tripName;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public void setReportObjectMovementList(List<ReportObjectMovement> reportObjectMovementList) {
        this.reportObjectMovementList = reportObjectMovementList;
    }

    public Timestamp getReportStartPeriod() {
        return reportStartPeriod;
    }

    public void setReportStartPeriod(Timestamp reportStartPeriod) {
        this.reportStartPeriod = reportStartPeriod;
    }

    public Timestamp getReportEndPeriod() {
        return reportEndPeriod;
    }

    public void setReportEndPeriod(Timestamp reportEndPeriod) {
        this.reportEndPeriod = reportEndPeriod;
    }

    public Timestamp getReportDay() {
        return reportDay;
    }

    public void setReportDay(Timestamp reportDay) {
        this.reportDay = reportDay;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }
}
