package uzgps.excel.tripReports.objectMovement;

import org.apache.log4j.Logger;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import uzgps.common.excel.ExcelStyles;
import uzgps.excel.tripReports.AbstractTripItem;
import uzgps.persistence.ReportObjectMovement;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Service for processing Apache POI-based reports
 *
 * @author Saidolim
 * @since 04.04.2016 11:32
 */
@Component
public abstract class ExcelDownloaderObjectMovementDynamic<T extends AbstractTripItem> {
    protected static final Logger logger = Logger.getLogger(ExcelDownloaderObjectMovementDynamic.class.getName());

    protected MessageSource messageSource;

    private XSSFWorkbook workbook;
    private XSSFSheet worksheet;
    private List<CustomWorkSheetOM> worksheetList;
    protected Locale locale;
    private List<T> dbList;
    private String companyName;
    private String mobjectName;
    private Integer tripType;
    private String userLogin;
    private Timestamp startDate;
    private Timestamp endDate;
    protected ExcelStyles excelStyles;

    /* -------------- Settings -------------- >> */
    protected int startRowIndex = 0;
    protected int startColIndex = 0;
    short rowHeight = 500;
    protected String fileName = "";
    protected String title = "";
    protected String sheetName = "Worksheet 1";
    protected int fieldsCount = 5;
    protected Date reportDate;
    public Long token = 0L;

    /* -------------- Settings -------------- << */

    /**
     * Processes the download for Excel format.
     * It does the following steps:
     * <pre>
     * 1. Create new workbook
     * 2. Create new worksheet
     * 3. Define starting indices for rows and columns
     * 4. Build layout
     * 5. Fill report
     * 6. Set the HttpServletResponse properties
     * 7. Write to the output stream
     * </pre>
     */
    @SuppressWarnings("unchecked")
    public void downloadXLS(HttpServletResponse response) throws Exception {
        logger.debug("Downloading Excel report");

        // 1. Create new workbook
        workbook = new XSSFWorkbook();

        List<ObjectMovementData> objectMovementDataList = new ArrayList<>();

        worksheetList = new ArrayList<>();
        excelStyles = new ExcelStyles();

        List addedExitPlannedDays = new ArrayList<>();

        Timestamp currentStationExitPlannedDay;
        String currentStationExitPlannedDayFmt;

        SimpleDateFormat fmtSimple = new SimpleDateFormat("dd.MM.yyyy");
        SimpleDateFormat fmtSimpleShort = new SimpleDateFormat("ddMMyyyy");
//          fmt.format(date1).equals(fmt.format(date2));

        if (dbList != null) {
            for (T item : dbList) {
                currentStationExitPlannedDay = item.getStationExitPlanned();
                currentStationExitPlannedDayFmt = fmtSimple.format(currentStationExitPlannedDay);

                if (addedExitPlannedDays.contains(currentStationExitPlannedDayFmt)) {
                    for (ObjectMovementData objectMovementData : objectMovementDataList) {
                        if (Objects.equals(fmtSimple.format(objectMovementData.getReportDay()), currentStationExitPlannedDayFmt)) {
                            objectMovementData.getReportObjectMovementList().add((ReportObjectMovement) item);
                        }
                    }
                } else {
                    ObjectMovementData objectMovementData = new ObjectMovementData();

                    objectMovementData.setReportDay(item.getStationExitPlanned());

                    objectMovementData.setTripId(item.getTripId());
                    objectMovementData.setTripName(item.getTripName());
                    objectMovementData.setCustomerCompanyName(getCompanyName());
                    objectMovementData.setMobjectName(getMobjectName());
                    objectMovementData.setTripType(getTripType());
                    objectMovementData.setUserLogin(getUserLogin());
                    objectMovementData.setStartDate(getStartDate());
                    objectMovementData.setEndDate(getEndDate());

                    addedExitPlannedDays.add(fmtSimple.format(currentStationExitPlannedDay));

                    objectMovementData.getReportObjectMovementList().add((ReportObjectMovement) item);
                    objectMovementDataList.add(objectMovementData);
                }
            }
        }

        if (objectMovementDataList.size() > 0) {
            for (ObjectMovementData objectMovementData : objectMovementDataList) {

                List<Timestamp> timeStartPlannedList = new ArrayList();
                List<Timestamp> timeEndPlannedList = new ArrayList();

                for (ReportObjectMovement reportObjectMovement : objectMovementData.getReportObjectMovementList()) {
                    timeStartPlannedList.add(reportObjectMovement.getStationExitPlanned());
                    timeEndPlannedList.add(reportObjectMovement.getStationEnterPlanned());
                }

                timeStartPlannedList.sort(Comparator.naturalOrder());
                timeEndPlannedList.sort(Comparator.naturalOrder());

                objectMovementData.setReportStartPeriod(timeStartPlannedList.get(0));
                objectMovementData.setReportEndPeriod(timeEndPlannedList.get(timeEndPlannedList.size() - 1));

                // 2. Create new worksheet
                worksheet = workbook.createSheet(fmtSimpleShort.format(objectMovementData.getReportDay()));

                excelStyles.createStyles(worksheet);

                CustomWorkSheetOM customWorkSheet = new CustomWorkSheetOM(worksheet, objectMovementData, 0, 0);
                worksheetList.add(customWorkSheet);

                // 4. Build layout
                // Build column width, title, date, headers
                buildReport(customWorkSheet);

                // 5. Fill report from dbList
                try {
                    fillReport(customWorkSheet);
                } catch (Exception e) {
                    logger.error(getClass().getName() + "dynamic fillReport error " + ": " + e.toString());
                    if (workbook != null) {
                        workbook.close();
                    }
                    throw new Exception(getClass().getName() + " fillReport" + ": " + e.toString());
                }
                // 6. Build report footer
                buildFooter(worksheet);
            }
        } else {
            // 2. Create new worksheet
            worksheet = workbook.createSheet(fmtSimpleShort.format(new Timestamp(System.currentTimeMillis())));

            excelStyles.createStyles(worksheet);

            CustomWorkSheetOM customWorkSheet = new CustomWorkSheetOM(worksheet, null, 0, 0);
            worksheetList.add(customWorkSheet);

            // 4. Build layout
            // Build column width, title, date, headers
            buildReport(customWorkSheet);

            // 5. Fill report from dbList
            try {
                fillReport(customWorkSheet);
            } catch (Exception e) {
                logger.error(getClass().getName() + "dynamic fillReport error " + ": " + e.toString());
                if (workbook != null) {
                    workbook.close();
                }
                throw new Exception(getClass().getName() + " fillReport" + ": " + e.toString());
            }
            // 6. Build report footer
            buildFooter(worksheet);
        }

        // 7. Set the response properties
        try {
            response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8") + ".xlsx");
            response.setContentType("application/ms-excel; charset=UTF-8");
            response.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new UnsupportedEncodingException(getClass().getName() + " fillReport" + ": " + e.toString());
        }

        Long responseTokenValue = token * -1;
        Cookie qualityServicesDownloadToken = new Cookie("qualityServicesDownloadToken", responseTokenValue.toString());
        final int expiryTime = 60 * 60 * 24;  // 24h in seconds
        final String cookiePath = "/";
        qualityServicesDownloadToken.setMaxAge(expiryTime);  // A negative value means that the cookie is not stored persistently and will be deleted when the Web browser exits. A zero value causes the cookie to be deleted.
        qualityServicesDownloadToken.setPath(cookiePath);  // The cookie is visible to all the pages in the directory you specify, and all the pages in that directory's subdirectories
        response.addCookie(qualityServicesDownloadToken);

        // 8. Write to the output stream
       uzgps.common.excel.Writer.writeOM(response, worksheetList);
    }

    /* --------------------- Layout --------------------- >> */

    /**
     * Builds the report layout.
     */
    private void buildReport(CustomWorkSheetOM customWorkSheet) {
        // for language support
        locale = LocaleContextHolder.getLocale();

        // Build columns width
        buildColumnsWidth(customWorkSheet.getWorksheet());

        // Build the column headers
        buildHeaders(customWorkSheet);

        // Build the title and date headers
        buildTitle(customWorkSheet.getWorksheet());
    }

    /**
     * Builds the report layout.
     * <p/>
     * This doesn't have any data yet. This is your template.
     */
    public void buildColumnsWidth(XSSFSheet worksheet) {
        // Set column widths
        for (int k = 0; k < fieldsCount + 1; k++)
            worksheet.setColumnWidth(k, 5000);
    }

    /**
     * Builds the report title and the date header
     */
    public void buildTitle(XSSFSheet worksheet) {
        // Create report title
        XSSFRow rowTitle = worksheet.createRow(startRowIndex);
        rowTitle.setHeight(rowHeight);
        XSSFCell cellTitle = rowTitle.createCell(startColIndex);
        cellTitle.setCellValue(title);
        cellTitle.setCellStyle(excelStyles.cellStyleTitle);

        // Create merged region for the report title
//        worksheet.addMergedRegion(new CellRangeAddress(0, 0, 0, fieldsCount));
        worksheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 2));
    }

    /**
     * Builds the report footer
     */
    public void buildFooter(XSSFSheet worksheet) {

    }

    /**
     * Builds the column headers
     */
    public void buildHeaders(CustomWorkSheetOM customWorkSheet) {

    }
    /* --------------------- MAIN --------------------- >> */

    /**
     * Fills the report rows with content
     */
    public void fillReport(CustomWorkSheetOM customWorkSheet) throws Exception {
        // Create body
        int rowIndx = 3;

        if (customWorkSheet != null) {
            for (ReportObjectMovement ReportObjectMovement : customWorkSheet.getTripData().getReportObjectMovementList()) {
                // Create a new row
                XSSFRow row = worksheet.createRow(rowIndx);

                addRow(row, ReportObjectMovement);
                rowIndx++;
            }
        }
    }

    public void addRow(XSSFRow row, ReportObjectMovement ReportObjectMovement) {

    }

    /**
     * Return translated string
     *
     * @param langCode
     * @return
     */
    protected String translateText(String langCode) {
        try {
            return messageSource.getMessage(langCode, null, locale);
        } catch (Exception ex) {
            return langCode;
        }
    }

    /* --------------------- GETTER & SETTER --------------------- >> */
    public XSSFWorkbook getWorkbook() {
        return workbook;
    }

    public int getStartRowIndex() {
        return startRowIndex;
    }

    public void setStartRowIndex(int startRowIndex) {
        this.startRowIndex = startRowIndex;
    }

    public int getStartColIndex() {
        return startColIndex;
    }

    public void setStartColIndex(int startColIndex) {
        this.startColIndex = startColIndex;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
        if (fileName == null)
            this.fileName = "";

        // Add current date/time
        this.fileName += "-" + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public short getRowHeight() {
        return rowHeight;
    }

    public void setRowHeight(short rowHeight) {
        this.rowHeight = rowHeight;
    }

    public String getSheetName() {
        return sheetName;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public int getFieldsCount() {
        return fieldsCount;
    }

    public void setFieldsCount(int fieldsCount) {
        this.fieldsCount = fieldsCount;
    }

    public List<T> getDbList() {
        return dbList;
    }

    public void setDbList(List<T> dbList) {
        this.dbList = dbList;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }

    public void setToken(Long token) {
        this.token = token;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public static Logger getLogger() {
        return logger;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

/* --------------------- GETTER & SETTER --------------------- << */
}
