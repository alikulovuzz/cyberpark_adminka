package uzgps.excel.tripReports.tripSummary;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import uzgps.excel.ExcelDownloader;
import uzgps.persistence.ReportTripSummary;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Stanislav on 31.07.2019 11:54
 */
@Component
public class ExcelTripSummaryReport extends ExcelDownloader<ReportTripSummary> {
    private Integer routesTotal = 0;
    private Integer tripsTotal = 0;
    private Integer tripsFinishedTotal = 0;
    private Integer tripsActiveTotal = 0;
    private Integer tripsNotFinishedTotal = 0;
    private Integer mobjectsPlanTotal = 0;
    private Integer mobjectsFactTotal = 0;
    private Integer mobjectsDiffTotal = 0;

    private String customerCompanyName;
    private Integer tripType;
    private String userLogin;
    private Timestamp startDate;
    private Timestamp endDate;
//    private Timestamp reportStartPeriod;
//    private Timestamp reportEndPeriod;

    public ExcelTripSummaryReport() {
        setFileName("TripSummaryReport"); // File name
        sheetName = "Сводный отчет по рейсам";
        fieldsCount = 9;
    }

    public ExcelTripSummaryReport(MessageSource msgSource) {
        this();
        this.messageSource = msgSource;
    }

    /**
     * Builds the column headers
     */
    @Override
    public void buildHeaders() {
        // Create the column headers
        title = translateText("Сводный отчет по рейсам");

        // Create merged region for the report title
        worksheet.addMergedRegion(new CellRangeAddress(10, 11, 0, 0));

        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 10);
        rowHeader.setHeight((short) 550);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("Маршрут");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 1, 3));

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("Количество рейсов");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2_1 = rowHeader.createCell(startColIndex + 2);
        cell2_1.setCellValue("");
        cell2_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2_2 = rowHeader.createCell(startColIndex + 3);
        cell2_2.setCellValue("");
        cell2_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 4, 6));

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 4);
        cell3.setCellValue("Рейсы по статусам");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3_1 = rowHeader.createCell(startColIndex + 5);
        cell3_1.setCellValue("");
        cell3_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3_2 = rowHeader.createCell(startColIndex + 6);
        cell3_2.setCellValue("");
        cell3_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 7, 9));

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 7);
        cell4.setCellValue("Количество ТС");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4_1 = rowHeader.createCell(startColIndex + 8);
        cell4_1.setCellValue("");
        cell4_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4_2 = rowHeader.createCell(startColIndex + 9);
        cell4_2.setCellValue("");
        cell4_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        buildSecondHeaders(worksheet);
    }

    private void buildSecondHeaders(XSSFSheet worksheet) {
        // Create second column headers
        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 11);
        rowHeader.setHeight((short) 570);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("План");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("Факт");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("Отклонение");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("Завершен");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 5);
        cell6.setCellValue("Активный");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 6);
        cell7.setCellValue("Не завершенный");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 7);
        cell8.setCellValue("План");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 8);
        cell9.setCellValue("Факт");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10 = rowHeader.createCell(startColIndex + 9);
        cell10.setCellValue("Отклонение");
        cell10.setCellStyle(excelStyles.headerCellStyleBlue);
    }

    private void buildDetails() {
        worksheet.setColumnWidth(0, 12000);

        worksheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 2));
        worksheet.addMergedRegion(new CellRangeAddress(2, 2, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(3, 3, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(4, 4, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(5, 5, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(6, 6, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(7, 7, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(8, 8, 1, 2));
//        worksheet.addMergedRegion(new CellRangeAddress(9, 9, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(11, 11, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(12, 12, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(13, 13, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(14, 14, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(15, 15, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(16, 16, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(17, 17, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(19, 19, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(20, 20, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(21, 21, 1, 4));

        XSSFRow rowDetails1 = worksheet.createRow((short) startRowIndex + 1);
        rowDetails1.setHeight((short) 300);

        XSSFCell cell1 = rowDetails1.createCell(0);
        cell1.setCellValue("Сводные количественные показатели исполнения рейсов");
        cell1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails3 = worksheet.createRow((short) startRowIndex + 3);
        rowDetails3.setHeight((short) 300);

        XSSFCell cell2 = rowDetails3.createCell(0);
        cell2.setCellValue("Номер автопарка:");
        cell2.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell3 = rowDetails3.createCell(1);
        cell3.setCellValue(getCustomerCompanyName());
        cell3.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails4 = worksheet.createRow((short) startRowIndex + 4);
        rowDetails4.setHeight((short) 300);

        XSSFCell cell4 = rowDetails4.createCell(0);
        cell4.setCellValue("Начало рейса:");
        cell4.setCellStyle(excelStyles.bodyCellStyleLeft);

        String tripTypeStr = "";
        if (getTripType() == 1) {
            tripTypeStr = "График";
        } else if (getTripType() == 2) {
            tripTypeStr = "Произвольно";
        }
        XSSFCell cell4_1 = rowDetails4.createCell(1);
        cell4_1.setCellValue(tripTypeStr);
        cell4_1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails6 = worksheet.createRow((short) startRowIndex + 6);
        rowDetails6.setHeight((short) 300);

        XSSFCell cell6_1 = rowDetails6.createCell(0);
        cell6_1.setCellValue("Период отчета:");
        cell6_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell6_2 = rowDetails6.createCell(1);
        cell6_2.setCellValue(getStartDate());
        cell6_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell6_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell6_3 = rowDetails6.createCell(2);
        cell6_3.setCellValue(getEndDate());
        cell6_3.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell6_3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails8 = worksheet.createRow(startRowIndex + 7);

        XSSFCell rowDetails8_1 = rowDetails8.createCell(startColIndex);
        rowDetails8_1.setCellValue(translateText("Время генерации отчета:"));

        XSSFCell rowDetails8_2 = rowDetails8.createCell(startColIndex + 1);
        rowDetails8_2.setCellValue(new Timestamp(new Date().getTime()));
        rowDetails8_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        rowDetails8_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails9 = worksheet.createRow((short) startRowIndex + 8);
        rowDetails9.setHeight((short) 300);

        XSSFCell cell9_1 = rowDetails9.createCell(0);
        cell9_1.setCellValue("Отчет сгенерировал:");
        cell9_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell9_2 = rowDetails9.createCell(1);
        cell9_2.setCellValue(getUserLogin());
        cell9_2.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////
    }


    @Override
    public void addRow(XSSFRow row, ReportTripSummary item) {
        XSSFCell cell1 = row.createCell(startColIndex);
        cell1.setCellValue(item.getTripName());
        cell1.setCellStyle(excelStyles.bodyCellNotWrapStyle);
        cell1.setCellType(XSSFCell.CELL_TYPE_STRING);
        routesTotal += 1;
        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell2 = row.createCell(startColIndex + 1);
        cell2.setCellValue("");
        cell2.setCellStyle(excelStyles.bodyCellNotWrapStyle);
        cell2.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell3 = row.createCell(startColIndex + 2);
        cell3.setCellValue(item.getCountTrips());
        cell3.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        tripsTotal += item.getCountTrips();

        XSSFCell cell4 = row.createCell(startColIndex + 3);
        cell4.setCellValue("");
        cell4.setCellStyle(excelStyles.bodyCellNotWrapStyle);
        cell4.setCellType(XSSFCell.CELL_TYPE_STRING);
        ///////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell5 = row.createCell(startColIndex + 4);
        cell5.setCellValue(item.getTrip_100());
        cell5.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE_GREEN);
        cell5.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        tripsFinishedTotal += item.getTrip_100();

        XSSFCell cell6 = row.createCell(startColIndex + 5);
        cell6.setCellValue(item.getTrip_200());
        cell6.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE_BLUE);
        cell6.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        tripsActiveTotal += item.getTrip_200();

        XSSFCell cell7 = row.createCell(startColIndex + 6);
        cell7.setCellValue(item.getTrip_300());
        cell7.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE_RED);
        cell7.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        tripsNotFinishedTotal += item.getTrip_300();
        ///////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell8 = row.createCell(startColIndex + 7);
        cell8.setCellValue(item.getPlanCountMobjects());
        cell8.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell8.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        mobjectsPlanTotal += item.getPlanCountMobjects();

        XSSFCell cell9 = row.createCell(startColIndex + 8);
        cell9.setCellValue(item.getFactCountMobjects());
        cell9.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell9.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        mobjectsFactTotal += item.getFactCountMobjects();

        XSSFCell cell10 = row.createCell(startColIndex + 9);
        cell10.setCellValue(item.getDiffCountMobjects());
        cell10.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell10.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        mobjectsDiffTotal += item.getDiffCountMobjects();
        ///////////////////////////////////////////////////////////////////////////////////////////////
    }


    private void buildTotals(int totalIndex) {
        worksheet.addMergedRegion(new CellRangeAddress(totalIndex, totalIndex, 1, 9));

        // Create the column footer title
        XSSFRow rowFooterTitle = worksheet.createRow(totalIndex);
        rowFooterTitle.setHeight((short) 300);

        XSSFCell cellFooterTitle = rowFooterTitle.createCell(startColIndex);
        cellFooterTitle.setCellValue("Итого:");
        cellFooterTitle.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_1 = rowFooterTitle.createCell(startColIndex + 1);
        cellFooterTitle_1.setCellValue("");
        cellFooterTitle_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_2 = rowFooterTitle.createCell(startColIndex + 2);
        cellFooterTitle_2.setCellValue("");
        cellFooterTitle_2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_3 = rowFooterTitle.createCell(startColIndex + 3);
        cellFooterTitle_3.setCellValue("");
        cellFooterTitle_3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_4 = rowFooterTitle.createCell(startColIndex + 4);
        cellFooterTitle_4.setCellValue("");
        cellFooterTitle_4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_5 = rowFooterTitle.createCell(startColIndex + 5);
        cellFooterTitle_5.setCellValue("");
        cellFooterTitle_5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_6 = rowFooterTitle.createCell(startColIndex + 6);
        cellFooterTitle_6.setCellValue("");
        cellFooterTitle_6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_7 = rowFooterTitle.createCell(startColIndex + 7);
        cellFooterTitle_7.setCellValue("");
        cellFooterTitle_7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_8 = rowFooterTitle.createCell(startColIndex + 8);
        cellFooterTitle_8.setCellValue("");
        cellFooterTitle_8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cellFooterTitle_9 = rowFooterTitle.createCell(startColIndex + 9);
        cellFooterTitle_9.setCellValue("");
        cellFooterTitle_9.setCellStyle(excelStyles.headerCellStyleBlue);

        // Create the column footer totals
        XSSFRow rowTotals = worksheet.createRow(totalIndex + 1);
        rowTotals.setHeight((short) 300);

        XSSFCell cell1 = rowTotals.createCell(startColIndex);
        cell1.setCellValue(routesTotal);
        cell1.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE_RIGHT);
        cell1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell3 = rowTotals.createCell(startColIndex + 2);
        cell3.setCellValue(tripsTotal);
        cell3.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell5 = rowTotals.createCell(startColIndex + 4);
        cell5.setCellValue(tripsFinishedTotal);
        cell5.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE_GREEN);
        cell5.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell6 = rowTotals.createCell(startColIndex + 5);
        cell6.setCellValue(tripsActiveTotal);
        cell6.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE_BLUE);
        cell6.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell7 = rowTotals.createCell(startColIndex + 6);
        cell7.setCellValue(tripsNotFinishedTotal);
        cell7.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE_RED);
        cell7.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell8 = rowTotals.createCell(startColIndex + 7);
        cell8.setCellValue(mobjectsPlanTotal);
        cell8.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell8.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell9 = rowTotals.createCell(startColIndex + 8);
        cell9.setCellValue(mobjectsFactTotal);
        cell9.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell9.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell10 = rowTotals.createCell(startColIndex + 9);
        cell10.setCellValue(mobjectsDiffTotal);
        cell10.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell10.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Fills the report rows with content
     */
    @Override
    public void fillReport() {
        clearTotals();
        // Create body
        int rowIndx = 12;
        if (dbList != null) {
            for (ReportTripSummary item : dbList) {

                XSSFRow row = worksheet.createRow(rowIndx);

                addRow(row, item);
                rowIndx++;
            }
            buildDetails();
            buildTotals(rowIndx);
        }
    }

    private void clearTotals() {
        routesTotal = 0;
        tripsTotal = 0;
        tripsFinishedTotal = 0;
        tripsActiveTotal = 0;
        tripsNotFinishedTotal = 0;
        mobjectsPlanTotal = 0;
        mobjectsFactTotal = 0;
        mobjectsDiffTotal = 0;
    }

    public String getCustomerCompanyName() {
        return customerCompanyName;
    }

    public void setCustomerCompanyName(String customerCompanyName) {
        this.customerCompanyName = customerCompanyName;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

//    public Timestamp getReportStartPeriod() {
//        return reportStartPeriod;
//    }

//    public void setReportStartPeriod(Timestamp reportStartPeriod) {
//        this.reportStartPeriod = reportStartPeriod;
//    }
//
//    public Timestamp getReportEndPeriod() {
//        return reportEndPeriod;
//    }

//    public void setReportEndPeriod(Timestamp reportEndPeriod) {
//        this.reportEndPeriod = reportEndPeriod;
//    }
}
