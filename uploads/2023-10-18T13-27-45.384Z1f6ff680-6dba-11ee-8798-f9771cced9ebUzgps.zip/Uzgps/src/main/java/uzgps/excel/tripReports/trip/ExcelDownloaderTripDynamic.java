package uzgps.excel.tripReports.trip;

import org.apache.log4j.Logger;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import uzgps.common.excel.ExcelStyles;
import uzgps.common.excel.Writer;
import uzgps.excel.tripReports.AbstractTripItem;
import uzgps.persistence.ReportTrip;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Service for processing Apache POI-based reports
 *
 * @author Saidolim
 * @since 04.04.2016 11:32
 */
@Component
public abstract class ExcelDownloaderTripDynamic<T extends AbstractTripItem> {
    protected static final Logger logger = Logger.getLogger(ExcelDownloaderTripDynamic.class.getName());

    protected MessageSource messageSource;

    private XSSFWorkbook workbook;
    private XSSFSheet worksheet;
    private List<CustomWorkSheet> worksheetList;
    protected Locale locale;
    private List<T> dbList;
    //    private List<ReportTripHeaderData> reportTripHeaderDataList;
    private String companyName;
    private Integer tripType;
    private String userLogin;
    private Timestamp startDate;
    private Timestamp endDate;
    protected ExcelStyles excelStyles;

    /* -------------- Settings -------------- >> */
    protected int startRowIndex = 0;
    protected int startColIndex = 0;
    short rowHeight = 500;
    protected String fileName = "";
    protected String title = "";
    protected String sheetName = "Worksheet 1";
    protected int fieldsCount = 5;
    protected Date reportDate;
    public Long token = 0L;

    /* -------------- Settings -------------- << */

    /**
     * Processes the download for Excel format.
     * It does the following steps:
     * <pre>
     * 1. Create new workbook
     * 2. Create new worksheet
     * 3. Define starting indices for rows and columns
     * 4. Build layout
     * 5. Fill report
     * 6. Set the HttpServletResponse properties
     * 7. Write to the output stream
     * </pre>
     */
    @SuppressWarnings("unchecked")
    public void downloadXLS(HttpServletResponse response) throws Exception {
        logger.debug("Downloading Excel report");

        // 1. Create new workbook
        workbook = new XSSFWorkbook();

        long currentTripId;

        List<TripData> tripDataList = new ArrayList<>();

        List addedTripIds = new ArrayList<>();
        worksheetList = new ArrayList<>();

        excelStyles = new ExcelStyles();


        if (dbList != null) {
            for (T item : dbList) {
                currentTripId = item.getTripId();

                if (addedTripIds.contains(currentTripId)) {
                    for (TripData tripData : tripDataList) {
                        if (tripData.getTripId() == currentTripId) {

//                            for (ReportTripHeaderData reportTripHeaderData : reportTripHeaderDataList) {
//                                if (reportTripHeaderData.getRouteId() == currentTripId) {
//                                    tripData.setTripsCountByGraphic(reportTripHeaderData.getTripsCount());
//                                }
//                            }

                            tripData.getReportTripList().add((ReportTrip) item);
                        }
                    }
                } else {
                    TripData tripData = new TripData();

                    tripData.setTripId(currentTripId);
                    tripData.setTripName(item.getTripName());
                    tripData.setTripDirection(item.getTripDirection());
                    tripData.setTripDescription(item.getTripDescription());
                    tripData.setTripDistance(item.getTripDistance());
                    tripData.setTripTimePlanned(item.getTripTimePlanned());
                    tripData.setCustomerCompanyName(getCompanyName());
                    tripData.setTripType(getTripType());
                    tripData.setUserLogin(getUserLogin());
                    tripData.setStartDate(getStartDate());
                    tripData.setEndDate(getEndDate());

//                    for (ReportTripHeaderData reportTripHeaderData : reportTripHeaderDataList) {
//                        if (reportTripHeaderData.getRouteId() == currentTripId) {
//                            tripData.setTripsCountByGraphic(reportTripHeaderData.getTripsCount());
//                        }
//                    }

                    addedTripIds.add(currentTripId);

                    tripData.getReportTripList().add((ReportTrip) item);
                    tripDataList.add(tripData);
                }

            }
        }

        if (tripDataList.size() > 0) {
            for (TripData tripData : tripDataList) {
                List<Timestamp> timeStartPlannedList = new ArrayList();
                List<Timestamp> timeEndPlannedList = new ArrayList();

                for (ReportTrip reportTrip : tripData.getReportTripList()) {
                    timeStartPlannedList.add(reportTrip.getTimeStartPlanned());
                    timeEndPlannedList.add(reportTrip.getTimeEndPlanned());
                }

                timeStartPlannedList.sort(Comparator.naturalOrder());
                timeEndPlannedList.sort(Comparator.naturalOrder());

                tripData.setReportStartPeriod(timeStartPlannedList.get(0));
                tripData.setReportEndPeriod(timeEndPlannedList.get(timeEndPlannedList.size() - 1));

                // 2. Create new worksheet
                worksheet = workbook.createSheet(tripData.getTripName() + " " + tripData.getTripDirection());

                excelStyles.createStyles(worksheet);

                CustomWorkSheet customWorkSheet = new CustomWorkSheet(worksheet, tripData, 0, 0);
                worksheetList.add(customWorkSheet);

                // 4. Build layout
                // Build column width, title, date, headers
                buildReport(customWorkSheet);

                // 5. Fill report from dbList
                try {
                    fillReport(customWorkSheet);
                } catch (Exception e) {
                    logger.error(getClass().getName() + "dynamic fillReport error " + ": " + e.toString());
                    if (workbook != null) {
                        workbook.close();
                    }
                    throw new Exception(getClass().getName() + " fillReport" + ": " + e.toString());
                }

                // 6. Build report footer
                buildFooter(worksheet);
            }
        } else {
            // 2. Create new worksheet
            worksheet = workbook.createSheet("No data");

            excelStyles.createStyles(worksheet);

            CustomWorkSheet customWorkSheet = new CustomWorkSheet(worksheet, null, 0, 0);
            worksheetList.add(customWorkSheet);

            // 4. Build layout
            // Build column width, title, date, headers
            buildReport(customWorkSheet);

            // 5. Fill report from dbList
            try {
                fillReport(customWorkSheet);
            } catch (Exception e) {
                logger.error(getClass().getName() + "dynamic fillReport error " + ": " + e.toString());
                if (workbook != null) {
                    workbook.close();
                }
                throw new Exception(getClass().getName() + " fillReport" + ": " + e.toString());
            }

            // 6. Build report footer
            buildFooter(worksheet);
        }

        // 7. Set the response properties
        try {
            response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(fileName, "UTF-8") + ".xlsx");
            response.setContentType("application/ms-excel; charset=UTF-8");
            response.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            throw new UnsupportedEncodingException(getClass().getName() + " fillReport" + ": " + e.toString());
        }

        Long responseTokenValue = token * -1;
        Cookie qualityServicesDownloadToken = new Cookie("qualityServicesDownloadToken", responseTokenValue.toString());
        final int expiryTime = 60 * 60 * 24;  // 24h in seconds
        final String cookiePath = "/";
        qualityServicesDownloadToken.setMaxAge(expiryTime);  // A negative value means that the cookie is not stored persistently and will be deleted when the Web browser exits. A zero value causes the cookie to be deleted.
        qualityServicesDownloadToken.setPath(cookiePath);  // The cookie is visible to all the pages in the directory you specify, and all the pages in that directory's subdirectories
        response.addCookie(qualityServicesDownloadToken);

        // 8. Write to the output stream
        Writer.write(response, worksheetList);
    }

    /* --------------------- Layout --------------------- >> */

    /**
     * Builds the report layout.
     */
    private void buildReport(CustomWorkSheet customWorkSheet) {
        // for language support
        locale = LocaleContextHolder.getLocale();

        // Build columns width
        buildColumnsWidth(customWorkSheet.getWorksheet());

        // Build the column headers
        buildHeaders(customWorkSheet);

        // Build the title and date headers
        buildTitle(customWorkSheet.getWorksheet());
    }

    /**
     * Builds the report layout.
     * <p/>
     * This doesn't have any data yet. This is your template.
     */
    public void buildColumnsWidth(XSSFSheet worksheet) {
        // Set column widths
        for (int k = 0; k < fieldsCount + 1; k++)
            worksheet.setColumnWidth(k, 5000);
    }

    /**
     * Builds the report title and the date header
     */
    public void buildTitle(XSSFSheet worksheet) {
        // Create report title
        XSSFRow rowTitle = worksheet.createRow(startRowIndex);
        rowTitle.setHeight(rowHeight);
        XSSFCell cellTitle = rowTitle.createCell(startColIndex);
        cellTitle.setCellValue(title);
        cellTitle.setCellStyle(excelStyles.cellStyleTitle);

        // Create merged region for the report title
//        worksheet.addMergedRegion(new CellRangeAddress(0, 0, 0, fieldsCount));
        worksheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 2));

        // Create date header
        XSSFRow dateTitle = worksheet.createRow(startRowIndex + 13);
        XSSFCell cellDate = dateTitle.createCell(startColIndex);
        XSSFCell cellDate2 = dateTitle.createCell(startColIndex + 1);

        DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        df.format(new Date());

        cellDate.setCellValue(translateText("Время генерации отчета:"));
        cellDate2.setCellValue(new Timestamp(new Date().getTime()));
        cellDate2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cellDate2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
    }

    /**
     * Builds the report footer
     */
    public void buildFooter(XSSFSheet worksheet) {

    }

    /**
     * Builds the column headers
     */
    public void buildHeaders(CustomWorkSheet customWorkSheet) {

    }
    /* --------------------- MAIN --------------------- >> */

    /**
     * Fills the report rows with content
     */
    public void fillReport(CustomWorkSheet customWorkSheet) throws Exception {
        // Create body
        int rowIndx = 3;

        if (customWorkSheet != null) {
            for (ReportTrip reportTrip : customWorkSheet.getTripData().getReportTripList()) {
                // Create a new row
                XSSFRow row = worksheet.createRow(rowIndx);

                addRow(row, reportTrip);
                rowIndx++;
            }
        }
    }

    public void addRow(XSSFRow row, ReportTrip reportTrip) {

    }

    /**
     * Return translated string
     *
     * @param langCode
     * @return
     */
    protected String translateText(String langCode) {
        try {
            return messageSource.getMessage(langCode, null, locale);
        } catch (Exception ex) {
            return langCode;
        }
    }

    /* --------------------- GETTER & SETTER --------------------- >> */
    public XSSFWorkbook getWorkbook() {
        return workbook;
    }

    public int getStartRowIndex() {
        return startRowIndex;
    }

    public void setStartRowIndex(int startRowIndex) {
        this.startRowIndex = startRowIndex;
    }

    public int getStartColIndex() {
        return startColIndex;
    }

    public void setStartColIndex(int startColIndex) {
        this.startColIndex = startColIndex;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
        if (fileName == null)
            this.fileName = "";

        // Add current date/time
        this.fileName += "-" + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public short getRowHeight() {
        return rowHeight;
    }

    public void setRowHeight(short rowHeight) {
        this.rowHeight = rowHeight;
    }

    public String getSheetName() {
        return sheetName;
    }

    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    public int getFieldsCount() {
        return fieldsCount;
    }

    public void setFieldsCount(int fieldsCount) {
        this.fieldsCount = fieldsCount;
    }

    public List<T> getDbList() {
        return dbList;
    }

    public void setDbList(List<T> dbList) {
        this.dbList = dbList;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Date getReportDate() {
        return reportDate;
    }

    public void setReportDate(Date reportDate) {
        this.reportDate = reportDate;
    }

    public void setToken(Long token) {
        this.token = token;
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public static Logger getLogger() {
        return logger;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

//    public List<ReportTripHeaderData> getReportTripHeaderDataList() {
//        return reportTripHeaderDataList;
//    }
//
//    public void setReportTripHeaderDataList(List<ReportTripHeaderData> reportTripHeaderDataList) {
//        this.reportTripHeaderDataList = reportTripHeaderDataList;
//    }

    /* --------------------- GETTER & SETTER --------------------- << */
}
