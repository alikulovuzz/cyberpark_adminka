package uzgps.excel.tripReports.trip;

import uzgps.persistence.ReportTrip;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TripData {
    private List<ReportTrip> reportTripList = new ArrayList<>();

    private Long tripId;
    private String tripName;
    private String tripDirection;
    private String tripDescription;
    private Double tripDistance;
    private Timestamp tripTimePlanned;

    private String customerCompanyName;
    private Integer tripType;
    private String userLogin;

    private Timestamp reportDate;

    private Timestamp startDate;
    private Timestamp endDate;

    private Timestamp reportStartPeriod;
    private Timestamp reportEndPeriod;

    private Integer tripsCountByGraphic;

    public TripData() {
//        this.tripId = tripId;
//        this.tripName = tripName;
//        this.tripType = tripType;
    }

    public List<ReportTrip> getReportTripList() {
        return reportTripList;
    }

    public void setReportTripList(List<ReportTrip> reportTripList) {
        this.reportTripList = reportTripList;
    }

    public Long getTripId() {
        return tripId;
    }

    public void setTripId(Long tripId) {
        this.tripId = tripId;
    }

    public String getCustomerCompanyName() {
        return customerCompanyName;
    }

    public void setCustomerCompanyName(String customerCompanyName) {
        this.customerCompanyName = customerCompanyName;
    }

    public String getTripName() {
        return tripName;
    }

    public void setTripName(String tripName) {

        if (tripName.contains("*")) {
            tripName = tripName.replace("*", "");
        }

        this.tripName = tripName.trim();
    }

    public Integer getTripType() {
        return tripType;
    }

    public void setTripType(Integer tripType) {
        this.tripType = tripType;
    }

    public String getUserLogin() {
        return userLogin;
    }

    public void setUserLogin(String userLogin) {
        this.userLogin = userLogin;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public String getTripDirection() {
        return tripDirection;
    }

    public void setTripDirection(String tripDirection) {
        this.tripDirection = tripDirection;
    }

    public String getTripDescription() {
        return tripDescription;
    }

    public void setTripDescription(String tripDescription) {
        this.tripDescription = tripDescription;
    }

    public Double getTripDistance() {
        return tripDistance;
    }

    public void setTripDistance(Double tripDistance) {
        this.tripDistance = tripDistance;
    }

    public Timestamp getTripTimePlanned() {
        return tripTimePlanned;
    }

    public void setTripTimePlanned(Timestamp tripTimePlanned) {
        this.tripTimePlanned = tripTimePlanned;
    }

    public Timestamp getReportStartPeriod() {
        return reportStartPeriod;
    }

    public void setReportStartPeriod(Timestamp reportStartPeriod) {
        this.reportStartPeriod = reportStartPeriod;
    }

    public Timestamp getReportEndPeriod() {
        return reportEndPeriod;
    }

    public void setReportEndPeriod(Timestamp reportEndPeriod) {
        this.reportEndPeriod = reportEndPeriod;
    }

    public Timestamp getReportDate() {
        return reportDate;
    }

    public void setReportDate(Timestamp reportDate) {
        this.reportDate = reportDate;
    }


    public Integer getTripsCountByGraphic() {
        return tripsCountByGraphic;
    }

    public void setTripsCountByGraphic(Integer tripsCountByGraphic) {
        this.tripsCountByGraphic = tripsCountByGraphic;
    }
}
