package uzgps.excel.utils;


import org.apache.poi.ss.usermodel.ComparisonOperator;
import org.apache.poi.xssf.usermodel.XSSFConditionalFormattingRule;
import org.apache.poi.xssf.usermodel.XSSFSheetConditionalFormatting;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCfRule;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.STCfType;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.STConditionalFormattingOperator;

import java.lang.reflect.Field;

public class XSSFConditionalFormattingBeginsWith {

    public static XSSFConditionalFormattingRule createConditionalFormattingRuleBeginsWith(
            XSSFSheetConditionalFormatting sheetCF,
            String text) throws Exception {

        XSSFConditionalFormattingRule rule = sheetCF.createConditionalFormattingRule(
                ComparisonOperator.EQUAL /*only dummy*/,
                "" /*only dummy*/);

        Field _cfRule = XSSFConditionalFormattingRule.class.getDeclaredField("_cfRule");
        _cfRule.setAccessible(true);
        CTCfRule ctCfRule = (CTCfRule) _cfRule.get(rule);
        ctCfRule.setType(STCfType.BEGINS_WITH);
        ctCfRule.setOperator(STConditionalFormattingOperator.BEGINS_WITH);
        ctCfRule.setText(text);
        ctCfRule.addFormula("(LEFT(INDEX($1:$1048576, ROW(), COLUMN())," + text.length() + ")=\"" + text + "\")");
        _cfRule.set(rule, ctCfRule);

        return rule;
    }
}