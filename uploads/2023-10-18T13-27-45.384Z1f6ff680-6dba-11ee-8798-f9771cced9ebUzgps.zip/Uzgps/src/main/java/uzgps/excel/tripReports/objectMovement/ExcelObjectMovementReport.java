package uzgps.excel.tripReports.objectMovement;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import uzgps.persistence.ReportObjectMovement;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Stanislav on 26.06.2016 09:54
 */
@Component
public class ExcelObjectMovementReport extends ExcelDownloaderObjectMovementDynamic<ReportObjectMovement> {

    private Integer status100Total = 0;
    private Integer status200Total = 0;
    private Integer status300Total = 0;
    private Integer status400Total = 0;

    private List<Long> addedTripIdForStatuses = new ArrayList<>();

    public ExcelObjectMovementReport() {
        setFileName("ObjectMovementReport"); // File name
        sheetName = "";
        fieldsCount = 32;
    }

    public ExcelObjectMovementReport(MessageSource msgSource) {
        this();
        this.messageSource = msgSource;
    }

    /**
     * Builds the column headers
     */
    @Override
    public void buildHeaders(CustomWorkSheetOM customWorkSheet) {
        XSSFSheet worksheet = customWorkSheet.getWorksheet();

        // Create the column headers
        title = translateText("Отчет по движению объекта по маршрутам");

        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 18);
        rowHeader.setHeight((short) 550);

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 0, 0));
        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("Наименование маршрута");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);
        ///////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 1, 1));
        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("Направление маршрута");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 2, 2));
        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("Описание маршрута");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 3, 3));
        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("Порядковый номер КТ");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 4, 4));
        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("Контрольная точка");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 5, 5));
        XSSFCell cell6 = rowHeader.createCell(startColIndex + 5);
        cell6.setCellValue("Расстояние, км");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 6, 8));

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 6);
        cell7.setCellValue("Прибытие");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_1 = rowHeader.createCell(startColIndex + 7);
        cell7_1.setCellValue("");
        cell7_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_2 = rowHeader.createCell(startColIndex + 8);
        cell7_2.setCellValue("");
        cell7_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 9, 11));

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 9);
        cell8.setCellValue("Стоянка");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8_1 = rowHeader.createCell(startColIndex + 10);
        cell8_1.setCellValue("");
        cell8_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8_2 = rowHeader.createCell(startColIndex + 11);
        cell8_2.setCellValue("");
        cell8_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 12, 14));

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 12);
        cell9.setCellValue("Выезд");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9_1 = rowHeader.createCell(startColIndex + 13);
        cell9_1.setCellValue("");
        cell9_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9_2 = rowHeader.createCell(startColIndex + 14);
        cell9_2.setCellValue("");
        cell9_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 15, 17));

        XSSFCell cell10 = rowHeader.createCell(startColIndex + 15);
        cell10.setCellValue("Время в пути");
        cell10.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10_1 = rowHeader.createCell(startColIndex + 16);
        cell10_1.setCellValue("");
        cell10_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10_2 = rowHeader.createCell(startColIndex + 17);
        cell10_2.setCellValue("");
        cell10_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 18, 18));
        XSSFCell cell11 = rowHeader.createCell(startColIndex + 18);
        cell11.setCellValue("Допустимое отклонение");
        cell11.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 19, 19, 19));
        XSSFCell cell12 = rowHeader.createCell(startColIndex + 19);
        cell12.setCellValue("Пробег, км");
        cell12.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 20, 29));

        XSSFCell cell13 = rowHeader.createCell(startColIndex + 20);
        cell13.setCellValue("Нарушения");
        cell13.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_1 = rowHeader.createCell(startColIndex + 21);
        cell13_1.setCellValue("");
        cell13_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_2 = rowHeader.createCell(startColIndex + 22);
        cell13_2.setCellValue("");
        cell13_2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_3 = rowHeader.createCell(startColIndex + 23);
        cell13_3.setCellValue("");
        cell13_3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_4 = rowHeader.createCell(startColIndex + 24);
        cell13_4.setCellValue("");
        cell13_4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_5 = rowHeader.createCell(startColIndex + 25);
        cell13_5.setCellValue("");
        cell13_5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_6 = rowHeader.createCell(startColIndex + 26);
        cell13_6.setCellValue("");
        cell13_6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_13 = rowHeader.createCell(startColIndex + 27);
        cell13_13.setCellValue("");
        cell13_13.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_8 = rowHeader.createCell(startColIndex + 28);
        cell13_8.setCellValue("");
        cell13_8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13_9 = rowHeader.createCell(startColIndex + 29);
        cell13_9.setCellValue("");
        cell13_9.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 30, 31));

        XSSFCell cell14 = rowHeader.createCell(startColIndex + 30);
        cell14.setCellValue("Превышение скорости");
        cell14.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell14_1 = rowHeader.createCell(startColIndex + 31);
        cell14_1.setCellValue("");
        cell14_1.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        buildSecondHeaders(worksheet);
    }

    private void buildSecondHeaders(XSSFSheet worksheet) {
        // Create second column headers
        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 19);
        rowHeader.setHeight((short) 570);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 5);
        cell6.setCellValue("");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 6);
        cell7.setCellValue("Расписание");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_1 = rowHeader.createCell(startColIndex + 7);
        cell7_1.setCellValue("Факт");
        cell7_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_2 = rowHeader.createCell(startColIndex + 8);
        cell7_2.setCellValue("Отклонение");
        cell7_2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_3 = rowHeader.createCell(startColIndex + 9);
        cell7_3.setCellValue("Расписание");
        cell7_3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 10);
        cell8.setCellValue("Факт");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 11);
        cell9.setCellValue("Отклонение");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10 = rowHeader.createCell(startColIndex + 12);
        cell10.setCellValue("Расписание");
        cell10.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell11 = rowHeader.createCell(startColIndex + 13);
        cell11.setCellValue("Факт");
        cell11.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12 = rowHeader.createCell(startColIndex + 14);
        cell12.setCellValue("Отклонение");
        cell12.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12_d1 = rowHeader.createCell(startColIndex + 15);
        cell12_d1.setCellValue("Расписание");
        cell12_d1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12_d2 = rowHeader.createCell(startColIndex + 16);
        cell12_d2.setCellValue("Факт");
        cell12_d2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12_d3 = rowHeader.createCell(startColIndex + 17);
        cell12_d3.setCellValue("Отклонение");
        cell12_d3.setCellStyle(excelStyles.headerCellStyleBlue);


        XSSFCell cell13 = rowHeader.createCell(startColIndex + 18);
        cell13.setCellValue("");
        cell13.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell14 = rowHeader.createCell(startColIndex + 19);
        cell14.setCellValue("");
        cell14.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell15 = rowHeader.createCell(startColIndex + 20);
        cell15.setCellValue("Съезд с маршрута");
        cell15.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell16 = rowHeader.createCell(startColIndex + 21);
        cell16.setCellValue("Возврат на маршрут");
        cell16.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell17 = rowHeader.createCell(startColIndex + 22);
        cell17.setCellValue("Ранний заезд в КТ");
        cell17.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell18 = rowHeader.createCell(startColIndex + 23);
        cell18.setCellValue("Поздний заезд в КТ");
        cell18.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell19 = rowHeader.createCell(startColIndex + 24);
        cell19.setCellValue("Ранний выезд из КТ");
        cell19.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell21 = rowHeader.createCell(startColIndex + 25);
        cell21.setCellValue("Поздний выезд из КТ");
        cell21.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell22 = rowHeader.createCell(startColIndex + 26);
        cell22.setCellValue("Пропуск КТ");
        cell22.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell23 = rowHeader.createCell(startColIndex + 27);
        cell23.setCellValue("Превышено время нахождения в КТ");
        cell23.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell24 = rowHeader.createCell(startColIndex + 28);
        cell24.setCellValue("Остановка более лимита вне КТ");
        cell24.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell25 = rowHeader.createCell(startColIndex + 29);
        cell25.setCellValue("Остановился в КТ");
        cell25.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell26 = rowHeader.createCell(startColIndex + 30);
        cell26.setCellValue("Количество");
        cell26.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell27 = rowHeader.createCell(startColIndex + 31);
        cell27.setCellValue("Максимальная скорость, км/ч");
        cell27.setCellStyle(excelStyles.headerCellStyleBlue);

    }

    private void buildDetails(XSSFSheet worksheet, ObjectMovementData objectMovementData) {
        worksheet.setColumnWidth(0, 12000);

        worksheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 3));
        worksheet.addMergedRegion(new CellRangeAddress(3, 3, 1, 2));
        worksheet.addMergedRegion(new CellRangeAddress(11, 11, 1, 4));

        XSSFRow rowDetails1 = worksheet.createRow((short) startRowIndex + 1);
        rowDetails1.setHeight((short) 300);

        XSSFCell cell1 = rowDetails1.createCell(0);
        cell1.setCellValue("Детальная информация о движении объекта по маршрутам за выбранный интервал времени");
        cell1.setCellStyle(excelStyles.bodyCellStyleLeft);

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails2 = worksheet.createRow((short) startRowIndex + 3);
        rowDetails2.setHeight((short) 300);

        XSSFCell cell2 = rowDetails2.createCell(0);
        cell2.setCellValue("Номер автопарка:");
        cell2.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell2_1 = rowDetails2.createCell(1);
        cell2_1.setCellValue(objectMovementData.getCustomerCompanyName());
        cell2_1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails3 = worksheet.createRow((short) startRowIndex + 4);
        rowDetails3.setHeight((short) 300);

        XSSFCell cell3 = rowDetails3.createCell(0);
        cell3.setCellValue("Наименование объекта:");
        cell3.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell3_1 = rowDetails3.createCell(1);
        cell3_1.setCellValue(objectMovementData.getMobjectName());
        cell3_1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails10 = worksheet.createRow((short) startRowIndex + 5);
        rowDetails10.setHeight((short) 300);

        XSSFCell cell10_1 = rowDetails10.createCell(0);
        cell10_1.setCellValue("Начало рейса:");
        cell10_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        String tripTypeStr = "";
        if (objectMovementData.getTripType() == 1) {
            tripTypeStr = "График";
        } else if (objectMovementData.getTripType() == 2) {
            tripTypeStr = "Произвольно";
        }

        XSSFCell cell10_2_ = rowDetails10.createCell(1);
        cell10_2_.setCellValue(tripTypeStr);
        cell10_2_.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails12 = worksheet.createRow((short) startRowIndex + 6);
        rowDetails12.setHeight((short) 300);

        XSSFCell cell12_1 = rowDetails12.createCell(0);
        cell12_1.setCellValue("Период отчета:");
        cell12_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell12_2_ = rowDetails12.createCell(1);
        cell12_2_.setCellValue(objectMovementData.getStartDate());
        cell12_2_.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell12_2_.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell12_3_ = rowDetails12.createCell(2);
        cell12_3_.setCellValue(objectMovementData.getEndDate());
        cell12_3_.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell12_3_.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails13 = worksheet.createRow((short) startRowIndex + 7);
        rowDetails13.setHeight((short) 300);

        XSSFCell cell13_1 = rowDetails13.createCell(0);
        cell13_1.setCellValue("Период выборки данных:");
        cell13_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell13_2 = rowDetails13.createCell(1);
        cell13_2.setCellValue(objectMovementData.getReportStartPeriod());
        cell13_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell13_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell13_3 = rowDetails13.createCell(2);
        cell13_3.setCellValue(objectMovementData.getReportEndPeriod());
        cell13_3.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell13_3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails14 = worksheet.createRow(startRowIndex + 8);

        XSSFCell rowDetails14_1 = rowDetails14.createCell(startColIndex);
        rowDetails14_1.setCellValue(translateText("Время генерации отчета:"));

        XSSFCell rowDetails14_2 = rowDetails14.createCell(startColIndex + 1);
        rowDetails14_2.setCellValue(new Timestamp(new Date().getTime()));
        rowDetails14_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        rowDetails14_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails15 = worksheet.createRow((short) startRowIndex + 9);
        rowDetails15.setHeight((short) 300);

        XSSFCell cell15_1 = rowDetails15.createCell(0);
        cell15_1.setCellValue("Отчет сгенерировал:");
        cell15_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell15_2 = rowDetails15.createCell(1);
        cell15_2.setCellValue(objectMovementData.getUserLogin());
        cell15_2.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails17 = worksheet.createRow((short) startRowIndex + 11);
        rowDetails17.setHeight((short) 300);

        XSSFCell cell17_1 = rowDetails17.createCell(0);
        cell17_1.setCellValue("Количество рейсов по Графику:");
        cell17_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell17_2 = rowDetails17.createCell(1);
        cell17_2.setCellValue("Суммарное количество рейсов по данному маршруту за выбранный интервал времени");
        cell17_2.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails18 = worksheet.createRow((short) startRowIndex + 12);
        rowDetails18.setHeight((short) 300);

        XSSFCell cell18_1 = rowDetails18.createCell(0);
        cell18_1.setCellValue("Количество рейсов по статусам:");
        cell18_1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails19 = worksheet.createRow((short) startRowIndex + 13);
        rowDetails19.setHeight((short) 300);

        XSSFCell cell19_1 = rowDetails19.createCell(0);
        cell19_1.setCellValue("завершен:");
        cell19_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell19_2 = rowDetails19.createCell(1);
        cell19_2.setCellValue(status100Total);
        cell19_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell19_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails20 = worksheet.createRow((short) startRowIndex + 14);
        rowDetails20.setHeight((short) 300);

        XSSFCell cell20_1 = rowDetails20.createCell(0);
        cell20_1.setCellValue("не начат:");
        cell20_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell20_2 = rowDetails20.createCell(1);
        cell20_2.setCellValue(status400Total);
        cell20_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell20_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails21 = worksheet.createRow((short) startRowIndex + 15);
        rowDetails21.setHeight((short) 300);

        XSSFCell cell21_1 = rowDetails21.createCell(0);
        cell21_1.setCellValue("активный:");
        cell21_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell21_2 = rowDetails21.createCell(1);
        cell21_2.setCellValue(status200Total);
        cell21_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell21_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails22 = worksheet.createRow((short) startRowIndex + 16);
        rowDetails22.setHeight((short) 300);

        XSSFCell cell22_1 = rowDetails22.createCell(0);
        cell22_1.setCellValue("не завершен:");
        cell22_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell22_2 = rowDetails22.createCell(1);
        cell22_2.setCellValue(status300Total);
        cell22_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell22_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////
    }

    @Override
    public void addRow(XSSFRow row, ReportObjectMovement item) {

        if (!addedTripIdForStatuses.contains(item.getTripId())) {
            addedTripIdForStatuses.add(item.getTripId());
            if (item.getTripStatus() == 100) {
                status100Total += 1;
            } else if (item.getTripStatus() == 200) {
                status200Total += 1;
            } else if (item.getTripStatus() == 300) {
                status300Total += 1;
            } else if (item.getTripStatus() == 400) {
                status400Total += 1;
            }
        }

        XSSFCell cell1 = row.createCell(startColIndex);

        if (item.getTripName() != null) {
            cell1.setCellValue(item.getTripName());
        } else {
            cell1.setCellValue("");
        }
        cell1.setCellStyle(excelStyles.bodyCellNotWrapStyle);
        cell1.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell2 = row.createCell(startColIndex + 1);
        if (item.getTripDirection() != null) {
            cell2.setCellValue(item.getTripDirection());
        } else {
            cell2.setCellValue("");
        }

        cell2.setCellStyle(excelStyles.bodyCellStyle);
        cell2.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell3 = row.createCell(startColIndex + 2);
        if (item.getTripDescription() != null) {
            cell3.setCellValue(item.getTripDescription());
        } else {
            cell3.setCellValue("");
        }
        cell3.setCellStyle(excelStyles.bodyCellStyle);
        cell3.setCellType(XSSFCell.CELL_TYPE_STRING);


        XSSFCell cell4 = row.createCell(startColIndex + 3);
        if (item.getStationPriority() != null) {
            cell4.setCellValue(item.getStationPriority());
        } else {
            cell4.setCellValue("");
        }

        cell4.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell4.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell5 = row.createCell(startColIndex + 4);
        if (item.getStationName() != null) {
            cell5.setCellValue(item.getStationName());
        } else {
            cell5.setCellValue("");
        }

        cell5.setCellStyle(excelStyles.bodyCellStyle);
        cell5.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell6 = row.createCell(startColIndex + 5);
        if (item.getStationDistance() != null) {
            cell6.setCellValue(item.getStationDistance());
        } else {
            cell6.setCellValue("");
        }
        cell6.setCellStyle(excelStyles.bodyCellStyleNumeric);
        cell6.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell7 = row.createCell(startColIndex + 6);
        if (item.getStationEnterPlanned() != null) {
            cell7.setCellValue(item.getStationEnterPlanned());
        } else {
            cell7.setCellValue("");
        }
        cell7.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell7.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell8 = row.createCell(startColIndex + 7);
        if (item.getStationEnterReal() != null) {
            cell8.setCellValue(item.getStationEnterReal());
            cell8.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
            cell8.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell8.setCellValue("");
            cell8.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell8.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell9 = row.createCell(startColIndex + 8);
        if (item.getStationEnterDeviation() != null) {
            cell9.setCellValue(item.getStationEnterDeviation());
            cell9.setCellStyle(excelStyles.TIME_STYLE);
            cell9.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell9.setCellValue("");
            cell9.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell9.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell10 = row.createCell(startColIndex + 9);
        if (item.getStationParkingPlanned() != null) {
            cell10.setCellValue(item.getStationParkingPlanned());
            cell10.setCellStyle(excelStyles.TIME_STYLE);
            cell10.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell10.setCellValue("");
            cell10.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell10.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell11 = row.createCell(startColIndex + 10);
        if (item.getStationParkingReal() != null) {
            cell11.setCellValue(item.getStationParkingReal());
            cell11.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
            cell11.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell11.setCellValue("");
            cell11.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell11.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell14 = row.createCell(startColIndex + 11);
        if (item.getStationParkingDeviation() != null) {
            cell14.setCellValue(item.getStationParkingDeviation());
            cell14.setCellStyle(excelStyles.TIME_STYLE);
            cell14.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell14.setCellValue("");
            cell14.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell14.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell15 = row.createCell(startColIndex + 12);
        if (item.getStationExitPlanned() != null) {
            cell15.setCellValue(item.getStationExitPlanned());
        } else {
            cell15.setCellValue("");
        }
        cell15.setCellStyle(excelStyles.DATE_TIME_STYLE);
        cell15.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell16 = row.createCell(startColIndex + 13);
        if (item.getStationExitReal() != null) {
            cell16.setCellValue(item.getStationExitReal());
            cell16.setCellStyle(excelStyles.DATE_TIME_STYLE);
            cell16.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell16.setCellValue("");
            cell16.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell16.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell17 = row.createCell(startColIndex + 14);
        if (item.getStationExitDeviation() != null) {
            cell17.setCellValue(item.getStationExitDeviation());
            cell17.setCellStyle(excelStyles.TIME_STYLE);
            cell17.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell17.setCellValue("");
            cell17.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell17.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell16_1 = row.createCell(startColIndex + 15);
        if (item.getStationTravelPlanned() != null) {
            cell16_1.setCellValue(item.getStationTravelPlanned());
            cell16_1.setCellStyle(excelStyles.TIME_STYLE);
            cell16_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell16_1.setCellValue("");
            cell16_1.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell16_1.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell17_1 = row.createCell(startColIndex + 16);
        if (item.getStationTravelReal() != null) {
            cell17_1.setCellValue(item.getStationTravelReal());
            cell17_1.setCellStyle(excelStyles.TIME_STYLE);
            cell17_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell17_1.setCellValue("");
            cell17_1.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell17_1.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell17_2 = row.createCell(startColIndex + 17);
        if (item.getStationTravelDeviation() != null) {
            cell17_2.setCellValue(item.getStationTravelDeviation());
            cell17_2.setCellStyle(excelStyles.TIME_STYLE);
            cell17_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell17_2.setCellValue("");
            cell17_2.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell17_2.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell1_t_1 = row.createCell(startColIndex + 18);
        cell1_t_1.setCellValue(item.getStationDeviationNorm());
        cell1_t_1.setCellStyle(excelStyles.TIME_STYLE);
        cell1_t_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell1_t_2 = row.createCell(startColIndex + 19);
        cell1_t_2.setCellValue(item.getStationTripDistance());
        cell1_t_2.setCellStyle(excelStyles.bodyCellStyleNumeric);
        cell1_t_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);


        XSSFCell cell1_t_3 = row.createCell(startColIndex + 20);
        if (item.getEventRouteExitCount() != null) {
            cell1_t_3.setCellValue(item.getEventRouteExitCount());
        } else {
            cell1_t_3.setCellValue("");
        }
        cell1_t_3.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell1_t_3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell1_t_4 = row.createCell(startColIndex + 21);
        if (item.getEventRouteReturnCount() != null) {
            cell1_t_4.setCellValue(item.getEventRouteReturnCount());
        } else {
            cell1_t_4.setCellValue("");
        }
        cell1_t_4.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell1_t_4.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell1_t_5 = row.createCell(startColIndex + 22);
        if (item.getEventStationEnterEarly() != null) {
            cell1_t_5.setCellValue(item.getEventStationEnterEarly());
            cell1_t_5.setCellStyle(excelStyles.TIME_STYLE);
            cell1_t_5.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell1_t_5.setCellValue("");
            cell1_t_5.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell1_t_5.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell1_t_6 = row.createCell(startColIndex + 23);
        if (item.getEventStationEnterLate() != null) {
            cell1_t_6.setCellValue(item.getEventStationEnterLate());
            cell1_t_6.setCellStyle(excelStyles.TIME_STYLE);
            cell1_t_6.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell1_t_6.setCellValue("");
            cell1_t_6.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell1_t_6.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell1_t_7 = row.createCell(startColIndex + 24);
        if (item.getEventStationExitEarly() != null) {
            cell1_t_7.setCellValue(item.getEventStationExitEarly());
            cell1_t_7.setCellStyle(excelStyles.TIME_STYLE);
            cell1_t_7.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell1_t_7.setCellValue("");
            cell1_t_7.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell1_t_7.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell1_t_7_1 = row.createCell(startColIndex + 25);
        if (item.getEventStationExitLate() != null) {
            cell1_t_7_1.setCellValue(item.getEventStationExitLate());
            cell1_t_7_1.setCellStyle(excelStyles.TIME_STYLE);
            cell1_t_7_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell1_t_7_1.setCellValue("");
            cell1_t_7_1.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell1_t_7_1.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        String stationSkippedString;
        if (item.getEventStationSkipped() != null && item.getEventStationSkipped()) {
            stationSkippedString = "Да";
        } else {
            stationSkippedString = "";
        }
        XSSFCell cell18 = row.createCell(startColIndex + 26);
        cell18.setCellValue(stationSkippedString);
        cell18.setCellStyle(excelStyles.bodyCellStyle);
        cell18.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell19 = row.createCell(startColIndex + 27);
        int eventInStationParkingMore = 0;
        if (item.getEventInStationParkingMore() != null) {
            eventInStationParkingMore = item.getEventInStationParkingMore().intValue();
        }
        cell19.setCellValue(eventInStationParkingMore);
        cell19.setCellStyle(excelStyles.TIME_STYLE);
        cell19.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell20 = row.createCell(startColIndex + 28);
        if (item.getEventOutStationParkingMore() != null) {
            cell20.setCellValue(item.getEventOutStationParkingMore());
            cell20.setCellStyle(excelStyles.TIME_STYLE);
            cell20.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell20.setCellValue("");
            cell20.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell20.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        String stationStopped;
        if (item.getEventStationSkipped() != null && item.getEventStationSkipped()) {
            stationStopped = "Да";
        } else {
            stationStopped = "Нет";
        }
        XSSFCell cell21 = row.createCell(startColIndex + 29);
        cell21.setCellValue(stationStopped);
        cell21.setCellStyle(excelStyles.bodyCellStyle);
        cell21.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell22 = row.createCell(startColIndex + 30);
        int eventOverspeedCount = 0;
        if (item.getEventOverspeedCount() != null) {
            eventOverspeedCount = item.getEventOverspeedCount();
        }
        cell22.setCellValue(eventOverspeedCount);
        cell22.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell22.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell23 = row.createCell(startColIndex + 31);
        int eventOverspeedMaxSpeed = 0;
        if (item.getEventOverspeedMaxSpeed() != null) {
            eventOverspeedMaxSpeed = item.getEventOverspeedMaxSpeed();
        }
        cell23.setCellValue(eventOverspeedMaxSpeed);
        cell23.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell23.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

    }

    private void setConditionalFormatting(XSSFSheet worksheet, int maxRow) throws Exception {
//        XSSFSheetConditionalFormatting sheetCF = worksheet.getSheetConditionalFormatting();
//
//        CellRangeAddress[] regions1 = {CellRangeAddress.valueOf("H25:H" + maxRow)};
//
//        XSSFConditionalFormattingRule ruleGreen = createConditionalFormattingRuleBeginsWith(sheetCF, "Завершен");
//        XSSFConditionalFormattingRule ruleYellow = createConditionalFormattingRuleBeginsWith(sheetCF, "Активный");
//        XSSFConditionalFormattingRule ruleRed = createConditionalFormattingRuleBeginsWith(sheetCF, "Не завершен");
//        XSSFConditionalFormattingRule ruleBlue = createConditionalFormattingRuleBeginsWith(sheetCF, "Не начат");
//
////        ConditionalFormattingRule ruleYellow = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Активный");
////        ConditionalFormattingRule ruleRed = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Не завершен");
////        ConditionalFormattingRule ruleBlue = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Не начат");
//
//        PatternFormatting patternFmtGreen = ruleGreen.createPatternFormatting();
//        patternFmtGreen.setFillBackgroundColor(IndexedColors.LIGHT_GREEN.index);
//
//        PatternFormatting patternFmtYellow = ruleYellow.createPatternFormatting();
//        patternFmtYellow.setFillBackgroundColor(IndexedColors.YELLOW.index);
//
//        PatternFormatting patternFmtRed = ruleRed.createPatternFormatting();
//        patternFmtRed.setFillBackgroundColor(IndexedColors.RED.index);
////
//        PatternFormatting patternFmtBlue = ruleBlue.createPatternFormatting();
//        patternFmtBlue.setFillBackgroundColor(IndexedColors.LIGHT_BLUE.index);
//
//        XSSFConditionalFormattingRule[] cfRules = new XSSFConditionalFormattingRule[]{ruleGreen, ruleYellow, ruleRed};
//
//        sheetCF.addConditionalFormatting(regions1, cfRules);
//        sheetCF.addConditionalFormatting(regions1, ruleBlue);
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Fills the report rows with content
     */
    @Override
    public void fillReport(CustomWorkSheetOM customWorkSheet) throws Exception {
        int rowIndx = 20;
        status100Total = 0;
        status200Total = 0;
        status300Total = 0;
        status400Total = 0;

        if (customWorkSheet != null && customWorkSheet.getTripData() != null && customWorkSheet.getTripData().getReportObjectMovementList().size() > 0) {
            XSSFRow row;

            for (ReportObjectMovement ReportObjectMovement : customWorkSheet.getTripData().getReportObjectMovementList()) {
                // Create a new row
                row = customWorkSheet.getWorksheet().createRow(rowIndx);

                addRow(row, ReportObjectMovement);
                rowIndx++;
            }

            // Build report details
            buildDetails(customWorkSheet.getWorksheet(), customWorkSheet.getTripData());
            setConditionalFormatting(customWorkSheet.getWorksheet(), rowIndx);
        }
    }
}
