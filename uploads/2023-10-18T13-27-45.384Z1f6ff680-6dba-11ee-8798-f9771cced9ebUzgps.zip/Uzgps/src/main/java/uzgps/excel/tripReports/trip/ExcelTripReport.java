package uzgps.excel.tripReports.trip;

import com.microsoft.schemas.office.visio.x2012.main.CellType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.PatternFormatting;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import uzgps.persistence.ReportTrip;

import static uzgps.excel.utils.XSSFConditionalFormattingBeginsWith.createConditionalFormattingRuleBeginsWith;

/**
 * Created by Stanislav on 26.06.2016 09:54
 */
@Component
public class ExcelTripReport extends ExcelDownloaderTripDynamic<ReportTrip> {

    private Integer status100Total = 0;
    private Integer status200Total = 0;
    private Integer status300Total = 0;
    private Integer status400Total = 0;


    public ExcelTripReport() {
        setFileName("TripReport"); // File name
        sheetName = "Отчет по рейсам";
        fieldsCount = 22;
    }

    public ExcelTripReport(MessageSource msgSource) {
        this();
        this.messageSource = msgSource;
    }

    /**
     * Builds the column headers
     */
    @Override
    public void buildHeaders(CustomWorkSheet customWorkSheet) {
        XSSFSheet worksheet = customWorkSheet.getWorksheet();

        // Create the column headers
        title = translateText("Отчет по рейсам");

        // Create merged region for the report title
        worksheet.addMergedRegion(new CellRangeAddress(23, 24, 0, 0));

        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 23);
        rowHeader.setHeight((short) 550);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("Объект");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(23, 23, 1, 3));

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("Начало рейса");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2_1 = rowHeader.createCell(startColIndex + 2);
        cell2_1.setCellValue("");
        cell2_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2_2 = rowHeader.createCell(startColIndex + 3);
        cell2_2.setCellValue("");
        cell2_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(23, 23, 4, 6));

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 4);
        cell3.setCellValue("Завершение рейса");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3_1 = rowHeader.createCell(startColIndex + 5);
        cell3_1.setCellValue("");
        cell3_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3_2 = rowHeader.createCell(startColIndex + 6);
        cell3_2.setCellValue("");
        cell3_2.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(23, 24, 7, 7));

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 7);
        cell4.setCellValue("Статус рейса");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(23, 24, 8, 8));

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 8);
        cell5.setCellValue("Время в пути");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(23, 24, 9, 9));

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 9);
        cell6.setCellValue("Пробег, км");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(23, 23, 10, 19));

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 10);
        cell7.setCellValue("Нарушения");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_1 = rowHeader.createCell(startColIndex + 11);
        cell7_1.setCellValue("");
        cell7_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_2 = rowHeader.createCell(startColIndex + 12);
        cell7_2.setCellValue("");
        cell7_2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_3 = rowHeader.createCell(startColIndex + 13);
        cell7_3.setCellValue("");
        cell7_3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_4 = rowHeader.createCell(startColIndex + 14);
        cell7_4.setCellValue("");
        cell7_4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_5 = rowHeader.createCell(startColIndex + 15);
        cell7_5.setCellValue("");
        cell7_5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_6 = rowHeader.createCell(startColIndex + 16);
        cell7_6.setCellValue("");
        cell7_6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_7 = rowHeader.createCell(startColIndex + 17);
        cell7_7.setCellValue("");
        cell7_7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_8 = rowHeader.createCell(startColIndex + 18);
        cell7_8.setCellValue("");
        cell7_8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_9 = rowHeader.createCell(startColIndex + 19);
        cell7_9.setCellValue("");
        cell7_9.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////////////////////////////////////////////////
        worksheet.addMergedRegion(new CellRangeAddress(23, 23, 20, 21));

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 20);
        cell8.setCellValue("Превышение скорости");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8_1 = rowHeader.createCell(startColIndex + 21);
        cell8_1.setCellValue("");
        cell8_1.setCellStyle(excelStyles.headerCellStyleBlue);
        /////////////////////////////////////////////////////////////////////////////////////////////////////

        buildSecondHeaders(worksheet);
    }

    private void buildSecondHeaders(XSSFSheet worksheet) {
        // Create second column headers
        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 24);
        rowHeader.setHeight((short) 570);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("Расписание");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("Факт");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("Отклонение");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("Расписание");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 5);
        cell6.setCellValue("Факт");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 6);
        cell7.setCellValue("Отклонение");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_1 = rowHeader.createCell(startColIndex + 7);
        cell7_1.setCellValue("");
        cell7_1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_2 = rowHeader.createCell(startColIndex + 8);
        cell7_2.setCellValue("");
        cell7_2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell7_3 = rowHeader.createCell(startColIndex + 9);
        cell7_3.setCellValue("");
        cell7_3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 10);
        cell8.setCellValue("Съезд с маршрута");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 11);
        cell9.setCellValue("Возврат на маршрут");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10 = rowHeader.createCell(startColIndex + 12);
        cell10.setCellValue("Ранний заезд в КТ");
        cell10.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell11 = rowHeader.createCell(startColIndex + 13);
        cell11.setCellValue("Поздний заезд в КТ");
        cell11.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell12 = rowHeader.createCell(startColIndex + 14);
        cell12.setCellValue("Ранний выезд из КТ");
        cell12.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell13 = rowHeader.createCell(startColIndex + 15);
        cell13.setCellValue("Поздний выезд из КТ");
        cell13.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell14 = rowHeader.createCell(startColIndex + 16);
        cell14.setCellValue("Пропуск КТ");
        cell14.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell15 = rowHeader.createCell(startColIndex + 17);
        cell15.setCellValue("Превышено время нахождения в КТ");
        cell15.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell16 = rowHeader.createCell(startColIndex + 18);
        cell16.setCellValue("Остановка более лимита вне КТ");
        cell16.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell17 = rowHeader.createCell(startColIndex + 19);
        cell17.setCellValue("Не остановился в КТ");
        cell17.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell18 = rowHeader.createCell(startColIndex + 20);
        cell18.setCellValue("Количество");
        cell18.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell19 = rowHeader.createCell(startColIndex + 21);
        cell19.setCellValue("Максимальная скорость, км/ч");
        cell19.setCellStyle(excelStyles.headerCellStyleBlue);
    }

    private void buildDetails(XSSFSheet worksheet, TripData tripData) {
        worksheet.setColumnWidth(0, 12000);

        worksheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 3));
        worksheet.addMergedRegion(new CellRangeAddress(2, 2, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(3, 3, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(4, 4, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(5, 5, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(6, 6, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(7, 7, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(8, 8, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(9, 9, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(10, 10, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(11, 11, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(12, 12, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(13, 13, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(14, 14, 1, 4));
        worksheet.addMergedRegion(new CellRangeAddress(15, 15, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(16, 16, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(17, 17, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(18, 18, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(19, 19, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(20, 20, 1, 4));
//        worksheet.addMergedRegion(new CellRangeAddress(21, 21, 1, 4));

        XSSFRow rowDetails1 = worksheet.createRow((short) startRowIndex + 1);
        rowDetails1.setHeight((short) 300);

        XSSFCell cell1 = rowDetails1.createCell(0);
        cell1.setCellValue("Информация о движении объектов по маршрутам за выбранный интервал времени");
        cell1.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

//        XSSFRow rowDetails1 = worksheet.createRow((short) startRowIndex + 5);
//        rowDetails1.setHeight((short) 550);
//        XSSFCell cell1 = rowDetails1.createCell(startColIndex);
//        cell1.setCellValue("Информация о движении объектов по маршрутам за выбранный интервал времени");
//        cell1.setCellStyle(excelStyles.cellStyleTitle);

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails3 = worksheet.createRow((short) startRowIndex + 3);
        rowDetails3.setHeight((short) 300);

        XSSFCell cell2 = rowDetails3.createCell(0);
        cell2.setCellValue("Номер автопарка:");
        cell2.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell3 = rowDetails3.createCell(1);
        cell3.setCellValue(tripData.getCustomerCompanyName());
        cell3.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails5 = worksheet.createRow((short) startRowIndex + 4);
        rowDetails5.setHeight((short) 300);

        XSSFCell cell5_1 = rowDetails5.createCell(0);
        cell5_1.setCellValue("Наименование маршрута:");
        cell5_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell5_2_ = rowDetails5.createCell(1);
        cell5_2_.setCellValue(tripData.getTripName().trim());
        cell5_2_.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails6 = worksheet.createRow((short) startRowIndex + 5);
        rowDetails6.setHeight((short) 300);

        XSSFCell cell6_1 = rowDetails6.createCell(0);
        cell6_1.setCellValue("Направление маршрута:");
        cell6_1.setCellStyle(excelStyles.bodyCellStyleLeft);

//        String tripDirectionFmt = "";
//        if (tripData.getTripDirection() != null && Objects.equals(tripData.getTripDirection(), "A")) {
//            tripDirectionFmt = "AB";
//        } else if (tripData.getTripDirection() != null && Objects.equals(tripData.getTripDirection(), "B")) {
//            tripDirectionFmt = "BA";
//        } else if (tripData.getTripDirection() != null) {
//            tripDirectionFmt = tripData.getTripDirection();
//        }

        XSSFCell cell6_2_ = rowDetails6.createCell(1);
        cell6_2_.setCellValue(tripData.getTripDirection());
        cell6_2_.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails7 = worksheet.createRow((short) startRowIndex + 6);
        rowDetails7.setHeight((short) 300);

        XSSFCell cell7_1 = rowDetails7.createCell(0);
        cell7_1.setCellValue("Описание маршрута:");
        cell7_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell7_2_ = rowDetails7.createCell(1);
        cell7_2_.setCellValue(tripData.getTripDescription().trim());
        cell7_2_.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails8 = worksheet.createRow((short) startRowIndex + 7);
        rowDetails8.setHeight((short) 300);

        XSSFCell cell8_1 = rowDetails8.createCell(0);
        cell8_1.setCellValue("Длина маршрута:");
        cell8_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell8_2_ = rowDetails8.createCell(1);
        cell8_2_.setCellValue(tripData.getTripDistance() / 1000 + " км");
        cell8_2_.setCellStyle(excelStyles.bodyCellStyleLeft);

        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails9 = worksheet.createRow((short) startRowIndex + 8);
        rowDetails9.setHeight((short) 300);

        XSSFCell cell9_1 = rowDetails9.createCell(0);
        cell9_1.setCellValue("Плановое время в пути:");
        cell9_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell9_2_ = rowDetails9.createCell(1);
        cell9_2_.setCellValue(tripData.getTripTimePlanned());
        cell9_2_.setCellStyle(excelStyles.TIME_STYLE_LEFT);
        cell9_2_.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails10 = worksheet.createRow((short) startRowIndex + 9);
        rowDetails10.setHeight((short) 300);

        XSSFCell cell10_1 = rowDetails10.createCell(0);
        cell10_1.setCellValue("Начало рейса:");
        cell10_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        String tripTypeStr = "";
        if (tripData.getTripType() == 1) {
            tripTypeStr = "График";
        } else if (tripData.getTripType() == 2) {
            tripTypeStr = "Произвольно";
        }

        XSSFCell cell10_2_ = rowDetails10.createCell(1);
        cell10_2_.setCellValue(tripTypeStr);
        cell10_2_.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails12 = worksheet.createRow((short) startRowIndex + 11);
        rowDetails12.setHeight((short) 300);

        XSSFCell cell12_1 = rowDetails12.createCell(0);
        cell12_1.setCellValue("Период отчета:");
        cell12_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell12_2_ = rowDetails12.createCell(1);
        cell12_2_.setCellValue(tripData.getStartDate());
        cell12_2_.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell12_2_.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell12_3_ = rowDetails12.createCell(2);
        cell12_3_.setCellValue(tripData.getEndDate());
        cell12_3_.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell12_3_.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails13 = worksheet.createRow((short) startRowIndex + 12);
        rowDetails13.setHeight((short) 300);

        XSSFCell cell13_1 = rowDetails13.createCell(0);
        cell13_1.setCellValue("Период выборки данных:");
        cell13_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell13_2 = rowDetails13.createCell(1);
        cell13_2.setCellValue(tripData.getReportStartPeriod());
        cell13_2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell13_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell13_3 = rowDetails13.createCell(2);
        cell13_3.setCellValue(tripData.getReportEndPeriod());
        cell13_3.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell13_3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails15 = worksheet.createRow((short) startRowIndex + 14);
        rowDetails15.setHeight((short) 300);

        XSSFCell cell15_1 = rowDetails15.createCell(0);
        cell15_1.setCellValue("Отчет сгенерировал:");
        cell15_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell15_2 = rowDetails15.createCell(1);
        cell15_2.setCellValue(tripData.getUserLogin());
        cell15_2.setCellStyle(excelStyles.bodyCellStyleLeft);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails17 = worksheet.createRow((short) startRowIndex + 16);
        rowDetails17.setHeight((short) 300);

        XSSFCell cell17_1 = rowDetails17.createCell(0);
        cell17_1.setCellValue("Количество рейсов по Графику:");
        cell17_1.setCellStyle(excelStyles.bodyCellStyleLeft);

//        Integer tripsCountByGraphic = 0;
//        if (tripData.getTripsCountByGraphic() != null) {
//            tripsCountByGraphic = tripData.getTripsCountByGraphic();
//        }
        XSSFCell cell17_2 = rowDetails17.createCell(1);
        cell17_2.setCellValue(0);
        cell17_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell17_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails18 = worksheet.createRow((short) startRowIndex + 17);
        rowDetails18.setHeight((short) 300);

        XSSFCell cell18_1 = rowDetails18.createCell(0);
        cell18_1.setCellValue("Количество рейсов по статусам:");
        cell18_1.setCellStyle(excelStyles.bodyCellStyleLeft);

        XSSFCell cell18_2 = rowDetails18.createCell(1);
        cell18_2.setCellValue(status100Total + status200Total + status300Total + status400Total);
        cell18_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell18_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails19 = worksheet.createRow((short) startRowIndex + 18);
        rowDetails19.setHeight((short) 300);

        XSSFCell cell19_1 = rowDetails19.createCell(0);
        cell19_1.setCellValue("завершен:");
        cell19_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell19_2 = rowDetails19.createCell(1);
        cell19_2.setCellValue(status100Total);
        cell19_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell19_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails20 = worksheet.createRow((short) startRowIndex + 19);
        rowDetails20.setHeight((short) 300);

        XSSFCell cell20_1 = rowDetails20.createCell(0);
        cell20_1.setCellValue("не начат:");
        cell20_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell20_2 = rowDetails20.createCell(1);
        cell20_2.setCellValue(status400Total);
        cell20_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell20_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails21 = worksheet.createRow((short) startRowIndex + 20);
        rowDetails21.setHeight((short) 300);

        XSSFCell cell21_1 = rowDetails21.createCell(0);
        cell21_1.setCellValue("активный:");
        cell21_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell21_2 = rowDetails21.createCell(1);
        cell21_2.setCellValue(status200Total);
        cell21_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell21_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////
        XSSFRow rowDetails22 = worksheet.createRow((short) startRowIndex + 21);
        rowDetails22.setHeight((short) 300);

        XSSFCell cell22_1 = rowDetails22.createCell(0);
        cell22_1.setCellValue("не завершен:");
        cell22_1.setCellStyle(excelStyles.bodyCellStyleRight);

        XSSFCell cell22_2 = rowDetails22.createCell(1);
        cell22_2.setCellValue(status300Total);
        cell22_2.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell22_2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        //////////////////////////////////////////////////////////////////////
    }

    @Override
    public void addRow(XSSFRow row, ReportTrip item) {
        XSSFCell cell1 = row.createCell(startColIndex);
        cell1.setCellValue(item.getMobject());
        cell1.setCellStyle(excelStyles.bodyCellNotWrapStyle);
        cell1.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell2 = row.createCell(startColIndex + 1);
        cell2.setCellValue(item.getTimeStartPlanned());
        cell2.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell2.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell3 = row.createCell(startColIndex + 2);
        cell3.setCellValue(item.getTimeStartReal());
        cell3.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell3.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell4 = row.createCell(startColIndex + 3);
        cell4.setCellValue(item.getTimeStartDeviation());
        cell4.setCellStyle(excelStyles.TIME_STYLE);
        cell4.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell5 = row.createCell(startColIndex + 4);
        cell5.setCellValue(item.getTimeEndPlanned());
        cell5.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
        cell5.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell6 = row.createCell(startColIndex + 5);
        if (item.getTimeEndReal() != null) {
            cell6.setCellValue(item.getTimeEndReal());
            cell6.setCellStyle(excelStyles.DATE_TIME_FULL_STYLE);
            cell6.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell6.setCellValue("");
            cell6.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell6.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell7 = row.createCell(startColIndex + 6);
        if (item.getTimeEndDeviation() != null) {
            cell7.setCellValue(item.getTimeEndDeviation());
            cell7.setCellStyle(excelStyles.TIME_STYLE);
            cell7.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell7.setCellValue("");
            cell7.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell7.setCellType(XSSFCell.CELL_TYPE_STRING);
        }


        String tripStatusStr;
        if (item.getTripStatus() == 100) {
            tripStatusStr = "Завершен";
            status100Total += 1;
        } else if (item.getTripStatus() == 200) {
            tripStatusStr = "Активный";
            status200Total += 1;
        } else if (item.getTripStatus() == 300) {
            tripStatusStr = "Не завершен";
            status300Total += 1;
        } else if (item.getTripStatus() == 400) {
            tripStatusStr = "Не начат";
            status400Total += 1;
        } else {
            tripStatusStr = "Не начат";
        }

        XSSFCell cell8 = row.createCell(startColIndex + 7);
        cell8.setCellValue(tripStatusStr);
        cell8.setCellStyle(excelStyles.bodyCellStyle);
        cell8.setCellType(XSSFCell.CELL_TYPE_STRING);

        XSSFCell cell9 = row.createCell(startColIndex + 8);
        if (item.getTripTimeTravel() != null) {
            cell9.setCellValue(item.getTripTimeTravel());
            cell9.setCellStyle(excelStyles.TIME_STYLE);
            cell9.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell9.setCellValue("");
            cell9.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell9.setCellType(XSSFCell.CELL_TYPE_STRING);
        }

        XSSFCell cell10 = row.createCell(startColIndex + 9);
        cell10.setCellValue(item.getTripDistanceTravel());
        cell10.setCellStyle(excelStyles.bodyCellStyleNumeric);
        cell10.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell11 = row.createCell(startColIndex + 10);
        cell11.setCellValue(item.getEventRouteExitCount());
        cell11.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell11.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell14 = row.createCell(startColIndex + 11);
        cell14.setCellValue(item.getEventRouteReturnCount());
        cell14.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell14.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        /////////////////////////////
        XSSFCell cell15 = row.createCell(startColIndex + 12);
        cell15.setCellValue(item.getEventStationEnterEarly());
        cell15.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell15.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
/////////////////////////////

        XSSFCell cell16 = row.createCell(startColIndex + 13);
        cell16.setCellValue(item.getEventStationEnterLate());
        cell16.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell16.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell17 = row.createCell(startColIndex + 14);
        cell17.setCellValue(item.getEventStationExitEarly());
        cell17.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell17.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell16_1 = row.createCell(startColIndex + 15);
        cell16_1.setCellValue(item.getEventStationExitLate());
        cell16_1.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell16_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell17_1 = row.createCell(startColIndex + 16);
        cell17_1.setCellValue(item.getEventStationSkipped());
        cell17_1.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell17_1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell18 = row.createCell(startColIndex + 17);
        cell18.setCellValue(item.getEventStationParkingMoreCount());
        cell18.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell18.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell19 = row.createCell(startColIndex + 18);
        if(item.getEventStationOutParkingMoreTime() != null) {
            cell19.setCellValue(item.getEventStationOutParkingMoreTime());
        }else {
            cell19.setCellValue("");
        }
        cell19.setCellStyle(excelStyles.TIME_STYLE);
        cell19.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell20 = row.createCell(startColIndex + 19);
        cell20.setCellValue(item.getEventStationNotStopped());
        cell20.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell20.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell21 = row.createCell(startColIndex + 20);
        if (item.getEventOverspeedCount() != null) {
            cell21.setCellValue(item.getEventOverspeedCount());
        } else {
            cell21.setCellValue(0);
        }
        cell21.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell21.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        XSSFCell cell22 = row.createCell(startColIndex + 21);
        if (item.getEventOverspeedMaxSpeed() != null && item.getEventOverspeedCount() != null && item.getEventOverspeedCount() > 0) {
            cell22.setCellValue(item.getEventOverspeedMaxSpeed());
            cell22.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell22.setCellType(XSSFCell.CELL_TYPE_NUMERIC);
        } else {
            cell22.setCellValue("");
            cell22.setCellStyle(excelStyles.bodyCellNotWrapStyle);
            cell22.setCellType(XSSFCell.CELL_TYPE_STRING);
        }
    }

    private void setConditionalFormatting(XSSFSheet worksheet, int maxRow) throws Exception {
        XSSFSheetConditionalFormatting sheetCF = worksheet.getSheetConditionalFormatting();

        org.apache.poi.ss.util.CellRangeAddress[] regions1 = {CellRangeAddress.valueOf("H25:H" + maxRow)};

        XSSFConditionalFormattingRule ruleGreen = createConditionalFormattingRuleBeginsWith(sheetCF, "Завершен");
        XSSFConditionalFormattingRule ruleYellow = createConditionalFormattingRuleBeginsWith(sheetCF, "Активный");
        XSSFConditionalFormattingRule ruleRed = createConditionalFormattingRuleBeginsWith(sheetCF, "Не завершен");
        XSSFConditionalFormattingRule ruleBlue = createConditionalFormattingRuleBeginsWith(sheetCF, "Не начат");

//        ConditionalFormattingRule ruleYellow = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Активный");
//        ConditionalFormattingRule ruleRed = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Не завершен");
//        ConditionalFormattingRule ruleBlue = sheetCF.createConditionalFormattingRule(ComparisonOperator.EQUAL, "Не начат");

        PatternFormatting patternFmtGreen = ruleGreen.createPatternFormatting();
        patternFmtGreen.setFillBackgroundColor(IndexedColors.LIGHT_GREEN.index);

        PatternFormatting patternFmtYellow = ruleYellow.createPatternFormatting();
        patternFmtYellow.setFillBackgroundColor(IndexedColors.YELLOW.index);

        PatternFormatting patternFmtRed = ruleRed.createPatternFormatting();
        patternFmtRed.setFillBackgroundColor(IndexedColors.RED.index);
//
        PatternFormatting patternFmtBlue = ruleBlue.createPatternFormatting();
        patternFmtBlue.setFillBackgroundColor(IndexedColors.LIGHT_BLUE.index);

        XSSFConditionalFormattingRule[] cfRules = new XSSFConditionalFormattingRule[]{ruleGreen, ruleYellow, ruleRed};

        sheetCF.addConditionalFormatting(regions1, cfRules);
        sheetCF.addConditionalFormatting(regions1, ruleBlue);
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /**
     * Fills the report rows with content
     */
    @Override
    public void fillReport(CustomWorkSheet customWorkSheet) throws Exception {
        int rowIndx = 25;
        status100Total = 0;
        status200Total = 0;
        status300Total = 0;
        status400Total = 0;
        if (customWorkSheet != null && customWorkSheet.getTripData() != null && customWorkSheet.getTripData().getReportTripList().size() > 0) {
            XSSFRow row;

            for (ReportTrip reportTrip : customWorkSheet.getTripData().getReportTripList()) {
                // Create a new row
                row = customWorkSheet.getWorksheet().createRow(rowIndx);

                addRow(row, reportTrip);
                rowIndx++;
            }

            // Build report details
            buildDetails(customWorkSheet.getWorksheet(), customWorkSheet.getTripData());
            setConditionalFormatting(customWorkSheet.getWorksheet(), rowIndx);
        }


    }
}
