package uzgps.excel.data;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.springframework.stereotype.Component;
import uzgps.excel.ExcelDownloader;
import uzgps.persistence.Staff;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class ExcelStaff extends ExcelDownloader<Staff> {


    public ExcelStaff(){
        setFileName("ExcelStaff"); // File name
        sheetName = "Список персонала";
        fieldsCount = 8;
    }

    @Override
    public void buildHeaders() {
        title = translateText("Список персонала");

        XSSFRow rowHeader = worksheet.createRow((short) startRowIndex + 2);
        rowHeader.setHeight((short) 550);

        XSSFCell cell1 = rowHeader.createCell(startColIndex);
        cell1.setCellValue("ID");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);
        worksheet.addMergedRegion(new CellRangeAddress(startRowIndex + 2, startRowIndex + 3, startColIndex, startColIndex));

        XSSFCell cell2 = rowHeader.createCell(startColIndex + 1);
        cell2.setCellValue("Ф.И.О сотрудника");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);
        worksheet.addMergedRegion(new CellRangeAddress(startRowIndex + 2, startRowIndex + 3, startColIndex + 1, startColIndex + 1));

        XSSFCell cell3 = rowHeader.createCell(startColIndex + 2);
        cell3.setCellValue("Должность");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);
        worksheet.addMergedRegion(new CellRangeAddress(startRowIndex + 2, startRowIndex + 3, startColIndex + 2, startColIndex + 2));

        XSSFCell cell4 = rowHeader.createCell(startColIndex + 3);
        cell4.setCellValue("Организация");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);
        worksheet.addMergedRegion(new CellRangeAddress(startRowIndex + 2, startRowIndex + 3, startColIndex + 3, startColIndex + 3));

        XSSFCell cell5 = rowHeader.createCell(startColIndex + 4);
        cell5.setCellValue("Подразделение");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);
        worksheet.addMergedRegion(new CellRangeAddress(startRowIndex + 2, startRowIndex + 3, startColIndex + 4, startColIndex + 4));

        XSSFCell cell6 = rowHeader.createCell(startColIndex + 5);
        cell6.setCellValue("Наименование объекта");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);
        worksheet.addMergedRegion(new CellRangeAddress(startRowIndex + 2, startRowIndex + 3, startColIndex + 5, startColIndex + 5));

        XSSFCell cell7 = rowHeader.createCell(startColIndex + 6);
        cell7.setCellValue("Объект");
        cell7.setCellStyle(excelStyles.headerCellStyleBlue);
        worksheet.addMergedRegion(new CellRangeAddress(startRowIndex + 2, startRowIndex + 2, startColIndex + 6, startColIndex + 8));

        XSSFCell cell8 = rowHeader.createCell(startColIndex + 7);
        cell8.setCellValue("");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9 = rowHeader.createCell(startColIndex + 8);
        cell9.setCellValue("");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        buildSecondHeaders();
    }


    private void buildSecondHeaders() {
        XSSFRow rowHeaderSecond = worksheet.createRow((short) startRowIndex + 3);

        XSSFCell cell1 = rowHeaderSecond.createCell(startColIndex);
        cell1.setCellValue("");
        cell1.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell2 = rowHeaderSecond.createCell(startColIndex + 1);
        cell2.setCellValue("");
        cell2.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell3 = rowHeaderSecond.createCell(startColIndex + 2);
        cell3.setCellValue("");
        cell3.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell4 = rowHeaderSecond.createCell(startColIndex + 3);
        cell4.setCellValue("");
        cell4.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell5 = rowHeaderSecond.createCell(startColIndex + 4);
        cell5.setCellValue("");
        cell5.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell6 = rowHeaderSecond.createCell(startColIndex + 5);
        cell6.setCellValue("");
        cell6.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell8 = rowHeaderSecond.createCell(startColIndex + 6);
        cell8.setCellValue("c");
        cell8.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell9 = rowHeaderSecond.createCell(startColIndex + 7);
        cell9.setCellValue("до");
        cell9.setCellStyle(excelStyles.headerCellStyleBlue);

        XSSFCell cell10 = rowHeaderSecond.createCell(startColIndex + 8);
        cell10.setCellValue("Постоянно");
        cell10.setCellStyle(excelStyles.headerCellStyleBlue);

    }

    @Override
    public void addRow(XSSFRow row, Staff item) {

        XSSFCell cell1 = row.createCell(startColIndex);
        cell1.setCellValue(item.getId());
        cell1.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell1.setCellType(XSSFCell.CELL_TYPE_NUMERIC);

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell2 = row.createCell(startColIndex + 1);

        cell2.setCellValue(item.getMiddleName() + " " + item.getName() + " " + item.getSurName());
        cell2.setCellStyle(excelStyles.bodyCellStyleCenter);
        cell2.setCellType(XSSFCell.CELL_TYPE_STRING);

        ///////////////////////////////////////////////////////////////////////////////////////////////

        XSSFCell cell3 = row.createCell(startColIndex + 2);
        cell3.setCellValue(item.getPosition());
        cell3.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
        cell3.setCellType(XSSFCell.CELL_TYPE_STRING);

        ///////////////////////////////////////////////////////////////////////////////////////////////

        XSSFCell cell4 = row.createCell(startColIndex + 3);

        if (item.getCatalogCompany() != null){
            cell4.setCellValue(item.getCatalogCompany().getName());
        }else {
            cell4.setCellValue("");
        }

        cell4.setCellStyle(excelStyles.bodyCellStyleLeft);
        cell4.setCellType(XSSFCell.CELL_TYPE_STRING);
        ///////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////////////////////////////////////
        XSSFCell cell5 = row.createCell(startColIndex + 4);

        if (item.getCatalogSubdivision() != null){
            cell5.setCellValue(item.getCatalogSubdivision().getName());
        }else {
            cell5.setCellValue("");
        }
        cell5.setCellStyle(excelStyles.bodyCellStyleCenter);
        cell5.setCellType(XSSFCell.CELL_TYPE_STRING);

        if(item.getmObjectStaffList().size() > 0){
            XSSFCell cell6 = row.createCell(startColIndex + 5);
            cell6.setCellValue(item.getmObjectStaffList().get(0).getmObject().getmObjectName());
            cell6.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell6.setCellType(XSSFCell.CELL_TYPE_STRING);

            XSSFCell cell7 = row.createCell(startColIndex + 6);
            cell7.setCellValue(item.getmObjectStaffList().get(0).getStartDateToFormat());
            cell7.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell7.setCellType(XSSFCell.CELL_TYPE_STRING);

            ///////////////////////////////////////////////////////////////////////////////////////////////
            XSSFCell cell8 = row.createCell(startColIndex + 7);
            cell8.setCellValue(item.getmObjectStaffList().get(0).getEndless()? "" : item.getmObjectStaffList().get(0).getEndDateToFormat());
            cell8.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell8.setCellType(XSSFCell.CELL_TYPE_STRING);
            //////////////////////////////////////////////////////////////////////

            ///////////////////////////////////////////////////////////////////////////////////////////////
            XSSFCell cell9 = row.createCell(startColIndex + 8);
            cell9.setCellValue(item.getmObjectStaffList().get(0).getEndless()? "Да" : "Нет");
            cell9.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell9.setCellType(XSSFCell.CELL_TYPE_STRING);
            //////////////////////////////////////////////////////////////////////

        }else {
            XSSFCell cell6 = row.createCell(startColIndex + 5);
            cell6.setCellValue("");
            cell6.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell6.setCellType(XSSFCell.CELL_TYPE_STRING);

            XSSFCell cell7 = row.createCell(startColIndex + 6);
            cell7.setCellValue("");
            cell7.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell7.setCellType(XSSFCell.CELL_TYPE_STRING);

            ///////////////////////////////////////////////////////////////////////////////////////////////
            XSSFCell cell8 = row.createCell(startColIndex + 7);
            cell8.setCellValue("");
            cell8.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell8.setCellType(XSSFCell.CELL_TYPE_STRING);
            //////////////////////////////////////////////////////////////////////

            ///////////////////////////////////////////////////////////////////////////////////////////////
            XSSFCell cell9 = row.createCell(startColIndex + 8);
            cell9.setCellValue("");
            cell9.setCellStyle(excelStyles.SIMPLE_NUMERIC_STYLE);
            cell9.setCellType(XSSFCell.CELL_TYPE_STRING);
            //////////////////////////////////////////////////////////////////////

        }
    }

    @Override
    public void fillReport() {
        // Create body
        int rowIndx = 4;
        if (dbList != null) {
            for (Staff item : dbList) {

                XSSFRow row = worksheet.createRow(rowIndx);

                addRow(row, item);
                rowIndx++;
            }
        }
    }

    @Override
    public void buildTitle() {
        // Create report title
        XSSFRow rowTitle = worksheet.createRow(startRowIndex);
        rowTitle.setHeight((short) 500);
        XSSFCell cellTitle = rowTitle.createCell(startColIndex);
        cellTitle.setCellValue(title);
        cellTitle.setCellStyle(excelStyles.cellStyleTitle);

        // Create merged region for the report title
        worksheet.addMergedRegion(new CellRangeAddress(0, 0, 0, fieldsCount));

        // Create date header
        XSSFRow dateTitle = worksheet.createRow(startRowIndex + 1);
        XSSFCell cellDate = dateTitle.createCell(startColIndex);

        DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        df.format(new Date());
        cellDate.setCellValue("Список был сгенерирован" + " " + df.format(new Date()));
    }
}
