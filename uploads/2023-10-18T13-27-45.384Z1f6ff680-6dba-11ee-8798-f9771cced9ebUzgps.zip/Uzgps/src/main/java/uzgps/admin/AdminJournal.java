package uzgps.admin;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import uzgps.dto.BasedDTO;
import uzgps.main.MainController;
import uzgps.persistence.*;
import uzgps.settings.SettingsService;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.sql.Timestamp;

/**
 * Created by Saidolim on 02.04.14.
 */

@Service
@Transactional
public class AdminJournal {

    private static Logger logger = LoggerFactory.getLogger(AdminJournal.class);

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    SettingsService settingsService;

    /**
     * Stores all data about this action and object to journal table
     *
     * @param action  Create, Update, Save, Delete and others
     * @param comment really what is doing, the code of action in detail
     * @param obj     what object changed. object after change
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public void log(int action, int comment, int type, Object obj) {

        String callerName = "";

        Journal journal = new Journal();
        journal.setClassName(callerName);
        journal.setAction(action);
        journal.setComment(comment);
        journal.setObjectId(getObjectId(obj));
        journal.setDate(new Timestamp(System.currentTimeMillis()));
        journal.setRegDate(new Timestamp(System.currentTimeMillis()));
        journal.setStatus("A");
        journal.setType(type);

        // Get user Id from session.
        Long userId = MainController.getUserId();
//        if (MainController.getUser() != null)
//            userId = MainController.getUser().getId();
        if (userId != null)
            journal.setUserId(userId);
        else
            journal.setUserId(0);

        // Parse Data to Object
        String objData = "";
        try {
            ObjectMapper mapper = new ObjectMapper();
            objData = mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        journal.setJobject(objData);

        // Save log to journal
        entityManager.persist(journal);
    }

    @Transactional(propagation = Propagation.REQUIRED)
    public void logging(int action, int comment, int type, BasedDTO obj) {
        try {
            String callerName = "";

            Journal journal = new Journal();
            journal.setClassName(callerName);
            journal.setAction(action);
            journal.setComment(comment);
            journal.setObjectId(obj.returnObjectId());
            journal.setDate(new Timestamp(System.currentTimeMillis()));
            journal.setRegDate(new Timestamp(System.currentTimeMillis()));
            journal.setStatus("A");
            journal.setType(type);

            // Get user Id from session.
            Long userId = MainController.getUserId();

            if (userId != null)
                journal.setUserId(userId);
            else
                journal.setUserId(0);

            // Parse Object Data
            String objData = "";
            try {
                ObjectMapper mapper = new ObjectMapper();
                objData = mapper.writeValueAsString(obj);
            } catch (JsonProcessingException e) {
                logger.error(e.getMessage());
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
            journal.setJobject(objData);

            // Save log to journal
            entityManager.persist(journal);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

//    //  Logging Contract
//    @Transactional(propagation = Propagation.REQUIRED)
//    public void loggingContract(int action, int comment, int type, BasedDTO obj) {
//
//        Journal journal = setJournalAttributes(action, comment, type, obj);
//
//        // Parse Object Data
//        String objData = "";
//        try {
//            ObjectMapper mapper = new ObjectMapper();
//            objData = mapper.writeValueAsString(obj);
//        } catch (JsonProcessingException e) {
//            logger.error(e.getMessage());
//        } catch (Exception e) {
//            logger.error(e.getMessage());
//        }
//        journal.setGpsTrackPoint(objData);
//
//        // Save log to journal
//        entityManager.persist(journal);
//    }


    public Journal setJournalAttributes(int action, int comment, int type, BasedDTO obj) {

        String callerName = "";

        Journal journal = new Journal();
        journal.setClassName(callerName);
        journal.setAction(action);
        journal.setComment(comment);
        journal.setObjectId(obj.returnObjectId());
        journal.setDate(new Timestamp(System.currentTimeMillis()));
        journal.setRegDate(new Timestamp(System.currentTimeMillis()));
        journal.setStatus("A");
        journal.setType(type);

        // Get user Id from session.
        Long userId = MainController.getUserId();

        if (userId != null) {
            journal.setUserId(userId);

            User editor = settingsService.getUserByUserId(userId);
            journal.setEditor(editor.getLogin());
        } else
            journal.setUserId(0);

        // Parse Object Data
        String objData = "";
        try {
            ObjectMapper mapper = new ObjectMapper();
            objData = mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        journal.setJobject(objData);

        return journal;
    }

    /**
     * Gets a given object id
     *
     * @param object
     * @return id of the given object
     */
    private Long getObjectId(Object object) {

        if (object instanceof GPSUnit) {
            return ((GPSUnit) object).getId();
        } else if (object instanceof MObject) {
            return ((MObject) object).getId();
        } else if (object instanceof MObjectStaff) {
            return ((MObjectStaff) object).getId();
        }

        return 0L;
    }
}

