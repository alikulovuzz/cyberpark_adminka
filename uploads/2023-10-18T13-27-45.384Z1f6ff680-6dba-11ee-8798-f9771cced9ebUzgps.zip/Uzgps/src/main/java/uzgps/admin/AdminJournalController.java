package uzgps.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.Journal;
import uzgps.persistence.User;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Saidolim on 03.04.14.
 */

@Controller
public class AdminJournalController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ADMIN_JOURNALS = "/admin/journals.htm";
    private final static String VIEW_ADMIN_JOURNALS = "admin/journal-homepage";

    private final static String URL_ADMIN_JOURNALS_TABLE = "/admin/journals/table.htm";
    private final static String VIEW_ADMIN_JOURNALS_TABLE = "admin/journal-table";

    private final static String URL_ADMIN_JOURNALS_TABLE_AJAX = "/admin/journals/ajax.htm";
    private final static String VIEW_ADMIN_JOURNALS_TABLE_AJAX = "admin/ajax-journal-table";

    private final static String CMD_REPORT = "report";
    private final static String CMD_POI = "poi";
    private final static String CMD_USERS = "users";
    private final static String CMD_CONTRACT = "contract";
    private final static String CMD_GPSUNIT = "gpsunit";
    private final static String CMD_COMPANY = "company";
    private final static String CMD_GEOFANCE = "geofance";
    private final static String CMD_LOGIN = "login";
    private final static String CMD_NOTIFICATION = "notification";


    @Autowired
    private AdminJournalService adminJournalService;

    @Autowired
    private AppConfiguration appConfiguration;

    @RequestMapping(value = URL_ADMIN_JOURNALS, method = RequestMethod.GET)
    public ModelAndView getJournalHomepage() {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_JOURNALS);

        // All url and names
        // URL list
        List<String> urlList = new ArrayList<>();
        urlList.add(CMD_REPORT);
        urlList.add(CMD_POI);
        urlList.add(CMD_USERS);
        urlList.add(CMD_CONTRACT);
        urlList.add(CMD_GPSUNIT);
        urlList.add(CMD_COMPANY);
        urlList.add(CMD_GEOFANCE);
        urlList.add(CMD_LOGIN);
        urlList.add(CMD_NOTIFICATION);
        modelAndView.addObject("urlList", urlList);
        modelAndView.addObject("url_pattern", URL_ADMIN_JOURNALS);
        return modelAndView;
    }

    /**
     * Full site view of table with data from journal table
     *
     * @param cmd  what journal needed
     * @param page what page must be shown
     * @return
     */
    @RequestMapping(value = URL_ADMIN_JOURNALS_TABLE, method = RequestMethod.GET)
    public ModelAndView getJournalTableGet(@RequestParam(defaultValue = "none", value = "cmd", required = false) String cmd,
                                           @RequestParam(defaultValue = "0", value = "page", required = false) int page) {

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_JOURNALS_TABLE);
        getJournalTable(modelAndView, cmd, page);
        modelAndView.addObject("url_pattern", URL_ADMIN_JOURNALS);
        return modelAndView;
    }


    /**
     * Ajax result function. When you call this function from ajax, it
     *
     * @param cmd  what journal needed
     * @param page what page must be shown
     * @return
     */
    @RequestMapping(value = URL_ADMIN_JOURNALS_TABLE_AJAX, method = RequestMethod.GET)
    public ModelAndView getJournalTableAjax(@RequestParam(defaultValue = "none", value = "cmd", required = false) String cmd,
                                            @RequestParam(defaultValue = "0", value = "page", required = false) int page) {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_JOURNALS_TABLE_AJAX);

        getJournalTable(modelAndView, cmd, page);

        return modelAndView;
    }

    /**
     * Returnes table of jounal entities.
     *
     * @param modelAndView which layout must be used, full for site of simple for ajax
     * @param cmd          what journal needed
     * @param page         what page must be shown
     * @return
     */
    public ModelAndView getJournalTable(ModelAndView modelAndView, String cmd, int page) {

        int rangeStart = 0;
        int rangeEnd = 0;


        if (cmd.equalsIgnoreCase(CMD_REPORT)) {

            modelAndView.addObject("title", "admin.journal" + CMD_REPORT);
            rangeStart = UZGPS_CONST.JOURNAL_REPORT;
            rangeEnd = UZGPS_CONST.JOURNAL_REPORT + 99;

        } else if (cmd.equalsIgnoreCase(CMD_POI)) {

            modelAndView.addObject("title", "admin.journal" + CMD_POI);
            rangeStart = UZGPS_CONST.JOURNAL_POI;
            rangeEnd = UZGPS_CONST.JOURNAL_POI + 99;

        } else if (cmd.equalsIgnoreCase(CMD_USERS)) {

            modelAndView.addObject("title", "admin.journal" + CMD_USERS);
            rangeStart = UZGPS_CONST.JOURNAL_ADMIN_USER;
            rangeEnd = UZGPS_CONST.JOURNAL_ADMIN_USER + 99;

        } else if (cmd.equalsIgnoreCase(CMD_CONTRACT)) {

            modelAndView.addObject("title", "admin.journal" + CMD_CONTRACT);
            rangeStart = UZGPS_CONST.JOURNAL_ADMIN_CONTRACT;
            rangeEnd = UZGPS_CONST.JOURNAL_ADMIN_CONTRACT + 99;

        } else if (cmd.equalsIgnoreCase(CMD_GPSUNIT)) {

            modelAndView.addObject("title", "admin.journal" + CMD_GPSUNIT);
            rangeStart = UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT;
            rangeEnd = UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT + 99;

        } else if (cmd.equalsIgnoreCase(CMD_COMPANY)) {

            modelAndView.addObject("title", "admin.journal" + CMD_COMPANY);
            rangeStart = UZGPS_CONST.JOURNAL_ADMIN_COMPANY;
            rangeEnd = UZGPS_CONST.JOURNAL_ADMIN_COMPANY + 99;

        } else if (cmd.equalsIgnoreCase(CMD_GEOFANCE)) {

            modelAndView.addObject("title", "admin.journal" + CMD_GEOFANCE);
            rangeStart = UZGPS_CONST.JOURNAL_GEOFANCE;
            rangeEnd = UZGPS_CONST.JOURNAL_GEOFANCE + 99;

        } else if (cmd.equalsIgnoreCase(CMD_LOGIN)) {

            modelAndView.addObject("title", "admin.journal" + CMD_LOGIN);
            rangeStart = UZGPS_CONST.JOURNAL_LOGIN;
            rangeEnd = UZGPS_CONST.JOURNAL_LOGIN + 99;

        } else if (cmd.equalsIgnoreCase(CMD_NOTIFICATION)) {

            modelAndView.addObject("title", "admin.journal" + CMD_NOTIFICATION);
            rangeStart = UZGPS_CONST.JOURNAL_NOTIFICATION;
            rangeEnd = UZGPS_CONST.JOURNAL_NOTIFICATION + 99;

        } else {
            modelAndView = new ModelAndView("redirect:" + URL_ADMIN_JOURNALS);
        }


        User user = MainController.getUser();
        Long userId = 0L;
        if (user != null)
            userId = user.getId();

        List<Journal> journalTable = adminJournalService.getJournalTable(rangeStart, rangeEnd, userId, page);
        modelAndView.addObject("journalTable", journalTable);
        modelAndView.addObject("page", page);
        modelAndView.addObject("cmd", cmd);

        return modelAndView;
    }
}
