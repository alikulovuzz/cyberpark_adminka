package uzgps.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.common.GrpUtils;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.persistence.Report;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * User: Sheroz Khaydarov
 * Date: 21.02.13 Time: 19:38
 */

@Service
@Component
public class AdminReportService {

//    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private AdminJournal adminJournal;

    @Transactional(readOnly = true)
    public List getReportList(long tenantId) {
        Query query;
        query = em.createNamedQuery("Report.getListByTenantId");
        query.setParameter("tenantId", tenantId);

        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public List getReportList(String language) {
        Query query;
        query = em.createNamedQuery("Report.getListByLanguage");
        query.setParameter("language", language);

        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public List getReportListByCategory(String language, Long category) {
        Query query;
        query = em.createNamedQuery("Report.getListByLanguageAndCategory");
        query.setParameter("language", language);
        query.setParameter("category", category);

        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public Report getReportById(Long id) {
        if (id == null)
            throw new IllegalArgumentException("report id is null");

        TypedQuery<Report> query;
        query = em.createNamedQuery("Report.getById", Report.class);
        query.setParameter("id", id);
        return query.getSingleResult();
    }

    @Transactional
    public Report saveReport(Report report) {
        if (report == null)
            throw new IllegalArgumentException("report object is null");

        if (report.getId() != null) {
            em.merge(report); // update
            //adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_REPORT_UPDATED, report);
        } else {
            em.persist(report); // add new
            //adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_REPORT_INSERT, report);
        }
        return report;
    }

    @Transactional
    public void removeReport(Long id) {
        if (id == null)
            throw new IllegalArgumentException("object id is null");

        Report report = getReportById(id);
        if (report != null) {
            report.setVisible(false);
            saveReport(report);

            // em.remove(report);
            String reportFile = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + report.getId().toString() + "." + report.getFileExtention();
            GrpUtils.removeFile(reportFile);
            String paramScriptFile = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + report.getId().toString() + ".groovy";
            GrpUtils.removeFile(paramScriptFile);
            String scriptFile = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + "r" + report.getId().toString() + ".groovy";
            GrpUtils.removeFile(scriptFile);

            //adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_REPORT_DELETED, report);

        }
    }


}