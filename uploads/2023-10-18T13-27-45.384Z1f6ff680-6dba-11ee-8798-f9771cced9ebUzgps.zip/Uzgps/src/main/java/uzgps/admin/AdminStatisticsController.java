package uzgps.admin;

import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;
import groovy.util.ResourceException;
import groovy.util.ScriptException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.jasperreports.*;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.User;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by sarvar on 08.11.14.
 */
@Controller
public class AdminStatisticsController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ADMIN_STATISTICS = "/admin/statistics.htm";
    private final static String VIEW_ADMIN_STATISTICS = "admin/statistics";


    private static final String URL_STATISTICS_VIEW = "/admin/statistics/view.htm";

    private static final String paramPrefix = "param-";

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private DataSource dataSourceReport;

    @Autowired
    private AdminService adminService;

    @RequestMapping(value = URL_ADMIN_STATISTICS, method = RequestMethod.GET)
    public ModelAndView getStatisticsHomepage() {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_STATISTICS);

//        List<Company> companies = adminService.getCompanyNames();

        List<User> customerListCount = adminService.getCustomerAdminByFilterAndStatus(0L, UZGPS_CONST.STATUS_ACTIVE, "", UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN,
                UZGPS_CONST.STATUS_ACTIVE, -1);

        modelAndView.addObject("url_pattern", URL_ADMIN_STATISTICS);
//        modelAndView.addObject("companies", companies);
        modelAndView.addObject("customers", customerListCount);


        return modelAndView;


    }

    @RequestMapping(value = URL_STATISTICS_VIEW)
    public ModelAndView viewReport(HttpSession session,
                                   HttpServletRequest httpServletRequest,
                                   @RequestParam(defaultValue = "html") String type,
                                   @RequestParam(value = "reportId", defaultValue = "1") Long id,
                                   @RequestParam(value = "month", defaultValue = "-1") Long months,
                                   @RequestParam(value = "year", defaultValue = "-1") Long year,
                                   Locale locale)
            throws ServletException, IOException {


        ModelAndView modelAndView;


        String exportFilename = "1";
        exportFilename = "Report" + id + "-" + year + "-" + months + "-";


        SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss.");
        String reportFilename = exportFilename + df.format(new Date()) + type;

        String language = "ru";
        if (locale != null && locale.getLanguage() != null)  language = locale.getLanguage();

        String url = "file:///" +
                appConfiguration.getReportConfiguration().getPath() + "admin/" + language + "/" + id + ".jasper";

        //setting report parameters
        Map<String, Object> reportParams = new HashMap<String, Object>();
        reportParams.put("month", months);
        reportParams.put("year", year);


        // Prepare parameters for Groovy report
        Map<String, String[]> parameterMap = httpServletRequest.getParameterMap();
        Set parameterSet = parameterMap.entrySet();

        // Prepare Groovy itself
        String gPath = appConfiguration.getReportConfiguration().getPath() + "admin/" + language + '/';
        String gScript = "r" + id + ".groovy";

        String[] roots = new String[]{gPath};
        GroovyScriptEngine gse = new GroovyScriptEngine(roots);
        Binding binding = new Binding();
        binding.setVariable("contractId", MainController.getUserContractId(session));
        binding.setVariable("month", months);
        binding.setVariable("year", year);
        binding.setVariable("userId", MainController.getInterfaceUserId());
        binding.setVariable("dataSourceReport", dataSourceReport);
        binding.setVariable("lang", language);

        // Set parameters to Groovy
        for (Object aParameterSet : parameterSet) {
            Map.Entry<String, String[]> entry = (Map.Entry<String, String[]>) aParameterSet;
            String paramName = entry.getKey();
            String[] paramValues = entry.getValue();
            String paramValue = null;
            if (paramValues.length == 1)
                paramValue = paramValues[0];
            if (paramName.startsWith(paramPrefix)) {
                paramName = paramName.substring(paramPrefix.length());
                binding.setVariable(paramName, paramValue);
            }
        }

        try {
            gse.run(gScript, binding);
        } catch (ResourceException e) {
            logger.error("ResourceException: ", e);
        } catch (ScriptException e) {
            logger.error("ScriptException: ", e);
        }

        reportParams.putAll(binding.getVariables());

        modelAndView = generateReport(httpServletRequest, url, type, reportFilename, reportParams);

        return modelAndView;

    }

    public ModelAndView generateReport(HttpServletRequest httpServletRequest, String url, String type, String reportFilename, Map<String, Object> params)
            throws IllegalArgumentException {

        AbstractJasperReportsSingleFormatView jasperReportView;

        if (type.equalsIgnoreCase("html"))
            jasperReportView = new JasperReportsHtmlView();
        else if (type.equalsIgnoreCase("pdf"))
            jasperReportView = new JasperReportsPdfView();
        else if (type.equalsIgnoreCase("xls"))
            jasperReportView = new JasperReportsXlsView();
        else if (type.equalsIgnoreCase("csv"))
            jasperReportView = new JasperReportsCsvView();
        else
            throw new IllegalArgumentException("Unrecognized report format:" + type);

        // setting properties
        jasperReportView.setJdbcDataSource(dataSourceReport);
        jasperReportView.setUrl(url);

        Map<String, Object> exporterParameters = new HashMap<String, Object>();
        exporterParameters.put("net.sf.jasperreports.engine.JRExporterParameter.CHARACTER_ENCODING", "UTF-8");

        if (!type.equalsIgnoreCase("html")) {
            // prepare content header
            Properties availableHeaders = new Properties();
            availableHeaders.put(type, "inline; filename=" + reportFilename);

            // setting content disposition header
            Properties headers = new Properties();

            headers.put("Content-Disposition", availableHeaders.get(type));
            jasperReportView.setHeaders(headers);
        } else {
            // set url for Jasper reports image servlet
            exporterParameters.put("net.sf.jasperreports.engine.export.JRHtmlExporterParameter.IMAGES_URI", "/images?image=");
        }

        jasperReportView.setExporterParameters(exporterParameters);

        // setting webApplicationContext required by the view
        HttpSession httpSession = httpServletRequest.getSession();
        ServletContext servletContext = httpSession.getServletContext();
        WebApplicationContext webApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);

        jasperReportView.setApplicationContext(webApplicationContext);

        ModelAndView modelAndView;
        modelAndView = new ModelAndView(jasperReportView);

        if (params != null)
            modelAndView.addAllObjects(params);

        return modelAndView;
    }

}
