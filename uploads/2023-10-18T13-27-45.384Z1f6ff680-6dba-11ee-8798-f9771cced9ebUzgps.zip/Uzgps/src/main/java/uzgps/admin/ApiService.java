package uzgps.admin;

import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.persistence.api.MObjectExtendedData;
import uzgps.persistence.api.MObjectExtendedWithPhotoData;
import uzgps.persistence.api.MObjectLastData;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stanislav on 05.05.22
 */

@Service
@Component
public class ApiService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    /**
     * Get data on objects under contracts available to the user
     *
     * @param userId
     * @return
     */
    @Transactional
    public List<MObjectLastData> getMobjectLastDataByUserId(Long userId) {
        try {
            String sqlQuery = " SELECT * FROM api.mobject_last_data mld " +
                    " where contract_id in (select contract_id " +
                    "                          from uzgps_user_role ur " +
                    "                          where user_id = ? " +
                    "                            and ur.status = 'A');";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectLastData.class);
            q.setParameter(1, userId);

            List<MObjectLastData> list = q.getResultList();
            return list;
        } catch (Exception e) {
            logger.error("ERROR in getMobjectLastDataByUserId", e);
            return new ArrayList<>();
        }
    }

    /**
     * Get data on objects under contracts available to the user
     *
     * @param userId
     * @param mobjectId
     * @return
     */
    @Transactional
    public MObjectLastData getMobjectLastDataByUserIdAndMobjectId(Long userId, Long mobjectId) {
        try {
            String sqlQuery = " SELECT * FROM api.mobject_last_data mld " +
                    " where contract_id in (select contract_id " +
                    "                          from uzgps_user_role ur " +
                    "                          where user_id = ? " +
                    "                          and mld.mobject_id = ? " +
                    "                            and ur.status = 'A');";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectLastData.class);
            q.setParameter(1, userId);
            q.setParameter(2, mobjectId);

            MObjectLastData mld = (MObjectLastData) q.getSingleResult();
            return mld;
        } catch (Exception e) {
            logger.error("ERROR in getMobjectLastDataByUserIdAndMobjectId", e);
            return null;
        }
    }

    /**
     * Get objects extended data
     *
     * @param userId
     * @return
     */
    @Transactional
    public List<MObjectExtendedData> getMobjectExtendedDataByUserId(Long userId) {
        try {
            String sqlQuery = " SELECT med.* " +
                    " FROM api.view_mobject_extended_data med " +
                    "         inner join api.mobject_last_data mld on med.mobject_id = mld.mobject_id " +
                    " where contract_id in (select contract_id " +
                    "                          from uzgps_user_role ur " +
                    "                          where user_id = ? " +
                    "                            and ur.status = 'A');";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectExtendedData.class);
            q.setParameter(1, userId);

            List<MObjectExtendedData> list = q.getResultList();
            return list;
        } catch (Exception e) {
            logger.error("ERROR in getMobjectExtendedDataByUserId", e);
            return new ArrayList<>();
        }
    }

    /**
     * Get objects extended data
     *
     * @param userId
     * @param mobjectId
     * @return
     */
    @Transactional
    public MObjectExtendedData getMobjectExtendedDataByUserIdAndMobjectId(Long userId, Long mobjectId) {
        try {
            String sqlQuery = " SELECT med.* " +
                    " FROM api.view_mobject_extended_data med " +
                    "         inner join api.mobject_last_data mld on med.mobject_id = mld.mobject_id " +
                    " where contract_id in (select contract_id " +
                    "                          from uzgps_user_role ur " +
                    "                          where user_id = ? " +
                    "                          and med.mobject_id = ? " +
                    "                            and ur.status = 'A');";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectExtendedData.class);
            q.setParameter(1, userId);
            q.setParameter(2, mobjectId);

            MObjectExtendedData med = (MObjectExtendedData) q.getSingleResult();
            return med;
        } catch (Exception e) {
            logger.error("ERROR in getMobjectExtendedDataByUserId", e);
            return null;
        }
    }

    /**
     * Get objects extended data
     *
     * @param userId
     * @return
     */
    @Transactional
    public List<MObjectExtendedWithPhotoData> getMobjectExtendedWithPhotoDataByUserId(Long userId) {
        try {
            String sqlQuery = " SELECT med.* " +
                    "FROM api.view_mobject_extended_with_photo_data med " +
                    "         inner join api.mobject_last_data mld on med.mobject_id = mld.mobject_id " +
                    " where contract_id in (select contract_id " +
                    "                          from uzgps_user_role ur " +
                    "                          where user_id = ? " +
                    "                            and ur.status = 'A');";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectExtendedWithPhotoData.class);
            q.setParameter(1, userId);

            List<MObjectExtendedWithPhotoData> list = q.getResultList();
            return list;
        } catch (Exception e) {
            logger.error("ERROR in getMobjectExtendedWithPhotoDataByUserId", e);
            return new ArrayList<>();
        }
    }

    /**
     * Get objects extended data
     *
     * @param userId
     * @param mobjectId
     * @return
     */
    @Transactional
    public MObjectExtendedWithPhotoData getMobjectExtendedWithPhotoDataByUserIdAndMobjectId(Long userId, Long mobjectId) {
        try {
            String sqlQuery = " SELECT med.* " +
                    "FROM api.view_mobject_extended_with_photo_data med " +
                    "         inner join api.mobject_last_data mld on med.mobject_id = mld.mobject_id " +
                    " where contract_id in (select contract_id " +
                    "                          from uzgps_user_role ur " +
                    "                          where user_id = ? " +
                    "                          and med.mobject_id = ? " +
                    "                            and ur.status = 'A');";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectExtendedWithPhotoData.class);
            q.setParameter(1, userId);
            q.setParameter(2, mobjectId);

            MObjectExtendedWithPhotoData mewfd = (MObjectExtendedWithPhotoData) q.getSingleResult();
            return mewfd;
        } catch (Exception e) {
            logger.error("ERROR in getMobjectExtendedWithPhotoDataByUserId", e);
            return null;
        }
    }

    /**
     * Get all objects extended data
     *
     * @return List of MObjectLastData
     */
    @Transactional
    public List<MObjectExtendedWithPhotoData> getMobjectExtendedData() {
        try {
            String sqlQuery = " SELECT * FROM api.view_mobject_extended_with_photo_data med;";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectExtendedWithPhotoData.class);

            List<MObjectExtendedWithPhotoData> list = q.getResultList();
            return list;
        } catch (Exception e) {
            logger.error("ERROR in getMobjectExtendedData", e);
            return new ArrayList<>();
        }
    }

}
