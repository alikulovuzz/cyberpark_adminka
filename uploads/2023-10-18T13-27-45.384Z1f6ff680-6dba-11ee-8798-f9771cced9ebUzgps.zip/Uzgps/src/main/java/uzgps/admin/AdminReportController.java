package uzgps.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import uzgps.common.configuration.AppConfiguration;
import uzgps.persistence.Report;

import javax.servlet.ServletException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by Saidolim on 31.03.2014
 */

@Controller
public class AdminReportController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ADMIN_REPORTS = "/admin/reports.htm";
    private final static String VIEW_ADMIN_REPORTS = "admin/admin-reports";

    private static final String URL_REPORT_ADD = "/admin/admin-report-add.htm";
    private static final String URL_REPORT_EDIT = "/admin/admin-report-edit.htm";
    private static final String VIEW_REPORT_ADD = "admin/admin-report-add";

    // Actions to use in View files.
    private static final int ACTION_ADD = 1;
    private static final int ACTION_EDIT = 2;
    private static final int ACTION_SAVE = 3;
    private static final int ACTION_DELETE = 4;

    public static final long REPORT_CATEGORY_COMMON = 0;
    public static final long REPORT_CATEGORY_ROUTING = 100;

    @Autowired
    private AdminReportService adminReportService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private MessageSource messageSource;

    /**
     * Get list of reports. Action is GET so, returnes list of reports
     *
     * @return
     */
    @RequestMapping(value = URL_ADMIN_REPORTS, method = RequestMethod.GET)
    public ModelAndView getList(Locale locale, @RequestParam(value = "category", defaultValue = "0") Long category) {

        String language = "ru";
//        if (locale != null) {
//            language = locale.getLanguage();
//        }

        //List list = adminReportService.getReportList(tenantId);
//        List list = adminReportService.getReportList(language);
        List list = adminReportService.getReportListByCategory(language, category);

        List<Report> reportList = new ArrayList<>();
        if (list != null) {
            for (Object obj : list)
                reportList.add((Report) obj);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_REPORTS);
        modelAndView.addObject("reportList", reportList);
        modelAndView.addObject("url_pattern", URL_ADMIN_REPORTS);
        modelAndView.addObject("category", category);

        return modelAndView;
    }

    /**
     * Form action link. If data send by POST method, works this function.
     *
     * @param cmd              command like "add", "edit" or "remove"
     * @param checkedReportIds list of ID in string array to edit or delete for.
     * @return
     */
    @RequestMapping(value = URL_ADMIN_REPORTS, method = RequestMethod.POST)
    public ModelAndView postList(@RequestParam(defaultValue = "none") String cmd,
                                 @RequestParam(required = false) String[] checkedReportIds,
                                 @RequestParam(value = "category", defaultValue = "0") Long category) {

        ModelAndView modelAndView;

        // Check commands: ADD
        if (cmd.equalsIgnoreCase("add")) {

            modelAndView = new ModelAndView(VIEW_REPORT_ADD);
            modelAndView.addObject("cmd", ACTION_ADD);
            modelAndView.addObject("category", category);

        } else if (cmd.equalsIgnoreCase("remove")) { // DELETE
            removeReports(checkedReportIds);
            modelAndView = new ModelAndView("redirect:" + URL_ADMIN_REPORTS);

        } else if (cmd.equalsIgnoreCase("edit")) { // EDIT

            // Check if any ID selected. Go to Edit page.
            if (checkedReportIds != null && checkedReportIds.length > 0) {
                Long reportId = Long.valueOf(checkedReportIds[0]);

                // Here it redirects to edit page.
                return new ModelAndView("redirect:" + URL_REPORT_EDIT + "?id=" + reportId);

            } else {
                // Check NO ID selected, redirect to list.
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_REPORTS);
            }
        } else {
            modelAndView = new ModelAndView("redirect:" + URL_ADMIN_REPORTS);
        }

        modelAndView.addObject("url_pattern", URL_ADMIN_REPORTS);
        return modelAndView;
    }

    @RequestMapping(value = URL_REPORT_ADD, method = RequestMethod.POST)
    public ModelAndView addReport(@RequestParam(value = "report-name", defaultValue = "") String reportName,
                                  @RequestParam(value = "report-description", defaultValue = "") String reportDescription,
                                  @RequestParam(value = "export-filename", defaultValue = "") String exportFilename,
                                  @RequestParam(value = "report-category", defaultValue = "0") Long category,
                                  @RequestParam(value = "report-file") MultipartFile reportFile,
                                  @RequestParam(value = "report-script", required = false) MultipartFile scriptFile,
                                  @RequestParam(value = "report-param-script", required = false) MultipartFile paramScriptFile
    )
            throws ServletException, IOException {


//        SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
/*
        UserDetail user = securityLoggedUser.getUserDetail();
        Db db = user.getDb();
*/
        if (logger.isDebugEnabled())
            logger.debug("REPORT ADD");


//        Long tenantId = 0L;

        Report report = new Report();
        report.setTenantId(category);
        report.setReportname(reportName);
        report.setDescription(reportDescription);
        report.setExportFileName(exportFilename);

        String filename = reportFile.getOriginalFilename();
        report.setOriginalFileName(filename);
        report.setFileSize(reportFile.getSize());
        int dotPos = filename.lastIndexOf(".") + 1;
        String fileExtention = filename.substring(dotPos).toLowerCase();
        report.setFileExtention(fileExtention);

        boolean hasParameterScript = (paramScriptFile != null && !paramScriptFile.isEmpty() && paramScriptFile.getSize() > 0);
        report.setHasParameterScript(hasParameterScript);

        boolean hasGeneratorScript = (scriptFile != null && !scriptFile.isEmpty() && scriptFile.getSize() > 0);
        report.setHasGeneratorScript(hasGeneratorScript);

        report.setVisible(true);

        adminReportService.saveReport(report);

        Long id = report.getId();

        // Save Report File
        String outFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + id.toString() + "." + fileExtention;

        if (logger.isDebugEnabled())
            logger.debug("outFileName: {}", outFileName);

        File outFile = new File(outFileName);
        if (outFile.createNewFile()) {
            reportFile.transferTo(outFile);
        }

        // Parameter generator file
        if (hasParameterScript) {
            String scriptFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + id.toString() + ".groovy";
            if (logger.isDebugEnabled())
                logger.debug("scriptFileName: {}", scriptFileName);

            File outScript = new File(scriptFileName);
            if (outScript.createNewFile()) {
                paramScriptFile.transferTo(outScript);
            }
        }

        // Report generator file
        if (hasGeneratorScript) {
            String scriptFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + "r" + id.toString() + ".groovy";
            if (logger.isDebugEnabled())
                logger.debug("scriptFileName: {}", scriptFileName);

            File outScript = new File(scriptFileName);
            if (outScript.createNewFile()) {
                scriptFile.transferTo(outScript);
            }
        }

        return new ModelAndView("redirect:" + URL_ADMIN_REPORTS);
    }

    private void removeReports(String[] checkedReportIds) {
        if (checkedReportIds != null) {
            for (String value : checkedReportIds) {
                Long id = Long.parseLong(value);
                adminReportService.removeReport(id);
            }
        }

    }

    /**
     * Link that gets to Edit.
     *
     * @param reportId ID of report
     * @return
     */
    @RequestMapping(value = URL_REPORT_EDIT, method = RequestMethod.GET)
    public ModelAndView editReport(@RequestParam(value = "id", defaultValue = "0") Long reportId) {

        if (reportId != null && reportId > 0) {

            Report report = adminReportService.getReportById(reportId);

//            logger.info("editReport = " + report);

            ModelAndView modelAndView = new ModelAndView(VIEW_REPORT_ADD);
            modelAndView.addObject("cmd", ACTION_EDIT);
            modelAndView.addObject("report", report);


            return modelAndView;
        }

        return new ModelAndView("redirect:" + URL_ADMIN_REPORTS);
    }

    /**
     * Edits reports some parts. If files given to upload, it rewrites files too.
     *
     * @param reportId          Id of report to be edited
     * @param reportNameRu      Report name RU
     * @param reportNameEn      Report name EN
     * @param reportNameUzc     Report name UZc
     * @param reportNameUzl     Report name UZl
     * @param reportDescription Description of report
     * @param exportFilename    File extension depending on script file.
     * @param reportFile        Report file name, than generated report and makes as PDF
     * @param scriptFile        Script file that gets some data from database and gives it to reportFile
     * @param paramScriptFile   Parameter script. For each report there are separate parameters with different value and fields.
     * @return ModelView to show on screen.
     */
    @RequestMapping(value = URL_REPORT_EDIT, method = RequestMethod.POST)
    public ModelAndView editReport(@RequestParam(value = "report-id", defaultValue = "0") Long reportId,
                                   @RequestParam(value = "report-name", defaultValue = "") String reportNameRu,
                                   @RequestParam(value = "report-name-en", defaultValue = "") String reportNameEn,
                                   @RequestParam(value = "report-name-uzc", defaultValue = "") String reportNameUzc,
                                   @RequestParam(value = "report-name-uzl", defaultValue = "") String reportNameUzl,
                                   @RequestParam(value = "report-description", defaultValue = "") String reportDescription,
                                   @RequestParam(value = "report-category", defaultValue = "0") Long category,
                                   @RequestParam(value = "export-filename", defaultValue = "") String exportFilename,
                                   @RequestParam(value = "report-type", defaultValue = "0") Long reportType,
                                   @RequestParam(value = "report-db", defaultValue = "0") Integer reportDb,
                                   @RequestParam(value = "report-file", required = false) MultipartFile reportFile,
                                   @RequestParam(value = "report-script", required = false) MultipartFile scriptFile,
                                   @RequestParam(value = "report-param-script", required = false) MultipartFile paramScriptFile,
                                   Locale locale) {

        // Get Report Id
        if (reportId != null && reportId > 0) {

            Report report = adminReportService.getReportById(reportId);
            report.setReportType(reportType);
            report.setWorkingDb(reportDb);
            boolean reportMustSave = false;

            // Change report name if entered
            if (reportNameRu != null && reportNameRu.length() > 0) {
                report.setNameRu(reportNameRu);
                reportMustSave = true;
            }
            // Change report name EN if entered
            if (reportNameEn != null && reportNameEn.length() > 0) {
                report.setNameEn(reportNameEn);
                reportMustSave = true;
            }
            // Change report name UZC if entered
            if (reportNameUzc != null && reportNameUzc.length() > 0) {
                report.setNameUzc(reportNameUzc);
                reportMustSave = true;
            }
            // Change report name UZL if entered
            if (reportNameUzl != null && reportNameUzl.length() > 0) {
                report.setNameUzl(reportNameUzl);
                reportMustSave = true;
            }

            // Change report Description if entered
            if (reportDescription != null && reportDescription.length() > 0) {
                report.setDescription(reportDescription);
                reportMustSave = true;
            }

            // Save report if any data changed
            if (reportMustSave) {
                adminReportService.saveReport(report);
            }


            // If Main file given, delete previous one and save send one.
            String filename = reportFile.getOriginalFilename();
            if (filename != null && filename.length() > 0) {

                // Generate file name
                String outFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + report.getId().toString() + "." + report.getFileExtention();

                if (logger.isDebugEnabled())
                    logger.debug("outFileName: {}", outFileName);

                // Save Report File
                File outFile = new File(outFileName);
                try {
                    // Delete if exists
                    outFile.delete();

                    // Create file
                    if (outFile.createNewFile()) {
                        reportFile.transferTo(outFile);
                    }
                } catch (IOException e) {
                    logger.error("error in editReport", e);
                }

            }

            // Parameter generator file
            filename = paramScriptFile.getOriginalFilename();
            if (filename != null && filename.length() > 0) {

                // Generate file name
                String outFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + report.getId().toString() + ".groovy";

                // Save Parameter File
                File outFile = new File(outFileName);
                try {
                    // Delete if exists
                    outFile.delete();

                    // Create file
                    if (outFile.createNewFile()) {
                        paramScriptFile.transferTo(outFile);
                    }
                } catch (IOException e) {
                    logger.error("error in editReport", e);
                }

            }

            // Report generator file
            filename = scriptFile.getOriginalFilename();
            if (filename != null && filename.length() > 0) {

                // Generate file name
                String outFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + "r" + report.getId().toString() + ".groovy";

                // Save Report generator  File
                File outFile = new File(outFileName);
                try {
                    // Delete if exists
                    outFile.delete();

                    // Create file
                    if (outFile.createNewFile()) {
                        scriptFile.transferTo(outFile);
                    }
                } catch (IOException e) {
                    logger.error("error in editReport", e);
                }

            }

            return new ModelAndView("redirect:" + URL_REPORT_EDIT + "?id=" + reportId);
        } else if (reportId != null && reportId == 0) {
            // Add report
            if (logger.isDebugEnabled())
                logger.debug("REPORT ADD");


//            Long tenantId = 0L;

            Report report = new Report();
            report.setTenantId(category);
            report.setNameRu(reportNameRu);
            report.setNameEn(reportNameEn);
            report.setNameUzc(reportNameUzc);
            report.setNameUzl(reportNameUzl);
            report.setDescription(reportDescription);
            report.setExportFileName(exportFilename);
            report.setReportType(reportType);

            String language = "ru";
//            if (locale != null) language = locale.getLanguage();
            report.setLanguage(language);

            String filename = reportFile.getOriginalFilename();
            report.setOriginalFileName(filename);
            report.setFileSize(reportFile.getSize());
            int dotPos = filename.lastIndexOf(".") + 1;
            String fileExtention = filename.substring(dotPos).toLowerCase();
            report.setFileExtention(fileExtention);

            boolean hasParameterScript = (paramScriptFile != null && !paramScriptFile.isEmpty() && paramScriptFile.getSize() > 0);
            report.setHasParameterScript(hasParameterScript);

            boolean hasGeneratorScript = (scriptFile != null && !scriptFile.isEmpty() && scriptFile.getSize() > 0);
            report.setHasGeneratorScript(hasGeneratorScript);

            report.setVisible(true);

            adminReportService.saveReport(report);

            Long id = report.getId();

            // Save Report File
            String outFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + id.toString() + "." + fileExtention;

            if (logger.isDebugEnabled())
                logger.debug("outFileName: {}", outFileName);

            File outFile = new File(outFileName);
            try {
                if (outFile.createNewFile()) {
                    reportFile.transferTo(outFile);
                }
            } catch (IOException e) {
                logger.error("Report file not saved. IO error");
            }

            // Parameter generator file
            if (hasParameterScript) {
                String scriptFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + id.toString() + ".groovy";
                if (logger.isDebugEnabled())
                    logger.debug("scriptFileName: {}", scriptFileName);

                File outScript = new File(scriptFileName);
                try {
                    if (outScript.createNewFile()) {
                        paramScriptFile.transferTo(outScript);
                    }
                } catch (IOException e) {
                    logger.error("Report param script file not saved. IO error");
                }
            }

            // Report generator file
            if (hasGeneratorScript) {
                String scriptFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + "r" + id.toString() + ".groovy";
                if (logger.isDebugEnabled())
                    logger.debug("scriptFileName: {}", scriptFileName);

                File outScript = new File(scriptFileName);
                try {
                    if (outScript.createNewFile()) {
                        scriptFile.transferTo(outScript);
                    }
                } catch (IOException e) {
                    logger.error("Report generator file not saved. IO error");
                }
            }
        }
        return new ModelAndView("redirect:" + URL_ADMIN_REPORTS + "?category=" + category);
    }
}
