package uzgps.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.GPSUnit;
import uzgps.persistence.GPSUnitType;
import uzgps.persistence.MObject;
import uzgps.persistence.MObjectGPSUnit;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */
@Controller
@Component
public class AdminTrackerController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ADMIN_TRACKERS_LIST = "/admin/trackers-list.htm";
    private final static String VIEW_ADMIN_TRACKERS_LIST = "admin/trackers-list";
    private final static String URL_ADMIN_TRACKERS_MANAGE = "/admin/trackers-manage.htm";
    private final static String VIEW_ADMIN_TRACKERS_MANAGE = "admin/trackers-manage";

    private final static String URL_ADMIN_TRACKERS_TYPE_LIST = "/admin/trackers-type-list.htm";
    private final static String VIEW_ADMIN_TRACKERS_TYPE_LIST = "admin/trackers-type-list";
    private final static String URL_ADMIN_TRACKERS_TYPE_MANAGE = "/admin/trackers-type-manage.htm";
    private final static String VIEW_ADMIN_TRACKERS_TYPE_MANAGE = "admin/trackers-type-manage";
    public final static String SESSION_ADMIN_TRACKERS_GPS_TYPE_CONNECTION = "sessionGpsTypeConnection";
    public final static String SESSION_ADMIN_TRACKERS_TEXT_SEARCH = "sessionTextSearch";

    @Autowired
    private AdminService adminService;

    @Autowired
    AdminJournal adminJournal;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_ADMIN_TRACKERS_LIST)
    public ModelAndView processAdminTrackers(HttpSession session,
                                             @RequestParam(value = "cmd", required = false) String cmd,
                                             @RequestParam(value = "gpsTypeConnection", required = false) Integer gpsTypeConnection,
                                             @RequestParam(value = "page", required = false, defaultValue = "0") Integer pageNumber,
                                             @RequestParam(value = "txtSearch", required = false) String txtSearch)

            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminTrackers cmd={},gpsTypeConnection={},txtSearch={}", cmd, gpsTypeConnection, txtSearch);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_TRACKERS_LIST);

        // treckers list clear
        if (cmd != null) {
            if (cmd.equalsIgnoreCase("clear")) {
                session.removeAttribute(SESSION_ADMIN_TRACKERS_GPS_TYPE_CONNECTION);
                session.removeAttribute(SESSION_ADMIN_TRACKERS_TEXT_SEARCH);
            }
        }

        if (txtSearch == null) {
            txtSearch = (String) session.getAttribute(SESSION_ADMIN_TRACKERS_TEXT_SEARCH);
        }
        if (txtSearch == null) txtSearch = "";


        if (gpsTypeConnection == null) {
            gpsTypeConnection = (Integer) session.getAttribute(SESSION_ADMIN_TRACKERS_GPS_TYPE_CONNECTION);
        }
        if (gpsTypeConnection == null) gpsTypeConnection = 0;


        if (pageNumber == null) pageNumber = 0;
        if (pageNumber < 0) pageNumber = 0;

        List<MObjectGPSUnit> mObjectGPSUnitsList = adminService.getGPSUniteAllByStatus(UZGPS_CONST.STATUS_ACTIVE, gpsTypeConnection, txtSearch, pageNumber);
        Integer mObjectGPSUnitsListCount = adminService.getGPSUniteAllByStatusCount(UZGPS_CONST.STATUS_ACTIVE, gpsTypeConnection, txtSearch);

        int pageCount = (mObjectGPSUnitsListCount + UZGPS_CONST.LIST_PER_PAGE - 1) / UZGPS_CONST.LIST_PER_PAGE;

        List<Integer> pagination = getPages(pageNumber, pageCount);

        modelAndView.addObject("mObjectGPSUnitsList", mObjectGPSUnitsList);
        modelAndView.addObject("mObjectGPSUnitsListCount", mObjectGPSUnitsListCount);
        modelAndView.addObject("pageNumber", pageNumber);
        modelAndView.addObject("pageCount", pageCount);
        modelAndView.addObject("pagination", pagination);
        modelAndView.addObject("paginationUrl", URL_ADMIN_TRACKERS_LIST + "?page=");
        modelAndView.addObject("url_pattern", URL_ADMIN_TRACKERS_LIST);
        modelAndView.addObject("gpsTypeConnection", gpsTypeConnection);
        modelAndView.addObject("txtSearch", txtSearch);

        session.setAttribute(SESSION_ADMIN_TRACKERS_GPS_TYPE_CONNECTION, gpsTypeConnection);
        session.setAttribute(SESSION_ADMIN_TRACKERS_TEXT_SEARCH, txtSearch);

        return modelAndView;
    }

    /**
     * manage trackers from Admin user
     *
     * @param cmd             like "save" and "update" to edit tracker unit.
     * @param trackersId
     * @param rTrackersIdList
     * @param gpsUnitName
     * @param gpsUnitLogin
     * @param gpsUnitPassword
     * @param gpsUnitTypeId
     * @param gpsUnitImei
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ADMIN_TRACKERS_MANAGE)
    public ModelAndView processAdminTrackersManage(@RequestParam(value = "cmd", required = false) String cmd,
                                                   @RequestParam(value = "id", required = false) Long trackersId,
                                                   @RequestParam(value = "r-id[]", required = false) Long[] rTrackersIdList,
                                                   @RequestParam(value = "gps-unit-name", required = false) String gpsUnitName,
                                                   @RequestParam(value = "gps-unit-l", required = false) String gpsUnitLogin,
                                                   @RequestParam(value = "gps-unit-p", required = false) String gpsUnitPassword,
                                                   @RequestParam(value = "gps-unit-type-id", required = false) Long gpsUnitTypeId,
                                                   @RequestParam(value = "gps-unit-imei", required = false) String gpsUnitImei) {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminTrackersManage cmd={},id={}, r-id={}, gps-unit-name={}, gps-unit-login={}, gps-unit-password={}, gps-unit-type-id={}, gps-unit-imei={}",
                    cmd, trackersId, rTrackersIdList, gpsUnitName, gpsUnitLogin, gpsUnitPassword, gpsUnitTypeId, gpsUnitImei);
        }

        ModelAndView modelAndView = null;

        if (cmd != null) {
            // Add new tracker
            if (cmd.equalsIgnoreCase("save")) {
                if (!gpsUnitName.equalsIgnoreCase("") && !gpsUnitImei.equalsIgnoreCase("") && !gpsUnitLogin.equalsIgnoreCase("") && !gpsUnitPassword.equalsIgnoreCase("")) {

                    // Check imei for duplicate
                    gpsUnitImei = gpsUnitImei.trim();

                    GPSUnit gpsUnitByImei = adminService.getGPSUniteByIMEI(gpsUnitImei);

                    logger.error("gpsUnitImei=" + gpsUnitImei);
                    logger.error("gpsUnitByImei=" + gpsUnitByImei);

                    if (gpsUnitByImei == null) {
                        // imei not exists

                        GPSUnitType gpsUnitType = adminService.getGPSUniteTypeById(gpsUnitTypeId);
                        GPSUnit gpsUnit = new GPSUnit();
                        gpsUnit.setGpsUnitType(gpsUnitType);
                        gpsUnit.setName(gpsUnitName);
                        gpsUnit.setGpsUnitLogin(gpsUnitLogin);
                        gpsUnit.setGpsUnitPassword(gpsUnitPassword);
                        gpsUnit.setImei(gpsUnitImei.trim());
                        gpsUnit.setBlock(UZGPS_CONST.STATUS_BLOCK);
                        gpsUnit.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        gpsUnit.setRegDate(new Timestamp(System.currentTimeMillis()));
                        gpsUnit.setIsMobile(0);
                        adminService.saveGPSUnit(gpsUnit);

                        // Change mObject name too
                        changeMobjectNameByGpsUnit(gpsUnit);

                        // Check limit for trackers
                        checkTrackerCount();

                        // Update core Cloud A.1.1.1.
                        // coreMain.updateMobjectBigByUnitId(gpsUnit.getId());
                        // Update core Cloud : GpsUnitBig and Mobject must be updated
                        coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                        coreMain.coreUpdater.updateMobjectBigByUnitId(gpsUnit.getId());
                    }
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_TRACKERS_LIST);
            } else if (cmd.equalsIgnoreCase("update")) {
                if (!gpsUnitName.equalsIgnoreCase("") && !gpsUnitImei.equalsIgnoreCase("") && !gpsUnitLogin.equalsIgnoreCase("") && !gpsUnitPassword.equalsIgnoreCase("")) {
                    GPSUnitType gpsUnitType = adminService.getGPSUniteTypeById(gpsUnitTypeId);
                    GPSUnit gpsUnit = adminService.getGPSUniteById(trackersId);

                    gpsUnit.setGpsUnitType(gpsUnitType);
                    gpsUnit.setName(gpsUnitName);
                    gpsUnit.setGpsUnitLogin(gpsUnitLogin);
                    gpsUnit.setGpsUnitPassword(gpsUnitPassword);

                    gpsUnit.setImei(gpsUnitImei.trim());
                    gpsUnit.setModDate(new Timestamp(System.currentTimeMillis()));
                    adminService.saveGPSUnit(gpsUnit);

                    // Change mObject name too
                    changeMobjectNameByGpsUnit(gpsUnit);

                    // Check limit for trackers
                    checkTrackerCount();

                    // Update core Cloud : GpsUnitBig and Mobject must be updated
                    coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    coreMain.coreUpdater.updateMobjectBigByUnitId(gpsUnit.getId());
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_TRACKERS_LIST);
            } else if (cmd.equalsIgnoreCase("edit")) {
                modelAndView = new ModelAndView(VIEW_ADMIN_TRACKERS_MANAGE);
                List<GPSUnitType> gpsUnitTypeList = adminService.getGPSUniteTypeAllByStatus(UZGPS_CONST.STATUS_ACTIVE);
                GPSUnit gpsUnit = adminService.getGPSUniteById(trackersId);
                modelAndView.addObject("gpsUnit", gpsUnit);
                modelAndView.addObject("cmd", "update");
                modelAndView.addObject("gpsUnitTypeList", gpsUnitTypeList);
                modelAndView.addObject("url_pattern", URL_ADMIN_TRACKERS_LIST);

            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rTrackersId : rTrackersIdList) {
                    // Delete tracker
                    GPSUnit gpsUnit = adminService.getGPSUniteById(rTrackersId);
                    gpsUnit.setExpDate(new Timestamp(System.currentTimeMillis()));
                    gpsUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                    adminService.saveGPSUnit(gpsUnit);

                    // take list of connections of Mobject and GpsUnit. then delete them
                    List<MObjectGPSUnit> list = adminService.getMObjectGPSUnitByUnitId(rTrackersId);

                    if (list != null) {
                        for (MObjectGPSUnit mObjectGPSUnit : list) {
                            if (mObjectGPSUnit != null) {
                                mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                                mObjectGPSUnit.setExpDate(new Timestamp(System.currentTimeMillis()));
                                adminService.saveMObjectGPSUnit(mObjectGPSUnit);

                                // take mobject and delete it too
                                MObject mObject = mObjectGPSUnit.getmObject();
                                if (mObject != null) {
                                    mObject.setExpDate(new Timestamp(System.currentTimeMillis()));
                                    mObject.setStatus(UZGPS_CONST.STATUS_DELETE);
                                    adminService.saveMObject(mObject);

                                    // Update Core
                                    coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                                    coreMain.coreUpdater.updateUserMobjectAccessByMobjectId(mObject.getId());
                                }
                            }
                        }
                    }


                    // Update core Cloud : GpsUnitBig and Mobject must be updated
                    coreMain.coreUpdater.updateMobjectBigByUnitId(rTrackersId);
                    coreMain.coreUpdater.updateGpsUnit(rTrackersId);
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_TRACKERS_LIST);
            }

        } else {
            modelAndView = new ModelAndView(VIEW_ADMIN_TRACKERS_MANAGE);

            List<GPSUnitType> gpsUnitTypeList = adminService.getGPSUniteTypeAllByStatus(UZGPS_CONST.STATUS_ACTIVE);
            modelAndView.addObject("gpsUnitTypeList", gpsUnitTypeList);
            modelAndView.addObject("cmd", "save");
            modelAndView.addObject("url_pattern", URL_ADMIN_TRACKERS_LIST);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_TRACKERS_TYPE_LIST)
    public ModelAndView processAdminTrackersType() {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_TRACKERS_TYPE_LIST);
        List<GPSUnitType> gpsUnitTypeList = adminService.getGPSUniteTypeAllByStatus(UZGPS_CONST.STATUS_ACTIVE);
        modelAndView.addObject("gpsUnitTypeList", gpsUnitTypeList);
        modelAndView.addObject("url_pattern", URL_ADMIN_TRACKERS_LIST);

        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_TRACKERS_TYPE_MANAGE)
    public ModelAndView processAdminTrackersTypeManage(@RequestParam(value = "cmd", required = false) String cmd,
                                                       @RequestParam(value = "id", required = false) Long trackersTypeId,
                                                       @RequestParam(value = "r-id[]", required = false) Long[] rTrackersTypeIdList,
                                                       @RequestParam(value = "name", required = false) String name)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminTrackersTypeManage cmd={},id={}, r-id={}, name={}",
                    cmd, trackersTypeId, rTrackersTypeIdList, name);
        }

        ModelAndView modelAndView = null;
        boolean hasparam = false;

        if (cmd != null) {
            if (cmd.equalsIgnoreCase("save")) {
                if (!name.equalsIgnoreCase("")) {
                    GPSUnitType gpsUnitType = new GPSUnitType();
                    gpsUnitType.setName(name);
                    gpsUnitType.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                    gpsUnitType.setRegDate(new Timestamp(System.currentTimeMillis()));
                    adminService.saveGPSUniteType(gpsUnitType);
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_TRACKERS_TYPE_LIST);
            } else if (cmd.equalsIgnoreCase("update")) {
                if (!name.equalsIgnoreCase("")) {
                    GPSUnitType gpsUnitType = adminService.getGPSUniteTypeById(trackersTypeId);
                    gpsUnitType.setName(name);
                    gpsUnitType.setModDate(new Timestamp(System.currentTimeMillis()));
                    adminService.saveGPSUniteType(gpsUnitType);
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_TRACKERS_TYPE_LIST);
            } else if (cmd.equalsIgnoreCase("edit")) {
                modelAndView = new ModelAndView(VIEW_ADMIN_TRACKERS_TYPE_MANAGE);
                GPSUnitType gpsUnitType = adminService.getGPSUniteTypeById(trackersTypeId);
                modelAndView.addObject("gpsUnitType", gpsUnitType);
                modelAndView.addObject("cmd", "update");
                hasparam = true;
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rTrackersTypeId : rTrackersTypeIdList) {
                    GPSUnitType gpsUnitType = adminService.getGPSUniteTypeById(rTrackersTypeId);
                    gpsUnitType.setExpDate(new Timestamp(System.currentTimeMillis()));
                    gpsUnitType.setStatus(UZGPS_CONST.STATUS_DELETE);
                    adminService.saveGPSUniteType(gpsUnitType);
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_TRACKERS_TYPE_LIST);
            }

        } else {
            modelAndView = new ModelAndView(VIEW_ADMIN_TRACKERS_TYPE_MANAGE);
            modelAndView.addObject("cmd", "save");
        }

        if (hasparam) modelAndView.addObject("url_pattern", URL_ADMIN_TRACKERS_LIST);

        return modelAndView;
    }

    private void checkTrackerCount() {
        Integer mObjectGPSUnitsListCount = adminService.getGPSUniteAllByStatusCount(UZGPS_CONST.STATUS_ACTIVE, 2, "");
        if (mObjectGPSUnitsListCount != null) {
            if (mObjectGPSUnitsListCount < UZGPS_CONST.TRACKER_MIN_LIMIT) {
                adminJournal.log(
                        UZGPS_CONST.JOURNAL_NOTIFICATION,
                        UZGPS_CONST.JOURNAL_NOTIFICATION_TRACKER_LIMIT,
                        UZGPS_CONST.JOURNAL_NOTIFICATION,
                        "");
            }
        }
    }

    private void changeMobjectNameByGpsUnit(GPSUnit gpsUnit) {
        if (gpsUnit != null) {
            List<MObjectGPSUnit> mObjectGPSUnitList = adminService.getMObjectGPSUnitByUnitId(gpsUnit.getId());
            if (mObjectGPSUnitList != null) {
                for (MObjectGPSUnit mObjectGPSUnit : mObjectGPSUnitList) {
                    if (mObjectGPSUnit != null &&
                            mObjectGPSUnit.getStatus() != null &&
                            mObjectGPSUnit.getStatus().equals(UZGPS_CONST.STATUS_ACTIVE)) {
                        MObject mObject = mObjectGPSUnit.getmObject();
                        if (mObject != null) {
                            mObject.setmObjectName(gpsUnit.getName());
                            adminService.saveMObject(mObject);
                        }
                    }
                }
            }
        }
    }


    private List<Integer> getPages(Integer currentPage, Integer maxPages) {
        List<Integer> list = new ArrayList<>();
        if (currentPage != null && maxPages != null) {
            if (maxPages > 0) list.add(0); // 1 page
            if (maxPages > 1) list.add(1); // 2 page
            if (maxPages > 2) list.add(2); // 3 page

            if (currentPage > 1) {
                if (!list.contains(currentPage - 1) && (currentPage - 1 < maxPages))
                    list.add(currentPage - 1); // current - 1

                if (!list.contains(currentPage) && (currentPage < maxPages))
                    list.add(currentPage); // current

                if (!list.contains(currentPage + 1) && (currentPage + 1 < maxPages))
                    list.add(currentPage + 1); // current + 1
            }

            if (!list.contains(maxPages - 3) && (maxPages - 3 > 0)) list.add(maxPages - 3); // last-2 page
            if (!list.contains(maxPages - 2) && (maxPages - 3 > 0)) list.add(maxPages - 2); // last-1 page
            if (!list.contains(maxPages - 1) && (maxPages - 3 > 0)) list.add(maxPages - 1); // last page

            Collections.sort(list);

        }
        return list;
    }
}
