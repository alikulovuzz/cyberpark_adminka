package uzgps.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uzgps.common.RoleInfo;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.RoleConfiguration;
import uzgps.persistence.Profile;
import uzgps.persistence.Role;
import uzgps.persistence.User;
import uzgps.persistence.UserRole;
import uzgps.security.MD5;

import javax.servlet.ServletException;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class AdminManagerController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ADMIN_MANAGERS_LIST = "/admin/managers-list.htm";
    private final static String VIEW_ADMIN_MANAGERS_LIST = "admin/managers-list";
    private final static String URL_ADMIN_MANAGERS_MANAGE = "/admin/managers-manage.htm";
    private final static String VIEW_ADMIN_MANAGERS_MANAGE = "admin/managers-manage";

    @Autowired
    private AdminService adminService;

    @Autowired
    private AppConfiguration appConfiguration;

    @RequestMapping(value = URL_ADMIN_MANAGERS_LIST)
    public ModelAndView processAdminManagersList() {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MANAGERS_LIST);
        List<User> managerList = adminService.getCustomerCareAllByStatus(UZGPS_CONST.USER_STATUS_ACTIVE);
        modelAndView.addObject("managerList", managerList);
        modelAndView.addObject("url_pattern", URL_ADMIN_MANAGERS_LIST);

        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_MANAGERS_MANAGE)
    public ModelAndView processAdminManagersManage(@RequestParam(value = "cmd", required = false) String cmd,
                                                   @RequestParam(value = "user-id", required = false) Long managerId,
                                                   @RequestParam(value = "r-user-id[]", required = false) Long[] rManagerIdList,
                                                   @RequestParam(value = "manager-l", required = false) String login,
                                                   @RequestParam(value = "manager-p", required = false) String password,
                                                   @RequestParam(value = "surname", required = false) String surname,
                                                   @RequestParam(value = "name", required = false) String name,
                                                   @RequestParam(value = "middle-name", required = false) String middleName,
                                                   @RequestParam(value = "position", required = false) String position,
                                                   @RequestParam(value = "mobile-phone", required = false) String mobilePhone,
                                                   @RequestParam(value = "line-phone", required = false) String linePhone,
                                                   @RequestParam(value = "email", required = false) String email)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminManagersManage cmd={}, manager-id={}, login={}, password={} surname={}, name={}, middle-name={}, position={}, mobile-phone={}, line-phone={}, email={}, r-manager-id[]={}",
                    cmd, managerId, login, password, surname, name, middleName, position, mobilePhone, linePhone, email, rManagerIdList);
        }

        ModelAndView modelAndView = null;


        if (cmd != null) {
            if (cmd.equalsIgnoreCase("save")) {

                if ( // !surname.equalsIgnoreCase("") &&
                    // !middleName.equalsIgnoreCase("") &&
                        !name.equalsIgnoreCase("") &&
                                !login.equalsIgnoreCase("") &&
                                !password.equalsIgnoreCase("")) {

                    login = login.trim().toLowerCase();
                    User user = adminService.getUserByLogin(login);
                    if (user != null && user.getId() != null) {
                        modelAndView = new ModelAndView(VIEW_ADMIN_MANAGERS_MANAGE);
                        User manager = new User();
                        Profile profile = new Profile();
                        manager.setName(name);
                        manager.setSurName(surname);
                        manager.setMiddleName(middleName);
                        profile.setPosition(position);
                        profile.setMobilePhone(mobilePhone);
                        profile.setLinePhone(linePhone);
                        profile.setEmail(email);
                        manager.setProfile(profile);
                        modelAndView.addObject("manager", manager);
                        modelAndView.addObject("cmd", "save");
                        modelAndView.addObject("error_txt", "Такой Login существует в базе!");
                    } else {
                        Profile profile = new Profile();
                        profile.setPosition(position);
                        profile.setEmail(email);
                        profile.setLinePhone(linePhone);
                        profile.setMobilePhone(mobilePhone);
                        adminService.saveProfile(profile);

                        User manager = new User();
                        manager.setManagerId(1L);
//                        manager.setUserTypeId(UZGPS_CONST.USER_TYPE_OPERATOR);
                        Role role = adminService.getRoleById(UZGPS_CONST.USER_ROLE_CUSTOMER_CARE);
                        manager.setRole(role);
                        manager.setLogin(login);

                        MD5 md5 = new MD5();
                        password = md5.getMD5(password.trim());

                        manager.setPassword(password);
                        manager.setSurName(surname);
                        manager.setName(name);
                        manager.setMiddleName(middleName);
                        manager.setProfile(profile);
                        manager.setBlock(UZGPS_CONST.USER_BLOCK_STATUS_UNBLOCK);
                        manager.setStatus(UZGPS_CONST.USER_STATUS_ACTIVE);
                        manager.setRegDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveUser(manager);

                        // Update Core for User info


                        UserRole userRole = new UserRole();
                        userRole.setUser(manager);

                        RoleConfiguration roleConfiguration = appConfiguration.getRoleConfiguration();
                        RoleInfo[] roleInfos = roleConfiguration.getRoleInfo();

                        for (RoleInfo roleInfo : roleInfos) {
                            if (roleInfo.getName().equalsIgnoreCase("Operator")) {
                                userRole.setRoleId((long) roleInfo.getId());
                            }
                        }

                        adminService.saveUseRole(userRole);
                        modelAndView = new ModelAndView("redirect:" + URL_ADMIN_MANAGERS_LIST);
                    }

                } else {
                    modelAndView = new ModelAndView("redirect:" + URL_ADMIN_MANAGERS_LIST);
                }

            } else if (cmd.equalsIgnoreCase("update")) {
                if (!surname.equalsIgnoreCase("") && !name.equalsIgnoreCase("") && !middleName.equalsIgnoreCase("") && !login.equalsIgnoreCase("")) {
                    User manager = adminService.getCustomerCareById(managerId);
                    manager.setId(managerId);
                    manager.setLogin(login.trim().toLowerCase());
                    if (!password.equalsIgnoreCase("") && password.length() > 4) {
                        MD5 md5 = new MD5();
                        password = md5.getMD5(password.trim());
                        manager.setPassword(password);
                    }
                    manager.setSurName(surname);
                    manager.setName(name);
                    manager.setMiddleName(middleName);
                    manager.getProfile().setPosition(position);
                    manager.getProfile().setMobilePhone(mobilePhone);
                    manager.getProfile().setLinePhone(linePhone);
                    manager.getProfile().setEmail(email);
                    manager.setModDate(new Timestamp(System.currentTimeMillis()));
                    adminService.saveUser(manager);
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_MANAGERS_LIST);
            } else if (cmd.equalsIgnoreCase("edit")) {
                modelAndView = new ModelAndView(VIEW_ADMIN_MANAGERS_MANAGE);
                User user = adminService.getCustomerCareById(managerId);
                user.setPassword("");
                modelAndView.addObject("manager", user);
                modelAndView.addObject("cmd", "update");
                modelAndView.addObject("url_pattern", URL_ADMIN_MANAGERS_LIST);
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rManagerId : rManagerIdList) {
                    User manager = adminService.getCustomerCareById(rManagerId);
                    manager.setId(rManagerId);
                    manager.setExpDate(new Timestamp(System.currentTimeMillis()));
                    manager.setStatus(UZGPS_CONST.USER_STATUS_DELETE);
                    adminService.saveUser(manager);
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_MANAGERS_LIST);
            }

        } else {
            modelAndView = new ModelAndView(VIEW_ADMIN_MANAGERS_MANAGE);
            modelAndView.addObject("cmd", "save");
            modelAndView.addObject("url_pattern", URL_ADMIN_MANAGERS_LIST);
        }

        return modelAndView;
    }

}
