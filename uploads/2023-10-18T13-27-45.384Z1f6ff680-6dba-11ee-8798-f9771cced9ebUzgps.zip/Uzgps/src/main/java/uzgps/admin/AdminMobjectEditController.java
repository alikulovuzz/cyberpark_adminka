package uzgps.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.common.Errors;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreDatchikDigital;
import uz.netex.datatype.DatchikDigital;
import uz.netex.fuelcontrol.common.Calculator;
import uz.netex.fuelcontrol.common.Constants;
import uz.netex.fuelcontrol.core.CoreFuelControl;
import uz.netex.fuelcontrol.database.tables.CanDatchik;
import uz.netex.fuelcontrol.database.tables.FuelDatchik;
import uz.netex.fuelcontrol.database.tables.FuelNorm;
import uzgps.common.Error;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.persistence.*;
import uzgps.report.helper.database.tables.TpLastTime;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static uzgps.common.UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN_STR;

/**
 * Created by G'ayrat on 27.03.15.
 */
@Controller
public class AdminMobjectEditController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ADMIN_MOBJECT_EDIT_TABS = "/admin/mobject-edit-tabs.htm";
    private final static String VIEW_ADMIN_MOBJECT_EDIT_TABS = "admin/mobject-edit-tabs";

    private final static String URL_ADMIN_MOBJECT_EDIT_MAIN = "/admin/mobject-edit-main.htm";
    private final static String VIEW_ADMIN_MOBJECT_EDIT_MAIN = "admin/mobject-edit-main";

    private final static String URL_ADMIN_MOBJECT_EDIT_DATCHIK = "/admin/mobject-edit-datchik.htm";
    private final static String VIEW_ADMIN_MOBJECT_EDIT_DATCHIK = "admin/mobject-edit-datchik";

    private final static String URL_ADMIN_MOBJECT_EDIT_DUT = "/admin/mobject-edit-dut.htm";
    private final static String VIEW_ADMIN_MOBJECT_EDIT_DUT = "admin/mobject-edit-dut";

    private final static String URL_ADMIN_MOBJECT_EDIT_NORM = "/admin/mobject-edit-norm.htm";
    private final static String VIEW_ADMIN_MOBJECT_EDIT_NORM = "admin/mobject-edit-norm";

    private final static String URL_ADMIN_MOBJECT_EDIT_CAN = "/admin/mobject-edit-can.htm";
    private final static String VIEW_ADMIN_MOBJECT_EDIT_CAN = "admin/mobject-edit-can";

    private final static String URL_ADMIN_MOBJECT_EDIT_REPORT_PARAMS = "/admin/mobject-edit-report-params.htm";
    private final static String VIEW_ADMIN_MOBJECT_EDIT_REPORT_PARAMS = "admin/mobject-edit-report-params";

    private final static String URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST = "/admin/customers-trackers-relationship-list.htm";

    private final static String URL_ADMIN_MOBJECT_EDIT_DUT_REMOVE_REPORT = "/admin/mobject-edit-dut-remove-report.htm";
    private final static String URL_ADMIN_MOBJECT_EDIT_NORM_REMOVE_REPORT = "/admin/mobject-edit-norm-remove-report.htm";
    private final static String URL_ADMIN_MOBJECT_EDIT_CAN_REMOVE_REPORT = "/admin/mobject-edit-can-remove-report.htm";

    private final static String URL_AMIN_MOBJECT_EDIT_REMOVE_REPORT = "/admin/mobject-edit-report.htm";
    private final static String VIEW_AMIN_MOBJECT_EDIT_REMOVE_REPORT = "admin/mobject-edit-report";

    private final static int TAB_MAIN = 0;
    private final static int TAB_FUEL_DATCHIK = 1;
    private final static int TAB_FUEL_DUT = 5;
    private final static int TAB_FUEL_NORM = 2;
    private final static int TAB_CAN = 3;
    private final static int TAB_REPORT = 4;
    private final static int TAB_REMOVE_REPORT = 6;

    /**
     * Number of symbols in phone number.
     * 18 = +998 (95) 123-4567
     */
    private final static int SIM_PHONE_LENGTH = 18;

    private final static String CMD_SAVE = "save";
    private final static String CMD_EDIT = "edit";
    private final static String CMD_REMOVE = "remove";
    private final static String CMD_STATUS = "status";

    @Autowired
    private AdminService adminService;

    @Autowired
    private SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @Autowired
    private AdminReportService adminReportService;

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_TABS)
    public ModelAndView mobjectEditTabs(HttpSession session) throws ServletException, ParseException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_TABS);

        return modelAndView;
    }

    /**
     * This function makes MObjectGpsUnit and edit MObjectGpsUnit
     *
     * @param session
     * @param cmd                 "save" new object, "edit" update object
     * @param mobjectGpsUnitIdStr mobjectGpsUnitId in String format
     * @param contractIdStr       contractId in String format
     * @return
     * @throws ServletException
     * @throws IOException
     * @throws ParseException
     */
    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_MAIN)
    public ModelAndView mObjectEditMain(HttpSession session,
                                        @RequestParam(value = "cmd", required = false) String cmd,
                                        @RequestParam(value = "id", required = false) String mobjectGpsUnitIdStr,
                                        @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                        @RequestParam(value = "gps-unit-id", required = false) String gpsUnitIdStr,
                                        @RequestParam(value = "r-id[]", required = false) Long[] rId,
                                        @RequestParam(value = "mobject-id", required = false) String mobjectIdStr,
                                        @RequestParam(value = "gps-unit-name", required = false) String gpsUnitName,
                                        @RequestParam(value = "sim-phone", required = false) String simPhone,
                                        @RequestParam(value = "vehicle-brand", required = false) String vehicleBrand,
                                        @RequestParam(value = "car-number", required = false) String carNumber,
                                        @RequestParam(value = "gps-unit-login", required = false) String gpsUnitLogin,
                                        @RequestParam(value = "gps-unit-pass", required = false) String gpsUnitPass,
                                        @RequestParam(value = "status", required = false) String status)
            throws ServletException, IOException, ParseException {

        // get params and convert type
        Long mobjectGpsUnitId = strToLong(mobjectGpsUnitIdStr, null);
        Long contractId = strToLong(contractIdStr, null);
        Long gpsUnitId = strToLong(gpsUnitIdStr, null);
        Long mObjectId = strToLong(mobjectIdStr, null);


        // if contract not selected, redirect to contracts list
        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_LIST);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_MAIN);

        // Check CMD action
        if (cmd != null) {
            // If GPS Unit not selected, show error
            if (gpsUnitId == null) {
                modelAndView.addObject("errorGpsUnitId", Error.ERR_TRACKER_IS_NOT_FOUND);
            }

            if (cmd.equals(CMD_SAVE) && gpsUnitId != null) {
                // Save new object
                int errorCode = MobjectMainSave(modelAndView, contractId, gpsUnitId, simPhone,
                        gpsUnitName, vehicleBrand, carNumber, gpsUnitLogin, gpsUnitPass);
                if (errorCode == Error.ERR_SUCCESS) {
                    return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId);
                }
            } else if (cmd.equals(CMD_EDIT) && gpsUnitId != null) {
                // Edit current object
                Long mobjectGpsUnitIdEdited = MobjectMainEdit(modelAndView, contractId, gpsUnitId, simPhone,
                        gpsUnitName, vehicleBrand, carNumber, gpsUnitLogin, gpsUnitPass, mobjectGpsUnitId, status);
                if (mobjectGpsUnitIdEdited != null) {
                    return new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_MAIN + "?contract-id=" + contractId + "&cmd=edit&id=" + mobjectGpsUnitIdEdited);
                }
            } else if (cmd.equals(CMD_REMOVE)) {
                int errorCode = MobjectMainRemove(modelAndView, rId, contractId);
                if (errorCode == Error.ERR_SUCCESS) {
                    return new ModelAndView("redirect:" + URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId);
                }
            } else if (cmd.equals(CMD_STATUS)) {
                int errorCode = MobjectMaintatus(gpsUnitId, status);
                if (errorCode == Error.ERR_SUCCESS) {
                    return new ModelAndView("redirect:" + URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId);
                }
            }
        }

        // Get list of Trackers which is not connected
        List<GPSUnit> gpsUnitList = adminService.getGPSUniteAllFreeByStatus(UZGPS_CONST.STATUS_ACTIVE, "");

        // If mobject ID exists, send to view
        if (mobjectGpsUnitId != null) {

            MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitById(mobjectGpsUnitId);
            if (mObjectGPSUnit != null && mObjectGPSUnit.getGpsUnit() != null && mObjectGPSUnit.getGpsUnit().getImei() != null) {
                gpsUnitList = adminService.getGPSUniteAllFreeByStatus(UZGPS_CONST.STATUS_ACTIVE, mObjectGPSUnit.getGpsUnit().getImei());
                modelAndView.addObject("mObjectGPSUnit", mObjectGPSUnit);
                modelAndView.addObject("mobjectId", mObjectGPSUnit.getmObjectId());
            }

            modelAndView.addObject("mObjectGPSUnitId", mobjectGpsUnitId);
            modelAndView.addObject("cmd", CMD_EDIT);
        } else {
            modelAndView.addObject("cmd", CMD_SAVE);

            //            // If we are adding new Mobject, give default name
            //            if (gpsUnitList != null && gpsUnitList.size() > 0)
            //                modelAndView.addObject("mObjectName", gpsUnitList.get(0).getName());
        }

        modelAndView.addObject("gpsUnitList", gpsUnitList);
        modelAndView.addObject("gpsUnitListSize", (gpsUnitList != null) ? gpsUnitList.size() : 0);

        // Set tab ID
        modelAndView.addObject("menuActive", TAB_MAIN);
        modelAndView.addObject("contractId", contractId);
        if (mObjectId != null) {
            modelAndView.addObject("mobjectId", mObjectId);
        }
        return modelAndView;


    }

    /**
     * Makes new Mobject for this contract
     *
     * @param modelAndView what to show in screen
     * @param contractId   contract id
     * @param gpsUnitId    Tracker id
     * @param simPhone     phone number
     * @param gpsUnitName  name of object
     * @param vehicleBrand marka
     * @param carNumber    gos nomer
     * @param gpsUnitLogin sms command login
     * @param gpsUnitPass  sms command pass
     * @return in all saved, returnes {@link uzgps.common.Error#ERR_SUCCESS}
     */
    private int MobjectMainSave(ModelAndView modelAndView, Long contractId, Long gpsUnitId, String simPhone,
                                String gpsUnitName, String vehicleBrand, String carNumber,
                                String gpsUnitLogin, String gpsUnitPass) {
        int errorCode = Error.ERR_SUCCESS;
        MObjectGPSUnit mobjectGpsUnit = null;
        GPSUnit gpsUnit = null;
        GPSUnitSim gpsUnitSim = null;
        Sim sim = null;

        // If GPS Unit not selected, show error
        if (gpsUnitId == null) {
            modelAndView.addObject("errorGpsUnitId", Error.ERR_TRACKER_IS_NOT_FOUND);
            errorCode = Error.ERR_TRACKER_IS_NOT_FOUND;
        }

        // Check and Get MObjectGPSUnit by gpsUnitId
        if (errorCode == Error.ERR_SUCCESS) {
            gpsUnit = adminService.getGPSUniteById(gpsUnitId);

            // If GPS Unit not selected, show error
            if (gpsUnitId == null) {
                modelAndView.addObject("errorGpsUnitId", Error.ERR_TRACKER_IS_NOT_FOUND);
                errorCode = Error.ERR_TRACKER_IS_NOT_FOUND;
            } else {
                // Get Mobject connected to this tracker (gpsUnit)
                List<MObjectGPSUnit> mObjectGPSUnitList = adminService.getMObjectGPSUnitByUnitId(gpsUnit.getId());

                // Check if MobjectGpsUnit exists
                if (mObjectGPSUnitList != null && mObjectGPSUnitList.size() > 0) {
                    // There are several connections to this tracker. check it
                    errorCode = Error.ERR_MOBJECT_GPS_UNIT_EXISTS_MORE;
                    modelAndView.addObject("errorGpsUnitId", Error.ERR_MOBJECT_GPS_UNIT_EXISTS_MORE);
                }
            }
        }

        // Check sim number
        if (errorCode == Error.ERR_SUCCESS) {
            // Check if Sim number entered
            if (simPhone == null) {
                modelAndView.addObject("errorSimPhone", Error.ERR_OBJECT_IS_NULL);
                errorCode = Error.ERR_OBJECT_IS_NULL;
            }

            // Check Sim object from DB
            int errorSim = changeGpsUnitSim(simPhone, gpsUnit);
            if (errorSim != Error.ERR_SUCCESS) {
                modelAndView.addObject("errorSimPhone", errorSim);
                return errorSim;
            }


            if (errorCode == Error.ERR_SUCCESS && gpsUnit != null) {

                Group group = adminService.getGroupById(0L);
                Contract contract = adminService.getContractById(contractId);

                gpsUnit.setName(gpsUnitName);
                gpsUnit.setGpsUnitPassword(gpsUnitPass);
                gpsUnit.setGpsUnitLogin(gpsUnitLogin);
                gpsUnit.setBlock(UZGPS_CONST.STATUS_UNBLOCK);
                adminService.saveGPSUnit(gpsUnit);

                // Make new object
                MObject mObject = new MObject();
                mObject.setGroup(group);
                mObject.setContract(contract);
                mObject.setmObjectName(gpsUnit.getName());
                mObject.setmObjectType(vehicleBrand);
                mObject.setmObjectPlateNumber(carNumber);
                mObject.setDefaultIcon(true);
                mObject.setRegDate(new Timestamp(System.currentTimeMillis()));
                mObject.setPinId(UZGPS_CONST.MAP_MOBJECT_ICON_CAR);
                mObject.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                adminService.saveMObject(mObject);

                // Default settings Settings
                makeMobjectSettings(mObject);

                // Default settings for Mobile
                makeMobileSettings(gpsUnit, mObject);

                // Default Notification settings
                MObjectNotifications mObjectNotifications = makeMobjectNotification(mObject.getId());

                MObjectGPSUnit mObjectGPSUnit = new MObjectGPSUnit();
                mObjectGPSUnit.setmObject(mObject);
                mObjectGPSUnit.setGpsUnit(gpsUnit);
                mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                mObjectGPSUnit.setRegDate(new Timestamp(System.currentTimeMillis()));
                mObjectGPSUnit.setMovementStatus((short) 1);
                mObjectGPSUnit.setEngineOnStatus((short) 1);
                mObjectGPSUnit.setDatStatus((short) 1);
                mObjectGPSUnit.setTimeMin(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_MIN);
                mObjectGPSUnit.setTimeBig(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_BIG);
                mObjectGPSUnit.setTimeLost(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_LOST);
                mObjectGPSUnit.setDistanceMin(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_DISTANCE_MIN);
                mObjectGPSUnit.setDistanceBig(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_DISTANCE_BIG);
                mObjectGPSUnit.setOnlineStatus((short) 1);
                mObjectGPSUnit.setSatellitesStatus((short) 1);
                adminService.saveMObjectGPSUnit(mObjectGPSUnit);


                // Save Mobject count for Contract
                contract = adminService.getContractById(contractId);
                contract.setExistUnitCount(adminService.getMobjectCountByContractId(contractId));
                adminService.saveContract(contract);

                // Update core Cloud : GpsUnitBig and Mobject must be updated
                coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                coreMain.coreUpdater.updateMobjectNotificationsById(mObjectNotifications.getId());


            }


        }


        return errorCode;
    }

    /**
     * @param modelAndView
     * @param contractId
     * @param gpsUnitId
     * @param simPhone
     * @param gpsUnitName
     * @param vehicleBrand
     * @param carNumber
     * @param gpsUnitLogin
     * @param gpsUnitPass
     * @param mobjectGpsUnitId
     * @return
     */
    private Long MobjectMainEdit(ModelAndView modelAndView, Long contractId, Long gpsUnitId, String simPhone,
                                 String gpsUnitName, String vehicleBrand, String carNumber,
                                 String gpsUnitLogin, String gpsUnitPass, Long mobjectGpsUnitId, String status) {
        int errorCode = Error.ERR_SUCCESS;
        MObjectGPSUnit mobjectGpsUnit = null;
        GPSUnit gpsUnit = null;
        GPSUnitSim gpsUnitSim = null;
        Sim sim = null;
        MObject mObject = null;
        Long mobjectGpsUnitIdEdited = mobjectGpsUnitId;


        // If mobjectGpsUnit not found, show error
        if (mobjectGpsUnitId == null) {
            modelAndView.addObject("errorMobjectGpsUnit", Error.ERR_MOBJECT_GPS_UNIT_NOT_EXISTS);
            return null;
        }

        mobjectGpsUnit = adminService.getMObjectGPSUnitById(mobjectGpsUnitId);
        Long mobjectId = null;
        Long unitId = null;

        // If mobjectGpsUnit not found, show error
        if (mobjectGpsUnit == null) {
            modelAndView.addObject("errorMobjectGpsUnit", Error.ERR_MOBJECT_GPS_UNIT_NOT_EXISTS);
            return null;
        }
        // get mobject id
        if (mobjectGpsUnit.getGpsUnit() != null) {
            mobjectId = mobjectGpsUnit.getmObject().getId();
        }
        // get tracker (gpsUnit) id
        if (mobjectGpsUnit.getGpsUnit() != null) {
            unitId = mobjectGpsUnit.getGpsUnit().getId();
        }
        // If mobject or GpsUnit not found, show error
        if (mobjectId == null || unitId == null) {
            modelAndView.addObject("errorMobjectGpsUnit", Error.ERR_MOBJECT_GPS_UNIT_NOT_EXISTS);
            return null;
        }

        gpsUnit = adminService.getGPSUniteById(gpsUnitId);
        // If GPS Unit not selected, show error
        if (gpsUnit == null) {
            modelAndView.addObject("errorGpsUnit", Error.ERR_TRACKER_IS_NOT_FOUND);
            return null;
        }


        // Check and Get MObjectGPSUnit by gpsUnitId
        if (errorCode == Error.ERR_SUCCESS) {

            // Check if GpsUnit changed
            if (mobjectGpsUnit.getGpsUnit().getId().equals(gpsUnitId)) {
                // Tracker not changed, do nothing
            } else {
                // Tracker changed, do something

                // delete all connections with this object
                adminService.deleteAllMobjectGPSUnitByUnitId(gpsUnitId);
                // Delete sim card connection too
                adminService.deleteAllGPSUnitSimByUnitId(gpsUnitId);
                // delete all connections with this object
                adminService.deleteAllMobjectGPSUnitByUnitId(unitId);
                // Delete sim card connection too
                adminService.deleteAllGPSUnitSimByUnitId(unitId);

                // connect object
                MObjectGPSUnit mobjectGpsUnitNew = new MObjectGPSUnit();
                mobjectGpsUnitNew.setmObject(mobjectGpsUnit.getmObject());
                gpsUnit.setBlock(UZGPS_CONST.STATUS_UNBLOCK);
                mobjectGpsUnitNew.setGpsUnit(gpsUnit);
                mobjectGpsUnitNew.setGpsUnitId(gpsUnitId);

                mobjectGpsUnitNew.setDistanceBig(mobjectGpsUnit.getDistanceBig());
                mobjectGpsUnitNew.setDistanceMin(mobjectGpsUnit.getDistanceMin());

                mobjectGpsUnitNew.setTimeBig(mobjectGpsUnit.getTimeBig());
                mobjectGpsUnitNew.setTimeMin(mobjectGpsUnit.getTimeMin());
                mobjectGpsUnitNew.setTimeLost(mobjectGpsUnit.getTimeLost());

                mobjectGpsUnitNew.setDatStatus(mobjectGpsUnit.getDatStatus());
                mobjectGpsUnitNew.setEngineOnStatus(mobjectGpsUnit.getEngineOnStatus());
                mobjectGpsUnitNew.setMovementStatus(mobjectGpsUnit.getMovementStatus());
                mobjectGpsUnitNew.setSatellitesStatus(mobjectGpsUnit.getSatellitesStatus());
                mobjectGpsUnitNew.setOnlineStatus(mobjectGpsUnit.getOnlineStatus());

                mobjectGpsUnitNew.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                mobjectGpsUnitNew.setRegDate(new Timestamp(System.currentTimeMillis()));
                adminService.saveMObjectGPSUnit(mobjectGpsUnitNew);
                mobjectGpsUnit = mobjectGpsUnitNew;
                mobjectGpsUnitIdEdited = mobjectGpsUnit.getId();
            }
        }

        // Check sim number
        // Check if Sim number entered
        if (simPhone == null) {
            modelAndView.addObject("errorSimPhone", Error.ERR_OBJECT_IS_NULL);
            errorCode = Error.ERR_OBJECT_IS_NULL;
            return null;
        }

        // Check Sim object from DB
        int errorSim = changeGpsUnitSim(simPhone, gpsUnit);
        if (errorSim != Error.ERR_SUCCESS) {
            modelAndView.addObject("errorSimPhone", errorSim);
            return null;
        }

        if (errorCode == Error.ERR_SUCCESS) {

            gpsUnit.setName(gpsUnitName);
            gpsUnit.setGpsUnitPassword(gpsUnitPass);
            gpsUnit.setGpsUnitLogin(gpsUnitLogin);
            adminService.saveGPSUnit(gpsUnit);

            // Make new object
            mObject = mobjectGpsUnit.getmObject();

            if (mObject == null) {
                modelAndView.addObject("errorMobject", Error.ERR_MOBJECT_IS_NULL);
                errorCode = Error.ERR_MOBJECT_IS_NULL;
                return null;
            }

            mObject.setmObjectName(gpsUnit.getName());
            mObject.setmObjectType(vehicleBrand);
            mObject.setmObjectPlateNumber(carNumber);
            adminService.saveMObject(mObject);
        }

        // Update core Cloud : GpsUnitBig and Mobject must be updated
        if (gpsUnit.getId() != null)
            coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
        if (mObject != null && mObject.getId() != null)
            coreMain.coreUpdater.updateMobjectBigById(mObject.getId());

        return mobjectGpsUnitIdEdited;
    }

    /**
     * @param modelAndView
     * @param rId
     * @param contractId
     * @return
     */
    private int MobjectMainRemove(ModelAndView modelAndView, Long[] rId, Long contractId) {

        int errorCode = Error.ERR_SUCCESS;

        for (Long rMObjectGPSUnitId : rId) {
            if (rMObjectGPSUnitId != null) {

                Timestamp modTime = new Timestamp(System.currentTimeMillis());

                MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitById(rMObjectGPSUnitId);

                // Delete MObject
                MObject mObject = mObjectGPSUnit.getmObject();
                if (mObject != null) {
                    mObject.setStatus(UZGPS_CONST.STATUS_DELETE);
                    mObject.setModDate(modTime);
                    adminService.saveMObject(mObject);
                }

                // Delete Gps Unit
                GPSUnit gpsUnit = mObjectGPSUnit.getGpsUnit();
                if (gpsUnit != null) {
                    gpsUnit.setBlock(UZGPS_CONST.STATUS_BLOCK);
                    adminService.saveGPSUnit(gpsUnit);

                    // Delete all Sim numbers connected to Gps Unit
                    adminService.deleteAllGPSUnitSimByUnitId(gpsUnit.getId());

                    // Delete all Mobject Gps Unit
                    adminService.deleteAllMobjectGPSUnitByUnitId(gpsUnit.getId());
                } else {
                    mObjectGPSUnit.setExpDate(modTime);
                    mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                    adminService.saveMObjectGPSUnit(mObjectGPSUnit);
                }


                // Update core Cloud
                if (gpsUnit != null)
                    coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                if (mObject != null)
                    coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
            }
        }

        // Save Mobject count
        Contract contract = adminService.getContractById(contractId);
        contract.setExistUnitCount(adminService.getMobjectCountByContractId(contractId));
        adminService.saveContract(contract);

        return errorCode;
    }

    private int MobjectMaintatus(Long gpsUnitId, String status) {

        int errorCode = Error.ERR_SUCCESS;
        GPSUnit gpsUnit = adminService.getGPSUniteById(gpsUnitId);

        if (status.equalsIgnoreCase("active")) gpsUnit.setBlock(UZGPS_CONST.STATUS_UNBLOCK);
        else gpsUnit.setBlock(UZGPS_CONST.STATUS_BLOCK);

        gpsUnit.setModDate(new Timestamp(System.currentTimeMillis()));
        adminService.saveGPSUnit(gpsUnit);

        // Update core Cloud
        coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
        coreMain.coreUpdater.updateMobjectBigByUnitId(gpsUnit.getId());

        return errorCode;
    }

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_DATCHIK)
    public ModelAndView mobjectEditDatchik(HttpSession session,
                                           @RequestParam(value = "id", required = false) String mobjectIdStr,
                                           @RequestParam(value = "cmd", required = false) String cmd,
                                           @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                           @RequestParam(value = "cb-ignition-sensor", required = false, defaultValue = "0") String cbIgnitionSensor,
                                           @RequestParam(value = "cb-button-sos", required = false, defaultValue = "0") String cbButtonSos,
                                           @RequestParam(value = "cb-audio-call", required = false, defaultValue = "0") String cbAudioCall,
                                           @RequestParam(value = "cb-doors-sensor", required = false, defaultValue = "0") String cbDoorsSensor,
                                           @RequestParam(value = "rb-di1", required = false) String rbDi1,
                                           @RequestParam(value = "rb-di2", required = false) String rbDi2,
                                           @RequestParam(value = "rb-di3", required = false) String rbDi3,
                                           @RequestParam(value = "rb-di4", required = false) String rbDi4
    ) throws ServletException, ParseException, IOException {

        // get params and convert type
        Long mobjectId = strToLong(mobjectIdStr, null);
        Long contractId = strToLong(contractIdStr, null);
        // if contract not selected, redirect to contracts list
        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_LIST);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_DATCHIK);

        // Connect to CoreDatchikDigital
        CoreDatchikDigital coreDatchikDigital = CoreDatchikDigital.getInstance();

        // get datchikDigital by mobject id
        DatchikDigital datchikDigital = coreDatchikDigital.getByMobjectId(mobjectId);

        // If settings not exists, take by default
        if (datchikDigital == null) datchikDigital = new DatchikDigital();

        // if (cmd != null && checkUserId(id, contractId)) {
        if (cmd != null) {
            if (cmd.equalsIgnoreCase("save")) {
                datchikDigital.setMobjectId(mobjectId);

                datchikDigital.setUseIgnitionSensor(strToInt(cbIgnitionSensor, datchikDigital.getUseIgnitionSensor()));
                datchikDigital.setUseButtonSos(strToInt(cbButtonSos, datchikDigital.getUseButtonSos()));
                datchikDigital.setUseDoorsSensor(strToInt(cbDoorsSensor, datchikDigital.getUseDoorsSensor()));
                datchikDigital.setUseAudioCall(strToInt(cbAudioCall, datchikDigital.getUseAudioCall()));

                datchikDigital.setDigitalInput1(strToInt(rbDi1, datchikDigital.getDigitalInput1()));
                datchikDigital.setDigitalInput2(strToInt(rbDi2, datchikDigital.getDigitalInput2()));
                datchikDigital.setDigitalInput3(strToInt(rbDi3, datchikDigital.getDigitalInput3()));
                datchikDigital.setDigitalInput4(strToInt(rbDi4, datchikDigital.getDigitalInput4()));


                int saveError = coreDatchikDigital.save(datchikDigital);
                if (saveError == Error.ERR_SUCCESS) {
                    return new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_DATCHIK + "?contract-id=" + contractId + "&id=" + mobjectId);
                }
                logger.debug("saveError", saveError);
                modelAndView.addObject("saveError", saveError);

            }
        }

        modelAndView.addObject("datchikDigital", datchikDigital);

        // If mobject ID exists, send to view
        if (mobjectId != null) {
            modelAndView.addObject("mobjectId", mobjectId);
            MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mobjectId);
            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                modelAndView.addObject("mObjectGPSUnitId", mObjectGPSUnit.getId());
            }
        }
        if (contractIdStr != null)
            modelAndView.addObject("contractId", contractIdStr);
        // Set tab ID
        modelAndView.addObject("menuActive", TAB_FUEL_DATCHIK);
        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_DUT)
    public ModelAndView mobjectEditDut(HttpSession session,
                                       @RequestParam(value = "id", required = false) String mobjectIdStr,
                                       @RequestParam(value = "cmd", required = false) String cmd,
                                       @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                       // --
                                       @RequestParam(value = "cb-use-bak1", required = false, defaultValue = "0") String bak1Use,
                                       @RequestParam(value = "bak1-input", required = false) String bak1Input,
                                       @RequestParam(value = "bak1-fuel-type", required = false) String bak1FuelType,
                                       // --
                                       @RequestParam(value = "bak1-coef-a", required = false) String bak1CoefA,
                                       @RequestParam(value = "bak1-coef-b", required = false) String bak1CoefB,
                                       @RequestParam(value = "bak1-coef-c", required = false) String bak1CoefC,
                                       @RequestParam(value = "bak1-coef-d", required = false) String bak1CoefD,
                                       // --
                                       @RequestParam(value = "sp-bak1-tank-size", required = false) String bak1TankSize,
                                       @RequestParam(value = "sp-bak1-fuel-filling", required = false) String bak1FuelFilling,
                                       @RequestParam(value = "sp-bak1-fuel-drain", required = false) String bak1FuelDrain,
                                       @RequestParam(value = "sp-bak1-filling-drain-on-move", required = false, defaultValue = "0") String bak1FillingDrainOnMove,
                                       // --
                                       @RequestParam(value = "sp-bak1-filter-ignition-on", required = false, defaultValue = "0") String bak1FilterIgnitionOn,
                                       @RequestParam(value = "sp-bak1-filter-speed-non-zero", required = false, defaultValue = "0") String bak1FilterSpeedNonZero,
                                       @RequestParam(value = "sp-bak1-filter-speed-min", required = false) String bak1FilterSpeedMin,
                                       @RequestParam(value = "sp-bak1-average-seconds", required = false, defaultValue = "0") String bak1AverageSeconds,
                                       @RequestParam(value = "sp-bak1-average-windows-use", required = false, defaultValue = "0") String bak1AverageWindowsUse,
                                       @RequestParam(value = "sp-bak1-average-windows-data", required = false) String bak1AverageWindowsData,
                                       @RequestParam(value = "sp-bak1-average-windows-restart-use", required = false, defaultValue = "0") String bak1AverageWindowsRestartUse,
                                       @RequestParam(value = "sp-bak1-average-windows-restart-time", required = false) String bak1AverageWindowsRestartTime,
                                       @RequestParam(value = "sp-bak1-use-between-fillings", required = false, defaultValue = "0") String bak1UseBetweenFillings,
                                       // --
                                       @RequestParam(value = "cb-use-bak2", required = false, defaultValue = "0") String bak2Use,
                                       @RequestParam(value = "bak2-input", required = false) String bak2Input,
                                       @RequestParam(value = "bak2-fuel-type", required = false) String bak2FuelType,
                                       // --
                                       @RequestParam(value = "bak2-coef-a", required = false) String bak2CoefA,
                                       @RequestParam(value = "bak2-coef-b", required = false) String bak2CoefB,
                                       @RequestParam(value = "bak2-coef-c", required = false) String bak2CoefC,
                                       @RequestParam(value = "bak2-coef-d", required = false) String bak2CoefD,
                                       // --
                                       @RequestParam(value = "sp-bak2-tank-size", required = false) String bak2TankSize,
                                       @RequestParam(value = "sp-bak2-fuel-filling", required = false) String bak2FuelFilling,
                                       @RequestParam(value = "sp-bak2-fuel-drain", required = false) String bak2FuelDrain,
                                       @RequestParam(value = "sp-bak2-filling-drain-on-move", required = false, defaultValue = "0") String bak2FillingDrainOnMove,
                                       // --
                                       @RequestParam(value = "sp-bak2-filter-ignition-on", required = false, defaultValue = "0") String bak2FilterIgnitionOn,
                                       @RequestParam(value = "sp-bak2-filter-speed-non-zero", required = false, defaultValue = "0") String bak2FilterSpeedNonZero,
                                       @RequestParam(value = "sp-bak2-filter-speed-min", required = false) String bak2FilterSpeedMin,
                                       @RequestParam(value = "sp-bak2-average-seconds", required = false, defaultValue = "0") String bak2AverageSeconds,
                                       @RequestParam(value = "sp-bak2-average-windows-use", required = false, defaultValue = "0") String bak2AverageWindowsUse,
                                       @RequestParam(value = "sp-bak2-average-windows-data", required = false) String bak2AverageWindowsData,
                                       @RequestParam(value = "sp-bak2-average-windows-restart-use", required = false, defaultValue = "0") String bak2AverageWindowsRestartUse,
                                       @RequestParam(value = "sp-bak2-average-windows-restart-time", required = false) String bak2AverageWindowsRestartTime,
                                       @RequestParam(value = "sp-bak2-use-between-fillings", required = false, defaultValue = "0") String bak2UseBetweenFillings,

                                       @RequestParam(value = "bak1-comt-on", required = false, defaultValue = "0") String bak1ComtOn,
                                       @RequestParam(value = "bak1-comt-value", required = false) String bak1ComtValue,
                                       @RequestParam(value = "bak1-normalization-time-on", required = false, defaultValue = "0") String bak1NormalizationTimeOn,
                                       @RequestParam(value = "bak1-normalization-time-value", required = false) String bak1NormalizationTimeValue,
                                       @RequestParam(value = "bak2-comt-on", required = false, defaultValue = "0") String bak2ComtOn,
                                       @RequestParam(value = "bak2-comt-value", required = false) String bak2ComtValue,
                                       @RequestParam(value = "bak2-normalization-time-on", required = false, defaultValue = "0") String bak2NormalizationTimeOn,
                                       @RequestParam(value = "bak2-normalization-time-value", required = false) String bak2NormalizationTimeValue
    ) throws ServletException, ParseException, IOException {

        // get params and convert type
        Long mobjectId = strToLong(mobjectIdStr, null);
        Long contractId = strToLong(contractIdStr, null);


        // if contract not selected, redirect to contracts list
        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_LIST);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_DUT);

        // Connect to Core Fuel Controller
        CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();


        if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
            // Can work
        } else {
            modelAndView.addObject("errorCode", Errors.ERR_SERIAL_ACCESS_FUEL_DATCHIK);
            return modelAndView;
        }

        // get fuelDatchik  by mobject id
        FuelDatchik fuelDatchik = coreFuelControl.getFuelDatchikByMobjectId(mobjectId);

        // If settings not exists, take by default
        if (fuelDatchik == null) fuelDatchik = new FuelDatchik();

        // if (cmd != null && checkUserId(id, contractId)) {
        if (cmd != null) {
            if (cmd.equalsIgnoreCase("save")) {
                fuelDatchik.setMobjectId(mobjectId);

                fuelDatchik.setBak1Use(strToInt(bak1Use, fuelDatchik.getBak1Use()));
                fuelDatchik.setBak1Input(strToInt(bak1Input, fuelDatchik.getBak1Input()));
                fuelDatchik.setBak1FuelType(strToInt(bak1FuelType, fuelDatchik.getBak1FuelType()));

                fuelDatchik.setBak1CoefA(strToFloat(bak1CoefA, fuelDatchik.getBak1CoefA()));
                fuelDatchik.setBak1CoefB(strToFloat(bak1CoefB, fuelDatchik.getBak1CoefB()));
                fuelDatchik.setBak1CoefC(strToFloat(bak1CoefC, fuelDatchik.getBak1CoefC()));
                fuelDatchik.setBak1CoefD(strToFloat(bak1CoefD, fuelDatchik.getBak1CoefD()));

                fuelDatchik.setBak1TankSize(strToFloat(bak1TankSize, fuelDatchik.getBak1TankSize()));
                fuelDatchik.setBak1FuelFilling(strToFloat(bak1FuelFilling, fuelDatchik.getBak1FuelFilling()));
                fuelDatchik.setBak1FuelDrain(strToFloat(bak1FuelDrain, fuelDatchik.getBak1FuelDrain()));
                fuelDatchik.setBak1FillingDrainOnMove(strToInt(bak1FillingDrainOnMove, fuelDatchik.getBak1FillingDrainOnMove()));

                fuelDatchik.setBak1FilterIgnitionOn(strToInt(bak1FilterIgnitionOn, fuelDatchik.getBak1FilterIgnitionOn()));
                fuelDatchik.setBak1FilterSpeedNonZero(strToInt(bak1FilterSpeedNonZero, fuelDatchik.getBak1FilterSpeedNonZero()));
                fuelDatchik.setBak1FilterSpeedMin(strToFloat(bak1FilterSpeedMin, fuelDatchik.getBak1FilterSpeedMin()));
                fuelDatchik.setBak1AverageSeconds(strToLong(bak1AverageSeconds, fuelDatchik.getBak1AverageSeconds()));
                fuelDatchik.setBak1AverageWindowsUse(strToInt(bak1AverageWindowsUse, fuelDatchik.getBak1AverageWindowsUse()));
                fuelDatchik.setBak1AverageWindowsData(strToLong(bak1AverageWindowsData, fuelDatchik.getBak1AverageWindowsData()));
                fuelDatchik.setBak1AverageWindowsRestartUse(strToInt(bak1AverageWindowsRestartUse, fuelDatchik.getBak1AverageWindowsRestartUse()));
                fuelDatchik.setBak1AverageWindowsRestartTime(strToLong(bak1AverageWindowsRestartTime, fuelDatchik.getBak1AverageWindowsRestartTime()));
                fuelDatchik.setBak1UseBetweenFillings(strToInt(bak1UseBetweenFillings, fuelDatchik.getBak1UseBetweenFillings()));

                fuelDatchik.setBak1ComtOn(strToInt(bak1ComtOn, fuelDatchik.getBak1ComtOn()));
                fuelDatchik.setBak1ComtValue(strToInt(bak1ComtValue, fuelDatchik.getBak1ComtValue()));
                fuelDatchik.setBak1NormalizationTimeOn(strToInt(bak1NormalizationTimeOn, fuelDatchik.getBak1NormalizationTimeOn()));
                fuelDatchik.setBak1NormalizationTimeValue(strToInt(bak1NormalizationTimeValue, fuelDatchik.getBak1NormalizationTimeValue()));

                fuelDatchik.setBak2Use(strToInt(bak2Use, fuelDatchik.getBak2Use()));
                fuelDatchik.setBak2Input(strToInt(bak2Input, fuelDatchik.getBak2Input()));
                fuelDatchik.setBak2FuelType(strToInt(bak2FuelType, fuelDatchik.getBak2FuelType()));

                fuelDatchik.setBak2CoefA(strToFloat(bak2CoefA, fuelDatchik.getBak2CoefA()));
                fuelDatchik.setBak2CoefB(strToFloat(bak2CoefB, fuelDatchik.getBak2CoefB()));
                fuelDatchik.setBak2CoefC(strToFloat(bak2CoefC, fuelDatchik.getBak2CoefC()));
                fuelDatchik.setBak2CoefD(strToFloat(bak2CoefD, fuelDatchik.getBak2CoefD()));

                fuelDatchik.setBak2TankSize(strToFloat(bak2TankSize, fuelDatchik.getBak2TankSize()));
                fuelDatchik.setBak2FuelFilling(strToFloat(bak2FuelFilling, fuelDatchik.getBak2FuelFilling()));
                fuelDatchik.setBak2FuelDrain(strToFloat(bak2FuelDrain, fuelDatchik.getBak2FuelDrain()));
                fuelDatchik.setBak2FillingDrainOnMove(strToInt(bak2FillingDrainOnMove, fuelDatchik.getBak2FillingDrainOnMove()));

                fuelDatchik.setBak2FilterIgnitionOn(strToInt(bak2FilterIgnitionOn, fuelDatchik.getBak2FilterIgnitionOn()));
                fuelDatchik.setBak2FilterSpeedNonZero(strToInt(bak2FilterSpeedNonZero, fuelDatchik.getBak2FilterSpeedNonZero()));
                fuelDatchik.setBak2FilterSpeedMin(strToFloat(bak2FilterSpeedMin, fuelDatchik.getBak2FilterSpeedMin()));
                fuelDatchik.setBak2AverageSeconds(strToLong(bak2AverageSeconds, fuelDatchik.getBak2AverageSeconds()));
                fuelDatchik.setBak2AverageWindowsUse(strToInt(bak2AverageWindowsUse, fuelDatchik.getBak2AverageWindowsUse()));
                fuelDatchik.setBak2AverageWindowsData(strToLong(bak2AverageWindowsData, fuelDatchik.getBak2AverageWindowsData()));
                fuelDatchik.setBak2AverageWindowsRestartUse(strToInt(bak2AverageWindowsRestartUse, fuelDatchik.getBak2AverageWindowsRestartUse()));
                fuelDatchik.setBak2AverageWindowsRestartTime(strToLong(bak2AverageWindowsRestartTime, fuelDatchik.getBak2AverageWindowsRestartTime()));
                fuelDatchik.setBak2UseBetweenFillings(strToInt(bak2UseBetweenFillings, fuelDatchik.getBak2UseBetweenFillings()));

                fuelDatchik.setBak2ComtOn(strToInt(bak2ComtOn, fuelDatchik.getBak2ComtOn()));
                fuelDatchik.setBak2ComtValue(strToInt(bak2ComtValue, fuelDatchik.getBak2ComtValue()));
                fuelDatchik.setBak2NormalizationTimeOn(strToInt(bak2NormalizationTimeOn, fuelDatchik.getBak2NormalizationTimeOn()));
                fuelDatchik.setBak2NormalizationTimeValue(strToInt(bak2NormalizationTimeValue, fuelDatchik.getBak2NormalizationTimeValue()));

                int saveError = coreFuelControl.save(fuelDatchik);
                if (saveError == Error.ERR_SUCCESS) {
                    // Make a row for report generator
                    coreMain.timeUpdateController.dbTpLastTime.insertByReportMobject((long) TpLastTime.REPORTER_FUEL_FILTER,
                            mobjectId, new Timestamp(System.currentTimeMillis()));

                    return new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_DUT + "?contract-id=" + contractId + "&id=" + mobjectId);
                }
                logger.debug("saveError", saveError);
                modelAndView.addObject("saveError", saveError);

            }
        }

        modelAndView.addObject("fuelDatchik", fuelDatchik);

        // If mobject ID exists, send to view
        if (mobjectId != null) {
            modelAndView.addObject("mobjectId", mobjectId);
            MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mobjectId);
            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                modelAndView.addObject("mObjectGPSUnitId", mObjectGPSUnit.getId());
            }
        }
        if (contractIdStr != null)
            modelAndView.addObject("contractId", contractIdStr);
        // Set tab ID
        modelAndView.addObject("menuActive", TAB_FUEL_DUT);
        return modelAndView;
    }


    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_NORM)
    public ModelAndView mobjectEditNorm(HttpSession session,
                                        @RequestParam(value = "id", required = false) String mobjectIdStr,
                                        @RequestParam(value = "cmd", required = false) String cmd,
                                        @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                        @RequestParam(value = "cb-use-fuel-norm", required = false, defaultValue = "0") Integer useFuelNorm,
                                        @RequestParam(value = "select-fuel-type", required = false) Integer fuelType,
                                        @RequestParam(value = "period-summer-start", required = false, defaultValue = Constants.DEFAULT_PERIOD_SUMMER_START) String periodSummerStart,
                                        @RequestParam(value = "period-summer-end", required = false, defaultValue = Constants.DEFAULT_PERIOD_SUMMER_END) String periodSummerEnd,
                                        @RequestParam(value = "period-winter-start", required = false, defaultValue = Constants.DEFAULT_PERIOD_WINTER_START) String periodWinterStart,
                                        @RequestParam(value = "period-winter-end", required = false, defaultValue = Constants.DEFAULT_PERIOD_WINTER_END) String periodWinterEnd,
                                        @RequestParam(value = "speed-summer-1", required = false) String speedSummer1,
                                        @RequestParam(value = "speed-summer-2", required = false) String speedSummer2,
                                        @RequestParam(value = "speed-summer-3", required = false) String speedSummer3,
                                        @RequestParam(value = "speed-summer-4", required = false) String speedSummer4,
                                        @RequestParam(value = "speed-winter-1", required = false) String speedWinter1,
                                        @RequestParam(value = "speed-winter-2", required = false) String speedWinter2,
                                        @RequestParam(value = "speed-winter-3", required = false) String speedWinter3,
                                        @RequestParam(value = "speed-winter-4", required = false) String speedWinter4,
                                        @RequestParam(value = "fuel-rate-summer-0", required = false) String fuelRateSummer0,
                                        @RequestParam(value = "fuel-rate-summer-1", required = false) String fuelRateSummer1,
                                        @RequestParam(value = "fuel-rate-summer-2", required = false) String fuelRateSummer2,
                                        @RequestParam(value = "fuel-rate-summer-3", required = false) String fuelRateSummer3,
                                        @RequestParam(value = "fuel-rate-summer-4", required = false) String fuelRateSummer4,
                                        @RequestParam(value = "fuel-rate-winter-0", required = false) String fuelRateWinter0,
                                        @RequestParam(value = "fuel-rate-winter-1", required = false) String fuelRateWinter1,
                                        @RequestParam(value = "fuel-rate-winter-2", required = false) String fuelRateWinter2,
                                        @RequestParam(value = "fuel-rate-winter-3", required = false) String fuelRateWinter3,
                                        @RequestParam(value = "fuel-rate-winter-4", required = false) String fuelRateWinter4,
                                        @RequestParam(value = "fuel-norm-100km", required = false) String fuelNorm100km)
            throws ServletException, ParseException, IOException {

        // get params and convert type
        Long mobjectId = strToLong(mobjectIdStr, null);
        Long contractId = strToLong(contractIdStr, null);

        // if contract not selected, redirect to contracts list
        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_LIST);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_NORM);

        // Connect to Core Fuel Controller
        CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

        if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
            // Can work
        } else {
            modelAndView.addObject("errorCode", Errors.ERR_SERIAL_ACCESS_FUEL_DATCHIK);
            return modelAndView;
        }

        FuelNorm fuelNorm = coreFuelControl.getFuelNormByMobjectId(mobjectId);


        if (fuelNorm == null) fuelNorm = new FuelNorm();
        if (cmd != null) {
            if (cmd.equalsIgnoreCase("save")) {

                fuelNorm.setMobjectId(mobjectId);
                fuelNorm.setUseFuelNorm(useFuelNorm);
                fuelNorm.setFuelType(fuelType);

                String summerStartStr = dateConvert(periodSummerStart, Constants.DEFAULT_PERIOD_SUMMER_START);
                String summerEndStr = dateConvert(periodSummerEnd, Constants.DEFAULT_PERIOD_SUMMER_END);
                String winterStartStr = dateConvert(periodWinterStart, Constants.DEFAULT_PERIOD_WINTER_START);
                String winterEndStr = dateConvert(periodWinterEnd, Constants.DEFAULT_PERIOD_WINTER_END);

                fuelNorm.setPeriodSummerStart(summerStartStr);
                fuelNorm.setPeriodSummerEnd(summerEndStr);
                fuelNorm.setPeriodWinterStart(winterStartStr);
                fuelNorm.setPeriodWinterEnd(winterEndStr);

                fuelNorm.setSpeedSummer1(strToInt(speedSummer1, fuelNorm.getSpeedSummer1()));
                fuelNorm.setSpeedSummer2(strToInt(speedSummer2, fuelNorm.getSpeedSummer2()));
                fuelNorm.setSpeedSummer3(strToInt(speedSummer3, fuelNorm.getSpeedSummer3()));
                fuelNorm.setSpeedSummer4(strToInt(speedSummer4, fuelNorm.getSpeedSummer4()));
                fuelNorm.setSpeedWinter1(strToInt(speedWinter1, fuelNorm.getSpeedWinter1()));
                fuelNorm.setSpeedWinter2(strToInt(speedWinter2, fuelNorm.getSpeedWinter2()));
                fuelNorm.setSpeedWinter3(strToInt(speedWinter3, fuelNorm.getSpeedWinter3()));
                fuelNorm.setSpeedWinter4(strToInt(speedWinter4, fuelNorm.getSpeedWinter4()));

                fuelNorm.setFuelRateSummer0(strToFloat(fuelRateSummer0, fuelNorm.getFuelRateSummer0()));
                fuelNorm.setFuelRateSummer1(strToFloat(fuelRateSummer1, fuelNorm.getFuelRateSummer1()));
                fuelNorm.setFuelRateSummer2(strToFloat(fuelRateSummer2, fuelNorm.getFuelRateSummer2()));
                fuelNorm.setFuelRateSummer3(strToFloat(fuelRateSummer3, fuelNorm.getFuelRateSummer3()));
                fuelNorm.setFuelRateSummer4(strToFloat(fuelRateSummer4, fuelNorm.getFuelRateSummer4()));
                fuelNorm.setFuelRateWinter0(strToFloat(fuelRateWinter0, fuelNorm.getFuelRateWinter0()));
                fuelNorm.setFuelRateWinter1(strToFloat(fuelRateWinter1, fuelNorm.getFuelRateWinter1()));
                fuelNorm.setFuelRateWinter2(strToFloat(fuelRateWinter2, fuelNorm.getFuelRateWinter2()));
                fuelNorm.setFuelRateWinter3(strToFloat(fuelRateWinter3, fuelNorm.getFuelRateWinter3()));
                fuelNorm.setFuelRateWinter4(strToFloat(fuelRateWinter4, fuelNorm.getFuelRateWinter4()));

                // fuelNorm.setFuelLitrPer100km(strToFloat(fuelNorm100km, fuelNorm.getFuelLitrPer100km()));
                fuelNorm.setFuelLitrPer100km(strToFloat(fuelNorm100km, null));

                int saveError = coreFuelControl.save(fuelNorm);
                if (saveError == Error.ERR_SUCCESS) {
                    // Make a row for report generator
                    coreMain.timeUpdateController.dbTpLastTime.insertByReportMobject((long) TpLastTime.REPORTER_FUEL_CONSUMPTION_NORM,
                            mobjectId, new Timestamp(System.currentTimeMillis()));

                    return new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_NORM + "?contract-id=" + contractId + "&id=" + mobjectId);
                }
                logger.debug("saveError", saveError);
                modelAndView.addObject("saveError", saveError);

            }
        }


        String summerStartDate = parseDateFormat(Calculator.dateStrToLong2(fuelNorm.getPeriodSummerStart()));
        String summerEndDate = parseDateFormat(Calculator.dateStrToLong2(fuelNorm.getPeriodSummerEnd()));
        String winterStartDate = parseDateFormat(Calculator.dateStrToLong2(fuelNorm.getPeriodWinterStart()));
        String winterEndDate = parseDateFormat(Calculator.dateStrToLong2(fuelNorm.getPeriodWinterEnd()));

        modelAndView.addObject("fuelNorm", fuelNorm);
        modelAndView.addObject("summerStartDate", summerStartDate);
        modelAndView.addObject("summerEndDate", summerEndDate);
        modelAndView.addObject("winterStartDate", winterStartDate);
        modelAndView.addObject("winterEndDate", winterEndDate);

        // If mobject ID exists, send to view
        if (mobjectId != null) {
            modelAndView.addObject("mobjectId", mobjectId);
        }
        // If mobject ID exists, send to view
        if (mobjectId != null) {
            modelAndView.addObject("mobjectId", mobjectId);
            MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mobjectId);
            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                modelAndView.addObject("mObjectGPSUnitId", mObjectGPSUnit.getId());
            }
        }
        if (contractIdStr != null)
            modelAndView.addObject("contractId", contractIdStr);
        // Set tab ID
        modelAndView.addObject("menuActive", TAB_FUEL_NORM);


        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_CAN)
    public ModelAndView mobjectEditCan(HttpSession session,
                                       @RequestParam(value = "id", required = false) String mobjectIdStr,
                                       @RequestParam(value = "cmd", required = false) String cmd,
                                       @RequestParam(value = "contract-id", required = false) String contractIdStr,

                                       @RequestParam(value = "cb-use-can", required = false, defaultValue = "0") String useCan,
                                       @RequestParam(value = "sp-tank-size", required = false) String tankSize,
                                       @RequestParam(value = "sp-fuel-filling", required = false) String fuelFilling,
                                       @RequestParam(value = "sp-fuel-drain", required = false) String fuelDrain,
                                       @RequestParam(value = "sp-filling-drain-on-move", required = false, defaultValue = "0") String fillingDrainOnMove,

                                       @RequestParam(value = "sp-ignition-on", required = false) String ignitionOn,
                                       @RequestParam(value = "sp-speed-non-zero", required = false) String speedNonZero,
                                       @RequestParam(value = "sp-speed-min", required = false) String speedMin,
                                       @RequestParam(value = "sp-fuel-type", required = false, defaultValue = "0") String fuelType,

                                       @RequestParam(value = "sp-average-seconds", required = false, defaultValue = "0") String averageSeconds,
                                       @RequestParam(value = "sp-average-windows-use", required = false, defaultValue = "0") String averageWindowsUse,
                                       @RequestParam(value = "sp-average-windows-data", required = false) String averageWindowsData,
                                       @RequestParam(value = "sp-average-windows-restart-use", required = false, defaultValue = "0") String averageWindowsRestartUse,
                                       @RequestParam(value = "sp-average-windows-restart-time", required = false) String averageWindowsRestartTime
    ) throws ServletException, ParseException, IOException {

        // get params and convert type
        Long mobjectId = strToLong(mobjectIdStr, null);
        Long contractId = strToLong(contractIdStr, null);

        // if contract not selected, redirect to contracts list
        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_LIST);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_CAN);

        // Connect to Core Fuel Controller
        CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

        if (coreFuelControl != null &&
                coreFuelControl.isHasAccess() &&
                coreFuelControl.getCoreCanDatchik() != null &&
                (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                        || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                        || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                        || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                        || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                        || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                        || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                        || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")
                )) {
            // Can work
        } else {
            modelAndView.addObject("errorCode", Errors.ERR_SERIAL_ACCESS_FUEL_DATCHIK);
            return modelAndView;
        }

        CanDatchik canDatchik = coreFuelControl.getCoreCanDatchik().getByMobjectId(mobjectId);

        if (canDatchik == null) canDatchik = new CanDatchik();

        // Set CanDatchik values
        if (cmd != null) {
            if (cmd.equalsIgnoreCase("save")) {

                canDatchik.setMobjectId(mobjectId);

                canDatchik.setUseCan(strToInt(useCan, canDatchik.getUseCan()));
                canDatchik.setFuelType(strToInt(fuelType, canDatchik.getFuelType()));

                canDatchik.setFuelFilling(strToFloat(fuelFilling, canDatchik.getFuelFilling()));
                canDatchik.setFuelDrain(strToFloat(fuelDrain, canDatchik.getFuelDrain()));
                canDatchik.setTankSize(strToFloat(tankSize, canDatchik.getTankSize()));
                canDatchik.setFillingDrainOnMove(strToInt(fillingDrainOnMove, canDatchik.getFillingDrainOnMove()));

                canDatchik.setIgnitionOn(strToInt(ignitionOn, canDatchik.getIgnitionOn()));
                canDatchik.setSpeedNonZero(strToInt(speedNonZero, canDatchik.getSpeedNonZero()));
                canDatchik.setSpeedMin(strToFloat(speedMin, canDatchik.getSpeedMin()));

                canDatchik.setAverageSeconds(strToLong(averageSeconds, canDatchik.getAverageSeconds()));
                canDatchik.setAverageWindowsUse(strToInt(averageWindowsUse, canDatchik.getAverageWindowsUse()));
                canDatchik.setAverageWindowsData(strToLong(averageWindowsData, canDatchik.getAverageWindowsData()));
                canDatchik.setAverageWindowsRestartUse(strToInt(averageWindowsRestartUse, canDatchik.getAverageWindowsRestartUse()));
                canDatchik.setAverageWindowsRestartTime(strToLong(averageWindowsRestartTime, canDatchik.getAverageWindowsRestartTime()));

                int saveError = coreFuelControl.getCoreCanDatchik().save(canDatchik);
                if (saveError == Error.ERR_SUCCESS) {
                    // Make a row for report generator
                    coreMain.timeUpdateController.dbTpLastTime.insertByReportMobject((long) TpLastTime.REPORTER_CAN,
                            mobjectId, new Timestamp(System.currentTimeMillis()));

                    return new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_CAN + "?contract-id=" + contractId + "&id=" + mobjectId);
                }
                logger.debug("saveError", saveError);
                modelAndView.addObject("saveError", saveError);
            }
        }

        // Set tab ID
        modelAndView.addObject("menuActive", TAB_CAN);
        modelAndView.addObject("canDatchik", canDatchik);

        // If mobject ID exists, send to view
        if (mobjectId != null) {
            modelAndView.addObject("mobjectId", mobjectId);
            MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mobjectId);
            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                modelAndView.addObject("mObjectGPSUnitId", mObjectGPSUnit.getId());
            }
        }
        if (contractIdStr != null)
            modelAndView.addObject("contractId", contractIdStr);

        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_REPORT_PARAMS)
    public ModelAndView mobjectEditReportParam(HttpSession session,
                                               @RequestParam(value = "id", required = false) String mobjectIdStr,
                                               @RequestParam(value = "cmd", required = false) String cmd,
                                               @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                               @RequestParam(value = "timeMin", required = false) String timeMin,
                                               @RequestParam(value = "timeBig", required = false) String timeBig,
                                               @RequestParam(value = "timeLost", required = false) String timeLost,
                                               @RequestParam(value = "distanceMin", required = false) String distanceMin,
                                               @RequestParam(value = "distanceMax", required = false) String distanceMax)
            throws ServletException, ParseException, IOException {

        // get params and convert type
        Long mobjectId = strToLong(mobjectIdStr, null);
        Long contractId = strToLong(contractIdStr, null);

        // if contract not selected, redirect to contracts list
        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_LIST);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_REPORT_PARAMS);


        // Connect to Core Fuel Controller
        CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

        if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
            // Can work
        } else {
            modelAndView.addObject("errorCode", Errors.ERR_SERIAL_ACCESS_FUEL_DATCHIK);
            return modelAndView;
        }
        if (cmd != null) {
            if (cmd.equalsIgnoreCase("edit")) {
                mobjectReportParamEdit(mobjectId, timeMin, timeBig, timeLost, distanceMin, distanceMax);
            }
        }

        // If mobject ID exists, send to view
        if (mobjectId != null) {
            modelAndView.addObject("mobjectId", mobjectId);
            MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mobjectId);
            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                modelAndView.addObject("mObjectGPSUnitId", mObjectGPSUnit.getId());
                modelAndView.addObject("mObjectGPSUnit", mObjectGPSUnit);
            }
        }

        modelAndView.addObject("contractId", contractId);

        // Set tab ID
        modelAndView.addObject("menuActive", TAB_REPORT);

        return modelAndView;
    }

    /**
     * Checks access of user to this object.
     * Access can be as read only or edit.
     *
     * @param mobjectId  Object ID
     * @param contractId Contract ID
     * @return access level <br>
     * 0 No Access <br>
     * 1st bit Read Only <br>
     * 2nd bit Edit mode
     */

    private boolean checkUserId(HttpSession session, Long mobjectId, Long contractId) {
        boolean access = false;
        if (mobjectId != null && contractId != null) {
            if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_CUSTOMER_ADMIN_STR)
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")) {
                // Check contract number
                if (contractId.equals(MainController.getUserContractId(session))) {
                    access = true;
                }
            } else {
                // User
                if (contractId.equals(MainController.getUserContractId(session))) {
                    Long userId = MainController.getInterfaceUserId();
                    access = coreMain.isHasEditAccessToMobject(userId, mobjectId);
                }
            }
        }
        return access;
    }

    /**
     * Converts String type float value into Float.
     * Before convert, replaves all commas (,) to dots (.)
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return float value of result
     */
    private Float strToFloat(String value, Float defaultValue) {
        try {
            String valueWithDot = value.replaceAll(",", ".");
            valueWithDot = valueWithDot.replaceAll(" ", "");
            Float f = Float.valueOf(valueWithDot);
            return f;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type int value into Integer.
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return float value of result
     */
    private Integer strToInt(String value, Integer defaultValue) {
        try {
            String valueWithDot = value.replaceAll(" ", "");
            Integer v = Integer.valueOf(valueWithDot);
            return v;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type int value into Long.
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return Long value of result
     */
    private Long strToLong(String value, Long defaultValue) {
        try {
            String valueWithDot = value.replaceAll(" ", "");
            Long v = Long.valueOf(valueWithDot);
            return v;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Makes new Settings for Mobject and saves to DB
     *
     * @param mObject mobject itself
     */
    private void makeMobjectSettings(MObject mObject) {
        if (mObject != null) {
            // Make new Mobject settings
            MObjectSettings mObjectSettings = new MObjectSettings();
            mObjectSettings.setmObject(mObject);
            mObjectSettings.setDefaultTrackColor("#ff0000");
            mObjectSettings.setSpeedColor1("#1cf0f0");
            mObjectSettings.setSpeedColor2("#3442f4");
            mObjectSettings.setSpeedColor3("#28ec50");
            mObjectSettings.setSpeedColor4("#ff25e5");
            mObjectSettings.setSpeedColor5("#ffa500");
            mObjectSettings.setSpeedColor6("#ff0000");
            mObjectSettings.setSpeedValue1(30L);
            mObjectSettings.setSpeedValue2(50L);
            mObjectSettings.setSpeedValue3(70L);
            mObjectSettings.setSpeedValue4(90L);
            mObjectSettings.setSpeedValue5(100L);
            mObjectSettings.setSpeedValue6(120L);
            mObjectSettings.setLabelSize(10L);
            mObjectSettings.setMaxSpeed(70L);
            mObjectSettings.setOnlineTime(300L);
            mObjectSettings.setParkingTime(600L);
            mObjectSettings.setRegDate(new Timestamp(System.currentTimeMillis()));
            mObjectSettings.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            adminService.saveMObjectSettings(mObjectSettings);
        }
    }

    /**
     * Checks if given tracker is mobile tracker, if so, makes settings for this tracker
     *
     * @param gpsUnit tracker GPS Unit object
     * @param mObject MObject
     */
    private void makeMobileSettings(GPSUnit gpsUnit, MObject mObject) {
        if (gpsUnit.getIsMobile() != null && gpsUnit.getIsMobile() == 1) {
            MobileTrackerSettings mobileTrackerSettings = new MobileTrackerSettings();
            mobileTrackerSettings.setmObjectId(mObject.getId());
            mobileTrackerSettings.setMobileSerial(gpsUnit.getImei());
            mobileTrackerSettings.setHasPassword(UZGPS_CONST.MTRACKER_DEFAULT_SETTINGS_HAS_PASSWORD);
            mobileTrackerSettings.setPassword(UZGPS_CONST.MTRACKER_DEFAULT_SETTINGS_PASSWORD);
            mobileTrackerSettings.setLocationUpdateTime(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_TIME);
            mobileTrackerSettings.setLocationUpdateDistance(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_DISTANCE);
            mobileTrackerSettings.setLocationUpdateAccuracy(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_ACCURACY);
            mobileTrackerSettings.setLocationUpdateAngle(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_ANGLE);
            mobileTrackerSettings.setShouldChangeStatus(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_STATUS_CHANGE);
            mobileTrackerSettings.setRecordLimit(UZGPS_CONST.MTRACKER_DEFAULT_RECORD_LIMIT);
            mobileTrackerSettings.setLocationSendTime(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_SEND_TIME);
            mobileTrackerSettings.setShouldSend3G(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_SEND_3G);
            mobileTrackerSettings.setShouldSendWiFi(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_SEND_WIFI);
            mobileTrackerSettings.setTrackLength(UZGPS_CONST.MTRACKER_DEFAULT_TRACK_LENGTH);
            mobileTrackerSettings.setMapType(UZGPS_CONST.MTRACKER_DEFAULT_MAP_TYPE);
            mobileTrackerSettings.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            mobileTrackerSettings.setRegDate(new Timestamp(System.currentTimeMillis()));

            settingsService.saveMobileTrackerSettings(mobileTrackerSettings);
        }
    }


    /**
     * Generates new Mobject Notifications with Default Values
     *
     * @param mObjectId Mobject ID
     * @return MObjectNotification
     */
    private MObjectNotifications makeMobjectNotification(Long mObjectId) {
        MObjectNotifications mObjectNotifications = new MObjectNotifications();
        mObjectNotifications.setmObjectId(mObjectId);
        mObjectNotifications.setPanicButton(true);
        mObjectNotifications.setMinSpeed(20);
        mObjectNotifications.setMaxSpeed(70);
        mObjectNotifications.setSendSms(false);
        mObjectNotifications.setSendMail(false);
        mObjectNotifications.setPopUpWindow(true);
        mObjectNotifications.setnPopUpWindow(true);
        mObjectNotifications.setRegisterDatabase(false);
        mObjectNotifications.setRegisterDatabaseViolation(false);

        mObjectNotifications.setuSos(true);
        mObjectNotifications.setuEngine(true);
        mObjectNotifications.setuSpeedMin(false);
        mObjectNotifications.setuSpeedMax(true);
        mObjectNotifications.setuOnline(false);
        mObjectNotifications.setuStaff(false);
        mObjectNotifications.setuSettings(false);
        mObjectNotifications.setuPoi(true);
        mObjectNotifications.setuZoi(true);
        mObjectNotifications.setuAudioCall(false);
        mObjectNotifications.setuDoorOpen(false);
        mObjectNotifications.setuSosSound(1);
        mObjectNotifications.setuSosColor("#ff0000");
        mObjectNotifications.setuEngineSound(2);
        mObjectNotifications.setuEngineColor("#419D41");
        mObjectNotifications.setuPoiSound(4);
        mObjectNotifications.setuPoiColor("#0000CD");
        mObjectNotifications.setuZoiSound(4);
        mObjectNotifications.setuZoiColor("#1A89AE");
        mObjectNotifications.setuSpeedMaxColor("#C54EEA");
        mObjectNotifications.setuSpeedMaxSound(3);

        mObjectNotifications.setsSos(true);
        mObjectNotifications.setsEngine(true);
        mObjectNotifications.setsSpeedMin(false);
        mObjectNotifications.setsSpeedMax(true);
        mObjectNotifications.setsOnline(true);
        mObjectNotifications.setsStaff(true);
        mObjectNotifications.setsSettings(true);
        mObjectNotifications.setsPoi(true);
        mObjectNotifications.setsZoi(true);
        mObjectNotifications.setsAudioCall(false);
        mObjectNotifications.setsDoorOpen(false);

        mObjectNotifications.setnSos(false);
        mObjectNotifications.setnEngine(false);
        mObjectNotifications.setnSpeedMin(false);
        mObjectNotifications.setnSpeedMax(true);
        mObjectNotifications.setnOnline(false);
        //mObjectNotifications.setnStaff(false);
        //mObjectNotifications.setnSettings(false);
        mObjectNotifications.setnPoi(false);
        mObjectNotifications.setnZoi(false);

        mObjectNotifications.seteSos(false);
        mObjectNotifications.seteEngine(false);
        mObjectNotifications.seteSpeedMin(false);
        mObjectNotifications.seteSpeedMax(false);
        mObjectNotifications.seteOnline(false);
        mObjectNotifications.seteStaff(false);
        mObjectNotifications.seteSettings(false);
        mObjectNotifications.setePoi(false);
        mObjectNotifications.seteZoi(false);

        mObjectNotifications.setmSos(false);
        mObjectNotifications.setmEngine(false);
        mObjectNotifications.setmSpeedMin(false);
        mObjectNotifications.setmSpeedMax(false);
        mObjectNotifications.setmOnline(false);
        mObjectNotifications.setmStaff(false);
        mObjectNotifications.setmSettings(false);
        mObjectNotifications.setmPoi(false);
        mObjectNotifications.setmZoi(false);

        mObjectNotifications.setRegDate(new Timestamp(System.currentTimeMillis()));
        mObjectNotifications.setStatus(UZGPS_CONST.STATUS_ACTIVE);
        adminService.saveMObjectNotifications(mObjectNotifications);

        return mObjectNotifications;
    }

    /**
     * Changes Sim card and GpsUnit connection, and if needed, changes
     *
     * @param simPhone phone number
     * @param gpsUnit  Gps Unit Tracker
     * @return Error code
     */
    private int changeGpsUnitSim(String simPhone, GPSUnit gpsUnit) {
        // Get Sim object from DB
        Sim sim = adminService.getSimBySimPhone(simPhone);
        if (sim == null && simPhone.length() == SIM_PHONE_LENGTH) {
            // make sim
            sim = new Sim();
            sim.setSimPhone(simPhone);
            sim.setRegDate(new Timestamp(System.currentTimeMillis()));
            sim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            adminService.saveSim(sim);
        }

        if (sim != null && sim.getId() != null) {
            // Get GpsUnitSim connection
            GPSUnitSim gpsUnitSim = adminService.getGPSUnitSimBySimId(sim.getId());

            if (gpsUnitSim == null) {
                // Sim not connected, so connect this Sim and GpsUnit 2.d
                adminService.deleteAllGPSUnitSimByUnitId(gpsUnit.getId());
//                gpsUnit.setSimId(sim.getId());
                gpsUnit.setSim1(sim);
                adminService.saveGPSUnit(gpsUnit);
                gpsUnitSim = new GPSUnitSim();
                gpsUnitSim.setSim(sim);
                gpsUnitSim.setGpsUnit(gpsUnit);
                gpsUnitSim.setRegDate(new Timestamp(System.currentTimeMillis()));
                gpsUnitSim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                adminService.saveGPSUnitSim(gpsUnitSim);
            } else {
                // Check there this sim connected
                if (gpsUnitSim.getGpsUnitId() != null
                        && gpsUnitSim.getGpsUnitId().equals(gpsUnit.getId())) {
                    // This sim card connected to current Tracker, do nothing
                } else if (gpsUnitSim.getGpsUnitId() == null || gpsUnitSim.getGpsUnitId() == 0) {
                    // Sim card not connected to other object, connect it
                    gpsUnitSim.setGpsUnit(gpsUnit);
                    gpsUnitSim.setModDate(new Timestamp(System.currentTimeMillis()));
                    adminService.saveGPSUnitSim(gpsUnitSim);
                } else {
                    // Sim card connected to another Trakcer

                    return Error.ERR_SIM_ASSIGNED_TO_OTHER;
                }
            }
        } else {
            return Error.ERR_OBJECT_IS_NULL;
        }
        return Error.ERR_SUCCESS;
    }

    //
    private ModelAndView mobjectReportParamEdit(Long id, String timeMin, String timeBig, String timeLost, String distanceMin, String distanceMax) {

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_REPORT_PARAMS);

        MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(id);

        if (mObjectGPSUnit == null) {
            modelAndView.addObject("error 13");
            modelAndView = new ModelAndView("redirect" + URL_ADMIN_MOBJECT_EDIT_REPORT_PARAMS);
            return modelAndView;
        }

        mObjectGPSUnit.setTimeMin(strToInt(timeMin, mObjectGPSUnit.getTimeMin()));
        mObjectGPSUnit.setTimeBig(strToInt(timeBig, mObjectGPSUnit.getTimeBig()));
        mObjectGPSUnit.setTimeLost(strToInt(timeLost, mObjectGPSUnit.getTimeLost()));
        mObjectGPSUnit.setDistanceBig(strToInt(distanceMax, mObjectGPSUnit.getDistanceBig()));
        mObjectGPSUnit.setDistanceMin(strToInt(distanceMin, mObjectGPSUnit.getDistanceMin()));

        mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_ACTIVE);
        mObjectGPSUnit.setRegDate(new Timestamp(System.currentTimeMillis()));
        adminService.saveMObjectGPSUnit(mObjectGPSUnit);

        modelAndView = new ModelAndView("redirect" + URL_ADMIN_MOBJECT_EDIT_REPORT_PARAMS);


        return modelAndView;
    }

    /**
     * Converts date from long to String
     *
     * @param milliseconds in unix timestamp
     * @return date in String dd.MM.yyyy HH:mm format
     */
    private String parseDateFormat(long milliseconds) {
        SimpleDateFormat formatDate = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        Date date = new Date(milliseconds);
        String strDate = formatDate.format(date);
        return strDate;
    }

    /**
     * Converts date string from dd.MM.yyyy HH:mm format to MMddHHmm format
     *
     * @param dateStr      input date in dd.MM.yyyy HH:mm format
     * @param defaultValue default value if input value is incorrect
     * @return date string in MMddHHmm format
     */
    private String dateConvert(String dateStr, String defaultValue) {
        // Convert date to long in milliseconds
        long dateInLong = Calculator.dateStrToLong(dateStr);
        // If error in parsing, return default value
        if (dateInLong == 0) return defaultValue;
        // of no error, convert milliseconds to String in MMddHHmm format
        String resultStr = Calculator.dateLongToStr(dateInLong);
        return resultStr;
    }

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_DUT_REMOVE_REPORT)
    public ModelAndView removeDutReport(@RequestParam(value = "id", required = false) String mObjectIdStr,
                                        @RequestParam(value = "contract-id", required = false) String contractIdStr) {

        Long contractId = strToLong(contractIdStr, null);
        Long mObjectId = strToLong(mObjectIdStr, null);

        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_DUT + "?contract-id=" + contractId + "&id=" + mObjectId);

        if (mObjectId != null) {

            // Connect to Core Fuel Controller
            CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();


            if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
                // Can work
            } else {
                modelAndView.addObject("errorCode", Errors.ERR_SERIAL_ACCESS_FUEL_DATCHIK);
                return modelAndView;
            }

            // Set to recalculate
            FuelDatchik fuelDatchik = coreFuelControl.getFuelDatchikByMobjectId(mObjectId);

            if (fuelDatchik != null) {
                fuelDatchik.setRecalculate(1);
                coreFuelControl.save(fuelDatchik);
            }

        }

        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_NORM_REMOVE_REPORT)
    public ModelAndView removeNormReport(@RequestParam(value = "id", required = false) String mObjectIdStr,
                                         @RequestParam(value = "contract-id", required = false) String contractIdStr) {
        Long contractId = strToLong(contractIdStr, null);
        Long mObjectId = strToLong(mObjectIdStr, null);

        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_NORM + "?contract-id=" + contractId + "&id=" + mObjectId);

        if (mObjectId != null) {
            // Connect to Core Fuel Controller
            CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

            if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
                // Can work
            } else {
                modelAndView.addObject("errorCode", Errors.ERR_SERIAL_ACCESS_FUEL_DATCHIK);
                return modelAndView;
            }

            // Set to recalculate
            FuelNorm fuelNorm = coreFuelControl.getFuelNormByMobjectId(mObjectId);

            if (fuelNorm != null) {
                fuelNorm.setRecalculate(1);
                coreFuelControl.save(fuelNorm);
            }
        }

        return modelAndView;

    }

    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_CAN_REMOVE_REPORT)
    public ModelAndView removeCANReport(@RequestParam(value = "id", required = false) String mObjectIdStr,
                                        @RequestParam(value = "contract-id", required = false) String contractIdStr) {

        Long contractId = strToLong(contractIdStr, null);
        Long mObjectId = strToLong(mObjectIdStr, null);

        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_ADMIN_MOBJECT_EDIT_CAN + "?contract-id=" + contractId + "&id=" + mObjectId);
//
//        if (mObjectId != null) {
//            // Connect to Core Fuel Controller
//            CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();
//
//
//            if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
//                // Can work
//            } else {
//                modelAndView.addObject("errorCode", Errors.ERR_SERIAL_ACCESS_FUEL_DATCHIK);
//                return modelAndView;
//            }
//
//            // Set to recalculate
//            CANDevice CANDevice = coreFuelControl.getCANDeviceByMobjectId(mObjectId);
//
//            if (CANDevice!= null) {
//                CANDevice.setRecalculate(1);
//                coreFuelControl.save(CANDevice);
//            }
//        }
//
        return modelAndView;

    }

    /**
     * +
     * This function in Admin  Mobject remove report
     *
     * @param session
     * @param mobjectIdStr
     * @param cmd
     * @param contractIdStr
     * @param reportIdStr
     * @param fromDate
     * @return
     */
    @RequestMapping(value = URL_AMIN_MOBJECT_EDIT_REMOVE_REPORT)
    public ModelAndView formRemoveReport(HttpSession session,
                                         @RequestParam(value = "id", required = false) String mobjectIdStr,
                                         @RequestParam(value = "cmd", required = false) String cmd,
                                         @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                         @RequestParam(value = "report-id", required = false) String reportIdStr,
                                         @RequestParam(value = "from-date", required = false) String fromDate) {
        Long mobjectId = strToLong(mobjectIdStr, null);
        Long contractId = strToLong(contractIdStr, null);
        Long reportId = strToLong(reportIdStr, null);

        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminCustomerController.URL_ADMIN_CUSTOMERS_LIST);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_AMIN_MOBJECT_EDIT_REMOVE_REPORT);
//        modelAndView.addObject("pupopMsg", "");

        if (cmd != null && cmd.equals("delete") && mobjectId != null && fromDate != null && reportId != null &&
                MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")) {

            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            Date fDate = null;
            try {
                fDate = dateFormat.parse(fromDate);
            } catch (ParseException e) {

            }

            // move tpLastTime for this report, if needed
            int errorCode = 0;
            try {
                Timestamp timeStampFromDate = new Timestamp(fDate.getTime());
                //            DBTpLastTime dbTpLastTime = DBTpLastTime.getInstance();
                errorCode = coreMain.timeUpdateController.dbTpLastTime.updateByReportMobject(reportId, mobjectId, timeStampFromDate);
            } catch (Exception ex) {
                logger.error("coreMain.timeUpdateController.dbTpLastTime.updateByReportMobject");
                ex.getStackTrace();
            }

            // Check if report is FuelFilter, we need recalculate it
            // Datchik Recalculate
            if (reportId == TpLastTime.REPORTER_FUEL_FILTER) {
                // Connect to Core Fuel Controller
                CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

                if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
                    // Can work
                    // Set to recalculate
                    FuelDatchik fuelDatchik = coreFuelControl.getFuelDatchikByMobjectId(mobjectId);

                    if (fuelDatchik != null) {
                        fuelDatchik.setRecalculate(1);
                        coreFuelControl.save(fuelDatchik);
                    }
                }
            }

            // NORM Recalculate
            else if (reportId == TpLastTime.REPORTER_FUEL_CONSUMPTION_NORM) {
                // Connect to Core Fuel Controller
                CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

                if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
                    // Can work
                    // Set to recalculate
                    FuelNorm fuelNorm = coreFuelControl.getFuelNormByMobjectId(mobjectId);

                    if (fuelNorm != null) {
                        fuelNorm.setRecalculate(1);
                        coreFuelControl.save(fuelNorm);
                    }
                }
            }

            // CAN Recalculate
            else if (reportId == TpLastTime.REPORTER_CAN) {
                // Connect to Core Fuel Controller
                CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

                if (coreFuelControl != null && coreFuelControl.isHasAccess() && coreFuelControl.getCoreCanDatchik() != null) {
                    // Can work
                    // Set to recalculate
                    CanDatchik canDatchik = coreFuelControl.getCoreCanDatchik().getByMobjectId(mobjectId);

                    if (canDatchik != null) {
                        canDatchik.setRecalculate(1);
                        coreFuelControl.getCoreCanDatchik().save(canDatchik);
                    }
                }
            }

            String pupopMsg = (errorCode == 0) ? "alertMsgSuccess()" : "alertMsgFail()";
            modelAndView.addObject("pupopMsg", pupopMsg);

        }

        // If mobject ID exists, send to view
        if (mobjectId != null) {
            modelAndView.addObject("mobjectId", mobjectId);
            MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mobjectId);
            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                modelAndView.addObject("mObjectGPSUnitId", mObjectGPSUnit.getId());
            }
        }

        modelAndView.addObject("contractId", contractId);

        // Set tab ID
        modelAndView.addObject("menuActive", TAB_REMOVE_REPORT);

        return modelAndView;
    }


}
