package uzgps.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreGpsUnitBig;
import uz.netex.core.helper.CoreMobjectBig;
import uz.netex.core.helper.CoreTrackPoint;
import uz.netex.datatype.*;
import uz.netex.fuelcontrol.core.CoreFuelControl;
import uz.netex.fuelcontrol.database.tables.FuelDatchik;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.SystemConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.persistence.*;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.*;

import static uzgps.common.UZGPS_CONST.SYSTEM_SERVER_NAME_TSHTX;
import static uzgps.main.MainController.URL_CONTRACT_DETERMINED;

/**
 * Created by Zoxir on 25.01.14.
 *
 * @author Zoxir
 * @version 2.0
 * @since 10.06.2014
 */

@Controller
public class AdminCustomerController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public final static String URL_ADMIN_CUSTOMERS_LIST = "/admin/customers-list.htm";
    private final static String VIEW_ADMIN_CUSTOMERS_LIST = "admin/customers-list";
    private final static String URL_ADMIN_CUSTOMERS_MANAGE = "/admin/customers-manage.htm";
    private final static String VIEW_ADMIN_CUSTOMERS_MANAGE = "admin/customers-manage";

    public final static String URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST = "/admin/customers-trackers-relationship-list.htm";
    private final static String VIEW_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST = "admin/customers-trackers-relationship-list";
    private final static String URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_MANAGE = "/admin/customers-trackers-relationship-manage.htm";
    private final static String VIEW_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_MANAGE = "admin/customers-trackers-relationship-manage";


    @Autowired
    private AdminService adminService;

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private AdminReportService adminReportService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    CoreMain coreMain;


    /**
     * This function makes list of Customers. Using filter parameters from Session. If Session is empty uses default parameters. Works only if come from GET
     * Uses {@link uzgps.admin.AdminCustomerController#processAdminCustomers(Long, String, String, String, Integer)}
     *
     * @param session
     * @return
     * @throws ServletException
     * @throws ParseException
     * @throws IOException
     */
    @RequestMapping(value = URL_ADMIN_CUSTOMERS_LIST, method = RequestMethod.GET)
    public ModelAndView processAdminCustomersGet(HttpSession session,
                                                 @RequestParam(value = "page", required = false, defaultValue = "-1") String pageNumberGet)
            throws ServletException, ParseException, IOException {

        // Get Sessions
        Long operatorFilter = (Long) session.getAttribute("operator");
        String customerFilter = (String) session.getAttribute("customer");
        String showDeletedCustomer = (String) session.getAttribute("showDeletedCustomer");
        String txtSearch = (String) session.getAttribute("txtSearch");


        // Get page number
        Integer pageNumber = Converters.strToInt(pageNumberGet, -1);
        if (pageNumber < 0) {
            Integer pageNumberSession = (Integer) session.getAttribute("page");
            if (pageNumberSession != null) pageNumber = pageNumberSession;
        }
        if (pageNumber < 0) {
            pageNumber = 0;
        }


        if (operatorFilter == null && customerFilter == null && showDeletedCustomer == null && txtSearch == null)
            return processAdminCustomers(0L, "A", UZGPS_CONST.STATUS_ACTIVE, "", pageNumber);
        else
            return processAdminCustomers(operatorFilter, customerFilter, showDeletedCustomer, txtSearch, pageNumber);
    }


    /**
     * This function makes list of Customers. Using filter parameters. Works only if come from POST
     * Uses {@link uzgps.admin.AdminCustomerController#processAdminCustomers(Long, String, String, String, java.lang.Integer)}
     *
     * @param operatorFilter      Operator ID. If all operator needed, give "0"
     * @param customerFilter      Customer type. "O" - Organization, "I" - Individual, "A" - all customer types
     * @param showDeletedCustomer To show deleted customers, give "D". By default "A" is given.
     * @param txtSearch           Search by Customer name, Company name or Contract number.
     * @return ModelAndView returns.
     * @throws ServletException
     * @throws IOException
     * @throws ParseException
     */
    @RequestMapping(value = URL_ADMIN_CUSTOMERS_LIST, method = RequestMethod.POST)
    public ModelAndView processAdminCustomersPost(HttpSession session,
                                                  @RequestParam(value = "operator", required = false, defaultValue = "0") Long operatorFilter,
                                                  @RequestParam(value = "customer", required = false, defaultValue = "A") String customerFilter,
                                                  @RequestParam(value = "showDeletedCustomer", required = false, defaultValue = UZGPS_CONST.STATUS_ACTIVE) String showDeletedCustomer,
                                                  @RequestParam(value = "page", required = false, defaultValue = "0") Integer pageNumber,
                                                  @RequestParam(value = "txtSearch", required = false, defaultValue = "") String txtSearch) throws ServletException, ParseException, IOException {

        // Add Session
        session.setAttribute("operator", operatorFilter);
        session.setAttribute("customer", customerFilter);
        session.setAttribute("showDeletedCustomer", showDeletedCustomer);
        session.setAttribute("txtSearch", txtSearch);

        return processAdminCustomers(operatorFilter, customerFilter, showDeletedCustomer, txtSearch, pageNumber);
    }

    /**
     * This function makes list of Customers. Using filter parameters
     *
     * @param operatorFilter      Operator ID. If all operator needed, give "0"
     * @param customerFilter      Customer type. "O" - Organization, "I" - Individual, "A" - all customer types
     * @param showDeletedCustomer To show deleted customers, give "D". By default "A" is given.
     * @param txtSearch           Search by Customer name, Company name or Contract number.
     * @return ModelAndView returns.
     * @throws ServletException
     * @throws IOException
     * @throws ParseException
     */
    public ModelAndView processAdminCustomers(Long operatorFilter,
                                              String customerFilter,
                                              String showDeletedCustomer,
                                              String txtSearch,
                                              Integer pageNumber)
            throws ServletException, IOException, ParseException {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminCustomers operator={}, customer={}, txtSearch={}, showDeletedCustomer={},page={}",
                    operatorFilter, customerFilter, txtSearch, showDeletedCustomer, pageNumber);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_CUSTOMERS_LIST);

        User userDetails = MainController.getUser();


        if (pageNumber == null) pageNumber = 0;
        if (pageNumber < 0) pageNumber = 0;


        List<User> customerList;
        List<User> customerListCount;
        int custumeCount;
        if (userDetails.getRoleId() == UZGPS_CONST.USER_ROLE_SYSTEM_ADMINISTRATOR) {
            customerList = adminService.getCustomerAdminByFilterAndStatus(operatorFilter, customerFilter, txtSearch, UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN,
                    showDeletedCustomer, pageNumber);
            customerListCount = adminService.getCustomerAdminByFilterAndStatusCount(operatorFilter, customerFilter, txtSearch, UZGPS_CONST
                    .USER_ROLE_CUSTOMER_ADMIN, showDeletedCustomer, pageNumber);
            custumeCount = customerListCount.size();
            List<User> operatorList = adminService.getCustomerCareList(UZGPS_CONST.USER_STATUS_ACTIVE, UZGPS_CONST.USER_ROLE_CUSTOMER_CARE);
            modelAndView.addObject("operatorList", operatorList);

            Map<Long, String> hashMap = new HashMap<>();

            for (User operator : operatorList) {
                hashMap.put(operator.getId(), operator.getLogin());
            }

            for (User customer : customerList) {
                customer.setOperatorLogin(hashMap.get(customer.getManagerId()));
            }

            modelAndView.addObject("selectOperator", operatorFilter);
            modelAndView.addObject("showDeletedCustomer", showDeletedCustomer);
        } else {
            customerList = adminService.getCustomerAdminByManagerIdAndFilterAndStatus(customerFilter, txtSearch, UZGPS_CONST
                    .USER_ROLE_CUSTOMER_ADMIN, userDetails.getId(), showDeletedCustomer);
            custumeCount = customerList.size();
        }

        if (operatorFilter == null) operatorFilter = 0L;
        if (customerFilter == null) customerFilter = "A";

        if (txtSearch == null) txtSearch = "";

        int pageCount = (custumeCount + UZGPS_CONST.LIST_PER_PAGE - 1) / UZGPS_CONST.LIST_PER_PAGE;

        List<Integer> pagination = getPages(pageNumber, pageCount);
        modelAndView.addObject("customerList", customerList);
        modelAndView.addObject("contractType1", UZGPS_CONST.CONTRACT_TYPE_ORGANIZATION);
        modelAndView.addObject("contractType2", UZGPS_CONST.CONTRACT_TYPE_INDIVIDUAL);
        modelAndView.addObject("customer", customerFilter);
        modelAndView.addObject("pageNumber", pageNumber);
        modelAndView.addObject("pageCount", pageCount);
        modelAndView.addObject("pagination", pagination);
        modelAndView.addObject("paginationUrl", URL_ADMIN_CUSTOMERS_LIST + "?page=");
        modelAndView.addObject("txtSearch", txtSearch);

        modelAndView.addObject("managerColumnShowStatus", userDetails.getRoleId() == UZGPS_CONST.USER_ROLE_SYSTEM_ADMINISTRATOR ? 1 : 0);

        modelAndView.addObject("url_pattern", URL_ADMIN_CUSTOMERS_LIST);

        return modelAndView;
    }

    /**
     * This function manage Customers.
     *
     * @param cmd                         "save", "update", "edit", "remove" ,"status" ,"recovery"
     * @param status                      "active" - Activate Contract status, "suspended" - Deactivate Contract status
     * @param customerId                  CustomerID used for Edit
     * @param managerId                   Editor (Manager) ID
     * @param rCustomerIdList             Customer ID Array List for delete
     * @param login                       Customer UserName
     * @param password                    Customer Password
     * @param companyName                 Customer Company Name
     * @param contractDate                Contract registration day
     * @param contractNumber              Contract Number
     * @param contractType                Contract Type "O" - Organization, "I" - Individual
     * @param address                     Customer Company Address
     * @param adminSurname                Customer admin surname
     * @param adminName                   Customer admin name
     * @param adminMiddleName             Customer admin middle name
     * @param mobilePhone                 Customer Company Mobile phone
     * @param linePhone                   Customer Company line phone
     * @param maxUnitCount                Maximum number of used Units Count by Customer
     * @param maxUserCount                Maximum number of add User Count by Customer
     * @param maxStaffCount               Maximum number of add Staff Count by Customer
     * @param maxPoiCount                 Maximum number of used PoI Count by Customer
     * @param maxGeoFanceCount            Maximum number of used Geo Fence Count by Customer
     * @param description                 Customer company Description
     * @param contractId                  Customer Contract ID
     * @param monitoringAccess
     * @param trackerAccess
     * @param poiAccess
     * @param geozoneAccess
     * @param messageAccess
     * @param reportAccess
     * @param settingsAccess
     * @param settingsMapAccess
     * @param settingsMonitoringAccess
     * @param settingsObjectAccess
     * @param settingsGroupAccess
     * @param settingsStaffAccess
     * @param settingsUsersAccess
     * @param settingsNotificationsAccess
     * @param reportIdList
     * @param reportsAccessList
     * @param aclId
     * @return
     * @throws ServletException
     * @throws IOException
     * @throws ParseException
     */
    @RequestMapping(value = URL_ADMIN_CUSTOMERS_MANAGE)
    public ModelAndView processAdminCustomersManage(HttpSession session,
                                                    @RequestParam(value = "cmd", required = false) String cmd,
                                                    @RequestParam(value = "status", required = false) String status,
                                                    @RequestParam(value = "user-id", required = false) Long customerId,
                                                    @RequestParam(value = "manager-id", required = false) Long managerId,
                                                    @RequestParam(value = "r-user-id[]", required = false) Long[] rCustomerIdList,
                                                    @RequestParam(value = "customer-l", required = false) String login,
                                                    @RequestParam(value = "customer-p", required = false) String password,
                                                    @RequestParam(value = "company-name", required = false) String companyName,
                                                    @RequestParam(value = "contract-date", required = false) String contractDate,
                                                    @RequestParam(value = "contract-number", required = false) String contractNumber,
                                                    @RequestParam(value = "contract-type", required = false) String contractType,
                                                    @RequestParam(value = "current-account", required = false) String settlementAccount,
                                                    @RequestParam(value = "bank-details", required = false) String bankDetails,
                                                    @RequestParam(value = "okonh", required = false) String okonh,
                                                    @RequestParam(value = "inn", required = false) String inn,
                                                    @RequestParam(value = "contact", required = false) String contact,
                                                    @RequestParam(value = "contact-phone-mobile", required = false) String contactPhoneMobile,
                                                    @RequestParam(value = "contact-email", required = false) String contactEmail,
                                                    @RequestParam(value = "address", required = false) String address,
                                                    @RequestParam(value = "phone-mobile", required = false, defaultValue = "") String phoneMobile,
                                                    @RequestParam(value = "phone-line", required = false, defaultValue = "") String phoneLine,
                                                    @RequestParam(value = "email", required = false, defaultValue = "") String email,
                                                    @RequestParam(value = "admin-surname", required = false) String adminSurname,
                                                    @RequestParam(value = "admin-name", required = false) String adminName,
                                                    @RequestParam(value = "admin-middle-name", required = false) String adminMiddleName,
                                                    @RequestParam(value = "mobile-phone", required = false) String mobilePhone,
                                                    @RequestParam(value = "line-phone", required = false) String linePhone,
                                                    @RequestParam(value = "max-unit-count", required = false) Long maxUnitCount,
                                                    @RequestParam(value = "max-user-count", required = false) Long maxUserCount,
                                                    @RequestParam(value = "max-staff-count", required = false) Long maxStaffCount,
                                                    @RequestParam(value = "max-poi-count", required = false) Long maxPoiCount,
                                                    @RequestParam(value = "max-geo-fance-count", required = false) Long maxGeoFanceCount,
                                                    @RequestParam(value = "max-report-count", required = false) Long maxReportCount,
                                                    @RequestParam(value = "max-email-count", required = false) Long maxEmailCount,
                                                    @RequestParam(value = "max-sms-count", required = false) Long maxSmsCount,
                                                    @RequestParam(value = "max-sms-cmd-count", required = false) Long maxSmsCmdCount,
                                                    @RequestParam(value = "description", required = false) String description,
                                                    @RequestParam(value = "contract-id", required = false) Long contractId,
                                                    @RequestParam(value = "map-access", required = false) Integer mapAccess,
                                                    @RequestParam(value = "monitoring-access", required = false) Integer monitoringAccess,
                                                    @RequestParam(value = "tracker-access", required = false) Integer trackerAccess,
                                                    @RequestParam(value = "poi-access", required = false) Integer poiAccess,
                                                    @RequestParam(value = "geo-zone-access", required = false) Integer geozoneAccess,
                                                    @RequestParam(value = "message-access", required = false) Integer messageAccess,
                                                    @RequestParam(value = "report-access", required = false) Integer reportAccess,
                                                    @RequestParam(value = "settings-access", required = false) Integer settingsAccess,
                                                    @RequestParam(value = "settings-map-access", required = false) Integer settingsMapAccess,
                                                    @RequestParam(value = "settings-monitoring-access", required = false) Integer settingsMonitoringAccess,
                                                    @RequestParam(value = "settings-object-access", required = false) Integer settingsObjectAccess,
                                                    @RequestParam(value = "settings-group-access", required = false) Integer settingsGroupAccess,
                                                    @RequestParam(value = "settings-staff-access", required = false) Integer settingsStaffAccess,
                                                    @RequestParam(value = "settings-users-access", required = false) Integer settingsUsersAccess,
                                                    @RequestParam(value = "settings-notifications-access", required = false) Integer settingsNotificationsAccess,
                                                    @RequestParam(value = "routing-access", required = false) Integer routingAccess,
                                                    @RequestParam(value = "track-statistics-access", required = false) Integer trackStatisticsAccess,
                                                    @RequestParam(value = "report-id[]", required = false) Long[] reportIdList,
                                                    @RequestParam(value = "reports-access[]", required = false) Long[] reportsAccessList,
                                                    @RequestParam(value = "acl-id[]", required = false) Long[] aclId)
            throws ServletException, IOException, ParseException {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminCustomersManage cmd={}, status={}, customer-id={}, manager-id={}, login={}, password={}  company-name={}, contract-date={}, contract-number={}, contact-type={}, address={}, admin-surname={}, admin-name={}, admin-middle-name={}, mobile-phone={}, line-phone={}, max-unit-count={}, max-user-count={}, max-staff-count={}, max-poi-count={}, max-poigeo-fance-count={}, description={}, r-manager-id[]={}",
                    cmd, status, customerId, managerId, login, password, companyName, contractDate, contractNumber, contractType, address, adminSurname, adminName, adminMiddleName, mobilePhone, linePhone, maxUnitCount, maxUserCount, maxStaffCount, maxPoiCount, maxGeoFanceCount, description, rCustomerIdList);
        }

        if (cmd != null && cmd.equalsIgnoreCase("goToMap")) {

            Contract contract = adminService.getContractById(contractId);

            if (contract != null) {
                MainController.replaceUserInSession(contract, customerId, MainController.getUser().getPhoto(), null, null, null);
                MainController.setUserContractId(contractId, session);
                MainController.setUserContract(contract, session);

                session.removeAttribute(MainController.SESSION_USER_ACCESS_LIST);
                session.removeAttribute(MainController.SESSION_CONTRACT_SETTINGS);

                User customerAdmin = adminService.getCustomerAdminById(customerId);

                if (customerAdmin != null) {
                    customerAdmin.setContract(contract);
                    MainController.replaceCustomerAdminInSession(customerAdmin);
                } else {
                    return new ModelAndView("redirect:" + "../" + URL_CONTRACT_DETERMINED);
                }
            }

            return new ModelAndView("redirect:" + MainController.URL_MAIN);
        }

        return null;
    }

    /**
     * @param contractId
     * @return
     * @throws ServletException
     * @throws IOException
     * @throws ParseException
     */
    @RequestMapping(value = URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST)
    public ModelAndView processAdminCustomersTrackersRelationshipList(@RequestParam(value = "contract-id", required = false) Long contractId,
                                                                      @RequestParam(value = "error", required = false) Long errorId)
            throws ServletException, IOException, ParseException {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminCustomersTrackersRelationshipList contract_id={}", contractId);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST);

        List<MObjectGPSUnit> mObjectGPSUnits = adminService.getMObjectGPSUnitByContractId(contractId);
        modelAndView.addObject("mObjectGPSUnits", mObjectGPSUnits);
        modelAndView.addObject("mObjectGPSUnitsCount", (mObjectGPSUnits != null) ? mObjectGPSUnits.size() : 0);

        Contract contract = adminService.getContractById(contractId);
        modelAndView.addObject("contractId", contractId);
        if (contract != null) {
            modelAndView.addObject("maxUnitCont", contract.getActiveMaxUnitCount());
            if (contract.getCompany() != null)
                modelAndView.addObject("companyName", contract.getCompany().getName());
            else
                modelAndView.addObject("companyName", "");
        } else {
            modelAndView.addObject("maxUnitCont", 0);
            modelAndView.addObject("companyName", "");
        }


        // Send error Id
        if (errorId != null && errorId > 0)
            modelAndView.addObject("errorId", errorId);

        modelAndView.addObject("url_pattern", URL_ADMIN_CUSTOMERS_LIST);

        return modelAndView;
    }

    @RequestMapping(value = URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_MANAGE)
    public ModelAndView processAdminCustomersTrackersRelationshipManage(@RequestParam(value = "cmd", required = false) String cmd,
                                                                        @RequestParam(value = "gps-unit-id", required = false) Long gpsUnitId,
                                                                        @RequestParam(value = "id", required = false) Long mObjectGPSUnitId,
                                                                        @RequestParam(value = "r-id[]", required = false) Long[] rMObjectGPSUnitIdList,
                                                                        @RequestParam(value = "sim-phone", required = false) String simPhone,
                                                                        @RequestParam(value = "sensor-speed", required = false) Short sensorSpeed,
                                                                        @RequestParam(value = "sensor-fuel", required = false) Short sensorFuel,
                                                                        @RequestParam(value = "sensor-reserve", required = false) Short sensorReserve,
                                                                        @RequestParam(value = "tariff", required = false) Long tariff,
                                                                        @RequestParam(value = "status", required = false) String status,
                                                                        @RequestParam(value = "vehicle-brand", required = false) String vehicleBrand,
                                                                        @RequestParam(value = "car-number", required = false) String carNumber,
                                                                        @RequestParam(value = "contract-id", required = false) Long contractId,
                                                                        @RequestParam(value = "timeMin", required = false) Integer timeMin,
                                                                        @RequestParam(value = "timeBig", required = false) Integer timeBig,
                                                                        @RequestParam(value = "timeLost", required = false) Integer timeLost,
                                                                        @RequestParam(value = "distanceMin", required = false) Integer distanceMin,
                                                                        @RequestParam(value = "distanceMax", required = false) Integer distanceBig)
            throws ServletException, IOException, ParseException {

        if (logger.isDebugEnabled()) {
            logger.debug("processAdminCustomersTrackersRelationshipManage contract-id={}, cmd={}, gps-unit-id={}, sim-phone={}, sensor-speed={}, sensor-fuel={}, sensor-reserve={}, tariff={}, status={}, vehicle-brand={}, car-number={}, id={}, r-id[]={},timeMin={},distanceMin={},distanceMax={},timeBig={},timeLost={}",
                    contractId, cmd, gpsUnitId, simPhone, sensorSpeed, sensorFuel, sensorReserve, tariff, status, vehicleBrand, carNumber, mObjectGPSUnitId, rMObjectGPSUnitIdList, timeMin, distanceBig, distanceMin, timeBig, timeLost);
        }

        ModelAndView modelAndView = null;

        if (cmd != null) {
            if (cmd.equalsIgnoreCase("save")) {
                // New admin customer added

                if (!simPhone.equalsIgnoreCase("") && gpsUnitId != null && gpsUnitId > 0) {

                    String simPhoneWritten = simPhone;
                    simPhone = simPhone.replace("_", "");
                    simPhone = simPhone.trim();

                    if (simPhone.length() == 18) {
//

                        timeMin = getCorrectedTimeBig(timeMin);
                        timeBig = getCorrectTimeMax(timeBig);
                        timeLost = getCorrectTimeLost(timeLost);
                        distanceMin = getCorrectDistanceMin(distanceMin);
                        distanceBig = getCorrectDistanceBig(distanceBig, distanceMin);


                        Group group = adminService.getGroupById(0L);
                        Contract contract = adminService.getContractById(contractId);

                        Sim sim = new Sim();
                        sim.setSimPhone(simPhone);
                        sim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        sim.setRegDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveSim(sim);

                        GPSUnit gpsUnit = adminService.getGPSUniteById(gpsUnitId);
                        gpsUnit.setBlock(status);
                        gpsUnit.setSim1(sim);
                        adminService.saveGPSUnit(gpsUnit);

                        MObject mObject = new MObject();
                        mObject.setGroup(group);
                        mObject.setContract(contract);
                        mObject.setmObjectName(gpsUnit.getName());
                        mObject.setmObjectType(vehicleBrand);

                        mObject.setmObjectPlateNumber(carNumber);
                        mObject.setDefaultIcon(true);
                        mObject.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        mObject.setRegDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveMObject(mObject);

                        MObjectType mObjectType;
                        if (SystemConfiguration.getSystemServer().equals(SYSTEM_SERVER_NAME_TSHTX)) {
                            mObjectType = settingsService.getObjectTypeById(UZGPS_CONST.MOBJECT_TYPE_TSHTX_DEFAULT_TYPE);
                        } else {
                            mObjectType = settingsService.getObjectTypeById(UZGPS_CONST.MOBJECT_TYPE_DEFAULT_TYPE);
                        }

                        MObjectState mObjectState = settingsService.getObjectStateById(UZGPS_CONST.MOBJECT_STATE_DEFAULT_TYPE);
                        MObjectAppointment mObjectAppointment = settingsService.getObjectAppointmentById(UZGPS_CONST.MOBJECT_APPOINTMENT_DEFAULT);

                        MObjectSettings mObjectSettings = new MObjectSettings();
                        mObjectSettings.setmObject(mObject);
                        mObjectSettings.setDefaultTrackColor("#ff0000");
                        mObjectSettings.setSpeedColor1("#1cf0f0");
                        mObjectSettings.setSpeedColor2("#3442f4");
                        mObjectSettings.setSpeedColor3("#28ec50");
                        mObjectSettings.setSpeedColor4("#ff25e5");
                        mObjectSettings.setSpeedColor5("#ffa500");
                        mObjectSettings.setSpeedColor6("#ff0000");
                        mObjectSettings.setSpeedValue1(30L);
                        mObjectSettings.setSpeedValue2(50L);
                        mObjectSettings.setSpeedValue3(70L);
                        mObjectSettings.setSpeedValue4(90L);
                        mObjectSettings.setSpeedValue5(100L);
                        mObjectSettings.setSpeedValue6(120L);
                        mObjectSettings.setLabelSize(10L);
                        mObjectSettings.setMaxSpeed(70L);
                        mObjectSettings.setOnlineTime(300L);
                        mObjectSettings.setParkingTime(600L);
                        mObjectSettings.setmObjectType(mObjectType);
                        mObjectSettings.setmObjectState(mObjectState);
                        mObjectSettings.setmObjectAppointment(mObjectAppointment);
                        mObjectSettings.setRegDate(new Timestamp(System.currentTimeMillis()));
                        mObjectSettings.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        adminService.saveMObjectSettings(mObjectSettings);

                        if (gpsUnit.getIsMobile() != null && gpsUnit.getIsMobile() == 1) {
                            MobileTrackerSettings mobileTrackerSettings = new MobileTrackerSettings();
                            mobileTrackerSettings.setmObjectId(mObject.getId());
                            mobileTrackerSettings.setMobileSerial(gpsUnit.getImei());
                            mobileTrackerSettings.setHasPassword(UZGPS_CONST.MTRACKER_DEFAULT_SETTINGS_HAS_PASSWORD);
                            mobileTrackerSettings.setPassword(UZGPS_CONST.MTRACKER_DEFAULT_SETTINGS_PASSWORD);
                            mobileTrackerSettings.setLocationUpdateTime(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_TIME);
                            mobileTrackerSettings.setLocationUpdateDistance(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_DISTANCE);
                            mobileTrackerSettings.setLocationUpdateAccuracy(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_ACCURACY);
                            mobileTrackerSettings.setLocationUpdateAngle(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_ANGLE);
                            mobileTrackerSettings.setShouldChangeStatus(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_STATUS_CHANGE);
                            mobileTrackerSettings.setRecordLimit(UZGPS_CONST.MTRACKER_DEFAULT_RECORD_LIMIT);
                            mobileTrackerSettings.setLocationSendTime(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_SEND_TIME);
                            mobileTrackerSettings.setShouldSend3G(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_SEND_3G);
                            mobileTrackerSettings.setShouldSendWiFi(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_SEND_WIFI);
                            mobileTrackerSettings.setTrackLength(UZGPS_CONST.MTRACKER_DEFAULT_TRACK_LENGTH);
                            mobileTrackerSettings.setMapType(UZGPS_CONST.MTRACKER_DEFAULT_MAP_TYPE);
                            mobileTrackerSettings.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                            mobileTrackerSettings.setRegDate(new Timestamp(System.currentTimeMillis()));

                            settingsService.saveMobileTrackerSettings(mobileTrackerSettings);
                        }

                        MObjectNotifications mObjectNotifications = mobjectNotificationNewDefault(mObject.getId());
                        mObjectNotifications.setRegDate(new Timestamp(System.currentTimeMillis()));
                        mObjectNotifications.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        adminService.saveMObjectNotifications(mObjectNotifications);

                        MObjectGPSUnit mObjectGPSUnit = new MObjectGPSUnit();
                        mObjectGPSUnit.setmObject(mObject);
                        mObjectGPSUnit.setGpsUnit(gpsUnit);
                        mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        mObjectGPSUnit.setRegDate(new Timestamp(System.currentTimeMillis()));
                        mObjectGPSUnit.setMovementStatus(sensorSpeed);
                        mObjectGPSUnit.setEngineOnStatus(sensorFuel);
                        mObjectGPSUnit.setDatStatus(sensorReserve);
                        mObjectGPSUnit.setTimeMin(timeMin);
                        mObjectGPSUnit.setTimeBig(timeBig);
                        mObjectGPSUnit.setTimeLost(timeLost);
                        mObjectGPSUnit.setDistanceMin(distanceMin);
                        mObjectGPSUnit.setDistanceBig(distanceBig);
                        mObjectGPSUnit.setOnlineStatus((short) 1);
                        mObjectGPSUnit.setSatellitesStatus((short) 1);
                        adminService.saveMObjectGPSUnit(mObjectGPSUnit);

                        GPSUnitSim gpsUnitSim = new GPSUnitSim();
                        gpsUnitSim.setSim(sim);
                        gpsUnitSim.setGpsUnit(gpsUnit);
                        gpsUnitSim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        gpsUnitSim.setRegDate(new Timestamp(System.currentTimeMillis()));

                        adminService.saveGPSUnitSim(gpsUnitSim);

                        // Save Mobject count for Contract
                        contract = adminService.getContractById(contractId);
                        contract.setExistUnitCount(adminService.getMobjectCountByContractId(contractId));
                        adminService.saveContract(contract);

                        // Update core Cloud : GpsUnitBig and Mobject must be updated
                        coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                        coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                        coreMain.coreUpdater.updateMobjectNotificationsById(mObjectNotifications.getId());
                        // coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    } else {
                        // Sim error
                        // tracker select error
                        modelAndView = new ModelAndView(VIEW_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_MANAGE);

                        MObjectGPSUnit mObjectGPSUnit = new MObjectGPSUnit();
                        mObjectGPSUnit.setGpsUnit(new GPSUnit());
                        mObjectGPSUnit.getGpsUnit().setSim1(new Sim());
                        mObjectGPSUnit.getGpsUnit().getSim1().setSimPhone(simPhoneWritten);

                        modelAndView.addObject("mObjectGPSUnit", mObjectGPSUnit);
                        modelAndView.addObject("cmd", "save");
                        modelAndView.addObject("contractId", contractId);
                        modelAndView.addObject("errorSim", 1);

                        List<GPSUnit> gpsUnitList = adminService.getGPSUniteAllFreeByStatus(UZGPS_CONST.STATUS_ACTIVE, mObjectGPSUnit.getGpsUnit().getImei());
                        modelAndView.addObject("gpsUnitList", gpsUnitList);
                        modelAndView.addObject("gpsUnitListSize", (gpsUnitList != null) ? gpsUnitList.size() : 0);

                        return modelAndView;
                    }
                } else {
                    modelAndView = new ModelAndView("redirect:" + URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId + "&error=1");
                }
                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId);

            } else if (cmd.equalsIgnoreCase("status")) {

                GPSUnit gpsUnit = adminService.getGPSUniteById(gpsUnitId);

                if (status.equalsIgnoreCase("active")) gpsUnit.setBlock(UZGPS_CONST.STATUS_UNBLOCK);
                else gpsUnit.setBlock(UZGPS_CONST.STATUS_BLOCK);

                gpsUnit.setModDate(new Timestamp(System.currentTimeMillis()));
                adminService.saveGPSUnit(gpsUnit);

                // Update core Cloud
                coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                coreMain.coreUpdater.updateMobjectBigByUnitId(gpsUnit.getId());


                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId);
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rMObjectGPSUnitId : rMObjectGPSUnitIdList) {


                    Timestamp modTime = new Timestamp(System.currentTimeMillis());

                    MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitById(rMObjectGPSUnitId);
                    mObjectGPSUnit.setExpDate(modTime);
                    mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_DELETE);


                    GPSUnit gpsUnit = mObjectGPSUnit.getGpsUnit();
                    if (gpsUnit != null) {
                        gpsUnit.setBlock(UZGPS_CONST.STATUS_BLOCK);
                        adminService.saveGPSUnit(gpsUnit);


                        Sim sim = gpsUnit.getSim1();
                        if (sim != null) {
                            sim.setExpDate(modTime);
                            sim.setStatus(UZGPS_CONST.STATUS_DELETE);
                            adminService.saveSim(sim);

                            adminService.deleteAllGPSUnitSimByUnitId(gpsUnit.getId());

//                            GPSUnitSim gpsUnitSim = adminService.getGPSUnitSimBySimId(sim.getId());
//                            gpsUnitSim.setStatus(UZGPS_CONST.STATUS_DELETE);
//                            gpsUnitSim.setExpDate(new Timestamp(System.currentTimeMillis()));
//                            adminService.saveGPSUnitSim(gpsUnitSim);
                        }
                    }

                    MObject mObject = mObjectGPSUnit.getmObject();
                    if (mObject != null) {
                        mObject.setStatus(UZGPS_CONST.STATUS_DELETE);
                        mObject.setModDate(modTime);
                        mObject.getContract().setExistUnitCount(mObject.getContract().getExistUnitCount() - 1);
                        adminService.saveMObjectGPSUnit(mObjectGPSUnit);

                    }

                    if (gpsUnit != null) {
                        // Update core Cloud
                        coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    }

                    if (mObject != null) {
                        // Update core Cloud
                        coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                    }

                }

                // Save Mobject count
                Contract contract = adminService.getContractById(contractId);
                contract.setExistUnitCount(adminService.getMobjectCountByContractId(contractId));
                adminService.saveContract(contract);


                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId);
            } else if (cmd.equalsIgnoreCase("edit")) {
                modelAndView = new ModelAndView(VIEW_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_MANAGE);

                MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitById(mObjectGPSUnitId);
                modelAndView.addObject("mObjectGPSUnit", mObjectGPSUnit);
                modelAndView.addObject("cmd", "update");
                modelAndView.addObject("contractId", contractId);

                List<GPSUnit> gpsUnitList = adminService.getGPSUniteAllFreeByStatus(UZGPS_CONST.STATUS_ACTIVE, mObjectGPSUnit.getGpsUnit().getImei());
                modelAndView.addObject("gpsUnitList", gpsUnitList);
                modelAndView.addObject("gpsUnitListSize", (gpsUnitList != null) ? gpsUnitList.size() : 0);

                modelAndView.addObject("url_pattern", URL_ADMIN_CUSTOMERS_LIST);
            } else if (cmd.equalsIgnoreCase("update")) {

                MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitById(mObjectGPSUnitId);

                Sim sim = mObjectGPSUnit.getGpsUnit().getSim1();

                if (mObjectGPSUnit.getGpsUnit() != null
                        && mObjectGPSUnit.getGpsUnit().getId() != null
                        && !mObjectGPSUnit.getGpsUnit().getId().equals(gpsUnitId)) {
                    mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                    mObjectGPSUnit.setExpDate(new Timestamp(System.currentTimeMillis()));
                    mObjectGPSUnit.getGpsUnit().setBlock(UZGPS_CONST.STATUS_BLOCK);
                    adminService.saveMObjectGPSUnit(mObjectGPSUnit);

                    if (simPhone != null && !simPhone.equalsIgnoreCase(sim.getSimPhone())) {
                        sim.setStatus(UZGPS_CONST.STATUS_DELETE);
                        sim.setExpDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveSim(sim);

                        GPSUnitSim gpsUnitSim = adminService.getGPSUnitSimBySimId(sim.getId());
                        gpsUnitSim.setStatus(UZGPS_CONST.STATUS_DELETE);
                        gpsUnitSim.setExpDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveGPSUnitSim(gpsUnitSim);

                        sim = new Sim();
                        sim.setSimPhone(simPhone);
                        sim.setRegDate(new Timestamp(System.currentTimeMillis()));
                        sim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        adminService.saveSim(sim);
                    } else {
                        GPSUnitSim gpsUnitSim = adminService.getGPSUnitSimBySimId(sim.getId());
                        gpsUnitSim.setStatus(UZGPS_CONST.STATUS_DELETE);
                        gpsUnitSim.setExpDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveGPSUnitSim(gpsUnitSim);
                    }

                    GPSUnit gpsUnit = adminService.getGPSUniteById(gpsUnitId);
                    gpsUnit.setBlock(status);
                    gpsUnit.setSim1(sim);
                    adminService.saveGPSUnit(gpsUnit);

                    GPSUnitSim gpsUnitSimNew = new GPSUnitSim();
                    gpsUnitSimNew.setGpsUnit(gpsUnit);
                    gpsUnitSimNew.setSim(sim);
                    gpsUnitSimNew.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                    gpsUnitSimNew.setRegDate(new Timestamp(System.currentTimeMillis()));
                    adminService.saveGPSUnitSim(gpsUnitSimNew);

                    MObject mObject = mObjectGPSUnit.getmObject();

                    mObjectGPSUnit = new MObjectGPSUnit();
                    mObjectGPSUnit.setmObject(mObject);
                    mObjectGPSUnit.setGpsUnit(gpsUnit);
                    mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_ACTIVE);

                    mObjectGPSUnit.setRegDate(new Timestamp(System.currentTimeMillis()));
                    mObjectGPSUnit.setOnlineStatus((short) 1);
                    mObjectGPSUnit.setSatellitesStatus((short) 1);
                } else {
                    if (simPhone != null && !simPhone.equalsIgnoreCase(sim.getSimPhone())) {
                        sim.setStatus(UZGPS_CONST.STATUS_DELETE);
                        sim.setExpDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveSim(sim);

                        GPSUnitSim gpsUnitSim = adminService.getGPSUnitSimBySimId(sim.getId());
                        gpsUnitSim.setStatus(UZGPS_CONST.STATUS_DELETE);
                        gpsUnitSim.setExpDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveGPSUnitSim(gpsUnitSim);

                        sim = new Sim();
                        sim.setSimPhone(simPhone);
                        sim.setRegDate(new Timestamp(System.currentTimeMillis()));
                        sim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        adminService.saveSim(sim);
                        mObjectGPSUnit.getGpsUnit().setSim1(sim);

                        GPSUnitSim gpsUnitSimNew = new GPSUnitSim();
                        gpsUnitSimNew.setGpsUnit(mObjectGPSUnit.getGpsUnit());
                        gpsUnitSimNew.setSim(sim);
                        gpsUnitSimNew.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        gpsUnitSimNew.setRegDate(new Timestamp(System.currentTimeMillis()));
                        adminService.saveGPSUnitSim(gpsUnitSimNew);
                    }
                }


                timeMin = getCorrectedTimeBig(timeMin);
                timeBig = getCorrectTimeMax(timeBig);
                timeLost = getCorrectTimeLost(timeLost);
                distanceMin = getCorrectDistanceMin(distanceMin);
                distanceBig = getCorrectDistanceBig(distanceBig, distanceMin);

                MObject mObject = mObjectGPSUnit.getmObject();
                mObjectGPSUnit.setMovementStatus(sensorSpeed);
                mObjectGPSUnit.setEngineOnStatus(sensorFuel);
                mObjectGPSUnit.setDatStatus(sensorReserve);
                mObjectGPSUnit.setTimeMin(timeMin);
                mObjectGPSUnit.setTimeBig(timeBig);
                mObjectGPSUnit.setTimeLost(timeLost);
                mObjectGPSUnit.setDistanceMin(distanceMin);
                mObjectGPSUnit.setDistanceBig(distanceBig);
                mObjectGPSUnit.getmObject().setmObjectPlateNumber(carNumber);
                mObjectGPSUnit.getmObject().setmObjectType(vehicleBrand);

                adminService.saveMObjectGPSUnit(mObjectGPSUnit);

                // Save Mobject count fo Contract
                Contract contract = adminService.getContractById(contractId);
                contract.setExistUnitCount(adminService.getMobjectCountByContractId(contractId));
                adminService.saveContract(contract);

                // Update core Cloud
                // coreMain.coreResetMobject(mObjectGPSUnit.getmObject().getId());
                if (mObjectGPSUnit.getGpsUnit() != null)
                    coreMain.coreUpdater.updateGpsUnit(mObjectGPSUnit.getGpsUnit().getId());
                if (mObjectGPSUnit.getmObject() != null)
                    coreMain.coreUpdater.updateMobjectBigById(mObjectGPSUnit.getmObject().getId());

                modelAndView = new ModelAndView("redirect:" + URL_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_LIST + "?contract-id=" + contractId);
            } else if (cmd.equalsIgnoreCase("core-gpsunit")) {

                modelAndView = new ModelAndView("admin/ajax-api");
                String apiText = "";

                apiText += "gpsUnitBig";
                apiText += "<br>";
                GpsUnitBig gpsUnitBig = CoreGpsUnitBig.getInstance().getById(mObjectGPSUnitId);
                apiText += gpsUnitBig;

                apiText += "gpsUnitBig (id = -20)";
                apiText += "<br>";
                if (mObjectGPSUnitId != null && mObjectGPSUnitId == -20) {
                    List<GpsUnitBig> gpsUnitBigList = CoreGpsUnitBig.getInstance().getGpsUnitBigList();
                    apiText += gpsUnitBigList;
                }

                apiText += "<br><br><br>";

                apiText += "mobjectBig";
                apiText += "<br>";
                MobjectBig mobjectBig = CoreMobjectBig.getInstance().getById(mObjectGPSUnitId);
                apiText += mobjectBig;

                apiText += "mobjectBig List (id = -10)";
                apiText += "<br>";
                if (mObjectGPSUnitId != null && mObjectGPSUnitId == -10) {
                    List<MobjectBig> mobjectBigList = CoreMobjectBig.getInstance().getMobjectBigList();
                    apiText += mobjectBigList;
                }

                apiText += "<br><br><br>";

                apiText += "getMobjectTracksListByContract mobjectTracksList";
                apiText += "<br>";
                List<MobjectTracks> mobjectTracksList = coreMain.getMobjectTracksListByContract(mObjectGPSUnitId, 0L);
                apiText += mobjectTracksList;

                apiText += "<br><br><br>";

                apiText += "getMobjectTracksListByUser mobjectTracksList";
                apiText += "<br>";
                mobjectTracksList = coreMain.getMobjectTracksListByUser(mObjectGPSUnitId, 0L);
                apiText += mobjectTracksList;

                apiText += "<br><br><br>";

                apiText += "getLastPointDataHelperByUnitId lastPointDataHelper";
                apiText += "<br>";
                CoreGpsUnitBig coreGpsUnitBig = CoreGpsUnitBig.getInstance();
                LastPointDataHelper lastPointDataHelper = null;
//                if (coreGpsUnitBig != null)
//                    lastPointDataHelper = coreMoGpsUnitBig.getLastPointDataHelperByMobjectId(mObjectGPSUnitId);
                apiText += lastPointDataHelper;

                apiText += "<br><br><br>";

                apiText += "getGpsTrackPointsByUnitId gpsTrackPoints";
                apiText += "<br>";
                ArrayList<GPSTrackPoint> gpsTrackPoints = CoreTrackPoint.getInstance().getGpsTrackPointsByMobjectId(mObjectGPSUnitId);
                apiText += gpsTrackPoints;

                apiText += "getMobjectTracksListByUser mobjectTracksList";
                // Connect to Core Fuel Controller
                CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();
                apiText += "<br>coreFuelControl : " + coreFuelControl;

                apiText += "<br>By Mobject : ";
                FuelDatchik fuelDatchikLocal = coreFuelControl.getFuelDatchikByMobjectId(mObjectGPSUnitId);
                apiText += fuelDatchikLocal;

                apiText += "<br>By ID : ";
                fuelDatchikLocal = coreFuelControl.getFuelDatchikById(mObjectGPSUnitId);
                apiText += fuelDatchikLocal;

                apiText += "<br><br><br>";


                modelAndView.addObject("text", apiText);
            }
        } else {
            modelAndView = new ModelAndView(VIEW_ADMIN_CUSTOMERS_TRACKERS_RELATIONSHIP_MANAGE);

            List<GPSUnit> gpsUnitList = adminService.getGPSUniteAllFreeByStatus(UZGPS_CONST.STATUS_ACTIVE, "");
            modelAndView.addObject("gpsUnitList", gpsUnitList);
            modelAndView.addObject("gpsUnitListSize", (gpsUnitList != null) ? gpsUnitList.size() : 0);

            MObjectGPSUnit mObjectGPSUnit = new MObjectGPSUnit();
            MObject mObject = new MObject();
            mObjectGPSUnit.setTimeMin(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_MIN);
            mObjectGPSUnit.setTimeBig(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_BIG);
            mObjectGPSUnit.setTimeLost(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_LOST);
            mObjectGPSUnit.setDistanceMin(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_DISTANCE_MIN);
            mObjectGPSUnit.setDistanceBig(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_DISTANCE_BIG);
            mObjectGPSUnit.setmObject(mObject);


            modelAndView.addObject("contractId", contractId);
            modelAndView.addObject("cmd", "save");
            modelAndView.addObject("url_pattern", URL_ADMIN_CUSTOMERS_LIST);
            modelAndView.addObject("mObjectGPSUnit", mObjectGPSUnit);
        }


        return modelAndView;
    }

    /**
     * Generates new Mobject Notifications with Default Values
     *
     * @param mObjectId Mobject ID
     * @return MObjectNotification
     */
    private MObjectNotifications mobjectNotificationNewDefault(Long mObjectId) {
        MObjectNotifications mObjectNotifications = new MObjectNotifications();
        mObjectNotifications.setmObjectId(mObjectId);
        mObjectNotifications.setPanicButton(true);
        mObjectNotifications.setMinSpeed(20);
        mObjectNotifications.setMaxSpeed(70);
        mObjectNotifications.setSendSms(false);
        mObjectNotifications.setSendMail(false);
        mObjectNotifications.setPopUpWindow(true);
        mObjectNotifications.setnPopUpWindow(true);
        mObjectNotifications.setRegisterDatabase(false);
        mObjectNotifications.setRegisterDatabaseViolation(false);

        mObjectNotifications.setuSos(true);
        mObjectNotifications.setuEngine(false);
        mObjectNotifications.setuSpeedMin(false);
        mObjectNotifications.setuSpeedMax(false);
        mObjectNotifications.setuOnline(false);
        mObjectNotifications.setuStaff(false);
        mObjectNotifications.setuSettings(false);
        mObjectNotifications.setuPoi(true);
        mObjectNotifications.setuZoi(true);

        mObjectNotifications.setsSos(true);
        mObjectNotifications.setsEngine(true);
        mObjectNotifications.setsSpeedMin(false);
        mObjectNotifications.setsSpeedMax(true);
        mObjectNotifications.setsOnline(false);
        mObjectNotifications.setsStaff(true);
        mObjectNotifications.setsSettings(true);
        mObjectNotifications.setsPoi(true);
        mObjectNotifications.setsZoi(true);

        mObjectNotifications.setnSos(false);
        mObjectNotifications.setnEngine(false);
        mObjectNotifications.setnSpeedMin(false);
        mObjectNotifications.setnSpeedMax(true);
        mObjectNotifications.setnOnline(false);
        //mObjectNotifications.setnStaff(false);
        //mObjectNotifications.setnSettings(false);
        mObjectNotifications.setnPoi(false);
        mObjectNotifications.setnZoi(false);

        mObjectNotifications.seteSos(false);
        mObjectNotifications.seteEngine(false);
        mObjectNotifications.seteSpeedMin(false);
        mObjectNotifications.seteSpeedMax(false);
        mObjectNotifications.seteOnline(false);
        mObjectNotifications.seteStaff(false);
        mObjectNotifications.seteSettings(false);
        mObjectNotifications.setePoi(false);
        mObjectNotifications.seteZoi(false);

        mObjectNotifications.setmSos(false);
        mObjectNotifications.setmEngine(false);
        mObjectNotifications.setmSpeedMin(false);
        mObjectNotifications.setmSpeedMax(false);
        mObjectNotifications.setmOnline(false);
        mObjectNotifications.setmStaff(false);
        mObjectNotifications.setmSettings(false);
        mObjectNotifications.setmPoi(false);
        mObjectNotifications.setmZoi(false);

        return mObjectNotifications;
    }

    private Integer getCorrectedTimeBig(Integer timeMin) {
        if (timeMin == null) {
            timeMin = UZGPS_CONST.COSTOMER_TRACKER_TBIG_MIN;
        } else if (timeMin < UZGPS_CONST.COSTOMER_TRACKER_TBIG_MIN) {
            timeMin = UZGPS_CONST.COSTOMER_TRACKER_TBIG_MIN;
        } else if (timeMin > UZGPS_CONST.COSTOMER_TRACKER_TBIG_MAX) {
            timeMin = UZGPS_CONST.COSTOMER_TRACKER_TBIG_MAX;
        }

        return timeMin;
    }

    private Integer getCorrectTimeMax(Integer timeBig) {
        if (timeBig == null) {
            timeBig = UZGPS_CONST.COSTOMER_TRACKER_TMAXBIG_MIN;
        } else if (timeBig < UZGPS_CONST.COSTOMER_TRACKER_TMAXBIG_MIN) {
            timeBig = UZGPS_CONST.COSTOMER_TRACKER_TMAXBIG_MIN;
        } else if (timeBig > UZGPS_CONST.COSTOMER_TRAKER_TMAXBIG_MAX) {
            timeBig = UZGPS_CONST.COSTOMER_TRAKER_TMAXBIG_MAX;
        }
        return timeBig;
    }

    private Integer getCorrectTimeLost(Integer timeLost) {
        if (timeLost == null) {
            timeLost = UZGPS_CONST.COSTOMER_TRAKER_TLOST_MIN;
        } else if (timeLost < UZGPS_CONST.COSTOMER_TRAKER_TLOST_MIN) {
            timeLost = UZGPS_CONST.COSTOMER_TRAKER_TLOST_MIN;
        } else if (timeLost > UZGPS_CONST.COSTOMER_TRAKER_TLOST_MAX) {
            timeLost = UZGPS_CONST.COSTOMER_TRAKER_TLOST_MAX;
        }
        return timeLost;
    }

    private Integer getCorrectDistanceMin(Integer distanceMin) {
        if (distanceMin == null) {
            distanceMin = UZGPS_CONST.COSTOMER_TRACKER_DMIN_MIN;
        } else if (distanceMin < UZGPS_CONST.COSTOMER_TRACKER_DMIN_MIN) {
            distanceMin = UZGPS_CONST.COSTOMER_TRACKER_DMIN_MIN;
        } else if (distanceMin > UZGPS_CONST.COSTOMER_TRACKER_DMIN_MAX) {
            distanceMin = UZGPS_CONST.COSTOMER_TRACKER_DMIN_MAX;
        }
        return distanceMin;
    }

    private Integer getCorrectDistanceBig(Integer distanceBig, Integer distanceMin) {
        if (distanceBig == null) {
            distanceBig = UZGPS_CONST.COSTOMER_TRACKER_DBIG_MIN;
        } else if (distanceBig < distanceMin) {
            distanceBig = distanceMin + 1;
        } else if (distanceBig > UZGPS_CONST.COSTOMER_TRACKER_DBIG_MAX) {
            distanceBig = UZGPS_CONST.COSTOMER_TRACKER_DBIG_MAX;
        }
        return distanceBig;
    }


//    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_MAIN)
//    public ModelAndView mobjectEditMain(HttpSession session) throws ServletException, ParseException, IOException {
//
//
//        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_MAIN);
//
//        return modelAndView;
//    }


//    @RequestMapping(value = URL_ADMIN_MOBJECT_EDIT_TABS)
//    public ModelAndView mobjectEditTabs(HttpSession session) throws ServletException, ParseException, IOException {
//
//
//        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MOBJECT_EDIT_TABS);
//
//        return modelAndView;
//    }

    private List<Integer> getPages(java.lang.Integer currentPage, java.lang.Integer maxPages) {
        List<java.lang.Integer> list = new ArrayList<>();
        if (currentPage != null && maxPages != null) {
            if (maxPages > 0) list.add(0); // 1 page
            if (maxPages > 1) list.add(1); // 2 page
            if (maxPages > 2) list.add(2); // 3 page

            if (currentPage > 1) {
                if (!list.contains(currentPage - 1) && (currentPage - 1 < maxPages))
                    list.add(currentPage - 1); // current - 1

                if (!list.contains(currentPage) && (currentPage < maxPages))
                    list.add(currentPage); // current

                if (!list.contains(currentPage + 1) && (currentPage + 1 < maxPages))
                    list.add(currentPage + 1); // current + 1
            }


            if (!list.contains(maxPages - 3) && (maxPages - 3 > 0)) list.add(maxPages - 3); // last-2 page
            if (!list.contains(maxPages - 2) && (maxPages - 3 > 0)) list.add(maxPages - 2); // last-1 page
            if (!list.contains(maxPages - 1) && (maxPages - 3 > 0)) list.add(maxPages - 1); // last page

            Collections.sort(list);

        }
        return list;
    }

}
