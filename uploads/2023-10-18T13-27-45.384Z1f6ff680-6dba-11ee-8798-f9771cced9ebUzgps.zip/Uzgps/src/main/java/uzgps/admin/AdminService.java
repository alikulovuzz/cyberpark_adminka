package uzgps.admin;

import io.vertx.core.logging.Logger;
import io.vertx.core.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.*;

import javax.persistence.*;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Service
@Component
public class AdminService {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    private AdminJournal adminJournal;


    @Transactional
    public User saveUser(User user) {
        if (user.getId() != null) {
            entityManager.merge(user);


//            if (user.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_USER_DELETED, user);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_USER_UPDATED, user);
        } else {
            entityManager.persist(user);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ADMIN_USER_INSERT, UZGPS_CONST.JOURNAL_ADMIN_USER_INSERT, user);
        }
        return user;
    }

    @Transactional
    public UserRole saveUseRole(UserRole userRole) {
        entityManager.persist(userRole);
//        adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_USER_ROLE_INSERT, userRole);

        return userRole;
    }

    @Transactional
    public Profile saveProfile(Profile profile) {
        if (profile.getId() != null) {
            entityManager.merge(profile);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_PROFILE_UPDATED, profile);
        } else {
            entityManager.persist(profile);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_PROFILE_INSERT, profile);
        }
        return profile;
    }

    @Transactional
    public Contract saveContract(Contract contract) {
        if (contract.getId() != null) {
            entityManager.merge(contract);
//            if (contract.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_DELETED, contract);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_UPDATED, contract);
        } else {
            entityManager.persist(contract);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_INSERT, contract);
        }

        return contract;
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Contract getContractById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<Contract> query;
            query = entityManager.createNamedQuery("Contract.findById", Contract.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getMaxContractId() {
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("Contract.getMaxContractId", Long.class);
            Long result = query.getSingleResult();
            if (result == null) return 0L;
            //return query.getSingleResult();
            return result;
        } catch (Exception e) {
            return 0L;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getMobjectCountByContractId(Long contractId) {
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("Contract.getMobjectCountByContractId", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            Long result = query.getSingleResult();
            if (result == null) return 0L;
            return result;
        } catch (Exception e) {
            return 0L;
        }
    }

    @Transactional
    public ContractSettings saveContractSettings(ContractSettings contractSettings) {
        if (contractSettings.getId() != null) {
            entityManager.merge(contractSettings);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_SETTINGS_UPDATED, contractSettings);
        } else {
            entityManager.persist(contractSettings);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_SETTINGS_INSERT, contractSettings);
        }

        return contractSettings;
    }

    @Transactional
    public GPSUnit saveGPSUnit(GPSUnit gpsUnit) {
        if (gpsUnit.getId() != null) {
            entityManager.merge(gpsUnit);
//            if (gpsUnit.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_DELETED, gpsUnit);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_UPDATED, gpsUnit);
        } else {
            entityManager.persist(gpsUnit);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_INSERT, gpsUnit);
        }
        return gpsUnit;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public GPSUnit getGPSUniteById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<GPSUnit> query;
            query = entityManager.createNamedQuery("GPSUnite.findById", GPSUnit.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Integer getGPSUniteAllByStatusCount(String status, Integer gpsTypeConnection, String txtSearch) {

        String sqlQuery;

        if (gpsTypeConnection != null) {
            if (gpsTypeConnection == 1)
                sqlQuery = " SELECT count(*) as cou " +
                        " FROM uzgps_mobject_gps_units m " +
                        " Join uzgps_gps_unit u on u.id=m.mogu_gps_unit_id and m.mogu_status=? " +
                        " left join uzgps_mobject n on mogu_mobject_id = n.id and n.mo_status = 'A' " +
                        " left join uzgps_contract c on mo_contract_id = c.id and c.c_status ='A' " +
                        " left join uzgps_company y on c.company_id = y.id " +
                        " where u.gu_status=? " +
                        " and (upper(u.gu_name) Like '%" + txtSearch.toUpperCase() + "%' " +
                        "      or upper(u.gu_imei) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(contract_number) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(y.name) Like '%" + txtSearch.toUpperCase() + "%') ";
            else if (gpsTypeConnection == 2)
                sqlQuery = " SELECT count(*) as cou " +
                        " FROM uzgps_mobject_gps_units m " +
                        " Right Join uzgps_gps_unit u on u.id=m.mogu_gps_unit_id and m.mogu_status=? " +
                        " left join uzgps_mobject n on mogu_mobject_id = n.id and n.mo_status = 'A' " +
                        " left join uzgps_contract c on mo_contract_id = c.id and c.c_status ='A' " +
                        " left join uzgps_company y on c.company_id = y.id " +
                        " where u.gu_status=? " +
                        " and (upper(u.gu_name) Like '%" + txtSearch.toUpperCase() + "%' " +
                        "      or upper(u.gu_imei) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(contract_number) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(y.name) Like '%" + txtSearch.toUpperCase() + "%') " +
                        " and mogu_mobject_id is null ";
            else
                sqlQuery = " SELECT count(*) as cou " +
                        " FROM uzgps_mobject_gps_units m " +
                        " Right Join uzgps_gps_unit u on u.id=m.mogu_gps_unit_id and m.mogu_status=? " +
                        " left join uzgps_mobject n on mogu_mobject_id = n.id and n.mo_status = 'A' " +
                        " left join uzgps_contract c on mo_contract_id = c.id and c.c_status ='A' " +
                        " left join uzgps_company y on c.company_id = y.id " +
                        " where u.gu_status=? " +
                        " and (upper(u.gu_name) Like '%" + txtSearch.toUpperCase() + "%' " +
                        "      or upper(u.gu_imei) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(contract_number) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(y.name) Like '%" + txtSearch.toUpperCase() + "%') ";
        } else
            sqlQuery = " SELECT count(*) AS cou " +
                    " FROM uzgps_mobject_gps_units m " +
                    " RIGHT JOIN uzgps_gps_unit u ON u.id=m.mogu_gps_unit_id AND m.mogu_status=? " +
                    " LEFT JOIN uzgps_mobject n ON mogu_mobject_id = n.id AND n.mo_status = 'A' " +
                    " LEFT JOIN uzgps_contract c ON mo_contract_id = c.id AND c.c_status ='A' " +
                    " LEFT JOIN uzgps_company y ON c.company_id = y.id " +
                    " WHERE u.gu_status=? ";

        Query q = entityManager.createNativeQuery(sqlQuery);
        q.setParameter(1, status);
        q.setParameter(2, status);
        BigInteger count = (BigInteger) q.getSingleResult();
        Integer result = 0;
        if (count != null)
            result = count.intValue();
        return result;


    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectGPSUnit> getGPSUniteAllByStatus(String status, Integer gpsTypeConnection, String txtSearch, int pageNumber) {

        String sqlQuery;
        int perPage = UZGPS_CONST.LIST_PER_PAGE;
        int skipRows = pageNumber * perPage;

        if (gpsTypeConnection != null) {
            if (gpsTypeConnection == 1)
                sqlQuery = " SELECT row_number() OVER () as id, mogu_dat_status, mogu_engineon_status, mogu_exp_date, coalesce(mogu_gps_unit_id,u.id) as mogu_gps_unit_id, " +
                        " mogu_mobject_id, mogu_mod_date, mogu_movement_status, mogu_online_status, " +
                        " mogu_reg_date, mogu_satellites_status, mogu_status, mogu_t_min, mogu_t_big, mogu_t_lost, mogu_d_min, mogu_d_big, u.is_mobile" +
                        " FROM uzgps_mobject_gps_units m " +
                        " Join uzgps_gps_unit u on u.id=m.mogu_gps_unit_id and m.mogu_status=? " +
                        " left join uzgps_mobject n on mogu_mobject_id = n.id and n.mo_status = 'A' " +
                        " left join uzgps_contract c on mo_contract_id = c.id and c.c_status ='A' " +
                        " left join uzgps_company y on c.company_id = y.id " +
                        " where u.gu_status=? " +
                        " and (upper(u.gu_name) Like '%" + txtSearch.toUpperCase() + "%' " +
                        "      or upper(u.gu_imei) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(contract_number) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(y.name) Like '%" + txtSearch.toUpperCase() + "%') " +
                        " order by u.gu_name" +
                        " limit " + perPage + " offset " + skipRows;
            else if (gpsTypeConnection == 2)
                sqlQuery = " SELECT row_number() OVER () as id, mogu_dat_status, mogu_engineon_status, mogu_exp_date, coalesce(mogu_gps_unit_id,u.id) as mogu_gps_unit_id, " +
                        " mogu_mobject_id, mogu_mod_date, mogu_movement_status, mogu_online_status, " +
                        " mogu_reg_date, mogu_satellites_status, mogu_status, mogu_t_min, mogu_t_big, mogu_t_lost, mogu_d_min, mogu_d_big, u.is_mobile " +
                        " FROM uzgps_mobject_gps_units m " +
                        " Right Join uzgps_gps_unit u on u.id=m.mogu_gps_unit_id and m.mogu_status=? " +
                        " left join uzgps_mobject n on mogu_mobject_id = n.id and n.mo_status = 'A' " +
                        " left join uzgps_contract c on mo_contract_id = c.id and c.c_status ='A' " +
                        " left join uzgps_company y on c.company_id = y.id " +
                        " where u.gu_status=? " +
                        " and (upper(u.gu_name) Like '%" + txtSearch.toUpperCase() + "%' " +
                        "      or upper(u.gu_imei) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(contract_number) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(y.name) Like '%" + txtSearch.toUpperCase() + "%') " +
                        " and mogu_mobject_id is null " +
                        " order by u.gu_name" +
                        " limit " + perPage + " offset " + skipRows;
            else
                sqlQuery = " SELECT row_number() OVER () as id, mogu_dat_status, mogu_engineon_status, mogu_exp_date, coalesce(mogu_gps_unit_id,u.id) as mogu_gps_unit_id, " +
                        " mogu_mobject_id, mogu_mod_date, mogu_movement_status, mogu_online_status, " +
                        " mogu_reg_date, mogu_satellites_status, mogu_status, mogu_t_min, mogu_t_big, mogu_t_lost, mogu_d_min, mogu_d_big, u.is_mobile " +
                        " FROM uzgps_mobject_gps_units m " +
                        " Right Join uzgps_gps_unit u on u.id=m.mogu_gps_unit_id and m.mogu_status=? " +
                        " left join uzgps_mobject n on mogu_mobject_id = n.id and n.mo_status = 'A' " +
                        " left join uzgps_contract c on mo_contract_id = c.id and c.c_status ='A' " +
                        " left join uzgps_company y on c.company_id = y.id " +
                        " where u.gu_status=? " +
                        " and (upper(u.gu_name) Like '%" + txtSearch.toUpperCase() + "%' " +
                        "      or upper(u.gu_imei) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(contract_number) Like '%" + txtSearch.toUpperCase() + "%'" +
                        "      or upper(y.name) Like '%" + txtSearch.toUpperCase() + "%') " +
                        " order by u.gu_name" +
                        " limit " + perPage + " offset " + skipRows;
        } else
            sqlQuery = " SELECT row_number() OVER () as id, mogu_dat_status, mogu_engineon_status, mogu_exp_date, coalesce(mogu_gps_unit_id,u.id) as mogu_gps_unit_id, " +
                    " mogu_mobject_id, mogu_mod_date, mogu_movement_status, mogu_online_status, " +
                    " mogu_reg_date, mogu_satellites_status, mogu_status, mogu_t_min, mogu_t_big, mogu_t_lost, mogu_d_min, mogu_d_big, u.is_mobile " +
                    " FROM uzgps_mobject_gps_units m " +
                    " Right Join uzgps_gps_unit u on u.id=m.mogu_gps_unit_id and m.mogu_status=? " +
                    " left join uzgps_mobject n on mogu_mobject_id = n.id and n.mo_status = 'A' " +
                    " left join uzgps_contract c on mo_contract_id = c.id and c.c_status ='A' " +
                    " left join uzgps_company y on c.company_id = y.id " +
                    " where u.gu_status=? " +
                    " order by u.gu_name" +
                    " limit " + perPage + " offset " + skipRows;

        Query q = entityManager.createNativeQuery(sqlQuery, MObjectGPSUnit.class);
        q.setParameter(1, status);
        q.setParameter(2, status);
        return q.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<GPSUnit> getGPSUniteAllFreeByStatus(String status, String imei) {
        Query query;
        query = entityManager.createNamedQuery("GPSUnite.findAllFreeByStatus");
        query.setParameter("status", status);
        query.setParameter("imei", imei);
        return query.getResultList();
    }

    @Transactional
    public GPSUnitType saveGPSUniteType(GPSUnitType gpsUnitType) {
        if (gpsUnitType.getId() != null) {
            entityManager.merge(gpsUnitType);
//            if (gpsUnitType.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_TYPE_DELETED, gpsUnitType);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_TYPE_UPDATED, gpsUnitType);
        } else {
            entityManager.persist(gpsUnitType);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_TYPE_INSERT, gpsUnitType);
        }
        return gpsUnitType;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public GPSUnitType getGPSUniteTypeById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<GPSUnitType> query;
            query = entityManager.createNamedQuery("GPSUniteType.findById", GPSUnitType.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<GPSUnitType> getGPSUniteTypeAllByStatus(String status) {
        Query query;
        query = entityManager.createNamedQuery("GPSUniteType.findAllByStatus");
        query.setParameter("status", status);
        return query.getResultList();
    }

    @Transactional
    public Company saveCompany(Company company) {
        if (company.getId() != null) {
            entityManager.merge(company);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_UPDATED, company);
        } else {
            entityManager.persist(company);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_CONTRACT_INSERT, company);
        }
        return company;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getCustomerCareById(Long id) {
        if (id == null)
            return null;

        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findById", User.class);
            query.setParameter("id", id);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_CUSTOMER_CARE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getCustomerAdminById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findById", User.class);
            query.setParameter("id", id);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getCustomerCareAllByStatus(String status) {
        Query query;
        query = entityManager.createNamedQuery("User.findAllByStatus");
        query.setParameter("status", status);
        query.setParameter("roleId", UZGPS_CONST.USER_ROLE_CUSTOMER_CARE);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getCustomerAdminByFilterAndStatus(Long operatorFilter, String customerFilter, String textSearch, Long roleId,
                                                        String showDeletedCustomer, int pageNumber) {

        int perPage = UZGPS_CONST.LIST_PER_PAGE;
        int skipRows = pageNumber * perPage;

        Query query = entityManager.createNamedQuery("User.findByStatusAndFilterOperatorAndFilterCustomerAndFilterText");
        query.setParameter("operator", operatorFilter);
        query.setParameter("contractType", customerFilter);
        query.setParameter("text", textSearch);
        query.setParameter("roleId", roleId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
        query.setParameter("statusExtra", showDeletedCustomer);
        if (pageNumber >= 0) {
            query.setFirstResult(skipRows);
            query.setMaxResults(UZGPS_CONST.LIST_PER_PAGE);
        }

        return query.getResultList();
    }

    public List<User> getCustomerAdminByFilterAndStatusCount(Long operatorFilter, String customerFilter, String textSearch, Long roleId,
                                                             String showDeletedCustomer, int pageNumber) {

        Query query = entityManager.createNamedQuery("User.findByStatusAndFilterOperatorAndFilterCustomerAndFilterTextCount");
        query.setParameter("operator", operatorFilter);
        query.setParameter("contractType", customerFilter);
        query.setParameter("text", textSearch);
        query.setParameter("roleId", roleId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
        query.setParameter("statusExtra", showDeletedCustomer);


        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getCustomerAdminByManagerIdAndFilterAndStatus(String customerFilter, String textSearch, Long roleId, Long
            managerId, String showDeletedCustomer) {

        Query query = entityManager.createNamedQuery("User.findByStatusAndFilterOperatorAndFilterCustomerAndFilterText");
        query.setParameter("operator", managerId);
        query.setParameter("contractType", customerFilter);
        query.setParameter("text", textSearch);
        query.setParameter("roleId", roleId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
        query.setParameter("statusExtra", showDeletedCustomer);

        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getCustomerCareList(String status, Long roleId) {
        Query query;
        query = entityManager.createNamedQuery("User.findCustomerCareByStatusAndFilter");
        query.setParameter("status", status);
        query.setParameter("roleId", roleId);
        return query.getResultList();
    }

    /*@SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObject> getMObjectById(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<MObject> query;
            query = entityManager.createNamedQuery("MObject.findById", MObject.class);
            query.setParameter("contractId", contractId);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }*/

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectGPSUnit> getMObjectGPSUnitByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<MObjectGPSUnit> query;
            query = entityManager.createNamedQuery("MObjectGPSUnit.findByContractId", MObjectGPSUnit.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectGPSUnit> getMObjectGPSUnitMobileByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<MObjectGPSUnit> query;
            query = entityManager.createNamedQuery("MObjectGPSUnit.findMobileByContractId", MObjectGPSUnit.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("isMobile", UZGPS_CONST.TRACKER_TYPE_MOBILE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectGPSUnit getMObjectGPSUnitById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<MObjectGPSUnit> query;
            query = entityManager.createNamedQuery("MObjectGPSUnit.findById", MObjectGPSUnit.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectGPSUnit getMObjectGPSUnitByMObjectId(Long mObjectId) {
        if (mObjectId == null)
            return null;
        try {
            TypedQuery<MObjectGPSUnit> query;
            query = entityManager.createNamedQuery("MObjectGPSUnit.findByMObjectId", MObjectGPSUnit.class);
            query.setParameter("mObjectId", mObjectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObject getMObjectById(Long mObjectId) {
        if (mObjectId == null)
            return null;
        try {
            TypedQuery<MObject> query;
            query = entityManager.createNamedQuery("MObject.findByObjectId", MObject.class);
            query.setParameter("objectId", mObjectId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public MObject saveMObject(MObject mObject) {
        if (mObject.getId() != null) {
            entityManager.merge(mObject);

//            if (mObject.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_DELETED, mObject);
//            else // todo
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_UPDATED, mObject);
        } else {
            entityManager.persist(mObject);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_INSERT, mObject);
        }

        return mObject;
    }

    @Transactional
    public MObjectSettings saveMObjectSettings(MObjectSettings mObjectSettings) {
        if (mObjectSettings.getId() != null) {
            entityManager.merge(mObjectSettings);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_SETTINGS_UPDATED, mObjectSettings);
        } else {
            entityManager.persist(mObjectSettings);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_SETTINGS_INSERT, mObjectSettings);
        }
        return mObjectSettings;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Group getGroupById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<Group> query;
            query = entityManager.createNamedQuery("Group.findById", Group.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public MObjectGPSUnit saveMObjectGPSUnit(MObjectGPSUnit mObjectGPSUnit) {
        if (mObjectGPSUnit.getId() != null) {
            entityManager.merge(mObjectGPSUnit);
//            if (mObjectGPSUnit.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GPSUNIT_DELETED, mObjectGPSUnit);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GPSUNIT_UPDATED, mObjectGPSUnit);
        } else {
            entityManager.persist(mObjectGPSUnit);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_GPSUNIT_INSERT, mObjectGPSUnit);
        }
        return mObjectGPSUnit;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectGPSUnit> getMObjectGPSUnitByUnitId(Long unitId) {
        if (unitId == null)
            return null;
        try {
            TypedQuery<MObjectGPSUnit> query;
            query = entityManager.createNamedQuery("MObjectGPSUnit.findByUnitId", MObjectGPSUnit.class);
            query.setParameter("unitId", unitId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public Sim saveSim(Sim sim) {
        if (sim.getId() != null) {
            entityManager.merge(sim);
//            if (sim.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_SIM_DELETED, sim);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_SIM_UPDATED, sim);
        } else {
            entityManager.persist(sim);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_SIM_INSERT, sim);
        }
        return sim;
    }

    @Transactional
    public GPSUnitSim saveGPSUnitSim(GPSUnitSim gpsUnitSim) {
        if (gpsUnitSim.getId() != null) {
            entityManager.merge(gpsUnitSim);
//            if (gpsUnitSim.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_SIM_DELETED, gpsUnitSim);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_SIM_UPDATED, gpsUnitSim);
        } else {
            entityManager.persist(gpsUnitSim);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_GPSUNIT_SIM_INSERT, gpsUnitSim);
        }
        return gpsUnitSim;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public GPSUnitSim getGPSUnitSimBySimId(Long simId) {
        if (simId == null)
            return null;
        try {
            TypedQuery<GPSUnitSim> query;
            query = entityManager.createNamedQuery("GPSUnitSim.findBySimId", GPSUnitSim.class);
            query.setParameter("simId", simId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public GPSUnitSim getGPSUnitSimByGPSUnitId(Long gpsUnitId) {
        if (gpsUnitId == null)
            return null;
        try {
            TypedQuery<GPSUnitSim> query;
            query = entityManager.createNamedQuery("GPSUnitSim.findByGPSUnitId", GPSUnitSim.class);
            query.setParameter("gpsUnitId", gpsUnitId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    /**
     * Deletes all GPSUnitSim connections by gpsUnitId
     *
     * @param gpsUnitId GPSUnit id
     */
    @Transactional
    public void deleteAllGPSUnitSimByUnitId(Long gpsUnitId) {
        if (gpsUnitId != null) {
            final int changes =
                    entityManager.createQuery("UPDATE GPSUnitSim SET status = :status, modDate = :modDate WHERE gpsUnitId = :unitId ")
                            .setParameter("unitId", gpsUnitId)
                            .setParameter("status", UZGPS_CONST.STATUS_DELETE)
                            .setParameter("modDate", new Timestamp(System.currentTimeMillis()))
                            .executeUpdate();

        }
    }

    /**
     * Deletes all Mobject Gps Unit connections by Unit ID
     *
     * @param gpsUnitId
     */
    @Transactional
    public void deleteAllMobjectGPSUnitByUnitId(Long gpsUnitId) {
        if (gpsUnitId != null) {
            final int changes =
                    entityManager.createQuery("UPDATE MObjectGPSUnit SET status = :status, modDate = :modDate WHERE gpsUnitId = :unitId ")
                            .setParameter("unitId", gpsUnitId)
                            .setParameter("status", UZGPS_CONST.STATUS_DELETE)
                            .setParameter("modDate", new Timestamp(System.currentTimeMillis()))
                            .executeUpdate();

        }
    }

    /**
     * Return Sim object if found
     *
     * @param simPhone phone number in +(998 93) 123-45-67 format
     * @return returns null if object not found
     */
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Sim getSimBySimPhone(String simPhone) {
        if (simPhone == null)
            return null;
        try {
            TypedQuery<Sim> query;
            query = entityManager.createNamedQuery("GPSUnitSim.findBySimPhone", Sim.class);
            query.setParameter("simPhone", simPhone);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Sim getSimById(Long id) {
        if (id == null)
            return null;

        try {
            TypedQuery<Sim> query;
            query = entityManager.createNamedQuery("Sim.findById", Sim.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public MObjectNotifications saveMObjectNotifications(MObjectNotifications mObjectNotifications) {
        if (mObjectNotifications.getId() != null) {
            entityManager.merge(mObjectNotifications);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_NOTIFICATION_UPDATED, mObjectNotifications);
        } else {
            entityManager.persist(mObjectNotifications);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_ADMIN_MOBJECT_NOTIFICATION_INSERT, mObjectNotifications);
        }
        return mObjectNotifications;
    }

    @Transactional
    public UserAccessList saveUserAccessList(UserAccessList userAccessList) {
        if (userAccessList.getId() != null) {
            entityManager.merge(userAccessList);
        } else {
            entityManager.persist(userAccessList);
        }
        return userAccessList;
    }

    @Transactional
    public ReportACL saveReportACL(ReportACL reportACL) {
//        if (reportACL.getReportId() != null && reportACL.getContractId() != null) {
        if (reportACL.getId() != null) {
            entityManager.merge(reportACL);
        } else {
            entityManager.persist(reportACL);
        }
//        }
        return reportACL;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public ReportACL gerReportACLById(Long contractId, Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<ReportACL> query;
            query = entityManager.createNamedQuery("ReportACL.findAllById", ReportACL.class);
            query.setParameter("id", id);
            query.setParameter("contractId", contractId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<ReportACL> getReportACLByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<ReportACL> query;
            query = entityManager.createNamedQuery("ReportACL.findAllByContractId", ReportACL.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserAccessList getUserAccessByUserId(Long userId) {
        if (userId == null)
            return null;
        try {
            TypedQuery<UserAccessList> query;
            query = entityManager.createNamedQuery("UserAccessList.findByUserId", UserAccessList.class);
            query.setParameter("userId", userId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserAccessList getUserAccessByUserContractId(Long userId, Long contractId) {
        if (userId != null && contractId != null)
            try {
                TypedQuery<UserAccessList> query;
                query = entityManager.createNamedQuery("UserAccessList.findByUserContractId", UserAccessList.class);
                query.setParameter("userId", userId);
                query.setParameter("contractId", contractId);
                return query.getSingleResult();
            } catch (NoResultException e) {
            }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Long> getFmsContracts() {
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("UserAccessList.getFmsContracts", Long.class);
            return query.getResultList();
        } catch (NoResultException e) {
            logger.error("Error in getFmsContracts", e.getCause());
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public GPSUnit getGPSUniteByIMEI(String imei) {
        if (imei == null)
            return null;
        try {
            TypedQuery<GPSUnit> query;
            query = entityManager.createNamedQuery("GPSUnit.findByIMEI", GPSUnit.class);
            query.setParameter("imei", imei);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByLogin(String login) {
        if (login == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByLogin", User.class);
            query.setParameter("login", login);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByContractId", User.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Company> getCompanyNames() {

        try {
            TypedQuery<Company> query;
            query = entityManager.createNamedQuery("Company.findByContractId", Company.class);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    /**
     * Makes new Sim object by given phone number
     *
     * @param phoneNumber phone number in +(998 93) 123-45-67 format
     * @return new sim object
     */
    @Transactional
    public Sim saveSim(String phoneNumber) {

        /*
           Create new object sim
           Sets status Active
           Sets the time to edit the current
        */
        if (phoneNumber != null) {
            Sim sim = new Sim();
            sim.setSimPhone(phoneNumber);
            sim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            sim.setRegDate(new Timestamp(System.currentTimeMillis()));
            saveSim(sim);
            return sim;
        }
        return null;
    }

    /**
     * Deletes Sim object
     *
     * @param sim Sim object
     * @return returns null if sim object is null
     */
    @Transactional
    public Sim deleteSim(Sim sim) {

        if (sim != null) {
        /*
           Sets status Delete
          Sets the time to edit the current

        */
            sim.setStatus(UZGPS_CONST.STATUS_DELETE);
            sim.setExpDate(new Timestamp(System.currentTimeMillis()));
            saveSim(sim);

        }
        return sim;
    }

    /**
     * Updates Sim object if sim, phone and status is not null
     *
     * @param sim    Sim  object
     * @param phone  phone number in +(998 93) 123-45-67 format
     * @param status status
     *               {@link uzgps.common.UZGPS_CONST#STATUS_ACTIVE}
     *               {@link uzgps.common.UZGPS_CONST#STATUS_DELETE}
     * @return returns null if sim, phone and status object is null
     */
    public Sim updateSim(Sim sim, String phone, String status) {

        if (sim != null && phone != null && status != null) {

        /*
           Sets status Active
           Sets new phone number
           Sets the time to edit the current
         */
            sim.setStatus(status);
            sim.setSimPhone(phone);
            sim.setModDate(new Timestamp(System.currentTimeMillis()));
            saveSim(sim);

        }
        return sim;

    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Role getRoleById(Long id) {
        if (id == null)
            return null;

        try {
            TypedQuery<Role> query;
            query = entityManager.createNamedQuery("Role.findById", Role.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getUserContractsCount(Long userId) {
        if (userId == null)
            return 0L;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("Contract.getUserContractsCountByUserId", Long.class);
            query.setParameter("userId", userId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return 0L;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Contract> getUserContractsByUserId(Long userId) {
        if (userId == null)
            return null;
        try {
            TypedQuery<Contract> query;
            query = entityManager.createNamedQuery("Contract.getUserContractsByUserId", Contract.class);
            query.setParameter("userId", userId);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Contract> getUserContractsWithoutTerminatedByUserId(Long userId) {
        if (userId == null)
            return null;
        try {
            TypedQuery<Contract> query;
            query = entityManager.createNamedQuery("Contract.getUserContractsWithoutTerminatedByUserId", Contract.class);
            query.setParameter("userId", userId);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<UserRole> getCustomerAdminsByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<UserRole> query;
            query = entityManager.createNamedQuery("UserRole.getCustomerAdminsByContractId", UserRole.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<UserRole> getUserRoleByUserIdAndContractId(Long userId, Long contractId) {
        if (userId == null || contractId == null) {
            return null;
        }

        TypedQuery<UserRole> query = entityManager.createNamedQuery("UserRole.findByUserIdAndContractId", UserRole.class);
        query.setParameter("userId", userId);
        query.setParameter("contractId", contractId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserRole getDefaultCustomerAdminByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<UserRole> query;
            query = entityManager.createNamedQuery("UserRole.getDefaultCustomerAdminByContractId", UserRole.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN);
            query.setMaxResults(1);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public UserRole saveUserRole(UserRole userRole) {
        if (userRole.getId() != null) {
            entityManager.merge(userRole);
        } else {
            entityManager.persist(userRole);
        }

        return userRole;
    }

    /**
     * Get distance information by parts
     *
     * @param id
     * @param startDate
     * @param endDate
     * @return
     */
    @Transactional
    public List<CustomDistancesForTracking> getDistanceByObjectAndPeriod(Long id, Timestamp startDate, Timestamp endDate) {
        try {
//            String sqlQuery = "SELECT * FROM  dashboard.mobject_distance_for_smpo_treking_points(?,?,?)"; by 1000 tracks

            // by days
            String sqlQuery = "SELECT * FROM  dashboard.mobject_distance_for_smpo_tracking_points(?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, CustomDistancesForTracking.class);
            q.setParameter(1, id);
            q.setParameter(2, startDate);
            q.setParameter(3, endDate);

            List<CustomDistancesForTracking> list = q.getResultList();

            return list;
        } catch (Exception e) {
            logger.error("ERROR in AdminService getDistanceByObjectAndPeriod START");
            logger.error(startDate);
            logger.error(endDate);
            logger.error(e.getMessage());
            logger.error("ERROR in AdminService getDistanceByObjectAndPeriod END");
            return null;
        }
    }

    /**
     * Get distance information by parts
     *
     * @param id
     * @param startDate
     * @param endDate
     * @return
     */
    @Transactional
    public List<Double> getOnlyDistanceByObjectAndPeriod(Long id, Timestamp startDate, Timestamp endDate) {
        try {
            // by period
            String sqlQuery = "SELECT distance FROM  dashboard.mobject_only_distance_for_smpo_tracking_points(?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery);
            q.setParameter(1, id);
            q.setParameter(2, startDate);
            q.setParameter(3, endDate);

            List<Double> distancesList = q.getResultList();

            return distancesList;
        } catch (Exception e) {
            logger.error("ERROR in AdminService getOnlyDistanceByObjectAndPeriod START");
            logger.error(startDate);
            logger.error(endDate);
            logger.error(e.getMessage());
            logger.error("ERROR in AdminService getOnlyDistanceByObjectAndPeriod END");
            return null;
        }
    }

    /**
     * Get distance by mobject and period, in meters
     *
     * @param id
     * @param startDate
     * @param endDate
     * @return
     */
    @Transactional
    public FmsMobjectDistance getDistanceByMobjectIdAndPeriodV2(Long returningId,
                                                                String returningDateStr,
                                                                Double returningCurrentOdometer,
                                                                Long id, Timestamp startDate, Timestamp endDate) {
        try {
            // by period
            String sqlQuery = "SELECT mobject_id, start_period_date distance_date, (mileage / 1000.0) as distance FROM  dashboard.view_one_mobject_mileage_on_period(?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, FmsMobjectDistance.class);
            q.setParameter(1, id);
            q.setParameter(2, startDate);
            q.setParameter(3, endDate);

            FmsMobjectDistance fmsMobjectDistance = null;
            try {
                fmsMobjectDistance = (FmsMobjectDistance) q.getSingleResult();
                fmsMobjectDistance.setReturningId(returningId);

                if (returningDateStr != null && !returningDateStr.isEmpty()) {
                    fmsMobjectDistance.setReturningDate(returningDateStr);
                }

                if (returningCurrentOdometer != null) {
                    fmsMobjectDistance.setReturningCurrentOdometer(returningCurrentOdometer);
                }
            } catch (NoResultException e) {
                return null;
            }

            return fmsMobjectDistance;
        } catch (Exception e) {
            logger.error("ERROR in AdminService getDistanceByMobjectIdAndPeriodV2 START");
            logger.error(id + " - " + startDate + " - " + endDate);
            logger.error(e.getCause());
            logger.error("ERROR in AdminService getDistanceByMobjectIdAndPeriodV2 END");
            return null;
        }
    }

    /**
     * Get distance by mobject and period, in meters
     *
     * @param id
     * @param startDate
     * @param endDate
     * @return
     */
    @Transactional
    public FmsMobjectDistance getDistanceByMobjectIdAndPeriodV2(Long id, Timestamp startDate, Timestamp endDate) {
        try {
            // by period
            String sqlQuery = "SELECT mobject_id, start_period_date distance_date, (mileage / 1000.0) as distance FROM  dashboard.view_one_mobject_mileage_on_period(?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, FmsMobjectDistance.class);
            q.setParameter(1, id);
            q.setParameter(2, startDate);
            q.setParameter(3, endDate);

            FmsMobjectDistance fmsMobjectDistance = null;
            try {
                fmsMobjectDistance = (FmsMobjectDistance) q.getSingleResult();
            } catch (NoResultException e) {
                return null;
            }

            return fmsMobjectDistance;
        } catch (Exception e) {
            logger.error("ERROR in AdminService getDistanceByMobjectIdAndPeriodV2 START");
            logger.error(id + " - " + startDate + " - " + endDate);
            logger.error(e.getCause());
            logger.error("ERROR in AdminService getDistanceByMobjectIdAndPeriodV2 END");
            return null;
        }
    }

    /**
     * Get distances for all mobjects by today date
     *
     * @return
     */
    @Transactional
    public List<FmsMobjectDistance> getAllMobjectsDistancesToday() {
        try {
            // by all mobjects
            String sqlQuery = "SELECT mobject_id, start_date distance_date, distance FROM dashboard.view_all_mobjects_today_mileage();";
            Query q = entityManager.createNativeQuery(sqlQuery, FmsMobjectDistance.class);
            List<FmsMobjectDistance> distancesList = q.getResultList();

            return distancesList;
        } catch (Exception e) {
            logger.error("ERROR in AdminService getAllMobjectsDistancesToday START");
            logger.error(e.getCause());
            logger.error("ERROR in AdminService getAllMobjectsDistancesToday END");
            return null;
        }
    }

    /**
     * Get distances for all mobjects by yesterday date
     *
     * @return
     */
    @Transactional
    public List<FmsMobjectDistance> getAllMobjectsDistancesYesterday() {
        try {
            // by all mobjects
            String sqlQuery = "SELECT mobject_id, start_date distance_date, distance FROM  dashboard.view_all_mobjects_yesterday_mileage();";
            Query q = entityManager.createNativeQuery(sqlQuery, FmsMobjectDistance.class);
            List<FmsMobjectDistance> distancesList = q.getResultList();

            return distancesList;
        } catch (Exception e) {
            logger.error("ERROR in AdminService getAllMobjectsDistancesYesterday START");
            logger.error(e.getCause());
            logger.error("ERROR in AdminService getAllMobjectsDistancesYesterday END");
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByToken(String token) {
        if (token == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByToken", User.class);
            query.setParameter("token", token);
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public User getUserByApiToken(String token) {
        if (token == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByApiToken", User.class);
            query.setParameter("token", token);
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }


}
