package uzgps.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.core.interfaces.LicenseData;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.persistence.GPSUnit;
import uzgps.persistence.Sim;
import uzgps.persistence.User;

import javax.servlet.ServletException;
import java.io.IOException;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class AdminController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public final static String URL_ADMIN_MAIN = "/admin/main.htm";
    private final static String VIEW_ADMIN_MAIN = "admin/admin-main";

    private final static String URL_ADMIN_BILLING = "/admin/billing.htm";
    private final static String VIEW_ADMIN_BILLING = "admin/billing-trackers";

    private final static String URL_ADMIN_AJAX_CHECK_VALUE = "/admin/ajax-check-value.htm";
    private final static String VIEW_ADMIN_AJAX_CHECK_VALUE = "admin/ajax-check-value";

    @Autowired
    private AdminService adminService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_ADMIN_MAIN)
    public ModelAndView processAdminMain() {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_MAIN);
        modelAndView.addObject("url_pattern", URL_ADMIN_MAIN);

        // DB handler
        int queueCount = coreMain.getQueueCount(CoreMain.QT_DB_HANDLER);
        modelAndView.addObject("queue_dbhandler_count", queueCount);

        // Log Hex
        queueCount = coreMain.getQueueCount(CoreMain.QT_DB_LOG_HEX_HANDLER);
        modelAndView.addObject("queue_loghex_count", queueCount);


//        List<User> userList = adminService.getUserAll();
//        modelAndView.addObject("userList", userList);

        return modelAndView;
    }


    @RequestMapping(value = URL_ADMIN_BILLING)
    public ModelAndView processAdminBilling() {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_BILLING);
        modelAndView.addObject("url_pattern", URL_ADMIN_BILLING);

        return modelAndView;
    }

    /**
     * Ajax function. Check value by cmd command.
     *
     * @param cmd
     * @param key
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ADMIN_AJAX_CHECK_VALUE)
    public ModelAndView processMapMonitoringPanel(@RequestParam(value = "cmd", required = false) String cmd,
                                                  @RequestParam(value = "key", required = false) String key,
                                                  @RequestParam(value = "contract-id", required = false, defaultValue = "0") Long contractId) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_ADMIN_AJAX_CHECK_VALUE);

        if (logger.isDebugEnabled()) {
            logger.debug("processMapMonitoringPanel cmd={},key={}",
                    cmd, key);
        }

        // if cms exists, continue
        if (cmd != null) {
            // Check by Imei. Checks dublicates of Imei
            if (cmd.equalsIgnoreCase("imei")) {
                // clear imei Spaces
                key = key.trim();
                // Get object
                GPSUnit gpsUnit = adminService.getGPSUniteByIMEI(key);
                if (gpsUnit != null && gpsUnit.getId() != null)
                    modelAndView.addObject("error_txt", "Такой IMEI существует в базе!");
            }
            // Check by User Login. Checks dublicates of Login
            else if (cmd.equalsIgnoreCase("login")) {
                User user = adminService.getUserByLogin(key.trim().toLowerCase());
                if (user != null && user.getId() != null)
                    modelAndView.addObject("error_txt", "Такой Login существует в базе!");
            }
            // check unit count by license data
            else if (cmd.equalsIgnoreCase("UnitCount")) {
                // get unit count entered by operator
                Long maxUnitCount = Long.parseLong(key);

                // Get number of available units count from license (core)
                Long licenseMaxUnitCount = coreMain.licenseData.checkTrackerCount(maxUnitCount, contractId);

                // Check 2 values
                if (licenseMaxUnitCount != null && !licenseMaxUnitCount.equals(maxUnitCount)) {
                    modelAndView.addObject("error_txt", "Превышение квоты на количество трекеров! Максимально возможное количество " + licenseMaxUnitCount);
                }
            } else if (cmd.equalsIgnoreCase("UserCount")) {
                // get users count entered by operator
                Long maxUserCount = Long.parseLong(key);

                // Get number of available users count from license (core)
                Long licenseMaxUserCount = coreMain.licenseData.checkUserCount(LicenseData.USER_TYPE_CUSTOMER, maxUserCount, contractId);

                // Check 2 values
                if (licenseMaxUserCount != null && !licenseMaxUserCount.equals(maxUserCount)) {
                    modelAndView.addObject("error_txt", "Превышение квоты на количество пользователей! Максимально возможное количество " + licenseMaxUserCount);
                }
            } else if (cmd.equalsIgnoreCase("StaffCount")) {
                // get staff count entered by operator
                Long maxStaffCount = Long.parseLong(key);

                // Get number of available staff count from license (core)
                Long licenseMaxStaffCount = coreMain.licenseData.checkUserCount(LicenseData.USER_TYPE_STAFF, maxStaffCount, contractId);

                // Check 2 values
                if (licenseMaxStaffCount != null && !licenseMaxStaffCount.equals(maxStaffCount)) {
                    modelAndView.addObject("error_txt", "Превышение квоты на количество персонала! Максимально возможное количество " + licenseMaxStaffCount);
                }
            } else if (cmd.equalsIgnoreCase("PoICount")) {
                // get PoIs count entered by operator
                Long maxPoICount = Long.parseLong(key);

                // Get number of available PoIs count from license (core)
                Long licenseMaxPoICount = coreMain.licenseData.checkModuleCount(LicenseData.MODUL_POI, maxPoICount, contractId);

                // Check 2 values
                if (licenseMaxPoICount != null && !licenseMaxPoICount.equals(maxPoICount)) {
                    modelAndView.addObject("error_txt", "Превышение квоты создания POI! Максимально возможное количество " + licenseMaxPoICount);
                }
            } else if (cmd.equalsIgnoreCase("ZoICount")) {
                // get ZoIs count entered by operator
                Long maxZoICount = Long.parseLong(key);

                // Get number of available ZoIs count from license (core)
                Long licenseMaxZoICount = coreMain.licenseData.checkModuleCount(LicenseData.MODUL_ZOI, maxZoICount, contractId);

                // Check 2 values
                if (licenseMaxZoICount != null && !licenseMaxZoICount.equals(maxZoICount)) {
                    modelAndView.addObject("error_txt", "Превышение квоты создания ZOI! Максимально возможное количество " + licenseMaxZoICount);
                }
            } else if (cmd.equalsIgnoreCase("sim-phone")) {
                // Check by SIM phone. Checks dublicates of SIM number
                key = key.trim();
                key = "+" + key;

                // Get Sim card
                Sim sim = adminService.getSimBySimPhone(key);

                // If Sim Card exists
                if (sim != null && sim.getId() != null) {

                    boolean simCardInUse = false;

                    // Try to find, is this Sim card IS USING now?
                    List<GPSUnit> list = sim.getGpsUnitList();
                    if (list != null) {
                        for (GPSUnit gpsUnit : list) {
                            if (gpsUnit != null
                                    && sim.getId().equals(gpsUnit.getSim1().getId())
                                    && gpsUnit.getStatus().equals(UZGPS_CONST.STATUS_ACTIVE)) {
                                simCardInUse = true;
                                break;
                            }
                        }
                    }

                    if (simCardInUse)
                        modelAndView.addObject("error_txt", "Такой номер SIM-карты уже используется!");
                }
            }
        }

        return modelAndView;
    }
}
