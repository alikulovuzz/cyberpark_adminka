package uzgps.admin;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.persistence.Journal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created by Saidolim on 03.04.14.
 */

@Service
public class AdminJournalService {

//    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static int LIMIT = 25;

    @PersistenceContext
    EntityManager entityManager;

/*
    @Transactional
    public Journal saveJournal(Journal journal) {
        if (journal.getId() != null)
            entityManager.merge(journal);
        else
            entityManager.persist(journal);
        return journal;
    }
*/

    /**
     * Retunes data according to start and end dates, userId and limits and page.
     *
     * @param rangeStart
     * @param rangeEnd
     * @param userId
     * @param page
     * @return
     */
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Journal> getJournalTable(int rangeStart, int rangeEnd, long userId, int page) {
        Query query;
        query = entityManager.createNamedQuery("Journal.getTable");
        query.setParameter("rangeStart", rangeStart);
        query.setParameter("rangeEnd", rangeEnd);
//        query.setParameter("userId", userId);
        query.setMaxResults(LIMIT);
        query.setFirstResult(page * LIMIT);
        return query.getResultList();
    }


}
