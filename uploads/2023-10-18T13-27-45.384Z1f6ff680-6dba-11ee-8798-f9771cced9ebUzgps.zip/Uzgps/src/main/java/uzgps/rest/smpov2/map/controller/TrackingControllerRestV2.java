package uzgps.rest.smpov2.map.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uzgps.rest.smpov2.map.TrackingBase;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


@RestController
@RequestMapping("/v2/map/")
public class TrackingControllerRestV2 extends TrackingBase {

    /**
     * <h3>Get xml</h3>
     * <p>
     *
     * @param mObjectId        in path required true
     * @param startDate        in path required true
     * @param endDate          in path required true
     * @param pointCount       in path required true
     * @param trackTypeColor   in path required true
     * @param color            in path required false
     * @param lineWidth        in path required default 1
     * @param trackViewTypeStr in path required default 1
     * @return track points pins
     * </p>
     *
     * <b>Example:</b>
     * <i>If success</i>
     * <pre>
     *     {
     *         "result": "{...}",
     *         "error": null
     *     }
     * </pre>
     * <br/>
     * <hr/>
     * <br/>
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/tracking-object-tracks-kml", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMovableObjectTracksById(HttpSession session,
                                                        @RequestParam(value = "object-id") Long mObjectId,
                                                        @RequestParam(value = "start-date") String startDate,
                                                        @RequestParam(value = "end-date") String endDate,
                                                        @RequestParam(value = "point-count") Integer pointCount,
                                                        @RequestParam(value = "track-type-color") String trackTypeColor,
                                                        @RequestParam(value = "color", required = false) String color,
                                                        @RequestParam(value = "line-width", defaultValue = "1") Integer lineWidth,
                                                        @RequestParam(value = "track-view-type", defaultValue = "1") String trackViewTypeStr) {

        return getResponseEntity(getKmlObjectTrack(session, mObjectId, startDate, endDate, pointCount, trackTypeColor, color, lineWidth, trackViewTypeStr));
    }


    /**
     * <h3>Get object full track table</h3>
     * <p>
     *
     * @param mObjectId              in path required true.
     * @param startDateStr           in path required true.
     * @param endDateStr             in path required true.
     * @param limitStr               in path default 0.
     * @param needLoadTracksTableStr in path default false.
     * @param pageIdStr              in path default 0.
     * @return track points pins
     *
     * </p>
     *
     * <b>Example:</b>
     * <i>If success</i>
     * <pre>
     *     {
     *          "result": {...}
     *          "error": null
     *     }
     * </pre>
     * <br/>
     * <hr/>
     * <br/>
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/tracking-object-tracks-table", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> loadDataForTracking(HttpSession session,
                                                 @RequestParam(value = "object-id") Long mObjectId,
                                                 @RequestParam(value = "start-date") String startDateStr,
                                                 @RequestParam(value = "end-date") String endDateStr,
                                                 @RequestParam(value = "point-count", defaultValue = "0") String limitStr,
                                                 @RequestParam(value = "need-load-track-table", defaultValue = "false")
                                                 String needLoadTracksTableStr,
                                                 @RequestParam(value = "page-id", defaultValue = "0") String pageIdStr) throws JsonProcessingException {

        return getResponseEntity(loadDataForTrackingService(session, mObjectId, startDateStr, endDateStr, limitStr, needLoadTracksTableStr, pageIdStr));
    }


    /**
     * <h3>Get track data download xls</h3>
     * <p>
     *
     * @param mObjectId  in path required true.
     * @param startDate  in path required true.
     * @param endDate    in path required true.
     * @param pointCount in path required true.
     * @return xls file
     *
     * </p>
     *
     * <b>Example:</b>
     * <i>If success</i>
     * <pre>
     *     {
     *          ...(data *.xls)...
     *     }
     * </pre>
     * <br/>
     * <hr/>
     * <br/>
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/track-data-download-xls", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getXLSByApi(HttpServletResponse response, HttpServletRequest request,
                                         @RequestParam(value = "object-id") Long mObjectId,
                                         @RequestParam(value = "start-date") String startDate,
                                         @RequestParam(value = "end-date") String endDate,
                                         @RequestParam(value = "point-count") Integer pointCount) throws Exception {

        return getResponseEntity(getXLSService(response, request, mObjectId, startDate, endDate, pointCount));
    }


    /**
     * <h3>Get tracks count by period</h3>
     * <p>
     *
     * @param mObjectId in path required false.
     * @param startDate in path required false.
     * @param endDate   in path required false.
     * @return true if point count > EXCEL_TRACK_POINTS_DOWNLOAD_LIMIT (50_000), false if point count = 0, else null
     *
     * </p>
     *
     * <b>Example:</b>
     * <i>If success</i>
     * <pre>
     *     {
     *          "result": true,
     *          "error": null
     *     }
     * </pre>
     * <br/>
     * <hr/>
     * <br/>
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/tracks-count-by-period", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getTrackPointsCountByPeriod(@RequestParam(value = "object-id") Long mObjectId,
                                                         @RequestParam(value = "start-date") String startDate,
                                                         @RequestParam(value = "end-date") String endDate) {

        return getResponseEntity(getTrackPointsCountByPeriodRestService(mObjectId, startDate, endDate));
    }


    /**
     * <h3>Get object full track</h3>
     * <p>
     *
     * @param mObjectId in path required true.
     * @param startDate in path required true.
     * @param endDate   in path required true.
     * @param color     in path required false.
     * @param lineWidth in path default 3.
     * @param epsilon   in path default 1.
     * @return track points pins
     *
     * </p>
     *
     * <b>Example:</b>
     * <i>If success</i>
     * <pre>
     *     {
     *          "result": {...}
     *      }
     * </pre>
     * <br/>
     * <hr/>
     * <br/>
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/object-full-tracks", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMovableObjectReduces(@RequestParam(value = "object-id") Long mObjectId,
                                                     @RequestParam(value = "start-date") String startDate,
                                                     @RequestParam(value = "end-date") String endDate,
                                                     @RequestParam(value = "color", required = false) String color,
                                                     @RequestParam(value = "line-width", defaultValue = "3") Integer lineWidth,
                                                     @RequestParam(value = "epsilon", defaultValue = "1") Integer epsilon) {

        return getResponseEntity(getMovableObjectReducesService(mObjectId, startDate, endDate, color, lineWidth, epsilon));
    }


    /**
     * <h3>Get track points pins</h3>
     * <p>
     *
     * @param mObjectId   in path required true.
     * @param startDate   in path required true.
     * @param endDate     in path required true.
     * @param pointsCount in path required true.
     * @return track points pins
     *
     * </p>
     *
     * <b>Example:</b>
     * <i>If success</i>
     * <pre>
     *     {
     *          "result": {
     *              "parkingPins": "[{...}]",
     *              "sosPins": "[{...}]"
     *                  },
     *           "error": null
     *      }
     * </pre>
     * <br/>
     * <hr/>
     * <br/>
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/track-points-pins", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getTrackPointsPins(HttpSession session,
                                                HttpServletResponse response,
                                                @RequestParam(value = "object-id") Long mObjectId,
                                                @RequestParam(value = "start-date") String startDate,
                                                @RequestParam(value = "end-date") String endDate,
                                                @RequestParam(value = "point-count") Integer pointsCount) throws IOException {
        return getResponseEntity(getTrackPointsPinsRestService(session, response, mObjectId, startDate, endDate, pointsCount));
    }


    /**
     * <h3>Get nearest track point</h3>
     * <p>
     *
     * @param mObjectId    in path required false.
     * @param startDateStr in path required false.
     * @param endDateStr   in path required false.
     * @param latitude     in path required false.
     * @param longitude    in path required.
     * @param radius       in path required.
     * @return nearest track point
     *
     * </p>
     *
     * <b>Example:</b>
     * <i>If success</i>
     * <pre>
     *     {
     *          "result": {...}
     *          "error": null
     *      }
     * </pre>
     * <br/>
     * <hr/>
     * <br/>
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/nearest-track-point", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getNearestTrackPoint(HttpSession session,
                                                  HttpServletResponse response,
                                                  @RequestParam(value = "object-id") Long mObjectId,
                                                  @RequestParam(value = "start-date") String startDateStr,
                                                  @RequestParam(value = "end-date") String endDateStr,
                                                  @RequestParam(value = "lat") Double latitude,
                                                  @RequestParam(value = "lon") Double longitude,
                                                  @RequestParam(value = "radius") Double radius) throws JsonProcessingException {

        return getResponseEntity(getNearestTrackPointRestService(session, response, mObjectId, startDateStr, endDateStr, latitude, longitude, radius));
    }
}
