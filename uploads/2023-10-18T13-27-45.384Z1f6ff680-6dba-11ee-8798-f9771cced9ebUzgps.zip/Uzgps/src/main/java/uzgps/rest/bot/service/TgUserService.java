package uzgps.rest.bot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.admin.AdminService;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.TgUser;
import uzgps.persistence.User;
import uzgps.rest.bot.payload.ApiResponse;
import uzgps.rest.bot.payload.TgUserDTO;
import uzgps.rest.bot.payload.TokenDTO;
import uzgps.rest.security.JWTProvider;

import javax.persistence.*;
import java.sql.Timestamp;

@Service
@Component
public class TgUserService {

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    AdminService adminService;

    @Transactional
    public TgUser getTgUser(long id) {

        try {
            TypedQuery<TgUser> query;
            query = entityManager.createNamedQuery("TgUser.findByUserId", TgUser.class);
            query.setParameter("userId", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);

            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public String getEncodedTgUser(Long id) {
        TgUser tgUser = getTgUser(id);

        if (tgUser != null) {
            if (checkTokenExpire(tgUser))
                disableTgUsersById(tgUser.getId());
            else
                return JWTProvider.generateToken(tgUser.toJsonObject());
        }
        return null;
    }

    @Transactional
    public ApiResponse addTgUser(TgUserDTO tgUserDTO) {

        TgUser user = getTgUser(tgUserDTO.getUserId());
        if (user != null) return new ApiResponse("Such user already exist", false);

        TgUser tgUser = new TgUser(
                tgUserDTO.getFirstName(),
                tgUserDTO.getLastName(),
                tgUserDTO.getLanguage(),
                tgUserDTO.getUserId(),
                tgUserDTO.getChatId(),
                tgUserDTO.getState()
        );

        saveTgUser(tgUser);
        return new ApiResponse(tgUser, true);
    }

    @Transactional
    public TgUser saveTgUser(TgUser tgUser) {
        if (tgUser.getId() != null) {
            entityManager.merge(tgUser);
        } else {
            entityManager.persist(tgUser);
        }
        return tgUser;
    }

    @Transactional
    public ApiResponse editUser(Long userId, TgUserDTO tgUserDTO) {

        try {
            TypedQuery<TgUser> query;
            query = entityManager.createNamedQuery("TgUser.findByUserId", TgUser.class);
            query.setParameter("userId", userId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            TgUser tgUser = query.getSingleResult();

            tgUser.setUserToken(tgUserDTO.getUserToken());
            tgUser.setFirstName(tgUserDTO.getFirstName());
            tgUser.setLastName(tgUserDTO.getLastName());
            tgUser.setLanguage(tgUserDTO.getLanguage());
            tgUser.setState(tgUserDTO.getState());
            tgUser.setPhoneNumber(tgUserDTO.getPhoneNumber());
            tgUser.setModDate(new Timestamp(System.currentTimeMillis()));
            tgUser.setStatus(tgUserDTO.getStatus());

            TgUser savedTgUser = saveTgUser(tgUser);
            return new ApiResponse(savedTgUser, true);
        } catch (NoResultException e) {
            return new ApiResponse("User not found", false);
        } catch (Exception e) {
            return new ApiResponse("something went wrong", false);
        }
    }

    public ApiResponse checkUserToken(TokenDTO tokenDTO) {
        if (tokenDTO.getToken() == null) return new ApiResponse("the token must not be null!", false);

        User user = adminService.getUserByApiToken(tokenDTO.getToken());

        if (user == null || user.getTokenExpDate() != null && user.getTokenExpDateTime() < System.currentTimeMillis())
            return new ApiResponse("Token invalid", false);

        return new ApiResponse("Token is valid", true);
    }

    public boolean checkTokenExpire(TgUser tgUser) {
        if (tgUser.getUserToken() != null) {
            User user = adminService.getUserByApiToken(tgUser.getUserToken());

            return user == null || user.getTokenExpDate() != null
                    && user.getTokenExpDateTime() < System.currentTimeMillis();

        }
        return false;
    }

    @Transactional
    public void disableTgUsersById(Long id) {
        if (id != null) {
            Query query;
            query = entityManager.createNamedQuery("TgUser.updateStatusById");
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.executeUpdate();
        }
    }

}
