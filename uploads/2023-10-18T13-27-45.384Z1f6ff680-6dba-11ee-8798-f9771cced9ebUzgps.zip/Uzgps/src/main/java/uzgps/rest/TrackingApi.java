package uzgps.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.netex.core.CoreMain;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GPSTrackPointList;
import uzgps.map.TrackingController;
import uzgps.rest.dto.TrackPointTinyDTO;
import uzgps.route.DouglasPeuckerReducer;
import uzgps.settings.SettingsService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Saidolim on 11.07.2017.
 */
@RestController
@RequestMapping("")
public class TrackingApi {

    @Autowired
    CoreMain coreMain;

    @Autowired
    SettingsService settingsService;

    @Autowired
    TrackingController trackingController;

    @RequestMapping(value = "/track-list.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectList(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                            @RequestParam(value = "user-id", required = true) Long userId,
                                            @RequestParam(value = "contract-id", required = true) Long contractId,
                                            @RequestParam(value = "object-id", required = false) Long mObjectId,
                                            @RequestParam(value = "point-count", required = false) Integer pointCount,
                                            @RequestParam(value = "start-date", required = false) String startDate,
                                            @RequestParam(value = "end-date", required = false) String endDate,
                                            @RequestParam(value = "epsilon", required = false, defaultValue = "200") Integer epsilon) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        List<TrackPointTinyDTO> trackPointList = Collections.emptyList();
        if (mObjectId != null && startDate != null) {
            GPSTrackPointList gpsTrackPointList = trackingController.getGpsTrackPointList(mObjectId, pointCount, startDate, endDate);

            if (gpsTrackPointList != null && gpsTrackPointList.getGpsTrackPoints() != null) {
                // Clear NULL and ZERO coordinates - Delete ZERO points
                coreMain.deleteZeroPoints(gpsTrackPointList);
                List<GPSTrackPoint> reducedGpsTrackPoints = DouglasPeuckerReducer.reduceWithTolerance(gpsTrackPointList.getGpsTrackPoints(), epsilon);
                gpsTrackPointList.setGpsTrackPoints(reducedGpsTrackPoints);
            }

            if (gpsTrackPointList != null
                    && gpsTrackPointList.getGpsTrackPoints() != null
                    && gpsTrackPointList.getGpsTrackPoints().size() > 0) {
                trackPointList = new ArrayList<>();
                for (GPSTrackPoint gpsTrackPoint : gpsTrackPointList.getGpsTrackPoints()) {
                    trackPointList.add(TrackPointTinyDTO.makeOne(gpsTrackPoint));
                }
            }
        }
        return new ResponseEntity(trackPointList, HttpStatus.OK);
    }


}
