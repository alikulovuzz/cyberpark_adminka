package uzgps.rest.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JWTProvider {
    private static final String secretKey = "";

    public static String generateToken(String subject) {
        return Jwts
                .builder()
                .setSubject(subject)
                .signWith(SignatureAlgorithm.HS512, secretKey)
                .compact();
    }

    public static boolean isTokenValid(String token) {
        try {
            String subject = Jwts.parser()
                    .setSigningKey(secretKey)
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();

            return subject.equals(secretKey);

        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isTokenValidExt(String token, String validatedSubject) {
        try {
            String subject = Jwts.parser()
                    .setSigningKey(secretKey)
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();

            return subject.equals(validatedSubject);

        } catch (Exception e) {
            return false;
        }
    }
}
