package uzgps.rest;

import it.geosolutions.imageio.utilities.StringToDouble;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.netex.datatype.MobjectTracks;
import uzgps.admin.ApiService;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.Contract;
import uzgps.persistence.FmsMobjectDistance;
import uzgps.persistence.User;
import uzgps.persistence.api.MObjectExtendedData;
import uzgps.persistence.api.MObjectExtendedWithPhotoData;
import uzgps.persistence.api.MObjectLastData;
import uzgps.rest.dto.PayloadDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stanislav on 01.04.2021 15:40
 */
@SuppressWarnings("SingleStatementInBlock")
@RestController
@RequestMapping("/mobject/")
public class MobjectRest extends BaseRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    protected ApiService apiService;

    /**
     * Return mobject last data, Get request with token authorization in body
     *
     * @param request HttpServletRequest
     * @return List
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "lastData",
            produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> lastData(HttpServletRequest request, @RequestBody PayloadDTO payload) {
        try {
            String token = payload.getToken();

            if (token != null && !token.isEmpty()) {
                return getMobjectLastData(token);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in MobjectRest - lastData POST: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    /**
     * Return mobject last data, Get request with Bearer authorization
     *
     * @param request    HttpServletRequest
     * @param authHeader bearer token
     * @return List
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "lastData",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> lastData(HttpServletRequest request,
                                      @RequestHeader(value = HttpHeaders.AUTHORIZATION) String authHeader) {
        try {
            String token = formatToken(authHeader);

            if (token != null && !token.isEmpty()) {
                return getMobjectLastData(token);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in MobjectRest - lastData: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }


    /**
     * Return mobject last data, Get request with Bearer authorization
     *
     * @param request    HttpServletRequest
     * @param authHeader bearer token
     * @return List
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "lastData/{id}",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> lastDataById(HttpServletRequest request,
                                          @PathVariable Long id,
                                          @RequestHeader(value = HttpHeaders.AUTHORIZATION) String authHeader) {
        try {
            String token = formatToken(authHeader);

            if (token != null && !token.isEmpty()) {
                return getMobjectLastDataById(token, id);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in MobjectRest - lastDataById: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "staffData",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectExtendedData(HttpServletRequest request,
                                                    @RequestHeader(required = true, value = HttpHeaders.AUTHORIZATION) String authHeader,
                                                    @RequestParam(required = false, value = "with-photo", defaultValue = "false") boolean withPhoto) {
        try {
            String token = formatToken(authHeader);

            if (token != null && !token.isEmpty()) {
                User user = adminService.getUserByToken(token);

                if (user != null && isAuthenticate(user, token)) {
                    if (withPhoto) {
                        List<MObjectExtendedWithPhotoData> mObjectExtendedWithPhotoData = apiService.getMobjectExtendedWithPhotoDataByUserId(user.getId());
                        return ResponseUtil.respondSuccess(mObjectExtendedWithPhotoData);
                    } else {
                        List<MObjectExtendedData> mObjectExtendedData = apiService.getMobjectExtendedDataByUserId(user.getId());
                        return ResponseUtil.respondSuccess(mObjectExtendedData);
                    }
                } else {
                    return ResponseUtil.respondUnauthorized("Unauthorized request");
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in MobjectRest - getMobjectStaffData: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "staffData/{mobjectId}",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectExtendedDataById(HttpServletRequest request,
                                                        @PathVariable Long mobjectId,
                                                        @RequestHeader(required = true, value = HttpHeaders.AUTHORIZATION) String authHeader,
                                                        @RequestParam(required = false, value = "with-photo", defaultValue = "false") boolean withPhoto) {
        try {
            String token = formatToken(authHeader);

            if (token != null && !token.isEmpty()) {
                User user = adminService.getUserByToken(token);

                if (user != null && isAuthenticate(user, token)) {
                    if (withPhoto) {
                        MObjectExtendedWithPhotoData mObjectExtendedWithPhotoData = apiService.getMobjectExtendedWithPhotoDataByUserIdAndMobjectId(user.getId(), mobjectId);
                        return ResponseUtil.respondSuccess(mObjectExtendedWithPhotoData);
                    } else {
                        MObjectExtendedData mObjectExtendedData = apiService.getMobjectExtendedDataByUserIdAndMobjectId(user.getId(), mobjectId);
                        return ResponseUtil.respondSuccess(mObjectExtendedData);
                    }
                } else {
                    return ResponseUtil.respondUnauthorized("Unauthorized request");
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in MobjectRest - getMobjectStaffData: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    @RequestMapping(value = "/distance-by-date",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getDistanceByMobjectIdAndDate(HttpServletRequest request,
                                                           @RequestParam(value = "returning-id", required = false) Long returningId,
                                                           @RequestParam(value = "returning-date", required = false) String returningDate,
                                                           @RequestParam(value = "returning-current-odometer", required = false) String returningCurrentOdometerStr,
                                                           @RequestParam(value = "mobject-id", required = true) Long mobjectId,
                                                           @RequestParam(value = "start-date-ms", required = true) Long startDateMs,
                                                           @RequestParam(value = "end-date-ms", required = true) Long endDateMs
    ) {

        if (mobjectId == null || startDateMs == null || endDateMs == null) {
            return ResponseUtil.respondConflict("Bad request");
        }

        try {
            Timestamp startDate = new Timestamp(startDateMs);
            Timestamp endDate = new Timestamp(endDateMs);

            Double returningCurrentOdometer = Converters.strToDouble(returningCurrentOdometerStr, null);

            FmsMobjectDistance result;
            if (returningId == null) {
                result = adminService.getDistanceByMobjectIdAndPeriodV2(mobjectId, startDate, endDate);
            } else {
                result = adminService.getDistanceByMobjectIdAndPeriodV2(returningId, returningDate, returningCurrentOdometer,
                        mobjectId, startDate, endDate);
            }

            return ResponseUtil.respondSuccess(result);
        } catch (Exception e) {
            logger.error("Error in getDistanceByMobjectIdAndDate", e);
            return ResponseUtil.respondConflict("Something went wrong:" + e.getCause());
        }
    }

    @RequestMapping(value = "/distances-yesterday",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getDistancesYesterday(HttpServletRequest request) {
        try {
            List<FmsMobjectDistance> result = adminService.getAllMobjectsDistancesYesterday();
            return ResponseUtil.respondSuccess(result);
        } catch (Exception e) {
            logger.error("Error in getDistancesYesterday", e);
            return ResponseUtil.respondConflict("Something went wrong:" + e.getCause());
        }
    }

    @RequestMapping(value = "/distances-today",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getDistancesToday(HttpServletRequest request) {
        try {
            List<FmsMobjectDistance> result = adminService.getAllMobjectsDistancesToday();
            return ResponseUtil.respondSuccess(result);
        } catch (Exception e) {
            logger.error("Error in getDistancesToday", e);
            return ResponseUtil.respondConflict("Something went wrong:" + e.getCause());
        }
    }


    /**
     * Return mobjects data from core, Get request with token authorization in header
     *
     * @param session
     * @param token
     * @return
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "getAll",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getAllFromCore(HttpSession session,
                                            @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token) {
        try {
            token = formatToken(token);

            User user = getUserByToken(token);
            List<MobjectTracks> mobjectTracks = new ArrayList<>();

            if (user != null && isAuthenticate(user, token)) {
                if (user.getRoleId() == UZGPS_CONST.USER_ROLE_USER) {
                    mobjectTracks = coreMain.getMobjectTracksListByUser(user.getId(), 0L);
                } else {
                    List<Contract> contracts = adminService.getUserContractsByUserId(user.getId());
                    List<MobjectTracks> tempMobjectTracksList;
                    for (Contract contract : contracts) {
                        tempMobjectTracksList = coreMain.getMobjectTracksListByContract(contract.getId(), 0L);

                        if (tempMobjectTracksList != null && !tempMobjectTracksList.isEmpty()) {
                            mobjectTracks.addAll(tempMobjectTracksList);
                        }
                    }
                }
                return ResponseUtil.respondSuccess(mobjectTracks);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in MobjectRest - getAllFromCore: " + e.getMessage());
        }
        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    private ResponseEntity<?> getMobjectLastData(String token) {
        User user = adminService.getUserByToken(token);

        if (user != null && isAuthenticate(user, token)) {
            List<MObjectLastData> mObjectLastData = apiService.getMobjectLastDataByUserId(user.getId());

            for (MObjectLastData mld : mObjectLastData) {
                if (mld.getTpTimestamp() != null) {
                    mld.setTpTimestampFmt(mld.getTpTimestamp());
                }
            }
            return ResponseUtil.respondSuccess(mObjectLastData);
        } else {
            return ResponseUtil.respondUnauthorized("Unauthorized request");
        }
    }

    private ResponseEntity<?> getMobjectLastDataById(String token, Long mobjectId) {
        User user = adminService.getUserByToken(token);

        if (user != null && isAuthenticate(user, token)) {
            MObjectLastData mObjectLastData = apiService.getMobjectLastDataByUserIdAndMobjectId(user.getId(), mobjectId);

            if (mObjectLastData != null && mObjectLastData.getTpTimestamp() != null) {
                mObjectLastData.setTpTimestampFmt(mObjectLastData.getTpTimestamp());
            }

            return ResponseUtil.respondSuccess(mObjectLastData);
        } else {
            return ResponseUtil.respondUnauthorized("Unauthorized request");
        }
    }

}
