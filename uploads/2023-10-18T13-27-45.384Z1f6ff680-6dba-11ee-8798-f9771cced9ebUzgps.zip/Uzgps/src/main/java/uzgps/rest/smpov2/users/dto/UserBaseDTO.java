package uzgps.rest.smpov2.users.dto;

import uzgps.persistence.User;

public class UserBaseDTO {
    private Long id;
    private String login;
    private String surName;
    private String name;
    private String middleName;
    private String fullName;
    private Long contractId;
    private Long roleId;

    public static UserBaseDTO toModel(User user) {
        UserBaseDTO model = new UserBaseDTO();
        model.setId(user.getId());
        model.setLogin(user.getLogin());
        model.setSurName(user.getSurName());
        model.setName(user.getName());
        model.setMiddleName(user.getMiddleName());
        model.setContractId(user.getContractId());
        model.setRoleId(user.getRoleId());
        return model;
    }

    public UserBaseDTO() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getSurName() {
        return surName;
    }

    public void setSurName(String surName) {
        this.surName = surName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    public Long getContractId() {
        return contractId;
    }

    public void setContractId(Long contractId) {
        this.contractId = contractId;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }


}
