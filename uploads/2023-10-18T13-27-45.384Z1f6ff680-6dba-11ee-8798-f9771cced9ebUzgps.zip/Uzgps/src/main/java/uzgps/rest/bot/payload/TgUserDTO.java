package uzgps.rest.bot.payload;

import javax.validation.constraints.NotNull;

public class TgUserDTO {

    private String firstName;

    private String lastName;

    private String language;

    private String phoneNumber;

    @NotNull
    private long userId;

    @NotNull
    private long chatId;

    private String userToken;

    @NotNull
    private int state;

    private String status;

    public TgUserDTO() {
    }

    public TgUserDTO(String firstName, String lastName, String language, String phoneNumber, long userId, long chatId, String userToken, int state, String status) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.language = language;
        this.phoneNumber = phoneNumber;
        this.userId = userId;
        this.chatId = chatId;
        this.userToken = userToken;
        this.state = state;
        this.status = status;
    }

    public TgUserDTO(String firstName, String lastName, String language, String phoneNumber, long userId, long chatId, String userToken, int state) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.language = language;
        this.phoneNumber = phoneNumber;
        this.userId = userId;
        this.chatId = chatId;
        this.userToken = userToken;
        this.state = state;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getChatId() {
        return chatId;
    }

    public void setChatId(long chatId) {
        this.chatId = chatId;
    }

    public String getUserToken() {
        return userToken;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
}
