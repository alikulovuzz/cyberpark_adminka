package uzgps.rest.bot.payload;

public class ApiResponse {

    private Object response;
    private boolean isSuccess;

    public ApiResponse(Object response, boolean isSuccess) {
        this.response = response;
        this.isSuccess = isSuccess;
    }

    public ApiResponse() {
    }

    public Object getResponse() {
        return response;
    }

    public void setResponse(Object response) {
        this.response = response;
    }

    public boolean getIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }
}
