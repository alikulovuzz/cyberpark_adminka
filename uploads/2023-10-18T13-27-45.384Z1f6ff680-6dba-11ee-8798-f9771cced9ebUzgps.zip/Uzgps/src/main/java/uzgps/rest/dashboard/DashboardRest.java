package uzgps.rest.dashboard;

import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.netex.datatype.MobjectTracks;
import uzgps.common.Converters;
import uzgps.dashboard.DTO.DashboardData;
import uzgps.dashboard.DTO.DonutData;
import uzgps.dashboard.DTO.MonitoredZoiData;
import uzgps.dashboard.DashboardService;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.User;
import uzgps.rest.BaseDashboardRest;
import uzgps.rest.ResponseUtil;
import uzgps.settings.SettingsService;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

import static uzgps.common.Converters.formatListToStr;

/**
 * Created by Stanislav on 07.04.2022 15:40
 */
@SuppressWarnings({"SingleStatementInBlock", "DuplicatedCode"})
@RestController
@RequestMapping("/dashboard/")
public class DashboardRest extends BaseDashboardRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    DashboardService dashboardService;

    @Autowired
    SettingsService settingsService;

    @Autowired
    private HttpSession httpSession;


    private static final String MOBJECT_TYPE_DATA_URL = "mobject-type-data";

    private static final String MOBJECT_APPOINTMENT_DATA_URL = "mobject-appointment-data";
    private static final String MOBJECT_STATE_DATA_URL = "mobject-state-data";
    private static final String MOBJECT_BRAND_DATA_URL = "mobject-brand-data";

    private static final String MOBJECT_INDICATOR_STATES_DATA_TOTAL_URL = "mobject-indicator-states-data-total";
    private static final String MOBJECT_INDICATOR_STATES_DATA_URL = "mobject-indicator-states-data";

    private static final String MOBJECT_MONITORED_ZOI_DATA_URL = "monitored-zoi-data";

    private static final String MOBJECT_LOCATION_DATA = "mobject-location-data";

    private static final String OVERALL_DATA = "overall-data";


    /**
     * Return mobject type data
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_TYPE_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectTypeData(HttpSession session,
                                                @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            boolean isForChart = Converters.strToBoolean(isForChartStr, false);

            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isForChart) {
                    JsonObject mobjectTypeDataJson = getMobjectTypeDataForChart(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    List<DonutData> mobjectTypeData = getMobjectTypeData(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectTypeData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return mobject appointment data
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_APPOINTMENT_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectAppointmentData(HttpSession session,
                                                       @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                       @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                       @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                       @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            boolean isForChart = Converters.strToBoolean(isForChartStr, false);

            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isForChart) {
                    JsonObject mobjectTypeDataJson = getMobjectAppointmentDataForChart(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    List<DonutData> mobjectTypeData = getMobjectAppointmentData(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectAppointmentData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return mobject state data
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_STATE_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectStateData(HttpSession session,
                                                 @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                 @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                 @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                 @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            boolean isForChart = Converters.strToBoolean(isForChartStr, false);

            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isForChart) {
                    JsonObject mobjectTypeDataJson = getMobjectStateDataForChart(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    List<DonutData> mobjectTypeData = getMobjectStateData(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectStateData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return mobject brand data
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_BRAND_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectBrandData(HttpSession session,
                                                 @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                 @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                 @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                 @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            boolean isForChart = Converters.strToBoolean(isForChartStr, false);

            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isForChart) {
                    JsonObject mobjectTypeDataJson = getMobjectBrandDataForChart(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    List<DonutData> mobjectTypeData = getMobjectBrandData(regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectBrandData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return mobject indicator states data totals by all user contracts
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_INDICATOR_STATES_DATA_TOTAL_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectIndicatorStatesDataTotal(HttpSession session,
                                                                @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                                @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                                @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                                @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isAuthenticateByUser) {
                    JsonObject mobjectTypeDataJson = getObjectStatesDataTotal(session, regionId);
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    JsonObject mobjectTypeData = getObjectStatesDataTotal(user, contractId);
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectIndicatorStatesDataTotal", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return mobject indicator states data by contracts
     *
     * @param session  HttpSession
     * @param regionId Filter - regionId
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_INDICATOR_STATES_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectIndicatorStatesData(HttpSession session,
                                                           @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId) {
        try {
            boolean isAuthenticateByUser = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            }

            if (isAuthenticateByUser) {
                JsonObject mobjectStatesDataJson = getObjectStatesData(session);
                return ResponseUtil.respondSuccess(mobjectStatesDataJson);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectIndicatorStatesData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return quantity of mobjects visiting monitored zoi
     *
     * @param session    HttpSession
     * @param token      Bearer token for external services
     * @param contractId Contract
     * @return List<MonitoredZoiData>
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_MONITORED_ZOI_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMonitoredZoiData(HttpSession session,
                                                 @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                 @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId) {
        try {
            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractId = MainController.getUserContractId(session);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if (contractId == null || contractId == 0) {
                return ResponseUtil.respondUnauthorized("Not found required parameter");
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                List<MonitoredZoiData> monitoredZoiData = dashboardService.getMonitoredZoiData(contractIds);
                return ResponseUtil.respondSuccess(monitoredZoiData);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMonitoredZoiData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return quantity of mobjects located in each region of Uzbekistan
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_LOCATION_DATA,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectLocationData(HttpSession session,
                                                    @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                    @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                    @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                    @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            boolean isForChart = Converters.strToBoolean(isForChartStr, false);

            List<Long> contractIds = new ArrayList<>();
            String contractIdsStr = "";

            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }
            contractIdsStr = formatListToStr(contractIds);

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isForChart) {
                    JsonObject mobjectLocationDataJson = getMobjectLocationDataForChart(contractIdsStr, regionId);
                    return ResponseUtil.respondSuccess(mobjectLocationDataJson);
                } else {
                    List<DonutData> mobjectLocationData = getMobjectLocationData(contractIdsStr, regionId);
                    return ResponseUtil.respondSuccess(mobjectLocationData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectLocationData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return data from report server. Fuel, mileage, violations
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param startDate     Filter - startDate (dd-mm-yyyy)
     * @param endDate       Filter - endDate (dd-mm-yyyy)
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = OVERALL_DATA,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getOverallData(HttpSession session,
                                            @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                            @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                            @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                            @RequestParam(value = "start-date") String startDate,
                                            @RequestParam(value = "end-date") String endDate,
                                            @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {

        try {
            List<Long> contractIds = new ArrayList<>();
            String contractIdsStr = "";
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }
            contractIdsStr = formatListToStr(contractIds);

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                List<DashboardData> overallData = getOverallData(regionId, contractIdsStr, startDate, endDate);
                return ResponseUtil.respondSuccess(overallData);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getOverallData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    private JsonObject getObjectStatesDataTotal(HttpSession session, Integer regionId) {
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();

        List<MobjectTracks> mObjectTracksList = getMobjectTracksList(session, regionId);
        return getObjectStatesEntries(isShowSuspendedObjects, mObjectTracksList);
    }

    private JsonObject getObjectStatesDataTotal(User user, Long contractId) {
        ContractSettings contractSettings = settingsService.getContractSettingsByContractId(contractId);
        boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();

        List<MobjectTracks> mObjectTracksList = getMobjectTracksList(user.getId(), contractId, false);
        return getObjectStatesEntries(isShowSuspendedObjects, mObjectTracksList);
    }

    private JsonObject getObjectStatesData(HttpSession session) {
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();

        JsonObject resultJsonObject = new JsonObject();
        JsonArray resultJsonArray = new JsonArray();
        List<Contract> contracts = new ArrayList<>();

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            contracts = MainController.getUserContracts(session);
        } else {
            Contract contract = MainController.getUserContract(session);
            contracts.add(contract);
        }

        for (Contract contract : contracts) {
            JsonObject contractResultData = new JsonObject();
            JsonObject contractData;

            Long userId = 0L;

            if (MainController.getInterfaceUserId() != null) {
                userId = MainController.getInterfaceUserId();
            } else {
                userId = MainController.getUserId();
            }

            List<MobjectTracks> mObjectTracksList = getMobjectTracksList(userId, contract.getId(), false);
            contractData = getObjectStatesEntries(isShowSuspendedObjects, mObjectTracksList);
            contractResultData.put("contractId", contract.getId());
            contractResultData.put("data", contractData);

            resultJsonArray.add(contractResultData);
        }
        resultJsonObject.put("contractsData", resultJsonArray);

        return resultJsonObject;
    }

    public static JsonObject getObjectStatesEntries(boolean isShowSuspendedObjects, List<MobjectTracks> mObjectTracksList) {
        MobjectStatusesCounter mobjectStatusesCounter = new MobjectStatusesCounter(mObjectTracksList, isShowSuspendedObjects);

        JsonObject objectStateDate = new JsonObject();
        objectStateDate.put("objectCount", mobjectStatusesCounter.getObjectCount());
        objectStateDate.put("activeObjectsCount", mobjectStatusesCounter.getActiveObjectsCount());
        objectStateDate.put("parkingObjectsCount", mobjectStatusesCounter.getParkingObjectsCount());
        objectStateDate.put("connectionLostObjectsCount", mobjectStatusesCounter.getConnectionLostObjectsCount());
        objectStateDate.put("noDataObjectsCount", mobjectStatusesCounter.getNoDataObjectsCount());

        return objectStateDate;
    }

    private JsonObject getMobjectTypeDataForChart(Integer regionId, List<Long> contractIds) {
        return DashboardDataConverter.splitObjectsForDonut(getMobjectTypeData(regionId, contractIds));
    }

    private List<DonutData> getMobjectTypeData(Integer regionId, List<Long> contractIds) {
        return dashboardService.getMobjectTypeData(regionId, contractIds);
    }

    private JsonObject getMobjectAppointmentDataForChart(Integer regionId, List<Long> contractIds) {
        List<DonutData> mobjectTypeData = dashboardService.getMobjectAppointmentData(regionId, contractIds);
        return DashboardDataConverter.splitObjectsForDonut(mobjectTypeData);
    }

    private List<DonutData> getMobjectAppointmentData(Integer regionId, List<Long> contractIds) {
        return dashboardService.getMobjectAppointmentData(regionId, contractIds);
    }

    private JsonObject getMobjectStateDataForChart(Integer regionId, List<Long> contractIds) {
        List<DonutData> mobjectTypeData = dashboardService.getMobjectStateData(regionId, contractIds);
        return DashboardDataConverter.splitObjectsForDonut(mobjectTypeData);
    }

    private List<DonutData> getMobjectStateData(Integer regionId, List<Long> contractIds) {
        return dashboardService.getMobjectStateData(regionId, contractIds);
    }

    private JsonObject getMobjectBrandDataForChart(Integer regionId, List<Long> contractIds) {
        List<DonutData> mobjectTypeData = dashboardService.getMobjectBrandData(regionId, contractIds);
        return DashboardDataConverter.splitObjectsForDonut(mobjectTypeData);
    }

    private List<DonutData> getMobjectBrandData(Integer regionId, List<Long> contractIds) {
        return dashboardService.getMobjectBrandData(regionId, contractIds);
    }

    private JsonObject getMobjectLocationDataForChart(String contractIds, Integer regionId) {
        return DashboardDataConverter.splitObjectsForDonut(getMobjectLocationData(contractIds, regionId));
    }

    private List<DonutData> getMobjectLocationData(String contractIds, Integer regionId) {
        return dashboardService.getMobjectLocationData(contractIds, regionId);
    }

    private List<DashboardData> getOverallData(Integer regionId, String contractIds, String startDate, String endDate) {
        return dashboardService.getOverallData(regionId, contractIds, startDate, endDate);
    }

}
