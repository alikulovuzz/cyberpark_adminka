package uzgps.rest.dto;


import uz.netex.datatype.MobjectBig;

import java.util.List;

public class GroupedMobjectDTO {

    private String groupName;
    private Long groupId;
    private List<MobjectBig> mobjectList;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    public List<MobjectBig> getMobjectList() {
        return mobjectList;
    }

    public void setMobjectList(List<MobjectBig> mobjectList) {
        this.mobjectList = mobjectList;
    }
}
