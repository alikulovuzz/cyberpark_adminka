package uzgps.rest.dto;

import uz.netex.datatype.GPSTrackPoint;

/**
 * Created by Gayratjon on 10/17/2016.
 */
public class TrackLocationDTO {
    private Long trackId;
    private Double latitude;
    private Double longitude;

    private TrackLocationDTO() {
    }

    public static TrackLocationDTO makeOne(GPSTrackPoint trackPoint) {
        TrackLocationDTO trackLocationDTO = new TrackLocationDTO();
        trackLocationDTO.trackId = trackPoint.getId();
        trackLocationDTO.latitude = trackPoint.getLatitude();
        trackLocationDTO.longitude = trackPoint.getLongitude();
        return trackLocationDTO;
    }

    public Long getTrackId() {
        return trackId;
    }

    public void setTrackId(Long trackId) {
        this.trackId = trackId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
