package uzgps.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import uzgps.excel.ExcelDownloadTrackData;
import uzgps.map.TrackingController;
import uzgps.persistence.User;
import uzgps.report.ReportController;
import uzgps.rest.response.ResponseApi;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
@RequestMapping(value = "")
public class MobileReportsAPI extends BaseRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private static final String URL_TRACKS_XLS = "/get-tracks-xls.json";
    private static final String URL_REPORT_BY_ID = "/get-report-by-id.json";
    private static final String URL_REPORT_LIST = "/get-report-list.json";

    @Autowired
    SettingsService settingsService;

    @Autowired
    ExcelDownloadTrackData excelDownloadTrackData;

    @Autowired
    ReportController reportController;

    @RequestMapping(value = URL_TRACKS_XLS, method = RequestMethod.GET)
    public void getTracksXls(HttpServletResponse httpServletResponse,
                             @RequestParam(value = "object-id", required = false) Long mObjectId,
                             @RequestParam(value = "start-date", required = false) String startDate,
                             @RequestParam(value = "end-date", required = false) String endDate,
                             @RequestParam(value = "report-token", required = false, defaultValue = "0") long reportToken,
                             @RequestParam(value = "point-count", required = false) Integer pointCount) throws Exception {

        TrackingController controller = new TrackingController();
        controller.getXLSWithoutSession(
                coreMain,
                settingsService,
                excelDownloadTrackData,
                httpServletResponse,
                mObjectId,
                startDate,
                endDate,
                pointCount,
                reportToken);
    }

    @RequestMapping(value = URL_REPORT_BY_ID, method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView getReport(HttpServletRequest httpServletRequest,
                                  HttpServletResponse httpServletResponse,
                                  @RequestParam(value = "type") String type,
                                  @RequestParam(value = "reportId") Long reportId,
                                  @RequestParam(value = "contractId") Long contractId,
                                  @RequestParam(value = "userId") Long userId,
                                  @RequestParam(value = "objectId", required = false) Long objectId,
                                  @RequestParam(value = "startDate", required = false) String startDate,
                                  @RequestParam(value = "endDate", required = false) String endDate,
                                  @RequestParam(value = "language", required = false, defaultValue = "ru") String language
    ) throws ClassNotFoundException, IOException {

        try {
            User user = findUser(httpServletRequest);
            if (user != null) {
                return reportController.viewReportForMobile(
                        httpServletRequest,
                        httpServletResponse,
                        language,
                        type,
                        reportId,
                        contractId,
                        userId,
                        objectId,
                        startDate,
                        endDate
                );
            } else {
                httpServletResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
            }
        } catch (ServletException e) {
            logger.error("Error in getReport", e);
        }
        return null;
    }

    @RequestMapping(value = URL_REPORT_LIST, produces = "application/json", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<?> getReportList(
            HttpServletRequest httpServletRequest,
            @RequestParam(value = "contractId") Long contractId
    ) {
        ResponseApi response = new ResponseApi();
        try {
            User user = findUser(httpServletRequest);
            if (user != null) {
                response = reportController.getReportListByContractId(contractId);
            } else {
                response.setError("User not found!");
            }
        } catch (Exception e) {
            response.setError(e.getMessage());
        }
        return ResponseEntity.ok(response);
    }

    private User findUser(HttpServletRequest httpServletRequest) {
        User user = null;
        try {
            String bearerToken = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION);
            if (bearerToken == null) {
                bearerToken = httpServletRequest.getHeader("X-" + HttpHeaders.AUTHORIZATION);
            }
            user = getUserByToken(bearerToken);
        } catch (Exception ignored) { }
        return user;
    }
}
