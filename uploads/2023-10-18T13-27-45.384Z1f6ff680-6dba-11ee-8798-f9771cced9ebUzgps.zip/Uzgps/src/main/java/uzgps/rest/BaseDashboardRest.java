package uzgps.rest;

import uz.netex.datatype.MobjectTracks;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.persistence.Contract;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

public class BaseDashboardRest extends BaseRest {

    protected static final String MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN_NAME = "Газовоз (цистерна)";
    protected static final String MOBJECT_TYPE_GAS_CAR_TYPE_BALLOON_NAME = "Газовоз (баллон)";

    protected static final long MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN = 32;
    protected static final long MOBJECT_TYPE_GAS_CAR_TYPE_BALLOON = 33;
    protected static final long MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN_WAGON = 34;

    protected List<MobjectTracks> getMobjectTracksList(Long userId, Long contractId, boolean isShowObjectsOfAllContracts) {
        List<MobjectTracks> mObjectTracksList = new ArrayList<>();

        Long roleId = getUserRoleByUserIdAndContractId(userId, contractId);

        if (roleId == null || roleId == 0) {
            return mObjectTracksList;
        }

        if (roleId == UZGPS_CONST.USER_ROLE_USER) {
            mObjectTracksList = coreMain.getMobjectTracksListByUser(userId, 0L);
        } else {
            if (isShowObjectsOfAllContracts) {
                List<MobjectTracks> tempMobjectTracksList;

                List<Contract> contracts = adminService.getUserContractsByUserId(userId);

                for (Contract contract : contracts) {
                    tempMobjectTracksList = coreMain.getMobjectTracksListByContract(contract.getId(), 0L);

                    if (tempMobjectTracksList != null && tempMobjectTracksList.size() > 0) {
                        mObjectTracksList.addAll(tempMobjectTracksList);
                    }
                }
            } else {
                mObjectTracksList = coreMain.getMobjectTracksListByContract(contractId, 0L);
            }
        }

        return mObjectTracksList;
    }

    protected List<MobjectTracks> getMobjectTracksList(HttpSession session, Integer regionId) {
        List<MobjectTracks> mObjectTracksList = null;

//        System.out.println(MainController.getUser().getRoleId());

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            mObjectTracksList = coreMain.getMobjectTracksListByUser(MainController.getInterfaceUserId(), 0L);
        } else {
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<MobjectTracks> tempMobjectTracksList;

                List<Contract> contracts = MainController.getUserContracts(session);

                for (Contract contract : contracts) {
                    if (contract.getCustomerRegion() != regionId.longValue() && regionId != 0) {
                        continue;
                    }

                    tempMobjectTracksList = coreMain.getMobjectTracksListByContract(contract.getId(), 0L);

                    if (tempMobjectTracksList != null && tempMobjectTracksList.size() > 0) {
                        if (mObjectTracksList == null) mObjectTracksList = new ArrayList<>();
                        {
                            mObjectTracksList.addAll(tempMobjectTracksList);
                        }
                    }
                }
            } else {
                mObjectTracksList = coreMain.getMobjectTracksListByContract(MainController.getUserContractId(session), 0L);
            }
        }

        return mObjectTracksList;
    }

    protected List<Long> getMobjectTypesIdGasCars() {
        List<Long> mobjectTypesId = new ArrayList<>();
        mobjectTypesId.add(MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN);
        mobjectTypesId.add(MOBJECT_TYPE_GAS_CAR_TYPE_BALLOON);
        mobjectTypesId.add(MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN_WAGON);
        return mobjectTypesId;
    }

    protected List<Long> getIdListByContracts(List<Contract> contracts) {
        List<Long> contractIdList = new ArrayList<>();

        for (Contract contract : contracts) {
            contractIdList.add(contract.getId());
        }
        return contractIdList;
    }

    protected static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }
}
