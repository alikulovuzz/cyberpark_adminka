package uzgps.rest.dto;

import uz.netex.datatype.MobjectBig;
import uzgps.map.models.MobjectBigZoned;

import java.util.List;

public class ZonedMobjectDTO {
    private Long zoneId;
    private String zoneName;

    // Z = zoi or P = poi
    private String zoneType;
    private List<MobjectBig> mobjectBigList;


    public Long getZoneId() {
        return zoneId;
    }

    public void setZoneId(Long zoneId) {
        this.zoneId = zoneId;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public String getZoneType() {
        return zoneType;
    }

    public void setZoneType(String zoneType) {
        this.zoneType = zoneType;
    }

    public List<MobjectBig> getMobjectBigList() {
        return mobjectBigList;
    }

    public void setMobjectBigList(List<MobjectBig> mobjectBigList) {
        this.mobjectBigList = mobjectBigList;
    }
}
