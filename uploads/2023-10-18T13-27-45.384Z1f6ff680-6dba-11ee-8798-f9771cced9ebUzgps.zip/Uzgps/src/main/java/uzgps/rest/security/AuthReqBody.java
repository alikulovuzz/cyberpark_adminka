package uzgps.rest.security;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AuthReqBody {

    private String username;
    private String password = "";
    private long contractId;

    @JsonProperty("show-objects-of-all-contracts")
    private boolean showObjectsOfAllContracts = false;


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getContractId() {
        return contractId;
    }

    public void setContractId(long contractId) {
        this.contractId = contractId;
    }


    public boolean getIsShowObjectsOfAllContracts() {
        return showObjectsOfAllContracts;
    }
    @JsonProperty("show-objects-of-all-contracts")
    public void setShowObjectsOfAllContracts(boolean showObjectsOfAllContracts) {
        this.showObjectsOfAllContracts = showObjectsOfAllContracts;
    }
}
