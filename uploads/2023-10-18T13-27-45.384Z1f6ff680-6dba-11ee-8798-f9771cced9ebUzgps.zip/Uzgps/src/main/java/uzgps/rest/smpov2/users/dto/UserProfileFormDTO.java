package uzgps.rest.smpov2.users.dto;

import org.springframework.web.multipart.MultipartFile;

public class UserProfileFormDTO {
    private String login;
    private String surName;
    private String email;
    private String name;
    private String middleName;
    private String position;
    private String phoneMobile;
    private String phoneLine;

    public UserProfileFormDTO() {
    }


    public String getLogin() {
        return login;
    }

    public String getSurName() {
        return surName;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public String getPosition() {
        return position;
    }

    public String getPhoneMobile() {
        return phoneMobile;
    }

    public String getPhoneLine() {
        return phoneLine;
    }
}
