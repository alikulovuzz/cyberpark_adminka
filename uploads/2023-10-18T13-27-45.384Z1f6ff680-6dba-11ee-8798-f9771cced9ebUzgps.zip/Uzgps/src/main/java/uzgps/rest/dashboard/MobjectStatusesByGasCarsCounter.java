package uzgps.rest.dashboard;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.datatype.GPSTrackPoint;
import uzgps.common.UZGPS_CONST;
import uzgps.dashboard.DTO.MobjectTracksExtended;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class MobjectStatusesByGasCarsCounter {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    protected List<GasTypeCounter> gasTypeCounterList = new ArrayList<>();

    public MobjectStatusesByGasCarsCounter(List<MobjectTracksExtended> mObjectTracks, boolean isShowSuspendedObjects) {
        fillMobjectTypesGas(mObjectTracks);
        calculate(mObjectTracks, isShowSuspendedObjects);
    }

    private void fillMobjectTypesGas(List<MobjectTracksExtended> mObjectTracks) {

        List<MobjectTracksExtended> distinctElements = mObjectTracks.stream()
                .filter(distinctByKey(MobjectTracksExtended::getMobjectTypeId))
                .collect(Collectors.toList());

        for (MobjectTracksExtended mobjectTracksExtended : distinctElements) {
            GasTypeCounter gasTypeCounter = new GasTypeCounter();
            gasTypeCounter.setId(mobjectTracksExtended.getMobjectTypeId());
            gasTypeCounter.setName(mobjectTracksExtended.getMobjectTypeName());
            gasTypeCounterList.add(gasTypeCounter);
        }
    }

    private void calculate(List<MobjectTracksExtended> mObjectTracksList, boolean isShowSuspendedObjects) {
        try {

            if (!isShowSuspendedObjects) {
                mObjectTracksList.removeIf(mObjectTr -> mObjectTr.getMobject() != null &&
                        mObjectTr.getMobject().getGpsUnitBig() != null &&
                        mObjectTr.getMobject().getGpsUnitBig().getBlock().equals(UZGPS_CONST.STATUS_BLOCK));
            }

            for (MobjectTracksExtended mobjectWithTracks : mObjectTracksList) {
                List<GPSTrackPoint> trackPoints = mobjectWithTracks.getTracks();
                GPSTrackPoint gpsTrackPoint;

                incrementObjectCount(mobjectWithTracks.getMobjectTypeId());

                if (trackPoints != null && !trackPoints.isEmpty()) {
                    gpsTrackPoint = trackPoints.get(0);

                    byte movement = gpsTrackPoint.getMovement();
                    byte online = gpsTrackPoint.getOnline();

                    if (movement == 1 && online == 1) {
                        // Object is moving "GREEN"
                        incrementActiveCount(mobjectWithTracks.getMobjectTypeId());
                    } else if (movement == 2 && online == 1) {
                        incrementStoppedCount(mobjectWithTracks.getMobjectTypeId());
                    } else if (movement == 0 && online == 1) {
                        incrementParkingCount(mobjectWithTracks.getMobjectTypeId());
                    } else if (online == 0) {
                        // Connection lost
                        incrementConnectionLostCount(mobjectWithTracks.getMobjectTypeId());
                    } else if (movement == -1 && online == -1) {
                        // Object is online, but no data to display
                        incrementActiveCount(mobjectWithTracks.getMobjectTypeId());
                    } else {
                        incrementNoDataCount(mobjectWithTracks.getMobjectTypeId());
                    }
                } else {
                    incrementNoDataCount(mobjectWithTracks.getMobjectTypeId());
                }
            }
        } catch (Exception e) {
            logger.error("Error in MobjectStatusesByGasCarsCounter calculate", e);
        }
    }

    private void incrementObjectCount(Long mobjectTypeId) {
        for (GasTypeCounter gasTypeCounter : gasTypeCounterList) {
            if (gasTypeCounter.getId().equals(mobjectTypeId)) {
                gasTypeCounter.incrementObjectCount();
            }
        }
    }

    private void incrementActiveCount(Long mobjectTypeId) {
        for (GasTypeCounter gasTypeCounter : gasTypeCounterList) {
            if (gasTypeCounter.getId().equals(mobjectTypeId)) {
                gasTypeCounter.incrementActiveObjectsCount();
            }
        }
    }

    private void incrementStoppedCount(Long mobjectTypeId) {
        for (GasTypeCounter gasTypeCounter : gasTypeCounterList) {
            if (gasTypeCounter.getId().equals(mobjectTypeId)) {
                gasTypeCounter.incrementStoppedObjectsCount();
            }
        }
    }
    private void incrementParkingCount(Long mobjectTypeId) {
        for (GasTypeCounter gasTypeCounter : gasTypeCounterList) {
            if (gasTypeCounter.getId().equals(mobjectTypeId)) {
                gasTypeCounter.incrementParkingObjectsCount();
            }
        }
    }

    private void incrementConnectionLostCount(Long mobjectTypeId) {
        for (GasTypeCounter gasTypeCounter : gasTypeCounterList) {
            if (gasTypeCounter.getId().equals(mobjectTypeId)) {
                gasTypeCounter.incrementConnectionLostObjectsCount();
            }
        }
    }

    private void incrementNoDataCount(Long mobjectTypeId) {
        for (GasTypeCounter gasTypeCounter : gasTypeCounterList) {
            if (gasTypeCounter.getId().equals(mobjectTypeId)) {
                gasTypeCounter.incrementNoDataObjectsCount();
            }
        }
    }


    private static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    protected static class GasTypeCounter {
        Long id;
        String name;

        private int objectCount = 0;
        private int activeObjectsCount = 0;
        private int stoppedObjectsCount = 0;
        private int parkingObjectsCount = 0;
        private int connectionLostObjectsCount = 0;
        private int noDataObjectsCount = 0;

        public Long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public int getObjectCount() {
            return objectCount;
        }

        public void incrementObjectCount() {
            this.objectCount += 1;
        }

        public int getActiveObjectsCount() {
            return activeObjectsCount;
        }

        public void incrementActiveObjectsCount() {
            this.activeObjectsCount += 1;
        }

        public int getStoppedObjectsCount() {
            return stoppedObjectsCount;
        }

        public void incrementStoppedObjectsCount() {
            this.stoppedObjectsCount += 1;
        }

        public int getParkingObjectsCount() {
            return parkingObjectsCount;
        }

        public void incrementParkingObjectsCount() {
            this.parkingObjectsCount += 1;
        }

        public int getConnectionLostObjectsCount() {
            return connectionLostObjectsCount;
        }

        public void incrementConnectionLostObjectsCount() {
            this.connectionLostObjectsCount += 1;
        }

        public int getNoDataObjectsCount() {
            return noDataObjectsCount;
        }

        public void incrementNoDataObjectsCount() {
            this.noDataObjectsCount += 1;
        }

        public void setObjectCount(int objectCount) {
            this.objectCount = objectCount;
        }

        public void setActiveObjectsCount(int activeObjectsCount) {
            this.activeObjectsCount = activeObjectsCount;
        }

        public void setStoppedObjectsCount(int stoppedObjectsCount) {
            this.stoppedObjectsCount = stoppedObjectsCount;
        }

        public void setParkingObjectsCount(int parkingObjectsCount) {
            this.parkingObjectsCount = parkingObjectsCount;
        }

        public void setConnectionLostObjectsCount(int connectionLostObjectsCount) {
            this.connectionLostObjectsCount = connectionLostObjectsCount;
        }

        public void setNoDataObjectsCount(int noDataObjectsCount) {
            this.noDataObjectsCount = noDataObjectsCount;
        }
    }
}
