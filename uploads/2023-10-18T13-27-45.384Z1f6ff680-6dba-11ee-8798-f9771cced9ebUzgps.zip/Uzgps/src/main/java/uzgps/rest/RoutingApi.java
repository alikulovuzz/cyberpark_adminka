package uzgps.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.netex.core.CoreMain;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.CoreRoute;
import uzgps.common.Converters;
import uzgps.rest.dto.RoutesDTO;

/**
 * Created by Stanislav on 31.07.2017 15:18
 */
@RestController
@RequestMapping("")
public class RoutingApi {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTES_BY_CONTRACT = "/routes-by-contract-id.json";
    private final static String URL_HAS_ROUTING_ACCESS = "/has-routing-access.json";

    @Autowired
    CoreMain coreMain;

    /**
     * Return Routings by contract id
     *
     * @param contractIdStr
     * @return
     */
    @RequestMapping(value = URL_ROUTES_BY_CONTRACT)
    public ResponseEntity<RoutesDTO> getRoutesByContractId(@RequestParam(value = "contract-id") String contractIdStr) {
        try {
            // Get params
            Long contractId = Converters.strToLong(contractIdStr, 0L);
            CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

            if (tripRoutingControl != null) {
                CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
                // Get list of routes by contract id

                RoutesDTO rDto = new RoutesDTO();
                rDto.setRoutes(coreRoute.getListByContract(contractId, null, -1));

                return new ResponseEntity(rDto, HttpStatus.OK);
            }
        } catch (Exception e) {
            logger.error("Error in getRoutesByContractId", e);
        }

        return new ResponseEntity(new RoutesDTO(), HttpStatus.OK);
    }

    /**
     * Return the value indicating access to the module "Trip Routing"
     *
     * @return
     */
    @RequestMapping(value = URL_HAS_ROUTING_ACCESS)
    public ResponseEntity<?> getHasAccess() {
        boolean hasRoutingAccess = false;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
        if (tripRoutingControl != null) {
            hasRoutingAccess = tripRoutingControl.isHasAccess();
        }

        return new ResponseEntity<>(hasRoutingAccess, HttpStatus.OK);
    }

}

