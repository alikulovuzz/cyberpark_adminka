package uzgps.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreDatchikDigital;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.core.helper.CorePoi;
import uz.netex.database.helpers.DBDatchikDigital;
import uz.netex.datatype.*;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Group;
import uz.netex.dbtables.GroupList;
import uz.netex.dbtables.Poi;
import uz.netex.fuelcontrol.core.CoreFuelControl;
import uzgps.admin.AdminService;
import uzgps.common.UZGPS_CONST;
import uzgps.map.MonitoringController;
import uzgps.map.models.TrackPopupData;
import uzgps.persistence.Contract;
import uzgps.persistence.*;
import uzgps.rest.bot.service.TgLocationService;
import uzgps.rest.dto.*;
import uzgps.rest.security.JWTProvider;
import uzgps.settings.SettingsService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * Created by Gayratjon on 10/13/2016.
 */
@RestController
@RequestMapping("")
public class MObjectController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    CoreMain coreMain;

    @Autowired
    SettingsService settingsService;

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    AdminService adminService;

    @Autowired
    TgLocationService tgLocationService;

    @RequestMapping(value = "/mobjects.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectList(@RequestParam(value = "user-role-id") Long userRoleId,
                                            @RequestParam(value = "user-id") Long userId,
                                            @RequestParam(value = "contract-id") Long contractId) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        List<MobjectBig> mObjectList = Collections.emptyList();
        if (UZGPS_CONST.USER_ROLE_USER == userRoleId) {
            mObjectList = coreMain.getMobjectListByUser(userId);
        } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == userRoleId) {
            mObjectList = coreMain.getMobjectListByContract(contractId);
        }

        return new ResponseEntity(mObjectList, HttpStatus.OK);
    }

    @RequestMapping(value = "/mobjects-monitor-data.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectsMonitorData(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                                    @RequestParam(value = "user-id", required = true) Long userId,
                                                    @RequestParam(value = "contract-id", required = true) Long contractId) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        List<MobjectTracks> mObjectTracksList = null;
        if (UZGPS_CONST.USER_ROLE_USER == userRoleId) {
            mObjectTracksList = coreMain.getMobjectTracksListByUser(userId, 0L);
        } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == userRoleId) {
            mObjectTracksList = coreMain.getMobjectTracksListByContract(contractId, 0L);
        }

        ContractSettings contractSettings = getContractSettingsByContractId(contractId);
        List<MonitorDataDTO> monitorDataDTOList = processMonitorData(mObjectTracksList, contractSettings);

        return new ResponseEntity(monitorDataDTOList, HttpStatus.OK);
    }

    public ContractSettings getContractSettingsByContractId(Long contractId) {
        ContractSettings contractSettings = settingsService.getContractSettingsByContractId(contractId);
        if (contractSettings == null) {
            contractSettings = contractSettings.createDefault();
        }
        return contractSettings;
    }

    private List<MonitorDataDTO> processMonitorData(List<MobjectTracks> mObjectTracksList, ContractSettings contractSettings) {
        if (mObjectTracksList == null) {
            return Collections.emptyList();
        }

        List<MonitorDataDTO> monitorDataDTOList = new ArrayList<>();
        for (MobjectTracks mobjectTracks : mObjectTracksList) {
            List<GPSTrackPoint> trackPointList = mobjectTracks.getTracks();
            if (trackPointList != null && !mobjectTracks.getTracks().isEmpty()) {
                MobjectBig mobjectBig = mobjectTracks.getMobject();
                GPSTrackPoint fistTrackPoint = trackPointList.get(0);
                MonitorDataDTO monitorDataDTO = MonitorDataDTO.makeOne(mobjectBig, fistTrackPoint);

                if (monitorDataDTO.getBak2() != null && monitorDataDTO.getBak2() > 0 &&
                        monitorDataDTO.getBak1() != null && monitorDataDTO.getBak1() > 0) {
                    monitorDataDTO.setBak1(monitorDataDTO.getBak1() + monitorDataDTO.getBak2());
                }

                Long trackLimit = contractSettings.getTrackLengthValue();
                Long trackSelectionType = contractSettings.getTrackLengthType();
                GPSTrackPointList gpsTrackPointList = getGPSTrackPointList(mobjectBig.getId(), trackLimit, trackSelectionType);
                List<TrackLocationDTO> trackLocationDTOList = processLastTrackLocation(gpsTrackPointList);
                monitorDataDTO.setTracks(trackLocationDTOList);
                monitorDataDTOList.add(monitorDataDTO);
            }
        }

        return monitorDataDTOList;
    }

    private GPSTrackPointList getGPSTrackPointList(Long mobjectId, Long trackLimit, Long trackSelectionType) {
        GPSTrackPointList gpsTrackPointList;
        if (trackSelectionType == 1) {
            gpsTrackPointList = coreMain.getPointsByDate(mobjectId, 0L, 0L, trackLimit.intValue());
        } else {
            gpsTrackPointList = coreMain.getPointsByLastSeconds(mobjectId, trackLimit);
        }
        coreMain.deleteZeroPoints(gpsTrackPointList);

        return gpsTrackPointList;
    }

    private List<TrackLocationDTO> processLastTrackLocation(GPSTrackPointList gpsTrackPointList) {
        if (gpsTrackPointList.size() == 0) {
            return Collections.emptyList();
        }
        List<TrackLocationDTO> trackLocationDTOList = new ArrayList<>();
        for (GPSTrackPoint trackPoint : gpsTrackPointList.getGpsTrackPoints()) {
            TrackLocationDTO trackLocationDTO = TrackLocationDTO.makeOne(trackPoint);
            trackLocationDTOList.add(trackLocationDTO);
        }
        return trackLocationDTOList;
    }

    @RequestMapping(value = "/mobjects-dashboard-data.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectsDashboardData(@RequestParam(value = "user-role-id") Long userRoleId,
                                                      @RequestParam(value = "user-id") Long userId,
                                                      @RequestParam(value = "contract-id") Long contractId) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        List<MobjectTracks> mObjectTracksList = null;
        if (UZGPS_CONST.USER_ROLE_USER == userRoleId) {
            mObjectTracksList = coreMain.getMobjectTracksListByUser(userId, 0L);
        } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == userRoleId) {
            mObjectTracksList = coreMain.getMobjectTracksListByContract(contractId, 0L);
        }

        ContractSettings contractSettings = getContractSettingsByContractId(contractId);
        List<TrackPopupData> dashboardDataDTOList = processDashboardData(mObjectTracksList);
        Set<String> ignoredFieldSet = TrackPopupData.monitoringPopupIgnoredFieldNames(contractSettings);
        String jsonResponse = convertObjectToJSONStringWithIgnoredFields(dashboardDataDTOList, ignoredFieldSet);

        return new ResponseEntity(jsonResponse, HttpStatus.OK);
    }


    private List<TrackPopupData> processDashboardData(List<MobjectTracks> mObjectTracksList) {
        if (mObjectTracksList == null) {
            return Collections.emptyList();
        }

        List<TrackPopupData> dashboardDataDTOList = new ArrayList<>();

        // Collect mobject in Poi
        CorePoi corePoi = CorePoi.getInstance();
        // Collect mobject in Geofence
        CoreGeofence coreGeofence = CoreGeofence.getInstance();
        ;

        if (corePoi != null) {
            corePoi.loadMobjectsInPoi();
        }

        if (coreGeofence != null) {
            coreGeofence.loadMobjectsInGeofence();
        }

        for (MobjectTracks mobjectTracks : mObjectTracksList) {
            TrackPopupData trackPopupData = makeTrackPopupDate(mobjectTracks);
            if (trackPopupData != null) {
                dashboardDataDTOList.add(trackPopupData);
            }
        }

        return dashboardDataDTOList;
    }

    @RequestMapping(value = "/one-mobject-dashboard-data.json", method = RequestMethod.GET)
    public ResponseEntity<?> getOneMObjectDashboardData(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                                        @RequestParam(value = "user-id", required = true) Long userId,
                                                        @RequestParam(value = "contract-id", required = true) Long contractId,
                                                        @RequestParam(value = "object-id", required = true) Long objectId) {
        if (userRoleId == null
                || userId == null
                || contractId == null
                || objectId == null) {
            return new ResponseEntity(Collections.emptyMap(), HttpStatus.OK);
        }

        List<MobjectTracks> mObjectTracksList = null;
        if (UZGPS_CONST.USER_ROLE_USER == userRoleId) {
            mObjectTracksList = coreMain.getMobjectTracksListByUser(userId, 0L);
        } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == userRoleId) {
            mObjectTracksList = coreMain.getMobjectTracksListByContract(contractId, 0L);
        }

        MobjectTracks oneMobjectTracks = getMobjectTracksByObjectId(mObjectTracksList, objectId);
        ContractSettings contractSettings = getContractSettingsByContractId(contractId);
        TrackPopupData dashboardDataDTO = makeTrackPopupDate(oneMobjectTracks);
        Set<String> ignoredFieldSet = TrackPopupData.monitoringPopupIgnoredFieldNames(contractSettings);
        String jsonResponse = convertObjectToJSONStringWithIgnoredFields(dashboardDataDTO, ignoredFieldSet);

        return new ResponseEntity(jsonResponse, HttpStatus.OK);
    }

    private MobjectTracks getMobjectTracksByObjectId(List<MobjectTracks> mObjectTracksList, Long objectId) {
        if (mObjectTracksList != null && !mObjectTracksList.isEmpty()) {
            for (MobjectTracks mobjectTracks : mObjectTracksList) {
                if (mobjectTracks.getMobject().getId().equals(objectId)) {
                    return mobjectTracks;
                }
            }
        }
        return null;
    }

    private TrackPopupData makeTrackPopupDate(MobjectTracks mobjectTracks) {
        if (mobjectTracks != null) {
            List<GPSTrackPoint> trackPointList = mobjectTracks.getTracks();
            if (trackPointList != null && !mobjectTracks.getTracks().isEmpty()) {
                MobjectBig mobjectBig = mobjectTracks.getMobject();
                GPSTrackPoint fistTrackPoint = trackPointList.get(0);

                TrackPopupData trackPopupData = new TrackPopupData();
                trackPopupData.setGPSTrackPoint(fistTrackPoint);
                trackPopupData.setMobjectBig(mobjectBig);

                // Collect mobject in Poi
                CorePoi corePoi = CorePoi.getInstance();
                // Collect mobject in Geofence
                CoreGeofence coreGeofence = CoreGeofence.getInstance();
                ;

                List<Poi> poiList = null;
                List<Geofence> geofenceList = null;

                if (corePoi != null) {
                    poiList = corePoi.getPoiWithMobjectInside(mobjectBig.getId());
                }

                if (coreGeofence != null) {
                    geofenceList = coreGeofence.getGeofencesWithMobjectInside(mobjectBig.getId());
                }

                trackPopupData.setPoiAndGeoFenceList(poiList, geofenceList);
                trackPopupData.setAssignedRoutes(monitoringController.getAssignedTripNamesToMobject(mobjectBig.getId()));

                return trackPopupData;
            }
        }
        return null;
    }

    private String convertObjectToJSONStringWithIgnoredFields(Object obj, Set<String> ignoredFieldSet) {
        SimpleFilterProvider filterProvider = new SimpleFilterProvider();
        filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignoredFieldSet));
        ObjectMapper jsonMapper = new ObjectMapper();
        String jsonResponse = null;

        try {
            jsonResponse = jsonMapper.writer(filterProvider).writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error("Error in convertObjectToJSONStringWithIgnoredFields", e);
        }

        return jsonResponse;
    }

    @RequestMapping(value = "/mobjects-tg-data.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectsTGdata(@RequestHeader(HttpHeaders.AUTHORIZATION) String token) {

        if (token == null)
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);

        token = token.substring(7);

        User user = adminService.getUserByApiToken(token);
        if (user == null)
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);

        List<Contract> userContracts = adminService.getUserContractsByUserId(user.getId());
        if (userContracts == null || user.getRoleId() == null)
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);


        Long contractId = userContracts.get(0).getId();
        List<MobjectBig> mobjectList = null;

        if (UZGPS_CONST.USER_ROLE_USER == user.getRoleId()) {
            mobjectList = coreMain.getMobjectListByUser(user.getId());
        } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == user.getRoleId()) {
            mobjectList = coreMain.getMobjectListByContract(contractId);
        }

        List<TgMobjectDTO> mobjectDTOList = processTgData(mobjectList);

        return new ResponseEntity(mobjectDTOList, HttpStatus.OK);
    }

    @RequestMapping(value = "/one-mobject-tg-data.json", method = RequestMethod.GET)
    public ResponseEntity<?> getOneMObjectTGData(@RequestHeader(HttpHeaders.AUTHORIZATION) String token,
                                                 @RequestParam(value = "object-id") Long objectId) {
        if (token == null)
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);

        token = token.substring(7);

        User user = adminService.getUserByApiToken(token);

        if (user == null)
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);

        List<Contract> userContracts = adminService.getUserContractsByUserId(user.getId());
        if (userContracts == null || user.getRoleId() == null || objectId == null)
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);

        List<MobjectTracks> mObjectTracksList = null;
        Long contractId = userContracts.get(0).getId();

        if (UZGPS_CONST.USER_ROLE_USER == user.getRoleId()) {
            mObjectTracksList = coreMain.getMobjectTracksListByUser(user.getId(), 0L);
        } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == user.getRoleId()) {
            mObjectTracksList = coreMain.getMobjectTracksListByContract(contractId, 0L);
        }

        MobjectTracks oneMobjectTracks = getMobjectTracksByObjectId(mObjectTracksList, objectId);
        TrackTgDataDTO trackTgDataDTO = makeTrackTgData(oneMobjectTracks);

        return new ResponseEntity(trackTgDataDTO, HttpStatus.OK);
    }

    @RequestMapping(value = "/mobjects-tg-location-list", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectsTGLocationList(@RequestHeader(HttpHeaders.AUTHORIZATION) String token) {

        if (token == null || token.length() < 8)
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);

        token = token.substring(7);

        if (!JWTProvider.isTokenValid(token))
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);

        List<TgLocation> tgLocationList = tgLocationService.getTgLocationList();
        List<TgLocationPointDTO> tgLocationPointDTOList = new ArrayList<>();

        if (tgLocationList != null) {
            for (TgLocation tgLocation : tgLocationList) {
                if (tgLocation.getTimeExpireDate().getTime() <= System.currentTimeMillis()) {
                    tgLocationService.disableTgLocation(tgLocation.getId());
                    continue;
                }

                MobjectTracks mobjectTracks = coreMain.getMobjectTracksByMobject(tgLocation.getMobjectId(), 0L);
                TgLocationPointDTO tgLocationPointDTO = makeTgLocationPointList(mobjectTracks, tgLocation);

                if (tgLocationPointDTO != null)
                    tgLocationPointDTOList.add(tgLocationPointDTO);

            }
        }

        return new ResponseEntity(tgLocationPointDTOList, HttpStatus.OK);
    }

    private TgLocationPointDTO makeTgLocationPointList(MobjectTracks mobjectTracks, TgLocation tgLocation) {
        if (mobjectTracks != null && mobjectTracks.getTracks() != null && !mobjectTracks.getTracks().isEmpty()) {
            GPSTrackPoint gpsTrackPoint = mobjectTracks.getTracks().get(0);

            TgLocationPointDTO locationDTO = new TgLocationPointDTO();
            locationDTO.setChatId(tgLocation.getChatId());
            locationDTO.setMessageId(tgLocation.getMessageId());
            locationDTO.setMobjectId(tgLocation.getMobjectId());
            locationDTO.setLatitude(gpsTrackPoint.getLatitude());
            locationDTO.setLongitude(gpsTrackPoint.getLongitude());
            locationDTO.setMobjectName(mobjectTracks.getMobject().getName());

            return locationDTO;
        }
        return null;
    }

    private List<TgMobjectDTO> processTgData(List<MobjectBig> mobjectList) {
        if (mobjectList == null)
            return Collections.emptyList();

        List<TgMobjectDTO> mobjectDTOList = new ArrayList<>();

        for (MobjectBig mobjectBig : mobjectList) {
            MobjectTracks tracksByMobject = coreMain.getMobjectTracksByMobject(mobjectBig.getId(), 0L);

            //Check has tracks in mobject
            boolean hasTracks = tracksByMobject != null && !tracksByMobject.getTracks().isEmpty();

            TgMobjectDTO tgMobjectDTO = new TgMobjectDTO(mobjectBig.getId(), mobjectBig.getName(), hasTracks);
            mobjectDTOList.add(tgMobjectDTO);
        }

        return mobjectDTOList;
    }

    private TrackTgDataDTO makeTrackTgData(MobjectTracks mobjectTracks) {
        if (mobjectTracks != null) {
            List<GPSTrackPoint> trackPointList = mobjectTracks.getTracks();
            MobjectBig mobject = mobjectTracks.getMobject();
            TrackTgDataDTO trackTgDataDTO = new TrackTgDataDTO();
            trackTgDataDTO.setMobjectBig(mobject);

            if (trackPointList != null && !mobjectTracks.getTracks().isEmpty()) {
                GPSTrackPoint gpsTrackPoint = trackPointList.get(0);
                trackTgDataDTO.setGPSTrackPoint(gpsTrackPoint);
                trackTgDataDTO.setHasTracks(true);
            }

            return trackTgDataDTO;
        }
        return null;
    }

    @RequestMapping(value = "/update-mobject.json", method = RequestMethod.GET)
    public ResponseEntity<?> updateMobject(@RequestParam(value = "mobject-id", required = true) Long mobjectId) {

        if (mobjectId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }
        coreMain.coreUpdater.updateMobjectBigById(mobjectId);
        // Connect to Core Fuel Controller
        CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();
        if (coreFuelControl != null && coreFuelControl.isHasAccess()) {
            coreFuelControl.updateByMobject(mobjectId);
        }

        // update DigitalDatchik
        // Connect to CoreDatchikDigital
        CoreDatchikDigital coreDatchikDigital = CoreDatchikDigital.getInstance();
        DBDatchikDigital dbDatchikDigital = DBDatchikDigital.getInstance();
        // get datchikDigital by mobject id
        DatchikDigital datchikDigital = dbDatchikDigital.getDatchikDigitalByMobjectId(mobjectId);
        int saveError = coreDatchikDigital.save(datchikDigital);

        return new ResponseEntity(mobjectId, HttpStatus.OK);
    }

    @RequestMapping(value = "/update-gps-unit.json", method = RequestMethod.GET)
    public ResponseEntity<?> updateGpsUnit(@RequestParam(value = "gps-unit-id", required = true) Long gpsUnitId) {
        if (gpsUnitId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        coreMain.coreUpdater.updateGpsUnit(gpsUnitId);
        return new ResponseEntity(gpsUnitId, HttpStatus.OK);
    }

    @RequestMapping(value = "/update-mobject-by-gps-unit.json", method = RequestMethod.GET)
    public ResponseEntity<?> updateMobjectByGpsUnit(@RequestParam(value = "gps-unit-id", required = true) Long gpsUnitId) {

        if (gpsUnitId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }
        coreMain.coreUpdater.updateMobjectBigByUnitId(gpsUnitId);
        return new ResponseEntity(gpsUnitId, HttpStatus.OK);
    }

    @RequestMapping(value = "/update-user-mobject-access-by-mobject-id.json", method = RequestMethod.GET)
    public ResponseEntity<?> updateUserMobjectAccess(@RequestParam(value = "mobject-id", required = true) Long mobjectId) {
        try {
            if (mobjectId == null) {
                return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
            }

            List<UserMObjectAccessList> userMobjectAccessList = settingsService.getUserMObjectAccessByMobjectId(mobjectId);

            for (UserMObjectAccessList userMObjectAccess : userMobjectAccessList) {
                // Core Update for User Mobject Access By User Id
                coreMain.coreUpdater.updateUserMobjectAccessByUserId(userMObjectAccess.getUserId());
//                    coreMain.coreUpdater.deleteUserMobjectAccessByMobjectId(mobjectId);
            }

            return new ResponseEntity(mobjectId, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error in updateUserMobjectAccess", e);
        }

        return new ResponseEntity(0, HttpStatus.OK);
    }


    @RequestMapping(value = "/update-mobject-notification.json", method = RequestMethod.GET)
    public ResponseEntity<?> updateMobjectNotification(@RequestParam(value = "mobject-notification-id", required = true) Long mobjectNotificationId) {
        if (mobjectNotificationId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }
        coreMain.coreUpdater.updateMobjectNotificationsById(mobjectNotificationId);
        return new ResponseEntity(mobjectNotificationId, HttpStatus.OK);
    }

    /* --------- Mobject groups --------- */
    @RequestMapping(value = "/mobject-group-list.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectGroupList(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                                 @RequestParam(value = "user-id", required = true) Long userId,
                                                 @RequestParam(value = "contract-id", required = true) Long contractId) {
        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        GroupList groupList = coreMain.getGroupListByContract(contractId);
        List<Group> resultList = (groupList != null) ? groupList.getGroupList() : null;

        return new ResponseEntity(resultList, HttpStatus.OK);
    }


}
