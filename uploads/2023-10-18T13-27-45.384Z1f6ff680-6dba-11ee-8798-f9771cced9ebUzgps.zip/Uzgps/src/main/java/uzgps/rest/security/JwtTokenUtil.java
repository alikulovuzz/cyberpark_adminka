package uzgps.rest.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import uzgps.persistence.User;
import uzgps.persistence.UserAccessList;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

@Component
public class JwtTokenUtil implements Serializable {

    private static final long serialVersionUID = -2550185165626007488L;
    //    public static final long JWT_TOKEN_VALIDITY = 5 * 60 * 60;
    public static final long JWT_TOKEN_VALIDITY = 5 * 60 * 60; //

    private static final String SECRET_ENCODED_BASE_64 = "";

    //generate token for user
    public String generateToken(User user, UserAccessList ual, List<Long> contractIdList) {
//        Map<String, Object> claims = new HashMap<>();

        Claims claims = Jwts.claims()
                .setSubject(user.getLogin());
        claims.put("userId", user.getId());
        claims.put("role", user.getRole());
        claims.put("audience", "smpov2");
        claims.put("issuer ", "smpo");
        claims.put("userAccessList", ual);
        claims.put("contractId", user.getContractId());

        if (contractIdList != null) {
            claims.put("contractIdList", contractIdList.toString());

            String contractIdListRB = contractIdList.toString();
            contractIdListRB = contractIdListRB.replaceFirst("\\[", "(");
            contractIdListRB = contractIdListRB.replaceFirst("\\]", ")");
            claims.put("contractIdListRB", contractIdListRB);

            String contractIdListCB = contractIdList.toString();
            contractIdListCB = contractIdListCB.replaceFirst("\\[", "{");
            contractIdListCB = contractIdListCB.replaceFirst("\\]", "}");
            claims.put("contractIdListCB", contractIdListCB);

            claims.put("showObjectsOfAllContracts", true);
        } else {
            claims.put("contractIdList", String.format("[%d]", user.getContractId()));
            claims.put("contractIdListRB", String.format("(%d)", user.getContractId()));
            claims.put("contractIdListCB", String.format("{%d}", user.getContractId()));
            claims.put("showObjectsOfAllContracts", false);
        }

        return doGenerateToken(claims, user.getLogin());
    }

    //while creating the token -
    //1. Define  claims of the token, like Issuer, Expiration, Subject, and the ID
    //2. Sign the JWT using the HS512 algorithm and secret key.
    //3. According to JWS Compact Serialization(https://tools.ietf.org/html/draft-ietf-jose-json-web-signature-41#section-3.1)
    //   compaction of the JWT to a URL-safe string
    private String doGenerateToken(Claims claims, String subject) {

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
                .setIssuer("smpo")
                .setAudience("smpov2")
                .signWith(SignatureAlgorithm.HS512, SECRET_ENCODED_BASE_64)
                .compact();
    }

    /**
     * Return is token valid
     *
     * @param authorization
     * @return
     */
    public Boolean isValid(String authorization) {
        try {
            String token = authorization.substring("Bearer ".length());

            Claims claims = Jwts.parser()
                    .setSigningKey(SECRET_ENCODED_BASE_64)
                    .parseClaimsJws(token)
                    .getBody();

            String signature = Jwts.parser()
                    .setSigningKey(SECRET_ENCODED_BASE_64)
                    .parseClaimsJws(token)
                    .getSignature();

            String subject = Jwts.parser()
                    .setSigningKey(SECRET_ENCODED_BASE_64)
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();

            String aud = Jwts.parser()
                    .setSigningKey(SECRET_ENCODED_BASE_64)
                    .parseClaimsJws(token)
                    .getBody()
                    .getAudience();

            String issuer = Jwts.parser()
                    .setSigningKey(SECRET_ENCODED_BASE_64)
                    .parseClaimsJws(token)
                    .getBody()
                    .getIssuer();

//            System.out.println(claims);
//            System.out.println(signature);
//            System.out.println(subject);
//            System.out.println(aud);
//            System.out.println(issuer);

//            System.out.println(claims.get("sub", String.class));

            return true;
        } catch (Exception e) {
            return false;
        }
    }


    //validate token
    public Boolean validateToken(String token, UserDetails userDetails) {
        final String username = getUsernameFromToken(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }


    //retrieve username from jwt token
    public String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    //retrieve expiration date from jwt token
    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    //for retrieving any information from token we will need the secret key
    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser().setSigningKey(SECRET_ENCODED_BASE_64).parseClaimsJws(token).getBody();
    }

    //check if the token has expired
    private Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }
}
