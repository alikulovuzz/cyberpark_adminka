package uzgps.rest.bot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uzgps.persistence.TgLocation;
import uzgps.rest.bot.service.TgLocationService;
import uzgps.rest.dto.TgLocationDTO;

import javax.validation.Valid;

@RestController
@RequestMapping("/tg-location")
public class TgLocationController {

    @Autowired
    TgLocationService tgLocationService;


    @RequestMapping(
            value = "",
            method = RequestMethod.POST,
            produces = "application/json"
    )
    public HttpEntity<?> addTGLocation(@Valid @RequestBody TgLocationDTO tgLocationDTO){
        TgLocation tgLocation = tgLocationService.addTgLocation(tgLocationDTO);
        return ResponseEntity
                .status(tgLocation.getId() != null ? HttpStatus.CREATED : HttpStatus.CONFLICT)
                .body(tgLocation);
    }

    @RequestMapping(
            value = "/disable/{id}",
            method = RequestMethod.POST,
            produces = "application/json"
    )
    public HttpEntity<?> disableTGLocation(@PathVariable Long id){
        boolean isSuccess = tgLocationService.disableTgLocationByMessageId(id);
        return ResponseEntity.status(isSuccess ? HttpStatus.OK : HttpStatus.CONFLICT).body("OK");
    }



}
