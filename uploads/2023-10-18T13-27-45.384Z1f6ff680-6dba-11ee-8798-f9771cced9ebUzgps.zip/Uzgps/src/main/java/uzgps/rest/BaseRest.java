package uzgps.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import uz.netex.core.CoreMain;
import uzgps.admin.AdminService;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.persistence.User;
import uzgps.persistence.UserRole;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

public class BaseRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    protected AdminService adminService;

    @Autowired
    protected CoreMain coreMain;

    protected boolean isAuthenticate(User user, String token) {
        // if token exists - login with token
        return user.getAuthToken() != null && user.getAuthToken().equals(token);
    }

    protected boolean isAuthenticateByUser(User user) {
        return user != null && user.getId() > 0;
    }

    protected User getUserByToken(String token) {
        if (token != null && token.length() > 7) {
            if (token.contains("Bearer")) {
                token = token.replace("Bearer", "").trim();
            }

            User userDb = adminService.getUserByToken(token);
            if (userDb != null && isAuthenticate(userDb, token)) {
                return userDb;
            }
        } else {
            return null;
        }
        return null;
    }

    protected List<Long> getContractsIds(HttpSession session) {
        List<Long> contractIds = new ArrayList<>();

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            contractIds = MainController.getUserContractsIds(session);
        } else {
            Long contractId = MainController.getUserContractId(session);
            contractIds.add(contractId);
        }
        return contractIds;
    }

    protected List<Long> getContractsIds(User user, Long contractId) {
        List<Long> contractIds = new ArrayList<>();

        if (user == null) {
            return contractIds;
        }

        List<Contract> contracts = adminService.getUserContractsByUserId(user.getId());

        boolean isContactIdPresent = contracts.stream().map(Contract::getId).anyMatch(contractId::equals);

        if (isContactIdPresent) {
            contractIds.add(contractId);
        }

        return contractIds;
    }

    protected List<Contract> getContracts(HttpSession session) {
        List<Contract> contracts = new ArrayList<>();

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            contracts = MainController.getUserContracts(session);
        } else {
            Contract contract = MainController.getUserContract(session);
            contracts.add(contract);
        }
        return contracts;
    }

    protected Long getUserRoleByUserIdAndContractId(Long userId, Long contractId) {
        try {
            List<UserRole> userRoles = adminService.getUserRoleByUserIdAndContractId(userId, contractId);

            if (userRoles != null && !userRoles.isEmpty()) {
                return userRoles.get(0).getRoleId();
            } else {
                return null;
            }
        } catch (Exception e) {
            logger.error("Error in getUserRoleByUserIdAndContractId", e);
        }
        return null;
    }

    protected String formatToken(String authHeader) {
        if (authHeader.contains("Bearer ")) {
            return authHeader.replace("Bearer ", "").trim();
        }
        return authHeader;
    }

    // Get response entity if user is authenticated
    protected ResponseEntity<?> getResponseEntity(Object responseEntity) {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                try {
                    return ResponseUtil.respondSuccess(responseEntity);
                } catch (Exception e) {
                    return ResponseUtil.respondError(e);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

}
