package uzgps.rest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;

public class ResponseUtil {
    public static ResponseEntity<?> respondUnauthorized(String content) {
//        return ResponseEntity.ok().body();

//        return new ResponseEntity<>(new JsonObject()
//                .putNull("result")
//                .put("error", content), HttpStatus.OK);

        HashMap<String, Object> map = new HashMap<>();
        map.put("result", null);
        map.put("error", content);

        return new ResponseEntity<>(map, HttpStatus.UNAUTHORIZED);
    }

    public static ResponseEntity<?> respondSuccess(Object content) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("result", content);
        map.put("error", null);

        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    public static ResponseEntity<?> respondConflict(String content) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("result", null);
        map.put("error", content);

        return new ResponseEntity<>(map, HttpStatus.CONFLICT);
    }

    public static ResponseEntity<?> respondError(Throwable cause) {
        HashMap<String, Object> map = new HashMap<>();
        map.put("result", null);
        map.put("error", cause.toString());

        return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
