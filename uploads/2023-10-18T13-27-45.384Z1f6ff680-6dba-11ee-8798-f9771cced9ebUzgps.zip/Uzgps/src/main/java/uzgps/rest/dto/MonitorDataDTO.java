package uzgps.rest.dto;

import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;

import java.util.Collections;
import java.util.List;

/**
 * Created by Gayratjon on 10/17/2016.
 */
public class MonitorDataDTO {
    private long objectId = 0;
    private long timestamp = 0;
    private double latitude = 0;
    private double longitude = 0;
    private byte movement = -1;
    private byte engineOn = -1;
    private byte online = -1;
    private byte satellites = -1;
    private int speed = 0;
    private Double epv = null;
    private Integer bak1 = null;
    private Integer bak2 = null;
    private List<TrackLocationDTO> tracks = Collections.emptyList();

    private MonitorDataDTO() {
    }

    public static MonitorDataDTO makeOne(MobjectBig mobjectBig, GPSTrackPoint trackPoint) {
        if (mobjectBig == null || trackPoint == null) {
            return null;
        }

        MonitorDataDTO monitorDataDTO = new MonitorDataDTO();
        monitorDataDTO.objectId = mobjectBig.getId();
        monitorDataDTO.timestamp = trackPoint.getTimestamp();
        monitorDataDTO.latitude = trackPoint.getLatitude();
        monitorDataDTO.longitude = trackPoint.getLongitude();
        monitorDataDTO.movement = trackPoint.getMovement();
        monitorDataDTO.engineOn = trackPoint.getEngineOn();
        monitorDataDTO.online = trackPoint.getOnline();
        monitorDataDTO.satellites = trackPoint.getSatellites();
        monitorDataDTO.speed = trackPoint.getSpeed();
        if (trackPoint.getIoData() != null) {
            monitorDataDTO.epv = trackPoint.getIoData().getExternalPowerVoltageDouble();
            monitorDataDTO.bak1 = trackPoint.getIoData().getBak1();
            monitorDataDTO.bak2 = trackPoint.getIoData().getBak2();
        }
        return monitorDataDTO;
    }

    public long getObjectId() {
        return objectId;
    }

    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public byte getMovement() {
        return movement;
    }

    public void setMovement(byte movement) {
        this.movement = movement;
    }

    public byte getEngineOn() {
        return engineOn;
    }

    public void setEngineOn(byte engineOn) {
        this.engineOn = engineOn;
    }

    public byte getOnline() {
        return online;
    }

    public void setOnline(byte online) {
        this.online = online;
    }

    public byte getSatellites() {
        return satellites;
    }

    public void setSatellites(byte satellites) {
        this.satellites = satellites;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public List<TrackLocationDTO> getTracks() {
        return tracks;
    }

    public void setTracks(List<TrackLocationDTO> tracks) {
        this.tracks = tracks;
    }

    public Double getEpv() {
        return epv;
    }

    public void setEpv(Double epv) {
        this.epv = epv;
    }

    public Integer getBak1() {
        return bak1;
    }

    public void setBak1(Integer bak1) {
        this.bak1 = bak1;
    }

    public Integer getBak2() {
        return bak2;
    }

    public void setBak2(Integer bak2) {
        this.bak2 = bak2;
    }
}
