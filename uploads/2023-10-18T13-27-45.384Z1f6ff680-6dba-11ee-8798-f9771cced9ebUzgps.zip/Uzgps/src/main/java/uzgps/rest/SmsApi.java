package uzgps.rest;

import io.vertx.core.json.JsonObject;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreTerminal;
import uz.netex.dbtables.SmsOut;
import uzgps.persistence.User;

import javax.servlet.http.HttpServletRequest;

@RestController
public class SmsApi extends BaseRest {
    private final Logger logger = Logger.getLogger(this.getClass());
    public static final String BULK_SMS = "/bulk-sms.htm";

    @Autowired
    private CoreMain coreMain;

    @Autowired
    private CoreTerminal coreTerminal;

    @RequestMapping(BULK_SMS)
    public String send(HttpServletRequest httpServletRequest,
                       @RequestParam(name = "mobject-id[]") Long[] mObjectIds,
                       @RequestParam(value = "sms") String sms,
                       @RequestParam(value = "gprs", required = false) boolean viaGprs) {
        JsonObject responseJson = new JsonObject();
        try {
            String bearerToken = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION);
            User user = getUserByToken(bearerToken);
            if (user != null) {
                SmsOut smsOut = null;
                JsonObject smsIdMap = new JsonObject();
                if (mObjectIds != null) {
                    for (Long mObjectId : mObjectIds) {
                        smsOut = viaGprs
                                ? coreTerminal.send(mObjectId, sms)
                                : coreMain.sendSMS(mObjectId, sms);
                        if (smsOut != null) {
                            smsIdMap.put(mObjectId.toString(), smsOut.getId());
                        }
                    }
                }
                if (smsOut != null) {
                    responseJson.put("sms", smsOut.getMessage());
                }
                responseJson.put("smsIdByMObjectId", smsIdMap);
            } else {
                responseJson.put("error", "auth error");
            }
        } catch (Exception e) {
            logger.error("Failed SmsApi.send: " + e.getMessage());
        }
        return responseJson.toString();
    }
}
