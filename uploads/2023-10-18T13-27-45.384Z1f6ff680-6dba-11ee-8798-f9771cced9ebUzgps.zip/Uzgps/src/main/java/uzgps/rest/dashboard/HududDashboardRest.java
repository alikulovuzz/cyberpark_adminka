package uzgps.rest.dashboard;

import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.netex.datatype.MobjectTracks;
import uzgps.common.Converters;
import uzgps.dashboard.DTO.DonutData;
import uzgps.dashboard.DTO.MobjectTracksExtended;
import uzgps.dashboard.DTO.MobjectTypeDataExtendedImpl;
import uzgps.dashboard.DashboardService;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.MObjectSettings;
import uzgps.persistence.User;
import uzgps.rest.BaseDashboardRest;
import uzgps.rest.ResponseUtil;
import uzgps.rest.dashboard.MobjectStatusesByGasCarsCounter.GasTypeCounter;
import uzgps.settings.SettingsService;

import javax.servlet.http.HttpSession;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Created by Stanislav on 07.04.2022 15:40
 */
@SuppressWarnings({"SingleStatementInBlock", "DuplicatedCode"})
@RestController
@RequestMapping("/dashboard/")
public class HududDashboardRest extends BaseDashboardRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    DashboardService dashboardService;

    @Autowired
    SettingsService settingsService;

    @Autowired
    private HttpSession httpSession;

    private static final String MOBJECT_INDICATOR_STATES_GAS_TYPE_DATA_TOTAL_URL = "mobject-indicator-states-gas-type-data-total";
    private static final String MOBJECT_INDICATOR_STATES_GAS_TYPE_DATA_URL = "mobject-indicator-states-gas-type-data";

    private static final String MOBJECT_TYPE_GAS_CARS_TOTAL_DATA_URL = "mobject-type-gas-cars-total-data";
    private static final String MOBJECT_TYPE_GAS_CARS_BY_REGION_DATA_URL = "mobject-type-gas-cars-by-region-data";

    /**
     * Return mobject type data, only with mobject types Gas... (Hudud server only)
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonArray
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_TYPE_GAS_CARS_TOTAL_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectTypeGasCarsTotalData(HttpSession session,
                                                            @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                            @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                            @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                            @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            boolean isForChart = Converters.strToBoolean(isForChartStr, false);

            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isForChart) {
                    JsonObject mobjectTypeDataJson = getMobjectTypeGasCarsTotalDataForChart(regionId, contractIds, getMobjectTypesIdGasCars());
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    List<DonutData> mobjectTypeData = getMobjectTypeGasCarsTotalData(regionId, contractIds, getMobjectTypesIdGasCars());
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectTypeGasCarsData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return mobject indicator states data totals by all user contracts, only with mobject types Gas... (Hudud server only)
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_INDICATOR_STATES_GAS_TYPE_DATA_TOTAL_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectIndicatorStatesDataGasTypeTotal(HttpSession session,
                                                                       @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                                       @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                                       @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                                       @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isAuthenticateByUser) {
                    JsonArray mobjectTypeDataJson = getObjectStatesGasCarsDataTotal(session, regionId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    JsonArray mobjectTypeData = getObjectStatesGasCarsDataTotal(user, contractId, contractIds);
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectIndicatorStatesDataTotal", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return mobject indicator states data by contracts, only with mobject types Gas... (Hudud server only)
     *
     * @param session       HttpSession
     * @param token         Bearer token for external services
     * @param contractId    Contract
     * @param regionId      Filter - regionId
     * @param isForChartStr If true data is formatted for using in charts
     * @return JsonArray
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_INDICATOR_STATES_GAS_TYPE_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectIndicatorStatesDataGasType(HttpSession session,
                                                                  @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                                  @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                                  @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId,
                                                                  @RequestParam(value = "is-for-chart", required = false, defaultValue = "false") String isForChartStr) {
        try {
            List<Contract> contracts = new ArrayList<>();

            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contracts = getContracts(session);
            } else if (isAuthenticateByToken) {
                Contract contract = user.getContract();
                contracts.add(contract);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                if (isAuthenticateByUser) {
                    JsonArray mobjectTypeDataJson = getObjectStatesGasCarsData(session, user.getId(), regionId, contracts);
                    return ResponseUtil.respondSuccess(mobjectTypeDataJson);
                } else {
                    JsonArray mobjectTypeData = getObjectStatesGasCarsData(user.getId(), contractId, regionId, contracts);
                    return ResponseUtil.respondSuccess(mobjectTypeData);
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectIndicatorStatesDataTotal", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    /**
     * Return quantity of mobjects, only with mobject types Gas... (Hudud server only)
     *
     * @param session    HttpSession
     * @param token      Bearer token for external services
     * @param contractId Contract
     * @param regionId   Filter - regionId
     * @return List<MobjectTypeDataExtendedImpl>
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_TYPE_GAS_CARS_BY_REGION_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectTypeGasCarsByRegionData(HttpSession session,
                                                               @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                               @RequestParam(value = "contractId", required = false, defaultValue = "0") Long contractId,
                                                               @RequestParam(value = "region-id", required = false, defaultValue = "0") Integer regionId) {
        try {
            List<Long> contractIds = new ArrayList<>();
            boolean isAuthenticateByUser = false;
            boolean isAuthenticateByToken = false;

            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                isAuthenticateByUser = true;
            } else {
                user = getUserByToken(token);
                isAuthenticateByToken = (user != null && user.getId() > 0);
            }

            if (isAuthenticateByUser) {
                contractIds = getContractsIds(session);
            } else if (isAuthenticateByToken) {
                contractIds = getContractsIds(user, contractId);
            }

            if ((isAuthenticateByUser || isAuthenticateByToken) && !contractIds.isEmpty()) {
                List<MobjectTypeDataExtendedImpl> mobjectTypeData = getMobjectTypeGasCarsByContractsData(regionId, contractIds, getMobjectTypesIdGasCars());
                return ResponseUtil.respondSuccess(mobjectTypeData);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectTypeGasCarsData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    private JsonArray getObjectStatesGasCarsDataTotal(HttpSession session, Integer regionId, List<Long> contractIds) {
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();

        List<MObjectSettings> mobjectSettingsWithTypeGasCars = dashboardService.getMobjectSettingsWithGasTypesData(regionId, contractIds, getMobjectTypesIdGasCars());
        List<MobjectTracks> mObjectTracksList = getMobjectTracksList(session, regionId);

        return getObjectStatesGasCarsTotalEntries(isShowSuspendedObjects, mobjectSettingsWithTypeGasCars, mObjectTracksList);
    }

    private JsonArray getObjectStatesGasCarsDataTotal(User user, Long contractId, List<Long> contractIds) {
        ContractSettings contractSettings = settingsService.getContractSettingsByContractId(contractId);
        boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();

        List<MObjectSettings> mobjectIdsWithTypeGasCars = dashboardService.getMobjectSettingsWithGasTypesData(0, contractIds, getMobjectTypesIdGasCars());

        List<MobjectTracks> mObjectTracksList = getMobjectTracksList(user.getId(), contractId, false);

        return getObjectStatesGasCarsTotalEntries(isShowSuspendedObjects, mobjectIdsWithTypeGasCars, mObjectTracksList);
    }

    private JsonArray getObjectStatesGasCarsData(HttpSession session, Long userId, Integer regionId, List<Contract> contracts) {
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();
        return getObjectStatesGasCarsEntries(userId, regionId, contracts, isShowSuspendedObjects);
    }

    private JsonArray getObjectStatesGasCarsData(Long userId, Long contractId, Integer regionId, List<Contract> contracts) {
        ContractSettings contractSettings = settingsService.getContractSettingsByContractId(contractId);
        boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();
        return getObjectStatesGasCarsEntries(userId, regionId, contracts, isShowSuspendedObjects);
    }

    private JsonArray getObjectStatesGasCarsTotalEntries(boolean isShowSuspendedObjects,
                                                         List<MObjectSettings> mobjectSettingsWithTypeGasCars,
                                                         List<MobjectTracks> mObjectTracksList) {

        List<MobjectTracks> mObjectTracksListFiltered;

        Predicate<MobjectTracks> withGasType =
                c -> mobjectSettingsWithTypeGasCars.stream().anyMatch(mot -> mot.getmObjectId().equals(c.getMobject().getId()));

        mObjectTracksListFiltered = mObjectTracksList.stream()
                .filter(withGasType).collect(Collectors.toList());

        List<MobjectTracksExtended> mObjectTracksFilteredList = new ArrayList<>();

        for (MObjectSettings mos : mobjectSettingsWithTypeGasCars) {

            MobjectTracks mobjectTracks = mObjectTracksListFiltered.stream().filter(mtl ->
                            mtl.getMobject().getId().equals(mos.getmObjectId()))
                    .collect(Collectors.toList()).stream().findFirst().orElse(null);

            if (mobjectTracks != null) {
                MobjectTracksExtended mobjectTracksExtended = new MobjectTracksExtended();
                mobjectTracksExtended.setMobject(mobjectTracks.getMobject());
                mobjectTracksExtended.setTracks(mobjectTracks.getTracks());
                mobjectTracksExtended.setMobjectTypeId(mos.getMObjectTypeId());
                mobjectTracksExtended.setMobjectTypeName(mos.getmObjectType().getNameRu());

                mObjectTracksFilteredList.add(mobjectTracksExtended);
            }
        }

        MobjectStatusesByGasCarsCounter mobjectStatusesCounter =
                new MobjectStatusesByGasCarsCounter(mObjectTracksFilteredList, isShowSuspendedObjects);

        JsonObject objectsStateData = new JsonObject();
        JsonArray gasTypeCounterArr = new JsonArray();

        for (GasTypeCounter gasTypeCounter : mobjectStatusesCounter.gasTypeCounterList) {
            JsonObject objectStateData = new JsonObject();
            objectStateData.put("id", gasTypeCounter.getId());
            objectStateData.put("name", gasTypeCounter.getName());

            objectStateData.put("objectCount", gasTypeCounter.getObjectCount());
            objectStateData.put("activeObjectsCount", gasTypeCounter.getActiveObjectsCount());
            objectStateData.put("stoppedObjectsCount", gasTypeCounter.getStoppedObjectsCount());
            objectStateData.put("parkingObjectsCount", gasTypeCounter.getParkingObjectsCount());
//            objectStateData.put("connectionLostObjectsCount", gasTypeCounter.getConnectionLostObjectsCount() + gasTypeCounter.getNoDataObjectsCount());
            objectStateData.put("noDataObjectsCount", gasTypeCounter.getConnectionLostObjectsCount() + gasTypeCounter.getNoDataObjectsCount());

            gasTypeCounterArr.add(objectStateData);
        }
        objectsStateData.put("objectsStateData", gasTypeCounterArr);

        return gasTypeCounterArr;
    }

    private JsonArray getObjectStatesGasCarsEntries(long userId, Integer iRegionId,
                                                    List<Contract> contracts,
                                                    boolean isShowSuspendedObjects) {

        List<MobjectTracks> mObjectTracksListFiltered;
        List<Long> contractIdList = contracts.stream().map(Contract::getId).collect(Collectors.toList());
        List<MObjectSettings> mobjectSettingsWithTypeGasCars = dashboardService.getMobjectSettingsWithGasTypesData(iRegionId, contractIdList, getMobjectTypesIdGasCars());

        Predicate<MobjectTracks> withGasType =
                c -> mobjectSettingsWithTypeGasCars.stream().anyMatch(mot -> mot.getmObjectId().equals(c.getMobject().getId()));

        Set<Long> regionIdList = getRegionIdListByContracts(contracts);
        HashMap<Long, List<GasTypeCounter>> regionStateData = new HashMap<>();

        for (Long regionId : regionIdList) {
            regionStateData.put(regionId, new ArrayList<>());

            for (Contract contract : contracts) {
                if (regionId.equals(contract.getCustomerRegion())) {
                    List<MobjectTracks> mObjectTracksList = getMobjectTracksList(userId, contract.getId(), false);

                    mObjectTracksListFiltered = mObjectTracksList.stream()
                            .filter(withGasType).collect(Collectors.toList());

                    List<MobjectTracksExtended> mObjectTracksExtendedFilteredList = new ArrayList<>();

                    for (MObjectSettings mos : mobjectSettingsWithTypeGasCars) {
                        MobjectTracks mobjectTracks = mObjectTracksListFiltered.stream().filter(mtl ->
                                        mtl.getMobject().getId().equals(mos.getmObjectId()))
                                .collect(Collectors.toList()).stream().findFirst().orElse(null);

                        if (mobjectTracks != null) {
                            MobjectTracksExtended mobjectTracksExtended = new MobjectTracksExtended();
                            mobjectTracksExtended.setMobject(mobjectTracks.getMobject());
                            mobjectTracksExtended.setTracks(mobjectTracks.getTracks());
                            mobjectTracksExtended.setMobjectTypeId(mos.getMObjectTypeId());
                            mobjectTracksExtended.setMobjectTypeName(mos.getmObjectType().getNameRu());
                            mObjectTracksExtendedFilteredList.add(mobjectTracksExtended);
                        }
                    }

                    MobjectStatusesByGasCarsCounter mobjectStatusesCounter =
                            new MobjectStatusesByGasCarsCounter(mObjectTracksExtendedFilteredList, isShowSuspendedObjects);

                    List<GasTypeCounter> gtcList = regionStateData.get(regionId);
                    if (gtcList.size() != mobjectStatusesCounter.gasTypeCounterList.size()) {
                        for (GasTypeCounter gasTypeCounter : mobjectStatusesCounter.gasTypeCounterList) {
                            GasTypeCounter gtcCheck = gtcList.stream().filter(gtc ->
                                            gtc.getId().equals(gasTypeCounter.getId()))
                                    .collect(Collectors.toList()).stream().findFirst().orElse(null);

                            if (gtcCheck == null) {
                                GasTypeCounter gtcTemp = new GasTypeCounter();
                                gtcTemp.setId(gasTypeCounter.getId());
                                gtcTemp.setName(gasTypeCounter.getName());
                                gtcList.add(gtcTemp);
                            }

                        }
                    }

                    for (GasTypeCounter gasTypeCounter : mobjectStatusesCounter.gasTypeCounterList) {
                        for (GasTypeCounter gtc : gtcList) {
                            if (gasTypeCounter.getId().equals(gtc.getId())) {
                                gtc.setObjectCount(gtc.getObjectCount() + gasTypeCounter.getObjectCount());
                                gtc.setActiveObjectsCount(gtc.getActiveObjectsCount() + gasTypeCounter.getActiveObjectsCount());
                                gtc.setStoppedObjectsCount(gtc.getStoppedObjectsCount() + gasTypeCounter.getStoppedObjectsCount());
                                gtc.setParkingObjectsCount(gtc.getParkingObjectsCount() + gasTypeCounter.getParkingObjectsCount());
                                gtc.setNoDataObjectsCount(gtc.getConnectionLostObjectsCount() + gasTypeCounter.getConnectionLostObjectsCount() + gasTypeCounter.getNoDataObjectsCount());
                            }
                        }
                    }
                }
            }
        }

        JsonArray resultJsonArray = new JsonArray();

        for (Map.Entry<Long, List<GasTypeCounter>> entry : regionStateData.entrySet()) {
            Long regionId = entry.getKey();
            List<GasTypeCounter> gtcList = entry.getValue();

            JsonObject regionResultData = new JsonObject();
            regionResultData.put("id", regionId);

            JsonArray regionDataArr = new JsonArray();
            for (GasTypeCounter gtc : gtcList) {
                JsonObject regionDataObj = new JsonObject();
                regionDataObj.put("id", gtc.getId());
                regionDataObj.put("name", gtc.getName());
                regionDataObj.put("objectCount", gtc.getObjectCount());
                regionDataObj.put("activeObjectsCount", gtc.getActiveObjectsCount());
                regionDataObj.put("stoppedObjectsCount", gtc.getStoppedObjectsCount());
                regionDataObj.put("parkingObjectsCount", gtc.getParkingObjectsCount());
                regionDataObj.put("noDataObjectsCount", gtc.getConnectionLostObjectsCount() + gtc.getNoDataObjectsCount());
                regionDataArr.add(regionDataObj);
            }
            regionResultData.put("data", regionDataArr);
            resultJsonArray.add(regionResultData);
        }

        return resultJsonArray;
    }

    private JsonObject getMobjectTypeGasCarsTotalDataForChart(Integer regionId, List<Long> contractIds, List<Long> mobjectTypesId) {
        return DashboardDataConverter.splitObjectsForDonut(getMobjectTypeGasCarsTotalData(regionId, contractIds, mobjectTypesId));
    }

    private List<DonutData> getMobjectTypeGasCarsTotalData(Integer regionId, List<Long> contractIds, List<Long> mobjectTypesId) {
        return dashboardService.getMobjectTypeGasCarsTotalData(regionId, contractIds, mobjectTypesId);
    }

    private List<MobjectTypeDataExtendedImpl> getMobjectTypeGasCarsByContractsData(Integer regionId, List<Long> contractIds, List<Long> mobjectTypesId) {
        List<MobjectTypeDataExtendedImpl> mobjectTypeGasCarsByContractsData = dashboardService.getMobjectTypeGasCarsByContractsData(regionId, contractIds, mobjectTypesId);
        long id = 10000L;

        for (Long contractId : contractIds) {
            MobjectTypeDataExtendedImpl mobjectTypeDataCistern = mobjectTypeGasCarsByContractsData.stream().filter(
                            mtd ->
                                    mtd.getContractId().equals(contractId) &&
                                            mtd.getMobjectTypeId() == MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN)
                    .collect(Collectors.toList()).stream().findFirst().orElse(null);

            MobjectTypeDataExtendedImpl mobjectTypeDataBalloon = mobjectTypeGasCarsByContractsData.stream().filter(
                            mtd ->
                                    mtd.getContractId().equals(contractId) &&
                                            mtd.getMobjectTypeId() == MOBJECT_TYPE_GAS_CAR_TYPE_BALLOON)
                    .collect(Collectors.toList()).stream().findFirst().orElse(null);

            if (mobjectTypeDataCistern == null) {
                id = createEmptyMobjectGasCarType(id, contractId,
                        MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN, MOBJECT_TYPE_GAS_CAR_TYPE_CISTERN_NAME, mobjectTypeGasCarsByContractsData);
            }

            if (mobjectTypeDataBalloon == null) {
                id = createEmptyMobjectGasCarType(id, contractId,
                        MOBJECT_TYPE_GAS_CAR_TYPE_BALLOON, MOBJECT_TYPE_GAS_CAR_TYPE_BALLOON_NAME, mobjectTypeGasCarsByContractsData);
            }
        }

        mobjectTypeGasCarsByContractsData.sort(Comparator.comparing(MobjectTypeDataExtendedImpl::getContractId)
                .thenComparing(MobjectTypeDataExtendedImpl::getMobjectTypeId));

        return mobjectTypeGasCarsByContractsData;
    }

    private long createEmptyMobjectGasCarType(long id, Long contractId,
                                              long mobjectTypeGasCarType,
                                              String mobjectTypeGasCarTypeName,
                                              List<MobjectTypeDataExtendedImpl> mobjectTypeGasCarsByContractsData) {

        MobjectTypeDataExtendedImpl mobjectTypeDataExtendedImpl = new MobjectTypeDataExtendedImpl();
        mobjectTypeDataExtendedImpl.setId(id);
        mobjectTypeDataExtendedImpl.setContract_id(contractId);
        mobjectTypeDataExtendedImpl.setMobject_type_id(mobjectTypeGasCarType);
        mobjectTypeDataExtendedImpl.setName(mobjectTypeGasCarTypeName);
        mobjectTypeDataExtendedImpl.setCount(0);

        mobjectTypeGasCarsByContractsData.add(mobjectTypeDataExtendedImpl);
        id += 1;
        return id;
    }

    private Set<Long> getRegionIdListByContracts(List<Contract> contracts) {
        Set<Long> regionIdList = new HashSet<>();

        for (Contract contract : contracts) {
            regionIdList.add(contract.getCustomerRegion());
        }

        return regionIdList;
    }

}
