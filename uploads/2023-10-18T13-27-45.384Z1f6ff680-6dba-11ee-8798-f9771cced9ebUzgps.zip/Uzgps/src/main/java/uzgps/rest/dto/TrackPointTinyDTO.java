package uzgps.rest.dto;

import uz.netex.datatype.GPSTrackPoint;

/**
 * Created by Gayratjon on 10/17/2016.
 */
public class TrackPointTinyDTO {

    private Long trackId;
    private Double latitude;
    private Double longitude;
    private Integer angle;
    private Integer speed;
    private Long timestamp;

    private TrackPointTinyDTO() {
    }

    public static TrackPointTinyDTO makeOne(GPSTrackPoint trackPoint) {
        TrackPointTinyDTO trackLocationDTO = new TrackPointTinyDTO();
        trackLocationDTO.trackId = trackPoint.getId();
        trackLocationDTO.latitude = trackPoint.getLatitude();
        trackLocationDTO.longitude = trackPoint.getLongitude();
        trackLocationDTO.angle = Integer.valueOf(trackPoint.getAngle());
        trackLocationDTO.speed = trackPoint.getSpeed();
        trackLocationDTO.timestamp = trackPoint.getTimestamp();
        return trackLocationDTO;
    }

    public Long getTrackId() {
        return trackId;
    }

    public void setTrackId(Long trackId) {
        this.trackId = trackId;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Integer getAngle() {
        return angle;
    }

    public void setAngle(Integer angle) {
        this.angle = angle;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
