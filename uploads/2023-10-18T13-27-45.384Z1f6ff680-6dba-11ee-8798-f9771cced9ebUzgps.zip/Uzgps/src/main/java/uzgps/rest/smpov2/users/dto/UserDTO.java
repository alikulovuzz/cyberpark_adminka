package uzgps.rest.smpov2.users.dto;

import uzgps.persistence.Contract;
import uzgps.persistence.FileStorage;
import uzgps.persistence.Role;
import uzgps.persistence.User;

import java.sql.Timestamp;
import java.util.List;
import java.util.stream.Collectors;

public class UserDTO extends UserBaseDTO {
    private Long managerId;
    private Long profileId;
    private Long userTypeId;
    private Long photoId;
    private FileStorage photo;
    private Contract contract;
    private Timestamp lastLoggedIn;
    private String recoveryKey;
    private Timestamp recoveryExp;
    private String block;
    private Integer loginAttemp;
    private Long roleId;
    private Role role;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private String authToken;
    private String sysAdminNote;
    private String apiToken;
    private Timestamp tokenExpDate;

    private List<UserDTO> users;


    public static UserDTO toModel(User user) {
        UserDTO model = new UserDTO();
        model.setId(user.getId());
        model.setManagerId(user.getManagerId());
        model.setProfileId(user.getProfileId());
        model.setUserTypeId(user.getUserTypeId());
        model.setLogin(user.getLogin());
        model.setSurName(user.getSurName());
        model.setName(user.getName());
        model.setMiddleName(user.getMiddleName());
        model.setPhotoId(user.getPhotoId());
        model.setPhoto(user.getPhoto());
        model.setContractId(user.getContractId());
        model.setContract(user.getContract());
        model.setLastLoggedIn(user.getLastLoggedIn());
        model.setRecoveryKey(user.getRecoveryKey());
        model.setRecoveryExp(user.getRecoveryExp());
        model.setBlock(user.getBlock());
        model.setLoginAttemp(user.getLoginAttemp());
        model.setRoleId(user.getRoleId());
        model.setRole(user.getRole());
        model.setStatus(user.getStatus());
        model.setRegDate(user.getRegDate());
        model.setModDate(user.getModDate());
        model.setExpDate(user.getExpDate());
        model.setSysAdminNote(user.getSysAdminNote());

        return model;
    }

    public static List<UserDTO> getUsers(List<User> users) {
        return users.stream().map(UserDTO::toModel).collect(Collectors.toList());
    }

    public UserDTO() {
    }

    public Long getManagerId() {
        return managerId;
    }

    public void setManagerId(Long managerId) {
        this.managerId = managerId;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public Long getUserTypeId() {
        return userTypeId;
    }

    public void setUserTypeId(Long userTypeId) {
        this.userTypeId = userTypeId;
    }

    public Long getPhotoId() {
        return photoId;
    }

    public void setPhotoId(Long photoId) {
        this.photoId = photoId;
    }

    public FileStorage getPhoto() {
        return photo;
    }

    public void setPhoto(FileStorage photo) {
        this.photo = photo;
    }

    public Contract getContract() {
        return contract;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public Timestamp getLastLoggedIn() {
        return lastLoggedIn;
    }

    public void setLastLoggedIn(Timestamp lastLoggedIn) {
        this.lastLoggedIn = lastLoggedIn;
    }

    public String getRecoveryKey() {
        return recoveryKey;
    }

    public void setRecoveryKey(String recoveryKey) {
        this.recoveryKey = recoveryKey;
    }

    public Timestamp getRecoveryExp() {
        return recoveryExp;
    }

    public void setRecoveryExp(Timestamp recoveryExp) {
        this.recoveryExp = recoveryExp;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public Integer getLoginAttemp() {
        return loginAttemp;
    }

    public void setLoginAttemp(Integer loginAttemp) {
        this.loginAttemp = loginAttemp;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public void setModDate(Timestamp modDate) {
        this.modDate = modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public void setExpDate(Timestamp expDate) {
        this.expDate = expDate;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public String getSysAdminNote() {
        return sysAdminNote;
    }

    public void setSysAdminNote(String sysAdminNote) {
        this.sysAdminNote = sysAdminNote;
    }

    public String getApiToken() {
        return apiToken;
    }

    public void setApiToken(String apiToken) {
        this.apiToken = apiToken;
    }

    public Timestamp getTokenExpDate() {
        return tokenExpDate;
    }

    public void setTokenExpDate(Timestamp tokenExpDate) {
        this.tokenExpDate = tokenExpDate;
    }

    public List<UserDTO> getUsers() {
        return users;
    }

    public void setUsers(List<UserDTO> users) {
        this.users = users;
    }
}
