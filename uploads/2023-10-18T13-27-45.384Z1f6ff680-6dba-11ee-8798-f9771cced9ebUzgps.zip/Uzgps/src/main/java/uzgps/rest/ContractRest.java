package uzgps.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import uzgps.admin.AdminService;
import uzgps.persistence.Contract;
import uzgps.persistence.User;
import uzgps.rest.dto.ContractRestDTO;
import uzgps.rest.dto.PayloadDTO;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stanislav on 01.04.2021 15:40
 */
@SuppressWarnings("SingleStatementInBlock")
@RestController
@RequestMapping("/contracts")
public class ContractRest extends BaseRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    AdminService adminService;

    @RequestMapping(value = "",
            produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> getContracts(HttpServletRequest request,
                                          @RequestBody PayloadDTO payload) {
        try {
            String token = payload.getToken();

            if (token != null && !token.isEmpty()) {
                User user = adminService.getUserByToken(token);

                if (user != null && isAuthenticate(user, token)) {
                    List<Contract> contracts = adminService.getUserContractsByUserId(user.getId());

                    List<ContractRestDTO> contractsDTOList = new ArrayList<>();

                    for (Contract contract : contracts) {
                        ContractRestDTO contractRestDTO = new ContractRestDTO(contract);
                        contractsDTOList.add(contractRestDTO);
                    }

//                    final String contractsDTOJsonStrTemp = new Gson().toJson(contractsDTOList);
//                    String contractsDTOJsonStr = contractsDTOJsonStrTemp.substring(1, contractsDTOJsonStrTemp.length() - 1);

                    return ResponseUtil.respondSuccess(contractsDTOList);
                } else {
                    return ResponseUtil.respondUnauthorized("Unauthorized request");
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in ContractRest - getContracts: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }


}
