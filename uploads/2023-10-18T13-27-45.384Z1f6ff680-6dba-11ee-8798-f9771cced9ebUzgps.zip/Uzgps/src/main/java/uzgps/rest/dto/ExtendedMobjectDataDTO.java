package uzgps.rest.dto;

import java.util.Arrays;

/**
 * Created by Stanislav on 06.05.2022.
 */
public class ExtendedMobjectDataDTO {
    private Long id;
    private Long mobjectId;
    private Long staffId;

    private Long staffPhotoId;
    private String staffPhotoFilename;
    private String staffPhotoContentType;
//    private byte[] staffPhotoDataBytea;
    private String staffPhotoDataBase64;
    private Long staffPhotoSize;

    private String staffFirstName;
    private String staffLastName;
    private String staffPatronymic;

    private String staffPosition;
    private String staffPhoneMobile;
    private String staffPhoneLine;

    private String staffCompanyName;
    private String staffSubdivisionName;
    private Boolean isNeedUpdatePhoto = false;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public Long getStaffPhotoId() {
        return staffPhotoId;
    }

    public void setStaffPhotoId(Long staffPhotoId) {
        this.staffPhotoId = staffPhotoId;
    }

    public String getStaffPhotoFilename() {
        return staffPhotoFilename;
    }

    public void setStaffPhotoFilename(String staffPhotoFilename) {
        this.staffPhotoFilename = staffPhotoFilename;
    }

    public String getStaffPhotoContentType() {
        return staffPhotoContentType;
    }

    public void setStaffPhotoContentType(String staffPhotoContentType) {
        this.staffPhotoContentType = staffPhotoContentType;
    }
//
//    public byte[] getStaffPhotoDataBytea() {
//        return staffPhotoDataBytea;
//    }
//
//    public void setStaffPhotoDataBytea(byte[] staffPhotoDataBytea) {
//        this.staffPhotoDataBytea = staffPhotoDataBytea;
//    }

    public String getStaffPhotoDataBase64() {
        return staffPhotoDataBase64;
    }

    public void setStaffPhotoDataBase64(String staffPhotoDataBase64) {
        this.staffPhotoDataBase64 = staffPhotoDataBase64;
    }

    public Long getStaffPhotoSize() {
        return staffPhotoSize;
    }

    public void setStaffPhotoSize(Long staffPhotoSize) {
        this.staffPhotoSize = staffPhotoSize;
    }

    public String getStaffFirstName() {
        return staffFirstName;
    }

    public void setStaffFirstName(String staffFirstName) {
        this.staffFirstName = staffFirstName;
    }

    public String getStaffLastName() {
        return staffLastName;
    }

    public void setStaffLastName(String staffLastName) {
        this.staffLastName = staffLastName;
    }

    public String getStaffPatronymic() {
        return staffPatronymic;
    }

    public void setStaffPatronymic(String staffPatronymic) {
        this.staffPatronymic = staffPatronymic;
    }

    public String getStaffPosition() {
        return staffPosition;
    }

    public void setStaffPosition(String staffPosition) {
        this.staffPosition = staffPosition;
    }

    public String getStaffPhoneMobile() {
        return staffPhoneMobile;
    }

    public void setStaffPhoneMobile(String staffPhoneMobile) {
        this.staffPhoneMobile = staffPhoneMobile;
    }

    public String getStaffPhoneLine() {
        return staffPhoneLine;
    }

    public void setStaffPhoneLine(String staffPhoneLine) {
        this.staffPhoneLine = staffPhoneLine;
    }

    public String getStaffCompanyName() {
        return staffCompanyName;
    }

    public void setStaffCompanyName(String staffCompanyName) {
        this.staffCompanyName = staffCompanyName;
    }

    public String getStaffSubdivisionName() {
        return staffSubdivisionName;
    }

    public void setStaffSubdivisionName(String staffSubdivisionName) {
        this.staffSubdivisionName = staffSubdivisionName;
    }

    public Boolean getNeedUpdatePhoto() {
        return isNeedUpdatePhoto;
    }

    public void setNeedUpdatePhoto(Boolean needUpdatePhoto) {
        isNeedUpdatePhoto = needUpdatePhoto;
    }

    @Override
    public String toString() {
        return "ExtendedMobjectDataDTO{" +
                "id=" + id +
                ", mobjectId=" + mobjectId +
                ", staffId=" + staffId +
                ", staffPhotoId=" + staffPhotoId +
                ", staffPhotoFilename='" + staffPhotoFilename + '\'' +
                ", staffPhotoContentType='" + staffPhotoContentType + '\'' +
                ", staffPhotoDataBase64='" + staffPhotoDataBase64 + '\'' +
                ", staffPhotoSize=" + staffPhotoSize +
                ", staffFirstName='" + staffFirstName + '\'' +
                ", staffLastName='" + staffLastName + '\'' +
                ", staffPatronymic='" + staffPatronymic + '\'' +
                ", staffPosition='" + staffPosition + '\'' +
                ", staffPhoneMobile='" + staffPhoneMobile + '\'' +
                ", staffPhoneLine='" + staffPhoneLine + '\'' +
                ", staffCompanyName='" + staffCompanyName + '\'' +
                ", staffSubdivisionName='" + staffSubdivisionName + '\'' +
                ", isNeedUpdatePhoto=" + isNeedUpdatePhoto +
                '}';
    }
}
