package uzgps.rest.dto;

import uzgps.dto.BasedDTO;
import uzgps.persistence.Contract;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by Stanislav on 01.04.2021 16:40
 */
public class ContractRestDTO implements Serializable, BasedDTO {

    private Long id;
    private Long companyId;
    private String contractNumber;
    private Timestamp contractRegDate;
    private String contractType;

    private String customerOKED;
    private String customerOKONH;
    private String customerINN;
    private String customerBankCode;
    private String customerAccount;
    private String taxpayerRegNumber;
    private String customerAccountTreasury;

    public ContractRestDTO(Contract contract) {
        this.id = contract.getId();
        this.companyId = contract.getCompanyId();
        this.contractNumber = contract.getContractNumber();
        this.contractRegDate = contract.getContractRegDate();
        this.contractType = contract.getContractType();

        this.customerOKED = contract.getCustomerOKED();
        this.customerOKONH = contract.getCustomerOKONH();
        this.customerINN = contract.getCustomerINN();
        this.customerBankCode = contract.getCustomerBankCode();
        this.customerAccount = contract.getCustomerAccount();
        this.taxpayerRegNumber = contract.getTaxpayerRegNumber();

        this.customerAccount = contract.getCustomerAccount();
        this.customerAccountTreasury = contract.getCustomerAccountTreasury();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Long companyId) {
        this.companyId = companyId;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public void setContractNumber(String contractNumber) {
        this.contractNumber = contractNumber;
    }

    public Timestamp getContractRegDate() {
        return contractRegDate;
    }

    public void setContractRegDate(Timestamp contractRegDate) {
        this.contractRegDate = contractRegDate;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getCustomerOKED() {
        return customerOKED;
    }

    public void setCustomerOKED(String customerOKED) {
        this.customerOKED = customerOKED.replaceAll("\\s+", "");
    }

    public String getCustomerOKONH() {
        return customerOKONH;
    }

    public void setCustomerOKONH(String customerOKONH) {
        this.customerOKONH = customerOKONH.replaceAll("\\s+", "");
    }

    public String getCustomerINN() {
        return customerINN;
    }

    public void setCustomerINN(String customerINN) {
        this.customerINN = customerINN.replaceAll("\\s+", "");
    }

    public String getCustomerBankCode() {
        return customerBankCode;
    }

    public void setCustomerBankCode(String customerBankCode) {
        this.customerBankCode = customerBankCode.replaceAll("\\s+", "");
    }

    public String getCustomerAccount() {
        return customerAccount;
    }

    public String getTaxpayerRegNumber() {
        return taxpayerRegNumber;
    }

    public void setTaxpayerRegNumber(String taxpayerRegNumber) {
        this.taxpayerRegNumber = taxpayerRegNumber.replaceAll("\\s+", "");
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount.replaceAll("\\s+", "");
    }

    public String getCustomerAccountTreasury() {
        return customerAccountTreasury;
    }

    public void setCustomerAccountTreasury(String customerAccountTreasury) {
        this.customerAccountTreasury = customerAccountTreasury.replaceAll("\\s+", "");
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
