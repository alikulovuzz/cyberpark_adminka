package uzgps.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TrackTgDataDTO {

    private Long objectId;
    private String objectName;
    private String trackDate;
    private String trackTime;
    private String trackDateTime;
    private Double latitude;
    private Double longitude;
    private Integer speedTrack;
    @JsonProperty("gsmSignal")
    private Byte gsmSignalLevel;
    @JsonProperty("satellites")
    private Byte satelliteCount;
    @JsonProperty("totalDut")
    private Double totalIndicationDut;
    private boolean hasTracks = false;

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getTrackDate() {
        return trackDate;
    }

    public void setTrackDate(String trackDate) {
        this.trackDate = trackDate;
    }

    public String getTrackTime() {
        return trackTime;
    }

    public void setTrackTime(String trackTime) {
        this.trackTime = trackTime;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Integer getSpeedTrack() {
        return speedTrack;
    }

    public void setSpeedTrack(Integer speedTrack) {
        this.speedTrack = speedTrack;
    }

    public Byte getGsmSignalLevel() {
        return gsmSignalLevel;
    }

    public void setGsmSignalLevel(Byte gsmSignalLevel) {
        this.gsmSignalLevel = gsmSignalLevel;
    }

    public Byte getSatelliteCount() {
        return satelliteCount;
    }

    public void setSatelliteCount(Byte satelliteCount) {
        this.satelliteCount = satelliteCount;
    }

    public Double getTotalIndicationDut() {
        return totalIndicationDut;
    }

    public void setTotalIndicationDut(Double totalIndicationDut) {
        this.totalIndicationDut = totalIndicationDut;
    }

    public boolean isHasTracks() {
        return hasTracks;
    }

    public void setHasTracks(boolean hasTracks) {
        this.hasTracks = hasTracks;
    }

    public String getTrackDateTime() {
        return trackDateTime;
    }

    public void setTrackDateTime(String trackDateTime) {
        this.trackDateTime = trackDateTime;
    }

    private String dateInDayFormat(Long dateLong) {
        if (dateLong != null) {
            Date date = new Date(dateLong);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

            return dateFormat.format(date);
        }

        return null;
    }

    private String dateInHourFormat(Long dateLong) {
        if (dateLong != null) {
            Date date = new Date(dateLong);
            DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

            return dateFormat.format(date);
        }

        return null;
    }

    private String dateInFullFormat(Long dateLong) {
        if (dateLong != null) {
            Date date = new Date(dateLong);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

            return dateFormat.format(date);
        }

        return null;
    }

    public void setGPSTrackPoint(GPSTrackPoint gpsTrackPoint){
        if (gpsTrackPoint != null){
            this.trackDate = dateInDayFormat(gpsTrackPoint.getDate().getTime());
            this.trackTime = dateInHourFormat(gpsTrackPoint.getDate().getTime());
            this.trackDateTime = dateInFullFormat(gpsTrackPoint.getDate().getTime());
            this.longitude = gpsTrackPoint.getLongitude();
            this.latitude = gpsTrackPoint.getLatitude();
            this.speedTrack = gpsTrackPoint.getSpeed();
            this.gsmSignalLevel = gpsTrackPoint.getIoData().getGsmSignalLevel();
            this.satelliteCount = gpsTrackPoint.getSatellites();
            this.totalIndicationDut = gpsTrackPoint.getIoData().getBakTotalLitr();
        }
    }

    public void setMobjectBig(MobjectBig mobjectBig){
        this.objectId = mobjectBig.getId();
        this.objectName = mobjectBig.getName();
    }

}
