package uzgps.rest.dto;

public class TgMobjectDTO {

    private Long objectId;
    private String objectName;
    private boolean hasTracks;

    public TgMobjectDTO() {
    }

    public TgMobjectDTO(Long objectId, String objectName, boolean hasTracks) {
        this.objectId = objectId;
        this.objectName = objectName;
        this.hasTracks = hasTracks;
    }

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public boolean isHasTracks() {
        return hasTracks;
    }

    public void setHasTracks(boolean hasTracks) {
        this.hasTracks = hasTracks;
    }
}
