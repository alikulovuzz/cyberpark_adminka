package uzgps.rest.fuel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uzgps.main.MainController;
import uzgps.persistence.User;
import uzgps.rest.BaseRest;
import uzgps.rest.ResponseUtil;
import uzgps.rest.fuel.model.FuelDrain;
import uzgps.rest.fuel.model.FuelFill;
import uzgps.rest.fuel.service.DrainingService;
import uzgps.rest.fuel.service.FillingService;

import java.util.List;


@RestController
@RequestMapping("fuel/")
public class FuelFillDrainMobject extends BaseRest {
    private final static String FILLING_MOBJECT = "/filling-mobject";
    private final static String DRAIN_MOBJECT = "/drain-mobject";

    @Autowired
    private FillingService fillingService;

    @Autowired
    private DrainingService drainingService;

    @RequestMapping(value = FILLING_MOBJECT)
    public ResponseEntity<?> getFillingById(@RequestParam(value = "object-id", required = false) Long mobjectId,
                                               @RequestParam(value = "start-date", required = false) String startDate,
                                               @RequestParam(value = "end-date", required = false) String endDate) {

        try {
           User user = MainController.getUser();
           if (user != null) {
               List<FuelFill> fuelFillList = fillingService.getFuelFillings(mobjectId, startDate, endDate);
               return ResponseUtil.respondSuccess(fuelFillList);
           } else {
               return ResponseUtil.respondUnauthorized("Unauthorized request");
           }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = DRAIN_MOBJECT)
    public ResponseEntity<?> getDrainById(@RequestParam(value = "object-id", required = false) Long mobjectId,
                                               @RequestParam(value = "start-date", required = false) String startDate,
                                               @RequestParam(value = "end-date", required = false) String endDate) {

        try {
           User user = MainController.getUser();
           if (user != null) {
               List<FuelDrain> fuelDrainList = drainingService.getFuelDrainings(mobjectId, startDate, endDate);
               return ResponseUtil.respondSuccess(fuelDrainList);
           } else {
               return ResponseUtil.respondUnauthorized("Unauthorized request");
           }
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}