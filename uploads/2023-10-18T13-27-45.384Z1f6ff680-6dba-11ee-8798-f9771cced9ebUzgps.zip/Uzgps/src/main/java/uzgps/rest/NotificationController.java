package uzgps.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.netex.core.CoreMain;
import uz.netex.dbtables.NotificationUnit;
import uzgps.common.UZGPS_CONST;
import uzgps.map.models.notification.BaseNotification;
import uzgps.message.MessageController;
import uzgps.persistence.ContractSettings;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Gayratjon on 10/19/2016.
 */
@RestController
@RequestMapping("")
public class NotificationController {

    @Autowired
    CoreMain coreMain;

    @Autowired
    MObjectController mObjectController;

    @Autowired
    MessageController messageController;

    @RequestMapping(value = "/notification-list.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMObjectList(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                            @RequestParam(value = "user-id", required = true) Long userId,
                                            @RequestParam(value = "contract-id", required = true) Long contractId,
                                            @RequestParam(value = "event-type", required = true, defaultValue = "1") Integer eventType,
                                            @RequestParam(value = "from-date", required = true) Long fromDate,
                                            @RequestParam(value = "to-date", required = true) Long toDate,
                                            @RequestParam(value = "up-to-now", required = false, defaultValue = "0") Boolean upToNow,
                                            @RequestParam(value = "object-id-list", required = false) Long[] idList,
                                            @RequestParam(value = "page-number", required = false, defaultValue = "1") Integer pageNumber) {

        if (userId == null || contractId == null
                || fromDate == null || toDate == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        List<Long> objectIdList = convertArrayToList(idList);
        if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == userRoleId) {
            userId = null;
        }
        Timestamp fromDate1 = new Timestamp(fromDate);
        Timestamp toDate1 = new Timestamp(toDate);

        List<NotificationUnit> notificationUnitList = coreMain.
                getNotificationList(contractId, userId, eventType, fromDate1, toDate1, upToNow, objectIdList, pageNumber);

        ContractSettings contractSettings = mObjectController.getContractSettingsByContractId(contractId);
        List<BaseNotification> notificationList = messageController.getFilteredNotificationList(notificationUnitList, contractSettings);
        String jsonResponse = convertObjectToJSONString(notificationList);

        return new ResponseEntity(jsonResponse, HttpStatus.OK);
    }

    private List<Long> convertArrayToList(Long[] idList) {
        if (idList == null) {
            return null;
        }
        List<Long> objectIdList = new ArrayList<>();
        for (int i = 0; i < idList.length; i++) {
            objectIdList.add(idList[i]);
        }

        return objectIdList;
    }

    private String convertObjectToJSONString(List<BaseNotification> notificationList) {
        ObjectMapper jsonMapper = new ObjectMapper();
        String jsonResponse = "";
        try {
            jsonResponse = jsonMapper.writer().writeValueAsString(notificationList);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return jsonResponse;
    }
}
