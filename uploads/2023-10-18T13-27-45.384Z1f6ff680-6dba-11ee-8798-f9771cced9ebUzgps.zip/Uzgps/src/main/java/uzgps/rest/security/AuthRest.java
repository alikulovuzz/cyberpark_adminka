package uzgps.rest.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.apache.commons.lang.SerializationUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import uzgps.admin.AdminService;
import uzgps.common.Error;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.persistence.FileStorage;
import uzgps.persistence.User;
import uzgps.persistence.UserAccessList;
import uzgps.rest.ResponseUtil;
import uzgps.security.SecurityLoggedUser;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by Stanislav on 25.05.2022 15:40
 */
@SuppressWarnings({"SingleStatementInBlock", "DuplicatedCode"})
@RestController
@RequestMapping("/auth/")
public class AuthRest implements AuthenticationManager {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private static final String REST_LOGIN_URL = "login";
    private static final String REST_CONTRACTS_URL = "contracts";
    private static final String REST_USER_URL = "user";
    private static final String REST_LOGOUT_URL = "logout";

    @Autowired
    private SecurityAuthenticationProviderRest securityAuthenticatonProviderRest;

    @Autowired
    AdminService adminService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private MainController mainController;

    @RequestMapping(value = REST_LOGIN_URL,
            produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<?> login(HttpSession session,
                                   @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                   @RequestBody(required = false) AuthReqBody authReqBody) {
        try {
            UsernamePasswordAuthenticationToken authPrincipal = new UsernamePasswordAuthenticationToken(
                    authReqBody.getUsername(),
                    authReqBody.getPassword());

            Authentication authentication = securityAuthenticatonProviderRest.authenticate(authPrincipal);
            SecurityContextHolder.getContext().setAuthentication(authentication);

            SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();
            User user = securityLoggedUser.getUser();

            List<Contract> contracts = adminService.getUserContractsByUserId(user.getId());

            // If user has access to several contracts, need to choose from them
            boolean isNeedChooseContracts = isNeedChooseContracts(authReqBody.getContractId(), contracts);
            if (isNeedChooseContracts) {
                return ResponseUtil.respondSuccess(contracts);
            }

            Long contractId = 0L;
            if (authReqBody.getContractId() == 0) {
                if (contracts != null && contracts.size() == 1) {
                    contractId = contracts.get(0).getId();
                }
            } else {
                contractId = authReqBody.getContractId();
            }

            if (contractId > 0) {
                int error = prepareSessionData(session, user, contractId, contracts, authReqBody.getIsShowObjectsOfAllContracts());
                if (error != Error.ERR_SUCCESS) {
                    return ResponseUtil.respondUnauthorized("Bad request, error: " + error);
                }

                UserAccessList userAccessList = filterUserAccessList(mainController.getUserAccessList(session));
                List<Long> userContractsIds = MainController.getUserContractsIds(session);

                final String jwtToken = jwtTokenUtil.generateToken(user, filterUserAccessList(userAccessList), userContractsIds);
                return ResponseUtil.respondSuccess(makeUser(user, jwtToken, userAccessList, userContractsIds));
            } else {
                return ResponseUtil.respondUnauthorized("Bad request");
            }


        } catch (BadCredentialsException bce) {
            logger.error("BadCredentialsException: ", bce);
            return ResponseUtil.respondUnauthorized("Unauthorized request, badCredentials");
        } catch (Exception e) {
            logger.error("Error in login", e);
            return ResponseUtil.respondUnauthorized("Unauthorized request");
        }
    }

    @RequestMapping(value = REST_CONTRACTS_URL,
            produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
    public ResponseEntity<?> getContractsForChoose(HttpSession session,
                                                   @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                   @RequestBody(required = false) AuthReqBody authReqBody) {
        try {
            UsernamePasswordAuthenticationToken authPrincipal = new UsernamePasswordAuthenticationToken(
                    authReqBody.getUsername(),
                    authReqBody.getPassword());

            Authentication authentication = securityAuthenticatonProviderRest.authenticate(authPrincipal);
            SecurityContextHolder.getContext().setAuthentication(authentication);

            SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();
            User user = securityLoggedUser.getUser();

            List<Contract> contracts = adminService.getUserContractsByUserId(user.getId());
            return ResponseUtil.respondSuccess(contracts);

        } catch (BadCredentialsException bce) {
            logger.error("BadCredentialsException: ", bce);
            return ResponseUtil.respondUnauthorized("Unauthorized request, badCredentials");
        } catch (Exception e) {
            logger.error("Error in getContracts", e);
            return ResponseUtil.respondUnauthorized("Unauthorized request");
        }
    }

    @RequestMapping(value = REST_USER_URL, method = RequestMethod.GET)
    public ResponseEntity<?> user(HttpSession session) {
        try {
            User user = MainController.getUser();

            if (user != null) {
                UserAccessList userAccessList = filterUserAccessList(mainController.getUserAccessList(session));
                List<Long> userContractsIds = MainController.getUserContractsIds(session);

                final String jwtToken = jwtTokenUtil.generateToken(user, userAccessList, userContractsIds);
                return ResponseUtil.respondSuccess(makeUser(user, jwtToken, userAccessList, userContractsIds));
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in user", e);
            return ResponseUtil.respondUnauthorized("Unauthorized request");
        }
    }

    @RequestMapping(value = REST_LOGOUT_URL, method = RequestMethod.GET)
    public ResponseEntity<?> logout(HttpSession session) {
        try {
            session.setAttribute("userDetail", null);
            session.invalidate();
            SecurityContextHolder.clearContext();

            return ResponseUtil.respondSuccess(HttpStatus.OK);

        } catch (Exception e) {
            logger.error("Error in logout", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    private int prepareSessionData(HttpSession session, User user, Long contractId, List<Contract> contracts, boolean isShowObjectsOfAllContracts) {
        long userId = user.getId();
        Contract contract = adminService.getContractById(contractId);

        FileStorage photo = null;
        if (MainController.getUser() != null && MainController.getUser().getPhoto() != null) {
            photo = MainController.getUser().getPhoto();
        }

        MainController.replaceUserInSession(contract, userId, photo, null, null, null);

        MainController.setUserContractId(contractId, session);
        MainController.setUserContract(contract, session);

        session.removeAttribute(MainController.SESSION_USER_ACCESS_LIST);
        session.removeAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        session.removeAttribute(MainController.SESSION_CONTRACTS);
        session.removeAttribute(MainController.SESSION_SHOW_OBJECTS_OF_ALL_CONTRACTS);

        if (isShowObjectsOfAllContracts) {
            // Add contracts to session
            MainController.setUserContracts(contracts, session);
            // Add ShowObjectsOfAllContracts value to session
            MainController.setIsShowObjectsByAllContracts(1, session);
        }

        User customerAdmin = adminService.getCustomerAdminById(userId);
        if (customerAdmin != null) {
            customerAdmin.setContract(contract);
            MainController.replaceCustomerAdminInSession(customerAdmin);
        } else {
            user.setContract(contract);
            user.setInterfaceContractId(contract.getId());
            user.setInterfaceAuthToken(user.getAuthToken());
        }


//        else {
//            return Error.ERR_NO_CUSTOMER_ADMIN_FOR_CONTRACT;
//        }

        return Error.ERR_SUCCESS;
    }

    private JsonObject makeUser(User user, String jwtToken, UserAccessList userAccessList, List<Long> contractIdList) {
        JsonObject userObj = new JsonObject();

        try {
            ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
            userObj.put("id", user.getId());
            userObj.put("login", user.getLogin());
            userObj.put("name", user.getName());
            userObj.put("surname", user.getSurName());
            userObj.put("middleName", user.getMiddleName());
            userObj.put("recoveryKey", user.getRecoveryKey());

            userObj.put("interfaceUserId", user.getInterfaceUserId());
            userObj.put("interfaceContractId", user.getInterfaceContractId());

            userObj.put("managerId", user.getManagerId());

            userObj.put("roleId", user.getRoleId());
            userObj.put("role", new JsonObject(ow.writeValueAsString(user.getRole())));

            userObj.put("contractId", user.getContractId());

            if (contractIdList != null) {
                userObj.put("contractIdList", contractIdList.toString());
                userObj.put("contractIdListArr", new JsonArray(contractIdList.toString()));
                userObj.put("showObjectsOfAllContracts", true);
            } else {
                userObj.put("contractIdList", String.format("[%d]", user.getContractId()));
                userObj.put("contractIdListArr", (Object) null);
                userObj.put("showObjectsOfAllContracts", false);
            }

            userObj.put("authToken", user.getAuthToken());
            userObj.put("jwtToken", jwtToken);

            userObj.put("profile", new JsonObject(ow.writeValueAsString(user.getProfile())));

            if (user.getContract() != null) {
                userObj.put("contract", new JsonObject(ow.writeValueAsString(user.getContract())));
            }

            if (user.getUserRole() != null) {
                userObj.put("userRole", new JsonObject(ow.writeValueAsString(user.getUserRole())));
            }

            if (userAccessList != null) {
                userObj.put("userAccessList", new JsonObject(ow.writeValueAsString(userAccessList)));
            }

        } catch (Exception e) {
            logger.error("Error in makeUser", e);
        }

        return userObj;
    }

    private Contract makeUserContract(Contract contract) {
        Contract userContract = new Contract();
        try {
            userContract.setId(contract.getId());
            userContract.setContractNumber(contract.getContractNumber());
            userContract.setContractType(contract.getContractType());
            userContract.setRegistrationDate(contract.getRegistrationDate());
            userContract.setCustomerCompanyName(contract.getCustomerCompanyName());

            if (contract.getCompany() != null) {
                userContract.setCompany(contract.getCompany());
            }

        } catch (Exception e) {
            logger.error("Error in makeUserContract", e);
        }

        return userContract;
//        return securityLoggedUser.getUser().setInterfaceUserId();
    }

    private boolean isNeedChooseContracts(Long contractId, List<Contract> contracts) {
        if (contractId == null || contractId == 0) {
            // if a logged user have access to more than 1 contract, he must choose one of contract
            return contracts.size() > 1;
        }
        return false;
    }


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        return null;
    }

    private UserAccessList filterUserAccessList(UserAccessList ual) {
        UserAccessList userAccessList = (UserAccessList) SerializationUtils.clone(ual);
        userAccessList.setContract(null);
        userAccessList.setUser(null);
        return userAccessList;
    }

}
