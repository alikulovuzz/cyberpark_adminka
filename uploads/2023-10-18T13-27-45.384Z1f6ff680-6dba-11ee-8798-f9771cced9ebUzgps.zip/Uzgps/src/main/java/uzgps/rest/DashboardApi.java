package uzgps.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import uz.netex.core.CoreMain;
import uz.netex.server.TCPServer;
import uzgps.rest.dto.DashboardStatisticsDTO;

/**
 * Created by Saidolim on 17.10.2016.
 */
@RestController
@RequestMapping("")
public class DashboardApi {

    @Autowired
    CoreMain coreMain;

    public final static String URL_DASHBOARD_STAT = "/dashboard.json";

    @RequestMapping(value = URL_DASHBOARD_STAT)
    public ResponseEntity<?> getDashboardStatistics() {
        DashboardStatisticsDTO dashboardStatisticsDTO = new DashboardStatisticsDTO();
        dashboardStatisticsDTO.setQtDbHandler(coreMain.getQueueCount(CoreMain.QT_DB_HANDLER));
        dashboardStatisticsDTO.setQtDbLogHexHandler(coreMain.getQueueCount(CoreMain.QT_DB_LOG_HEX_HANDLER));
        dashboardStatisticsDTO.setParserThreadCount(TCPServer.getThreadCount());
        dashboardStatisticsDTO.setTrackerCountLicense(coreMain.getTrackerCountInLicense());

        return new ResponseEntity(dashboardStatisticsDTO, HttpStatus.OK);
    }

}
