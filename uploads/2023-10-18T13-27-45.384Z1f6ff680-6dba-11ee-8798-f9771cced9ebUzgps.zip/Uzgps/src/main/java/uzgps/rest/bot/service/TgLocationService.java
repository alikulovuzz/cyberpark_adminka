package uzgps.rest.bot.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.TgLocation;
import uzgps.rest.dto.TgLocationDTO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.List;

@Service
public class TgLocationService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<TgLocation> getTgLocationList() {
        Query query;
        query = entityManager.createNamedQuery("TgLocation.findAll");
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);

        return query.getResultList();
    }

    @Transactional
    public TgLocation addTgLocation(TgLocationDTO tgLocationDTO){
        TgLocation tgLocation = new TgLocation();
        tgLocation.setChatId(tgLocationDTO.getChatId());
        tgLocation.setMessageId(tgLocationDTO.getMessageId());
        tgLocation.setMobjectId(tgLocationDTO.getMobjectId());
        tgLocation.setTimeExpireDate(new Timestamp(tgLocationDTO.getExpireTime()));

        //disable existing location by chat id
        disableTgLocationByChatId(tgLocationDTO.getChatId());
        return saveTgLocation(tgLocation);
    }

    @Transactional
    public TgLocation saveTgLocation(TgLocation tgLocation) {
        if (tgLocation.getId() != null) {
            entityManager.merge(tgLocation);
        } else {
            entityManager.persist(tgLocation);
        }
        return tgLocation;
    }

    @Transactional
    public void disableTgLocation(Long id) {
        if (id != null) {
            Query query;
            query = entityManager.createNamedQuery("TgLocation.updateStatusById");
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.executeUpdate();
        }
    }

    @Transactional
    public boolean disableTgLocationByMessageId(Long id) {
        try {
            if (id != null) {
                Query query;
                query = entityManager.createNamedQuery("TgLocation.updateStatusByMessageId");
                query.setParameter("id", id);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.executeUpdate();
                return true;
            }
        }catch (Exception e){
            logger.error("Error in disableTgLocationByMessageId", e);
        }
        return false;
    }

    @Transactional
    public boolean disableTgLocationByChatId(Long id) {
        try {
            if (id != null) {
                Query query;
                query = entityManager.createNamedQuery("TgLocation.updateStatusByChatId");
                query.setParameter("id", id);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.executeUpdate();
                return true;
            }
        }catch (Exception e){
            logger.error("Error in disableTgLocationByChatId", e);
        }
        return false;
    }
}
