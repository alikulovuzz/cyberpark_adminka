package uzgps.rest.bot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uzgps.rest.bot.payload.TokenDTO;
import uzgps.rest.bot.service.TgUserService;
import uzgps.rest.bot.payload.ApiResponse;
import uzgps.rest.bot.payload.TgUserDTO;

import javax.validation.Valid;

@RestController
@RequestMapping("/tg-user")
public class TgUserController {

    @Autowired
    TgUserService tgUserService;

    @RequestMapping(value = "/{id}",method = RequestMethod.GET,produces = "application/json")
    public HttpEntity<?> getTgUser(@PathVariable Long id){
        String tgUserToken = tgUserService.getEncodedTgUser(id);
        return ResponseEntity
                .status(tgUserToken != null ? HttpStatus.ACCEPTED : HttpStatus.NOT_FOUND)
                .body(tgUserToken);
    }

    @RequestMapping(
            value = "",
            method = RequestMethod.POST,
            produces = "application/json"
    )
    public HttpEntity<?> addUser(@Valid @RequestBody TgUserDTO tgUserDTO){
        ApiResponse apiResponse = tgUserService.addTgUser(tgUserDTO);
        return ResponseEntity
                .status(apiResponse.getIsSuccess() ? HttpStatus.CREATED : HttpStatus.CONFLICT)
                .body(apiResponse);
    }

    @RequestMapping(
            value = "/{id}",
            method = RequestMethod.PUT,
            produces = "application/json"
    )
    public HttpEntity<?> editUser(@Valid @PathVariable Long id,@RequestBody TgUserDTO tgUserDTO){
        ApiResponse apiResponse = tgUserService.editUser(id, tgUserDTO);
        return ResponseEntity
                .status(apiResponse.getIsSuccess() ? HttpStatus.ACCEPTED : HttpStatus.CONFLICT)
                .body(apiResponse);
    }

    @RequestMapping(
            value = "/check-token",
            method = RequestMethod.POST,
            produces = "application/json"
    )
    public HttpEntity<?> checkUserToken(@RequestBody TokenDTO tokenDTO){
        ApiResponse apiResponse = tgUserService.checkUserToken(tokenDTO);
        return ResponseEntity
                .status(apiResponse.getIsSuccess() ? HttpStatus.ACCEPTED : HttpStatus.NOT_FOUND)
                .body(apiResponse);
    }

}
