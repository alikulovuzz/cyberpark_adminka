package uzgps.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.core.helper.CorePoi;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectInPoiGeofence;
import uzgps.common.UZGPS_CONST;
import uzgps.map.GeoFenceService;
import uzgps.map.POIService;
import uzgps.persistence.GeoFence;
import uzgps.persistence.GeoFencePoint;
import uzgps.persistence.POI;

import java.util.*;

/**
 * Created by Gayratjon on 12/14/2016.
 */
@RestController
@RequestMapping("")
public class ZoneController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    GeoFenceService geoFenceService;

    @Autowired
    POIService poiService;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = "/update-zoi-by-contract-id.json", method = RequestMethod.GET)
    public ResponseEntity<?> updateZoiByContractId(@RequestParam(value = "contract-id", required = true) Long contractId) {
        try {
            if (contractId == null) {
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
            }

            coreMain.coreUpdater.updateGeofenceByContract(contractId);

            return new ResponseEntity<>(contractId, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error in updateUserMobjectAccess", e);
        }
        return new ResponseEntity<>(0, HttpStatus.OK);
    }

    @RequestMapping(value = "/update-poi-by-contract-id.json", method = RequestMethod.GET)
    public ResponseEntity<?> updatePoiByContractId(@RequestParam(value = "contract-id", required = true) Long contractId) {
        try {
            if (contractId == null) {
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.OK);
            }

            coreMain.coreUpdater.updatePoiByContract(contractId);

            return new ResponseEntity<>(contractId, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error in updateUserMobjectAccess", e);
        }
        return new ResponseEntity<>(0, HttpStatus.OK);
    }


    @RequestMapping(value = "/zone-list.json", method = RequestMethod.GET)
    public ResponseEntity<?> getZoneList(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                         @RequestParam(value = "user-id", required = true) Long userId,
                                         @RequestParam(value = "contract-id", required = true) Long contractId) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        List<GeoFence> geoFenceList = geoFenceService.getGeoFenceListByContractIdAndStatus(contractId, UZGPS_CONST.STATUS_ACTIVE);
        cleanUnnecessaryObjects(geoFenceList);

        return new ResponseEntity(geoFenceList, HttpStatus.OK);
    }

    private void cleanUnnecessaryObjects(List<GeoFence> geoFenceList) {
        if (geoFenceList != null) {
            for (GeoFence geoFence : geoFenceList) {
                List<GeoFencePoint> geoFencePointList = geoFence.getGeoFencePointList();
                if (geoFencePointList != null) {
                    for (GeoFencePoint geoFencePoint : geoFencePointList) {
                        geoFencePoint.setGeoFence(null);
                    }
                }
            }
        }
    }

    @RequestMapping(value = "/mobject-in-zone-list.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectInZoneList(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                                  @RequestParam(value = "user-id", required = true) Long userId,
                                                  @RequestParam(value = "contract-id", required = true) Long contractId) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        // make list to return
        List<MobjectBig> mObjectInGeofenceList = Collections.emptyList();

        // get mobject list, for this user
        List<MobjectBig> mobjectList = getMobjectList(userRoleId, userId, contractId);

        // Get geofence list for this user
        List<GeoFence> geoFenceList = geoFenceService.getGeoFenceListByContractIdAndStatus(contractId, UZGPS_CONST.STATUS_ACTIVE);

        // get clean Map of Geofence with mobject list
        Map<Long, List<MobjectInPoiGeofence>> mapByGeofenceForMobject = getCleanMapByGeofenceForMobject(mobjectList, geoFenceList);

        return new ResponseEntity(mapByGeofenceForMobject, HttpStatus.OK);
    }

    /**
     * Returns map of Geofence id with Mobject list
     *
     * @param mobjectList
     * @param geoFenceList
     * @return
     */
    private Map<Long, List<MobjectInPoiGeofence>> getCleanMapByGeofenceForMobject(List<MobjectBig> mobjectList,
                                                                                  List<GeoFence> geoFenceList) {

        // Get Map of all geofences and mobjects
        CoreGeofence coreGeofence = CoreGeofence.getInstance();
        Map<Long, List<MobjectInPoiGeofence>> listMobjectInZones = null;

        if (coreGeofence != null) {
            coreGeofence.loadMobjectsInGeofence();
            listMobjectInZones = coreGeofence.getMapByGeofenceForMobjectInGeofence();
        }

        Map<Long, List<MobjectInPoiGeofence>> resultMap = new HashMap<>();

        if (listMobjectInZones != null)
            for (GeoFence geoFence : geoFenceList) {
                if (geoFence != null && geoFence.getId() != null) {
                    List<MobjectInPoiGeofence> listForThisGeofence = new ArrayList<>();

                    // get list by geofence
                    if (listMobjectInZones.containsKey(geoFence.getId())) {
                        List<MobjectInPoiGeofence> mobjectInPoiList = listMobjectInZones.get(geoFence.getId());
                        if (mobjectInPoiList != null) {
                            // for each element of mobjectInPoiGeofence list
                            for (MobjectInPoiGeofence mobjectInPoiGeofence : mobjectInPoiList) {
                                if (mobjectInPoiGeofence != null
                                        && mobjectInPoiGeofence.getPoiId() != null
                                ) {

                                    for (MobjectBig mobject : mobjectList) {
                                        if (mobject != null
                                                && mobject.getId() != null
                                                && mobjectInPoiGeofence.getMobjectId().equals(mobject.getId())
                                        ) {
                                            // Add to list
                                            listForThisGeofence.add(mobjectInPoiGeofence);
                                        }
                                    }

                                }
                            }
                        }
                    }

                    if (listForThisGeofence.size() > 0) {
                        resultMap.put(geoFence.getId(), listForThisGeofence);
                    }

                }
            }

        return resultMap;
    }

    @RequestMapping(value = "/poi-list.json", method = RequestMethod.GET)
    public ResponseEntity<?> getPoiList(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                        @RequestParam(value = "user-id", required = true) Long userId,
                                        @RequestParam(value = "contract-id", required = true) Long contractId) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        List<POI> poiList = poiService.getPOIListByContractIdAndStatus(contractId, UZGPS_CONST.STATUS_ACTIVE);

        return new ResponseEntity(poiList, HttpStatus.OK);
    }

    /**
     * Mobject list by user type and contract id
     *
     * @param userRoleId if 1, then user
     * @param userId     user id, if role = 1
     * @param contractId admin or customer admin
     * @return empty list, if no data
     */
    public List<MobjectBig> getMobjectList(Long userRoleId,
                                           Long userId,
                                           Long contractId) {
        List<MobjectBig> mObjectList = Collections.emptyList();
        if (UZGPS_CONST.USER_ROLE_USER == userRoleId) {
            mObjectList = coreMain.getMobjectListByUser(userId);
        } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == userRoleId) {
            mObjectList = coreMain.getMobjectListByContract(contractId);
        }
        return mObjectList;
    }


    @RequestMapping(value = "/mobject-in-poi-list.json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectInPoiList(@RequestParam(value = "user-role-id", required = true) Long userRoleId,
                                                 @RequestParam(value = "user-id", required = true) Long userId,
                                                 @RequestParam(value = "contract-id", required = true) Long contractId) {

        if (userRoleId == null || userId == null || contractId == null) {
            return new ResponseEntity(Collections.emptyList(), HttpStatus.OK);
        }

        // get mobject list, for this user
        List<MobjectBig> mobjectList = getMobjectList(userRoleId, userId, contractId);

        // Get Poi list for this user
        List<POI> poiList = poiService.getPOIListByContractIdAndStatus(contractId, UZGPS_CONST.STATUS_ACTIVE);

        // get clean Map of poi with mobject list
        Map<Long, List<MobjectInPoiGeofence>> mapByPoiForMobject = getCleanMapByPoiForMobject(mobjectList, poiList);

        return new ResponseEntity(mapByPoiForMobject, HttpStatus.OK);
    }

    /**
     * Returns map of Geofence id with Mobject list
     *
     * @param mobjectList
     * @param poiList
     * @return
     */
    private Map<Long, List<MobjectInPoiGeofence>> getCleanMapByPoiForMobject(List<MobjectBig> mobjectList,
                                                                             List<POI> poiList) {

        // Get Map of all poi and mobjects
        CorePoi corePoi = CorePoi.getInstance();
        Map<Long, List<MobjectInPoiGeofence>> listMobjectInPoi = null;

        if (corePoi != null) {
            corePoi.loadMobjectsInPoi();
            listMobjectInPoi = corePoi.getMapByPoiForMobjectInPoi();
        }

        Map<Long, List<MobjectInPoiGeofence>> resultMap = new HashMap<>();

        if (listMobjectInPoi != null)
            for (POI poi : poiList) {
                if (poi != null && poi.getId() != null) {
                    List<MobjectInPoiGeofence> listForThisPoi = new ArrayList<>();

                    // get list by poi
                    if (listMobjectInPoi.containsKey(poi.getId())) {
                        List<MobjectInPoiGeofence> mobjectInPoiList = listMobjectInPoi.get(poi.getId());
                        if (mobjectInPoiList != null) {
                            // for each element of mobjectInPoi list
                            for (MobjectInPoiGeofence mobjectInPoi : mobjectInPoiList) {
                                if (mobjectInPoi != null
                                        && mobjectInPoi.getPoiId() != null
                                ) {

                                    for (MobjectBig mobject : mobjectList) {
                                        if (mobject != null
                                                && mobject.getId() != null
                                                && mobjectInPoi.getMobjectId().equals(mobject.getId())
                                        ) {
                                            // Add to list
                                            listForThisPoi.add(mobjectInPoi);
                                        }
                                    }

                                }
                            }
                        }
                    }

                    if (listForThisPoi.size() > 0) {
                        resultMap.put(poi.getId(), listForThisPoi);
                    }

                }
            }

        return resultMap;
    }
}
