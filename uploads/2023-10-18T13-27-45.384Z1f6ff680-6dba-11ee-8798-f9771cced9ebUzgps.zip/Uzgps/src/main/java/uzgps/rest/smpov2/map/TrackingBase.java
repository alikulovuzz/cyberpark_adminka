package uzgps.rest.smpov2.map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.core.helper.CorePoi;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GPSTrackPointList;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Poi;
import uz.netex.fuelcontrol.core.CoreFuelControl;
import uz.netex.fuelcontrol.database.tables.Bak;
import uz.netex.fuelcontrol.database.tables.FuelDatchik;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.service.TripRunnerService;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.excel.ExcelDownloadTrackData;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.ParkingHelper;
import uzgps.map.TrackingController;
import uzgps.map.TripHelperV2;
import uzgps.map.kml.KMLExtraDataEvent;
import uzgps.map.kml.KMLObjectTrack;
import uzgps.map.models.*;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.CustomDistancesForTracking;
import uzgps.persistence.MObjectSettings;
import uzgps.rest.BaseRest;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uzgps.route.DouglasPeuckerReducer;
import uzgps.settings.SettingsService;

public class TrackingBase extends BaseRest {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());
    protected final static String SESSION_OBJECT_SETTINGS = "sessionMObjectSettings";
    protected final static double MIN_TRIP_DISTANCE = 0.5;
    protected final static int EXCEL_TRACK_POINTS_DOWNLOAD_LIMIT = 50000;
    protected final static String VIEW_MAP_OBJECT_TRACKS_TABLE = "map/ajax-tracks-table";
    protected final static String URL_MAP_OBJECT_TRACKS_TABLE = "/map/tracking-object-tracks-table.htm";
    protected static final String VIEW_MAX_TRACKS_LIMIT_MESSAGE = "map/max-tracks-limit-message";
    protected static final String VIEW_NO_TRACKS_MESSAGE = "map/no-tracks-message";

    @Autowired
    protected
    MainController mainController;

    @Autowired
    protected
    CoreMain coreMain;

    @Autowired
    protected
    SettingsService settingsService;

    @Autowired
    protected
    ObjectMapper jsonMapper;

    @Autowired
    protected
    MonitoringController monitoringController;

    @Autowired
    protected
    ExcelDownloadTrackData excelDownloadTrackData;

    /**
     * Get list of gps track point from DB for given period of time
     *
     * @param mObjectId
     * @param pointCount
     * @param startDate
     * @param endDate
     * @return
     */

    public GPSTrackPointList getGpsTrackPointList(Long mObjectId, Integer pointCount, String startDate, String endDate) {
        GPSTrackPointList gpsTrackPointList = null;

        try {
            if (pointCount > 0) {
                gpsTrackPointList = coreMain.getPointsByDate(mObjectId, startDate, endDate, pointCount);
            } else {
                SimpleDateFormat dateFormat1 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss.SSS");
                SimpleDateFormat dateFormat2 = new SimpleDateFormat("dd.MM.yyyy HH:mm");
                Date fromDate;
                Date toDate;
                try {
                    fromDate = dateFormat1.parse(startDate);
                    toDate = dateFormat1.parse(endDate);
                } catch (ParseException e) {
                    fromDate = null;
                    toDate = null;
                }

                if (fromDate == null && toDate == null) {
                    try {
                        fromDate = dateFormat2.parse(startDate);
                        toDate = dateFormat2.parse(endDate);
                    } catch (ParseException e) {
                        fromDate = null;
                        toDate = null;
                    }
                }

                if (fromDate != null && toDate != null) {
                    gpsTrackPointList = coreMain.getPointsByDate(mObjectId, new Timestamp(fromDate.getTime()).getTime(), new Timestamp(toDate.getTime()).getTime(), pointCount);
                }
            }
        } catch (Exception e) {
            logger.error("Error in getGpsTrackPointList", e);
        }

        return gpsTrackPointList;
    }

    protected KMLObjectTrack getKmlObjectTrack(HttpSession session, Long mObjectId, String startDate, String endDate, Integer pointCount, String trackTypeColor, String color, Integer lineWidth, String trackViewTypeStr) {

        if (logger.isDebugEnabled()) {
            logger.debug("Build tracks for parameters: object-id={}, start-date={}, end-date={}, point-count={}, track-type-color={}, color={}, line-width={}",
                    mObjectId, startDate, endDate, pointCount, trackTypeColor, color, lineWidth);
        }

        /* ----- TRACK DRAWING ------ */
        KMLObjectTrack kmlObjectTrack = null;

        if (mObjectId != null) {
            int trackViewType = Converters.strToInt(trackViewTypeStr, 1);

            GPSTrackPointList gpsTrackPointList = getGpsTrackPointList(mObjectId, pointCount, startDate, endDate);

            // Clear NULL and ZERO coordinates - Delete ZERO points
            coreMain.deleteZeroPoints(gpsTrackPointList);

            MobjectBig mobject = coreMain.getMobjectById(mObjectId);

            MObjectSettings mObjectSettings = (MObjectSettings) session.getAttribute(SESSION_OBJECT_SETTINGS + mObjectId);
            TrackingController.SpeedColor speedColor = new TrackingController.SpeedColor();

            if (mObjectSettings == null) {
                mObjectSettings = settingsService.getObjectSettingsByObjectId(mObjectId);

                if (mObjectSettings != null) {
                    speedColor.setSpeedColorList(mObjectSettings);
                    session.setAttribute(SESSION_OBJECT_SETTINGS + mObjectId, mObjectSettings);
                } else {
                    speedColor.setDefault();
                }
            } else {
                speedColor.setSpeedColorList(mObjectSettings);
            }

            Timestamp startDateT = null;
            Timestamp endDateT = null;
            if (!startDate.equalsIgnoreCase("")) {
                startDate = startDate.trim();


                try {
                    startDateT = Converters.dateFormatterTimestamp(startDate);
                } catch (Exception e) {
                    logger.error("Error in date converting", e);
                }
                if (startDateT == null) {
                    startDateT = Converters.dateFormatterTimestampSimple(startDate);
                }
            }

            if (!endDate.equalsIgnoreCase("")) {
                endDate = endDate.trim();

                try {
                    endDateT = Converters.dateFormatterTimestamp(endDate);
                } catch (Exception e) {
                    logger.error("Error in date converting", e);
                }

                if (endDateT == null) {
                    endDateT = Converters.dateFormatterTimestampSimple(endDate);
                }
            }

            List<CustomDistancesForTracking> distancesList = adminService.getDistanceByObjectAndPeriod(mObjectId, startDateT, endDateT);

            if (gpsTrackPointList != null && distancesList != null) {
                List<KMLExtraDataEvent> kmlExtraDataEvents = new ArrayList<>();
                List<KMLExtraDataEvent> trips;

                if (trackViewType == UZGPS_CONST.TRACK_VIEW_TYPE.BY_DAY_AND_TRIP_PARKING.getValue()) {
                    MobjectBig mobjectBig = coreMain.getMobjectById(mObjectId);

                    ParkingHelper parkingHelper = new ParkingHelper();
                    kmlExtraDataEvents = parkingHelper.getParkingEventsForKMLExtraData(mobjectBig, mObjectSettings, gpsTrackPointList.getGpsTrackPoints());

                    TripHelperV2 tripHelperV2 = new TripHelperV2();
                    trips = tripHelperV2.getTripEventsForKMLExtraData(mobjectBig, kmlExtraDataEvents);

                    try {
                        // set distances from DB
                        if (trips != null) {
                            for (KMLExtraDataEvent trip : trips) {
                                Double tripDistanceTotal = 0D;
                                List<Double> tripDistancesList =
                                        adminService.getOnlyDistanceByObjectAndPeriod(mObjectId,
                                                new Timestamp(trip.getFromDate()),
                                                new Timestamp(trip.getToDate()));

                                for (Double tripDistance : tripDistancesList) {
                                    tripDistanceTotal += tripDistance;
                                }
                                trip.seteTripDistDouble(tripDistanceTotal);

                                if (trip.geteTripDistDouble() >= MIN_TRIP_DISTANCE) {
                                    kmlExtraDataEvents.add(trip);
                                }
                            }
                        }
                    } catch (Exception e) {
                        logger.error("Error in getMovableObjectTracksById", e);
                    }

                    if (kmlExtraDataEvents != null && kmlExtraDataEvents.size() > 0) {
                        kmlExtraDataEvents.sort(Comparator.comparing(KMLExtraDataEvent::getFromDate));
                    }
                }

                kmlObjectTrack = new KMLObjectTrack(mobject, gpsTrackPointList, speedColor, trackTypeColor,
                        color, lineWidth, 1000, distancesList, trackViewType, kmlExtraDataEvents);
            }

        }
        return kmlObjectTrack;
    }

    private boolean isMObjectHasBak(long mObjectId) {
        boolean hasBak = false;


        // Connect to Core Fuel Controller
        CoreFuelControl coreFuelControl = coreMain.getCoreFuelControl();

        // get fuel Datchik  by mobject id
        FuelDatchik fuelDatchik = coreFuelControl.getFuelDatchikByMobjectId(mObjectId);
        if (fuelDatchik != null) {
            Bak bak1 = fuelDatchik.getBak1();
            Bak bak2 = fuelDatchik.getBak2();
            Bak bak3 = fuelDatchik.getBak3();
            Bak bak4 = fuelDatchik.getBak4();

            if ((bak1 != null && bak1.getUse() != null && bak1.getUse() == 1)
                    || (bak2 != null && bak2.getUse() != null && bak2.getUse() == 1)
                    || (bak3 != null && bak3.getUse() != null && bak3.getUse() == 1)
                    || (bak4 != null && bak4.getUse() != null && bak4.getUse() == 1)) {
                hasBak = true;
            }
        }

        return hasBak;
    }

    private double getBakTotalValue(GPSTrackPoint trackPoint, boolean hasBak) {
        if (hasBak && trackPoint.getBakTotalLitr() != null) {
            return trackPoint.getBakTotalLitr();
        } else {
            return 0.0;
        }
    }

    private String getChartDataByTrackPoint(GPSTrackPoint trackPoint, String bakStr) throws JsonProcessingException {

        ChartDataCI chartDataCI = new ChartDataCI(
                trackPoint.getDate().getTime(),
                trackPoint.getSpeed().toString(), bakStr, ((int) trackPoint.getEngineOn()));

        ObjectMapper mapper = new ObjectMapper();

        if (trackPoint.getIoData() != null && trackPoint.getIoData().getExternalPowerVoltage() != null) {
            int externalBattery = (int) trackPoint.getIoData().getExternalPowerVoltage();
            chartDataCI.setExternalBattery(externalBattery);
        } else {
            chartDataCI.setExternalBattery(0);
        }

        // Converting the Object to JSONString
        return mapper.writeValueAsString(chartDataCI);
    }

    protected List<Integer> getPageNumbers(Integer currentPage, Integer maxPages) {
        List<Integer> list = new ArrayList<>();
        if (currentPage != null && maxPages != null) {
            if (maxPages > 0) list.add(0); // 1 page
            if (maxPages > 1) list.add(1); // 2 page
            if (maxPages > 2) list.add(2); // 3 page

            if (currentPage > 1) {
                if (!list.contains(currentPage - 1) && (currentPage - 1 < maxPages))
                    list.add(currentPage - 1); // current - 1

                if (!list.contains(currentPage) && (currentPage < maxPages))
                    list.add(currentPage); // current

                if (!list.contains(currentPage + 1) && (currentPage + 1 < maxPages))
                    list.add(currentPage + 1); // current + 1
            }


            if (!list.contains(maxPages - 3) && (maxPages - 3 > 0)) list.add(maxPages - 3); // last-2 page
            if (!list.contains(maxPages - 2) && (maxPages - 3 > 0)) list.add(maxPages - 2); // last-1 page
            if (!list.contains(maxPages - 1) && (maxPages - 3 > 0)) list.add(maxPages - 1); // last page

            Collections.sort(list);

        }
        return list;
    }

    protected void addPaginationData(ModelAndView modelAndView, int currentPageId,
                                     int tracksCount, String paginationUrl, int limit) {

        int pagesCount = (tracksCount + limit - 1) / limit;

        if (currentPageId >= pagesCount
                && currentPageId > 0
                && pagesCount > 0) {
            currentPageId = pagesCount - 1;
        }

        List<Integer> pages = getPageNumbers(currentPageId, pagesCount);

        modelAndView.addObject("pageNumber", currentPageId);
        modelAndView.addObject("pageCount", pagesCount);
        modelAndView.addObject("pagination", pages);
        modelAndView.addObject("paginationUrl", paginationUrl);
    }

    protected ModelAndView loadDataForTrackingService(HttpSession session, Long mObjectId, String startDateStr, String endDateStr, String limitStr, String needLoadTracksTableStr, String pageIdStr) throws JsonProcessingException {
        if (logger.isDebugEnabled()) {
            logger.debug("Build tracks table for parameters: object-id={}, start-date={}, end-date={}, limit={}",
                    mObjectId, startDateStr, endDateStr, limitStr);
        }

        int pageId = Converters.strToInt(pageIdStr, 0);
        int limit = Converters.strToInt(limitStr, 0);
        boolean needLoadTracksTable = Converters.strToBoolean(needLoadTracksTableStr, false);

        /* ----- TRACK TABLE ------ */
        ModelAndView modelAndView = new ModelAndView(VIEW_MAP_OBJECT_TRACKS_TABLE);

        if (mObjectId != null) {
            String dateFormatPattern = "dd.MM.yyyy HH:mm:ss.SSS";

            if (startDateStr.length() < 17 && endDateStr.length() < 17) {
                dateFormatPattern = "dd.MM.yyyy HH:mm";
            }

            SimpleDateFormat dateFormat = new SimpleDateFormat(dateFormatPattern);
            Date fromDate = null;
            Date toDate = null;
            try {
                fromDate = dateFormat.parse(startDateStr);
                toDate = dateFormat.parse(endDateStr);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            Long tracksCount = null;
            GPSTrackPointList gpsTrackPointList = null;

            try {
                tracksCount = coreMain.getPointsCountByDate(mObjectId,
                        new Timestamp(fromDate.getTime()).getTime(),
                        new Timestamp(toDate.getTime()).getTime());

                gpsTrackPointList = new GPSTrackPointList();
                if (tracksCount > 0) {
                    if (limit > 0) {
                        gpsTrackPointList = coreMain.getPointsByDateFiltered(mObjectId,
                                new Timestamp(fromDate.getTime()).getTime(),
                                new Timestamp(toDate.getTime()).getTime(),
                                limit, pageId);
                    } else if (limit == 0) {
                        gpsTrackPointList = coreMain.getPointsByDate(mObjectId,
                                new Timestamp(fromDate.getTime()).getTime(),
                                new Timestamp(toDate.getTime()).getTime(),
                                limit);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            MobjectBig mObject = coreMain.getMobjectById(mObjectId);

            if (gpsTrackPointList != null && gpsTrackPointList.getGpsTrackPoints() != null &&
                    gpsTrackPointList.getGpsTrackPoints().size() > 0 && mObject != null) {
                ContractSettings contractSettings = mainController.getContractSettings(session);
                SimpleFilterProvider filterProvider = new SimpleFilterProvider();

                filterProvider.addFilter("TrackPopupDataFilter",
                        SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.trackPopupIgnoredFieldNames(contractSettings)));

                ObjectWriter objectWriter = jsonMapper.writer(filterProvider).withRootName("data");
                List<Message> messageList = new ArrayList<>();
                List<String> chartData = new ArrayList<>();

                List<GPSTrackPoint> trackPointList = gpsTrackPointList.getGpsTrackPoints();

                boolean hasBak = isMObjectHasBak(mObjectId);

                long firstTrackTime = trackPointList.get(0).getTimestamp();
                long lastTrackTime = trackPointList.get(trackPointList.size() - 1).getTimestamp();

                if (firstTrackTime < lastTrackTime) {
                    trackPointList = Lists.reverse(trackPointList);
                }

                double validBakTotal = 0.0;

                // Collect mobject in Poi
                CorePoi corePoi = CorePoi.getInstance();
                // Collect mobject in Geofence
                CoreGeofence coreGeofence = CoreGeofence.getInstance();

                if (corePoi != null) {
                    corePoi.loadMobjectsInPoi();
                }

                if (coreGeofence != null) {
                    coreGeofence.loadMobjectsInGeofence();
                }

                for (int i = trackPointList.size() - 1; i >= 0; i--) {
                    // Preparing popup data for mobject
                    GPSTrackPoint trackPoint = trackPointList.get(i);

                    TrackPopupData trackPopupData = new TrackPopupData();
                    trackPopupData.setGPSTrackPoint(trackPoint);
                    trackPopupData.setMobjectBig(mObject);

                    List<Poi> poiList = null;
                    List<Geofence> geofenceList = null;

                    if (corePoi != null) {
                        poiList = corePoi.getPoiWithMobjectInside(mObjectId);
                    }

                    if (coreGeofence != null) {
                        geofenceList = coreGeofence.getGeofencesWithMobjectInside(mObjectId);
                    }

                    trackPopupData.setPoiAndGeoFenceList(poiList, geofenceList);
                    trackPopupData.setAssignedRoutes(monitoringController.getAssignedTripNamesToMobject(mObject.getId()));

                    if (needLoadTracksTable) {
                        Message message = new Message(trackPoint);
                        message.setJson(objectWriter.writeValueAsString(trackPopupData));
                        messageList.add(message);
                    }

                    if (trackPoint != null) {
                        String bakStr;

                        double bakTotal = getBakTotalValue(trackPoint, hasBak);

                        if (bakTotal > 0) {
                            validBakTotal = bakTotal;
                        }

                        if (hasBak) {
                            bakStr = Double.toString(validBakTotal);
                        } else {
                            bakStr = "null";
                        }

                        chartData.add(getChartDataByTrackPoint(trackPoint, bakStr));
                    }
                }

                modelAndView.addObject("messageList", messageList);

                if (limit > 0) {
                    addPaginationData(modelAndView, pageId, tracksCount.intValue(), URL_MAP_OBJECT_TRACKS_TABLE, limit);
                }

                modelAndView.addObject("contractSettings", contractSettings);
                modelAndView.addObject("chartData", chartData);
            }
        }

        return modelAndView;
    }

    protected Object getXLSService(HttpServletResponse response, HttpServletRequest request, Long mObjectId, String startDate, String endDate, Integer pointCount) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("Received request to download report as an XLS");
            logger.debug("Build tracks table for parameters: object-id={}, start-date={}, end-date={}, point-count={}",
                    mObjectId, startDate, endDate, pointCount);
        }
        Cookie[] cookies = request.getCookies();
        long reportToken = 0L;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("fileDownloadToken")) {
                    reportToken = Long.parseLong(cookie.getValue());
                }
            }
        }

        return getXLSWithoutSession(coreMain, settingsService, excelDownloadTrackData, response, mObjectId, startDate, endDate, pointCount, reportToken);
    }

    public Object getXLSWithoutSession(
            CoreMain coreMain,
            SettingsService settingsService,
            ExcelDownloadTrackData excelDownloadTrackData,
            HttpServletResponse response,
            Long mObjectId,
            String startDate,
            String endDate,
            Integer pointCount,
            long reportToken) throws Exception {

        if (mObjectId != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            Date fromDate;
            Date toDate;

            try {
                fromDate = dateFormat.parse(startDate);
                toDate = dateFormat.parse(endDate);
            } catch (ParseException e) {
                fromDate = null;
                toDate = null;
                e.printStackTrace();
            }

            if (fromDate != null && toDate != null) {
                GPSTrackPointList gpsTrackPointList =
                        coreMain.getPointsByDate(mObjectId, new Timestamp(fromDate.getTime()).getTime(), new Timestamp(toDate.getTime()).getTime(), pointCount);
                MobjectBig mObject = coreMain.getMobjectById(mObjectId);

                ContractSettings contractSettings = settingsService.getContractSettingsByContractId(mObject.getContractId());

                List<Message> messageList = new ArrayList<>();

                if (gpsTrackPointList.getGpsTrackPoints() != null && gpsTrackPointList.getGpsTrackPoints().size() > 0) {
                    List<GPSTrackPoint> trackPointList = gpsTrackPointList.getGpsTrackPoints();

                    for (int i = trackPointList.size() - 1; i >= 0; i--) {
                        GPSTrackPoint trackPoint = trackPointList.get(i);
                        Message message = new Message(trackPoint);
                        messageList.add(message);
                    }
                }

                excelDownloadTrackData.setDbList(messageList);
                excelDownloadTrackData.setMobjectBig(mObject);
                excelDownloadTrackData.setDateInterval(fromDate, toDate);
                excelDownloadTrackData.setContractSettings(contractSettings);
                excelDownloadTrackData.setToken(reportToken);
                excelDownloadTrackData.downloadXLS(response);
            }
        }
        return response;
    }

    protected ModelAndView getTrackPointsCountByPeriodService(Long mObjectId, String startDate, String endDate) {
        if (mObjectId != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            Date fromDate = null;
            Date toDate = null;

            try {
                toDate = dateFormat.parse(endDate);
                fromDate = dateFormat.parse(startDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (fromDate != null && toDate != null) {
                Long pointsCount = coreMain.getPointsCountByDate(mObjectId, new Timestamp(fromDate.getTime()).getTime(), new Timestamp
                        (toDate.getTime()).getTime());

                if (pointsCount > EXCEL_TRACK_POINTS_DOWNLOAD_LIMIT) {
                    return new ModelAndView(VIEW_MAX_TRACKS_LIMIT_MESSAGE);
                } else if (pointsCount == 0L) {
                    return new ModelAndView(VIEW_NO_TRACKS_MESSAGE);
                } else {
                    return null;
                }
            }
        }

        return null;
    }

    protected Boolean getTrackPointsCountByPeriodRestService(Long mObjectId, String startDate, String endDate) {
        if (mObjectId != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            Date fromDate = null;
            Date toDate = null;

            try {
                toDate = dateFormat.parse(endDate);
                fromDate = dateFormat.parse(startDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (fromDate != null && toDate != null) {
                Long pointsCount = coreMain.getPointsCountByDate(mObjectId, new Timestamp(fromDate.getTime()).getTime(), new Timestamp
                        (toDate.getTime()).getTime());

                if (pointsCount > EXCEL_TRACK_POINTS_DOWNLOAD_LIMIT) {
                    return Boolean.TRUE;
                } else if (pointsCount == 0L) {
                    return Boolean.FALSE;
                } else {
                    return null;
                }
            }
        }

        return null;
    }

    protected KMLObjectTrack getMovableObjectReducesService(Long mObjectId, String startDate, String endDate, String color, Integer lineWidth, Integer epsilon) {
        if (logger.isDebugEnabled()) {
            logger.debug("Build tracks for parameters: object-id={}, start-date={}, end-date={}, epsilon={}",
                    mObjectId, startDate, endDate, epsilon);
        }

        KMLObjectTrack kmlObjectTrack = null;

        try {
            if (mObjectId != null) {
//                int trackViewType = Converters.strToInt(trackViewTypeStr, 1);
                int trackViewType = UZGPS_CONST.TRACK_VIEW_TYPE.ALL.getValue();

                GPSTrackPointList gpsTrackPointList = getGpsTrackPointList(mObjectId, 0, startDate, endDate);
                MobjectBig mobject = coreMain.getMobjectById(mObjectId);

                if (gpsTrackPointList != null) {
                    // Clear NULL and ZERO coordinates - Delete ZERO points
                    coreMain.deleteZeroPoints(gpsTrackPointList);

                    List<GPSTrackPoint> gpsTrackPoints = gpsTrackPointList.getGpsTrackPoints();
                    List<GPSTrackPoint> reducedGpsTrackPoints = DouglasPeuckerReducer.reduceWithTolerance(gpsTrackPointList.getGpsTrackPoints(), epsilon);
                    gpsTrackPointList.setGpsTrackPoints(reducedGpsTrackPoints);

                    if (logger.isDebugEnabled()) {
                        logger.debug("GPSTrackPoint count after DouglasPeuckerReducer: {}",
                                gpsTrackPointList.getGpsTrackPoints().size());
                    }

                    Timestamp startDateT = null;
                    Timestamp endDateT = null;
                    if (!startDate.equalsIgnoreCase("")) {
                        startDate = startDate.trim();
                        startDateT = Converters.dateFormatterTimestamp(startDate);
                    }

                    if (!endDate.equalsIgnoreCase("")) {
                        endDate = endDate.trim();
                        endDateT = Converters.dateFormatterTimestamp(endDate);
                    }

                    List<CustomDistancesForTracking> distancesList = adminService.getDistanceByObjectAndPeriod(mObjectId, startDateT, endDateT);

                    if (distancesList != null) {
                        List<KMLExtraDataEvent> kmlExtraDataEvents = new ArrayList<>();

                        kmlObjectTrack = new KMLObjectTrack(mobject, gpsTrackPointList, null, "solid", color,
                                lineWidth, reducedGpsTrackPoints.size(), distancesList, trackViewType, kmlExtraDataEvents);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Error in getMovableObjectReduces", e);
        }

        return kmlObjectTrack;
    }

    private TrackPopupData makeParkingSosPoint(GPSTrackPoint trackPoint) {
        if (trackPoint == null)
            return null;

        TrackPopupData parkingPoint = new TrackPopupData();
        parkingPoint.setLat(trackPoint.getLatitude());
        parkingPoint.setLon(trackPoint.getLongitude());
        parkingPoint.setTimestamp(trackPoint.getDate().getTime());
        parkingPoint.setTpRegDate(trackPoint.getRegDate().getTime());
        parkingPoint.setParkingFromDate(trackPoint.getDate());
        parkingPoint.setParkingToDate(null);

        return parkingPoint;
    }

    /**
     * Collect sos pin points
     *
     * @param session
     * @param mObjectId
     * @param trackPointList
     * @return
     */
    private List<TrackPopupData> getSosPins(HttpSession session, Long mObjectId, List<GPSTrackPoint> trackPointList) {
        if (trackPointList == null || trackPointList.size() == 0) {
            return null;
        }

        MobjectBig mobjectBig = coreMain.getMobjectById(mObjectId);
        List<TrackPopupData> sosPins = new ArrayList<>();

        for (int i = trackPointList.size() - 1; i >= 0; i--) {
            GPSTrackPoint trackPoint = trackPointList.get(i);

            // Check id sos button pressed
            if (trackPoint.getSosStatus() == 1) {
                TrackPopupData trackPopupData = makeParkingSosPoint(trackPoint);
                trackPopupData.setGPSTrackPoint(trackPoint);
                trackPopupData.setMobjectBig(mobjectBig);
                sosPins.add(trackPopupData);
            }
        }

        return sosPins;
    }

    protected void getTrackPointsPinsService(HttpSession session, HttpServletResponse response, Long mObjectId, String startDate, String endDate, Integer pointsCount) throws JsonProcessingException {
        if (logger.isDebugEnabled()) {
            logger.debug("Build tracks for parameters: object-id={}, start-date={}, end-date={}, points-count={}",
                    mObjectId, startDate, endDate, pointsCount);
        }

        GPSTrackPointList gpsTrackPointList = getGpsTrackPointList(mObjectId, pointsCount, startDate, endDate);
        ResponsePins responsePins = new ResponsePins();

        if (gpsTrackPointList != null && gpsTrackPointList.size() > 0) {
            MobjectBig mobjectBig = coreMain.getMobjectById(mObjectId);

            List<GPSTrackPoint> trackPointList = gpsTrackPointList.getGpsTrackPoints();

            ParkingHelper parkingHelper = new ParkingHelper();
            MObjectSettings mObjectSettings = (MObjectSettings) session.getAttribute(SESSION_OBJECT_SETTINGS + mObjectId);

            if (mObjectSettings == null) {
                mObjectSettings = settingsService.getObjectSettingsByObjectId(mObjectId);

                if (mObjectSettings != null) {
                    session.setAttribute(SESSION_OBJECT_SETTINGS + mObjectId, mObjectSettings);
                }
            }

            long parkingTime = UZGPS_CONST.MIN_PARKING_TIME_DEFAULT;
            if (mObjectSettings != null && mObjectSettings.getParkingTime() != null) {
                parkingTime = mObjectSettings.getParkingTime() * 1000;
            }

            CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
            TripRunnerService tripRunnerService = null;
            if (tripRoutingControl != null) {
                tripRunnerService = tripRoutingControl.getTripRunnerService();
            }

            List<TrackPopupData> parkingPins = parkingHelper.getParkingPinsForTracking(session, mobjectBig, parkingTime, tripRunnerService, trackPointList);

            List<TrackPopupData> sosPins = getSosPins(session, mObjectId, trackPointList);

            ContractSettings contractSettings = mainController.getContractSettings(session);

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.parkingPopupIgnoredFieldNames(contractSettings)));
            ObjectWriter objectWriter = jsonMapper.writer(filterProvider);

            responsePins.setParkingPins(objectWriter.writeValueAsString(parkingPins));

            filterProvider.removeFilter("TrackPopupDataFilter");
            filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.sosPopupIgnoredFieldNames(contractSettings)));

            responsePins.setSosPins(objectWriter.writeValueAsString(sosPins));
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responsePins);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error in getTrackPointsPins", e);
        }
    }

    protected Object getTrackPointsPinsRestService(HttpSession session, HttpServletResponse response, Long mObjectId, String startDate, String endDate, Integer pointsCount) throws JsonProcessingException {
        if (logger.isDebugEnabled()) {
            logger.debug("Build tracks for parameters: object-id={}, start-date={}, end-date={}, points-count={}",
                    mObjectId, startDate, endDate, pointsCount);
        }

        GPSTrackPointList gpsTrackPointList = getGpsTrackPointList(mObjectId, pointsCount, startDate, endDate);
        ResponsePins responsePins = new ResponsePins();

        if (gpsTrackPointList != null && gpsTrackPointList.size() > 0) {
            MobjectBig mobjectBig = coreMain.getMobjectById(mObjectId);

            List<GPSTrackPoint> trackPointList = gpsTrackPointList.getGpsTrackPoints();

            ParkingHelper parkingHelper = new ParkingHelper();
            MObjectSettings mObjectSettings = (MObjectSettings) session.getAttribute(SESSION_OBJECT_SETTINGS + mObjectId);

            if (mObjectSettings == null) {
                mObjectSettings = settingsService.getObjectSettingsByObjectId(mObjectId);

                if (mObjectSettings != null) {
                    session.setAttribute(SESSION_OBJECT_SETTINGS + mObjectId, mObjectSettings);
                }
            }

            long parkingTime = UZGPS_CONST.MIN_PARKING_TIME_DEFAULT;
            if (mObjectSettings != null && mObjectSettings.getParkingTime() != null) {
                parkingTime = mObjectSettings.getParkingTime() * 1000;
            }

            CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
            TripRunnerService tripRunnerService = null;
            if (tripRoutingControl != null) {
                tripRunnerService = tripRoutingControl.getTripRunnerService();
            }

            List<TrackPopupData> parkingPins = parkingHelper.getParkingPinsForTracking(session, mobjectBig, parkingTime, tripRunnerService, trackPointList);

            List<TrackPopupData> sosPins = getSosPins(session, mObjectId, trackPointList);

            ContractSettings contractSettings = mainController.getContractSettings(session);

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.parkingPopupIgnoredFieldNames(contractSettings)));
            ObjectWriter objectWriter = jsonMapper.writer(filterProvider);

            responsePins.setParkingPins(objectWriter.writeValueAsString(parkingPins));

            filterProvider.removeFilter("TrackPopupDataFilter");
            filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.sosPopupIgnoredFieldNames(contractSettings)));

            responsePins.setSosPins(objectWriter.writeValueAsString(sosPins));
        }

        return responsePins;
    }

    protected void getNearestTrackPointService(HttpSession session, HttpServletResponse response, Long mObjectId, String startDateStr, String endDateStr, Double latitude, Double longitude, Double radius) throws JsonProcessingException {
        if (logger.isDebugEnabled()) {
            logger.debug("Get nearest track point for parameters: object-id={}, start-date={}, end-date={}, radius={}, latitude={}, longitude={}",
                    mObjectId, startDateStr, endDateStr, radius, latitude, longitude);
        }

//        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");

        long startDate = Converters.strToLong(startDateStr, 0L);
        long endDate = Converters.strToLong(endDateStr, 0L);

        if (mObjectId != null && startDate > 0 && endDate > 0) {

            GPSTrackPoint gpsTrackPoint = coreMain.getPointInRadius(mObjectId, startDate, endDate, latitude, longitude, radius);

            if (gpsTrackPoint != null) {
//                Map<String, Object> mapModels = new HashMap<>();
                ContractSettings contractSettings = mainController.getContractSettings(session);

                MobjectBig mObject = coreMain.getMobjectById(mObjectId);
                SimpleFilterProvider filterProvider = new SimpleFilterProvider();
                filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.trackPopupIgnoredFieldNames(contractSettings)));
//                    filterProvider.addFilter("PopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorablePopupFieldNames));
                ObjectWriter objectWriter = jsonMapper.writer(filterProvider).withRootName("data");

                // Preparing popup data for mobject
                TrackPopupData trackPopupData = new TrackPopupData();
                trackPopupData.setGPSTrackPoint(gpsTrackPoint);
                trackPopupData.setMobjectBig(mObject);

                // Collect mobject in Poi
                CorePoi corePoi = CorePoi.getInstance();
                // Collect mobject in Geofence
                CoreGeofence coreGeofence = CoreGeofence.getInstance();

                List<Poi> poiList = null;
                List<Geofence> geofenceList = null;

                if (corePoi != null) {
                    corePoi.loadMobjectsInPoi();
                    poiList = corePoi.getPoiWithMobjectInside(mObjectId);
                }

                if (coreGeofence != null) {
                    coreGeofence.loadMobjectsInGeofence();
                    geofenceList = coreGeofence.getGeofencesWithMobjectInside(mObjectId);
                }

                trackPopupData.setPoiAndGeoFenceList(poiList, geofenceList);
                trackPopupData.setAssignedRoutes(monitoringController.getAssignedTripNamesToMobject(mObject.getId()));

                Message message = new Message(gpsTrackPoint);
                message.setJson(objectWriter.writeValueAsString(trackPopupData));

                try {
                    // Make json response
                    ResponseNearestPoint responseNearestPoint = new ResponseNearestPoint();

                    responseNearestPoint.setTimestamp(gpsTrackPoint.getTimestamp());
                    responseNearestPoint.setRegDate(gpsTrackPoint.getRegDateLong());
                    responseNearestPoint.setParsingDate(gpsTrackPoint.getParsingDate().getTime());

                    responseNearestPoint.setMovement(gpsTrackPoint.getMovement());
                    responseNearestPoint.setEngineOn(gpsTrackPoint.getEngineOn());
                    responseNearestPoint.setOnline(gpsTrackPoint.getOnline());
                    responseNearestPoint.setSatellites(gpsTrackPoint.getSatellites());
                    responseNearestPoint.setDat(gpsTrackPoint.getDat());
                    responseNearestPoint.setSpeed(gpsTrackPoint.getSpeed());

                    ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
                    byte[] data = writer.writeValueAsBytes(trackPopupData);
                    response.setContentType("application/json");
                    response.setContentLength(data.length);

                    // Write in output stream
                    ServletOutputStream outStream = response.getOutputStream();
                    outStream.write(data);
                    outStream.close();
                    outStream.flush();
                } catch (Exception e) {
                    logger.error("Error: ", e);
                }
            }
        } else {
            try {
                ObjectWriter writer = jsonMapper.writer().withRootName("data");
                byte[] data = writer.writeValueAsBytes(null);
                response.setContentType("application/json");
                response.setContentLength(data.length);

                // Write in output stream
                ServletOutputStream outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
                outStream.flush();
            } catch (Exception e) {
                logger.error("Error: ", e);
            }
        }
    }

    protected Object getNearestTrackPointRestService(HttpSession session, HttpServletResponse response, Long mObjectId, String startDateStr, String endDateStr, Double latitude, Double longitude, Double radius) throws JsonProcessingException {
        if (logger.isDebugEnabled()) {
            logger.debug("Get nearest track point for parameters: object-id={}, start-date={}, end-date={}, radius={}, latitude={}, longitude={}",
                    mObjectId, startDateStr, endDateStr, radius, latitude, longitude);
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");

        long startDate = Converters.strToLong(startDateStr, 0L);
        long endDate = Converters.strToLong(endDateStr, 0L);

        if (mObjectId != null && startDate > 0 && endDate > 0) {

            GPSTrackPoint gpsTrackPoint = coreMain.getPointInRadius(mObjectId, startDate, endDate, latitude, longitude, null);

            if (gpsTrackPoint != null) {
//                Map<String, Object> mapModels = new HashMap<>();
                ContractSettings contractSettings = mainController.getContractSettings(session);

                MobjectBig mObject = coreMain.getMobjectById(mObjectId);
                SimpleFilterProvider filterProvider = new SimpleFilterProvider();
                filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.trackPopupIgnoredFieldNames(contractSettings)));
//                    filterProvider.addFilter("PopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorablePopupFieldNames));
                ObjectWriter objectWriter = jsonMapper.writer(filterProvider).withRootName("data");

                // Preparing popup data for mobject
                TrackPopupData trackPopupData = new TrackPopupData();
                trackPopupData.setGPSTrackPoint(gpsTrackPoint);
                trackPopupData.setMobjectBig(mObject);

                // Collect mobject in Poi
                CorePoi corePoi = CorePoi.getInstance();
                // Collect mobject in Geofence
                CoreGeofence coreGeofence = CoreGeofence.getInstance();

                List<Poi> poiList = null;
                List<Geofence> geofenceList = null;

                if (corePoi != null) {
                    corePoi.loadMobjectsInPoi();
                    poiList = corePoi.getPoiWithMobjectInside(mObjectId);
                }

                if (coreGeofence != null) {
                    coreGeofence.loadMobjectsInGeofence();
                    geofenceList = coreGeofence.getGeofencesWithMobjectInside(mObjectId);
                }

                trackPopupData.setPoiAndGeoFenceList(poiList, geofenceList);
                trackPopupData.setAssignedRoutes(monitoringController.getAssignedTripNamesToMobject(mObject.getId()));

                Message message = new Message(gpsTrackPoint);
                message.setJson(objectWriter.writeValueAsString(trackPopupData));

                return trackPopupData;
            }
        }
        return null;
    }
}
