package uzgps.rest;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreMobjectBig;
import uz.netex.core.helper.CoreMobjectStaff;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectTracks;
import uz.netex.dbtables.Staff;
import uzgps.admin.ApiService;
import uzgps.common.FileStorageService;
import uzgps.common.GrpUtils;
import uzgps.persistence.FileStorage;
import uzgps.persistence.api.MObjectExtendedWithPhotoData;
import uzgps.rest.dto.ExtendedMobjectDataDTO;
import uzgps.rest.dto.azs.MobjectsSimple;
import uzgps.rest.security.JWTProvider;
import uzgps.settings.SettingsService;

import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stanislav on 29.04.2022 15:40
 */
@SuppressWarnings({"SingleStatementInBlock", "DuplicatedCode"})
@RestController
@RequestMapping("/internal/")
public class UzgpsApiServiceRest extends BaseRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    protected CoreMain coreMain;

    @Autowired
    private FileStorageService storageService;

    @Autowired
    protected ApiService apiService;

    @Autowired
    protected SettingsService settingsService;

    private static final String MOBJECT_EXTENDED_DATA_URL = "getMobjectsExtendedData";
    private static final String FMS_CONTRACTS_URL = "fmsContracts";
    private static final String FMS_USER_MOBJECT_TP_URL = "getUserMobjectTp";
    private static final String USER_MOBJECTS_URL = "getUserMobjects";

    private static final String MOBJECTS_BY_CONTRACT_URL = "getMobjectsByContractId";

    /**
     * Return mobject extended data
     *
     * @param token Bearer token for external services
     * @return JsonObject
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = MOBJECT_EXTENDED_DATA_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectExtendedData(HttpSession session,
                                                    @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token) {
        try {
            logger.info("getMobjectExtendedData start");

            final String TOKEN_SUBJECT_STAFF = "staff";

            token = formatToken(token);
            boolean isAuthenticate = JWTProvider.isTokenValidExt(token, TOKEN_SUBJECT_STAFF);

            if (isAuthenticate) {
                List<MObjectExtendedWithPhotoData> mobjectExtendedData = apiService.getMobjectExtendedData();

                Timestamp currentDate = new Timestamp(System.currentTimeMillis());

                List<ExtendedMobjectDataDTO> extendedMobjectDataList = new ArrayList<>();

                for (MObjectExtendedWithPhotoData med : mobjectExtendedData) {
                    Staff staffCore = CoreMobjectStaff.getInstance().getStaffByMobjectId(med.getMobjectId(), currentDate);

                    if (staffCore != null) {
                        uzgps.persistence.Staff staff = settingsService.getStaffById(staffCore.getId());
                        ExtendedMobjectDataDTO extendedMobjectDataDTO = new ExtendedMobjectDataDTO();

                        try {
                            extendedMobjectDataDTO.setId(med.getId());
                            extendedMobjectDataDTO.setMobjectId(med.getMobjectId());
                            extendedMobjectDataDTO.setStaffId(med.getStaffId());

                            extendedMobjectDataDTO.setStaffFirstName(staffCore.getName());
                            extendedMobjectDataDTO.setStaffLastName(staffCore.getSurName());
                            extendedMobjectDataDTO.setStaffPatronymic(staffCore.getMiddleName());
                            extendedMobjectDataDTO.setStaffPosition(staffCore.getPosition());

                            extendedMobjectDataDTO.setStaffPhoneMobile(staffCore.getPhoneMobile());
                            extendedMobjectDataDTO.setStaffPhoneLine(staffCore.getPhoneLine());

                            if (staff.getCatalogCompany() != null) {
                                extendedMobjectDataDTO.setStaffCompanyName(staff.getCatalogCompany().getName());
                            }

                            if (staff.getCatalogCompany() != null && staff.getCatalogSubdivision() != null) {
                                extendedMobjectDataDTO.setStaffSubdivisionName(staff.getCatalogSubdivision().getName());
                            }

                        } catch (Exception e) {
                            logger.error("Error in getMobjectExtendedData", e);
                        }

                        FileStorage staffPhoto = storageService.getFileStorage(staffCore.getPhotoId());
                        if (staffPhoto != null) {
                            extendedMobjectDataDTO.setStaffPhotoId(staffPhoto.getId());
                            extendedMobjectDataDTO.setStaffPhotoFilename(staffPhoto.getFilename());
                            extendedMobjectDataDTO.setStaffPhotoContentType(staffPhoto.getContentType());
                            extendedMobjectDataDTO.setStaffPhotoSize(staffPhoto.getSize());

                            byte[] staffPhotoData = getPhotoData(staffPhoto);
//                            extendedMobjectDataDTO.setStaffPhotoDataBytea(staffPhotoData);
                            extendedMobjectDataDTO.setStaffPhotoDataBase64(Base64.encodeBase64String(staffPhotoData));

//                            if (staffPhoto.getId().equals(med.getStaffPhotoId()) || med.getStaffPhotoId()) {
                            if (med.getStaffPhotoSize() != null && staffPhoto.getSize() == med.getStaffPhotoSize()) {
                                extendedMobjectDataDTO.setNeedUpdatePhoto(false);
                            } else {
                                extendedMobjectDataDTO.setNeedUpdatePhoto(true);
                            }
                        } else if (med.getStaffPhotoId() != null) {
                            extendedMobjectDataDTO.setNeedUpdatePhoto(true);
                        }

                        extendedMobjectDataList.add(extendedMobjectDataDTO);
                    }
                }

                logger.info("getMobjectExtendedData end, size: " + extendedMobjectDataList.size());

                return ResponseUtil.respondSuccess(extendedMobjectDataList);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }

        } catch (Exception e) {
            logger.error("Error in getMobjectExtendedData", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    private byte[] getPhotoData(FileStorage staffPhoto) {
        try {
            String outFilename = storageService.getFilePath(staffPhoto, false) + staffPhoto.getId();
            File outFile = new File(outFilename);
            byte[] data = GrpUtils.getBytesFromFile(outFile);
            return data;
        } catch (IOException e) {
            logger.error("Error in getPhotoData", e);
        }
        return null;
    }

    @RequestMapping(value = FMS_CONTRACTS_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getFmsContracts(HttpSession session,
                                             @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token) {
        try {
            final String TOKEN_SUBJECT_STAFF = "fms";

            token = formatToken(token);
            boolean isAuthenticate = JWTProvider.isTokenValidExt(token, TOKEN_SUBJECT_STAFF);

            if (isAuthenticate) {
                List<Long> fmsContracts = adminService.getFmsContracts();

                return ResponseUtil.respondSuccess(fmsContracts);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getFmsContracts", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    @RequestMapping(value = MOBJECTS_BY_CONTRACT_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectsByContractId(HttpSession session,
                                                     @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                     @RequestParam(required = true, value = "contract-id") Long contractId) {
        try {
            final String TOKEN_SUBJECT_STAFF = "azs";

            token = formatToken(token);
            boolean isAuthenticate = JWTProvider.isTokenValidExt(token, TOKEN_SUBJECT_STAFF);

            if (isAuthenticate) {
                List<MobjectBig> mobjects = CoreMobjectBig.getInstance().getByContract(contractId);
//            JsonArray mobjectsSimple = new JsonArray();
//            for (MobjectBig mobject : mobjects) {
//                JsonObject mobjectSimple = new JsonObject();
//                mobjectSimple.put("name", mobject.getName());
//                mobjectSimple.put("plateNumber", mobject.getPlateNumber());
//                mobjectsSimple.add(mobjectSimple);
//            }
                List<MobjectsSimple> mobjectsSimple = new ArrayList<>();
                for (MobjectBig mobject : mobjects) {
                    MobjectsSimple mobjectSimple = new MobjectsSimple();
                    mobjectSimple.setId(mobject.getId());
                    mobjectSimple.setContractId(mobject.getContractId());
                    mobjectSimple.setName(mobject.getPlateNumber());
                    mobjectSimple.setPlateNumber(mobject.getPlateNumber());
                    mobjectsSimple.add(mobjectSimple);
                }

                return ResponseUtil.respondSuccess(mobjectsSimple);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getMobjectsByContractId", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }

    @RequestMapping(value = FMS_USER_MOBJECT_TP_URL,
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getUserMobjectTrack(HttpSession session,
                                                 @RequestHeader(required = false, value = HttpHeaders.AUTHORIZATION) String token,
                                                 @RequestParam(required = true, value = "user-id") Long userId) {
        try {
            final String TOKEN_SUBJECT_STAFF = "fms";

            token = formatToken(token);
            boolean isAuthenticate = JWTProvider.isTokenValidExt(token, TOKEN_SUBJECT_STAFF);

            if (isAuthenticate) {

//                List<MobjectTracks> mObjectTracksList;

//                if (UZGPS_CONST.USER_ROLE_USER == user.getRoleId()) {
//                    mObjectTracksList = coreMain.getMobjectTracksListByUser(user.getId(), 0L);
//                } else if (UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN == user.getRoleId()) {
//                    mObjectTracksList = coreMain.getMobjectTracksListByContract(contractId, 0L);
//                }
//
//                return ResponseUtil.respondSuccess(fmsContracts);
                return null;
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in getFmsContracts", e);
            return ResponseUtil.respondError(e.getCause());
        }
    }


}
