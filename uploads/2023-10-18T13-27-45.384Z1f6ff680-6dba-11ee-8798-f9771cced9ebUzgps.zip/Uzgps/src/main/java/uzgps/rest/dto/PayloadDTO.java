package uzgps.rest.dto;

/**
 * Created by Stanislav on 31.07.2017 16:40
 */
public class PayloadDTO {

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "ItemDTO{" +
                "token='" + token + '\'' +
                '}';
    }
}
