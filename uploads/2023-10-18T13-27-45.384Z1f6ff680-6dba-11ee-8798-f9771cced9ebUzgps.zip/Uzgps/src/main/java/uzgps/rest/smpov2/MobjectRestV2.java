package uzgps.rest.smpov2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.core.helper.CorePoi;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectInPoiGeofence;
import uz.netex.datatype.MobjectTracks;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Poi;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.models.MobjectBigZoned;
import uzgps.map.models.MonitorData;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.User;
import uzgps.rest.BaseRest;
import uzgps.rest.ResponseUtil;
import uzgps.rest.dto.GroupedMobjectDTO;
import uzgps.rest.dto.ZonedMobjectDTO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Created by Stanislav on 15.06.2022 10:05
 */
@SuppressWarnings("SingleStatementInBlock")
@RestController
@RequestMapping("/v2/mobject-management/")
public class MobjectRestV2 extends BaseRest {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    MainController mainController;

    private static final String ALL_MOBJECTS = "all-mobjects";
    public static final String GROUPED_MOBJECTS = "grouped";
    public static final String ZONED_MOBJECTS = "zoned";


    /**
     * Return user mobjects
     *
     * @param request HttpServletRequest
     * @return List
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/mobject",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjects(HttpSession session,
                                         HttpServletRequest request) {
        try {
            User user = MainController.getUser();

            if (!isAuthenticateByUser(user)) {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
            List<MobjectBig> mobjects = monitoringController.getMobjects(session, true);
            return ResponseUtil.respondSuccess(mobjects);
        } catch (Exception e) {
            logger.error("Error in MobjectRestv2 rest - getMobjects: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }


    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/grouped-mobject",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getGroupedMobjects(HttpSession session,
                                                HttpServletRequest request) {
        try {
            User user = MainController.getUser();

            if (!isAuthenticateByUser(user)) {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
            List<MobjectBig> mobjectList = monitoringController.getMobjects(session, true);
            Map<Long, GroupedMobjectDTO> groupedMObjectList = new HashMap<>();

            if (mobjectList != null && mobjectList.size() > 0) {

                for (MobjectBig mObject : mobjectList) {
                    if (groupedMObjectList.containsKey(mObject.getGroupId())) {
                        GroupedMobjectDTO groupedMobjectDTO = groupedMObjectList.get(mObject.getGroupId());
                        groupedMobjectDTO.getMobjectList().add(mObject);
                    } else {
                        GroupedMobjectDTO groupedMobjectDTO = new GroupedMobjectDTO();
                        List<MobjectBig> mobjects = new ArrayList<>();
                        mobjects.add(mObject);

                        groupedMobjectDTO.setGroupId(mObject.getGroupId());
                        groupedMobjectDTO.setGroupName(mObject.getGroupName());
                        groupedMobjectDTO.setMobjectList(mobjects);

                        groupedMObjectList.put(mObject.getGroupId(), groupedMobjectDTO);
                    }
                }
            }

            return ResponseUtil.respondSuccess(groupedMObjectList.values());
        } catch (Exception e) {
            logger.error("Error in MobjectRestv2 rest - getMobjects: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/zoned-mobject",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getZonedMobjects(HttpSession session,
                                              HttpServletRequest request) {
        try {
            User user = MainController.getUser();

            if (!isAuthenticateByUser(user)) {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }

            List<ZonedMobjectDTO> zonedMobjectList = getZonedMobjectList(session);

            return ResponseUtil.respondSuccess(zonedMobjectList);
        } catch (Exception e) {
            logger.error("Error in MobjectRestv2 rest - getMobjects: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    /**
     * Return user mobject by id
     *
     * @param request HttpServletRequest
     * @return List
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/mobject/{id}",
            produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getMobjectById(@PathVariable Long id) {
        try {
            User user = MainController.getUser();

            if (isAuthenticateByUser(user)) {
                MobjectBig mobject = coreMain.getMobjectById(id);
                return ResponseUtil.respondSuccess(mobject);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            logger.error("Error in MobjectRestv2 - getMobjectById: " + e.getMessage());
        }

        return ResponseUtil.respondSuccess(new ArrayList<>());
    }

    public List<ZonedMobjectDTO> getZonedMobjectList(HttpSession session) {

        List<ZonedMobjectDTO> zonedMobjectDTOList = new ArrayList<>();
        List<MobjectTracks> mObjectTracksList = monitoringController.getMobjectTracksList(session);

        List<MobjectBig> mObjectList = new ArrayList<>();
        Set<MobjectBig> mobjectInZoneList = new HashSet<>();
        TreeSet<MobjectBig> mobjectOutZoneList = new TreeSet<>();

        for (MobjectTracks mobjectTracks : mObjectTracksList) {

            MobjectBig mobject = mobjectTracks.getMobject();

            mObjectList.add(mobject);
            mobjectOutZoneList.add(mobject);
        }

        // Collect mobject in Poi
        CorePoi corePoi = CorePoi.getInstance();
        // Collect mobject in Geofence
        CoreGeofence coreGeofence = CoreGeofence.getInstance();

        Map<Long, List<MobjectBig>> poiMobjectList = new HashMap<>();
        Map<Long, List<MobjectBig>> geofenceMobjectList = new HashMap<>();
        List<Poi> poiList = new ArrayList<>();
        List<Geofence> geofenceList = new ArrayList<>();

        // Collect mobject in Poi
        if (corePoi != null) {
            poiList = monitoringController.getPoiList(corePoi, session);

            poiMobjectList =
                    getMobjectListInPoiList(
                            corePoi,
                            poiList,
                            mObjectList,
                            mobjectInZoneList,
                            mobjectOutZoneList);

        }

        // Collect mobject in Geofence
        if (coreGeofence != null) {
            geofenceList = monitoringController.getGeofenceList(coreGeofence, session);

            geofenceMobjectList =
                    getMobjectListInGeofenceList(
                            coreGeofence,
                            geofenceList,
                            mObjectList,
                            mobjectInZoneList,
                            mobjectOutZoneList);
        }


        ZonedMobjectDTO zoneOutMobjectDTO = new ZonedMobjectDTO();
        zoneOutMobjectDTO.setZoneId(0L);
        zoneOutMobjectDTO.setZoneName("Вне зон");
        zoneOutMobjectDTO.setMobjectBigList(new ArrayList<>(mobjectOutZoneList));

        zonedMobjectDTOList.add(zoneOutMobjectDTO);

        if (poiList != null && poiList.size() > 0){
            for (Poi poi : poiList) {
                ZonedMobjectDTO zonedMobjectDTO = new ZonedMobjectDTO();

                zonedMobjectDTO.setZoneId(poi.getId());
                zonedMobjectDTO.setZoneName(poi.getName());
                zonedMobjectDTO.setZoneType("P");
                zonedMobjectDTO.setMobjectBigList(poiMobjectList.get(poi.getId()));

                zonedMobjectDTOList.add(zonedMobjectDTO);
            }
        }

        if (geofenceList != null && geofenceList.size() > 0){
            for (Geofence geofence : geofenceList) {
                ZonedMobjectDTO zonedMobjectDTO = new ZonedMobjectDTO();

                zonedMobjectDTO.setZoneId(geofence.getId());
                zonedMobjectDTO.setZoneName(geofence.getName());
                zonedMobjectDTO.setZoneType("P");
                zonedMobjectDTO.setMobjectBigList(geofenceMobjectList.get(geofence.getId()));

                zonedMobjectDTOList.add(zonedMobjectDTO);
            }
        }
        return zonedMobjectDTOList;
    }

    private Map<Long, List<MobjectBig>> getMobjectListInPoiList(
            CorePoi corePoi,
            List<Poi> poiList,
            List<MobjectBig> mobjectList,
            Set<MobjectBig> mobjectInZoneList,
            TreeSet<MobjectBig> mobjectOutZoneList) {

        Map<Long, List<MobjectBig>> poiMobjectListMap = new HashMap<>();
        List<MobjectBig> foundMobjectsInPoi;

        if (poiList != null && !poiList.isEmpty()
                && mobjectList != null && !mobjectList.isEmpty()
                && mobjectInZoneList != null) {

            // Get all poi IDs and Mobject IDs, where Mobject is inside Poi
            Map<Long, List<MobjectInPoiGeofence>> mapByPoiForMobjectInPoi = null;
            if (corePoi != null) {
                corePoi.loadMobjectsInPoi();
                mapByPoiForMobjectInPoi = corePoi.getMapByPoiForMobjectInPoi();
            }

            // If there is some Mobjects inside Poi, use them
            if (mapByPoiForMobjectInPoi != null) {
                for (Poi poi : poiList) {
                    foundMobjectsInPoi = new ArrayList<>();

                    List<MobjectInPoiGeofence> mobjectsInPoi = mapByPoiForMobjectInPoi.get(poi.getId());

                    if (mobjectsInPoi != null) {

                        for (MobjectInPoiGeofence mobjectInPoi : mobjectsInPoi) {

                            MobjectBig mobz = mobjectList.stream().filter(o -> o.getId().equals(mobjectInPoi.getMobjectId())).findFirst().orElse(null);

                            if (mobz != null) {
                                foundMobjectsInPoi.add(mobz);
                                mobjectOutZoneList.remove(mobz);
                            }

                        }
                    }

                    poiMobjectListMap.put(poi.getId(), foundMobjectsInPoi);
                }
            }
        }

        return poiMobjectListMap;
    }

    private Map<Long, List<MobjectBig>> getMobjectListInGeofenceList(
            CoreGeofence coreGeofence,
            List<Geofence> geofenceList,
            List<MobjectBig> mobjectList,
            Set<MobjectBig> mobjectInZoneList,
            TreeSet<MobjectBig> mobjectOutZoneList) {

        Map<Long, List<MobjectBig>> geofenceMobjectListMap = new HashMap<>();
        List<MobjectBig> foundMobjectsInGeofence;

        if (geofenceList != null && !geofenceList.isEmpty()
                && mobjectList != null && !mobjectList.isEmpty()
                && mobjectInZoneList != null) {

            // Get all geofence IDs and Mobject IDs, where Mobject is inside Geofence
            Map<Long, List<MobjectInPoiGeofence>> mapByGeofenceForMobjectInGeofence = null;
            if (coreGeofence != null) {
                coreGeofence.loadMobjectsInGeofence();
                mapByGeofenceForMobjectInGeofence = coreGeofence.getMapByGeofenceForMobjectInGeofence();
            }

            // If there is some Mobjects inside Geofence, use them
            if (mapByGeofenceForMobjectInGeofence != null) {
                for (Geofence geofence : geofenceList) {
                    foundMobjectsInGeofence = new ArrayList<>();

                    List<MobjectInPoiGeofence> mobjectsInPoi = mapByGeofenceForMobjectInGeofence.get(geofence.getId());

                    if (mobjectsInPoi != null) {
                        for (MobjectInPoiGeofence mobjectInGeofence : mobjectsInPoi) {

                            MobjectBig mobz = mobjectList.stream().filter(o -> o.getId().equals(mobjectInGeofence.getMobjectId())).findFirst().orElse(null);

                            if (mobz != null) {
                                foundMobjectsInGeofence.add(mobz);
                                mobjectOutZoneList.remove(mobz);
                            }
                        }
                    }
                    geofenceMobjectListMap.put(geofence.getId(), foundMobjectsInGeofence);
                }
            }
        }

        return geofenceMobjectListMap;
    }


}
