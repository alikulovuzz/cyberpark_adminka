package uzgps.rest.dashboard;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectTracks;
import uzgps.common.UZGPS_CONST;
import uzgps.dashboard.DTO.MobjectTracksExtended;

import java.util.List;

public class MobjectStatusesCounter {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private int objectCount = 0;
    private int activeObjectsCount = 0;
    private int parkingObjectsCount = 0;
    private int connectionLostObjectsCount = 0;
    private int noDataObjectsCount = 0;

    public MobjectStatusesCounter(List<MobjectTracks> mObjectTracksList, boolean isShowSuspendedObjects) {
        calculate(mObjectTracksList, isShowSuspendedObjects);
    }

    private void calculate(List<MobjectTracks> mObjectTracksList, boolean isShowSuspendedObjects) {
        try {
            int activeObjectCountTemp = 0;
            int parkingObjectCountTemp = 0;
            int connectionLostCountTemp = 0;
            int noDataCountTemp = 0;

            if (!isShowSuspendedObjects) {
                mObjectTracksList.removeIf(mObjectTr -> mObjectTr.getMobject() != null &&
                        mObjectTr.getMobject().getGpsUnitBig() != null &&
                        mObjectTr.getMobject().getGpsUnitBig().getBlock().equals(UZGPS_CONST.STATUS_BLOCK));
            }

            int objectCountTemp = mObjectTracksList.size();

            for (MobjectTracks mobjectWithTracks : mObjectTracksList) {
                List<GPSTrackPoint> trackPoints = mobjectWithTracks.getTracks();
                GPSTrackPoint gpsTrackPoint;

                if (trackPoints != null && !trackPoints.isEmpty()) {
                    gpsTrackPoint = trackPoints.get(0);

                    byte movement = gpsTrackPoint.getMovement();
                    byte online = gpsTrackPoint.getOnline();
//                    calculateIconUrl(this.movement, this.online);

                    if (movement == 1 && online == 1) {
                        // Object is moving "GREEN"
                        activeObjectCountTemp += 1;
                    } else if (movement == 2 && online == 1) {
                        parkingObjectCountTemp += 1;
                    } else if (movement == 0 && online == 1) {
                        parkingObjectCountTemp += 1;
                    } else if (online == 0) {
                        // Connection lost
                        connectionLostCountTemp += 1;
                    } else if (movement == -1 && online == -1) {
                        // Object is online, but no data to display
                        activeObjectCountTemp += 1;
                    } else {
                        noDataCountTemp += 1;
                    }
                } else {
                    noDataCountTemp += 1;
                }
            }

            setObjectCount(objectCountTemp);
            setActiveObjectsCount(activeObjectCountTemp);
            setParkingObjectsCount(parkingObjectCountTemp);
            setConnectionLostObjectsCount(connectionLostCountTemp);
            setNoDataObjectsCount(noDataCountTemp);
        } catch (Exception e) {
            logger.error("Error in MobjectStatusesCounter", e);
        }
    }

    public int getObjectCount() {
        return objectCount;
    }

    public void setObjectCount(int objectCount) {
        this.objectCount = objectCount;
    }

    public int getActiveObjectsCount() {
        return activeObjectsCount;
    }

    public void setActiveObjectsCount(int activeObjectsCount) {
        this.activeObjectsCount = activeObjectsCount;
    }

    public int getParkingObjectsCount() {
        return parkingObjectsCount;
    }

    public void setParkingObjectsCount(int parkingObjectsCount) {
        this.parkingObjectsCount = parkingObjectsCount;
    }

    public int getConnectionLostObjectsCount() {
        return connectionLostObjectsCount;
    }

    public void setConnectionLostObjectsCount(int connectionLostObjectsCount) {
        this.connectionLostObjectsCount = connectionLostObjectsCount;
    }

    public int getNoDataObjectsCount() {
        return noDataObjectsCount;
    }

    public void setNoDataObjectsCount(int noDataObjectsCount) {
        this.noDataObjectsCount = noDataObjectsCount;
    }
}
