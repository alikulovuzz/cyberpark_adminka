package uzgps.rest.dto;

import uz.netex.routing.database.tables.Route;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stanislav on 31.07.2017 16:40
 */
public class RoutesDTO {

    private List<Route> routes;

    public RoutesDTO() {
        this.routes = new ArrayList<>();
    }


    public List<Route> getRoutes() {
        return routes;
    }

    public void setRoutes(List<Route> routes) {
        this.routes = routes;
    }

    @Override
    public String toString() {
        return "RoutesDTO{" +
                "routes=" + routes +
                '}';
    }
}
