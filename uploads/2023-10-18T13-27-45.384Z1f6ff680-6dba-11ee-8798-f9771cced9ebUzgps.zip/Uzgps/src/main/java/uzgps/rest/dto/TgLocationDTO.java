package uzgps.rest.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TgLocationDTO {

    private Long chatId;
    private Long messageId;
    private Long mobjectId;
    private Long expireTime;

    public Long getExpireTime() {
        return expireTime;
    }

    public void setExpireTime(Long expireTime) {
        this.expireTime = expireTime;
    }

    public Long getChatId() {
        return chatId;
    }

    public void setChatId(Long chatId) {
        this.chatId = chatId;
    }

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public void setMobjectId(Long mobjectId) {
        this.mobjectId = mobjectId;
    }
}
