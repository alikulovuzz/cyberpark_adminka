package uzgps.rest.dto;

/**
 * Created by Saidolim on 17.10.2016.
 */
public class DashboardStatisticsDTO {

    private Integer qtDbHandler;
    private Integer qtDbLogHexHandler;
    private Integer parserThreadCount;
    private Integer trackerCountUsed;
    private Integer trackerCountLicense;

    public Integer getQtDbHandler() {
        return qtDbHandler;
    }

    public void setQtDbHandler(Integer qtDbHandler) {
        this.qtDbHandler = qtDbHandler;
    }

    public Integer getQtDbLogHexHandler() {
        return qtDbLogHexHandler;
    }

    public void setQtDbLogHexHandler(Integer qtDbLogHexHandler) {
        this.qtDbLogHexHandler = qtDbLogHexHandler;
    }

    public Integer getParserThreadCount() {
        return parserThreadCount;
    }

    public void setParserThreadCount(Integer parserThreadCount) {
        this.parserThreadCount = parserThreadCount;
    }

    public Integer getTrackerCountUsed() {
        return trackerCountUsed;
    }

    public void setTrackerCountUsed(Integer trackerCountUsed) {
        this.trackerCountUsed = trackerCountUsed;
    }

    public Integer getTrackerCountLicense() {
        return trackerCountLicense;
    }

    public void setTrackerCountLicense(Integer trackerCountLicense) {
        this.trackerCountLicense = trackerCountLicense;
    }

    @Override
    public String toString() {
        return "DashboardStatisticsDTO{" +
                "qtDbHandler=" + qtDbHandler +
                ", qtDbLogHexHandler=" + qtDbLogHexHandler +
                ", parserThreadCount=" + parserThreadCount +
                ", trackerCountUsed=" + trackerCountUsed +
                ", trackerCountLicense=" + trackerCountLicense +
                '}';
    }
}
