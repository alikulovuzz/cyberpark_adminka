package uzgps.rest.dashboard;

import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uzgps.dashboard.DTO.DonutData;
import uzgps.dashboard.DTO.MobjectTypeDataExtendedImpl;
import uzgps.dashboard.DTO.MobjectTypeDataImpl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public final class DashboardDataConverter {

    private DashboardDataConverter() {
    }

    private static final Logger logger = LoggerFactory.getLogger(DashboardDataConverter.class.getName());

    public static JsonObject splitObjectsForDonut(List<DonutData> donutDataList) {
        try {
            JsonObject resultJsonObj = new JsonObject();

            List<String> names = new ArrayList<>();
            List<Integer> values = new ArrayList<>();

            for (DonutData donutData : donutDataList) {
                if (donutData.getName() != null) {
                    names.add(donutData.getName());
                }

                if (donutData.getCount() != null) {
                    values.add(donutData.getCount());
                }
            }

            resultJsonObj.put("labels", names);
            resultJsonObj.put("values", values);

            return resultJsonObj;
        } catch (Exception e) {
            logger.error("splitObjectsForDonut error", e);
        }
        return null;
    }

    public static JsonObject splitReservoirData(List<JsonObject> itemsJson) {
        try {
            JsonObject resultJsonObject = new JsonObject();
            JsonArray reservoirDataJsonArr = new JsonArray();

            List<String> names = new ArrayList<>();
            List<Double> capacities = new ArrayList<>();
            List<Double> balances = new ArrayList<>();

            try {
                for (JsonObject item : itemsJson) {
                    if (item.getString("name") != null) {
                        names.add(item.getString("name"));
                    }

                    if (item.getDouble("capacity") != null) {
                        capacities.add(item.getDouble("capacity"));
                    }

                    if (item.getDouble("balance") != null) {
                        balances.add(item.getDouble("balance"));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            try {
                for (JsonObject item : itemsJson) {
                    if (item.getString("name") != null) {
                        names.add(item.getString("name"));
                    }

                    if (item.getDouble("capacity") != null) {
                        capacities.add(item.getDouble("capacity"));
                    }

                    if (item.getDouble("balance") != null) {
                        balances.add(item.getDouble("balance"));
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            JsonObject capacitiesJsonObj = new JsonObject();
            capacitiesJsonObj.put("name", "Объем резервуара");
            capacitiesJsonObj.put("data", capacities);

            JsonObject balancesJsonObj = new JsonObject();
            balancesJsonObj.put("name", "Остаток резервуара");
            balancesJsonObj.put("data", balances);

            reservoirDataJsonArr.add(capacities);
            reservoirDataJsonArr.add(balances);

            JsonArray dataJsonArray = new JsonArray();
            dataJsonArray.add(capacitiesJsonObj);
            dataJsonArray.add(balancesJsonObj);

            resultJsonObject.put("categories", names);
            resultJsonObject.put("data", dataJsonArray);

            return resultJsonObject;

        } catch (Exception e) {
            logger.error("splitReservoirData error", e);
        }
        return null;
    }

    public static JsonObject splitFuelAndConsumptionData(List<JsonObject> itemsJson) {
        try {

            JsonObject resultJsonObject = new JsonObject();
            JsonArray reservoirDataJsonArr = new JsonArray();

            List<String> dates = new ArrayList<>();

            List<Double> refuelings = new ArrayList<>();
            List<Double> fuelLevels = new ArrayList<>();
            List<Double> fuelConsumptions = new ArrayList<>();

            for (JsonObject item : itemsJson) {
                if (item.getString("date") != null) {
                    String dateStrFmt = formatDateStringToDayMonth(item.getString("date"));
                    dates.add(dateStrFmt);
                }

                if (item.getDouble("refueling") != null) {
                    refuelings.add(item.getDouble("refueling"));
                }

                if (item.getDouble("fuel_level_at_arrival") != null) {
                    fuelLevels.add(item.getDouble("fuel_level_at_arrival"));
                }

                if (item.getDouble("fuel_consumption") != null) {
                    fuelConsumptions.add(item.getDouble("fuel_consumption"));
                }
            }

            JsonObject refuelingsJsonObj = new JsonObject();
            refuelingsJsonObj.put("name", "Заправка");
            refuelingsJsonObj.put("data", refuelings);

            JsonObject fuelLevelsJsonObj = new JsonObject();
            fuelLevelsJsonObj.put("name", "Остатки топлива");
            fuelLevelsJsonObj.put("data", fuelLevels);

            JsonObject fuelConsumptionsJsonObj = new JsonObject();
            fuelConsumptionsJsonObj.put("name", "Расход топлива");
            fuelConsumptionsJsonObj.put("data", fuelConsumptions);

            reservoirDataJsonArr.add(refuelings);
            reservoirDataJsonArr.add(fuelLevels);
            reservoirDataJsonArr.add(fuelConsumptions);

            JsonArray dataJsonArray = new JsonArray();
            dataJsonArray.add(refuelingsJsonObj);
            dataJsonArray.add(fuelLevelsJsonObj);
            dataJsonArray.add(fuelConsumptionsJsonObj);

            resultJsonObject.put("dates", dates);
            resultJsonObject.put("data", dataJsonArray);

            return resultJsonObject;

        } catch (Exception e) {
            logger.error("splitFuelAndConsumptionData error", e);
        }
        return null;
    }

    public static JsonObject splitFuelData(List<JsonObject> itemsJson) {
        try {

            JsonObject resultJsonObject = new JsonObject();
            JsonArray reservoirDataJsonArr = new JsonArray();

            List<String> dates = new ArrayList<>();

            List<Double> refuelings = new ArrayList<>();

            for (JsonObject item : itemsJson) {
                if (item.getString("date") != null) {
                    String dateStrFmt = formatDateStringToDayMonth(item.getString("date"));
                    dates.add(dateStrFmt);
                }

                if (item.getDouble("refueling") != null) {
                    refuelings.add(item.getDouble("refueling"));
                }
            }

            JsonObject refuelingsJsonObj = new JsonObject();
            refuelingsJsonObj.put("name", "Заправка");
            refuelingsJsonObj.put("data", refuelings);

            reservoirDataJsonArr.add(refuelings);

            JsonArray dataJsonArray = new JsonArray();
            dataJsonArray.add(refuelingsJsonObj);

            resultJsonObject.put("dates", dates);
            resultJsonObject.put("data", dataJsonArray);

            return resultJsonObject;

        } catch (Exception e) {
            logger.error("splitFuelData error", e);
        }
        return null;
    }

    public static JsonObject splitDistanceData(List<JsonObject> itemsJson) {
        try {

            JsonObject resultJsonObject = new JsonObject();
            JsonArray reservoirDataJsonArr = new JsonArray();

            List<String> dates = new ArrayList<>();

            List<Double> distances = new ArrayList<>();

            for (JsonObject item : itemsJson) {
                if (item.getString("date") != null) {
                    String dateStrFmt = formatDateStringToDayMonth(item.getString("date"));
                    dates.add(dateStrFmt);
                }

                if (item.getDouble("distance") != null) {
                    distances.add(item.getDouble("distance"));
                }
            }

            JsonObject refuelingsJsonObj = new JsonObject();
            refuelingsJsonObj.put("name", "Пробег");
            refuelingsJsonObj.put("data", distances);

            reservoirDataJsonArr.add(distances);

            JsonArray dataJsonArray = new JsonArray();
            dataJsonArray.add(refuelingsJsonObj);

            resultJsonObject.put("dates", dates);
            resultJsonObject.put("data", dataJsonArray);

            return resultJsonObject;

        } catch (Exception e) {
            logger.error("splitDistanceData error", e);
        }
        return null;
    }

    public static JsonObject splitInspectionsData(List<JsonObject> itemsJson) {
        try {

            JsonObject resultJsonObject = new JsonObject();
            JsonArray InspectionsDataJsonArr = new JsonArray();

            List<String> dates = new ArrayList<>();

            List<Integer> passedCount = new ArrayList<>();
            List<Integer> notPassedCount = new ArrayList<>();

            for (JsonObject item : itemsJson) {
                if (item.getString("date") != null) {
                    String dateStrFmt = formatDateStringToDayMonth(item.getString("date"));
                    dates.add(dateStrFmt);
                }

                if (item.getInteger("passed_count") != null) {
                    passedCount.add(item.getInteger("passed_count"));
                }

                if (item.getInteger("not_passed_count") != null) {
                    notPassedCount.add(item.getInteger("not_passed_count"));
                }
            }

            JsonObject passedJsonObj = new JsonObject();
            passedJsonObj.put("name", "Допуск");
            passedJsonObj.put("data", passedCount);

            JsonObject notPassedJsonObj = new JsonObject();
            notPassedJsonObj.put("name", "Не допуск");
            notPassedJsonObj.put("data", notPassedCount);

            InspectionsDataJsonArr.add(passedCount);
            InspectionsDataJsonArr.add(notPassedCount);

            JsonArray dataJsonArray = new JsonArray();
            dataJsonArray.add(passedJsonObj);
            dataJsonArray.add(notPassedJsonObj);

            resultJsonObject.put("dates", dates);
            resultJsonObject.put("data", dataJsonArray);

            return resultJsonObject;

        } catch (Exception e) {
            logger.error("splitInspectionsData error", e);
        }
        return null;
    }


    /**
     * Return String formatted local date string from iso date string
     *
     * @param dateStr
     * @return
     */
    public static String formatDateStringToDayMonth(String dateStr) {
        SimpleDateFormat utcFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        utcFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM");
        try {
            Date date = utcFormat.parse(dateStr);
            LocalDateTime localDate = LocalDateTime.ofInstant(date.toInstant(), ZoneId.of("Asia/Tashkent"));
            return localDate.format(formatter);
        } catch (ParseException e) {
            return dateStr;
        }
    }

}
