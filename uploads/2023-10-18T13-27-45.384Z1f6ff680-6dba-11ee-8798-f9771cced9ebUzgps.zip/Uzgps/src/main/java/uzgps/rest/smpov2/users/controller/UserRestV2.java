package uzgps.rest.smpov2.users.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import uzgps.common.FileStorageService;
import uzgps.common.RoleInfo;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.RoleConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.*;
import uzgps.rest.BaseRest;
import uzgps.rest.ResponseUtil;
import uzgps.rest.smpov2.users.dto.UserBaseDTO;
import uzgps.rest.smpov2.users.dto.UserDTO;
import uzgps.rest.smpov2.users.dto.UserFormDTO;
import uzgps.security.MD5;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

@RestController
@RequestMapping("/v2/user/")
public class UserRestV2 extends BaseRest {


    @Autowired
    MainController mainController;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private SettingsService settingsService;

    @Autowired
    FileStorageService storageService;

    /**
     * Get user data by id.
     *
     * @param id in path.
     * @return user data.
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */


    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/{user-id}", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getUser(
            @PathVariable("user-id") Long id)
            throws ServletException, IOException {

        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                User user = settingsService.getUserByUserId(id);
                UserDTO userDTO = UserDTO.toModel(user);
                return ResponseUtil.respondSuccess(userDTO);

            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    /**
     * Get users by contractId
     *
     * @param contractId in path.
     * @return user data.
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/get-ids-by-contract-id/{contract-id}", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getFmsUserIdsByContractId(
            @PathVariable("contract-id") Long contractId) {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                List<Long> usersId = settingsService.getFmsUsersIdByContractId(contractId);
                return ResponseUtil.respondSuccess(usersId);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    /**
     * Get users by contractId
     *
     * @param contractId in path.
     * @return user data.
     */
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/get-by-contract-id/{contract-id}", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> getFmsUsersByContractId(
            @PathVariable("contract-id") Long contractId) {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                List<User> users = settingsService.getFmsUsersByContractId(contractId);
                List<UserBaseDTO> usersDTO = new ArrayList<>();

                for (User user: users) {
                    UserBaseDTO userDTO = UserBaseDTO.toModel(user);
                    usersDTO.add(userDTO);
                }

                return ResponseUtil.respondSuccess(usersDTO);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }


    /**
     * Create new user (without fms-access).
     * <p>
     * Request POST call to create new user without fms access.
     *
     * @return user id if success or
     * "User with this login already exists" if user with this login already exists.
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/create", produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> createUser(
            HttpSession session,
            @RequestBody UserFormDTO userFormDTO)
            throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                String login = userFormDTO.getLogin();
                login = (login != null) ? login.trim().toLowerCase() : "";
                User userFind = adminService.getUserByLogin(login);

                if (userFind != null && userFind.getId() != null) {
                    return ResponseUtil.respondConflict(String.format("User with login %s already exists", login));
                } else {
                    User user = addUser(userFormDTO, login);
                    addDefaultUserAccess(session, user);
                    addUserRole(session, user);
                    return ResponseUtil.respondSuccess(user.getId());
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    /**
     * Create new user (with fms-access).
     * <p>
     * Request POST call to create new user with fms access.
     *
     * @return user id if success or
     * "User with this login already exists" if user with this login already exists.
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/create-fms", produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> createFmsUser(
            HttpSession session,
            @RequestBody UserFormDTO userFormDTO)
            throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                String login = userFormDTO.getLogin();
                login = (login != null) ? login.trim().toLowerCase() : "";
                User userFind = adminService.getUserByLogin(login);

                if (userFind != null && userFind.getId() != null) {
                    return ResponseUtil.respondConflict(String.format("User with login %s already exists", login));
                } else {
                    User user = addUser(userFormDTO, login);
                    addDefaultFMSUserAccess(session, user);
                    addUserRole(session, user);
                    return ResponseUtil.respondSuccess(user.getId());
                }
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    /**
     * Update a given user's password.
     * <p>
     * Request POST call to update user`s password.
     *
     * @param userId in path.
     * @return if success user id else "Error request"
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/{user-id}/update-password", produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> updateUserPassword(
            @PathVariable("user-id") Long userId,
            @RequestBody UserFormDTO userFormDTO)
            throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                User user = settingsService.getUserByUserId(userId);
                MD5 md5 = new MD5();
                String password = userFormDTO.getPassword();
                password = md5.getMD5(password);
                user.setPassword(password);
                settingsService.saveUser(user);
                return ResponseUtil.respondSuccess(user.getId());

            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    /**
     * Update a given user's password with new login and password.
     *
     * @param userId in path.
     *               Request POST call to update user`s login or password.
     * @return if success user id else if
     * user with this login already exists "User with this login already exists" else
     * "Error request".
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/{user-id}/update-login-password", produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> updateUserLoginPassword(
            @PathVariable("user-id") Long userId,
            @RequestBody UserFormDTO userFormDTO)
            throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                String login = userFormDTO.getLogin();
                login = (login != null) ? login.trim().toLowerCase() : "";
                User userFind = adminService.getUserByLogin(login);

                if (userFind != null && userFind.getId() != null && !userFind.getId().equals(userId)) {
                    return ResponseUtil.respondConflict(String.format("User with login %s already exists", login));
                }

                User user = settingsService.getUserByUserId(userId);
                user.setLogin(login.trim().toLowerCase());

                if (userFormDTO.getPassword() != null) {
                    MD5 md5 = new MD5();
                    String password = userFormDTO.getPassword();
                    password = md5.getMD5(password);
                    user.setPassword(password);
                }

                settingsService.saveUser(user);
                return ResponseUtil.respondSuccess(user.getId());
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    /**
     * Update profile of a given user.
     *
     * @param userId      in path.
     * @param file        optional.
     * @param login       optional.
     * @param email       optional.
     * @param surName     optional.
     * @param name        optional.
     * @param middleName  optional.
     * @param position    optional.
     * @param phoneMobile optional.
     * @param phoneLine   optional.
     * @return if success "User password updated" else if
     * user with this login already exists "User with this login already exists" else
     * "Error request".
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/{user-id}/update-profile", produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> updateUserProfile(
            @PathVariable("user-id") Long userId,
            @RequestParam(value = "file", required = false) MultipartFile file,
            @RequestParam(value = "login", required = false) String login,
            @RequestParam(value = "email", required = false) String email,
            @RequestParam(value = "name", required = false) String name,
            @RequestParam(value = "sur-name", required = false) String surName,
            @RequestParam(value = "middle-name", required = false) String middleName,
            @RequestParam(value = "position", required = false) String position,
            @RequestParam(value = "phone-mobile", required = false) String phoneMobile,
            @RequestParam(value = "phone-line", required = false) String phoneLine
    )
            throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                User user = settingsService.getUserByUserId(userId);
                if (file != null && file.getSize() > 0) {
                    if (user.getPhoto() != null) {
                        // Remove the image of Profile if exists
                        FileStorage oldFileStorage = user.getPhoto();
                        user.setPhoto(null);
                        settingsService.saveUser(user);
                        storageService.removeFileFromStorage(oldFileStorage);
                    }

                    FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                    user.setPhoto(fileStorage);
                } else if (file == null) {
                    // Remove the image of Profile if exists
                    FileStorage fileStorage = user.getPhoto();
                    if (fileStorage != null) {
                        user.setPhoto(null);
                        settingsService.saveUser(user);
                        storageService.removeFileFromStorage(fileStorage);
                    }
                }
                if (login != null) {
                    login = login.trim().toLowerCase();
                    User userFind = adminService.getUserByLogin(login);
                    if (userFind != null) {
                        return ResponseUtil.respondConflict(String.format("User with login %s already exists", login));
                    }
                    user.setLogin(login);
                }
                if (name != null) {
                    user.setName(name);
                }
                if (surName != null) {
                    user.setSurName(surName);
                }
                if (middleName != null) {
                    user.setMiddleName(middleName);
                }
                if (position != null) {
                    user.getProfile().setPosition(position);
                }
                if (email != null) {
                    user.getProfile().setEmail(email);
                }
                if (phoneMobile != null) {
                    user.getProfile().setMobilePhone(phoneMobile.replaceAll("[^0-9]", ""));
                }
                if (phoneLine != null) {
                    user.getProfile().setLinePhone(phoneLine.replaceAll("[^0-9]", ""));
                }
                user.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveUser(user);
                return ResponseUtil.respondSuccess(user.getId());

            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }

    }

    /**
     * Update access profile of a given user.
     *
     * @param userId            in path.
     * @param mapAccess         default "0".
     * @param monitoringAccess  default "0".
     * @param trackerAccess     default "0".
     * @param poiAccess         default "0".
     * @param geoZoneAccess     default "0".
     * @param messageAccess     default "0".
     * @param reportAccess      default "0".
     * @param routingAccess     default "0".
     * @param dashboardAccess   default "0".
     * @param fmsAccess         default "0".
     * @param statisticsAccess  default "0".
     * @param mObjectAccessList optional.
     * @param mObjectIdList     optional.
     * @param idList            optional.
     * @return if success user id else "Error request".
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/{user-id}/update-access", produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> updateUserAccess(
            HttpSession session,
            @PathVariable("user-id") Long userId,
            @RequestParam(value = "map-access", defaultValue = "0", required = false) Integer mapAccess,
            @RequestParam(value = "monitoring-access", defaultValue = "0", required = false) Integer
                    monitoringAccess,
            @RequestParam(value = "tracker-access", defaultValue = "0", required = false) Integer trackerAccess,
            @RequestParam(value = "poi-access", defaultValue = "0", required = false) Integer poiAccess,
            @RequestParam(value = "geo-zone-access", defaultValue = "0", required = false) Integer geoZoneAccess,
            @RequestParam(value = "message-access", defaultValue = "0", required = false) Integer messageAccess,
            @RequestParam(value = "report-access", defaultValue = "0", required = false) Integer reportAccess,
            @RequestParam(value = "routing-access", defaultValue = "0", required = false) Integer routingAccess,
            @RequestParam(value = "dashboard-access", defaultValue = "0", required = false) Integer dashboardAccess,
            @RequestParam(value = "fms-access", defaultValue = "0", required = false) Integer fmsAccess,
            @RequestParam(value = "statistics-access", defaultValue = "0", required = false) Integer
                    statisticsAccess,
            @RequestParam(value = "mobject-access[]", required = false) Long[] mObjectAccessList,
            @RequestParam(value = "mobject-id[]", required = false) Long[] mObjectIdList,
            @RequestParam(value = "id-list[]", required = false) Long[] idList) throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                UserAccessList userAccessList = settingsService.getUserAccessListByUserContractId(userId, MainController.getUserContractId(session));
                userAccessList.setMap(mapAccess);
                userAccessList.setMonitoring(monitoringAccess);
                userAccessList.setTracker(trackerAccess);
                userAccessList.setPoi(poiAccess);
                userAccessList.setGeoZone(geoZoneAccess);
                userAccessList.setMessage(messageAccess);
                userAccessList.setReport(reportAccess);
                userAccessList.setRouting(routingAccess);
                userAccessList.setDashboard(dashboardAccess);
                userAccessList.setFms(fmsAccess);
                userAccessList.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveUserAccessList(userAccessList);

                if (mObjectAccessList != null) {
                    for (int i = 0; i < mObjectAccessList.length; i++) {
                        MObject mObject = settingsService.getObjectByObjectId(mObjectIdList[i]);
                        UserMObjectAccessList userMObjectAccessList;

                        if (idList[i] == 0) {
                            userMObjectAccessList = new UserMObjectAccessList();
                        } else {
                            userMObjectAccessList = settingsService.getUserMObjectAccessById(idList[i]);
                        }

                        userMObjectAccessList.setmObject(mObject);
                        userMObjectAccessList.setUserId(userId);
                        userMObjectAccessList.setPermission(mObjectAccessList[i].intValue());

                        settingsService.saveUserMObjectAccess(userMObjectAccessList);

                        // Core Update for User Mobject Access
                        coreMain.coreUpdater.updateUserMobjectAccessById(userMObjectAccessList.getId());
                    }
                }

                return ResponseUtil.respondSuccess(userId);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }

    }

    /**
     * Remove users by r-id[].
     *
     * @param rUsersIdList required.
     *                     Request coll update users.setStatus() by rUserIdList by UZGPS_CONST.STATUS_DELETE.
     * @return rUsersIdList if success else "Error request"
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/remove", produces = "application/json", method = RequestMethod.POST)
    public ResponseEntity<?> deleteUser(
            @RequestParam(value = "r-id[]") Long[] rUsersIdList)
            throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                for (Long rUsersId : rUsersIdList) {
                    removeUser(rUsersId);
                }
                return ResponseUtil.respondSuccess(rUsersIdList);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    /**
     * Remove users by id.
     *
     * @param userId required.
     *               Request coll update users.setStatus() by userId by UZGPS_CONST.STATUS_DELETE.
     * @return userId if success else "Error request"
     * @throws ServletException if any error occurs.
     * @throws IOException      On input error.
     */

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @RequestMapping(value = "/{user-id}", produces = "application/json", method = RequestMethod.DELETE)
    public ResponseEntity<?> deleteUserById(@PathVariable("user-id") Long userId)
            throws ServletException, IOException {
        try {
            User sessionUser = MainController.getUser();

            if (sessionUser != null) {
                removeUser(userId);
                return ResponseUtil.respondSuccess(userId);
            } else {
                return ResponseUtil.respondUnauthorized("Unauthorized request");
            }
        } catch (Exception e) {
            return ResponseUtil.respondError(e);
        }
    }

    private User addUser(UserFormDTO userFormDTO, String login) {
        String password = userFormDTO.getPassword();
        String surName = userFormDTO.getSurName();
        String name = userFormDTO.getName();
        String middleName = userFormDTO.getMiddleName();

        User user = new User();
        Profile profile = new Profile();
        user.setProfile(profile);
        settingsService.saveProfile(profile);

        user.setLogin(login.trim().toLowerCase());

        MD5 md5 = new MD5();
        password = md5.getMD5(password);
        user.setPassword(password);

        user.setSurName(surName);
        user.setName(name);
        user.setMiddleName(middleName);

        Role role = adminService.getRoleById(UZGPS_CONST.USER_ROLE_USER);
        user.setRole(role);

        user.setStatus(UZGPS_CONST.USER_STATUS_ACTIVE);
        user.setBlock(UZGPS_CONST.USER_BLOCK_STATUS_UNBLOCK);
        user.setRegDate(new Timestamp(System.currentTimeMillis()));
        settingsService.saveUser(user);
        return user;
    }

    private void addUserRole(HttpSession session, User user) {
        UserRole userRole = new UserRole();
        userRole.setUser(user);

        RoleConfiguration roleConfiguration = appConfiguration.getRoleConfiguration();
        RoleInfo[] roleInfos = roleConfiguration.getRoleInfo();
        for (RoleInfo roleInfo : roleInfos) {
            if (roleInfo.getType().equalsIgnoreCase(USER_ROLE_USER_STR)) {
                userRole.setRoleId((long) roleInfo.getId());
                userRole.setContract(MainController.getUserContract(session));
                userRole.setRegDate(new Timestamp(System.currentTimeMillis()));
                userRole.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            }
        }
        settingsService.saveUseRole(userRole);
    }

    private void addDefaultUserAccess(HttpSession session, User user) {
        UserAccessList userAccessList = new UserAccessList();
        setDefaultUserAccessList(session, user, userAccessList);
        settingsService.saveUserAccessList(userAccessList);
    }

    private void addDefaultFMSUserAccess(HttpSession session, User user) {
        UserAccessList userAccessList = new UserAccessList();
        setDefaultUserAccessList(session, user, userAccessList);
        userAccessList.setFms(UZGPS_CONST.USER_ACCESS_FULL);
        settingsService.saveUserAccessList(userAccessList);
    }

    private void setDefaultUserAccessList(HttpSession session, User user, UserAccessList userAccessList) {
        userAccessList.setUser(user);
        userAccessList.setMap(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setMonitoring(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setTracker(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setPoi(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setGeoZone(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setMessage(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setReport(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setDashboard(UZGPS_CONST.USER_ACCESS_NONE);
        userAccessList.setFms(UZGPS_CONST.USER_ACCESS_FULL);
        userAccessList.setRegDate(new Timestamp(System.currentTimeMillis()));
        userAccessList.setContract(MainController.getUserContract(session));
    }


    private void removeUser(Long userId) {
        User user = settingsService.getUserById(userId);
        user.setExpDate(new Timestamp(System.currentTimeMillis()));
        user.setStatus(UZGPS_CONST.STATUS_DELETE);
        settingsService.saveUser(user);

        settingsService.updateUserMObjectAccessList(userId);
        // Core Update for User Mobject Access By User ID
        coreMain.coreUpdater.updateUserMobjectAccessByUserId(userId);
    }


//    /**
//     * Get all users
//     *
//     * @param contractId required
//     * @return list of users
//     * @throws ServletException if any error occurs
//     * @throws IOException      if any error occurs
//     */
//
//    @CrossOrigin(origins = "*", allowedHeaders = "*")
//    @RequestMapping(value = "/get-list", produces = "application/json", method = RequestMethod.GET)
//    public ResponseEntity<?> getUserList(
//            @RequestParam(value = "contract-id", required = true) Long contractId)
//            throws ServletException, IOException {
//        try {
//            List<User> users = settingsService.getCustomerUsersByContractId(contractId);
//            List<UserDTO> usersDTO = UserDTO.getUsers(users);
//            return ResponseUtil.respondSuccess(usersDTO);
//        } catch (Exception e) {
//            return ResponseUtil.respondConflict("Error request");
//        }
//    }
}
