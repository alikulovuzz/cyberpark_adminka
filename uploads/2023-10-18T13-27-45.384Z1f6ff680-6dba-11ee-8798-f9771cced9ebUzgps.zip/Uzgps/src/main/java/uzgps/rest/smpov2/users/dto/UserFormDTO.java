package uzgps.rest.smpov2.users.dto;

public class UserFormDTO {
    private String login;
    private String password;
    private String surName = "";
    private String name = "";
    private String middleName = "";

    public UserFormDTO() {
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public String getSurName() {
        return surName;
    }

    public String getName() {
        return name;
    }

    public String getMiddleName() {
        return middleName;
    }
}
