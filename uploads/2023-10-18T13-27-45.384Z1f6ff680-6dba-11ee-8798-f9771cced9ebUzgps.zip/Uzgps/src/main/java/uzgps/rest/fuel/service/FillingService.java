package uzgps.rest.fuel.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.admin.AdminService;
import uzgps.rest.fuel.model.FuelFill;

import javax.persistence.*;
import java.util.Collections;
import java.util.List;

@Service
@Component
public class FillingService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    AdminService adminService;

    @Transactional
    public List<FuelFill> getFuelFillings(Long mobjectId, String startDate, String endDate) {
        if (mobjectId != null && startDate != null && endDate != null) {
            try {
                Query query;
                String sqlStr = "select row_number() OVER () AS id," +
                        "     m.rffd_mobject_id mobjectId, " +
                        "     m.rffd_start_date startDate,\n" +
                        "     m.rffd_end_date endDate,\n" +
                        "     m.rffd_fuel_filling amount " +
                        "FROM dashboard.report_fuel_fillings_drains_from_db_reports(\n" +
                        "  :mobjectId, \n" +
                        "  :startDate, \n" +
                        "  :endDate) m where  rffd_fuel_filling is not null";

                query = entityManager.createNativeQuery(sqlStr, FuelFill.class);
                query.setParameter("mobjectId", mobjectId);
                query.setParameter("startDate", startDate);
                query.setParameter("endDate", endDate);
                return query.getResultList();
            } catch (Exception e) {
                logger.error("Error in getFuelFillings", e);
            }
        } else {
            return Collections.emptyList();
        }
        return Collections.emptyList();
    }
}
