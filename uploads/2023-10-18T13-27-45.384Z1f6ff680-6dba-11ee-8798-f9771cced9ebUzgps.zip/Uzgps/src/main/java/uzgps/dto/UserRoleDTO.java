package uzgps.dto;

import uzgps.persistence.UserRole;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class UserRoleDTO implements Serializable, BasedDTO {

    private Long id;
    private Long userId;
    private Long roleId;
    private Long contractId;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private Boolean defaultCustomerAdmin;

    public UserRoleDTO(UserRole userRole) {
        this.id = userRole.getId();
        this.userId = userRole.getUserId();
        this.roleId = userRole.getRoleId();
        this.contractId = userRole.getContractId();
        this.status = userRole.getStatus();
        this.regDate = userRole.getRegDate();
        this.modDate = userRole.getModDate();
        this.expDate = userRole.getExpDate();
        this.defaultCustomerAdmin = userRole.getDefaultCustomerAdmin();
    }

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public Long getRoleId() {
        return roleId;
    }

    public Long getContractId() {
        return contractId;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public Boolean getDefaultCustomerAdmin() {
        return defaultCustomerAdmin;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
