package uzgps.dto;

import uzgps.common.UZGPS_CONST;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Stanislav on 02.04.2020.
 */
public class GPSTrackPointDTO implements Serializable, BasedDTO {
    private Long id;
    private Timestamp updateDate;
    private String status;
    private Timestamp startDate;
    private Timestamp endDate;
    private List<Long> mObjectsList;
    private String note;

    public GPSTrackPointDTO(Long id, String status) {
        this.id = id;
        this.updateDate = new Timestamp(System.currentTimeMillis());
        this.status = status;
        this.note = "Deleted track id: " + id;
    }

    public GPSTrackPointDTO(Long id, String status, Timestamp startDate, Timestamp endDate, List<Long> mObjectsList) {
        this.id = id;
        this.updateDate = new Timestamp(System.currentTimeMillis());
        this.status = status;

        this.startDate = startDate;
        this.endDate = endDate;
        this.mObjectsList = mObjectsList;

        switch (status) {
            case UZGPS_CONST.STATUS_ACTIVE:
                this.note = "Restore tracks from " + startDate + " to " + endDate + " from list: " + mObjectsList;
            case UZGPS_CONST.STATUS_DELETE:
                this.note = "Delete tracks from " + startDate + " to " + endDate + " from list: " + mObjectsList;
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public List<Long> getmObjectsList() {
        return mObjectsList;
    }

    public void setmObjectsList(List<Long> mObjectsList) {
        this.mObjectsList = mObjectsList;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "GPSTrackPointDTO{" +
                "id=" + id +
                ", updateDate=" + updateDate +
                ", status='" + status + '\'' +
                ", startDate=" + startDate +
                ", endDate=" + endDate +
                ", mObjectsList=" + mObjectsList +
                ", note='" + note + '\'' +
                '}';
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
