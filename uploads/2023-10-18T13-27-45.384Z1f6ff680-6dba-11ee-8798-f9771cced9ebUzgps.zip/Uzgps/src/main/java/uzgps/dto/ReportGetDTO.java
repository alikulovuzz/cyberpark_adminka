package uzgps.dto;

import java.io.Serializable;

/**
 * Created by NETEX on 15.06.2017.
 */
public class ReportGetDTO implements Serializable, BasedDTO {
    private Long id;
    private String locale;
    private String type;
    private String startDate;
    private String endDate;

    public ReportGetDTO(Long id, String locale, String type, String startDate, String endDate) {
//        this.id = id;
//        this.locale = locale;
//        this.type = type;
//        this.startDate = startDate;
//        this.endDate = endDate;
//
//
        setId(id);
        setLocale(locale);
        setType(type);
        setStartDate(startDate);
        setEndDate(endDate);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
