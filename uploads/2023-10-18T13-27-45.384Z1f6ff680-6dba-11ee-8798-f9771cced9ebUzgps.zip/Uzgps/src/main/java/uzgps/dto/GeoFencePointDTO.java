package uzgps.dto;

import uzgps.persistence.GeoFencePoint;

import java.io.Serializable;

/**
 * Created by NETEX on 15.06.2017.
 */
public class GeoFencePointDTO implements Serializable, BasedDTO {
    private Long id;
    private Double longitude;
    private Double latitude;
    private Long geoFenceId;

    public GeoFencePointDTO(GeoFencePoint geoFencePoint) {
        this.id = geoFencePoint.getId();
        this.longitude = geoFencePoint.getLongitude();
        this.latitude = geoFencePoint.getLatitude();
        this.geoFenceId = geoFencePoint.getGeoFenceId();
    }

    public Long getId() {
        return id;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Long getGeoFenceId() {
        return geoFenceId;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
