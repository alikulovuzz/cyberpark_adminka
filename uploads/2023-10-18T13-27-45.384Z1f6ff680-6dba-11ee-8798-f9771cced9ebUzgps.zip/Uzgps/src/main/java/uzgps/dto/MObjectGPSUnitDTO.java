package uzgps.dto;

import uzgps.persistence.MObjectGPSUnit;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class MObjectGPSUnitDTO implements Serializable, BasedDTO {
    private Long id;
    private Long mObjectId;
    private Long gpsUnitId;
    private Short movementStatus;
    private Short engineOnStatus;
    private Short onlineStatus;
    private Short satellitesStatus;
    private Short datStatus;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private Integer distanceMin;
    private Integer distanceBig;
    private Integer timeMin;
    private Integer timeBig;
    private Integer timeLost;

    public MObjectGPSUnitDTO(MObjectGPSUnit mObjectGPSUnit) {
        this.id = mObjectGPSUnit.getId();
        this.mObjectId = mObjectGPSUnit.getmObjectId();
        this.gpsUnitId = mObjectGPSUnit.getGpsUnitId();
        this.movementStatus = mObjectGPSUnit.getMovementStatus();
        this.engineOnStatus = mObjectGPSUnit.getEngineOnStatus();
        this.onlineStatus = mObjectGPSUnit.getOnlineStatus();
        this.satellitesStatus = mObjectGPSUnit.getSatellitesStatus();
        this.datStatus = mObjectGPSUnit.getDatStatus();
        this.status = mObjectGPSUnit.getStatus();
        this.regDate = mObjectGPSUnit.getRegDate();
        this.modDate = mObjectGPSUnit.getModDate();
        this.expDate = mObjectGPSUnit.getExpDate();
        this.distanceMin = mObjectGPSUnit.getDistanceMin();
        this.distanceBig = mObjectGPSUnit.getDistanceBig();
        this.timeMin = mObjectGPSUnit.getTimeMin();
        this.timeBig = mObjectGPSUnit.getTimeBig();
        this.timeLost = mObjectGPSUnit.getTimeLost();
    }

    public Long getId() {
        return id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public Long getGpsUnitId() {
        return gpsUnitId;
    }

    public Short getMovementStatus() {
        return movementStatus;
    }

    public Short getEngineOnStatus() {
        return engineOnStatus;
    }

    public Short getOnlineStatus() {
        return onlineStatus;
    }

    public Short getSatellitesStatus() {
        return satellitesStatus;
    }

    public Short getDatStatus() {
        return datStatus;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public Integer getDistanceMin() {
        return distanceMin;
    }

    public Integer getDistanceBig() {
        return distanceBig;
    }

    public Integer getTimeMin() {
        return timeMin;
    }

    public Integer getTimeBig() {
        return timeBig;
    }

    public Integer getTimeLost() {
        return timeLost;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
