package uzgps.dto;

import uzgps.persistence.Company;

import java.io.Serializable;

/**
 * Created by NETEX on 15.06.2017.
 */
public class CompanyDTO implements Serializable, BasedDTO {
    private Long id;
    private String name;
    private String address;
    private String email;
    private String phoneMobile;
    private String phoneLine;
    private String settlementAccount;
    private String bankDetails;
    private String okonh;
    private String inn;
    private String contact;
    private String contactPhoneMobile;
    private String contactEmail;

    public CompanyDTO(Company company) {
        this.id = company.getId();
        this.name = company.getName();
        this.address = company.getAddress();
        this.email = company.getEmail();
        this.phoneMobile = company.getPhoneMobile();
        this.phoneLine = company.getPhoneLine();
        this.settlementAccount = company.getSettlementAccount();
        this.bankDetails = company.getBankDetails();
        this.okonh = company.getOkonh();
        this.inn = company.getInn();
        this.contact = company.getContact();
        this.contactPhoneMobile = company.getContactPhoneMobile();
        this.contactEmail = company.getContactEmail();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneMobile() {
        return phoneMobile;
    }

    public String getPhoneLine() {
        return phoneLine;
    }

    public String getSettlementAccount() {
        return settlementAccount;
    }

    public String getBankDetails() {
        return bankDetails;
    }

    public String getOkonh() {
        return okonh;
    }

    public String getInn() {
        return inn;
    }

    public String getContact() {
        return contact;
    }

    public String getContactPhoneMobile() {
        return contactPhoneMobile;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
