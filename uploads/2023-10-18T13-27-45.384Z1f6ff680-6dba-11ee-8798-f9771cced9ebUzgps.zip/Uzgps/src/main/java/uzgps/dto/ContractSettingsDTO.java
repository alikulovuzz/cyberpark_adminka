package uzgps.dto;

import uzgps.persistence.ContractSettings;

import java.io.Serializable;

/**
 * Created by NETEX on 15.06.2017.
 */
public class ContractSettingsDTO implements Serializable, BasedDTO {
    private Long id;
    private Long contractId;
    private Long mapType;
    private Boolean saveCurrentPosition;
    private Boolean showNamePoi;
    private Boolean bindingTracksToMap;
    private Boolean showNameGeoZone;
    private Long objectLabel;
    private Boolean objectNameMonitoring;
    private Boolean objectNameTracking;
    private Boolean typeTrackerMonitoring;
    private Boolean typeTrackerTracking;
    private Boolean trackerIdMonitoring;
    private Boolean trackerIdTracking;
    private Boolean trackerPhoneNumberMonitoring;
    private Boolean trackerPhoneNumberTracking;
    private Boolean objectTypeMonitoring;
    private Boolean objectTypeTracking;
    private Boolean objectPlateNumberMonitoring;
    private Boolean objectPlateNumberTracking;
    private Boolean objectCapacityMonitoring;
    private Boolean objectCapacityTracking;
    private Boolean objectFuelMonitoring;
    private Boolean objectFuelTracking;
    private Boolean objectAddressMonitoring;
    private Boolean objectAddressTracking;
    private Boolean objectCoordinatesMonitoring;
    private Boolean objectCoordinatesTracking;
    private Boolean objectSpeedMonitoring;
    private Boolean objectSpeedTracking;
    private Boolean objectSatelliteMonitoring;
    private Boolean objectSatelliteTracking;
    private Boolean objectOdometerMonitoring;
    private Boolean objectOdometerTracking;
    private Boolean objectHourmeterMonitoring;
    private Boolean objectHourmeterTracking;
    private Boolean beingGeozonMonitoring;
    private Boolean beingGeozonTracking;
    private Boolean designRoutMonitoring;
    private Boolean designRoutTracking;
    private Boolean nameStaffMonitoring;
    private Boolean nameStaffTracking;
    private Boolean photoStaffMonitoring;
    private Boolean photoStaffTracking;
    private Boolean phoneStaffMonitoring;
    private Boolean phoneStaffTracking;
    private Boolean objectStatusView;
    private Integer objectStatusPosition;
    private Boolean ignitionSensorView;
    private Integer ignitionSensorPosition;
    private Boolean objectLinkView;
    private Integer objectLinkPosition;
    private Boolean satelliteVisibilityView;
    private Integer satelliteVisibilityPosition;
    private Boolean objectDriverView;
    private Integer objectDriverPosition;
    private Boolean sensorStateView;
    private Integer sensorStatePosition;
    private Boolean objectMassageView;
    private Integer objectMassagePosition;
    private Boolean buildTrackView;
    private Integer buildTrackPosition;
    private Boolean reportView;
    private Integer reportPosition;
    private Boolean smsSendView;
    private Integer smsSendPosition;
    private Boolean objectPropertiesView;
    private Integer objectPropertiesPosition;
    private Long fastTrackType;
    private Long fastTrackValue;
    private Boolean deletePrevTrack;
    private Integer dottedLineThickness;
    private Integer linearLineThickness;
    private Long trackLengthType;
    private Long trackLengthValue;
    private String trackLengthColor;
    private Long mappingObjectType;
    private Long tooltipsViewQuantity;
    private Boolean tooltipsMassagesView;
    private String tooltipsMassagesColor;
    private Boolean tooltipsSmsView;
    private String tooltipsSmsColor;
    private Boolean tooltipsCommandView;
    private String tooltipsCommandColor;
    private Boolean tooltipsEventView;
    private String tooltipsEventColor;
    private Integer monitoringRefreshInterval;
    private Boolean lastTrackTimestamp;
    private Boolean fuelMonitoring;
    private Boolean fuelTracking;
    private Boolean assignedRouteMonitoring;
    private Boolean assignedRouteTracking;
    private Boolean bakPositionView;
    private Integer bakPosition;
    private Integer viewMessage;
    private Integer viewNextMessage;
    private Integer viewTrack;
    private Integer viewNextTrack;
    private Integer trackingValuesPart1;
    private Integer trackingValuesPart2;
    private Integer trackingValuesPart3;
    private Integer messageValuesPart1;
    private Integer messageValuesPart2;
    private Integer messageValuesPart3;
    private Integer monitoringValuesPart1;
    private Integer monitoringValuesPart2;
    private Integer monitoringValuesPart3;
    private Integer trackPopupValuesPart1;
    private Integer trackPopupValuesPart2;
    private Integer trackPopupValuesPart3;
    private Integer parkingPopupValuesPart1;
    private Integer sosPopupValuesPart1;
    private Integer sosPopupValuesPart2;
    private Integer sosPopupValuesPart3;

    public ContractSettingsDTO(ContractSettings contractSettings) {
        this.id = contractSettings.getId();
        this.contractId = contractSettings.getContractId();
        this.mapType = contractSettings.getMapType();
        this.saveCurrentPosition = contractSettings.getSaveCurrentPosition();
        this.showNamePoi = contractSettings.getShowNamePoi();
        this.bindingTracksToMap = contractSettings.getBindingTracksToMap();
        this.showNameGeoZone = contractSettings.getShowNameGeoZone();
        this.objectLabel = contractSettings.getObjectLabel();
        this.objectNameMonitoring = contractSettings.getObjectNameMonitoring();
        this.objectNameTracking = contractSettings.getObjectNameTracking();
        this.typeTrackerMonitoring = contractSettings.getTypeTrackerMonitoring();
        this.typeTrackerTracking = contractSettings.getTypeTrackerTracking();
        this.trackerIdMonitoring = contractSettings.getTrackerIdMonitoring();
        this.trackerIdTracking = contractSettings.getTrackerIdTracking();
        this.trackerPhoneNumberMonitoring = contractSettings.getTrackerPhoneNumberMonitoring();
        this.trackerPhoneNumberTracking = contractSettings.getTrackerPhoneNumberTracking();
        this.objectTypeMonitoring = contractSettings.getObjectTypeMonitoring();
        this.objectTypeTracking = contractSettings.getObjectTypeTracking();
        this.objectPlateNumberMonitoring = contractSettings.getObjectPlateNumberMonitoring();
        this.objectPlateNumberTracking = contractSettings.getObjectPlateNumberTracking();
        this.objectCapacityMonitoring = contractSettings.getObjectCapacityMonitoring();
        this.objectCapacityTracking = contractSettings.getObjectCapacityTracking();
        this.objectFuelMonitoring = contractSettings.getObjectFuelMonitoring();
        this.objectFuelTracking = contractSettings.getObjectFuelTracking();
        this.objectAddressMonitoring = contractSettings.getObjectAddressMonitoring();
        this.objectAddressTracking = contractSettings.getObjectAddressTracking();
        this.objectCoordinatesMonitoring = contractSettings.getObjectCoordinatesMonitoring();
        this.objectCoordinatesTracking = contractSettings.getObjectCoordinatesTracking();
        this.objectSpeedMonitoring = contractSettings.getObjectSpeedMonitoring();
        this.objectSpeedTracking = contractSettings.getObjectSpeedTracking();
        this.objectSatelliteMonitoring = contractSettings.getObjectSatelliteMonitoring();
        this.objectSatelliteTracking = contractSettings.getObjectSatelliteTracking();
        this.objectOdometerMonitoring = contractSettings.getObjectOdometerMonitoring();
        this.objectOdometerTracking = contractSettings.getObjectOdometerTracking();
        this.objectHourmeterMonitoring = contractSettings.getObjectHourmeterMonitoring();
        this.objectHourmeterTracking = contractSettings.getObjectHourmeterTracking();
        this.beingGeozonMonitoring = contractSettings.getBeingGeozonMonitoring();
        this.beingGeozonTracking = contractSettings.getBeingGeozonTracking();
        this.designRoutMonitoring = contractSettings.getDesignRoutMonitoring();
        this.designRoutTracking = contractSettings.getDesignRoutTracking();
        this.nameStaffMonitoring = contractSettings.getNameStaffMonitoring();
        this.nameStaffTracking = contractSettings.getNameStaffTracking();
        this.photoStaffMonitoring = contractSettings.getPhotoStaffMonitoring();
        this.photoStaffTracking = contractSettings.getPhotoStaffTracking();
        this.phoneStaffMonitoring = contractSettings.getPhoneStaffMonitoring();
        this.phoneStaffTracking = contractSettings.getPhoneStaffTracking();
        this.objectStatusView = contractSettings.getObjectStatusView();
        this.objectStatusPosition = contractSettings.getObjectStatusPosition();
        this.ignitionSensorView = contractSettings.getIgnitionSensorView();
        this.ignitionSensorPosition = contractSettings.getIgnitionSensorPosition();
        this.objectLinkView = contractSettings.getObjectLinkView();
        this.objectLinkPosition = contractSettings.getObjectLinkPosition();
        this.satelliteVisibilityView = contractSettings.getSatelliteVisibilityView();
        this.satelliteVisibilityPosition = contractSettings.getSatelliteVisibilityPosition();
        this.objectDriverView = contractSettings.getObjectDriverView();
        this.objectDriverPosition = contractSettings.getObjectDriverPosition();
        this.sensorStateView = contractSettings.getSensorStateView();
        this.sensorStatePosition = contractSettings.getSensorStatePosition();
        this.objectMassageView = contractSettings.getObjectMassageView();
        this.objectMassagePosition = contractSettings.getObjectMassagePosition();
        this.buildTrackView = contractSettings.getBuildTrackView();
        this.buildTrackPosition = contractSettings.getBuildTrackPosition();
        this.reportView = contractSettings.getReportView();
        this.reportPosition = contractSettings.getReportPosition();
        this.smsSendView = contractSettings.getSmsSendView();
        this.smsSendPosition = contractSettings.getSmsSendPosition();
        this.objectPropertiesView = contractSettings.getObjectPropertiesView();
        this.objectPropertiesPosition = contractSettings.getObjectPropertiesPosition();
        this.fastTrackType = contractSettings.getFastTrackType();
        this.fastTrackValue = contractSettings.getFastTrackValue();
        this.deletePrevTrack = contractSettings.getDeletePrevTrack();
        this.dottedLineThickness = contractSettings.getDottedLineThickness();
        this.linearLineThickness = contractSettings.getLinearLineThickness();
        this.trackLengthType = contractSettings.getTrackLengthType();
        this.trackLengthValue = contractSettings.getTrackLengthValue();
        this.trackLengthColor = contractSettings.getTrackLengthColor();
        this.mappingObjectType = contractSettings.getMappingObjectType();
        this.tooltipsViewQuantity = contractSettings.getTooltipsViewQuantity();
        this.tooltipsMassagesView = contractSettings.getTooltipsMassagesView();
        this.tooltipsMassagesColor = contractSettings.getTooltipsMassagesColor();
        this.tooltipsSmsView = contractSettings.getTooltipsSmsView();
        this.tooltipsSmsColor = contractSettings.getTooltipsSmsColor();
        this.tooltipsCommandView = contractSettings.getTooltipsCommandView();
        this.tooltipsCommandColor = contractSettings.getTooltipsCommandColor();
        this.tooltipsEventView = contractSettings.getTooltipsEventView();
        this.tooltipsEventColor = contractSettings.getTooltipsEventColor();
        this.monitoringRefreshInterval = contractSettings.getMonitoringRefreshInterval();
        this.lastTrackTimestamp = contractSettings.getLastTrackTimestamp();
        this.fuelMonitoring = contractSettings.getFuelMonitoring();
        this.fuelTracking = contractSettings.getFuelTracking();
        this.assignedRouteMonitoring = contractSettings.getAssignedRouteMonitoring();
        this.assignedRouteTracking = contractSettings.getAssignedRouteTracking();
        this.bakPositionView = contractSettings.getBakPositionView();
        this.bakPosition = contractSettings.getBakPosition();
        this.viewMessage = contractSettings.getViewMessage();
        this.viewNextMessage = contractSettings.getViewNextMessage();
        this.viewTrack = contractSettings.getViewTrack();
        this.viewNextTrack = contractSettings.getViewNextTrack();
        this.trackingValuesPart1 = contractSettings.getTrackingValuesPart1();
        this.trackingValuesPart2 = contractSettings.getTrackingValuesPart2();
        this.trackingValuesPart3 = contractSettings.getTrackingValuesPart3();
        this.messageValuesPart1 = contractSettings.getMessageValuesPart1();
        this.messageValuesPart2 = contractSettings.getMessageValuesPart2();
        this.messageValuesPart3 = contractSettings.getMessageValuesPart3();
        this.monitoringValuesPart1 = contractSettings.getMonitoringValuesPart1();
        this.monitoringValuesPart2 = contractSettings.getMonitoringValuesPart2();
        this.monitoringValuesPart3 = contractSettings.getMonitoringValuesPart3();
        this.trackPopupValuesPart1 = contractSettings.getTrackPopupValuesPart1();
        this.trackPopupValuesPart2 = contractSettings.getTrackPopupValuesPart2();
        this.trackPopupValuesPart3 = contractSettings.getTrackPopupValuesPart3();
        this.parkingPopupValuesPart1 = contractSettings.getParkingPopupValuesPart1();
        this.sosPopupValuesPart1 = contractSettings.getSosPopupValuesPart1();
        this.sosPopupValuesPart2 = contractSettings.getSosPopupValuesPart2();
        this.sosPopupValuesPart3 = contractSettings.getSosPopupValuesPart3();
    }

    public Long getId() {
        return id;
    }

    public Long getContractId() {
        return contractId;
    }

    public Long getMapType() {
        return mapType;
    }

    public Boolean getSaveCurrentPosition() {
        return saveCurrentPosition;
    }

    public Boolean getShowNamePoi() {
        return showNamePoi;
    }

    public Boolean getBindingTracksToMap() {
        return bindingTracksToMap;
    }

    public Boolean getShowNameGeoZone() {
        return showNameGeoZone;
    }

    public Long getObjectLabel() {
        return objectLabel;
    }

    public Boolean getObjectNameMonitoring() {
        return objectNameMonitoring;
    }

    public Boolean getObjectNameTracking() {
        return objectNameTracking;
    }

    public Boolean getTypeTrackerMonitoring() {
        return typeTrackerMonitoring;
    }

    public Boolean getTypeTrackerTracking() {
        return typeTrackerTracking;
    }

    public Boolean getTrackerIdMonitoring() {
        return trackerIdMonitoring;
    }

    public Boolean getTrackerIdTracking() {
        return trackerIdTracking;
    }

    public Boolean getTrackerPhoneNumberMonitoring() {
        return trackerPhoneNumberMonitoring;
    }

    public Boolean getTrackerPhoneNumberTracking() {
        return trackerPhoneNumberTracking;
    }

    public Boolean getObjectTypeMonitoring() {
        return objectTypeMonitoring;
    }

    public Boolean getObjectTypeTracking() {
        return objectTypeTracking;
    }

    public Boolean getObjectPlateNumberMonitoring() {
        return objectPlateNumberMonitoring;
    }

    public Boolean getObjectPlateNumberTracking() {
        return objectPlateNumberTracking;
    }

    public Boolean getObjectCapacityMonitoring() {
        return objectCapacityMonitoring;
    }

    public Boolean getObjectCapacityTracking() {
        return objectCapacityTracking;
    }

    public Boolean getObjectFuelMonitoring() {
        return objectFuelMonitoring;
    }

    public Boolean getObjectFuelTracking() {
        return objectFuelTracking;
    }

    public Boolean getObjectAddressMonitoring() {
        return objectAddressMonitoring;
    }

    public Boolean getObjectAddressTracking() {
        return objectAddressTracking;
    }

    public Boolean getObjectCoordinatesMonitoring() {
        return objectCoordinatesMonitoring;
    }

    public Boolean getObjectCoordinatesTracking() {
        return objectCoordinatesTracking;
    }

    public Boolean getObjectSpeedMonitoring() {
        return objectSpeedMonitoring;
    }

    public Boolean getObjectSpeedTracking() {
        return objectSpeedTracking;
    }

    public Boolean getObjectSatelliteMonitoring() {
        return objectSatelliteMonitoring;
    }

    public Boolean getObjectSatelliteTracking() {
        return objectSatelliteTracking;
    }

    public Boolean getObjectOdometerMonitoring() {
        return objectOdometerMonitoring;
    }

    public Boolean getObjectOdometerTracking() {
        return objectOdometerTracking;
    }

    public Boolean getObjectHourmeterMonitoring() {
        return objectHourmeterMonitoring;
    }

    public Boolean getObjectHourmeterTracking() {
        return objectHourmeterTracking;
    }

    public Boolean getBeingGeozonMonitoring() {
        return beingGeozonMonitoring;
    }

    public Boolean getBeingGeozonTracking() {
        return beingGeozonTracking;
    }

    public Boolean getDesignRoutMonitoring() {
        return designRoutMonitoring;
    }

    public Boolean getDesignRoutTracking() {
        return designRoutTracking;
    }

    public Boolean getNameStaffMonitoring() {
        return nameStaffMonitoring;
    }

    public Boolean getNameStaffTracking() {
        return nameStaffTracking;
    }

    public Boolean getPhotoStaffMonitoring() {
        return photoStaffMonitoring;
    }

    public Boolean getPhotoStaffTracking() {
        return photoStaffTracking;
    }

    public Boolean getPhoneStaffMonitoring() {
        return phoneStaffMonitoring;
    }

    public Boolean getPhoneStaffTracking() {
        return phoneStaffTracking;
    }

    public Boolean getObjectStatusView() {
        return objectStatusView;
    }

    public Integer getObjectStatusPosition() {
        return objectStatusPosition;
    }

    public Boolean getIgnitionSensorView() {
        return ignitionSensorView;
    }

    public Integer getIgnitionSensorPosition() {
        return ignitionSensorPosition;
    }

    public Boolean getObjectLinkView() {
        return objectLinkView;
    }

    public Integer getObjectLinkPosition() {
        return objectLinkPosition;
    }

    public Boolean getSatelliteVisibilityView() {
        return satelliteVisibilityView;
    }

    public Integer getSatelliteVisibilityPosition() {
        return satelliteVisibilityPosition;
    }

    public Boolean getObjectDriverView() {
        return objectDriverView;
    }

    public Integer getObjectDriverPosition() {
        return objectDriverPosition;
    }

    public Boolean getSensorStateView() {
        return sensorStateView;
    }

    public Integer getSensorStatePosition() {
        return sensorStatePosition;
    }

    public Boolean getObjectMassageView() {
        return objectMassageView;
    }

    public Integer getObjectMassagePosition() {
        return objectMassagePosition;
    }

    public Boolean getBuildTrackView() {
        return buildTrackView;
    }

    public Integer getBuildTrackPosition() {
        return buildTrackPosition;
    }

    public Boolean getReportView() {
        return reportView;
    }

    public Integer getReportPosition() {
        return reportPosition;
    }

    public Boolean getSmsSendView() {
        return smsSendView;
    }

    public Integer getSmsSendPosition() {
        return smsSendPosition;
    }

    public Boolean getObjectPropertiesView() {
        return objectPropertiesView;
    }

    public Integer getObjectPropertiesPosition() {
        return objectPropertiesPosition;
    }

    public Long getFastTrackType() {
        return fastTrackType;
    }

    public Long getFastTrackValue() {
        return fastTrackValue;
    }

    public Boolean getDeletePrevTrack() {
        return deletePrevTrack;
    }

    public Integer getDottedLineThickness() {
        return dottedLineThickness;
    }

    public Integer getLinearLineThickness() {
        return linearLineThickness;
    }

    public Long getTrackLengthType() {
        return trackLengthType;
    }

    public Long getTrackLengthValue() {
        return trackLengthValue;
    }

    public String getTrackLengthColor() {
        return trackLengthColor;
    }

    public Long getMappingObjectType() {
        return mappingObjectType;
    }

    public Long getTooltipsViewQuantity() {
        return tooltipsViewQuantity;
    }

    public Boolean getTooltipsMassagesView() {
        return tooltipsMassagesView;
    }

    public String getTooltipsMassagesColor() {
        return tooltipsMassagesColor;
    }

    public Boolean getTooltipsSmsView() {
        return tooltipsSmsView;
    }

    public String getTooltipsSmsColor() {
        return tooltipsSmsColor;
    }

    public Boolean getTooltipsCommandView() {
        return tooltipsCommandView;
    }

    public String getTooltipsCommandColor() {
        return tooltipsCommandColor;
    }

    public Boolean getTooltipsEventView() {
        return tooltipsEventView;
    }

    public String getTooltipsEventColor() {
        return tooltipsEventColor;
    }

    public Integer getMonitoringRefreshInterval() {
        return monitoringRefreshInterval;
    }

    public Boolean getLastTrackTimestamp() {
        return lastTrackTimestamp;
    }

    public Boolean getFuelMonitoring() {
        return fuelMonitoring;
    }

    public Boolean getFuelTracking() {
        return fuelTracking;
    }

    public Boolean getAssignedRouteMonitoring() {
        return assignedRouteMonitoring;
    }

    public Boolean getAssignedRouteTracking() {
        return assignedRouteTracking;
    }

    public Boolean getBakPositionView() {
        return bakPositionView;
    }

    public Integer getBakPosition() {
        return bakPosition;
    }

    public Integer getViewMessage() {
        return viewMessage;
    }

    public Integer getViewNextMessage() {
        return viewNextMessage;
    }

    public Integer getViewTrack() {
        return viewTrack;
    }

    public Integer getViewNextTrack() {
        return viewNextTrack;
    }

    public Integer getTrackingValuesPart1() {
        return trackingValuesPart1;
    }

    public Integer getTrackingValuesPart2() {
        return trackingValuesPart2;
    }

    public Integer getTrackingValuesPart3() {
        return trackingValuesPart3;
    }

    public Integer getMessageValuesPart1() {
        return messageValuesPart1;
    }

    public Integer getMessageValuesPart2() {
        return messageValuesPart2;
    }

    public Integer getMessageValuesPart3() {
        return messageValuesPart3;
    }

    public Integer getMonitoringValuesPart1() {
        return monitoringValuesPart1;
    }

    public Integer getMonitoringValuesPart2() {
        return monitoringValuesPart2;
    }

    public Integer getMonitoringValuesPart3() {
        return monitoringValuesPart3;
    }

    public Integer getTrackPopupValuesPart1() {
        return trackPopupValuesPart1;
    }

    public Integer getTrackPopupValuesPart2() {
        return trackPopupValuesPart2;
    }

    public Integer getTrackPopupValuesPart3() {
        return trackPopupValuesPart3;
    }

    public Integer getParkingPopupValuesPart1() {
        return parkingPopupValuesPart1;
    }

    public Integer getSosPopupValuesPart1() {
        return sosPopupValuesPart1;
    }

    public Integer getSosPopupValuesPart2() {
        return sosPopupValuesPart2;
    }

    public Integer getSosPopupValuesPart3() {
        return sosPopupValuesPart3;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
