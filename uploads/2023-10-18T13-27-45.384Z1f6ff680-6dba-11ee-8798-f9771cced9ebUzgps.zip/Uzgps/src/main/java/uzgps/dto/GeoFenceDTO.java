package uzgps.dto;

import uzgps.persistence.GeoFence;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class GeoFenceDTO implements Serializable, BasedDTO {
    private Long id;
    private Long contractId;
    private String status;
    private String name;
    private String fontColor;
    private Integer fontSize;
    private String type;
    private String color;
    private Float radius;
    private Double area;
    private Double perimeter;
    private Double geometryOpacity;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public GeoFenceDTO(GeoFence geoFence) {
        this.id = geoFence.getId();
        this.contractId = geoFence.getContractId();
        this.status = geoFence.getStatus();
        this.name = geoFence.getName();
        this.fontColor = geoFence.getFontColor();
        this.fontSize = geoFence.getFontSize();
        this.type = geoFence.getType();
        this.color = geoFence.getColor();
        this.radius = geoFence.getRadius();
        this.area = geoFence.getArea();
        this.perimeter = geoFence.getPerimeter();
        this.geometryOpacity = geoFence.getGeometryOpacity();
        this.regDate = geoFence.getRegDate();
        this.modDate = geoFence.getModDate();
        this.expDate = geoFence.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getContractId() {
        return contractId;
    }

    public String getStatus() {
        return status;
    }

    public String getName() {
        return name;
    }

    public String getFontColor() {
        return fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public String getType() {
        return type;
    }

    public String getColor() {
        return color;
    }

    public Float getRadius() {
        return radius;
    }

    public Double getArea() {
        return area;
    }

    public Double getPerimeter() {
        return perimeter;
    }

    public Double getGeometryOpacity() {
        return geometryOpacity;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
