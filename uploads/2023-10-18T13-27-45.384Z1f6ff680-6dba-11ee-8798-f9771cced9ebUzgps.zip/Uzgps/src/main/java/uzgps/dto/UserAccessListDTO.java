package uzgps.dto;

import uzgps.persistence.UserAccessList;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 16.06.2017.
 */
public class UserAccessListDTO implements Serializable, BasedDTO{
    private Long id;
    private Long userId;
    private Long contractId;
    private Integer map;
    private Integer monitoring;
    private Integer tracker;
    private Integer poi;
    private Integer geoZone;
    private Integer message;
    private Integer report;
    private Integer dashboard;
    private Integer settings;
    private Integer settingsMap;
    private Integer settingsMonitoring;
    private Integer settingsObject;
    private Integer settingsGroup;
    private Integer settingsStaff;
    private Integer settingsUsers;
    private Integer settingsNotifications;
    private Integer settingsDisplayData;

    private Integer settingsUserPoiZoiAccess;
    private Integer settingsDashboard;
    private Integer settingsExternalServices;

    private Integer routing;
    private Integer camera;
    private Integer agro;
    private Integer fms;

    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private Integer userAccessFull;
    private Integer userAccessNone;
    private Integer userAccessView;
    private Integer userAccessEdit;

    public UserAccessListDTO(UserAccessList userAccessList) {
        this.id = userAccessList.getId();
        this.userId = userAccessList.getUserId();
        this.contractId = userAccessList.getContract().getId();
        this.map = userAccessList.getMap();
        this.monitoring = userAccessList.getMonitoring();
        this.tracker = userAccessList.getTracker();
        this.poi = userAccessList.getPoi();
        this.geoZone = userAccessList.getGeoZone();
        this.message = userAccessList.getMessage();
        this.report = userAccessList.getReport();
        this.dashboard = userAccessList.getDashboard();
        this.settings = userAccessList.getSettings();
        this.settingsMap = userAccessList.getSettingsMap();
        this.settingsMonitoring = userAccessList.getSettingsMonitoring();
        this.settingsObject = userAccessList.getSettingsObject();
        this.settingsGroup = userAccessList.getSettingsGroup();
        this.settingsStaff = userAccessList.getSettingsStaff();
        this.settingsUsers = userAccessList.getSettingsUsers();
        this.settingsNotifications = userAccessList.getSettingsNotifications();
        this.settingsDisplayData = userAccessList.getSettingsDisplayData();

        this.settingsUserPoiZoiAccess = userAccessList.getSettingsUserPoiZoiAccess();
        this.settingsDashboard = userAccessList.getSettingsDashboard();
        this.settingsExternalServices = userAccessList.getSettingsExternalServices();

        this.routing = userAccessList.getRouting();
        this.camera = userAccessList.getCamera();
        this.agro = userAccessList.getAgro();
        this.fms = userAccessList.getFms();

        this.regDate = userAccessList.getRegDate();
        this.modDate = userAccessList.getModDate();
        this.expDate = userAccessList.getExpDate();
        this.userAccessFull = userAccessList.getUserAccessFull();
        this.userAccessNone = userAccessList.getUserAccessNone();
        this.userAccessView = userAccessList.getUserAccessView();
        this.userAccessEdit = userAccessList.getUserAccessEdit();
    }

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public Long getContractId() {
        return contractId;
    }

    public Integer getMap() {
        return map;
    }

    public Integer getMonitoring() {
        return monitoring;
    }

    public Integer getTracker() {
        return tracker;
    }

    public Integer getPoi() {
        return poi;
    }

    public Integer getGeoZone() {
        return geoZone;
    }

    public Integer getMessage() {
        return message;
    }

    public Integer getReport() {
        return report;
    }

    public Integer getSettings() {
        return settings;
    }

    public Integer getSettingsMap() {
        return settingsMap;
    }

    public Integer getSettingsMonitoring() {
        return settingsMonitoring;
    }

    public Integer getSettingsObject() {
        return settingsObject;
    }

    public Integer getSettingsGroup() {
        return settingsGroup;
    }

    public Integer getSettingsStaff() {
        return settingsStaff;
    }

    public Integer getSettingsUsers() {
        return settingsUsers;
    }

    public Integer getSettingsNotifications() {
        return settingsNotifications;
    }

    public Integer getSettingsDisplayData() {
        return settingsDisplayData;
    }

    public Integer getRouting() {
        return routing;
    }

//    public Integer getTrackStatistics() {
//        return trackStatistics;
//    }



    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public Integer getUserAccessFull() {
        return userAccessFull;
    }

    public Integer getUserAccessNone() {
        return userAccessNone;
    }

    public Integer getUserAccessView() {
        return userAccessView;
    }

    public Integer getUserAccessEdit() {
        return userAccessEdit;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
