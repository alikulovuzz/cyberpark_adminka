package uzgps.dto;

import uzgps.persistence.UserMObjectAccessList;

import java.io.Serializable;

/**
 * Created by NETEX on 16.06.2017.
 */
public class UserMObjectAccessListDTO implements Serializable, BasedDTO{
    private Long id;
    private Long userId;
    private Long mObjectId;
    private Integer permission;

    public UserMObjectAccessListDTO(UserMObjectAccessList userMObjectAccessList) {
        this.id = userMObjectAccessList.getId();
        this.userId = userMObjectAccessList.getUserId();
        this.mObjectId = userMObjectAccessList.getmObjectId();
        this.permission = userMObjectAccessList.getPermission();
    }

    public Long getId() {
        return id;
    }

    public Long getUserId() {
        return userId;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public Integer getPermission() {
        return permission;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
