package uzgps.dto;

import uzgps.persistence.MobileTrackerSettings;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class MobileTrackerSettingsDTO implements Serializable, BasedDTO{
    private Long id;
    private Long mObjectId;
    private String mobileSerial;
    private Boolean hasPassword;
    private Integer password;
    private Integer locationProfile;
    private Integer locationUpdateTime;
    private Integer locationUpdateDistance;
    private Integer locationUpdateAccuracy;
    private Integer locationUpdateAngle;
    private Boolean shouldChangeStatus;
    private Integer recordLimit;
    private Integer locationSendTime;
    private Boolean shouldSend3G;
    private Boolean shouldSendWiFi;
    private Integer trackLength;
    private String sosNumber1;
    private String sosNumber2;
    private String sosNumber3;
    private String sosNumber4;
    private String sosNumber5;
    private String sosNumber6;
    private String sosNumber7;
    private Integer mapType;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public MobileTrackerSettingsDTO(MobileTrackerSettings mobileTrackerSettings) {
        this.id = mobileTrackerSettings.getId();
        this.mObjectId = mobileTrackerSettings.getmObjectId();
        this.mobileSerial = mobileTrackerSettings.getMobileSerial();
        this.hasPassword = mobileTrackerSettings.getHasPassword();
        this.password = mobileTrackerSettings.getPassword();
        this.locationProfile = mobileTrackerSettings.getLocationProfile();
        this.locationUpdateTime = mobileTrackerSettings.getLocationUpdateTime();
        this.locationUpdateDistance = mobileTrackerSettings.getLocationUpdateDistance();
        this.locationUpdateAccuracy = mobileTrackerSettings.getLocationUpdateAccuracy();
        this.locationUpdateAngle = mobileTrackerSettings.getLocationUpdateAngle();
        this.shouldChangeStatus = mobileTrackerSettings.getShouldChangeStatus();
        this.recordLimit = mobileTrackerSettings.getRecordLimit();
        this.locationSendTime = mobileTrackerSettings.getLocationSendTime();
        this.shouldSend3G = mobileTrackerSettings.getShouldSend3G();
        this.shouldSendWiFi = mobileTrackerSettings.getShouldSendWiFi();
        this.trackLength = mobileTrackerSettings.getTrackLength();
        this.sosNumber1 = mobileTrackerSettings.getSosNumber1();
        this.sosNumber2 = mobileTrackerSettings.getSosNumber2();
        this.sosNumber3 = mobileTrackerSettings.getSosNumber3();
        this.sosNumber4 = mobileTrackerSettings.getSosNumber4();
        this.sosNumber5 = mobileTrackerSettings.getSosNumber5();
        this.sosNumber6 = mobileTrackerSettings.getSosNumber6();
        this.sosNumber7 = mobileTrackerSettings.getSosNumber7();
        this.mapType = mobileTrackerSettings.getMapType();
        this.status = mobileTrackerSettings.getStatus();
        this.regDate = mobileTrackerSettings.getRegDate();
        this.modDate = mobileTrackerSettings.getModDate();
        this.expDate = mobileTrackerSettings.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public String getMobileSerial() {
        return mobileSerial;
    }

    public Boolean getHasPassword() {
        return hasPassword;
    }

    public Integer getPassword() {
        return password;
    }

    public Integer getLocationProfile() {
        return locationProfile;
    }

    public Integer getLocationUpdateTime() {
        return locationUpdateTime;
    }

    public Integer getLocationUpdateDistance() {
        return locationUpdateDistance;
    }

    public Integer getLocationUpdateAccuracy() {
        return locationUpdateAccuracy;
    }

    public Integer getLocationUpdateAngle() {
        return locationUpdateAngle;
    }

    public Boolean getShouldChangeStatus() {
        return shouldChangeStatus;
    }

    public Integer getRecordLimit() {
        return recordLimit;
    }

    public Integer getLocationSendTime() {
        return locationSendTime;
    }

    public Boolean getShouldSend3G() {
        return shouldSend3G;
    }

    public Boolean getShouldSendWiFi() {
        return shouldSendWiFi;
    }

    public Integer getTrackLength() {
        return trackLength;
    }

    public String getSosNumber1() {
        return sosNumber1;
    }

    public String getSosNumber2() {
        return sosNumber2;
    }

    public String getSosNumber3() {
        return sosNumber3;
    }

    public String getSosNumber4() {
        return sosNumber4;
    }

    public String getSosNumber5() {
        return sosNumber5;
    }

    public String getSosNumber6() {
        return sosNumber6;
    }

    public String getSosNumber7() {
        return sosNumber7;
    }

    public Integer getMapType() {
        return mapType;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public String toString() {
        return "MobileTrackerSettingsDTO{" +
                "id=" + id +
                ", mObjectId=" + mObjectId +
                ", mobileSerial='" + mobileSerial + '\'' +
                ", hasPassword=" + hasPassword +
                ", password=" + password +
                ", locationProfile=" + locationProfile +
                ", locationUpdateTime=" + locationUpdateTime +
                ", locationUpdateDistance=" + locationUpdateDistance +
                ", locationUpdateAccuracy=" + locationUpdateAccuracy +
                ", locationUpdateAngle=" + locationUpdateAngle +
                ", shouldChangeStatus=" + shouldChangeStatus +
                ", recordLimit=" + recordLimit +
                ", locationSendTime=" + locationSendTime +
                ", shouldSend3G=" + shouldSend3G +
                ", shouldSendWiFi=" + shouldSendWiFi +
                ", trackLength=" + trackLength +
                ", sosNumber1='" + sosNumber1 + '\'' +
                ", sosNumber2='" + sosNumber2 + '\'' +
                ", sosNumber3='" + sosNumber3 + '\'' +
                ", sosNumber4='" + sosNumber4 + '\'' +
                ", sosNumber5='" + sosNumber5 + '\'' +
                ", sosNumber6='" + sosNumber6 + '\'' +
                ", sosNumber7='" + sosNumber7 + '\'' +
                ", mapType=" + mapType +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
