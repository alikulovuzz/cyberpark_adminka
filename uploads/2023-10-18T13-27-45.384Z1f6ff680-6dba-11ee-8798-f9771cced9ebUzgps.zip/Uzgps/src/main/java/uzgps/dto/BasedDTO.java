package uzgps.dto;

/**
 * Created by NETEX on 15.06.2017.
 */
public interface BasedDTO {

    public long returnObjectId();
}
