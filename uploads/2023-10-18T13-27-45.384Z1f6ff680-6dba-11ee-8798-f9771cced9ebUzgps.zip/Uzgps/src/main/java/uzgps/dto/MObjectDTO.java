package uzgps.dto;

import uzgps.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class MObjectDTO implements Serializable, BasedDTO{
    private Long id;
    private String mObjectName;
    private Long mObjectGroupId;
    private Long mObjectContractId;
    private Long mobileTrackerStatusId;
    private MobileTrackerStatus mobileTrackerStatus;
    private String mObjectType;
    private String mObjectPlateNumber;
    private Long photoId;
    private Boolean defaultIcon;
    private Long pinId;
    private String sysAdminNote;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public MObjectDTO(MObject mObject) {
        this.id                     = mObject.getId();
        this.mObjectName            = mObject.getmObjectName();
        this.mObjectGroupId         = mObject.getmObjectGroupId();
        this.mObjectContractId      = mObject.getmObjectContractId();
        this.mobileTrackerStatusId  = mObject.getMobileTrackerStatusId();
        this.mobileTrackerStatus    = mObject.getMobileTrackerStatus();
        this.mObjectType            = mObject.getmObjectType();
        this.mObjectPlateNumber     = mObject.getmObjectPlateNumber();
        this.photoId                = mObject.getPhotoId();
        this.defaultIcon            = mObject.getDefaultIcon();
        this.pinId                  = mObject.getPinId();
        this.sysAdminNote           = mObject.getSysAdminNote();
        this.status                 = mObject.getStatus();
        this.regDate                = mObject.getRegDate();
        this.modDate                = mObject.getModDate();
        this.expDate                = mObject.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public String getmObjectName() {
        return mObjectName;
    }

    public Long getmObjectGroupId() {
        return mObjectGroupId;
    }

    public Long getmObjectContractId() {
        return mObjectContractId;
    }

    public Long getMobileTrackerStatusId() {
        return mobileTrackerStatusId;
    }

    public MobileTrackerStatus getMobileTrackerStatus() {
        return mobileTrackerStatus;
    }

    public String getmObjectType() {
        return mObjectType;
    }

    public String getmObjectPlateNumber() {
        return mObjectPlateNumber;
    }

    public Long getPhotoId() {
        return photoId;
    }

    public Boolean getDefaultIcon() {
        return defaultIcon;
    }

    public Long getPinId() {
        return pinId;
    }

    public String getSysAdminNote() {
        return sysAdminNote;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public String toString() {
        return "MObjectDTO{" +
                "id=" + id +
                ", mObjectName='" + mObjectName + '\'' +
                ", mObjectGroupId=" + mObjectGroupId +
                ", mObjectContractId=" + mObjectContractId +
                ", mobileTrackerStatusId=" + mobileTrackerStatusId +
                ", mobileTrackerStatus=" + mobileTrackerStatus +
                ", mObjectType='" + mObjectType + '\'' +
                ", mObjectPlateNumber='" + mObjectPlateNumber + '\'' +
                ", photoId=" + photoId +
                ", defaultIcon=" + defaultIcon +
                ", pinId=" + pinId +
                ", sysAdminNote='" + sysAdminNote + '\'' +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
