package uzgps.dto;

import uzgps.persistence.POI;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class POIDTO implements Serializable, BasedDTO {

    private Long id;
    private Long contractId;
    private String status;
    private String name;
    private String fontColor;
    private Integer fontSize;
    private Long imageId;
    private String description;
    private Double longitude;
    private Double latitude;
    private Float radius;
    private Boolean isCircleDisplayed;
    private String circleColor;
    private Float circleOpacity;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private String url;

    public POIDTO(POI poi) {
        this.id = poi.getId();
        this.contractId = poi.getContractId();
        this.status = poi.getStatus();
        this.name = poi.getName();
        this.fontColor = poi.getFontColor();
        this.fontSize = poi.getFontSize();
        this.imageId = poi.getImageId();
        this.description = poi.getDescription();
        this.longitude = poi.getLongitude();
        this.latitude = poi.getLatitude();
        this.radius = poi.getRadius();
        this.isCircleDisplayed = poi.getIsCircleDisplayed();
        this.circleColor = poi.getCircleColor();
        this.circleOpacity = poi.getCircleOpacity();
        this.regDate = poi.getRegDate();
        this.modDate = poi.getModDate();
        this.expDate = poi.getExpDate();
        this.url = poi.getUrl();
    }

    public Long getId() {
        return id;
    }

    public Long getContractId() {
        return contractId;
    }

    public String getStatus() {
        return status;
    }

    public String getName() {
        return name;
    }

    public String getFontColor() {
        return fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public Long getImageId() {
        return imageId;
    }

    public String getDescription() {
        return description;
    }

    public Double getLongitude() {
        return longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Float getRadius() {
        return radius;
    }

    public Boolean getCircleDisplayed() {
        return isCircleDisplayed;
    }

    public String getCircleColor() {
        return circleColor;
    }

    public Float getCircleOpacity() {
        return circleOpacity;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public String getUrl() {
        return url;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
