package uzgps.dto;

import uzgps.persistence.GPSUnit;
import uzgps.persistence.Sim;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by NETEX on 15.06.2017.
 */
public class GPSUnitDTO implements Serializable, BasedDTO{
    private Long id;
    private String name;
    private String imei;
    private Long gpsUnitTypId;
    private String gpsUnitLogin;
    private String gpsUnitPassword;
    private String block;
    private Integer dMin;
    private Integer dBig;
    private Integer tBig;
    private Integer isMobile;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private String sysAdminNote;

    public GPSUnitDTO(GPSUnit gpsUnit) {
        this.id = gpsUnit.getId();
        this.name = gpsUnit.getName();
        this.imei = gpsUnit.getImei();
        this.gpsUnitTypId = gpsUnit.getGpsUnitTypId();
        this.gpsUnitLogin = gpsUnit.getGpsUnitLogin();
        this.gpsUnitPassword = gpsUnit.getGpsUnitPassword();
        this.block = gpsUnit.getBlock();
        this.dMin = gpsUnit.getdMin();
        this.dBig = gpsUnit.getdBig();
        this.tBig = gpsUnit.gettBig();
        this.isMobile = gpsUnit.getIsMobile();
        this.status = gpsUnit.getStatus();
        this.regDate = gpsUnit.getRegDate();
        this.modDate = gpsUnit.getModDate();
        this.expDate = gpsUnit.getExpDate();
        this.sysAdminNote = gpsUnit.getSysAdminNote();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getImei() {
        return imei;
    }

    public Long getGpsUnitTypId() {
        return gpsUnitTypId;
    }

    public String getGpsUnitLogin() {
        return gpsUnitLogin;
    }

    public String getGpsUnitPassword() {
        return gpsUnitPassword;
    }

    public String getBlock() {
        return block;
    }

    public Integer getdMin() {
        return dMin;
    }

    public Integer getdBig() {
        return dBig;
    }

    public Integer gettBig() {
        return tBig;
    }

    public Integer getIsMobile() {
        return isMobile;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public String getSysAdminNote() {
        return sysAdminNote;
    }

    @Override
    public String toString() {
        return "GPSUnitDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", imei='" + imei + '\'' +
                ", gpsUnitTypId=" + gpsUnitTypId +
                ", gpsUnitLogin='" + gpsUnitLogin + '\'' +
                ", gpsUnitPassword='" + gpsUnitPassword + '\'' +
                ", block='" + block + '\'' +
                ", dMin=" + dMin +
                ", dBig=" + dBig +
                ", tBig=" + tBig +
                ", isMobile=" + isMobile +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                ", sysAdminNote='" + sysAdminNote + '\'' +
                '}';
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
