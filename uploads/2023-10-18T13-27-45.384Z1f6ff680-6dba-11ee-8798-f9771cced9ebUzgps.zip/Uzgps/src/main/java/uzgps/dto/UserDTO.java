package uzgps.dto;

import uzgps.persistence.User;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class UserDTO implements Serializable, BasedDTO {
    private Long id;
    private Long managerId;
    private Long profileId;
    private Long userTypeId;
    private String login;
    private String surName;
    private String name;
    private String middleName;
    private Long photoId;
    private Long contractId;
    private Timestamp lastLoggedIn;
    private String block;
    private Integer loginAttemp;
    private Long roleId;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private String sysAdminNote;
    private String operatorLogin;
    private Long interfaceUserId;

    public UserDTO(User user) {
        this.id = user.getId();
        this.managerId = user.getManagerId();
        this.profileId = user.getProfileId();
        this.userTypeId = user.getUserTypeId();
        this.login = user.getLogin();
        this.surName = user.getSurName();
        this.name = user.getName();
        this.middleName = user.getMiddleName();
        this.photoId = user.getPhotoId();
        this.contractId = user.getContractId();
        this.lastLoggedIn = user.getLastLoggedIn();
        this.block = user.getBlock();
        this.loginAttemp = user.getLoginAttemp();
        this.roleId = user.getRoleId();
        this.status = user.getStatus();
        this.regDate = user.getRegDate();
        this.modDate = user.getModDate();
        this.expDate = user.getExpDate();
        this.sysAdminNote = user.getSysAdminNote();
        this.operatorLogin = user.getOperatorLogin();
        this.interfaceUserId = user.getInterfaceUserId();
    }

    public Long getId() {
        return id;
    }

    public Long getManagerId() {
        return managerId;
    }

    public Long getProfileId() {
        return profileId;
    }

    public Long getUserTypeId() {
        return userTypeId;
    }

    public String getLogin() {
        return login;
    }

    public String getSurName() {
        return surName;
    }

    public String getName() {
        return name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public Long getPhotoId() {
        return photoId;
    }

    public Long getContractId() {
        return contractId;
    }

    public Timestamp getLastLoggedIn() {
        return lastLoggedIn;
    }

    public String getBlock() {
        return block;
    }

    public Integer getLoginAttemp() {
        return loginAttemp;
    }

    public Long getRoleId() {
        return roleId;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public String getSysAdminNote() {
        return sysAdminNote;
    }

    public String getOperatorLogin() {
        return operatorLogin;
    }

    public Long getInterfaceUserId() {
        return interfaceUserId;
    }

    public void setLoginAttemp(Integer loginAttemp) {
        this.loginAttemp = loginAttemp;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
