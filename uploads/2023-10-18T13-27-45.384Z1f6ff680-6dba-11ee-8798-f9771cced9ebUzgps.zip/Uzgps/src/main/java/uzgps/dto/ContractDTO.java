package uzgps.dto;

import uzgps.persistence.Contract;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class ContractDTO implements Serializable, BasedDTO {
    private Long id;
    private long companyId;
    private String contractNumber;
    private Timestamp contractRegDate;
    private String contractType;
    private Long existUnitCount;
    private Long activeMaxUnitCount;
    private Long activeMaxUserCount;
    private Long activeMaxStaffCount;
    private Long activeMaxPoiCount;
    private Long activeMaxGeoFanceCount;
    private Long maxUnitCount;
    private Long maxUserCount;
    private Long maxStaffCount;
    private Long maxPoiCount;
    private Long maxGeoFanceCount;
    private Long maxReportCount;
    private Long maxEmailCount;
    private Long maxSmsCount;
    private Long maxSmsCmdCount;
    private Boolean testContract;
    private String customerCompanyName;
    private String customerActsOnTheBasis;
    private Long customerRegion;
    private String customerLegalAddress;
    private String customerPostalAddress;
    private String customerPhone;
    private String customerPhoneMobile;
    private String customerFax;
    private String customerEmail;
    private String customerBankName;
    private String customerBankCode;
    private String customerAccount;
    private String customerINN;
    private String customerOKONH;
    private String position;
    private String directorSurname;
    private String directorName;
    private String directorMiddlename;
    private String directorPhone;
    private String directorEmail;
    private String note;
    private String customerSurname;
    private String customerName;
    private String customerMiddlename;
    private Long customerGender;
    private String customerDocumentType;
    private Timestamp customerBirthDate;
    private Long customerCitizenship;
    private String customerPassportSeries;
    private String customerPassportNumber;
    private String customerPassportIssuedBy;
    private Timestamp customerPassportExpireDate;
    private String customerRegistrationAddress;
    private Long statusId;
    private Timestamp expiredDate;
    private String block;
    private String status;
    private Timestamp registrationDate;
    private Timestamp modificationDate;
    private Timestamp beforeBlockingDate;
    private Timestamp lockedDate;
    private Timestamp suspendedSystemDate;
    private Timestamp pretensionDate;
    private Timestamp expiryDate;
    private String registrationDateFormatted;
    private Long balance;
    private Long paymentsInCurrentPeriod;
    private Long chargesInCurrentPeriod;
    private Timestamp lastPaymentDate;

    public ContractDTO(Contract contract) {
        this.id = contract.getId();
        this.companyId = contract.getCompanyId();
        this.contractNumber = contract.getContractNumber();
        this.contractRegDate = contract.getContractRegDate();
        this.contractType = contract.getContractType();
        this.existUnitCount = contract.getExistUnitCount();
        this.activeMaxUnitCount = contract.getActiveMaxUnitCount();
        this.activeMaxUserCount = contract.getActiveMaxUserCount();
        this.activeMaxStaffCount = contract.getActiveMaxStaffCount();
        this.activeMaxPoiCount = contract.getActiveMaxPoiCount();
        this.activeMaxGeoFanceCount = contract.getActiveMaxGeoFanceCount();
        this.maxUnitCount = contract.getMaxUnitCount();
        this.maxUserCount = contract.getMaxUserCount();
        this.maxStaffCount = contract.getMaxStaffCount();
        this.maxPoiCount = contract.getMaxPoiCount();
        this.maxGeoFanceCount = contract.getMaxGeoFanceCount();
        this.maxReportCount = contract.getMaxReportCount();
        this.maxEmailCount = contract.getMaxEmailCount();
        this.maxSmsCount = contract.getMaxSmsCount();
        this.maxSmsCmdCount = contract.getMaxSmsCmdCount();
        this.testContract = contract.getTestContract();
        this.customerCompanyName = contract.getCustomerCompanyName();
        this.customerActsOnTheBasis = contract.getCustomerActsOnTheBasis();
        this.customerRegion = contract.getCustomerRegion();
        this.customerLegalAddress = contract.getCustomerLegalAddress();
        this.customerPostalAddress = contract.getCustomerPostalAddress();
        this.customerPhone = contract.getCustomerPhone();
        this.customerPhoneMobile = contract.getCustomerPhoneMobile();
        this.customerFax = contract.getCustomerFax();
        this.customerEmail = contract.getCustomerEmail();
        this.customerBankName = contract.getCustomerBankName();
        this.customerBankCode = contract.getCustomerBankCode();
        this.customerAccount = contract.getCustomerAccount();
        this.customerINN = contract.getCustomerINN();
        this.customerOKONH = contract.getCustomerOKONH();
        this.position = contract.getPosition();
        this.directorSurname = contract.getDirectorSurname();
        this.directorName = contract.getDirectorName();
        this.directorMiddlename = contract.getDirectorMiddlename();
        this.directorPhone = contract.getDirectorPhone();
        this.directorEmail = contract.getDirectorEmail();
        this.note = contract.getNote();
        this.customerSurname = contract.getCustomerSurname();
        this.customerName = contract.getCustomerName();
        this.customerMiddlename = contract.getCustomerMiddlename();
        this.customerGender = contract.getCustomerGender();
        this.customerDocumentType = contract.getCustomerDocumentType();
        this.customerBirthDate = contract.getCustomerBirthDate();
        this.customerCitizenship = contract.getCustomerCitizenship();
        this.customerPassportSeries = contract.getCustomerPassportSeries();
        this.customerPassportNumber = contract.getCustomerPassportNumber();
        this.customerPassportIssuedBy = contract.getCustomerPassportIssuedBy();
        this.customerPassportExpireDate = contract.getCustomerPassportExpireDate();
        this.customerRegistrationAddress = contract.getCustomerRegistrationAddress();
        this.statusId = contract.getStatusId();
        this.expiredDate = contract.getExpiredDate();
        this.block = contract.getBlock();
        this.status = contract.getStatus();
        this.registrationDate = contract.getRegistrationDate();
        this.modificationDate = contract.getModificationDate();
        this.beforeBlockingDate = contract.getBeforeBlockingDate();
        this.lockedDate = contract.getLockedDate();
        this.suspendedSystemDate = contract.getSuspendedSystemDate();
        this.pretensionDate = contract.getPretensionDate();
        this.expiryDate = contract.getExpiryDate();
        this.registrationDateFormatted = contract.getRegistrationDateFormatted();
        this.balance = contract.getBalance();
        this.paymentsInCurrentPeriod = contract.getPaymentsInCurrentPeriod();
        this.chargesInCurrentPeriod = contract.getChargesInCurrentPeriod();
        this.lastPaymentDate = contract.getLastPaymentDate();
    }

    public Long getId() {
        return id;
    }

    public long getCompanyId() {
        return companyId;
    }

    public String getContractNumber() {
        return contractNumber;
    }

    public Timestamp getContractRegDate() {
        return contractRegDate;
    }

    public String getContractType() {
        return contractType;
    }

    public Long getExistUnitCount() {
        return existUnitCount;
    }

    public Long getActiveMaxUnitCount() {
        return activeMaxUnitCount;
    }

    public Long getActiveMaxUserCount() {
        return activeMaxUserCount;
    }

    public Long getActiveMaxStaffCount() {
        return activeMaxStaffCount;
    }

    public Long getActiveMaxPoiCount() {
        return activeMaxPoiCount;
    }

    public Long getActiveMaxGeoFanceCount() {
        return activeMaxGeoFanceCount;
    }

    public Long getMaxUnitCount() {
        return maxUnitCount;
    }

    public Long getMaxUserCount() {
        return maxUserCount;
    }

    public Long getMaxStaffCount() {
        return maxStaffCount;
    }

    public Long getMaxPoiCount() {
        return maxPoiCount;
    }

    public Long getMaxGeoFanceCount() {
        return maxGeoFanceCount;
    }

    public Long getMaxReportCount() {
        return maxReportCount;
    }

    public Long getMaxEmailCount() {
        return maxEmailCount;
    }

    public Long getMaxSmsCount() {
        return maxSmsCount;
    }

    public Long getMaxSmsCmdCount() {
        return maxSmsCmdCount;
    }

    public Boolean getTestContract() {
        return testContract;
    }

    public String getCustomerCompanyName() {
        return customerCompanyName;
    }

    public String getCustomerActsOnTheBasis() {
        return customerActsOnTheBasis;
    }

    public Long getCustomerRegion() {
        return customerRegion;
    }

    public String getCustomerLegalAddress() {
        return customerLegalAddress;
    }

    public String getCustomerPostalAddress() {
        return customerPostalAddress;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public String getCustomerPhoneMobile() {
        return customerPhoneMobile;
    }

    public String getCustomerFax() {
        return customerFax;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public String getCustomerBankName() {
        return customerBankName;
    }

    public String getCustomerBankCode() {
        return customerBankCode;
    }

    public String getCustomerAccount() {
        return customerAccount;
    }

    public String getCustomerINN() {
        return customerINN;
    }

    public String getCustomerOKONH() {
        return customerOKONH;
    }

    public String getPosition() {
        return position;
    }

    public String getDirectorSurname() {
        return directorSurname;
    }

    public String getDirectorName() {
        return directorName;
    }

    public String getDirectorMiddlename() {
        return directorMiddlename;
    }

    public String getDirectorPhone() {
        return directorPhone;
    }

    public String getDirectorEmail() {
        return directorEmail;
    }

    public String getNote() {
        return note;
    }

    public String getCustomerSurname() {
        return customerSurname;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerMiddlename() {
        return customerMiddlename;
    }

    public Long getCustomerGender() {
        return customerGender;
    }

    public String getCustomerDocumentType() {
        return customerDocumentType;
    }

    public Timestamp getCustomerBirthDate() {
        return customerBirthDate;
    }

    public Long getCustomerCitizenship() {
        return customerCitizenship;
    }

    public String getCustomerPassportSeries() {
        return customerPassportSeries;
    }

    public String getCustomerPassportNumber() {
        return customerPassportNumber;
    }

    public String getCustomerPassportIssuedBy() {
        return customerPassportIssuedBy;
    }

    public Timestamp getCustomerPassportExpireDate() {
        return customerPassportExpireDate;
    }

    public String getCustomerRegistrationAddress() {
        return customerRegistrationAddress;
    }

    public Long getStatusId() {
        return statusId;
    }

    public Timestamp getExpiredDate() {
        return expiredDate;
    }

    public String getBlock() {
        return block;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegistrationDate() {
        return registrationDate;
    }

    public Timestamp getModificationDate() {
        return modificationDate;
    }

    public Timestamp getBeforeBlockingDate() {
        return beforeBlockingDate;
    }

    public Timestamp getLockedDate() {
        return lockedDate;
    }

    public Timestamp getSuspendedSystemDate() {
        return suspendedSystemDate;
    }

    public Timestamp getPretensionDate() {
        return pretensionDate;
    }

    public Timestamp getExpiryDate() {
        return expiryDate;
    }

    public String getRegistrationDateFormatted() {
        return registrationDateFormatted;
    }

    public Long getBalance() {
        return balance;
    }

    public Long getPaymentsInCurrentPeriod() {
        return paymentsInCurrentPeriod;
    }

    public Long getChargesInCurrentPeriod() {
        return chargesInCurrentPeriod;
    }

    public Timestamp getLastPaymentDate() {
        return lastPaymentDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
