package uzgps.dto;

import uzgps.persistence.MObjectStaff;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 16.06.2017.
 */
public class MObjectStaffDTO implements Serializable, BasedDTO{
    private Long id;
    private Long mobjectId;
    private Long staffId;
    private Timestamp startDate;
    private Timestamp endDate;
    private Boolean endless;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;
    private String staffName;

    public MObjectStaffDTO(MObjectStaff mObjectStaff) {
        this.id = mObjectStaff.getId();
        this.mobjectId = mObjectStaff.getMobjectId();
        this.staffId = mObjectStaff.getStaffId();
        this.startDate = mObjectStaff.getStartDate();
        this.endDate = mObjectStaff.getEndDate();
        this.endless = mObjectStaff.getEndless();
        this.status = mObjectStaff.getStatus();
        this.regDate = mObjectStaff.getRegDate();
        this.modDate = mObjectStaff.getModDate();
        this.expDate = mObjectStaff.getExpDate();
        this.staffName = mObjectStaff.getStaffName();
    }

    public Long getId() {
        return id;
    }

    public Long getMobjectId() {
        return mobjectId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public Boolean getEndless() {
        return endless;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    public String getStaffName() {
        return staffName;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
