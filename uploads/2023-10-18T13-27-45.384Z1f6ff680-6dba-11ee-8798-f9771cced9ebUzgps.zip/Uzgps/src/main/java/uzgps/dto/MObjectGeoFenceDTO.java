package uzgps.dto;

import uzgps.persistence.MObjectGeoFence;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 16.06.2017.
 */
public class MObjectGeoFenceDTO implements Serializable, BasedDTO{
    private Long id;
    private Long mObjectId;
    private Long geoFenceId;
    private Integer controlType;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public MObjectGeoFenceDTO(MObjectGeoFence mObjectGeoFence) {
        this.id = mObjectGeoFence.getId();
        this.mObjectId = mObjectGeoFence.getmObjectId();
        this.geoFenceId = mObjectGeoFence.getGeoFenceId();
        this.controlType = mObjectGeoFence.getControlType();
        this.status = mObjectGeoFence.getStatus();
        this.regDate = mObjectGeoFence.getRegDate();
        this.modDate = mObjectGeoFence.getModDate();
        this.expDate = mObjectGeoFence.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public Long getGeoFenceId() {
        return geoFenceId;
    }

    public Integer getControlType() {
        return controlType;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
