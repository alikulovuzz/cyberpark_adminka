package uzgps.dto;

import uzgps.persistence.Sim;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class SimDTO implements Serializable, BasedDTO{

    private Long id;
    private String simPhone;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public SimDTO(Sim sim) {
        this.id          = sim.getId();
        this.simPhone    = sim.getSimPhone();
        this.status      = sim.getStatus();
        this.regDate     = sim.getRegDate();
        this.modDate     = sim.getModDate();
        this.expDate     = sim.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public String getSimPhone() {
        return simPhone;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public String toString() {
        return "SimDTO{" +
                "id=" + id +
                ", simPhone='" + simPhone + '\'' +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
