package uzgps.dto;

import uzgps.persistence.MObjectNotifications;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class MObjectNotificationsDTO implements Serializable, BasedDTO {
    private Long id;
    private Long mObjectId;
    private Boolean panicButton;
    private Integer minSpeed;
    private Integer maxSpeed;
    private Boolean sendSms;
    private String phoneNumber;
    private Boolean sendMail;
    private String mail;
    private Boolean popUpWindow;
    private Boolean nPopUpWindow;
    private Boolean registerDatabase;
    private Boolean registerDatabaseViolation;
    private Boolean uSos;
    private Integer uSosSound;
    private String uSosColor;
    private Boolean uEngine;
    private Integer uEngineSound;
    private String uEngineColor;
    private Boolean uSpeedMin;
    private Integer uSpeedMinSound;
    private String uSpeedMinColor;
    private Boolean uSpeedMax;
    private Integer uSpeedMaxSound;
    private String uSpeedMaxColor;
    private Boolean uOnline;
    private Integer uOnlineSound;
    private String uOnlineColor;
    private Boolean uStaff;
    private Integer uStaffSound;
    private String uStaffColor;
    private Boolean uSettings;
    private Integer uSettingsSound;
    private String uSettingsColor;
    private Boolean uPoi;
    private Integer uPoiSound;
    private String uPoiColor;
    private Boolean uZoi;
    private Integer uZoiSound;
    private String uZoiColor;
    private Boolean uAudioCall;
    private Integer uAudioCallSound;
    private String uAudioCallColor;
    private Boolean uDoorOpen;
    private Integer uDoorOpenSound;
    private String uDoorOpenColor;
    private Boolean sSos;
    private Boolean sEngine;
    private Boolean sSpeedMin;
    private Boolean sSpeedMax;
    private Boolean sOnline;
    private Boolean sStaff;
    private Boolean sSettings;
    private Boolean sPoi;
    private Boolean sZoi;
    private Boolean sAudioCall;
    private Boolean sDoorOpen;
    private Boolean nSos;
    private Boolean nEngine;
    private Boolean nSpeedMin;
    private Boolean nSpeedMax;
    private Boolean nOnline;
    private Boolean nPoi;
    private Boolean nZoi;
    private Boolean nAudioCall;
    private Boolean nDoorOpen;
    private Boolean eSos;
    private Boolean eEngine;
    private Boolean eSpeedMin;
    private Boolean eSpeedMax;
    private Boolean eOnline;
    private Boolean eStaff;
    private Boolean eSettings;
    private Boolean ePoi;
    private Boolean eZoi;
    private Boolean eAudioCall;
    private Boolean eDoorOpen;
    private Boolean mSos;
    private Boolean mEngine;
    private Boolean mSpeedMin;
    private Boolean mSpeedMax;
    private Boolean mOnline;
    private Boolean mStaff;
    private Boolean mSettings;
    private Boolean mPoi;
    private Boolean mZoi;
    private Boolean mAudioCall;
    private Boolean mDoorOpen;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public MObjectNotificationsDTO(MObjectNotifications mObjectNotifications) {
        this.id = mObjectNotifications.getId();
        this.mObjectId = mObjectNotifications.getmObjectId();
        this.panicButton = mObjectNotifications.getPanicButton();
        this.minSpeed = mObjectNotifications.getMinSpeed();
        this.maxSpeed = mObjectNotifications.getMaxSpeed();
        this.sendSms = mObjectNotifications.getSendSms();
        this.phoneNumber = mObjectNotifications.getPhoneNumber();
        this.sendMail = mObjectNotifications.getSendMail();
        this.mail = mObjectNotifications.getMail();
        this.popUpWindow = mObjectNotifications.getPopUpWindow();
        this.nPopUpWindow = mObjectNotifications.getnPopUpWindow();
        this.registerDatabase = mObjectNotifications.getRegisterDatabase();
        this.registerDatabaseViolation = mObjectNotifications.getRegisterDatabaseViolation();
        this.uSos = mObjectNotifications.getuSos();
        this.uSosSound = mObjectNotifications.getuSosSound();
        this.uSosColor = mObjectNotifications.getuSosColor();
        this.uEngine = mObjectNotifications.getuEngine();
        this.uEngineSound = mObjectNotifications.getuEngineSound();
        this.uEngineColor = mObjectNotifications.getuEngineColor();
        this.uSpeedMin = mObjectNotifications.getuSpeedMin();
        this.uSpeedMinSound = mObjectNotifications.getuSpeedMinSound();
        this.uSpeedMinColor = mObjectNotifications.getuSpeedMinColor();
        this.uSpeedMax = mObjectNotifications.getuSpeedMax();
        this.uSpeedMaxSound = mObjectNotifications.getuSpeedMaxSound();
        this.uSpeedMaxColor = mObjectNotifications.getuSpeedMaxColor();
        this.uOnline = mObjectNotifications.getuOnline();
        this.uOnlineSound = mObjectNotifications.getuOnlineSound();
        this.uOnlineColor = mObjectNotifications.getuOnlineColor();
        this.uStaff = mObjectNotifications.getuStaff();
        this.uStaffSound = mObjectNotifications.getuStaffSound();
        this.uStaffColor = mObjectNotifications.getuStaffColor();
        this.uSettings = mObjectNotifications.getuSettings();
        this.uSettingsSound = mObjectNotifications.getuSettingsSound();
        this.uSettingsColor = mObjectNotifications.getuSettingsColor();
        this.uPoi = mObjectNotifications.getuPoi();
        this.uPoiSound = mObjectNotifications.getuPoiSound();
        this.uPoiColor = mObjectNotifications.getuPoiColor();
        this.uZoi = mObjectNotifications.getuZoi();
        this.uZoiSound = mObjectNotifications.getuZoiSound();
        this.uZoiColor = mObjectNotifications.getuZoiColor();
        this.uAudioCall = mObjectNotifications.getuAudioCall();
        this.uAudioCallSound = mObjectNotifications.getuAudioCallSound();
        this.uAudioCallColor = mObjectNotifications.getuAudioCallColor();
        this.uDoorOpen = mObjectNotifications.getuDoorOpen();
        this.uDoorOpenSound = mObjectNotifications.getuDoorOpenSound();
        this.uDoorOpenColor = mObjectNotifications.getuDoorOpenColor();
        this.sSos = mObjectNotifications.getsSos();
        this.sEngine = mObjectNotifications.getsEngine();
        this.sSpeedMin = mObjectNotifications.getsSpeedMin();
        this.sSpeedMax = mObjectNotifications.getsSpeedMax();
        this.sOnline = mObjectNotifications.getsOnline();
        this.sStaff = mObjectNotifications.getsStaff();
        this.sSettings = mObjectNotifications.getsSettings();
        this.sPoi = mObjectNotifications.getsPoi();
        this.sZoi = mObjectNotifications.getsZoi();
        this.sAudioCall = mObjectNotifications.getsAudioCall();
        this.sDoorOpen = mObjectNotifications.getsDoorOpen();
        this.nSos = mObjectNotifications.getnSos();
        this.nEngine = mObjectNotifications.getnEngine();
        this.nSpeedMin = mObjectNotifications.getnSpeedMin();
        this.nSpeedMax = mObjectNotifications.getnSpeedMax();
        this.nOnline = mObjectNotifications.getnOnline();
        this.nPoi = mObjectNotifications.getnPoi();
        this.nZoi = mObjectNotifications.getnZoi();
        this.nAudioCall = mObjectNotifications.getnAudioCall();
        this.nDoorOpen = mObjectNotifications.getnDoorOpen();
        this.eSos = mObjectNotifications.geteSos();
        this.eEngine = mObjectNotifications.geteEngine();
        this.eSpeedMin = mObjectNotifications.geteSpeedMin();
        this.eSpeedMax = mObjectNotifications.geteSpeedMax();
        this.eOnline = mObjectNotifications.geteOnline();
        this.eStaff = mObjectNotifications.geteStaff();
        this.eSettings = mObjectNotifications.geteSettings();
        this.ePoi = mObjectNotifications.getePoi();
        this.eZoi = mObjectNotifications.geteZoi();
        this.eAudioCall = mObjectNotifications.geteAudioCall();
        this.eDoorOpen = mObjectNotifications.geteDoorOpen();
        this.mSos = mObjectNotifications.getmSos();
        this.mEngine = mObjectNotifications.getmEngine();
        this.mSpeedMin = mObjectNotifications.getmSpeedMin();
        this.mSpeedMax = mObjectNotifications.getmSpeedMax();
        this.mOnline = mObjectNotifications.getmOnline();
        this.mStaff = mObjectNotifications.getmStaff();
        this.mSettings = mObjectNotifications.getmSettings();
        this.mPoi = mObjectNotifications.getmPoi();
        this.mZoi = mObjectNotifications.getmZoi();
        this.mAudioCall = mObjectNotifications.getmAudioCall();
        this.mDoorOpen = mObjectNotifications.getmDoorOpen();
        this.status = mObjectNotifications.getStatus();
        this.regDate = mObjectNotifications.getRegDate();
        this.modDate = mObjectNotifications.getModDate();
        this.expDate = mObjectNotifications.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public Boolean getPanicButton() {
        return panicButton;
    }

    public Integer getMinSpeed() {
        return minSpeed;
    }

    public Integer getMaxSpeed() {
        return maxSpeed;
    }

    public Boolean getSendSms() {
        return sendSms;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public Boolean getSendMail() {
        return sendMail;
    }

    public String getMail() {
        return mail;
    }

    public Boolean getPopUpWindow() {
        return popUpWindow;
    }

    public Boolean getnPopUpWindow() {
        return nPopUpWindow;
    }

    public Boolean getRegisterDatabase() {
        return registerDatabase;
    }

    public Boolean getRegisterDatabaseViolation() {
        return registerDatabaseViolation;
    }

    public Boolean getuSos() {
        return uSos;
    }

    public Integer getuSosSound() {
        return uSosSound;
    }

    public String getuSosColor() {
        return uSosColor;
    }

    public Boolean getuEngine() {
        return uEngine;
    }

    public Integer getuEngineSound() {
        return uEngineSound;
    }

    public String getuEngineColor() {
        return uEngineColor;
    }

    public Boolean getuSpeedMin() {
        return uSpeedMin;
    }

    public Integer getuSpeedMinSound() {
        return uSpeedMinSound;
    }

    public String getuSpeedMinColor() {
        return uSpeedMinColor;
    }

    public Boolean getuSpeedMax() {
        return uSpeedMax;
    }

    public Integer getuSpeedMaxSound() {
        return uSpeedMaxSound;
    }

    public String getuSpeedMaxColor() {
        return uSpeedMaxColor;
    }

    public Boolean getuOnline() {
        return uOnline;
    }

    public Integer getuOnlineSound() {
        return uOnlineSound;
    }

    public String getuOnlineColor() {
        return uOnlineColor;
    }

    public Boolean getuStaff() {
        return uStaff;
    }

    public Integer getuStaffSound() {
        return uStaffSound;
    }

    public String getuStaffColor() {
        return uStaffColor;
    }

    public Boolean getuSettings() {
        return uSettings;
    }

    public Integer getuSettingsSound() {
        return uSettingsSound;
    }

    public String getuSettingsColor() {
        return uSettingsColor;
    }

    public Boolean getuPoi() {
        return uPoi;
    }

    public Integer getuPoiSound() {
        return uPoiSound;
    }

    public String getuPoiColor() {
        return uPoiColor;
    }

    public Boolean getuZoi() {
        return uZoi;
    }

    public Integer getuZoiSound() {
        return uZoiSound;
    }

    public String getuZoiColor() {
        return uZoiColor;
    }

    public Boolean getuAudioCall() {
        return uAudioCall;
    }

    public Integer getuAudioCallSound() {
        return uAudioCallSound;
    }

    public String getuAudioCallColor() {
        return uAudioCallColor;
    }

    public Boolean getuDoorOpen() {
        return uDoorOpen;
    }

    public Integer getuDoorOpenSound() {
        return uDoorOpenSound;
    }

    public String getuDoorOpenColor() {
        return uDoorOpenColor;
    }

    public Boolean getsSos() {
        return sSos;
    }

    public Boolean getsEngine() {
        return sEngine;
    }

    public Boolean getsSpeedMin() {
        return sSpeedMin;
    }

    public Boolean getsSpeedMax() {
        return sSpeedMax;
    }

    public Boolean getsOnline() {
        return sOnline;
    }

    public Boolean getsStaff() {
        return sStaff;
    }

    public Boolean getsSettings() {
        return sSettings;
    }

    public Boolean getsPoi() {
        return sPoi;
    }

    public Boolean getsZoi() {
        return sZoi;
    }

    public Boolean getsAudioCall() {
        return sAudioCall;
    }

    public Boolean getsDoorOpen() {
        return sDoorOpen;
    }

    public Boolean getnSos() {
        return nSos;
    }

    public Boolean getnEngine() {
        return nEngine;
    }

    public Boolean getnSpeedMin() {
        return nSpeedMin;
    }

    public Boolean getnSpeedMax() {
        return nSpeedMax;
    }

    public Boolean getnOnline() {
        return nOnline;
    }

    public Boolean getnPoi() {
        return nPoi;
    }

    public Boolean getnZoi() {
        return nZoi;
    }

    public Boolean getnAudioCall() {
        return nAudioCall;
    }

    public Boolean getnDoorOpen() {
        return nDoorOpen;
    }

    public Boolean geteSos() {
        return eSos;
    }

    public Boolean geteEngine() {
        return eEngine;
    }

    public Boolean geteSpeedMin() {
        return eSpeedMin;
    }

    public Boolean geteSpeedMax() {
        return eSpeedMax;
    }

    public Boolean geteOnline() {
        return eOnline;
    }

    public Boolean geteStaff() {
        return eStaff;
    }

    public Boolean geteSettings() {
        return eSettings;
    }

    public Boolean getePoi() {
        return ePoi;
    }

    public Boolean geteZoi() {
        return eZoi;
    }

    public Boolean geteAudioCall() {
        return eAudioCall;
    }

    public Boolean geteDoorOpen() {
        return eDoorOpen;
    }

    public Boolean getmSos() {
        return mSos;
    }

    public Boolean getmEngine() {
        return mEngine;
    }

    public Boolean getmSpeedMin() {
        return mSpeedMin;
    }

    public Boolean getmSpeedMax() {
        return mSpeedMax;
    }

    public Boolean getmOnline() {
        return mOnline;
    }

    public Boolean getmStaff() {
        return mStaff;
    }

    public Boolean getmSettings() {
        return mSettings;
    }

    public Boolean getmPoi() {
        return mPoi;
    }

    public Boolean getmZoi() {
        return mZoi;
    }

    public Boolean getmAudioCall() {
        return mAudioCall;
    }

    public Boolean getmDoorOpen() {
        return mDoorOpen;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
