package uzgps.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import uzgps.persistence.*;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class MObjectSettingsDTO implements Serializable, BasedDTO{
    private Long id;
    private Long mObjectId;
    private MObjectType mObjectTypeId;
    private MObjectState mObjectStateId;
    private MObjectAppointment mObjectAppointmentId;
    private String objectCapacity;
    private String objectFuel;
    private String defaultTrackColor;
    private String speedColor1;
    private Long speedValue1;
    private String speedColor2;
    private Long speedValue2;
    private String speedColor3;
    private Long speedValue3;
    private String speedColor4;
    private Long speedValue4;
    private String speedColor5;
    private Long speedValue5;
    private String speedColor6;
    private Long speedValue6;
    private Long labelSize;
    private Long maxSpeed;
    private Long onlineTime;
    private Long parkingTime;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public MObjectSettingsDTO(MObjectSettings mObjectSettings) {
        this.id = mObjectSettings.getId();
        this.mObjectId = mObjectSettings.getmObjectId();
        this.objectCapacity = mObjectSettings.getObjectCapacity();
        this.objectFuel = mObjectSettings.getObjectFuel();
        this.defaultTrackColor = mObjectSettings.getDefaultTrackColor();
        this.speedColor1 = mObjectSettings.getSpeedColor1();
        this.speedValue1 = mObjectSettings.getSpeedValue1();
        this.speedColor2 = mObjectSettings.getSpeedColor2();
        this.speedValue2 = mObjectSettings.getSpeedValue2();
        this.speedColor3 = mObjectSettings.getSpeedColor3();
        this.speedValue3 = mObjectSettings.getSpeedValue3();
        this.speedColor4 = mObjectSettings.getSpeedColor4();
        this.speedValue4 = mObjectSettings.getSpeedValue4();
        this.speedColor5 = mObjectSettings.getSpeedColor5();
        this.speedValue5 = mObjectSettings.getSpeedValue5();
        this.speedColor6 = mObjectSettings.getSpeedColor6();
        this.speedValue6 = mObjectSettings.getSpeedValue6();
        this.labelSize = mObjectSettings.getLabelSize();
        this.maxSpeed = mObjectSettings.getMaxSpeed();
        this.onlineTime = mObjectSettings.getOnlineTime();
        this.parkingTime = mObjectSettings.getParkingTime();
        this.status = mObjectSettings.getStatus();
        this.regDate = mObjectSettings.getRegDate();
        this.modDate = mObjectSettings.getModDate();
        this.expDate = mObjectSettings.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public MObjectType getmObjectTypeId() {
        return mObjectTypeId;
    }

    public void setmObjectTypeId(MObjectType mObjectTypeId) {
        this.mObjectTypeId = mObjectTypeId;
    }

    public MObjectState getmObjectStateId() {
        return mObjectStateId;
    }

    public void setmObjectStateId(MObjectState mObjectStateId) {
        this.mObjectStateId = mObjectStateId;
    }

    public MObjectAppointment getmObjectAppointmentId() {
        return mObjectAppointmentId;
    }

    public void setmObjectAppointmentId(MObjectAppointment mObjectAppointmentId) {
        this.mObjectAppointmentId = mObjectAppointmentId;
    }

    public String getObjectCapacity() {
        return objectCapacity;
    }

    public String getObjectFuel() {
        return objectFuel;
    }

    public String getDefaultTrackColor() {
        return defaultTrackColor;
    }

    public String getSpeedColor1() {
        return speedColor1;
    }

    public Long getSpeedValue1() {
        return speedValue1;
    }

    public String getSpeedColor2() {
        return speedColor2;
    }

    public Long getSpeedValue2() {
        return speedValue2;
    }

    public String getSpeedColor3() {
        return speedColor3;
    }

    public Long getSpeedValue3() {
        return speedValue3;
    }

    public String getSpeedColor4() {
        return speedColor4;
    }

    public Long getSpeedValue4() {
        return speedValue4;
    }

    public String getSpeedColor5() {
        return speedColor5;
    }

    public Long getSpeedValue5() {
        return speedValue5;
    }

    public String getSpeedColor6() {
        return speedColor6;
    }

    public Long getSpeedValue6() {
        return speedValue6;
    }

    public Long getLabelSize() {
        return labelSize;
    }

    public Long getMaxSpeed() {
        return maxSpeed;
    }

    public Long getOnlineTime() {
        return onlineTime;
    }

    public Long getParkingTime() {
        return parkingTime;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public String toString() {
        return "MObjectSettingsDTO{" +
                "id=" + id +
                ", mObjectId=" + mObjectId +
                ", objectCapacity='" + objectCapacity + '\'' +
                ", objectFuel='" + objectFuel + '\'' +
                ", defaultTrackColor='" + defaultTrackColor + '\'' +
                ", speedColor1='" + speedColor1 + '\'' +
                ", speedValue1=" + speedValue1 +
                ", speedColor2='" + speedColor2 + '\'' +
                ", speedValue2=" + speedValue2 +
                ", speedColor3='" + speedColor3 + '\'' +
                ", speedValue3=" + speedValue3 +
                ", speedColor4='" + speedColor4 + '\'' +
                ", speedValue4=" + speedValue4 +
                ", speedColor5='" + speedColor5 + '\'' +
                ", speedValue5=" + speedValue5 +
                ", speedColor6='" + speedColor6 + '\'' +
                ", speedValue6=" + speedValue6 +
                ", labelSize=" + labelSize +
                ", maxSpeed=" + maxSpeed +
                ", onlineTime=" + onlineTime +
                ", parkingTime=" + parkingTime +
                ", status='" + status + '\'' +
                ", regDate=" + regDate +
                ", modDate=" + modDate +
                ", expDate=" + expDate +
                '}';
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
