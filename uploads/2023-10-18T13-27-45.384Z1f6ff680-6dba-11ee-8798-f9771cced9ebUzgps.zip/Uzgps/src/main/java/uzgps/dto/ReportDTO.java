package uzgps.dto;

import uzgps.persistence.Report;

import java.io.Serializable;

/**
 * Created by NETEX on 15.06.2017.
 */
public class ReportDTO implements Serializable, BasedDTO {
    private Long id;
    private String name;
    private String nameEn;
    private String nameUzc;
    private String nameUzl;
    private String description;
    private String fileExtention;
    private Long FileSize;
    private String OriginalFileName;
    private String ExportFileName;
    private Boolean hasParameterScript;
    private Boolean hasGeneratorScript;
    private Long tenantId;
    private Long reportType;
    private Boolean visible;
    private String language;
    private Integer workingDb;
    private Long aclId;
    private Integer aclValue;

    public ReportDTO(Report report) {
        this.id = report.getId();
        this.name = report.getName();
        this.nameEn = report.getNameEn();
        this.nameUzc = report.getNameUzc();
        this.nameUzl = report.getNameUzl();
        this.description = report.getDescription();
        this.fileExtention = report.getFileExtention();
        FileSize = report.getFileSize();
        OriginalFileName = report.getOriginalFileName();
        ExportFileName = report.getExportFileName();
        this.hasParameterScript = report.getHasParameterScript();
        this.hasGeneratorScript = report.getHasGeneratorScript();
        this.tenantId = report.getTenantId();
        this.reportType = report.getReportType();
        this.visible = report.getVisible();
        this.language = report.getLanguage();
        this.workingDb = report.getWorkingDb();
        this.aclId = report.getAclId();
        this.aclValue = report.getAclValue();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNameEn() {
        return nameEn;
    }

    public String getNameUzc() {
        return nameUzc;
    }

    public String getNameUzl() {
        return nameUzl;
    }

    public String getDescription() {
        return description;
    }

    public String getFileExtention() {
        return fileExtention;
    }

    public Long getFileSize() {
        return FileSize;
    }

    public String getOriginalFileName() {
        return OriginalFileName;
    }

    public String getExportFileName() {
        return ExportFileName;
    }

    public Boolean getHasParameterScript() {
        return hasParameterScript;
    }

    public Boolean getHasGeneratorScript() {
        return hasGeneratorScript;
    }

    public Long getTenantId() {
        return tenantId;
    }

    public Long getReportType() {
        return reportType;
    }

    public Boolean getVisible() {
        return visible;
    }

    public String getLanguage() {
        return language;
    }

    public Integer getWorkingDb() {
        return workingDb;
    }

    public Long getAclId() {
        return aclId;
    }

    public Integer getAclValue() {
        return aclValue;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
