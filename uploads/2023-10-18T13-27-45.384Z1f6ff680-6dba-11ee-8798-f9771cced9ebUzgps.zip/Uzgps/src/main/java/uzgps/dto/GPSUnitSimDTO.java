package uzgps.dto;

import uzgps.persistence.GPSUnitSim;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 15.06.2017.
 */
public class GPSUnitSimDTO implements Serializable, BasedDTO {
    private Long id;
    private Long simId;
    private Long gpsUnitId;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public GPSUnitSimDTO(GPSUnitSim gpsUnitSim) {
        this.id = gpsUnitSim.getId();
        this.simId = gpsUnitSim.getSimId();
        this.gpsUnitId = gpsUnitSim.getGpsUnitId();
        this.status = gpsUnitSim.getStatus();
        this.regDate = gpsUnitSim.getRegDate();
        this.modDate = gpsUnitSim.getModDate();
        this.expDate = gpsUnitSim.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getSimId() {
        return simId;
    }

    public Long getGpsUnitId() {
        return gpsUnitId;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
