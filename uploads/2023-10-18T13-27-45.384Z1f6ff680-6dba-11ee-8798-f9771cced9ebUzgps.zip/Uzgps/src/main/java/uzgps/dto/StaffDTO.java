package uzgps.dto;

import uzgps.persistence.Staff;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 16.06.2017.
 */
public class StaffDTO implements Serializable, BasedDTO {

    private Long id;
    private Long contractId;
    private String surName;
    private String name;
    private String middleName;
    private Long photoId;
    private String position;
    private String phoneMobile;
    private String phoneLine;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public StaffDTO(Staff staff) {
        this.id = staff.getId();
        this.contractId = staff.getContractId();
        this.surName = staff.getSurName();
        this.name = staff.getName();
        this.middleName = staff.getMiddleName();
        this.photoId = staff.getPhotoId();
        this.position = staff.getPosition();
        this.phoneMobile = staff.getPhoneMobile();
        this.phoneLine = staff.getPhoneLine();
        this.status = staff.getStatus();
        this.regDate = staff.getRegDate();
        this.modDate = staff.getModDate();
        this.expDate = staff.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getContractId() {
        return contractId;
    }

    public String getSurName() {
        return surName;
    }

    public String getName() {
        return name;
    }

    public String getMiddleName() {
        return middleName;
    }

    public Long getPhotoId() {
        return photoId;
    }

    public String getPosition() {
        return position;
    }

    public String getPhoneMobile() {
        return phoneMobile;
    }

    public String getPhoneLine() {
        return phoneLine;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
