package uzgps.dto;

import uzgps.persistence.MObjectPoI;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 16.06.2017.
 */
public class MObjectPoIDTO implements Serializable, BasedDTO{
    private Long id;
    private Long mObjectId;
    private Long poiId;
    private Integer controlType;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public MObjectPoIDTO(MObjectPoI mObjectPoI) {
        this.id = mObjectPoI.getId();
        this.mObjectId = mObjectPoI.getmObjectId();
        this.poiId = mObjectPoI.getPoiId();
        this.controlType = mObjectPoI.getControlType();
        this.status = mObjectPoI.getStatus();
        this.regDate = mObjectPoI.getRegDate();
        this.modDate = mObjectPoI.getModDate();
        this.expDate = mObjectPoI.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public Long getPoiId() {
        return poiId;
    }

    public Integer getControlType() {
        return controlType;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
