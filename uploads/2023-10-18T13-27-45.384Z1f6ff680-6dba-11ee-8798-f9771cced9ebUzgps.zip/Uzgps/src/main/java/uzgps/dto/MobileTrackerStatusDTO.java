package uzgps.dto;

import uzgps.persistence.MobileTrackerStatus;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 16.06.2017.
 */
public class MobileTrackerStatusDTO implements Serializable, BasedDTO{
    private Long id;
    private Integer index;
    private String name;
    private String color;
    private String mobileSerial;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public MobileTrackerStatusDTO(MobileTrackerStatus mobileTrackerStatus) {
        this.id = mobileTrackerStatus.getId();
        this.index = mobileTrackerStatus.getIndex();
        this.name = mobileTrackerStatus.getName();
        this.color = mobileTrackerStatus.getColor();
        this.mobileSerial = mobileTrackerStatus.getMobileSerial();
        this.status = mobileTrackerStatus.getStatus();
        this.regDate = mobileTrackerStatus.getRegDate();
        this.modDate = mobileTrackerStatus.getModDate();
        this.expDate = mobileTrackerStatus.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public Integer getIndex() {
        return index;
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public String getMobileSerial() {
        return mobileSerial;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
