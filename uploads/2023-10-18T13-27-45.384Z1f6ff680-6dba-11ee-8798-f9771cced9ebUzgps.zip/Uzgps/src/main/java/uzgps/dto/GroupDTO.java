package uzgps.dto;

import uzgps.persistence.Group;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by NETEX on 16.06.2017.
 */
public class GroupDTO implements Serializable, BasedDTO {

    private Long id;
    private String groupName;
    private Long contractId;
    private String status;
    private Timestamp regDate;
    private Timestamp modDate;
    private Timestamp expDate;

    public GroupDTO(Group group) {
        this.id = group.getId();
        this.groupName = group.getGroupName();
        this.contractId = group.getContractId();
        this.status = group.getStatus();
        this.regDate = group.getRegDate();
        this.modDate = group.getModDate();
        this.expDate = group.getExpDate();
    }

    public Long getId() {
        return id;
    }

    public String getGroupName() {
        return groupName;
    }

    public Long getContractId() {
        return contractId;
    }

    public String getStatus() {
        return status;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public Timestamp getModDate() {
        return modDate;
    }

    public Timestamp getExpDate() {
        return expDate;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
