package uzgps.dto;

import uzgps.persistence.Profile;

import java.io.Serializable;

/**
 * Created by NETEX on 15.06.2017.
 */
public class ProfileDTO implements Serializable, BasedDTO {
    private Long id;
    private String position;
    private String mobilePhone;
    private String linePhone;
    private String email;
    private String description;

    public ProfileDTO(Profile profile) {
        this.id = profile.getId();
        this.position = profile.getPosition();
        this.mobilePhone = profile.getMobilePhone();
        this.linePhone = profile.getLinePhone();
        this.email = profile.getEmail();
        this.description = profile.getDescription();
    }

    public Long getId() {
        return id;
    }

    public String getPosition() {
        return position;
    }

    public String getMobilePhone() {
        return mobilePhone;
    }

    public String getLinePhone() {
        return linePhone;
    }

    public String getEmail() {
        return email;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public long returnObjectId() {
        return id;
    }
}
