package uzgps.home;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import uzgps.common.configuration.AppConfiguration;

import javax.servlet.ServletException;
import java.io.IOException;

/**
 * @author Sheroz Khaydarov
 * @since 31.03.13 21:45
 */
@Controller
public class HomeController {

//    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private AppConfiguration appConfiguration;

    public final static String URL_HOME = "/home.html";
    public final static String VIEW_HOME = "home/home";

    public final static String URL_HTML = "/{weburl}.html";
    public final static String VIEW_HTML = "home/products";

    @RequestMapping(value = URL_HOME)
    public ModelAndView processHome() throws ServletException, IOException {

        return new ModelAndView("redirect:/main.htm");

//        ModelAndView modelAndView = new ModelAndView(VIEW_HOME);
//
//        modelAndView.addObject("title", "Главная");
//        modelAndView.addObject("css_navbar", "");
//
//        return modelAndView;
    }

    @RequestMapping(value = URL_HTML)
    public ModelAndView pageProducts(@PathVariable String weburl) throws ServletException, IOException {
        //ModelAndView modelAndView = new ModelAndView(VIEW_HTML);


        String title = "";
        String activeCss = weburl;
        switch (weburl) {
            case "products":
                title = "Продукты";
                break;
            case "equipment":
                title = "Оборудавание";
                break;
            case "equipment-tracker":
                title = "Оборудавание - Трекеры";
                activeCss = "equipment";
                break;
            case "equipment-personal-tracker":
                title = "Оборудавание - Персональные трекеры";
                activeCss = "equipment";
                break;
            case "equipment-sensors":
                title = "Оборудавание - Датчики";
                activeCss = "equipment";
                break;
            case "equipment-optional":
                title = "Оборудавание - Дополнительное оборудование";
                activeCss = "equipment";
                break;
            case "contacts":
                title = "Контакты";
                break;
            case "solutions":
                title = "Решения";
                break;
            case "partners":
                title = "Партнеры";
                break;
            default:
                return new ModelAndView("redirect:" + URL_HOME);
        }

        ModelAndView modelAndView = new ModelAndView("home/" + weburl);
        modelAndView.addObject("title", title);
        modelAndView.addObject("activeCss", activeCss);
        modelAndView.addObject("weburl", weburl);
        modelAndView.addObject("css_navbar", "-2");

        return modelAndView;
    }

}
