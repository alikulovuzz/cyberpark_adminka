package uzgps.service;

import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.ContextRefreshedEvent;
import uz.netex.core.CoreMain;
import uzgps.common.ISpringContextEventLauncher;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/**
 * Created by Sheroz Khaydarov
 * 16.03.2014
 */

public class CoreInit implements ISpringContextEventLauncher {

    private org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public class NetworkInfo {
        private String macAddress;
        private List<String> ipAdreesList = new ArrayList<>();

        public String getMacAddress() {
            return macAddress;
        }

        public void setMacAddress(String macAddress) {
            this.macAddress = macAddress;
        }

        public List<String> getIpAdreesList() {
            return ipAdreesList;
        }

        public void setIpAdreesList(List<String> ipAdreesList) {
            this.ipAdreesList = ipAdreesList;
        }
    }

    @Override
    public void onContextEvent(ApplicationEvent event) {

        StringBuilder sb = new StringBuilder();
        sb.append("******* Network information *****");
        // for advanced system information see http://www.hyperic.com/products/sigar
        List<NetworkInfo> networkInfoList = getNetworkInfo();
        for (NetworkInfo networkInfo : networkInfoList){
            sb.append("\nMAC: ");
            sb.append(networkInfo.getMacAddress());
            for (String ip : networkInfo.getIpAdreesList())
                sb.append("\t IP: ").append(ip);
        }
        sb.append("\n******* End of Network information ****");

        logger.info("Core initialization process is launched...");

        ApplicationContext applicationContext = ((ContextRefreshedEvent) event).getApplicationContext();
        CoreMain coreMain = (CoreMain) applicationContext.getBean("coreMain");
        coreMain.start();
    }

    public List<NetworkInfo> getNetworkInfo() {
        List <NetworkInfo> networkInfoList = new ArrayList<>();
        try {
            // String hostAdrress = InetAddress.getLocalHost().getHostAddress();
            Enumeration<NetworkInterface> networks = NetworkInterface.getNetworkInterfaces();
            while(networks.hasMoreElements()) {
                NetworkInterface network = networks.nextElement();
                byte[] mac = network.getHardwareAddress();
                if(mac != null) {
                    NetworkInfo networkInfo = new NetworkInfo();
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < mac.length; i++) {
                        sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
                    }
                    networkInfo.setMacAddress(sb.toString());

                    Enumeration<InetAddress> inetAddressEnumeration = network.getInetAddresses();
                    while (inetAddressEnumeration.hasMoreElements()) {
                        InetAddress address = inetAddressEnumeration.nextElement();
                        networkInfo.getIpAdreesList().add(address.getHostAddress());
                    }
                    networkInfoList.add(networkInfo);
                }
            }
        } catch (SocketException e) {
            logger.error("Exception:", e);
        }
        return networkInfoList;
    }
}
