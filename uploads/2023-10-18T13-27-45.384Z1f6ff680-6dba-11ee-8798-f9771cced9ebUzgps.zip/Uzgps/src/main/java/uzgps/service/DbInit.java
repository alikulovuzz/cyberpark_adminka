package uzgps.service;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.jdbc.JdbcTestUtils;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;
import uzgps.admin.AdminService;
import uzgps.common.ISpringContextEventLauncher;
import uzgps.common.RoleInfo;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.RoleConfiguration;
import uzgps.persistence.Profile;
import uzgps.persistence.Role;
import uzgps.persistence.User;
import uzgps.persistence.UserRole;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.Date;

/**
 * Created by Sheroz Khaydarov
 * 24.01.2014
 */

public class DbInit implements ISpringContextEventLauncher {

    private org.slf4j.Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private PlatformTransactionManager transactionManager;

    @PersistenceContext
    EntityManager em;

    @Autowired
    javax.sql.DataSource dataSource;

    @Autowired
    AppConfiguration appConfiguration;

    @Autowired
    private AdminService adminService;

    private String sqlScript;
    private boolean usesSequence;


    public void setUsesSequence(boolean usesSequence) {
        this.usesSequence = usesSequence;
    }

    public void setSqlScript(String sqlScript) {
        this.sqlScript = sqlScript;
    }


    @Override
    public void onContextEvent(ApplicationEvent event) {

        TransactionTemplate transactionTemplate = new TransactionTemplate(transactionManager);
        transactionTemplate.execute(new TransactionCallbackWithoutResult() {
            @Override
            protected void doInTransactionWithoutResult(TransactionStatus status) {
                initialize();
            }
        });
    }


    @Transactional
    void initialize() {
        logger.info("Database data initialization: started...");

        long count = 0;
        Query query;
        query = em.createQuery("SELECT count(id) from User");
        count = (Long) query.getSingleResult();
        if (count == 0) {
            logger.info("Database data initialization: empty users, creating default admin account...");

            Profile profile = new Profile();
            profile.setPosition("Admin");
            em.persist(profile);

            User user = new User();
            user.setLogin(appConfiguration.getAuthConfiguration().getDefaultAdminLogin());
            user.setPassword(appConfiguration.getAuthConfiguration().getDefaultPassphraseValue());
            user.setManagerId(0L);
//            user.setUserTypeId(UZGPS_CONST.USER_TYPE_SUPERADMIN);
            Role role = adminService.getRoleById(UZGPS_CONST.USER_ROLE_SYSTEM_ADMINISTRATOR);
            user.setRole(role);
            user.setSurName("admin");
            user.setMiddleName("admin");
            user.setName("admin");
            user.setBlock(UZGPS_CONST.USER_BLOCK_STATUS_UNBLOCK);
            user.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            user.setRegDate(new Timestamp(new Date().getTime()));
            user.setProfile(profile);

            em.persist(user);

            UserRole userRole = new UserRole();
            userRole.setUser(user);

            RoleConfiguration roleConfiguration = appConfiguration.getRoleConfiguration();
            RoleInfo[] roleInfos = roleConfiguration.getRoleInfo();
            for (RoleInfo roleInfo : roleInfos) {
                if (roleInfo.getType().equalsIgnoreCase("ROLE_SYSADMIN")) {
                    userRole.setRoleId((long) roleInfo.getId());
                }
            }
            em.persist(userRole);

            // Make default group
            String sql = "INSERT INTO uzgps_group(id, g_contract_id,  g_name,  g_reg_date, g_status) VALUES (0, 0,  'Без группы', current_timestamp , 'A');";
            em.createNativeQuery(sql).executeUpdate();

            // Core tables
            // uzgps_track_point
            sql = "CREATE SEQUENCE seq_uzgps_track_point_id INCREMENT 1 START 1 CACHE 1;";
            em.createNativeQuery(sql).executeUpdate();

            sql = "CREATE TABLE IF NOT EXISTS uzgps_track_point (" +
                    "  id_track_point bigint NOT NULL DEFAULT nextval('seq_uzgps_track_point_id'), " +
                    "  tp_gpsunit_id bigint NOT NULL," +
                    "  tp_longitude real," +
                    "  tp_latitude real," +
                    "  tp_altitude integer," +
                    "  tp_angle integer," +
                    "  tp_satellites integer," +
                    "  tp_speed integer," +
                    "  tp_timestamp timestamp without time zone," +
                    "  tp_io_movement integer," +
                    "  tp_io_engineon integer," +
                    "  tp_io_dat integer," +
                    "  tp_status character(1) DEFAULT 'A'," +
                    "  tp_reg_date timestamp without time zone DEFAULT now()," +
                    "  to_mod_date timestamp without time zone," +
                    "  tp_exp_date timestamp without time zone," +
                    "  tp_staff_id bigint, " +
                    "  tp_unit_id bigint, " +
                    "  CONSTRAINT uzgps_track_point_pkey PRIMARY KEY (id_track_point));";
            em.createNativeQuery(sql).executeUpdate();

            // uzgps_movable_object_tracks
            sql = "CREATE SEQUENCE seq_uzgps_movable_object_tracks_id INCREMENT 1  MINVALUE 1  MAXVALUE 9223372036854775807  START 1 CACHE 1;";
            em.createNativeQuery(sql).executeUpdate();
            sql = "CREATE TABLE IF NOT EXISTS uzgps_movable_object_tracks (" +
                    "  id bigint NOT NULL DEFAULT nextval('seq_uzgps_movable_object_tracks_id')," +
                    "  altitude real NOT NULL," +
                    "  angle integer NOT NULL," +
                    "  log_time timestamp without time zone NOT NULL," +
                    "  imei character varying(256) NOT NULL," +
                    "  latitude real NOT NULL," +
                    "  longitude real NOT NULL," +
                    "  satellites integer NOT NULL," +
                    "  speed integer NOT NULL," +
                    "  type integer NOT NULL," +
                    "  gps_unit_id bigint," +
                    "  umot_status character(1) DEFAULT 'A'," +
                    "  umot_reg_date timestamp without time zone DEFAULT now()," +
                    "  umot_mod_date timestamp without time zone," +
                    "  umot_exp_date timestamp without time zone," +
                    "  CONSTRAINT uzgps_movable_object_tracks_pkey PRIMARY KEY (id))";
            em.createNativeQuery(sql).executeUpdate();

            // uzgps_track_point_io
            sql = "CREATE SEQUENCE seq_uzgps_track_point_io_id INCREMENT 1  MINVALUE 1  MAXVALUE 9223372036854775807  START 1 CACHE 1;";
            em.createNativeQuery(sql).executeUpdate();
            sql = "CREATE TABLE IF NOT EXISTS uzgps_track_point_io (" +
                    "  id_track_point_io bigint NOT NULL DEFAULT nextval('seq_uzgps_track_point_io_id')," +
                    "  tpo_track_point_id bigint," +
                    "  tpo_movement smallint NOT NULL," +
                    "  tpo_engineon smallint," +
                    "  tpo_online smallint," +
                    "  tpo_dat smallint," +
                    "  tpo_status character(1) DEFAULT 'A'," +
                    "  tpo_reg_date timestamp without time zone DEFAULT now()," +
                    "  tpo_mod_date timestamp without time zone," +
                    "  tpo_exp_date timestamp without time zone," +
                    "  CONSTRAINT uzgps_track_point_io_pkey PRIMARY KEY (id_track_point_io))";
            em.createNativeQuery(sql).executeUpdate();

            // uzgps_io_elements
            sql = "CREATE SEQUENCE seq_io_elements INCREMENT 1  MINVALUE 1  MAXVALUE 9223372036854775807  START 1 CACHE 1;";
            em.createNativeQuery(sql).executeUpdate();
            sql = "CREATE TABLE IF NOT EXISTS uzgps_io_elements (" +
                    "  id_ioe bigint NOT NULL DEFAULT nextval('seq_io_elements')," +
                    "  ioe_type_id bigint NOT NULL," +
                    "  ioe_key integer NOT NULL," +
                    "  ioe_value bigint NOT NULL," +
                    "  ioe_imei bigint NOT NULL," +
                    "  ioe_log_time timestamp without time zone NOT NULL," +
                    "  ioe_unit_id bigint NOT NULL," +
                    "  ioe_status character(1) DEFAULT 'A'," +
                    "  ioe_reg_date timestamp without time zone NOT NULL DEFAULT now()," +
                    "  ioe_mod_date timestamp without time zone," +
                    "  ioe_exp_date timestamp without time zone," +
                    "  CONSTRAINT io_elements_pkey PRIMARY KEY (id_ioe))";
            em.createNativeQuery(sql).executeUpdate();

            // test_movable_object_tracks
            sql = "CREATE SEQUENCE seq_test_movable_object_tracks_id INCREMENT 1  MINVALUE 1  MAXVALUE 9223372036854775807  START 1 CACHE 1;";
            em.createNativeQuery(sql).executeUpdate();
            sql = "CREATE TABLE IF NOT EXISTS test_movable_object_tracks (" +
                    "  id bigint NOT NULL DEFAULT nextval('seq_test_movable_object_tracks_id')," +
                    "  altitude real NOT NULL," +
                    "  angle integer NOT NULL," +
                    "  log_time timestamp without time zone NOT NULL," +
                    "  imei character varying(256) NOT NULL," +
                    "  latitude real NOT NULL," +
                    "  longitude real NOT NULL," +
                    "  satellites integer NOT NULL," +
                    "  speed integer NOT NULL," +
                    "  type integer NOT NULL," +
                    "  gps_unit_id bigint," +
                    "  umot_status character(1) DEFAULT 'A'," +
                    "  umot_reg_date timestamp without time zone DEFAULT now()," +
                    "  umot_mod_date timestamp without time zone," +
                    "  umot_exp_date timestamp without time zone," +
                    "  CONSTRAINT test_movable_object_tracks_pkey PRIMARY KEY (id))";
            em.createNativeQuery(sql).executeUpdate();
        }
        logger.info("Database data initialization: completed.");

//        setSqlScript("dbinit.sql");
//        initialInsertsSqlScript();
    }

    @Transactional
    public void initialInsertsSqlScript() {
        if (sqlScript != null && !sqlScript.isEmpty()) {
            JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
            FileSystemResource fileSystemResource = new FileSystemResource(sqlScript);
            JdbcTestUtils.executeSqlScript(jdbcTemplate, fileSystemResource, false);
        }
    }

}
