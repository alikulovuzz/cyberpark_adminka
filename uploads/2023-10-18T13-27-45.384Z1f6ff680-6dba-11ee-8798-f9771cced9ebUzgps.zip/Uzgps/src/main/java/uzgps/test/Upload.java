package uzgps.test;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: Dell
 * Date: 14.07.12
 * Time: 18:11
 * To change this template use File | Settings | File Templates.
 */
@Controller
public class Upload {

    @RequestMapping("/upload.htm")
    public ModelAndView upload(HttpServletRequest request)

            throws Exception {
        ModelAndView modelAndView = new ModelAndView("upload");
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultiValueMap<String, MultipartFile> map = multipartRequest.getMultiFileMap();
            if(map != null) {
                Iterator iter = map.keySet().iterator();
                while(iter.hasNext()) {
                    String str = (String) iter.next();
                    List<MultipartFile> fileList =  map.get(str);
                    for(MultipartFile mpf : fileList) {
                        File localFile = new File("c:\\temp\\" + StringUtils.trimAllWhitespace(mpf.getOriginalFilename()));
                        OutputStream out = new FileOutputStream(localFile);
                        out.write(mpf.getBytes());
                        out.close();
                        modelAndView.addObject("str",StringUtils.trimAllWhitespace(mpf.getOriginalFilename()));

                    }
                }
            }
        return modelAndView;
    }

    @RequestMapping("/uploadf.htm")
    public ModelAndView form () {
        ModelAndView modelAndView = new ModelAndView("upload");
        return modelAndView;
    }
}
