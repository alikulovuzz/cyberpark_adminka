package uzgps.message;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.common.Errors;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreMobjectBig;
import uz.netex.core.helper.CoreTerminal;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectTracks;
import uz.netex.datatype.PoiNotification;
import uz.netex.dbtables.NotificationUnit;
import uz.netex.dbtables.SmsOut;
import uz.netex.routing.database.tables.Notification;
import uzgps.admin.AdminJournal;
import uzgps.common.CommonUtils;
import uzgps.common.UZGPS_CONST;
import uzgps.dto.GPSTrackPointDTO;
import uzgps.main.AppLastStatus;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.models.MObjectTrackDataJSON;
import uzgps.map.models.MessageData;
import uzgps.map.models.notification.*;
import uzgps.persistence.Contract;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.UserAccessList;
import uzgps.route.json.models.trip.TripRouteNotification;
import uzgps.route.json.response.trip.ResponseTripNotification;
import uzgps.settings.AbstractSettingsController;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static uz.netex.database.DBSelector.*;
import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

/**
 * Created by Gayratjon on 3/18/14
 */
@Controller
public class MessageController extends AbstractSettingsController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_MESSAGES_TRACK_POINT_REMOVE = "/message/track-point-remove.htm";

    private final static String URL_MESSAGES_TRACK_POINTS_REMOVE_BY_DATES = "/message/track-points-remove.htm";
    private final static String URL_MESSAGES_TRACK_POINTS_RESTORE_BY_DATES = "/message/track-point-restore.htm";

    private final static String VIEW_MESSAGES_TRACK_POINT_REMOVE = "message/ajax-track-point-remove";
    private final static String VIEW_MESSAGES_TRACK_POINTS_REMOVE = "message/ajax-track-points-remove";
    private final static String VIEW_MESSAGES_TRACK_POINTS_RESTORE = "message/ajax-track-points-restore";

    public final static String URL_MOBJECT_GEOFENCE_INTERSECT_ALERTS = "/map/gf-intersect-alerts.htm";
    private final static String URL_MESSAGE_MONITORING_PANEL = "/message/monitoring.htm";
    private final static String VIEW_MESSAGE_MONITORING_PANEL = "message/ajax-message-monitoring";
    private final static String URL_MESSAGE_LIST_JSON = "/message/message-list-json.htm";
    private final static String URL_NOTIFICATION_LIST_JSON = "/message/notification-list-json.htm";
    private final static String URL_SMS_LIST_JSON = "/message/sms-list-json.htm";
    private final static String URL_SMS_COMMAND = "/message/sms-command.htm";
    private final static int MAX_NUM_MESSAGE = 5;

    private final static String URL_TAKE_MESSAGE_MOBJECT = "/message/take-message-mobject.htm";
    private final static String AJAX_MES_TAB_PANEL_VIEW = "message/ajax-message-tab-panel";

    @Autowired
    MainController mainController;

    @Autowired
    CoreMain coreMain;

    @Autowired
    ObjectMapper jsonMapper;

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    private AdminJournal adminJournal;

    @Autowired
    private CoreTerminal coreTerminal;

    public void processMessageModel(ModelAndView modelAndView)
            throws ServletException, IOException {

        // Long lastTime = coreMain.getNotificationUnitLastTime(MainController.getUserContractId(session));
        Long lastTime = System.currentTimeMillis();
        if (lastTime > 0)
            modelAndView.addObject("lastAlertNotificationTime", lastTime);
        else
            modelAndView.addObject("lastAlertNotificationTime", null);

        modelAndView.addObject("numLastTrackMessages", MAX_NUM_MESSAGE);
    }

    @RequestMapping(value = URL_MESSAGE_MONITORING_PANEL)
    public ModelAndView processMessageMonitoringPanel(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String appStatus, HttpSession session,
                                                      @RequestParam(value = "cmd", required = false) String cmd) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_MESSAGE_MONITORING_PANEL);
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        modelAndView.addObject("appLastStatus", appLastStatus);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("mobjectList", mobjectList);

        monitoringController.processMapMonitoringModel(session, modelAndView, cmd);

        return modelAndView;
    }

    @RequestMapping(value = URL_MESSAGE_LIST_JSON, method = RequestMethod.GET, produces = "application/json;charset=utf-8")
    @ResponseBody
    public String processGettingMovableObjectsMessage(HttpSession session,
                                                      HttpServletResponse response,
                                                      @RequestParam(value = "updtime", required = false, defaultValue = "0") Long updTime)
            throws ServletException, IOException {

        List<MobjectTracks> mObjectTracksList = monitoringController.getMobjectTracksList(session);

        List<MObjectTrackDataJSON> mObjectTrackDataJSONList = null;
        Set<String> ignorableMObjectTrackFieldNames = new HashSet<>();
        Set<String> ignorableMonitorFieldNames = new HashSet<>();
        if (mObjectTracksList != null && mObjectTracksList.size() > 0) {
            mObjectTrackDataJSONList = new ArrayList<>();
            ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
            UserAccessList userAccessList = (UserAccessList) session.getAttribute(MainController.SESSION_USER_ACCESS_LIST);

            for (MobjectTracks mobjectTracks : mObjectTracksList) {
                MObjectTrackDataJSON mObjectTrackDataJSON = new MObjectTrackDataJSON();
                MessageData messageData = new MessageData(session, mobjectTracks);
                mObjectTrackDataJSON.setMessageData(messageData);

                if (userAccessList.getMonitoring() == 0 && contractSettings.getTooltipsMassagesView()) {
                    MessageNotification messageNotification = new MessageNotification(mobjectTracks, contractSettings.getTooltipsMassagesColor());
//                    messageNotification.englishText();
                    mObjectTrackDataJSON.setMessageNot(messageNotification);
                }

                mObjectTrackDataJSONList.add(mObjectTrackDataJSON);
            }

            ignorableMObjectTrackFieldNames.add("monitorData");
            ignorableMObjectTrackFieldNames.add("popupData");
            ignorableMObjectTrackFieldNames.add("pointList");

            if (userAccessList.getMonitoring() > 0)
                ignorableMObjectTrackFieldNames.add("messageNot");

            if (!contractSettings.getTooltipsMassagesView())
                ignorableMObjectTrackFieldNames.add("messageNot");
        }

        try {
            Set<String> ignorableFields = new HashSet<>();
            ignorableFields.add("isLimitOver");
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("MObjectTrackDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableMObjectTrackFieldNames));
            filterProvider.addFilter("MonitorDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableMonitorFieldNames));
            ObjectWriter writer = jsonMapper.writer(filterProvider);

            return writer.writeValueAsString(mObjectTrackDataJSONList);

        } catch (IOException e) {
            logger.error("Error: ", e);
        }
        return "";
    }

    @RequestMapping(value = URL_MOBJECT_GEOFENCE_INTERSECT_ALERTS, method = RequestMethod.GET)
    public void getMObjectGeoFenceIntersectAlerts(HttpServletResponse response, HttpSession session,
                                                  @RequestParam(value = "time", required = false) Long time)
            throws ServletException, IOException {

        List<AlertNotification> alertNotifications = new ArrayList<>();
        if (MainController.getUserContractId(session) != null && time != null) {
            List<PoiNotification> poiNotifications = coreMain.getNotification(MainController.getUserContractId(session), time);
            if (poiNotifications != null) {
                if (time == 0) {
                    for (int i = 0; i < poiNotifications.size() && i < 3; i++) {
                        PoiNotification poiNotification = poiNotifications.get(i);
                        if (poiNotification != null) {
                            AlertNotification alertNotification = new AlertNotification(poiNotification);
//                            alertNotification.englishText();
                            alertNotifications.add(alertNotification);
                        }
                    }
                } else {
                    for (PoiNotification poiNotification : poiNotifications) {
                        if (poiNotification != null) {
                            AlertNotification alertNotification = new AlertNotification(poiNotification);
//                            alertNotification.englishText();
                            alertNotifications.add(alertNotification);
                        }
                    }
                }

                Collections.sort(alertNotifications);
            }
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("alerts");
            byte[] data;
            data = writer.writeValueAsBytes(alertNotifications);
            response.setContentType("application/json");
            response.setContentLength(data.length);
            ServletOutputStream outStream;
            outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    @RequestMapping(value = URL_NOTIFICATION_LIST_JSON, method = RequestMethod.GET, produces = "application/json;charset=utf-8")
    public void getNotificationList(HttpSession session,
                                    HttpServletResponse response,
                                    @RequestParam(value = "time", required = false) Long time)
            throws ServletException, IOException {

        if (logger.isDebugEnabled())
            logger.debug("getNotificationList: time={}", time);

        List<NotificationUnit> notificationUnitList = null;

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            notificationUnitList = coreMain.getNotificationUnitByUser(MainController.getInterfaceUserId(), time);
        } else {
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<NotificationUnit> tempNotificationUnitList;

                List<Contract> contracts = MainController.getUserContracts(session);

                for (Contract contract : contracts) {
                    tempNotificationUnitList = coreMain.getNotificationUnitByContract(contract.getId(), time);

                    if (tempNotificationUnitList != null && tempNotificationUnitList.size() > 0) {
                        if (notificationUnitList == null) notificationUnitList = new ArrayList<>();
                        {
                            notificationUnitList.addAll(tempNotificationUnitList);
                        }
                    }
                }
            } else {
                notificationUnitList = coreMain.getNotificationUnitByContract(MainController.getUserContractId(session), time);
            }
        }

        List<BaseNotification> notificationList = null;
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        if (contractSettings != null) {
            notificationList = getFilteredNotificationList(notificationUnitList, contractSettings);
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("alerts");
            byte[] data;
            data = writer.writeValueAsBytes(notificationList);
            response.setContentType("application/json");
            response.setContentLength(data.length);
            ServletOutputStream outStream;
            outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    @RequestMapping(value = URL_SMS_LIST_JSON, method = RequestMethod.GET, produces = "application/json;charset=utf-8")
    public void getSmsList(HttpServletResponse response, HttpSession session,
                           @RequestParam(value = "time", required = false) Long time)
            throws ServletException, IOException {

        if (logger.isDebugEnabled())
            logger.debug("getSmsList: time={}", time);

        List<SmsOut> smsList = null;

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            smsList = coreMain.getSmsOutListByUser(MainController.getInterfaceUserId(), time, (long) MAX_NUM_MESSAGE);
        } else {
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<SmsOut> tempSmsList;

                List<Contract> contracts = MainController.getUserContracts(session);

                for (Contract contract : contracts) {
                    tempSmsList = coreMain.getSmsOutListByContract(contract.getId(), time, (long) MAX_NUM_MESSAGE);

                    if (tempSmsList != null && tempSmsList.size() > 0) {
                        if (smsList == null) smsList = new ArrayList<>();
                        {
                            smsList.addAll(tempSmsList);
                        }
                    }
                }
            } else {
                smsList = coreMain.getSmsOutListByContract(MainController.getUserContractId(session), time, (long) MAX_NUM_MESSAGE);
            }

        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("sms");
            byte[] data;
            data = writer.writeValueAsBytes(smsList);
            response.setContentType("application/json");
            response.setContentLength(data.length);
            ServletOutputStream outStream;
            outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    @RequestMapping(value = URL_SMS_COMMAND, method = RequestMethod.POST)
    private void smsCommand(HttpServletResponse response, HttpSession session,
                            @RequestParam(value = "object-id", required = false) Long mObjectId,
                            @RequestParam(value = "sms", required = false) String sms,
                            @RequestParam(value = "gprs", required = false) boolean viaGprs)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("SMS sender object-id={}, sms={}", mObjectId, sms);
        }

        Contract contract = MainController.getUserContract(session);
        Long countSms = contract.getMaxSmsCmdCount();

        if (viaGprs) {
            coreTerminal.send(mObjectId, sms);
        } else {
            if (countSms != null && countSms > 0) {
                coreMain.sendSMS(mObjectId, sms);
            }
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("alerts");
            byte[] data;
            data = writer.writeValueAsBytes("");
            response.setContentType("application/json");
            response.setContentLength(data.length);
            ServletOutputStream outStream;
            outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    public List<BaseNotification> getFilteredNotificationList(List<NotificationUnit> notificationUnitList, ContractSettings
            contractSettings) {
        if (notificationUnitList != null) {
            List<BaseNotification> notificationList = new ArrayList<>();

            for (NotificationUnit notificationUnit : notificationUnitList) {
                if (notificationUnit != null) {
                    try {
                        switch (notificationUnit.getMessageType()) {
                            case NotificationUnit.MESSAGE_TYPE_POI:
                            case NotificationUnit.MESSAGE_TYPE_ZOI:
                                notificationList.add(new GeoFenceNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_SPEED_MIN:
                            case NotificationUnit.MESSAGE_TYPE_SPEED_MAX:
                                notificationList.add(new SpeedNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_SENSOR_MIN:
                            case NotificationUnit.MESSAGE_TYPE_SENSOR_MAX:
                            case NotificationUnit.MESSAGE_TYPE_SENSOR_CHANGE:
                            case NotificationUnit.MESSAGE_TYPE_SENSOR_ABSENT:
                                notificationList.add(new SensorNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_SOS_BUTTON:
                            case NotificationUnit.MESSAGE_TYPE_AUDIO_CALL:
                            case NotificationUnit.MESSAGE_TYPE_DOOR_OPENED:
                            case NotificationUnit.MESSAGE_TYPE_DOOR_CLOSED:
                                notificationList.add(new BaseNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_ENGINE_ON:
                            case NotificationUnit.MESSAGE_TYPE_ENGINE_OFF:
                                notificationList.add(new BaseNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_EXTERNAL_POWER_ON:
                            case NotificationUnit.MESSAGE_TYPE_EXTERNAL_POWER_OFF:
                                notificationList.add(new BaseNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_ONLINE_ON:
                            case NotificationUnit.MESSAGE_TYPE_ONLINE_OFF:
                                notificationList.add(new BaseNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_MOBJECT_EDIT:
                            case NotificationUnit.MESSAGE_TYPE_MOBJECT_DELETE:
                                notificationList.add(new MobjectChangeNotification(notificationUnit, coreMain, contractSettings));
                                break;
                            case NotificationUnit.MESSAGE_TYPE_STAFF_EDIT:
                            case NotificationUnit.MESSAGE_TYPE_STAFF_DELETE:
                                notificationList.add(new MobjectStaffAttacheNotification(notificationUnit, coreMain, contractSettings));
                                break;
                        }
                    } catch (Exception ignored) {
                    }
                }
            }

            return notificationList;
        }

        return null;
    }

    /**
     * Remove track point by id from ajax call
     *
     * @param tpId Track point id
     * @return modelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_MESSAGES_TRACK_POINT_REMOVE, method = RequestMethod.POST)
    public ModelAndView removeTrackPoint(@RequestParam(value = "tpId", required = false) Long tpId)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_MESSAGES_TRACK_POINT_REMOVE);
        modelAndView.addObject("isDeleted", 0);

        if (tpId != null) {
            if (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")) {
                if (coreMain.updateTrackPointById(tpId) == Errors.ERR_SUCCESS) {
                    modelAndView.addObject("isDeleted", 1);

                    // Log delete action
                    adminJournal.logging(
                            UZGPS_CONST.JOURNAL_ACT_DELETE,
                            UZGPS_CONST.JOURNAL_GPSTRACKPOINT_DELETE,
                            UZGPS_CONST.JOURNAL_GPSTRACKPOINT,
                            new GPSTrackPointDTO(tpId, UZGPS_CONST.STATUS_DELETE));
                } else {
                    modelAndView.addObject("isDeleted", 0);
                }
            }
        } else {
            modelAndView.addObject("isDeleted", 0);
        }

        return modelAndView;
    }

    /**
     * Remove tracks by date interval
     */
    @RequestMapping(value = URL_MESSAGES_TRACK_POINTS_REMOVE_BY_DATES, method = RequestMethod.POST)
    public ModelAndView removeTrackPointsByDates(HttpSession session,
                                                 @RequestParam(value = "mobjects", required = false) Long[] mObjects,
                                                 @RequestParam(value = "restore-msg-start-date", required = false) String messageStartDate,
                                                 @RequestParam(value = "restore-msg-end-date", required = false) String messageEndDate
    )
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_MESSAGES_TRACK_POINTS_REMOVE);
        modelAndView.addObject("isDeleted", STATUS_UPDATE_ERROR);
        Timestamp startDate = null;
        Timestamp endDate = null;

        try {
            if (!messageStartDate.equalsIgnoreCase("") && !messageEndDate.equalsIgnoreCase("")) {
                startDate = getTimestampFromString(messageStartDate);
                endDate = getTimestampFromString(messageEndDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (mObjects != null) {
            List<Long> mObjectsList = new ArrayList<>();
            Collections.addAll(mObjectsList, mObjects);

            if (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")) {
                int resultStatus;
                resultStatus = coreMain.setStatusForTracks(MainController.getUserContractId(session), startDate, endDate, mObjectsList,
                        TRACKLIST_STATUS_DELETED);

                if (resultStatus == STATUS_UPDATE_SUCCESS) {
                    modelAndView.addObject("isDeleted", STATUS_UPDATE_SUCCESS);

                    // Log  delete by period action
                    adminJournal.logging(
                            UZGPS_CONST.JOURNAL_ACT_DELETE,
                            UZGPS_CONST.JOURNAL_GPSTRACKPOINT_DELETE,
                            UZGPS_CONST.JOURNAL_GPSTRACKPOINT,
                            new GPSTrackPointDTO(0L, UZGPS_CONST.STATUS_DELETE, startDate, endDate, mObjectsList));
                } else if (resultStatus == STATUS_UPDATE_NODATA) {
                    modelAndView.addObject("isDeleted", STATUS_UPDATE_NODATA);
                } else {
                    modelAndView.addObject("isDeleted", STATUS_UPDATE_ERROR);
                }

                for (Long mobjectId : mObjects) {
                    CoreMobjectBig.getInstance().readMobjectTrackPoints(mobjectId);
                }

            }
        } else {
            modelAndView.addObject("isDeleted", STATUS_UPDATE_ERROR);
        }

        return modelAndView;
    }

    /**
     * Restore tracks by date interval
     */
    @RequestMapping(value = URL_MESSAGES_TRACK_POINTS_RESTORE_BY_DATES, method = RequestMethod.POST)
    public ModelAndView restoreTrackPointsByDates(HttpSession session,
                                                  @RequestParam(value = "mobjects", required = false) Long[] mObjects,
                                                  @RequestParam(value = "restore-msg-start-date", required = false) String messageStartDate,
                                                  @RequestParam(value = "restore-msg-end-date", required = false) String messageEndDate
    )
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_MESSAGES_TRACK_POINTS_RESTORE);
        modelAndView.addObject("isRestored", STATUS_UPDATE_ERROR);
        Timestamp startDate = null;
        Timestamp endDate = null;

        try {
            if (!messageStartDate.equalsIgnoreCase("") && !messageEndDate.equalsIgnoreCase("")) {
                startDate = getTimestampFromString(messageStartDate);
                endDate = getTimestampFromString(messageEndDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (mObjects != null) {
            List<Long> mObjectsList = new ArrayList<>();
            Collections.addAll(mObjectsList, mObjects);

            if (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")) {
                int resultStatus;
                resultStatus = coreMain.setStatusForTracks(MainController.getUserContractId(session), startDate, endDate, mObjectsList,
                        TRACKLIST_STATUS_ACTIVE);

                if (resultStatus == STATUS_UPDATE_SUCCESS) {
                    modelAndView.addObject("isRestored", STATUS_UPDATE_SUCCESS);

                    // Log  delete by period action
                    adminJournal.logging(
                            UZGPS_CONST.JOURNAL_ACT_UPDATE,
                            UZGPS_CONST.JOURNAL_GPSTRACKPOINT_UPDATE,
                            UZGPS_CONST.JOURNAL_GPSTRACKPOINT,
                            new GPSTrackPointDTO(0L, UZGPS_CONST.STATUS_ACTIVE, startDate, endDate, mObjectsList));

                } else if (resultStatus == STATUS_UPDATE_NODATA) {
                    modelAndView.addObject("isRestored", STATUS_UPDATE_NODATA);
                } else {
                    modelAndView.addObject("isRestored", STATUS_UPDATE_ERROR);
                }
            } else {
                modelAndView.addObject("isRestored", STATUS_UPDATE_ERROR);
            }
        } else {
            modelAndView.addObject("isRestored", STATUS_UPDATE_ERROR);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_TAKE_MESSAGE_MOBJECT, method = RequestMethod.POST)
    private ModelAndView takeMessage(HttpSession session,
                                     @RequestParam(value = "msg-start-date", required = false) String messageStartDate,
                                     @RequestParam(value = "msg-end-date", required = false) String messageEndDate,
                                     @RequestParam(value = "msg-tab-id", required = false) String selectedMessageTabId,
                                     @RequestParam(value = "msg-selected-mObject-list", required = false) Long[] msgSelectedMObjectList,
                                     @RequestParam(value = "is-checked-ignor", required = false) Boolean isCheckedIgnor,
                                     @RequestParam(value = "page-id", required = false) Integer pageId,
                                     @RequestParam(value = "show-message-type", required = false) int showMessagesType) throws
            ServletException, IOException {

        Long maxPages = 0L;
        List<Integer> pagination;

        if (logger.isDebugEnabled()) {
            logger.debug("msg-start-date, msg-end-date, msg-tab-id, msg-selected-mObject-list", messageStartDate, messageEndDate, selectedMessageTabId, msgSelectedMObjectList);
        }

        ModelAndView modelAndView = new ModelAndView(AJAX_MES_TAB_PANEL_VIEW);

        Long contractId = MainController.getUserContractId(session);
        Long userId = null;
        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            userId = MainController.getInterfaceUserId();
        } else {
            contractId = MainController.getUserContractId(session);
        }

        // vaqt Timestamp  ga utqazish
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse(messageStartDate);
            endDate = dateFormat.parse(messageEndDate);
        } catch (ParseException ignored) {

        }

        Timestamp timestampStartDate = null;
        Timestamp timestampEndDate = null;

        if (startDate != null && endDate != null) {
            timestampStartDate = new Timestamp(startDate.getTime());
            timestampEndDate = new Timestamp(endDate.getTime());
        }

        // massivdan listga olish hammma MObjectIdlar
        List<Long> mobjectIds = new ArrayList<>();

        Collections.addAll(mobjectIds, msgSelectedMObjectList);

        // get massage Notification
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        int eventType = -1;

        List<BaseNotification> notifications = new ArrayList<>();
        List<MObjectGPSTrackPoint> mObjectGPSTrackPointList = new ArrayList<>();
        List<GPSTrackPoint> gpsTrackPoints;
        List<MObjectSms> smsToDriverList = new ArrayList<>();
        List<Notification> routeNotifications;
        List<TripRouteNotification> tripRouteNotificationList = null;

        modelAndView.addObject("contractSettings", contractSettings);

        List<Long> contractsIds = new ArrayList<>();
        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            List<Contract> contracts = MainController.getUserContracts(session);

            for (Contract contract : contracts) {
                contractsIds.add(contract.getId());
            }
        } else {
            contractsIds.add(contractId);
        }

        switch (selectedMessageTabId) {
            case "message":
                eventType = 0;
                int messagesStatus;

                messagesStatus = showMessagesType;

                if (MainController.getIsShowObjectsOfAllContracts(session)) {
                    gpsTrackPoints = coreMain.getTrackListForMessagesListDeleted(contractsIds, userId, timestampStartDate,
                            timestampEndDate, isCheckedIgnor, mobjectIds, pageId, messagesStatus);

                    if (gpsTrackPoints != null && gpsTrackPoints.size() == 0 && pageId > 0) {
                        pageId = 0;
                        gpsTrackPoints = coreMain.getTrackListForMessagesListDeleted(contractsIds, userId, timestampStartDate,
                                timestampEndDate, isCheckedIgnor, mobjectIds, pageId, messagesStatus);
                    }

                    maxPages += coreMain.getTrackListForMessagesListDeletedPages(contractsIds, userId, timestampStartDate,
                            timestampEndDate, isCheckedIgnor, mobjectIds, messagesStatus);

                } else {
                    gpsTrackPoints = coreMain.getTrackListForMessagesListDeleted(contractId, userId, timestampStartDate, timestampEndDate,
                            isCheckedIgnor, mobjectIds, pageId, messagesStatus);

                    maxPages = coreMain.getTrackListForMessagesListDeletedPages(contractId, userId, timestampStartDate, timestampEndDate,
                            isCheckedIgnor, mobjectIds, messagesStatus);
                }

//                pagination = getPages(pageId, maxPages.intValue());
                if (gpsTrackPoints != null && gpsTrackPoints.size() > 0) {
                    for (GPSTrackPoint gpsTrackPoint : gpsTrackPoints) {
                        if (gpsTrackPoint != null && gpsTrackPoint.getMobjectId() != null) {
                            MObjectGPSTrackPoint mObjectGPSTrackPoint = new MObjectGPSTrackPoint();
                            mObjectGPSTrackPoint.setMobject(coreMain.getMobjectById(gpsTrackPoint.getMobjectId()));
                            mObjectGPSTrackPoint.setGpsElement(gpsTrackPoint.gpsElement);
                            mObjectGPSTrackPoint.setIoData(gpsTrackPoint.getIoData());
                            mObjectGPSTrackPoint.setExternalPowerVoltageDouble(gpsTrackPoint.getIoData().getExternalPowerVoltageDouble());
                            mObjectGPSTrackPoint.setInternalBatteryVoltageDouble(gpsTrackPoint.getIoData().getInternalBatteryVoltageDouble());
                            mObjectGPSTrackPoint.setPcbTemperature((gpsTrackPoint.getIoData().getPcbTemperature() != null) ? (gpsTrackPoint.getIoData().getPcbTemperature()) / 10 : null);
                            mObjectGPSTrackPoint.setRegDate(gpsTrackPoint.getRegDate());
                            mObjectGPSTrackPoint.setSosButtonPressed(gpsTrackPoint.getSosStatus());
                            mObjectGPSTrackPoint.setTrackPointId(gpsTrackPoint.getId());
                            mObjectGPSTrackPoint.setTpStatus(gpsTrackPoint.getStatus());
                            mObjectGPSTrackPointList.add(mObjectGPSTrackPoint);
                        }
                    }
                }

                modelAndView.addObject("showMessagesType", showMessagesType);
                modelAndView.addObject("mObjects", mobjectIds);
                modelAndView.addObject("mObjectsCount", mobjectIds.size());

                break;

            case "notification":
                eventType = NotificationUnit.EVENT_TYPE_UVEDOMLENIYE;

            case "event":
                if (eventType < 0) {
                    eventType = NotificationUnit.EVENT_TYPE_SOBITIYE;
                }

            case "violation":
                if (eventType < 0) {
                    eventType = NotificationUnit.EVENT_TYPE_NARUSHENIYE;
                }

                List<NotificationUnit> notificationsTemp;

                if (MainController.getIsShowObjectsOfAllContracts(session)) {
                    notificationsTemp = coreMain.getNotificationList(contractsIds, userId, eventType,
                            timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds, pageId);

                    if (notificationsTemp != null && notificationsTemp.size() == 0 && pageId > 0) {
                        pageId = 0;
                        notificationsTemp = coreMain.getNotificationList(contractsIds, userId, eventType,
                                timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds, pageId);
                    }

                    maxPages = coreMain.getNotificationListPages(contractsIds, userId, eventType,
                            timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds);
                } else {
                    notificationsTemp = coreMain.getNotificationList(contractId, userId, eventType,
                            timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds, pageId);

                    maxPages = coreMain.getNotificationListPages(contractId, userId, eventType,
                            timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds);
                }

                if (notificationsTemp != null) {
                    notifications.addAll(getFilteredNotificationList(notificationsTemp, contractSettings));
                }

                break;
            case "route-notification":
                eventType = Notification.TYPE_NOTIFICATION;

            case "route-event":
                if (eventType < 0) {
                    eventType = Notification.TYPE_MESSAGE;
                }
            case "route-violation":
                if (eventType < 0) {
                    eventType = Notification.TYPE_NARUSHENIYE;
                }

                routeNotifications = coreMain.getNotificationListOfTripRouting(contractsIds, userId, eventType,
                        timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds, pageId);

                if (routeNotifications != null && routeNotifications.size() == 0 && pageId > 0) {
                    pageId = 0;
                    routeNotifications = coreMain.getNotificationListOfTripRouting(contractsIds, userId, eventType,
                            timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds, pageId);
                }

                maxPages = coreMain.getNotificationListOfTripRoutingPages(contractsIds, userId, eventType,
                        timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds);

                if (routeNotifications != null) {
//                    notifications.addAll(getFilteredNotificationList(routeNotificationsTemp, contractSettings));
                    ResponseTripNotification routeNotificationsFiltered = new ResponseTripNotification(routeNotifications, 0L, coreMain);
                    if (routeNotificationsFiltered != null)
                        tripRouteNotificationList = routeNotificationsFiltered.getNotificationList();
                }

                break;
            case "sms":
                eventType = NotificationUnit.EVENT_TYPE_SMS;

                List<SmsOut> listSms;
                if (MainController.getIsShowObjectsOfAllContracts(session)) {

                    listSms = coreMain.getSmsOutListForMessage(contractsIds, userId, timestampStartDate, timestampEndDate, isCheckedIgnor,
                            mobjectIds, pageId);

                    if (listSms != null && listSms.size() == 0 && pageId > 0) {
                        pageId = 0;
                        listSms = coreMain.getSmsOutListForMessage(contractsIds, userId, timestampStartDate, timestampEndDate, isCheckedIgnor,
                                mobjectIds, pageId);
                    }
                    maxPages = coreMain.getSmsOutListForMessagePages(contractId, userId, timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds);
                } else {
                    listSms = coreMain.getSmsOutListForMessage(contractId, userId, timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds, pageId);

                    maxPages = coreMain.getSmsOutListForMessagePages(contractId, userId, timestampStartDate, timestampEndDate, isCheckedIgnor, mobjectIds);
                }

                if (listSms != null && listSms.size() > 0) {
                    for (SmsOut smsMessageList : listSms) {
                        if (smsMessageList != null && smsMessageList.getMobjectId() != null) {
                            MObjectSms smsOutList = new MObjectSms();
                            smsOutList.setMessage(smsMessageList.getMessage());
                            smsOutList.setSrcAddr(smsMessageList.getSrcAddr());
                            smsOutList.setDestAddr(smsMessageList.getDestAddr());
                            smsOutList.setRegDateLong(smsMessageList.getRegDateLong());
                            smsOutList.setStatus(smsMessageList.getStatus());
                            smsOutList.setMobject(coreMain.getMobjectById(smsMessageList.getMobjectId()));
                            smsToDriverList.add(smsOutList);
                        }
                    }
                }

                break;
            default:
                break;
        }

        // Make list for pagination
        pagination = getPages(pageId, maxPages.intValue());

        modelAndView.addObject("mObjectGPSTrackPointList", mObjectGPSTrackPointList);
        modelAndView.addObject("msgSmsList", smsToDriverList);
        modelAndView.addObject("notificationList", notifications);
        modelAndView.addObject("routeNotifications", tripRouteNotificationList);
        modelAndView.addObject("pagination", pagination);
        modelAndView.addObject("activeMessageTabMenu", selectedMessageTabId);
        modelAndView.addObject("pageNumber", pageId);
        modelAndView.addObject("pageCount", maxPages);

        return modelAndView;
    }

    private List<Integer> getPages(Integer currentPage, Integer maxPages) {
        List<Integer> list = new ArrayList<>();
        if (currentPage != null && maxPages != null) {
            if (maxPages > 0) list.add(0); // 1 page
            if (maxPages > 1) list.add(1); // 2 page
            if (maxPages > 2) list.add(2); // 3 page

            if (currentPage > 1) {
                if (!list.contains(currentPage - 1) && (currentPage - 1 < maxPages))
                    list.add(currentPage - 1); // current - 1

                if (!list.contains(currentPage) && (currentPage < maxPages))
                    list.add(currentPage); // current

                if (!list.contains(currentPage + 1) && (currentPage + 1 < maxPages))
                    list.add(currentPage + 1); // current + 1
            }


            if (!list.contains(maxPages - 3) && (maxPages - 3 > 0)) list.add(maxPages - 3); // last-2 page
            if (!list.contains(maxPages - 2) && (maxPages - 3 > 0)) list.add(maxPages - 2); // last-1 page
            if (!list.contains(maxPages - 1) && (maxPages - 3 > 0)) list.add(maxPages - 1); // last page

            Collections.sort(list);

        }
        return list;
    }

    private Timestamp getTimestampFromString(String date) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        return new Timestamp(dateFormat.parse(date).getTime());
    }

}
