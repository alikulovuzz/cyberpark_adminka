package uzgps.message;

import uz.netex.datatype.MobjectBig;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by zohid on 23.02.15.
 */
public class MObjectSms implements Comparable<MObjectSms> {
    @Override
    public int compareTo(MObjectSms o) {
        return 0;
    }

    private String message;
    private String srcAddr;
    private String destAddr;
    private Long regDateLong;
    private String status;
    private String formatterSmsDay;
    private String formatterSmsTime;
    private MobjectBig mobject = null;

    public MobjectBig getMobject() {
        return mobject;
    }

    public void setMobject(MobjectBig mobject) {
        this.mobject = mobject;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSrcAddr() {
        return srcAddr;
    }

    public void setSrcAddr(String srcAddr) {
        this.srcAddr = srcAddr;
    }

    public String getDestAddr() {
        return destAddr;
    }

    public void setDestAddr(String destAddr) {
        this.destAddr = destAddr;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFormatterSmsDay() {
        if (regDateLong != null) {
            Date date = new Date(regDateLong);

            DateFormat farmatterSmsDay = new SimpleDateFormat("dd.MM.yyyy");
            // this.farmatterDay = formatterSmsDay.format(date);
            return farmatterSmsDay.format(date);
        }
        // return formatterSmsDay;
        return "hello";
    }

    public void setFormatterSmsDay(String formatterSmsDay) {
        this.formatterSmsDay = formatterSmsDay;
    }

    public String getFormatterSmsTime() {
        if (regDateLong != null) {
            Date date = new Date(regDateLong);

            DateFormat farmatterSmsTime = new SimpleDateFormat("HH:mm:ss");
            // this.formatterSmsTime = formatterSmsTime.format(date);
            return farmatterSmsTime.format(date);
        }
        //return formatterSmsTime;
        return "hello2";
    }

    public void setFormatterSmsTime(String formatterSmsTime) {
        this.formatterSmsTime = formatterSmsTime;
    }


    public Long getRegDateLong() {
        return regDateLong;
    }

    public void setRegDateLong(Long regDateLong) {
        this.regDateLong = regDateLong;
    }

}
