package uzgps.message;

import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.dbtables.SmsOut;
import uzgps.map.models.notification.BaseNotification;

import java.util.List;

/**
 * Created by Gayratjon on 10/23/14.
 */
public class ResponseNotification {

    @JsonProperty("alerts")
    List<BaseNotification> baseNotificationList;
    @JsonProperty("sms")
    List<SmsOut> smsOutList;

    public ResponseNotification() {
        this.baseNotificationList = null;
        this.smsOutList = null;
    }

    public List<BaseNotification> getBaseNotificationList() {
        return baseNotificationList;
    }

    public void setBaseNotificationList(List<BaseNotification> baseNotificationList) {
        this.baseNotificationList = baseNotificationList;
    }

    public List<SmsOut> getSmsOutList() {
        return smsOutList;
    }

    public void setSmsOutList(List<SmsOut> smsOutList) {
        this.smsOutList = smsOutList;
    }
}
