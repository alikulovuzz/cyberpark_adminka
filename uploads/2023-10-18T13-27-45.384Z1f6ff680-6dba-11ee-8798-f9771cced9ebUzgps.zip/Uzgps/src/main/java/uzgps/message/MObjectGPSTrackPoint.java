package uzgps.message;

import uz.netex.datatype.GPSElement;
import uz.netex.datatype.IOData;
import uz.netex.datatype.MobjectBig;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Gayratjon on 5/6/14.
 */
public class MObjectGPSTrackPoint implements Comparable<MObjectGPSTrackPoint> {
    private MobjectBig mobject = null;
    private GPSElement gpsElement = null;
    private IOData ioData = null;
    private String formattedDate;

    private String farmatterDay;
    private String farmatterTime;
    private Double externalPowerVoltageDouble;
    private Double internalBatteryVoltageDouble;
    private Integer pcbTemperature;
    private Integer sosButtonPressed;
    private Timestamp regDate = null;
    private Long trackPointId = null;
    private String tpStatus = null;

    public MobjectBig getMobject() {
        return mobject;
    }

    public void setMobject(MobjectBig mobject) {
        this.mobject = mobject;//
    }

    public GPSElement getGpsElement() {
        return gpsElement;
    }

    public void setGpsElement(GPSElement gpsElement) {
        this.gpsElement = gpsElement;
    }

    public IOData getIoData() {
        return ioData;
    }

    public void setIoData(IOData ioData) {
        this.ioData = ioData;
    }

    public Long getTrackPointId() {
        return trackPointId;
    }

    public void setTrackPointId(Long trackPointId) {
        this.trackPointId = trackPointId;
    }

    public int getLongitudeInt() {
        return gpsElement.getLongitudeInt();
    }

    public void setLongitudeInt(int longitude) {
        gpsElement.setLongitudeInt(longitude);
    }

    public double getLongitude() {
        return gpsElement.getLongitude();
    }

    public void setLongitude(double longitudeDouble) {
        gpsElement.setLongitude(longitudeDouble);
    }

    public int getLatitudeInt() {
        return gpsElement.getLatitudeInt();
    }

    public void setLatitudeInt(int latitude) {
        gpsElement.setLatitudeInt(latitude);
    }

    public double getLatitude() {
        return gpsElement.getLatitude();
    }

    public void setLatitude(double latitudeDouble) {
        gpsElement.setLatitude(latitudeDouble);
    }

    public short getAltitude() {
        return gpsElement.getAltitude();
    }

    public void setAltitude(short altitude) {
        gpsElement.setAltitude(altitude);
    }

    public short getAngle() {
        return gpsElement.getAngle();
    }

    public void setAngle(short angle) {
        gpsElement.setAngle(angle);
    }

    public byte getSatellites() {
        return gpsElement.getSatellites();
    }

    public void setSatellites(byte satellites) {
        gpsElement.setSatellites(satellites);
    }

    public Integer getSpeed() {
        return gpsElement.getSpeed();
    }

    public void setSpeed(Integer speed) {
        gpsElement.setSpeed(speed);
    }

    public long getTimestamp() {
        return gpsElement.getTimestamp();
    }

    public void setTimestamp(long timestamp) {
        gpsElement.setTimestamp(timestamp);
    }

    public Timestamp getDate() {
        return gpsElement.getDate();
    }

    public byte getMovement() {
        return ioData.getMovement();
    }

    public void setDat(byte dat) {
        ioData.setDat(dat);
    }

    public void setMovement(byte movement) {
        ioData.setMovement(movement);
    }

    public byte getOnline() {
        return ioData.getOnline();
    }

    public byte getDat() {
        return ioData.getDat();
    }

    public byte getEngineOn() {
        return ioData.getEngineOn();
    }

    public void setOnline(byte online) {
        ioData.setOnline(online);
    }

    public void setEngineOn(byte engineOn) {
        ioData.setEngineOn(engineOn);
    }

    public String getFormattedDate() {
        if (gpsElement != null) {
            Date date = new Date(gpsElement.getTimestamp());
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            this.formattedDate = dateFormat.format(date);

            DateFormat dateFormatDay = new SimpleDateFormat("dd.MM.yyyy");
            DateFormat dateFormatHours = new SimpleDateFormat("HH:mm:ss");

            this.farmatterDay = dateFormatDay.format(date);
            this.farmatterTime = dateFormatHours.format(date);
        }
        return formattedDate;
    }

    public String getFarmatterDay() {
        if (gpsElement != null) {
            Date date = new Date(gpsElement.getTimestamp());

            DateFormat dateFormatDay = new SimpleDateFormat("dd.MM.yyyy");
            this.farmatterDay = dateFormatDay.format(date);
        }
        return farmatterDay;
    }

    public void setFarmatterDay(String farmatterDay) {
        this.farmatterDay = farmatterDay;
    }

    public String getFarmatterTime() {
        if (gpsElement != null) {
            Date date = new Date(gpsElement.getTimestamp());
            DateFormat dateFormatHours = new SimpleDateFormat("HH:mm:ss");
            this.farmatterTime = dateFormatHours.format(date);
        }
        return farmatterTime;
    }

    public void setFarmatterTime(String farmatterTime) {
        this.farmatterTime = farmatterTime;
    }


    public void setFormattedDate(String formattedDate) {
        this.formattedDate = formattedDate;
    }

    public String getFarmatterRegDay() {
        if (regDate != null) {
            Date date = new Date(regDate.getTime());

            DateFormat dateFormatDay = new SimpleDateFormat("dd.MM.yyyy");
            this.farmatterDay = dateFormatDay.format(date);
        }
        return farmatterDay;
    }

    public String getFarmatterRegTime() {
        if (regDate != null) {
            Date date = new Date(regDate.getTime());
            DateFormat dateFormatHours = new SimpleDateFormat("HH:mm:ss");
            this.farmatterTime = dateFormatHours.format(date);
        }
        return farmatterTime;
    }

    @Override
    public String toString() {
        return "MObjectGPSTrackPoint{" +
                "mobject=" + mobject +
                ", gpsElement=" + gpsElement +
                ", ioData=" + ioData +
                '}';
    }

    @Override
    public int compareTo(MObjectGPSTrackPoint o) {
        long l = (o.getTimestamp() - this.getTimestamp());
        if (l > 0) return 1;
        else if (l == 0) return 0;
        return -1;
//        return (int) (o.getTimestamp() - this.getTimestamp());
    }

    public Double getExternalPowerVoltageDouble() {
        return externalPowerVoltageDouble;
    }

    public void setExternalPowerVoltageDouble(Double externalPowerVoltageDouble) {
        this.externalPowerVoltageDouble = externalPowerVoltageDouble;
    }

    public Double getInternalBatteryVoltageDouble() {
        return internalBatteryVoltageDouble;
    }

    public void setInternalBatteryVoltageDouble(Double internalBatteryVoltageDouble) {
        this.internalBatteryVoltageDouble = internalBatteryVoltageDouble;
    }

    public Integer getPcbTemperature() {
        return pcbTemperature;
    }

    public void setPcbTemperature(Integer pcbTemperature) {
        this.pcbTemperature = pcbTemperature;
    }

    public Timestamp getRegDate() {
        return regDate;
    }

    public void setRegDate(Timestamp regDate) {
        this.regDate = regDate;
    }

    public Integer getSosButtonPressed() {
        return sosButtonPressed;
    }

    public void setSosButtonPressed(Integer sosButtonPressed) {
        this.sosButtonPressed = sosButtonPressed;
    }

    public String getTpStatus() {
        return tpStatus;
    }

    public void setTpStatus(String tpStatus) {
        this.tpStatus = tpStatus;
    }
}
