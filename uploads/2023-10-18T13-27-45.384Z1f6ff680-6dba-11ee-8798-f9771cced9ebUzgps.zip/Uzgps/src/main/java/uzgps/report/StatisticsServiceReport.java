package uzgps.report;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.persistence.*;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Stanislav on 30/12/16.
 */
@Service
@Transactional
public class StatisticsServiceReport {

    @PersistenceContext
    private EntityManager entityManager;

    public List<ReportTrip> getTripData(Long contractId, Timestamp startDate, Timestamp endDate, int tripType) {
        try {
//            Query query;
//
//            String queryStr = "SELECT * FROM public.uzgps_routing_report_trip " +
//                    "WHERE time_start_planned >= :startDate " +
//                    "AND time_end_planned < :endDate " +
//                    "AND contract_id  = :contractId " +
//                    "AND trip_type = :tripType " +
//                    "ORDER BY time_start_planned";
//
////            String queryStr = "SELECT * FROM public.uzgps_routing_report_trip ORDER BY time_start_planned";
//
//            query = entityManager.createNativeQuery(queryStr, ReportTrip.class);
//
//            query.setParameter("contractId", contractId);
//            query.setParameter("startDate", startDate);
//            query.setParameter("endDate", endDate);
//            query.setParameter("tripType", tripType);
//
//            return query.getResultList();

            String sqlQuery = "SELECT * FROM  public.uzgps_routing_report_trip(?,?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, ReportTrip.class);

            q.setParameter(1, contractId);
            q.setParameter(2, startDate);
            q.setParameter(3, endDate);
            q.setParameter(4, tripType);

            List<ReportTrip> list = q.getResultList();

            return list;

        } catch (NoResultException e) {
            return null;
        }
    }

//    String sqlQuery = "SELECT * FROM  dashboard.mobject_distance_for_smpo_treking_points(?,?,?)";
//
//    Query q = entityManager.createNativeQuery(sqlQuery, CustomDistancesForTracking.class);
//
//        q.setParameter(1, id);
//        q.setParameter(2, startDate);
//        q.setParameter(3, endDate);
//
//    List<CustomDistancesForTracking> list = q.getResultList();
//
//        return list;

//    public List<ReportTripHeaderData> getTripDetails(Long contractId, Timestamp startDate, Timestamp endDate) {
//        try {
//            String sqlQuery = "SELECT * FROM  public.uzgps_routing_report_trip_templates(?,?,?)";
//
//            Query q = entityManager.createNativeQuery(sqlQuery, ReportTripHeaderData.class);
//
//            q.setParameter(1, contractId);
//            q.setParameter(2, startDate);
//            q.setParameter(3, endDate);
//
//            List<ReportTripHeaderData> list = q.getResultList();
//
//            return list;
//        } catch (NoResultException e) {
//            return null;
//        }
//    }

    public List<ReportObjectMovement> getObjectMovementData(Long contractId, Long objectId,
                                                            Timestamp startDate, Timestamp endDate, int tripType) {
        try {

            String sqlQuery = "SELECT * FROM  public.uzgps_routing_report_trip_detailed(?,?,?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, ReportObjectMovement.class);

            q.setParameter(1, contractId);
            q.setParameter(2, objectId);
            q.setParameter(3, startDate);
            q.setParameter(4, endDate);
            q.setParameter(5, tripType);

            List<ReportObjectMovement> list = q.getResultList();

            return list;
        } catch (NoResultException e) {
            return null;
        }
    }

    public List<ReportWorkingMobjects> getWorkingMobjectsData(Long contractId, Timestamp reportDate, int tripType) {
        try {
            String sqlQuery = "SELECT * FROM  public.uzgps_routing_report_working_mobjects(?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, ReportWorkingMobjects.class);

            q.setParameter(1, contractId);
            q.setParameter(2, reportDate);
            q.setParameter(3, tripType);

            List<ReportWorkingMobjects> list = q.getResultList();

            return list;
        } catch (NoResultException e) {
            return null;
        }
    }

    public List<ReportTripSummary> getTripSummaryData(Long contractId, Timestamp startDate, Timestamp endDate, int tripType) {
        try {

            String sqlQuery = "SELECT * FROM  public.uzgps_routing_report_trips_results_view(?,?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, ReportTripSummary.class);

            q.setParameter(1, contractId);
            q.setParameter(2, startDate);
            q.setParameter(3, endDate);
            q.setParameter(4, tripType);

            List<ReportTripSummary> list = q.getResultList();

            return list;

        } catch (NoResultException e) {
            return null;
        }
    }

    public List<ReportRouteViolations> getRouteViolationsData(Long contractId, Long routeId, Long mobjectId,
                                                              Timestamp startDate, Timestamp endDate, int tripType) {
        try {

            String sqlQuery = "SELECT * FROM  public.report_violations_in_trips(?,?,?,?,?,?)";

            Query q = entityManager.createNativeQuery(sqlQuery, ReportRouteViolations.class);

            q.setParameter(1, contractId);
            q.setParameter(2, routeId);
            q.setParameter(3, mobjectId);
            q.setParameter(4, startDate);
            q.setParameter(5, endDate);
            q.setParameter(6, tripType);

            List<ReportRouteViolations> list = q.getResultList();

            return list;

        } catch (NoResultException e) {
            return null;
        }
    }

}
