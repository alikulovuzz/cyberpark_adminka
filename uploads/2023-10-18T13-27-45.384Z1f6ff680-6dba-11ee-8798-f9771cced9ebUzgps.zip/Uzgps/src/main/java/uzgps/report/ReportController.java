package uzgps.report;

import groovy.lang.Binding;
import groovy.util.GroovyScriptEngine;
import groovy.util.ResourceException;
import groovy.util.ScriptException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.jasperreports.*;
import uz.netex.core.CoreMain;
import uz.netex.dbtables.MobjectGpsUnitList;
import uzgps.admin.AdminJournal;
import uzgps.admin.AdminService;
import uzgps.common.Converters;
import uzgps.common.NominatimHelper;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.UrlConfiguration;
import uzgps.dto.ReportGetDTO;
import uzgps.excel.tripReports.objectMovement.ExcelObjectMovementReport;
import uzgps.excel.tripReports.routeViolations.ExcelRouteViolationsReport;
import uzgps.excel.tripReports.trip.ExcelTripReport;
import uzgps.excel.tripReports.tripSummary.ExcelTripSummaryReport;
import uzgps.excel.tripReports.workingMobjects.ExcelWorkingMobjectsReport;
import uzgps.main.MainController;
import uzgps.persistence.*;
import uzgps.rest.response.ResponseApi;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * User: Sheroz Khaydarov
 * Date: 21.02.13 Time: 18:56
 */

@Controller
public class ReportController {

    private static final String URL_REPORT_PANEL = "/report.htm";
    private static final String VIEW_REPORT_PANEL = "report/report-panel";

    private static final String URL_REPORT_FORM_HTML = "/report/report-html.htm";
    private static final String VIEW_REPORT_FORM_HTML = "report/report-html";


    private static final String URL_REPORT_LIST = "/report/list.htm";
    private static final String VIEW_REPORT_LIST = "report/report-list";

    private static final String URL_REPORT_ADD = "/report/add.htm";
    private static final String VIEW_REPORT_ADD = "report/report-add";

    private static final String URL_REPORT_VIEW = "/report/view.htm";

    private static final String URL_REPORT_PARAM = "/report/param.htm";
    private static final String VIEW_REPORT_PARAM = "report/ajax-report-param";

    private static final String VIEW_REPORT_NO_DATA = "report/report-no-data";
    private static final String VIEW_REPORT_ERROR = "report/report-error";

    private static final String paramPrefix = "param-";

    private static final String URL_TRIP_REPORT_DOWNLOAD_XLS = "/report/trip-report-download-xls.htm";
    private static final String URL_OBJECT_MOVEMENT_REPORT_DOWNLOAD_XLS = "/report/object-movement-report-download-xls.htm";
    private static final String URL_TRIP_REPORT_MOMENT_DOWNLOAD_XLS = "/report/trip-moment-report-download-xls.htm";
    private static final String URL_TRIP_SUMMARY_REPORT_DOWNLOAD_XLS = "/report/trip-summary-report-download-xls.htm";
    private static final String URL_ROUTE_VIOLATIONS_REPORT_DOWNLOAD_XLS = "/report/route-violations-report-download-xls.htm";

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private CoreMain coreMain;

    @Autowired
    private ReportService reportService;

    @Autowired
    private AdminService adminService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private DataSource dataSourceReport;

    @Autowired
    private DataSource dataSource;

    @Autowired
    private StatisticsServiceReport statisticsServiceReport;

    @Autowired
    MessageSource messageSource;

    @Autowired
    private AdminJournal adminJournal;

    /**
     * @param modelAndView
     */
    public void processReportModel(HttpSession session,
                                   ModelAndView modelAndView,
                                   Locale locale, long category) {
        MobjectGpsUnitList mObjectGpsUnitList = coreMain.getMobjectGpsUnitListByContract(MainController.getUserContractId(session));

        if (mObjectGpsUnitList != null) {
            modelAndView.addObject("mObjectGpsUnitList", mObjectGpsUnitList.getMobjectGpsUnitList());
        }

        // Start and finish dates
        String todayAsString = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
        modelAndView.addObject("dateStart", todayAsString + " 00:00");
        modelAndView.addObject("dateEnd", todayAsString + " 23:59");
        modelAndView.addObject("contractId", MainController.getUserContractId(session));
        modelAndView.addObject("userId", MainController.getInterfaceUserId());

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            modelAndView.addObject("contractsIds", MainController.getUserContractsIds(session));
        }


        // Get Report List
        // List<Report> reportList = this.getReportList();

        String language = "ru";
//        if (locale != null) language = locale.getLanguage();

        List list = reportService.getReportListByContractAndCategory(MainController.getUserContractId(session), language, category);
        if (list != null && list.size() > 0) {
            modelAndView.addObject("reportList", list);
        }
    }

    /**
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_REPORT_LIST, method = RequestMethod.GET)
    public ModelAndView getList() throws ServletException, IOException {

/*
        SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserDetail user = securityLoggedUser.getUserDetail();
        Long dbid = user.getDb().getId();
*/
        long tenantId = 0L;

        List list = reportService.getReportList(tenantId);

        List<Report> reportList = new ArrayList<>();
        if (list != null) {
            for (Object obj : list)
                reportList.add((Report) obj);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_REPORT_LIST);
        modelAndView.addObject("reportList", reportList);
        return modelAndView;
    }

    private List<Report> getReportList() {
        Long tenantId = 0L;

        List list = reportService.getReportList(tenantId);

        List<Report> reportList = new ArrayList<>();
        if (list != null) {
            for (Object obj : list)
                reportList.add((Report) obj);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_REPORT_LIST);
        modelAndView.addObject("reportList", reportList);
        return reportList;
    }

    @RequestMapping(value = URL_REPORT_LIST, method = RequestMethod.POST)
    public ModelAndView postList(@RequestParam(defaultValue = "none") String cmd, @RequestParam(required = false) String[] checkedReportIds)
            throws ServletException, IOException {

        ModelAndView modelAndView;

        if (cmd.equalsIgnoreCase("add")) {
            modelAndView = new ModelAndView(VIEW_REPORT_ADD);
        } else if (cmd.equalsIgnoreCase("remove")) {
            removeReports(checkedReportIds);
            modelAndView = new ModelAndView("redirect:" + URL_REPORT_LIST);
        } else
            modelAndView = new ModelAndView("redirect:" + URL_REPORT_LIST);

        return modelAndView;
    }

    private void removeReports(String[] checkedReportIds) {
        if (checkedReportIds != null) {
            for (String value : checkedReportIds) {
                Long id = Long.parseLong(value);
                reportService.removeReport(id);
            }
        }

    }

    @RequestMapping(value = URL_REPORT_ADD, method = RequestMethod.POST)
    public ModelAndView addReport(@RequestParam(value = "report-name", defaultValue = "") String reportName,
                                  @RequestParam(value = "report-description", defaultValue = "") String reportDescription,
                                  @RequestParam(value = "export-filename", defaultValue = "") String exportFilename,
                                  @RequestParam(value = "report-file") MultipartFile reportFile,
                                  @RequestParam(value = "report-script", required = false) MultipartFile scriptFile
    )
            throws ServletException, IOException {


//        SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
/*
        UserDetail user = securityLoggedUser.getUserDetail();
        Db db = user.getDb();
*/
        Long tenantId = 0L;

        Report report = new Report();
        report.setTenantId(tenantId);
        report.setReportname(reportName);
        report.setDescription(reportDescription);
        report.setExportFileName(exportFilename);

        String filename = reportFile.getOriginalFilename();
        report.setOriginalFileName(filename);
        report.setFileSize(reportFile.getSize());
        int dotPos = filename.lastIndexOf(".") + 1;
        String fileExtention = filename.substring(dotPos).toLowerCase();
        report.setFileExtention(fileExtention);

        boolean hasParameterScript = (scriptFile != null && !scriptFile.isEmpty() && scriptFile.getSize() > 0);
        report.setHasParameterScript(hasParameterScript);

        reportService.saveReport(report);

        Long id = report.getId();

        String outFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + id.toString() + "." + fileExtention;

        if (logger.isDebugEnabled())
            logger.debug("outFileName: {}", outFileName);

        File outFile = new File(outFileName);
        if (outFile.createNewFile()) {
            reportFile.transferTo(outFile);
        }

        if (hasParameterScript) {
            String scriptFileName = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + id.toString() + ".groovy";
            if (logger.isDebugEnabled())
                logger.debug("scriptFileName: {}", scriptFileName);

            File outScript = new File(scriptFileName);
            if (outScript.createNewFile()) {
                scriptFile.transferTo(outScript);
            }
        }

        return new ModelAndView("redirect:" + URL_REPORT_LIST);
    }

    @RequestMapping(value = URL_REPORT_PARAM, method = RequestMethod.GET)
    public ModelAndView viewParam(HttpSession session,
                                  HttpServletRequest httpServletRequest,
                                  @RequestParam(defaultValue = "html") String type,
                                  @RequestParam(value = "id", defaultValue = "-1") Long id,
                                  @RequestParam(value = "objtype", required = false, defaultValue = "-1") Long objtype,
                                  @RequestParam(value = "objid", required = false, defaultValue = "-1") Long objid,
                                  @RequestParam(value = "cid", defaultValue = "-1") int contractId,
                                  @RequestParam(value = "datestart", required = false) String datestart,
                                  @RequestParam(value = "dateend", required = false) String dateend,
                                  @RequestParam(value = "cids", required = false) Long[] contractsIds)
            throws ServletException, IOException {

        ModelAndView modelAndView;
        Report report = null;

        if (id != null && id > 0)
            report = reportService.getReportById(id);

        if (report != null) {
            modelAndView = new ModelAndView(VIEW_REPORT_PARAM);
            StringBuilder paramBody = new StringBuilder();
            paramBody.append("<input type='hidden' name='id' value='").append(report.getId()).append("'>");
            paramBody.append("<input type='hidden' name='type' value='").append(type).append("'>");
            paramBody.append("<br/>");
            paramBody.append("Report ID: ").append(report.getId());
            paramBody.append("<br/>");
            paramBody.append("Report name: ").append(report.getName());
            paramBody.append("<br/>");
            paramBody.append("Report type: ").append(type.toUpperCase());
            paramBody.append("<br/>");

            String gPath = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/';
            String gScript = report.getId() + ".groovy";

            String[] roots = new String[]{gPath};
            GroovyScriptEngine gse = new GroovyScriptEngine(roots);
            Binding binding = new Binding();
            binding.setVariable("inputparam1", "parameter1");
            binding.setVariable("contractId", MainController.getUserContractId(session));
            binding.setVariable("contractsIds", MainController.getUserContractsIds(session));
            binding.setVariable("objtype", objtype);
            binding.setVariable("objid", objid);
            binding.setVariable("userId", MainController.getInterfaceUserId());

            binding.setVariable("dataSourceReport", dataSourceReport);
            binding.setVariable("datasource", dataSource);
            try {
                gse.run(gScript, binding);
            } catch (ResourceException e) {
                // logger.error("ResourceException: ", e);
                binding.setVariable("output", "");
            } catch (ScriptException e) {
                // logger.error("ScriptException: ", e);
                binding.setVariable("output", "");
            }

            String res = binding.getVariable("output").toString();

            paramBody.append(res);
            paramBody.append("<br/>");

//            modelAndView.addObject("paramBody", paramBody.toString());
            modelAndView.addObject("paramBody", res);
            modelAndView.addObject("reportType", report.getReportType());
            modelAndView.addObject("datestart", datestart);
            modelAndView.addObject("dateend", dateend);
        } else {
            logger.error("Report with id={} not found!", id);
            modelAndView = new ModelAndView("redirect:" + URL_REPORT_LIST);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_TRIP_REPORT_DOWNLOAD_XLS, method = RequestMethod.GET)
    public void getTripReport(HttpServletResponse response, HttpServletRequest request,
                              @RequestParam(value = "contract-id", required = false) String contractIdStr,
                              @RequestParam(value = "trip-type", required = false) String tripTypeIdStr,
                              @RequestParam(value = "start-date", required = false, defaultValue = "") String startDateStr,
                              @RequestParam(value = "end-date", required = false, defaultValue = "") String endDateStr)
            throws Exception, OutOfMemoryError {

        Long contractId = Converters.strToLong(contractIdStr, 0L);
        Long tripType = Converters.strToLong(tripTypeIdStr, 0L);

        Contract contract = adminService.getContractById(contractId);

        Date startDate;
        Date endDate;


        if (startDateStr.length() < 11) {
            startDateStr += " 00:00";
        }

        if (endDateStr.length() < 11) {
            endDateStr += " 00:00";
        }

        startDate = Converters.dateFormatterStringToDateFull(startDateStr);
        endDate = Converters.dateFormatterStringToDateFull(endDateStr);

        List<ReportTrip> tripData = statisticsServiceReport.getTripData(contractId, new
                Timestamp(startDate.getTime()), new Timestamp(endDate.getTime()), tripType.intValue());

//            List<ReportTripHeaderData> tripDataDetails = statisticsServiceReport.getTripDetails(contractId, new
//                    Timestamp(startDate.getTime()), new Timestamp(endDate.getTime()));

//            List<ReportTripHeaderData> tripDataDetails = null;

        Cookie[] cookies = request.getCookies();
        Long reportToken = 0L;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("qualityServicesDownloadToken")) {
                    reportToken = Long.valueOf(cookie.getValue());
                }
            }
        }

        Date startDateFull;
        Date endDateFull;

        startDateFull = Converters.dateFormatterStringToDateFull(startDateStr);
        endDateFull = Converters.dateFormatterStringToDateFull(endDateStr);

        ExcelTripReport excelTripReport = new ExcelTripReport(messageSource);
        excelTripReport.setDbList(tripData);
//            excelTripReport.setReportTripHeaderDataList(tripDataDetails);

        excelTripReport.setCompanyName(contract.getCustomerCompanyName());
        excelTripReport.setTripType(tripType.intValue());

        excelTripReport.setUserLogin(MainController.getUser().getLogin());
        excelTripReport.setStartDate(new Timestamp(startDateFull.getTime()));
        excelTripReport.setEndDate(new Timestamp(endDateFull.getTime()));

        excelTripReport.setToken(reportToken);
        excelTripReport.downloadXLS(response);

    }

    @RequestMapping(value = URL_OBJECT_MOVEMENT_REPORT_DOWNLOAD_XLS, method = RequestMethod.GET)
    public void getObjectMovementReport(HttpServletResponse response, HttpServletRequest request,
                                        @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                        @RequestParam(value = "object-id", required = false) String objectIdStr,
                                        @RequestParam(value = "trip-type", required = false) String tripTypeIdStr,
                                        @RequestParam(value = "start-date", required = false, defaultValue = "") String startDateStr,
                                        @RequestParam(value = "end-date", required = false, defaultValue = "") String endDateStr)
            throws Exception, OutOfMemoryError {

        Long contractId = Converters.strToLong(contractIdStr, 0L);
        Long objectId = Converters.strToLong(objectIdStr, 0L);
        int tripType = Converters.strToInt(tripTypeIdStr, 0);

        Contract contract = adminService.getContractById(contractId);
        MObject mObject = adminService.getMObjectById(objectId);

        Date startDate;
        Date endDate;

        if (startDateStr.length() < 11) {
            startDateStr += " 00:00";
        }

        if (endDateStr.length() < 11) {
            endDateStr += " 00:00";
        }

        startDate = Converters.dateFormatterStringToDateFull(startDateStr);
        endDate = Converters.dateFormatterStringToDateFull(endDateStr);

        List<ReportObjectMovement> objectMovementData = statisticsServiceReport.getObjectMovementData(contractId,
                objectId, new Timestamp(startDate.getTime()), new Timestamp(endDate.getTime()), tripType);

        Cookie[] cookies = request.getCookies();
        Long reportToken = 0L;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("qualityServicesDownloadToken")) {
                    reportToken = Long.valueOf(cookie.getValue());
                }
            }
        }

        Date startDateFull;
        Date endDateFull;

        startDateFull = Converters.dateFormatterStringToDate(startDateStr);
        endDateFull = Converters.dateFormatterStringToDate(endDateStr);

        ExcelObjectMovementReport excelObjectMovementReport = new ExcelObjectMovementReport(messageSource);
        excelObjectMovementReport.setDbList(objectMovementData);

        excelObjectMovementReport.setCompanyName(contract.getCustomerCompanyName());
        excelObjectMovementReport.setMobjectName(mObject.getmObjectName());
        excelObjectMovementReport.setTripType(tripType);

        excelObjectMovementReport.setUserLogin(MainController.getUser().getLogin());
        excelObjectMovementReport.setStartDate(new Timestamp(startDateFull.getTime()));
        excelObjectMovementReport.setEndDate(new Timestamp(endDateFull.getTime()));

        excelObjectMovementReport.setToken(reportToken);
        excelObjectMovementReport.downloadXLS(response);

    }

    @RequestMapping(value = URL_TRIP_REPORT_MOMENT_DOWNLOAD_XLS, method = RequestMethod.GET)
    public void getTripMomentReport(HttpServletResponse response, HttpServletRequest request,
                                    @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                    @RequestParam(value = "trip-type", required = false) String tripTypeIdStr,
                                    @RequestParam(value = "report-date", required = false, defaultValue = "") String reportDateStr)
            throws Exception, OutOfMemoryError {

        Long contractId = Converters.strToLong(contractIdStr, 0L);
        int tripType = Converters.strToInt(tripTypeIdStr, 0);


        Contract contract = adminService.getContractById(contractId);

        Date reportDate;

        if (reportDateStr.length() < 11) {
            reportDateStr += " 00:00";
        }

        reportDate = Converters.dateFormatterStringToDateFull(reportDateStr);

        List<ReportWorkingMobjects> tripData = statisticsServiceReport.getWorkingMobjectsData(contractId, new
                Timestamp(reportDate.getTime()), tripType);

        Cookie[] cookies = request.getCookies();
        Long reportToken = 0L;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("qualityServicesDownloadToken")) {
                    reportToken = Long.valueOf(cookie.getValue());
                }
            }
        }

        ExcelWorkingMobjectsReport excelWorkingMobjectsReport = new ExcelWorkingMobjectsReport(messageSource,
                contract.getCustomerCompanyName(), tripType, MainController.getUser().getLogin());

        excelWorkingMobjectsReport.setDbList(tripData);

//            excelWorkingMobjectsReport.setCompanyName(contract.getCustomerCompanyName());
//            excelWorkingMobjectsReport.setTripType(tripType);
//
//            excelWorkingMobjectsReport.setUserLogin(MainController.getUser().getLogin());

        excelWorkingMobjectsReport.setReportDate(new Timestamp(reportDate.getTime()));

        excelWorkingMobjectsReport.setToken(reportToken);
        excelWorkingMobjectsReport.downloadXLS(response);

    }

    @RequestMapping(value = URL_TRIP_SUMMARY_REPORT_DOWNLOAD_XLS, method = RequestMethod.GET)
    public void getTripSummaryReport(HttpServletResponse response, HttpServletRequest request,
                                     @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                     @RequestParam(value = "trip-type", required = false) String tripTypeIdStr,
                                     @RequestParam(value = "start-date", required = false, defaultValue = "") String startDateStr,
                                     @RequestParam(value = "end-date", required = false, defaultValue = "") String endDateStr)
            throws Exception, OutOfMemoryError {


        Long contractId = Converters.strToLong(contractIdStr, 0L);
        Long tripType = Converters.strToLong(tripTypeIdStr, 0L);

        Contract contract = adminService.getContractById(contractId);

        Date startDate;
        Date endDate;

        if (startDateStr.length() < 11) {
            startDateStr += " 00:00";
        }

        if (endDateStr.length() < 11) {
            endDateStr += " 00:00";
        }

        startDate = Converters.dateFormatterStringToDateFull(startDateStr);
        endDate = Converters.dateFormatterStringToDateFull(endDateStr);

        List<ReportTripSummary> tripSummaryData = statisticsServiceReport.getTripSummaryData(contractId, new
                Timestamp(startDate.getTime()), new Timestamp(endDate.getTime()), tripType.intValue());

        Cookie[] cookies = request.getCookies();
        Long reportToken = 0L;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("qualityServicesDownloadToken")) {
                    reportToken = Long.valueOf(cookie.getValue());
                }
            }
        }

        Date startDateFull;
        Date endDateFull;

        startDateFull = Converters.dateFormatterStringToDateFull(startDateStr);
        endDateFull = Converters.dateFormatterStringToDateFull(endDateStr);

        ExcelTripSummaryReport excelTripSummaryReport = new ExcelTripSummaryReport(messageSource);
        excelTripSummaryReport.setDbList(tripSummaryData);

        excelTripSummaryReport.setCustomerCompanyName(contract.getCustomerCompanyName());
        excelTripSummaryReport.setTripType(tripType.intValue());

        excelTripSummaryReport.setUserLogin(MainController.getUser().getLogin());
        excelTripSummaryReport.setStartDate(new Timestamp(startDateFull.getTime()));
        excelTripSummaryReport.setEndDate(new Timestamp(endDateFull.getTime()));

        excelTripSummaryReport.setToken(reportToken);
        excelTripSummaryReport.downloadXLS(response);

    }

    @RequestMapping(value = URL_ROUTE_VIOLATIONS_REPORT_DOWNLOAD_XLS, method = RequestMethod.GET)
    public void getRouteViolationsReport(HttpServletResponse response, HttpServletRequest request,
                                         @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                         @RequestParam(value = "route-id", required = false) String routeIdStr,
                                         @RequestParam(value = "object-id", required = false) String objectIdStr,
                                         @RequestParam(value = "trip-type", required = false) String tripTypeIdStr,
                                         @RequestParam(value = "start-date", required = false, defaultValue = "") String startDateStr,
                                         @RequestParam(value = "end-date", required = false, defaultValue = "") String endDateStr)
            throws Exception, OutOfMemoryError {

        Long contractId = Converters.strToLong(contractIdStr, 0L);
        Long tripType = Converters.strToLong(tripTypeIdStr, 0L);

        Long routeId = Converters.strToLong(routeIdStr, 0L);
        Long objectId = Converters.strToLong(objectIdStr, 0L);

        Contract contract = adminService.getContractById(contractId);

        Date startDate;
        Date endDate;

        if (startDateStr.length() < 11) {
            startDateStr += " 00:00";
        }

        if (endDateStr.length() < 11) {
            endDateStr += " 00:00";
        }

        startDate = Converters.dateFormatterStringToDateFull(startDateStr);
        endDate = Converters.dateFormatterStringToDateFull(endDateStr);

        List<ReportRouteViolations> routeViolationsData = statisticsServiceReport.getRouteViolationsData(contractId, routeId, objectId,
                new Timestamp(startDate.getTime()), new Timestamp(endDate.getTime()), tripType.intValue());

        addAddressesToViolationsData(routeViolationsData);

        Cookie[] cookies = request.getCookies();
        Long reportToken = 0L;

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("qualityServicesDownloadToken")) {
                    reportToken = Long.valueOf(cookie.getValue());
                }
            }
        }

        Date startDateFull;
        Date endDateFull;

        startDateFull = Converters.dateFormatterStringToDateFull(startDateStr);
        endDateFull = Converters.dateFormatterStringToDateFull(endDateStr);

        ExcelRouteViolationsReport excelRouteViolationsReport = new ExcelRouteViolationsReport(messageSource);
        excelRouteViolationsReport.setDbList(routeViolationsData);

        excelRouteViolationsReport.setCustomerCompanyName(contract.getCustomerCompanyName());
        excelRouteViolationsReport.setTripType(tripType.intValue());

        excelRouteViolationsReport.setUserLogin(MainController.getUser().getLogin());
        excelRouteViolationsReport.setStartDate(new Timestamp(startDateFull.getTime()));
        excelRouteViolationsReport.setEndDate(new Timestamp(endDateFull.getTime()));

        excelRouteViolationsReport.setToken(reportToken);
        excelRouteViolationsReport.downloadXLS(response);
    }

    @Transactional()
    @RequestMapping(value = URL_REPORT_VIEW)
    public ModelAndView viewReport(HttpSession session,
                                   HttpServletRequest httpServletRequest,
                                   HttpServletResponse httpServletResponse,
                                   Locale locale,
                                   @RequestParam(defaultValue = "html") String type,
                                   @RequestParam(value = "reportId", defaultValue = "-1") Long id,
                                   @RequestParam(value = "datestart", defaultValue = "2021-01-01 00:00") String dateStart,
                                   @RequestParam(value = "dateend", defaultValue = "2021-01-01 00:00") String dateEnd)
            throws IOException {

        ModelAndView modelAndView = null;
        Report report = null;

        if (id != null && id > 0) {
            report = reportService.getReportById(id);
        }

        if (report != null) {
            String exportFilename = report.getExportFileName();
            if (!(exportFilename != null && !exportFilename.isEmpty())) {
                exportFilename = report.getId().toString();
            }
            exportFilename = "Report" + id + "-" + dateFormat(dateStart) + "-" + dateFormat(dateEnd) + "-";

            SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss.");
            String reportFilename = exportFilename + df.format(new Date()) + type;

            String url = "file:///" +
                    appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' +
                    report.getId().toString() +
                    "." +
                    report.getFileExtention();

            // setting report parameters
            Map<String, Object> reportParams = new HashMap<String, Object>();
            reportParams.put("datestart", dateStart);
            reportParams.put("dateend", dateEnd);

            // Prepare parameters for Groovy report
            Map<String, String[]> parameterMap = httpServletRequest.getParameterMap();
            Set parameterSet = parameterMap.entrySet();

            // Prepare Groovy itself
            String gPath = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/';
            String gScript = "r" + report.getId() + ".groovy";

            String lang = "ru";

            if (locale != null && locale.getLanguage() != null) {
                lang = locale.getLanguage();
            }

            String[] roots = new String[]{gPath};
            GroovyScriptEngine gse = new GroovyScriptEngine(roots);
            Binding binding = new Binding();
            binding.setVariable("contractId", MainController.getUserContractId(session));
            binding.setVariable("contractsIds", MainController.getUserContractsIds(session));
            binding.setVariable("dataSourceReport", dataSourceReport);
            binding.setVariable("datasource", dataSource);
            binding.setVariable("pdatestart", dateStart);
            binding.setVariable("pdateend", dateEnd);
            binding.setVariable("userId", MainController.getInterfaceUserId());
            binding.setVariable("lang", lang);

            try {
                // Set parameters to Groovy
                for (Object aParameterSet : parameterSet) {
                    Map.Entry<String, String[]> entry = (Map.Entry<String, String[]>) aParameterSet;
                    String paramName = entry.getKey();
                    String[] paramValues = entry.getValue();
                    String paramValue = null;
                    if (paramValues.length == 1)
                        paramValue = paramValues[0];
                    if (paramName.startsWith(paramPrefix)) {
                        paramName = paramName.substring(paramPrefix.length());
                        binding.setVariable(paramName, paramValue);
                    }
                }
            } catch (Exception e) {
                logger.error("Exception: ", e);
            }

            try {
                gse.run(gScript, binding);
            } catch (ResourceException e) {
                logger.error("ResourceException: ", e);
                modelAndView = new ModelAndView("report_resource_exception" + "_" + e.getMessage());
                return modelAndView;
            } catch (ScriptException e) {
                logger.error("ScriptException: ", e);
                modelAndView = new ModelAndView("report_script_exception" + "_" + e.getMessage());
                return modelAndView;
            } catch (NumberFormatException e) {
                logger.error("NumberFormatException: " + e.getMessage());
                modelAndView = new ModelAndView("report_num_format_exception" + "_" + e.getMessage());
                return modelAndView;
            } catch (NullPointerException e) {
                logger.error("NullPointerException: " + e.getMessage());
                modelAndView = new ModelAndView("report_null_exception" + "_" + e.getMessage());
                return modelAndView;
            } catch (Exception e) {
                logger.error("Exception: " + e.getMessage());
                modelAndView = new ModelAndView("report_unknown_exception" + "_" + e.getMessage());
                return modelAndView;
            }

            try {
                reportParams.putAll(binding.getVariables());
                modelAndView = generateReport(session, httpServletRequest, httpServletResponse, url, type, reportFilename, reportParams, report);
            } catch (Exception e) {
                logger.error("Error in generateReport: " + e.getMessage());
            } finally {
                String language = "ru";
                if (locale != null && locale.getLanguage() != null) language = locale.getLanguage();

                try {
                    adminJournal.logging(
                            UZGPS_CONST.JOURNAL_ACT_GET,
                            UZGPS_CONST.JOURNAL_REPORT_VIEW,
                            UZGPS_CONST.JOURNAL_REPORT,
                            new ReportGetDTO(id, lang, "", dateStart, dateEnd));
                } catch (Exception e) {
                    logger.error("Error when logging viewReportForMobile", e);
                }
            }
        } else {
            logger.error("Report with id={} not found!", id);
            modelAndView = new ModelAndView("redirect:" + URL_REPORT_LIST);
        }

        return modelAndView;
    }

    private ModelAndView generateReport(HttpSession session,
                                        HttpServletRequest httpServletRequest,
                                        HttpServletResponse httpServletResponse,
                                        String url,
                                        String type,
                                        String reportFilename,
                                        Map<String, Object> params,
                                        Report report)
            throws IllegalArgumentException {

        AbstractJasperReportsSingleFormatView jasperReportView;

        if (type.equalsIgnoreCase("html"))
            jasperReportView = new JasperReportsHtmlView();
        else if (type.equalsIgnoreCase("pdf"))
            jasperReportView = new JasperReportsPdfView();
        else if (type.equalsIgnoreCase("xls"))
            jasperReportView = new JasperReportsXlsView();
        else if (type.equalsIgnoreCase("csv"))
            jasperReportView = new JasperReportsCsvView();
        else
            throw new IllegalArgumentException("Unrecognized report format:" + type);

        // setting properties
        if (report != null && report.getWorkingDb() == Report.DB_MAIN)
            jasperReportView.setJdbcDataSource(dataSource);
        else
            jasperReportView.setJdbcDataSource(dataSourceReport);
        jasperReportView.setUrl(url);

        Map<String, Object> exporterParameters = new HashMap<String, Object>();
        exporterParameters.put("net.sf.jasperreports.engine.JRExporterParameter.CHARACTER_ENCODING", "UTF-8");

        if (!type.equalsIgnoreCase("html")) {
            // prepare content header
            Properties availableHeaders = new Properties();
            availableHeaders.put(type, "inline; filename=" + reportFilename);

            // setting content disposition header
            Properties headers = new Properties();

            headers.put("Content-Disposition", availableHeaders.get(type));
            jasperReportView.setHeaders(headers);
        } else {
            // set url for Jasper reports image servlet
            exporterParameters.put("net.sf.jasperreports.engine.export.JRHtmlExporterParameter.IMAGES_URI", "/images?image=");
        }

        jasperReportView.setExporterParameters(exporterParameters);

        // setting webApplicationContext required by the view
        HttpSession httpSession = httpServletRequest.getSession();
        ServletContext servletContext = httpSession.getServletContext();
        WebApplicationContext webApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);

        jasperReportView.setApplicationContext(webApplicationContext);

        ModelAndView modelAndView;
        modelAndView = new ModelAndView(jasperReportView);
        modelAndView.addObject("contractIdList", MainController.getUserContracts(session));

        if (params != null)
            modelAndView.addAllObjects(params);

        return modelAndView;
    }

    /**
     * Convers date from 01.02.1970 format to 19700201 format
     *
     * @param dateFrom date in string
     * @return new format in String
     */
    private String dateFormat(String dateFrom) {
        if (dateFrom != null) {
            String dateStr;
            dateStr = dateFrom.replaceAll("[^0-9]+", "");
            if (dateStr.length() > 7) {
                dateStr = dateStr.substring(4, 8) + dateStr.substring(2, 4) + dateStr.substring(0, 2);
                return dateStr;
            }
        }
        return "";
    }

    // For mobile API
    public ModelAndView viewReportForMobile(
            HttpServletRequest httpServletRequest,
            HttpServletResponse httpServletResponse,
            String language,
            String type,
            Long reportId,
            Long contractId,
            Long userId,
            Long objectId,
            String dateStart,
            String dateEnd
    ) throws ServletException, IOException {

        ModelAndView modelAndView;
        Report report = null;

        if (reportId != null && reportId > 0)
            report = reportService.getReportById(reportId);

        if (report != null) {
            String exportFilename = "Report" + reportId + "-" + dateFormat(dateStart) + "-" + dateFormat(dateEnd) + "-";


            SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss.");
            String reportFilename = exportFilename + df.format(new Date()) + type;

            String url = "file:///" +
                    appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' +
                    report.getId().toString() +
                    "." +
                    report.getFileExtention();

            //setting report parameters
            Map<String, Object> reportParams = new HashMap<>();
            reportParams.put("datestart", dateStart);
            reportParams.put("dateend", dateEnd);


            // Prepare parameters for Groovy report
            Map<String, String[]> parameterMap = httpServletRequest.getParameterMap();
            Set<Map.Entry<String, String[]>> parameterSet = parameterMap.entrySet();

            // Prepare Groovy itself
            String gPath = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/';
            String gScript = "r" + report.getId() + ".groovy";

            String lang = (language != null) ? language : "ru";

            String[] roots = new String[]{gPath};
            GroovyScriptEngine gse = new GroovyScriptEngine(roots);
            Binding binding = new Binding();
            binding.setVariable("contractId", contractId);
            binding.setVariable("contractsIds", null);
            binding.setVariable("dataSourceReport", dataSourceReport);
            binding.setVariable("datasource", dataSource);
            binding.setVariable("pdatestart", dateStart);
            binding.setVariable("pdateend", dateEnd);
            binding.setVariable("userId", userId);
            binding.setVariable("objectid", objectId);
            binding.setVariable("lang", lang);

            // Set parameters to Groovy
            for (Map.Entry<String, String[]> aParameterSet : parameterSet) {
                String paramName = aParameterSet.getKey();
                String[] paramValues = aParameterSet.getValue();
                String paramValue = null;
                if (paramValues.length == 1)
                    paramValue = paramValues[0];
                if (paramName.startsWith(paramPrefix)) {
                    paramName = paramName.substring(paramPrefix.length());
                    binding.setVariable(paramName, paramValue);
                }
            }

            try {
                gse.run(gScript, binding);
            } catch (ResourceException e) {
                logger.error("ResourceException: ", e);
            } catch (ScriptException e) {
                logger.error("ScriptException: ", e);
            } catch (Exception e) {
                logger.error("Exception: " + e);
            }

            reportParams.putAll(binding.getVariables());

            modelAndView = generateReport(null, httpServletRequest, httpServletResponse, url, type, reportFilename, reportParams, report);

            try {
                adminJournal.logging(
                        UZGPS_CONST.JOURNAL_ACT_GET,
                        UZGPS_CONST.JOURNAL_REPORT_MOBILE_VIEW,
                        UZGPS_CONST.JOURNAL_REPORT,
                        new ReportGetDTO(reportId, lang, "", dateStart, dateEnd));
            } catch (Exception e) {
                logger.error("Error when logging viewReportForMobile", e);
            }

        } else {
            logger.error("Report with reportId={} not found!", reportId);
            modelAndView = new ModelAndView("redirect:" + URL_REPORT_LIST);
        }
        return modelAndView;
    }

    /**
     * Add address to violation data
     *
     * @param routeViolations
     */
    private void addAddressesToViolationsData(List<ReportRouteViolations> routeViolations) {
        String nominatimAddress = UrlConfiguration.getUrlNominatim();
        NominatimHelper nominatimHelper = new NominatimHelper(nominatimAddress);

        String address;

        if (!routeViolations.isEmpty()) {
            for (ReportRouteViolations routeViolation : routeViolations)
                if (routeViolation.getViolationType() == 1) {
                    address = nominatimHelper.getAddressByCoordinates(routeViolation.getViolationLongitude(), routeViolation.getViolationLatitude());
                    routeViolation.setViolationPlace(address);
                }

        }
    }

    // For mobile API
    public ResponseApi getReportListByContractId(Long contractId) {
        ResponseApi response = new ResponseApi();
        try {
            List getList = reportService.getReportListByContract(contractId);
            if (getList != null) {
                List<Report> reportList = new ArrayList<>();
                for (Object reportAcl : getList) {
                    if (reportAcl instanceof ReportACL) {
                        reportList.add(((ReportACL) reportAcl).getReport());
                    }
                }
                response.setResult(reportList);
            }
        } catch (Exception e) {
            response.setError(e.getMessage());
        }
        return response;
    }
}
