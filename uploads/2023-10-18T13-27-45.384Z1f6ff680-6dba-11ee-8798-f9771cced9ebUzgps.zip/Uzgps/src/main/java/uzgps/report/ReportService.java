package uzgps.report;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.common.GrpUtils;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.persistence.Report;
import uzgps.trafficSchedule.MobjectInPoiDetail;

import javax.persistence.*;
import java.util.List;

/**
 * User: Sheroz Khaydarov
 * Date: 21.02.13 Time: 19:38
 */

@Service
@Component
public class ReportService {
    Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private AppConfiguration appConfiguration;

    @Transactional(readOnly = true)
    public List getReportList(long tenantId) {
        Query query;
        query = em.createNamedQuery("Report.getListByTenantId");
        query.setParameter("tenantId", tenantId);

        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public List getReportListByContract(long contractId, String language) {
        Query query;
        query = em.createNamedQuery("Report.getListByContractId");
        query.setParameter("contractId", contractId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
        query.setParameter("language", language);
        query.setParameter("access", 1);

        return query.getResultList();
    }

    @Transactional(readOnly = true)
    public List getReportListByContract(long contractId) {
        Query query;
        query = em.createNamedQuery("Report.getListByContractIdMultiLang");
        query.setParameter("contractId", contractId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
        query.setParameter("access", 1);

        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MobjectInPoiDetail> getMobjectInPoiDetails(long contractId, String startDate, String endDate) {
        try {
            try {
                String sql = "SELECT ROW_NUMBER() OVER (ORDER BY mobject_id) AS id , " +
                        " contract_id, poi_id, mobject_id, date_in_poi, date_out_poi " +
                        " FROM poi_notification.contract_mobjects_in_out_poi(?, ?, ?) " +
                        " ORDER BY date_in_poi;";

                Query q = em.createNativeQuery(sql, MobjectInPoiDetail.class);
                // Contract id
                q.setParameter(1, contractId);
                // Start date
//                q.setParameter(2, "01.10.2017 08:00");
                q.setParameter(2, startDate);
                // End date
//                q.setParameter(3, "10.10.2017 08:00");
                q.setParameter(3, endDate);

                List<MobjectInPoiDetail> trSdv = q.getResultList();

                return trSdv;
            } catch (NoResultException e) {
                logger.error("getMobjectInPoiDetails error: " + e.getMessage());
            }
        } catch (Exception ex) {
            logger.error("getMobjectInPoiDetails error: " + ex.getMessage());
        }
        return null;
    }

    @Transactional(readOnly = true)
    public List getReportListByContractAndCategory(long contractId, String language, long category) {
        Query query;
        query = em.createNamedQuery("Report.getListByContractIdAndCategory");
        query.setParameter("contractId", contractId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
        query.setParameter("language", language);
        query.setParameter("category", category);
        query.setParameter("access", 1);

        return query.getResultList();
    }

    @Transactional()
    public Report getReportById(Long id) {
        if (id == null)
            throw new IllegalArgumentException("report id is null");

        TypedQuery<uzgps.persistence.Report> query;
        query = em.createNamedQuery("Report.getById", uzgps.persistence.Report.class);
        query.setParameter("id", id);
        return query.getSingleResult();
    }

    @Transactional
    public void saveReport(Report report) {
        if (report == null)
            throw new IllegalArgumentException("report object is null");

        if (report.getId() != null)
            em.merge(report); // update
        else
            em.persist(report); // add new
    }

    @Transactional
    public void removeReport(Long id) {
        if (id == null)
            throw new IllegalArgumentException("object id is null");

        Report report = getReportById(id);
        if (report != null) {
            em.remove(report);
            String reportFile = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + report.getId().toString() + "." + report.getFileExtention();
            GrpUtils.removeFile(reportFile);
            String scriptFile = appConfiguration.getReportConfiguration().getPath() + report.getLanguage() + '/' + report.getId().toString() + ".groovy";
            GrpUtils.removeFile(scriptFile);

        }
    }


}
