package uzgps.common;

/**
 * User: Bobur
 * Date: 31.07.12
 * Time: 13:18
 */

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.servlet.ModelAndView;
import uzgps.main.AppLastStatus;

import javax.xml.namespace.QName;
import javax.xml.stream.events.XMLEvent;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CommonUtils {
    public static String getStackTrace(Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw, true);
        t.printStackTrace(pw);
        pw.flush();
        sw.flush();
        return sw.toString();
    }

    public enum GuideType {
        DB,
        DEPARTMENT,
        USER,
        ORG;
    }

    public enum MessageType {
        INFO,
        SUCCESS,
        ERROR
    }

    public class FileUploadBean {

        private byte[] file;

        public void setFile(byte[] file) {
            this.file = file;
        }

        public byte[] getFile() {
            return file;
        }
    }

    public static ModelAndView getMessageDialog(String messageText, String messageDetails, MessageType messageType) {
        ModelAndView modelAndView = new ModelAndView("common/ajaxMessage");
        modelAndView.addObject("messageText", messageText);
        modelAndView.addObject("messageDetails", messageDetails);
        return modelAndView;
    }

    public static ModelAndView getMessageDialog(String messageText) {
        return getMessageDialog(messageText, null, MessageType.INFO);
    }

    public static String generateRandomString() {
        SecureRandom random = new SecureRandom();
        return new BigInteger(130, random).toString(32).substring(0, 15);
    }

    public static Timestamp safeParseTimestamp(String value) {
        try {
            if (value != null && value.length() > 0) {
                if (value.length() == 10) {
                    value = value.substring(6, 10) + '-' + value.substring(3, 5) + '-' + value.substring(0, 2);
                    value = value.concat(" 00:00:00.000");
                }
                return Timestamp.valueOf(value);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Long safeParseLong(String value) {
        try {
            if (value != null && value.length() > 0) {
                return Long.parseLong(value);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Long safeParseLong(Object value) {
        try {
            if (value != null) {
                return (Long) value;
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Short safeParseShort(String value) {
        try {
            if (value != null && value.length() > 0) {
                return Short.parseShort(value);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Integer safeParseInteger(String value) {
        try {
            if (value != null && value.length() > 0) {
                return Integer.parseInt(value);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    public static Boolean safeParseBoolean(String value) {
        try {
            if (value != null && value.length() > 0) {
                return Boolean.parseBoolean(value);
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    private String getAttribute(XMLEvent event, String attributeName) {
        if (event.isStartElement()) {
            return event.asStartElement().getAttributeByName(new QName(attributeName)).getValue();
        } else {
            return null;
        }
    }

    private Boolean isStartElement(XMLEvent event, String elementName) {
        if (event.isStartElement() && event.asStartElement().getName().getLocalPart().equals(elementName)) {
            return true;
        } else {
            return false;
        }
    }

    public static Integer calcMaxPage(Integer rowCount, Integer limitRows) {
        Integer maxPages = (rowCount - rowCount % limitRows) / limitRows + (rowCount % limitRows > 0 ? 1 : 0);
        if (maxPages == 0) maxPages = 1;
        return maxPages;
    }

    public static AppLastStatus deserializeStatus(ObjectMapper jsonMapper, String appStatus) {
        AppLastStatus appLastStatus;
        try {
            appLastStatus = jsonMapper.readValue(appStatus, AppLastStatus.class);
        } catch (IOException e) {
            appLastStatus = new AppLastStatus();
        }
        return appLastStatus;
    }

    public static String serializeStatus(ObjectMapper jsonMapper, AppLastStatus appLastStatus) {
        String status = null;
        try {
            status = jsonMapper.writeValueAsString(appLastStatus);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return status;
    }

    /**
     * Convert milliseconds to hours ans minutes HH:mm format
     *
     * @param millis
     */
    public static String millisToHoursAndMinutes(Long millis) {
        try {
            millis = Math.abs(millis);

            Long hours = (long) Math.floor(millis / 3600000);
            Long minutes = ((millis % 3600000) / 60000);

            return (hours < 10 ? "0" : "") + hours + ":" + (minutes < 10 ? "0" : "") + minutes;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "00:00";
    }

    /**
     * @param currentPage
     * @param maxPages
     * @return
     */
    public static List<Integer> getPages(Integer currentPage, Integer maxPages) {
        List<Integer> list = new ArrayList<>();
        if (currentPage != null && maxPages != null) {
            if (maxPages > 0) list.add(0); // 1 page
            if (maxPages > 1) list.add(1); // 2 page
            if (maxPages > 2) list.add(2); // 3 page

            if (currentPage > 1) {
                if (!list.contains(currentPage - 1) && (currentPage - 1 < maxPages))
                    list.add(currentPage - 1); // current - 1

                if (!list.contains(currentPage) && (currentPage < maxPages))
                    list.add(currentPage); // current

                if (!list.contains(currentPage + 1) && (currentPage + 1 < maxPages))
                    list.add(currentPage + 1); // current + 1
            }

            // Last 3 page numbers
            for (int k = 1; k <= 3; k++) {
                int value = (int) (maxPages - k);
                if (!list.contains(value) && (value > 0)) list.add(value);
            }

            Collections.sort(list);

        }
        return list;
    }

    /**
     * Returns page count from number of elements
     * in page {@link UZGPS_CONST#LIST_PER_PAGE }
     *
     * @param count how many elements do you have?
     * @return Greatest number in devision, 0 if something wrong
     */
    public static int getPageCount(int count) {
        return (count + UZGPS_CONST.LIST_PER_PAGE - 1) / UZGPS_CONST.LIST_PER_PAGE;
    }
}
