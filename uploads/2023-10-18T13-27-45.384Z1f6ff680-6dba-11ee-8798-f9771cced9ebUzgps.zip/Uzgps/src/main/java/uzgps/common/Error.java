package uzgps.common;

/**
 * Created by Saidolim on 06.04.15.
 */
public class Error {

    // Error numbers
    public static final int ERR_SUCCESS = 0;
    public static final int ERR_DB_CONNECT_ERROR = 1;
    public static final int ERR_OBJECT_IS_NULL = 2;
    public static final int ERR_MOBJECT_IS_NULL = 3;
    public static final int ERR_TRACKER_IS_NOT_FOUND = 10;
    public static final int ERR_TRACKER_ASSIGNED_TO_OTHER = 11;
    public static final int ERR_SIM_ASSIGNED_TO_OTHER = 12;
    public static final int ERR_MOBJECT_GPS_UNIT_NOT_EXISTS = 13;
    public static final int ERR_MOBJECT_GPS_UNIT_EXISTS_MORE = 14;
    public static final int ERR_NO_CUSTOMER_ADMIN_FOR_CONTRACT = 15;

    // Fuel Datchik
    public static final int ERR_FUEL_DATCHIK_INSERT = 1200;
    public static final int ERR_FUEL_DATCHIK_UPDATE = 1201;
    public static final int ERR_FUEL_DATCHIK_DELETE = 1202;
    public static final int ERR_FUEL_DATCHIK_DELETE_BY_MOBJECT_ID = 1203;

    public static final int ERR_FUEL_NORM_INSERT = 1210;
    public static final int ERR_FUEL_NORM_UPDATE = 1211;
    public static final int ERR_FUEL_NORM_DELETE = 1212;
    public static final int ERR_FUEL_NORM_DELETE_BY_MOBJECT_ID = 1213;

    // Route Form Validation
//    public static final int ERR_ROUTE_NAME = 10100;
//    public static final int ERR_ROUTE_ROAD_WIDTH = 10101;
//    public static final int ERR_ROUTE_ROAD_WIDTH_MIN = 10102;
//    public static final int ERR_ROUTE_ROAD_WIDTH_MAX = 10103;
//    public static final int ERR_ROUTE_FONT_SIZE = 10104;
//    public static final int ERR_ROUTE_FONT_SIZE_MIN = 10105;
//    public static final int ERR_ROUTE_FONT_SIZE_MAX = 10106;
//    public static final int ERR_ROUTE_ACCESS = 10107;

    // Station Form Validation
//    public static final int ERR_STATION_NAME = 10200;
//    public static final int ERR_STATION_FONT_SIZE = 10201;
//    public static final int ERR_STATION_FONT_SIZE_MIN = 10202;
//    public static final int ERR_STATION_FONT_SIZE_MAX = 10203;
//    public static final int ERR_STATION_WIDTH = 10204;
//    public static final int ERR_STATION_WIDTH_MIN = 10205;
//    public static final int ERR_STATION_WIDTH_MAX = 10206;
//    public static final int ERR_STATION_RADIUS = 10207;
//    public static final int ERR_STATION_RADIUS_MIN = 10208;
//    public static final int ERR_STATION_RADIUS_MAX = 10209;
//    public static final int ERR_STATION_ACCESS = 10210;
}
