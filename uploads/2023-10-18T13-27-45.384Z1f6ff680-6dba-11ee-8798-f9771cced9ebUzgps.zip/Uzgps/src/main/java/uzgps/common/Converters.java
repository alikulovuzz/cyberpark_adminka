package uzgps.common;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Saidolim on 28.05.15.
 */
public class Converters {

    @Autowired
    private static MessageSource messageSource;

    /**
     * Converts String type float value into Float.
     * Before convert, replaves all commas (,) to dots (.)
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return float value of result
     */
    public static Float strToFloat(String value, Float defaultValue) {
        try {
            String valueWithDot = value.replaceAll(",", ".");
            valueWithDot = valueWithDot.replaceAll(" ", "");
            Float f = Float.valueOf(valueWithDot);
            return f;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type double value into Double.
     * Before convert, replaves all commas (,) to dots (.)
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return double value of result
     */
    public static Double strToDouble(String value, Double defaultValue) {
        try {
            String valueWithDot = value.replaceAll(",", ".");
            valueWithDot = valueWithDot.replaceAll(" ", "");
            Double f = Double.valueOf(valueWithDot);
            return f;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type int value into Integer.
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return float value of result
     */
    public static Integer strToInt(String value, Integer defaultValue) {
        try {
            String valueWithDot = value.replaceAll(" ", "");
            Integer v = Integer.valueOf(valueWithDot);
            return v;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type int value into Long.
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return Long value of result
     */
    public static Long strToLong(String value, Long defaultValue) {
        try {
            String valueWithDot = value.replaceAll(" ", "");
            Long v = Long.valueOf(valueWithDot);
            return v;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * @param in
     * @param position
     * @return
     */
    public static int getBitValue(int in, int position) {
        return (in >> position) & 1;
    }

    /**
     * @param in
     * @param position
     * @param value
     * @return
     */
    public static int setBitValue(int in, int position, int value) {
        if (position > 0 && position < 31) {
            if (value == 0) {
                return in & (0xBFFFFFFD >> (30 - position));
            } else {
                return in | (1 << (position));
            }
        }
        return in;
    }

    public static boolean strToBoolean(String val, boolean defaultValue) {
        try {
            switch (val) {
                case "false":
                    return false;
                case "true":
                    return true;
                default:
                    return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return defaultValue;
    }

    /**
     * Timestamp to String format "dd.MM.yyyy HH:mm"
     *
     * @param time Timestamp object
     * @return "" if null
     */
    public static String timeToStr(Timestamp time) {
        if (time != null && time.getTime() > 1) {
            return new SimpleDateFormat("dd.MM.yyyy HH:mm").format(time);
        }
        return "";
    }

    /**
     * Timestamp to String format "dd.MM.yyyy HH:mm:ss"
     *
     * @param time Timestamp object
     * @return "" if null
     */
    public static String timeWithSecondsToStr(Timestamp time) {
        if (time != null && time.getTime() > 1) {
            return new SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(time);
        }
        return "";
    }

    public static final long TIME_MINUTE = 60_000;
    public static final long TIME_HOUR = 60 * TIME_MINUTE;
    public static final long TIME_DAY = 24 * TIME_HOUR;
    public static final long TIME_YEAR = 365 * TIME_DAY;

    public static String calculateDateFormatted(long timeLong) {
        if (timeLong == 0) return "";

        long currentDate = System.currentTimeMillis();
        long time_diff = currentDate - timeLong;
        time_diff = (time_diff < 0) ? 0 : time_diff;

        if (time_diff < TIME_MINUTE) {
            return Math.round(time_diff / 1000.) + " сек";
        } else if (time_diff < TIME_HOUR) {
            time_diff = Math.round((time_diff / TIME_MINUTE)) % 60;
            return time_diff + " мин";
        } else if (time_diff < TIME_DAY) {
            return new SimpleDateFormat("HH:mm").format(timeLong);
        } else if (time_diff < TIME_YEAR) {
            return new SimpleDateFormat("d MMM").format(timeLong);
        }
        return new SimpleDateFormat("MMM yyyy").format(timeLong);
    }

    /**
     * This function converts String data from dd.MM.yyyy HH:mm to Date to
     * "yyyy-MM-dd HH:mm:ss" format
     *
     * @param dateFrom String in dd.MM.yyyy HH:mm format
     * @return Date object
     */
    public static Timestamp dateFormatterTimestamp(String dateFrom) {
        SimpleDateFormat dateFormatterFrom = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

        if (dateFrom.length() == 16) {
            dateFrom += ":00";
        }

        Date convertedCurrentDate;
        Timestamp timestamp = null;
        try {
            convertedCurrentDate = dateFormatterFrom.parse(dateFrom);
            timestamp = new Timestamp(convertedCurrentDate.getTime());
        } catch (ParseException e) {
            //        e.printStackTrace();
        }

        return timestamp;
    }

    public static String simpleDateFormat(Date date) {
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

        return dateFormat.format(date);
    }

    public static Timestamp dateFormatterTimestampSimple(String dateFrom) {
        SimpleDateFormat dateFormatterFrom = new SimpleDateFormat("dd.MM.yyyy");

        if (dateFrom.length() == 10) {
            Date convertedCurrentDate;
            Timestamp timestamp = null;
            try {
                convertedCurrentDate = dateFormatterFrom.parse(dateFrom);
                timestamp = new Timestamp(convertedCurrentDate.getTime());
            } catch (ParseException e) {
                //        e.printStackTrace();
            }
            return timestamp;
        }
        return null;
    }

    /**
     * Return Date in String format from Timestamp
     *
     * @param date
     * @return
     */
    public static String dateFormatterTimestampToStringSimple(Timestamp date) {
        SimpleDateFormat dateFormatterFrom = new SimpleDateFormat("dd.MM.yyyy");
        String result = "";
        try {
            return dateFormatterFrom.format(date);
        } catch (Exception e) {
            return result;
        }
    }

    /**
     * Return Date in String format from Timestamp
     *
     * @param dateStr
     * @return
     */
    public static String dateFormatterStringToStringSimple(String dateStr) {
        SimpleDateFormat initialFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss.SSS");
        SimpleDateFormat resultFormat = new SimpleDateFormat("dd.MM.yyyy");

        String result = "";
        try {
            Date date = initialFormat.parse(dateStr);
            return resultFormat.format(date);
        } catch (Exception e) {
            return result;
        }
    }

    public static String calculateIconUrl(int movement, int online) {
        if (movement == 1 && online == 1) {
            // Object is moving "GREEN"
            return "green";
        } else if (movement == 2 && online == 1) {
            // Object is moved before "YELLOW"
            return "yellow";
        } else if (movement == 0 && online == 1) {
            // Object is NOT moving "BLUE"
            return "blue";
        } else if (online == 0) {
            // Object is NOT moving "RED"
            return "red";
        } else if (movement == -1 && online == -1) {
            // Object is online, but no data to display
            return "green";
        }

        // Object is NOT moving
        return "grey";
    }

    protected static String translateText(String langCode) {
        try {
            return messageSource.getMessage(langCode, null, LocaleContextHolder.getLocale());
        } catch (Exception ex) {
            return langCode;
        }
    }

    /**
     * Return date by string
     *
     * @param dateStr
     * @return
     */
    public static Date dateFormatterStringToDateFull(String dateStr) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");

        try {
            return dateFormat.parse(dateStr);
        } catch (Exception e) {
            return new Date();
        }
    }

    /**
     * Return date by string
     *
     * @param dateStr
     * @return
     */
    public static Date dateFormatterStringToDate(String dateStr) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

        try {
            return dateFormat.parse(dateStr);
        } catch (Exception e) {
            return new Date();
        }
    }

    /**
     * Return String (comma separated) from List<Long>
     *
     * @param idList List<Long>
     * @return String
     */
    public static String formatListToStr(List<Long> idList) {
        try {
            return StringUtils.join(idList, ',');
        } catch (Exception e) {
            return "";
        }
    }


}
