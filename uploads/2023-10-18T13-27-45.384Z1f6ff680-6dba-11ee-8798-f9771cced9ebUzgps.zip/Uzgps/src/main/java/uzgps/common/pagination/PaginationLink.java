package uzgps.common.pagination;

 /**
 * @author Sheroz Khaydarov
 * @since 06.07.13 16:46
 */

public class PaginationLink {
     public static final byte constantLinkTypeFirst = 0;
     public static final byte constantLinkTypePrev = 1;
     public static final byte constantLinkTypeNormal = 2;
     public static final byte constantLinkTypeGap = 3;
     public static final byte constantLinkTypeCurrent = 4;
     public static final byte constantLinkTypeNext = 5;
     public static final byte constantLinkTypeLast = 6;

     private int page;
     private String image;
     private byte type;

     private boolean typeFirst;
     private boolean typePrev;
     private boolean typeNormal;
     private boolean typeGap;
     private boolean typeCurrent;
     private boolean typeNext;
     private boolean typeLast;

     public byte getConstantLinkTypeFirst() {
         return constantLinkTypeFirst;
     }

     public byte getConstantLinkTypePrev() {
         return constantLinkTypePrev;
     }

     public byte getConstantLinkTypeNormal() {
         return constantLinkTypeNormal;
     }

     public byte getConstantLinkTypeGap() {
         return constantLinkTypeGap;
     }

     public byte getConstantLinkTypeCurrent() {
         return constantLinkTypeCurrent;
     }

     public byte getConstantLinkTypeNext() {
         return constantLinkTypeNext;
     }

     public byte getConstantLinkTypeLast() {
         return constantLinkTypeLast;
     }

     private void refreshType()
     {
         typeFirst = (type==constantLinkTypeFirst);
         typePrev = (type==constantLinkTypePrev);
         typeNormal = (type==constantLinkTypeNormal);
         typeGap = (type==constantLinkTypeGap);
         typeCurrent = (type==constantLinkTypeCurrent);
         typeNext = (type==constantLinkTypeNext);
         typeLast = (type==constantLinkTypeLast);
     }

     public PaginationLink(int page, String image, byte type) {
         this.page = page;
         this.image = image;
         this.type = type;
         refreshType();
     }

     public PaginationLink() {
     }

     public String getImage() {
         return image;
     }

     public void setImage(String image) {
         this.image = image;
     }

     public byte getType() {
         return type;
     }

     public void setType(byte type) {
         this.type = type;
         refreshType();
     }

     public int getPage() {
         return page;
     }

     public void setPage(int page) {
         this.page = page;
     }

     public boolean isTypeFirst() {
         return typeFirst;
     }

     public boolean isTypePrev() {
         return typePrev;
     }

     public boolean isTypeNormal() {
         return typeNormal;
     }

     public boolean isTypeGap() {
         return typeGap;
     }

     public boolean isTypeCurrent() {
         return typeCurrent;
     }

     public boolean isTypeNext() {
         return typeNext;
     }

     public boolean isTypeLast() {
         return typeLast;
     }
 }
