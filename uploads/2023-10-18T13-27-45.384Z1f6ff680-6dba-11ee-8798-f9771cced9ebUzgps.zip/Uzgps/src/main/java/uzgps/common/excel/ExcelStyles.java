package uzgps.common.excel;

import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.context.i18n.LocaleContextHolder;

import java.util.Locale;

/**
 * Created by Stanislav on 01.04.2016 17:25
 */
public class ExcelStyles {

    Locale locale;

    public XSSFSheet worksheet;
    public HSSFPalette palette;

    public XSSFCellStyle headerCellStyle;
    public XSSFCellStyle headerCellStyleBlue;

    public XSSFCellStyle cellStyleTitle;

    public XSSFCellStyle bodyCellStyle;
    public XSSFCellStyle bodyCellNotWrapStyle;
    public XSSFCellStyle bodyCellStyleCenter;
    public XSSFCellStyle bodyCellStyleLeft;
    public XSSFCellStyle bodyCellStyleLeftMargin;
    public XSSFCellStyle bodyCellStyleLeftBold;
    public XSSFCellStyle bodyCellStyleRight;
    public XSSFCellStyle bodyCellStyleRightBold;
    public XSSFCellStyle bodyCellStyleNumeric;
    public XSSFCellStyle bodyCellStyleNumericFull;
    public XSSFCellStyle formulaCellStyleNumericFull;

    public XSSFCellStyle NUMERIC_STYLE;
    public XSSFCellStyle SIMPLE_NUMERIC_STYLE;
    public XSSFCellStyle SIMPLE_NUMERIC_STYLE_LEFT;
    public XSSFCellStyle SIMPLE_NUMERIC_STYLE_RIGHT;
    public XSSFCellStyle SIMPLE_NUMERIC_STYLE_RED;
    public XSSFCellStyle SIMPLE_NUMERIC_STYLE_BLUE;
    public XSSFCellStyle SIMPLE_NUMERIC_STYLE_GREEN;
    public XSSFCellStyle FULL_NUMERIC_STYLE;
    public XSSFCellStyle CURRENCY_STYLE;
    public XSSFCellStyle SIMPLE_PERCENT_STYLE;
    public XSSFCellStyle PERCENT_STYLE;
    public XSSFCellStyle PERCENT_FULL_STYLE;

    public XSSFCellStyle DATE_STYLE;
    public XSSFCellStyle DATE_TIME_STYLE;
    public XSSFCellStyle DATE_TIME_FULL_STYLE;
    public XSSFCellStyle DATE_TIME_FULL_STYLE_LEFT;
    public XSSFCellStyle TIME_STYLE;
    public XSSFCellStyle TIME_STYLE_LEFT;

    public ExcelStyles() {

    }

    public void createStyles(XSSFSheet _worksheet) {
        worksheet = _worksheet;
        locale = LocaleContextHolder.getLocale();

        createTitleStyle();
        createHeaderStyle();
        createTypedStyles();
    }

    private void createTitleStyle() {
        // Create font style for the report title
        Font fontTitle = worksheet.getWorkbook().createFont();
        fontTitle.setBold(true);
        fontTitle.setFontHeight((short) 280);

        // Create cell style for the report title
        cellStyleTitle = worksheet.getWorkbook().createCellStyle();
        cellStyleTitle.setAlignment(HorizontalAlignment.CENTER);
        cellStyleTitle.setWrapText(true);
        cellStyleTitle.setFont(fontTitle);
    }

    private void createHeaderStyle() {
        // Create font style for the headers
        Font font = worksheet.getWorkbook().createFont();
        font.setBold(true);

        // Create cell style for the headers
        headerCellStyle = worksheet.getWorkbook().createCellStyle();

        headerCellStyle.setFillForegroundColor(new XSSFColor(new java.awt.Color(0, 165, 236)));
        headerCellStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
        headerCellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        headerCellStyle.setWrapText(true);
        headerCellStyle.setFont(font);
        headerCellStyle.setBorderLeft(CellStyle.BORDER_THIN);
        headerCellStyle.setBorderTop(CellStyle.BORDER_THIN);
        headerCellStyle.setBorderRight(CellStyle.BORDER_THIN);
        headerCellStyle.setBorderBottom(CellStyle.BORDER_THIN);

        // Create cell style for the headers blue
        headerCellStyleBlue = worksheet.getWorkbook().createCellStyle();

        headerCellStyleBlue.setFillForegroundColor(new XSSFColor(new java.awt.Color(110, 198, 248)));
        headerCellStyleBlue.setFillPattern(CellStyle.SOLID_FOREGROUND);
        headerCellStyleBlue.setAlignment(HorizontalAlignment.CENTER);
        headerCellStyleBlue.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        headerCellStyleBlue.setWrapText(true);
        headerCellStyleBlue.setFont(font);
        headerCellStyleBlue.setBorderLeft(CellStyle.BORDER_THIN);
        headerCellStyleBlue.setBorderTop(CellStyle.BORDER_THIN);
        headerCellStyleBlue.setBorderRight(CellStyle.BORDER_THIN);
        headerCellStyleBlue.setBorderBottom(CellStyle.BORDER_THIN);
    }

    private void createTypedStyles() {
        XSSFDataFormat df = worksheet.getWorkbook().createDataFormat();

        Font fontRed = worksheet.getWorkbook().createFont();
        fontRed.setColor(HSSFColor.RED.index);

        Font fontBlue = worksheet.getWorkbook().createFont();
        fontBlue.setColor(HSSFColor.BLUE.index);

        Font fontGreen = worksheet.getWorkbook().createFont();
        fontGreen.setColor(HSSFColor.GREEN.index);

        // Create cell style for the body
        bodyCellStyle = worksheet.getWorkbook().createCellStyle();
        bodyCellStyle.setAlignment(HorizontalAlignment.CENTER);
        bodyCellStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyle.setWrapText(true);

        // Create cell style for the body not wrap text
        bodyCellNotWrapStyle = worksheet.getWorkbook().createCellStyle();
        bodyCellNotWrapStyle.setAlignment(HorizontalAlignment.RIGHT);
        bodyCellNotWrapStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellNotWrapStyle.setWrapText(false);

        // Create cell style for the body with center alignment
        bodyCellStyleCenter = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleCenter.setAlignment(HorizontalAlignment.CENTER);
        bodyCellStyleCenter.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleCenter.setWrapText(true);

        // Create cell style for the body with center alignment
        bodyCellStyleLeft = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleLeft.setAlignment(HorizontalAlignment.LEFT);
        bodyCellStyleLeft.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleLeft.setWrapText(true);

        // Create cell style for the body with center alignment
        bodyCellStyleLeftMargin = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleLeftMargin.setAlignment(HorizontalAlignment.LEFT);
        bodyCellStyleLeftMargin.setIndention((short) 3);
        bodyCellStyleLeftMargin.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleLeftMargin.setWrapText(true);

        // Create cell style for the body with left alignment
        // Create font style for the report title
        Font fontBold = worksheet.getWorkbook().createFont();
        fontBold.setBold(true);
        fontBold.setFontHeight((short) 220);

        bodyCellStyleLeftBold = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleLeftBold.setAlignment(HorizontalAlignment.LEFT);
        bodyCellStyleLeftBold.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleLeftBold.setFont(fontBold);
        bodyCellStyleLeftBold.setWrapText(true);

        // Create cell style for the body with right alignment
        bodyCellStyleRightBold = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleRightBold.setAlignment(HorizontalAlignment.RIGHT);
        bodyCellStyleRightBold.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleRightBold.setFont(fontBold);
        bodyCellStyleRightBold.setWrapText(true);

        // Create cell style for the body with right alignment
        bodyCellStyleRight = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleRight.setAlignment(HorizontalAlignment.RIGHT);
        bodyCellStyleRight.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleRight.setWrapText(true);

        // Create cell style for the body with center alignment
        bodyCellStyleNumeric = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleNumeric.setAlignment(HorizontalAlignment.LEFT);
        bodyCellStyleNumeric.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleNumeric.setWrapText(true);
        bodyCellStyleNumeric.setDataFormat(df.getFormat("0.0"));

        // Create cell style for the body with left alignment
        bodyCellStyleNumericFull = worksheet.getWorkbook().createCellStyle();
        bodyCellStyleNumericFull.setAlignment(HorizontalAlignment.LEFT);
        bodyCellStyleNumericFull.setVerticalAlignment(VerticalAlignment.CENTER);
        bodyCellStyleNumericFull.setWrapText(true);
        bodyCellStyleNumericFull.setDataFormat((short) 2);

        // Create cell style for the body with left alignment
        formulaCellStyleNumericFull = worksheet.getWorkbook().createCellStyle();
        formulaCellStyleNumericFull.setFillForegroundColor(new XSSFColor(new java.awt.Color(255, 180, 121)));
        formulaCellStyleNumericFull.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        formulaCellStyleNumericFull.setAlignment(HorizontalAlignment.LEFT);
        formulaCellStyleNumericFull.setWrapText(true);
        formulaCellStyleNumericFull.setDataFormat((short) 2);

        // Create font style for the report title
        Font numericFontTitle = worksheet.getWorkbook().createFont();
        numericFontTitle.setBold(true);
        numericFontTitle.setFontHeight((short) 180);
        numericFontTitle.setColor(HSSFColor.GREEN.index);

        SIMPLE_NUMERIC_STYLE = worksheet.getWorkbook().createCellStyle();
        SIMPLE_NUMERIC_STYLE.setAlignment(HorizontalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE.setWrapText(true);
        SIMPLE_NUMERIC_STYLE.setDataFormat((short) 3); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        SIMPLE_NUMERIC_STYLE_LEFT = worksheet.getWorkbook().createCellStyle();
        SIMPLE_NUMERIC_STYLE_LEFT.setAlignment(HorizontalAlignment.LEFT);
        SIMPLE_NUMERIC_STYLE_LEFT.setVerticalAlignment(VerticalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_LEFT.setWrapText(true);
        SIMPLE_NUMERIC_STYLE_LEFT.setDataFormat((short) 3); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        SIMPLE_NUMERIC_STYLE_RIGHT = worksheet.getWorkbook().createCellStyle();
        SIMPLE_NUMERIC_STYLE_RIGHT.setAlignment(HorizontalAlignment.RIGHT);
        SIMPLE_NUMERIC_STYLE_RIGHT.setVerticalAlignment(VerticalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_RIGHT.setWrapText(true);
        SIMPLE_NUMERIC_STYLE_RIGHT.setDataFormat((short) 3); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        SIMPLE_NUMERIC_STYLE_RED = worksheet.getWorkbook().createCellStyle();
        SIMPLE_NUMERIC_STYLE_RED.setAlignment(HorizontalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_RED.setVerticalAlignment(VerticalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_RED.setWrapText(true);
        SIMPLE_NUMERIC_STYLE_RED.setDataFormat((short) 3); // http://www.roseindia.net/java/poi/setDataFormat.shtml
        SIMPLE_NUMERIC_STYLE_RED.setFont(fontRed);

        SIMPLE_NUMERIC_STYLE_BLUE = worksheet.getWorkbook().createCellStyle();
        SIMPLE_NUMERIC_STYLE_BLUE.setAlignment(HorizontalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_BLUE.setVerticalAlignment(VerticalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_BLUE.setWrapText(true);
        SIMPLE_NUMERIC_STYLE_BLUE.setDataFormat((short) 3); // http://www.roseindia.net/java/poi/setDataFormat.shtml
        SIMPLE_NUMERIC_STYLE_BLUE.setFont(fontBlue);

        SIMPLE_NUMERIC_STYLE_GREEN = worksheet.getWorkbook().createCellStyle();
        SIMPLE_NUMERIC_STYLE_GREEN.setAlignment(HorizontalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_GREEN.setVerticalAlignment(VerticalAlignment.CENTER);
        SIMPLE_NUMERIC_STYLE_GREEN.setWrapText(true);
        SIMPLE_NUMERIC_STYLE_GREEN.setDataFormat((short) 3); // http://www.roseindia.net/java/poi/setDataFormat.shtml
        SIMPLE_NUMERIC_STYLE_GREEN.setFont(fontGreen);

        FULL_NUMERIC_STYLE = worksheet.getWorkbook().createCellStyle();
        FULL_NUMERIC_STYLE.setAlignment(HorizontalAlignment.CENTER);
        FULL_NUMERIC_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        FULL_NUMERIC_STYLE.setWrapText(true);
        FULL_NUMERIC_STYLE.setDataFormat((short) 4); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        SIMPLE_PERCENT_STYLE = worksheet.getWorkbook().createCellStyle();
        SIMPLE_PERCENT_STYLE.setAlignment(HorizontalAlignment.CENTER);
        SIMPLE_PERCENT_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        SIMPLE_PERCENT_STYLE.setWrapText(true);
        SIMPLE_PERCENT_STYLE.setDataFormat(df.getFormat("0%")); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        PERCENT_STYLE = worksheet.getWorkbook().createCellStyle();
        PERCENT_STYLE.setAlignment(HorizontalAlignment.CENTER);
        PERCENT_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        PERCENT_STYLE.setWrapText(true);
        PERCENT_STYLE.setDataFormat(df.getFormat("0.0%")); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        PERCENT_FULL_STYLE = worksheet.getWorkbook().createCellStyle();
        PERCENT_FULL_STYLE.setAlignment(HorizontalAlignment.CENTER);
        PERCENT_FULL_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        PERCENT_FULL_STYLE.setWrapText(true);
        PERCENT_FULL_STYLE.setDataFormat(df.getFormat("0.00%")); // http://www.roseindia.net/java/poi/setDataFormat.shtml

        // Create cell style for currency format
        CURRENCY_STYLE = worksheet.getWorkbook().createCellStyle();
        CURRENCY_STYLE.setAlignment(HorizontalAlignment.CENTER);
        CURRENCY_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        CURRENCY_STYLE.setWrapText(true);
        CURRENCY_STYLE.setDataFormat((short) 5);

        DATE_STYLE = worksheet.getWorkbook().createCellStyle();
        DATE_STYLE.setAlignment(HorizontalAlignment.CENTER);
        DATE_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        DATE_STYLE.setWrapText(true);
        DATE_STYLE.setDataFormat(df.getFormat("dd.mm.yyyy"));

        DATE_TIME_STYLE = worksheet.getWorkbook().createCellStyle();
        DATE_TIME_STYLE.setAlignment(HorizontalAlignment.CENTER);
        DATE_TIME_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        DATE_TIME_STYLE.setWrapText(true);
        DATE_TIME_STYLE.setDataFormat(df.getFormat("dd.mm.yyyy HH:mm"));

        DATE_TIME_FULL_STYLE = worksheet.getWorkbook().createCellStyle();
        DATE_TIME_FULL_STYLE.setAlignment(HorizontalAlignment.CENTER);
        DATE_TIME_FULL_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        DATE_TIME_FULL_STYLE.setWrapText(true);
        DATE_TIME_FULL_STYLE.setDataFormat(df.getFormat("dd.mm.yyyy HH:mm:ss"));

        DATE_TIME_FULL_STYLE_LEFT = worksheet.getWorkbook().createCellStyle();
        DATE_TIME_FULL_STYLE_LEFT.setAlignment(HorizontalAlignment.LEFT);
        DATE_TIME_FULL_STYLE_LEFT.setVerticalAlignment(VerticalAlignment.CENTER);
        DATE_TIME_FULL_STYLE_LEFT.setWrapText(true);
        DATE_TIME_FULL_STYLE_LEFT.setDataFormat(df.getFormat("dd.mm.yyyy HH:mm:ss"));

        TIME_STYLE = worksheet.getWorkbook().createCellStyle();
        TIME_STYLE.setAlignment(HorizontalAlignment.CENTER);
        TIME_STYLE.setVerticalAlignment(VerticalAlignment.CENTER);
        TIME_STYLE.setWrapText(true);
        TIME_STYLE.setDataFormat(df.getFormat("HH:mm:ss"));

        TIME_STYLE_LEFT = worksheet.getWorkbook().createCellStyle();
        TIME_STYLE_LEFT.setAlignment(HorizontalAlignment.LEFT);
        TIME_STYLE_LEFT.setVerticalAlignment(VerticalAlignment.CENTER);
        TIME_STYLE_LEFT.setWrapText(true);
        TIME_STYLE_LEFT.setDataFormat(df.getFormat("HH:mm:ss"));

    }

}
