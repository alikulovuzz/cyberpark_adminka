package uzgps.common.pagination;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Sheroz Khaydarov
 * @since 06.07.13 14:36
 */

public class Pagination implements Serializable {

    public static final int[] DEFAULT_ARRAY_ITEMS_PER_PAGE = new int[]{5,10,25,50,100};
    public static final int DEFAULT_LINKS_NEAR_COUNT = 5;
    public static final int DEFAULT_LINKS_FAR_COUNT = 3;
    public static final int DEFAULT_LINKS_FAR_MULTIPLE = 5;

    private int linksNearCount;
    private int linksFarLeftCount;
    private int linksFarRightCount;
    private int linksFarLeftStepMultiple;
    private int linksFarRightStepMultiple;

    private int currentPage;
    private int itemsPerPage;
    private int pageCount;
    private int fromItem;
    private int toItem;
    private long itemCount;
    private int[] arrayItemsPerPage;

    private int firstPage;
    private int prevPage;
    private int nextPage;
    private int lastPage;


    List <PaginationLink> links;

    public Pagination() {
        arrayItemsPerPage = DEFAULT_ARRAY_ITEMS_PER_PAGE;
        linksNearCount = DEFAULT_LINKS_NEAR_COUNT;
        linksFarLeftCount = DEFAULT_LINKS_FAR_COUNT;
        linksFarRightCount = DEFAULT_LINKS_FAR_COUNT;

        linksFarLeftStepMultiple = DEFAULT_LINKS_FAR_MULTIPLE;
        linksFarRightStepMultiple = DEFAULT_LINKS_FAR_MULTIPLE;

        pageCount = 0;
        currentPage = 1;
        fromItem = 0;
        toItem = 0;

        prevPage = -1;
        nextPage = -1;
        firstPage = -1;
        lastPage = -1;

        itemsPerPage = arrayItemsPerPage[0];
    }

    public void paginate()
    {
        // generate links array
        links = new ArrayList<PaginationLink>();
        pageCount = 0;
        fromItem = 1;
        toItem = itemsPerPage;

        prevPage = -1;
        nextPage = -1;
        firstPage = -1;
        lastPage = -1;

        if (itemCount<=0)
            return;

        if (itemsPerPage>0)
            pageCount = (int)(itemCount / itemsPerPage);

        if (pageCount*itemsPerPage < itemCount)
            pageCount++;

        if(currentPage < 0)
            currentPage = 1;
        if (currentPage > pageCount)
            currentPage = pageCount;

        fromItem = (currentPage-1)*itemsPerPage+1;
        toItem = fromItem + itemsPerPage - 1;
        if (toItem > itemCount)
            toItem = (int) itemCount;

        if (currentPage > 1)
        {
            firstPage = 1;
            prevPage = currentPage-1;
        }

        if (currentPage < pageCount)
        {
            nextPage = currentPage+1;
            lastPage = pageCount;
        }

        //             *
        // < 1 ... 8 9 10 11 12 ... 20 30 40 ... 55 >
        //      |   near links   |     FR     |
        //     gap               gap         gap

        //     * * *
        // < 1 2 3 4 5 6 ... 20 30 40 ... 55 >
        //     near links       FR
        //               gap          gap

        //             *
        // < 1 ... 3 4 5 6 7 ... 20 30 40 ... 55 >
        //         near links       FR
        //     gap           gap          gap

        //                            *  *  *
        // < 1 ... 20 30 40 ... 50 51 52 53 54 55 >
        //     gap   FL     gap    near

        //                            *
        // < 1 ... 20 30 40 ... 49 50 51 52 53 ... 55 >
        //     gap   FL     gap    near        gap

        // < 1 ... 20 30 40 41 42 43 44 45 ... 50 ... 55 >
        //     gap    FL   |    near       gap FR  gap

        // < 1 ... 20 30 ... 32 33 34 35 36 ... 40 50 ... 55 >
        //     gap   FL  gap     near       gap   FR  gap

        PaginationLink link;
        byte type;

        // add prev page link
        if (currentPage>1)
        {
            link = new PaginationLink(currentPage-1, null,PaginationLink.constantLinkTypePrev);
            links.add(link);
        }

        //  add first page
        type = (currentPage==1) ? PaginationLink.constantLinkTypeCurrent : PaginationLink.constantLinkTypeNormal;
        link = new PaginationLink(1, null,type);
        links.add(link);

        // add middle pages
        if (pageCount > 1)
        {

            int nearFirst = currentPage - (linksNearCount/2);
            if (nearFirst < 2)
                nearFirst = 2;

            int nearLast = nearFirst + linksNearCount-1;
            if (nearLast > (pageCount-1))
            {
                nearLast  = pageCount -1;
                nearFirst = pageCount - linksNearCount;
                if (nearFirst < 2)
                    nearFirst = 2;
            }

            // process farLeft
            if (nearFirst > 2)
            {
                int leftMultipleCount = nearFirst / linksFarLeftStepMultiple;
                if (leftMultipleCount > linksFarLeftCount)
                    leftMultipleCount = linksFarLeftCount;

                int step = 0;
                if (leftMultipleCount>0)
                    step = nearFirst / leftMultipleCount;

                link = new PaginationLink(0, null, PaginationLink.constantLinkTypeGap);
                links.add(link);

                if (step>=linksFarLeftStepMultiple)
                {
                    step = (step/linksFarLeftStepMultiple)*linksFarLeftStepMultiple;
                    int pos = step;
                    if (pos < nearFirst)
                    {
                        for (int i=1;i<=leftMultipleCount;i++)
                        {
                            link = new PaginationLink(pos, null, PaginationLink.constantLinkTypeNormal);
                            links.add(link);
                            pos+= step;
                            if (pos >= nearFirst)
                                break;
                        }
                        link = new PaginationLink(0, null, PaginationLink.constantLinkTypeGap);
                        links.add(link);
                    }
                }
            }

            // process near links
            for (int pos=nearFirst;pos<=nearLast;pos++)
            {
                type = (currentPage==pos) ? PaginationLink.constantLinkTypeCurrent : PaginationLink.constantLinkTypeNormal;
                link = new PaginationLink(pos, null, type);
                links.add(link);
            }

            // process farRight
            if (nearLast < (pageCount-1))
            {
                int rightMultipleCount = (pageCount - nearLast) / linksFarRightStepMultiple;
                if (rightMultipleCount > linksFarRightCount)
                    rightMultipleCount = linksFarRightCount;

                int step = 0;
                if (rightMultipleCount>0)
                    step = (pageCount - nearLast) / rightMultipleCount;

                link = new PaginationLink(0, null, PaginationLink.constantLinkTypeGap);
                links.add(link);

                if (step>=linksFarRightStepMultiple)
                {
                    step = (step/linksFarRightStepMultiple)*linksFarRightStepMultiple;
                    int pos = ((nearLast + step)/linksFarRightStepMultiple)*linksFarRightStepMultiple;
                    if (pos < pageCount)
                    {
                        for (int i=1;i<=rightMultipleCount;i++)
                        {
                            link = new PaginationLink(pos, null, PaginationLink.constantLinkTypeNormal);
                            links.add(link);
                            pos+= step;
                            if (pos >= pageCount)
                                break;
                        }
                        link = new PaginationLink(0, null, PaginationLink.constantLinkTypeGap);
                        links.add(link);
                    }
                }
            }
        }

        //  add last page
        if (pageCount>1)
        {
            type = (currentPage==pageCount) ? PaginationLink.constantLinkTypeCurrent : PaginationLink.constantLinkTypeNormal;
            link = new PaginationLink(pageCount, null, type);
            links.add(link);
        }

        // add next page link
        if (currentPage < pageCount)
        {
            link = new PaginationLink(currentPage+1,null,PaginationLink.constantLinkTypeNext);
            links.add(link);
        }

    }

    public List<PaginationLink> getLinks() {
        return links;
    }

    public void setLinks(List<PaginationLink> links) {
        this.links = links;
    }

    public int[] getArrayItemsPerPage() {
        return arrayItemsPerPage;
    }

    public void setArrayItemsPerPage(int[] arrayItemsPerPage) {
        this.arrayItemsPerPage = arrayItemsPerPage;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getItemsPerPage() {
        return itemsPerPage;
    }

    public void setItemsPerPage(int itemsPerPage) {
        this.itemsPerPage = itemsPerPage;
    }

    public long getItemCount() {
        return itemCount;
    }

    public void setItemCount(long itemCount) {
        this.itemCount = itemCount;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public int getToItem() {
        return toItem;
    }

    public void setToItem(int toItem) {
        this.toItem = toItem;
    }

    public int getFromItem() {
        return fromItem;
    }

    public void setFromItem(int fromItem) {
        this.fromItem = fromItem;
    }

    public int getLinksNearCount() {
        return linksNearCount;
    }

    public void setLinksNearCount(int linksNearCount) {
        this.linksNearCount = linksNearCount;
    }

    public int getLinksFarLeftCount() {
        return linksFarLeftCount;
    }

    public void setLinksFarLeftCount(int linksFarLeftCount) {
        this.linksFarLeftCount = linksFarLeftCount;
    }

    public int getLinksFarRightCount() {
        return linksFarRightCount;
    }

    public void setLinksFarRightCount(int linksFarRightCount) {
        this.linksFarRightCount = linksFarRightCount;
    }

    public int getLinksFarLeftStepMultiple() {
        return linksFarLeftStepMultiple;
    }

    public void setLinksFarLeftStepMultiple(int linksFarLeftStepMultiple) {
        this.linksFarLeftStepMultiple = linksFarLeftStepMultiple;
    }

    public int getLinksFarRightStepMultiple() {
        return linksFarRightStepMultiple;
    }

    public void setLinksFarRightStepMultiple(int linksFarRightStepMultiple) {
        this.linksFarRightStepMultiple = linksFarRightStepMultiple;
    }

    public int getPrevPage() {
        return prevPage;
    }

    public int getNextPage() {
        return nextPage;
    }

    public int getFirstPage() {
        return firstPage;
    }

    public int getLastPage() {
        return lastPage;
    }
}
