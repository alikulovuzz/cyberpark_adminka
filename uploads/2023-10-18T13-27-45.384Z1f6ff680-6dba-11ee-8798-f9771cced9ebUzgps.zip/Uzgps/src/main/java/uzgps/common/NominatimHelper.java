package uzgps.common;

import com.github.filosganga.geogson.gson.GeometryAdapterFactory;
import com.github.filosganga.geogson.jts.JtsAdapterFactory;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import fr.dudie.nominatim.client.NominatimResponseHandler;
import fr.dudie.nominatim.client.request.NominatimReverseRequest;
import fr.dudie.nominatim.gson.ArrayOfAddressElementsDeserializer;
import fr.dudie.nominatim.gson.ArrayOfPolygonPointsDeserializer;
import fr.dudie.nominatim.gson.BoundingBoxDeserializer;
import fr.dudie.nominatim.gson.PolygonPointDeserializer;
import fr.dudie.nominatim.model.Address;
import fr.dudie.nominatim.model.BoundingBox;
import fr.dudie.nominatim.model.Element;
import fr.dudie.nominatim.model.PolygonPoint;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

public class NominatimHelper {
    private String nominatimUrl;
//    private Double longitude = 69.30699;
//    private Double latitude = 41.30517;

    private Gson gsonInstance;

    private CloseableHttpClient httpClient;
    private NominatimReverseRequest nominatimRequest;
    private NominatimResponseHandler<Address> defaultReverseGeocodingHandler;
//    HttpClient httpClient;

    public NominatimHelper(String baseUrl) {
        nominatimUrl = baseUrl + "/reverse.php";
        //        httpClient = HttpClientBuilder.create().build();
//        fr.dudie.nominatim.client.NominatimClient nominatimClient = new fr.dudie.nominatim.client.JsonNominatimClient("https://osm.uzgps.uz/", httpClient, "laziol@mail.ru");
//        String address = nominatimClient.getAddress(41.30517578125003, 69.30699920654297,18).getDisplayName();
//        String nominatimAddress4 = "https://osm.uzgps.uz/nominatim/search.php";

//        NominatimOptions nominatimOpt = new NominatimOptions();
//        nominatimClient = new JsonNominatimClient(nominatimUrl, httpClient, "abc@bac.com", nominatimOpt);

        createHttpClient();
//        createNominatimClient();
        createJsonInstance();
        createNominatimReverseRequest();
        createReverseGeocodingHandler();
    }

    private void createHttpClient() {
        httpClient = HttpClientBuilder.create().build();
    }

//    private void createNominatimClient() {
//        NominatimClient nominatimClient = new JsonNominatimClient(nominatimUrl, httpClient, "abc@bac.com");
//    }

    private void createJsonInstance() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(Element[].class, new ArrayOfAddressElementsDeserializer());
        gsonBuilder.registerTypeAdapter(PolygonPoint.class, new PolygonPointDeserializer());
        gsonBuilder.registerTypeAdapter(PolygonPoint[].class, new ArrayOfPolygonPointsDeserializer());
        gsonBuilder.registerTypeAdapter(BoundingBox.class, new BoundingBoxDeserializer());
        gsonBuilder.registerTypeAdapterFactory(new JtsAdapterFactory());
        gsonBuilder.registerTypeAdapterFactory(new GeometryAdapterFactory());
        gsonInstance = gsonBuilder.create();
    }

    private void createNominatimReverseRequest() {
        nominatimRequest = new NominatimReverseRequest();
        nominatimRequest.setAcceptLanguage("ru");
        nominatimRequest.setZoom(18);
    }

    private void createReverseGeocodingHandler() {
        defaultReverseGeocodingHandler = new NominatimResponseHandler(gsonInstance, Address.class);
    }

    /**
     * Return address by coordinates
     *
     * @param lon
     * @param lat
     * @return
     */
    public String getAddressByCoordinates(double lon, double lat) {
        String addressName = "";

//        longitude += 0.001;

        nominatimRequest.setQuery(lon, lat);

        String apiCall = String.format("%s&%s", nominatimUrl + "/reverse?format=jsonv2", nominatimRequest.getQueryString());

        try {
            HttpGet req = new HttpGet(apiCall);
            addressName = httpClient.execute(req, defaultReverseGeocodingHandler).getDisplayName();
        } catch (Exception e) {
            e.printStackTrace();
        }

//        addressName.toString();

//        try {
//            address1 = nominatimClient.getAddress(longitude, latitude, 18).getDisplayName();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        try {
//            address2 = nominatimClient.getAddress(longitude, latitude).getDisplayName();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        return addressName;
    }

}
