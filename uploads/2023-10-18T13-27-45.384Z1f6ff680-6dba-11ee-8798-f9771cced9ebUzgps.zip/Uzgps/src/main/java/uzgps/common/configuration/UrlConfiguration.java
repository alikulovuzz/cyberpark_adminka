package uzgps.common.configuration;

/**
 * Created by Saidolim on 18.10.2016.
 */
public class UrlConfiguration {

    private static String urlUzgps;
    private static String urlBilling;
    private static String urlUzgpsPublic;
    private static String urlBillingPublic;
    private static String urlUzgpsLocal;
    private static String urlBillingLocal;

    public static String urlCabinetPublic = "";
    private static String urlCabinetLocal;

    public static String urlUzgpsBusPublic = "";
    private static String urlUzgpsBusLocal;

    private static String urlNominatim;

    public static String getUrlUzgps() {
        return urlUzgps;
    }

    public void setUrlUzgps(String urlUzgps) {
        UrlConfiguration.urlUzgps = urlUzgps;
    }

    public static String getUrlBilling() {
        return urlBilling;
    }

    public void setUrlBilling(String urlBilling) {
        UrlConfiguration.urlBilling = urlBilling;
    }

    public static String getUrlUzgpsPublic() {
        return urlUzgpsPublic;
    }

    public void setUrlUzgpsPublic(String urlUzgpsPublic) {
        UrlConfiguration.urlUzgpsPublic = urlUzgpsPublic;
    }

    public static String getUrlBillingPublic() {
        return urlBillingPublic;
    }

    public void setUrlBillingPublic(String urlBillingPublic) {
        UrlConfiguration.urlBillingPublic = urlBillingPublic;
    }

    public static String getUrlUzgpsLocal() {
        return urlUzgpsLocal;
    }

    public void setUrlUzgpsLocal(String urlUzgpsLocal) {
        UrlConfiguration.urlUzgpsLocal = urlUzgpsLocal;
    }

    public static String getUrlBillingLocal() {
        return urlBillingLocal;
    }

    public void setUrlBillingLocal(String urlBillingLocal) {
        UrlConfiguration.urlBillingLocal = urlBillingLocal;
    }

    public static String getUrlCabinetPublic() {
        return urlCabinetPublic;
    }

    public void setUrlCabinetPublic(String urlCabinetPublic) {
        UrlConfiguration.urlCabinetPublic = urlCabinetPublic;
    }

    public static String getUrlCabinetLocal() {
        return urlCabinetLocal;
    }

    public void setUrlCabinetLocal(String urlCabinetLocal) {
        UrlConfiguration.urlCabinetLocal = urlCabinetLocal;
    }


    public static String getUrlUzgpsBusPublic() {
        return urlUzgpsBusPublic;
    }

    public   void setUrlUzgpsBusPublic(String urlUzgpsBusPublic) {
        UrlConfiguration.urlUzgpsBusPublic = urlUzgpsBusPublic;
    }

    public static String getUrlUzgpsBusLocal() {
        return urlUzgpsBusLocal;
    }

    public   void setUrlUzgpsBusLocal(String urlUzgpsBusLocal) {
        UrlConfiguration.urlUzgpsBusLocal = urlUzgpsBusLocal;
    }

    public static String getUrlNominatim() {
        return urlNominatim;
    }

    public   void setUrlNominatim(String urlNominatim) {
        UrlConfiguration.urlNominatim = urlNominatim;
    }
}
