package uzgps.common.configuration;

/**
 * Created by Gayratjon on 11/20/2014.
 */
public class MobileConfiguration {

    private String apiUrl;
    private Long managerId;
    private Long gpsUnitType;

    public String getApiUrl() {
        return apiUrl;
    }

    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    public Long getManagerId() {
        return managerId;
    }

    public void setManagerId(Long managerId) {
        this.managerId = managerId;
    }

    public Long getGpsUnitType() {
        return gpsUnitType;
    }

    public void setGpsUnitType(Long gpsUnitType) {
        this.gpsUnitType = gpsUnitType;
    }
}
