package uzgps.common;

/**
 * Created by: Sheroz Khaydarov
 * Since: 13.08.2009, Time: 18:32:50
 */
public class UZGPS_CONST {

    /**
     * For each server, this value will be different. Now we have:
     * smpo - main system for Uzgps
     * uty - for UTY server
     * guvd - for Oxrana and GUVD servers
     */
    public static String SYSTEM_INSTALLED_NAME = "smpo";

    // constants for task progress status
    public static final byte TASK_STATUS_TYPE_SCHEDULED = 1;   // Тингловчига юборилган
    public static final byte TASK_STATUS_TYPE_IN_PROGRESS = 2; // Топшириш жараёнида
    public static final byte TASK_STATUS_TYPE_COMPLETED = 3;   // Текширишга юборилган
    public static final byte TASK_STATUS_TYPE_PASSED = 4;      // Муваффакиятли топширилган
    public static final byte TASK_STATUS_TYPE_FAILED = 5;      // Вазифа кайтарилган, кабул килинмаган
    public static final byte TASK_STATUS_TYPE_TIME_OUT = 6;    // Муддати утказиб юборилган

    // constants for test progress status
    public static final byte TEST_STATUS_TYPE_SCHEDULED = 1;
    public static final byte TEST_STATUS_TYPE_IN_PROGRESS = 2;
    public static final byte TEST_STATUS_TYPE_COMPLETED = 3;
    public static final byte TEST_STATUS_TYPE_PASSED = 4;
    public static final byte TEST_STATUS_TYPE_FAILED = 5;
    public static final byte TEST_STATUS_TYPE_TIME_OUT = 6;

    // constants for course subscribe and learning progress type
    public static final byte COURSE_STATUS_TYPE_PENDING = 1;
    public static final byte COURSE_STATUS_TYPE_PERMITTED = 2;
    public static final byte COURSE_STATUS_TYPE_REJECTED = 3;
    public static final byte COURSE_STATUS_TYPE_UNSUBSCRIBED = 4;
    public static final byte COURSE_STATUS_TYPE_SCHEDULED = 5;
    public static final byte COURSE_STATUS_TYPE_IN_PROGRESS = 6;
    public static final byte COURSE_STATUS_TYPE_COMPLETED = 7;
    public static final byte COURSE_STATUS_TYPE_FAILED = 8;
    public static final byte COURSE_STATUS_TYPE_DISQUALIFIED = 9;

    // constants for course moderation type
    public static final byte COURSE_MODERATION_TYPE_MODERATED = 1;
    public static final byte COURSE_MODERATION_TYPE_SELF_MODERATED = 2;

    // constants for test ask type
    public static final byte TEST_ASK_TYPE_CHECKBOX = 1;
    public static final byte TEST_ASK_TYPE_RADIO = 2;

    public static final String CURRENCY_NAME_UZS = "сум";

    // constants for repository storage
    public static final byte STORAGE_TYPE_FILE = 1;
    public static final byte STORAGE_TYPE_DATABASE = 2;

    // constants for Persistence.Folder.formType property
    public static final byte FORM_TYPE_NONE = 0;
    public static final byte FORM_TYPE_TEMPLATE = 1;
    public static final byte FORM_TYPE_REPORT = 2;
    public static final byte FORM_TYPE_REPOSITORY = 3;

    // constants for clipboard actions
    public static final byte CLIPBOARD_ACTION_NONE = 0;
    public static final byte CLIPBOARD_ACTION_CUT = 1;
    public static final byte CLIPBOARD_ACTION_COPY = 2;

    // constants for Persistence.Security.defaultAccess and Persistence.SecurityACL.accessType properties
    public static final byte SECURITY_ACCESS_ALLOW = 1;
    public static final byte SECURITY_ACCESS_DENY = 0;
    public static final byte SECURITY_ACCESS_UNDEFINED = -1;

    // constants for Persistence.Security.defaultAccess and Persistence.SecurityACL.accessType properties
    public static final byte SECURITY_ACCESS_NONE = 0;
    public static final byte SECURITY_ACCESS_BINARY_NONE = 0;
    public static final byte SECURITY_ACCESS_BINARY_LIST = 1;       // content (directory) listing only
    public static final byte SECURITY_ACCESS_BINARY_READ = 2;       // read only
    public static final byte SECURITY_ACCESS_BINARY_WRITE = 4;      // write only
    public static final byte SECURITY_ACCESS_BINARY_EXECUTE = 8;    // read - execute
    public static final byte SECURITY_ACCESS_BINARY_DELETE = 16;    // delete
    public static final byte SECURITY_ACCESS_LIST = 1;              // listing
    public static final byte SECURITY_ACCESS_READ = 3;              // listing-read
    public static final byte SECURITY_ACCESS_MODIFY = 7;            // listing-read-write
    public static final byte SECURITY_ACCESS_EXECUTE = 9;           // listing-execute
    public static final byte SECURITY_ACCESS_DELETE = 17;           // listing-delete
    public static final byte SECURITY_ACCESS_FULL = 127;            // full access

    public static final long SECURITY_KEY = 123456789; // SECURITY_KEY is changed and showing as example

    // constants for Persistence.User User Type
//    public static final  long USER_TYPE_SUPERADMIN = 1;
//    public static final  long USER_TYPE_OPERATOR = 2;
//    public static final  long USER_TYPE_CUSTOMER = 3;
//    public static final  long USER_TYPE_CUSTOMER_USER = 4;

    public static final long USER_ROLE_USER = 1L; // User role
    public static final long USER_ROLE_CUSTOMER_ADMIN = 2; // Customer role
    public static final long USER_ROLE_CUSTOMER_CARE = 4L; // System role
    public static final long USER_ROLE_SYSTEM_ADMINISTRATOR = 777L; // System role

    public static final String USER_ROLE_USER_STR = "ROLE_USER";
    public static final String USER_ROLE_CUSTOMER_ADMIN_STR = "ROLE_USER_ADMIN";

    // System servers names
    public static final String SYSTEM_SERVER_NAME_SMPO = "smpo";
    public static final String SYSTEM_SERVER_NAME_AGRO = "agro";
    public static final String SYSTEM_SERVER_NAME_TSHTX = "tshtx";

    // Default min parking time
    public static final long MIN_PARKING_TIME_DEFAULT = 600000L;

    // Default min trip time
    public static final long MIN_TRIP_TIME_DEFAULT = 120000L;

    // Trackers in warehouse
    /**
     * Minimum number of tracker in stock. If there is low trackers then this number, notification will work.
     */
    public static final long TRACKER_MIN_LIMIT = 50;

    // constants for Persistence.User User Status
    public static final String USER_STATUS_ACTIVE = "A";
    public static final String USER_STATUS_DELETE = "D";

    // constants for Persistence.User User Status
    public static final String USER_BLOCK_STATUS_UNBLOCK = "A";
    public static final String USER_BLOCK_STATUS_BLOCK = "B";

    // constants for Persistence.Contract Contarct Max Value Setting
    public static final long CONTRACT_MAX_UNIT_COUNT_DEFAULT = 1;
    public static final long CONTRACT_MAX_USER_COUNT_DEFAULT = 1;
    public static final long CONTRACT_MAX_STAFF_COUNT_DEFAULT = 1;
    public static final long CONTRACT_MAX_POI_COUNT_DEFAULT = 10;
    public static final long CONTRACT_MAX_GEO_FANCE_COUNT_DEFAULT = 10;
    public static final long CONTRACT_MAX_REPORT_COUNT_DEFAULT = 10;
    public static final long CONTRACT_MAX_EMAIL_COUNT_DEFAULT = 10;
    public static final long CONTRACT_MAX_SMS_COUNT_DEFAULT = 0;
    public static final long CONTRACT_MAX_SMS_CMD_COUNT_DEFAULT = 0;

    public static final String CONTRACT_TYPE_ORGANIZATION = "O";
    public static final String CONTRACT_TYPE_INDIVIDUAL = "I";

    // constants for Persistence.User User Status
    public static final String STATUS_ACTIVE = "A";
    public static final String STATUS_DELETE = "D";

    public static final String STATUS_UNBLOCK = "A";
    public static final String STATUS_BLOCK = "B";

    public static final int LIST_PER_PAGE = 20;
    public static final int LIST_PER_PAGE_X5 = 100;

    /* Mobject Icons' IDs ON MAP */
    public static final long MAP_MOBJECT_ICON_CAR = 1;
    public static final long MAP_MOBJECT_ICON_MOBILE = 2;
    public static final long MAP_MOBJECT_ICON_DEFAULT = MAP_MOBJECT_ICON_CAR;

    /* User Access List ID */

    public static final Integer USER_ACCESS_NONE = 0;
    public static final Integer USER_ACCESS_VIEW = 1;
    public static final Integer USER_ACCESS_EDIT = 2;
    public static final Integer USER_ACCESS_ADD = 4;
    public static final Integer USER_ACCESS_DELETE = 8;
    public static final Integer USER_ACCESS_FULL = 15;

    /* Journal constants */
// REPORT           : 100
// POI              : 200
// USER             : 300
// CONTRACT         : 400
// GPSUNIT          : 500
// COMPANY          : 600
// GEOFANCE         : 700
// NOTIFICATION     : 800
// LOGIN            : 1000
// CURRENCY_TYPE    : 2000
// CURRENCY_RATE    : 2100
// SERVICE          : 2200
    public static final int JOURNAL_ACT_INSERT = 1;
    public static final int JOURNAL_ACT_UPDATE = 2;
    public static final int JOURNAL_ACT_DELETE = 3;
    public static final int JOURNAL_ACT_LOGIN = 4;
    public static final int JOURNAL_ACT_LOGOUT = 5;
    public static final int JOURNAL_ACT_GET = 6;

    public static final int JOURNAL_REPORT = 100;
    public static final int JOURNAL_REPORT_INSERT = 101;
    public static final int JOURNAL_REPORT_UPDATED = 102;
    public static final int JOURNAL_REPORT_DELETED = 103;
    public static final int JOURNAL_REPORT_GET = 104;
    public static final int JOURNAL_REPORT_VIEW = 105;
    public static final int JOURNAL_REPORT_MOBILE_VIEW = 106;


    public static final int JOURNAL_POI = 200;
    public static final int JOURNAL_POI_INSERT = 201;
    public static final int JOURNAL_POI_UPDATED = 202;
    public static final int JOURNAL_POI_DELETED = 203;

    public static final int JOURNAL_ADMIN_USER = 300;
    public static final int JOURNAL_ADMIN_USER_INSERT = 301;
    public static final int JOURNAL_ADMIN_USER_UPDATED = 302;
    public static final int JOURNAL_ADMIN_USER_DELETED = 303;
    public static final int JOURNAL_ADMIN_USER_ROLE_INSERT = 311;
    public static final int JOURNAL_ADMIN_USER_ROLE_UPDATED = 312;
    public static final int JOURNAL_ADMIN_USER_ROLE_DELETED = 313;
    public static final int JOURNAL_ADMIN_PROFILE_INSERT = 321;
    public static final int JOURNAL_ADMIN_PROFILE_UPDATED = 322;
    public static final int JOURNAL_ADMIN_PROFILE_DELETED = 323;

    public static final int JOURNAL_ADMIN_CONTRACT = 400;
    public static final int JOURNAL_ADMIN_CONTRACT_INSERT = 401;
    public static final int JOURNAL_ADMIN_CONTRACT_UPDATED = 402;
    public static final int JOURNAL_ADMIN_CONTRACT_DELETED = 403;

    public static final int JOURNAL_ADMIN_CONTRACT_SETTINGS_INSERT = 421;
    public static final int JOURNAL_ADMIN_CONTRACT_SETTINGS_UPDATED = 422;
    public static final int JOURNAL_ADMIN_CONTRACT_SETTINGS_DELETED = 423;

    public static final int JOURNAL_ADMIN_GPSUNIT = 500;
    public static final int JOURNAL_ADMIN_GPSUNIT_INSERT = 501;
    public static final int JOURNAL_ADMIN_GPSUNIT_UPDATED = 502;
    public static final int JOURNAL_ADMIN_GPSUNIT_DELETED = 503;

    public static final int JOURNAL_ADMIN_GPSUNIT_TYPE_INSERT = 521;
    public static final int JOURNAL_ADMIN_GPSUNIT_TYPE_UPDATED = 522;
    public static final int JOURNAL_ADMIN_GPSUNIT_TYPE_DELETED = 523;

    public static final int JOURNAL_ADMIN_GPSUNIT_SIM_INSERT = 541;
    public static final int JOURNAL_ADMIN_GPSUNIT_SIM_UPDATED = 542;
    public static final int JOURNAL_ADMIN_GPSUNIT_SIM_DELETED = 543;

    public static final int JOURNAL_ADMIN_SIM_INSERT = 551;
    public static final int JOURNAL_ADMIN_SIM_UPDATED = 552;
    public static final int JOURNAL_ADMIN_SIM_DELETED = 553;

    public static final int JOURNAL_ADMIN_MOBJECT_INSERT = 561;
    public static final int JOURNAL_ADMIN_MOBJECT_UPDATED = 562;
    public static final int JOURNAL_ADMIN_MOBJECT_DELETED = 563;

    public static final int JOURNAL_ADMIN_MOBJECT_SETTINGS_INSERT = 571; // todo
    public static final int JOURNAL_ADMIN_MOBJECT_SETTINGS_UPDATED = 572; // todo
    public static final int JOURNAL_ADMIN_MOBJECT_SETTINGS_DELETED = 573; // todo

    public static final int JOURNAL_ADMIN_MOBJECT_GPSUNIT_INSERT = 581;
    public static final int JOURNAL_ADMIN_MOBJECT_GPSUNIT_UPDATED = 582;
    public static final int JOURNAL_ADMIN_MOBJECT_GPSUNIT_DELETED = 583;

    public static final int JOURNAL_ADMIN_MOBJECT_NOTIFICATION_INSERT = 591;  // todo
    public static final int JOURNAL_ADMIN_MOBJECT_NOTIFICATION_UPDATED = 592; // todo
    public static final int JOURNAL_ADMIN_MOBJECT_NOTIFICATION_DELETED = 593; // todo

    public static final int JOURNAL_ADMIN_COMPANY = 600;
    public static final int JOURNAL_ADMIN_COMPANY_INSERT = 601;
    public static final int JOURNAL_ADMIN_COMPANY_UPDATED = 602;
    public static final int JOURNAL_ADMIN_COMPANY_DELETED = 603;

    public static final int JOURNAL_ADMIN_MOBILE_TRACKER_SETTINGS_INSERT = 611;
    public static final int JOURNAL_ADMIN_MOBILE_TRACKER_SETTINGS_UPDATED = 612;
    public static final int JOURNAL_ADMIN_MOBILE_TRACKER_SETTINGS_DELETED = 613;

    public static final int JOURNAL_GEOFANCE = 700;
    public static final int JOURNAL_GEOFANCE_INSERT = 701;
    public static final int JOURNAL_GEOFANCE_UPDATED = 702;
    public static final int JOURNAL_GEOFANCE_DELETED = 703;

    public static final int JOURNAL_GEOFANCE_POINT_INSERT = 721;
    public static final int JOURNAL_GEOFANCE_POINT_UPDATED = 722;
    public static final int JOURNAL_GEOFANCE_POINT_DELETED = 723;

    public static final int JOURNAL_GROUP = 1100;
    public static final int JOURNAL_GROUP_INSERT = 1111;
    public static final int JOURNAL_GROUP_UPDATE = 1112;
    public static final int JOURNAL_GROUP_DELETE = 1113;

    public static final int JOURNAL_STAFF = 1200;
    public static final int JOURNAL_STAFF_INSERT = 1211;
    public static final int JOURNAL_STAFF_UPDATE = 1212;
    public static final int JOURNAL_STAFF_DELETE = 1213;

    public static final int JOURNAL_MOBJECT_STAFF = 1300;
    public static final int JOURNAL_MOBJECT_STAFF_INSERT = 1311;
    public static final int JOURNAL_MOBJECT_STAFF_UPDATE = 1312;
    public static final int JOURNAL_MOBJECT_STAFF_DELETE = 1313;

    public static final int JOURNAL_USER_MOBJECT_ACCESS_LIST = 1400;
    public static final int JOURNAL_USER_MOBJECT_ACCESS_LIST_UPDATE = 1412;

    public static final int JOURNAL_USER_ACCESS_LIST = 1500;
    public static final int JOURNAL_USER_ACCESS_LIST_UPDATE = 1512;

    public static final int JOURNAL_ADMIN_MOBILE_TRACKER_STATUS = 1600;
    public static final int JOURNAL_ADMIN_MOBILE_TRACKER_STATUS_UPDATED = 1612;

    public static final int JOURNAL_ADMIN_MOBJECT_GEOFENCE = 1700;
    public static final int JOURNAL_ADMIN_MOBJECT_GEOFENCE_UPDATED = 1712;

    public static final int JOURNAL_ADMIN_MOBJECT_POI = 1800;
    public static final int JOURNAL_ADMIN_MOBJECT_POI_UPDATED = 1812;

    public static final int JOURNAL_PROFILE = 1900;
    public static final int JOURNAL_PROFILE_UPDATED = 1912;

    public static final int JOURNAL_GPSTRACKPOINT = 2000;
    public static final int JOURNAL_GPSTRACKPOINT_UPDATE = 2012;
    public static final int JOURNAL_GPSTRACKPOINT_DELETE = 2013;

    public static final int JOURNAL_NOTIFICATION = 800;
    public static final int JOURNAL_NOTIFICATION_IMEI_FOREIGN = 801;
    public static final int JOURNAL_NOTIFICATION_IMEI_BLOCKED = 802;
    public static final int JOURNAL_NOTIFICATION_TRACKER_LIMIT = 803;

    public static final int JOURNAL_LOGIN = 1000;
    public static final int JOURNAL_LOGIN_SUCCESS = 1001;
    public static final int JOURNAL_LOGIN_FAIL = 1009;
    public static final int JOURNAL_LOGIN_TRY_LIMIT = 1010;

    public static final int LOGIN_PASSWORD_SUCCESS = 100;
    public static final int LOGIN_PASSWORD_OLD_NONE = 101;
    public static final int LOGIN_PASSWORD_NEW_NONE = 102;
    public static final int LOGIN_PASSWORD_VERIFY_NONE = 103;
    public static final int LOGIN_PASSWORD_VERIFY_INCORRECT = 104;
    public static final int LOGIN_PASSWORD_OLD_INCORRECT = 105;

    public static final long MOBJECT_SPEED1_MIN = 1;
    public static final long MOBJECT_SPEED1_MAX = 400;
    public static final long MOBJECT_SPEED2_MIN = 1;
    public static final long MOBJECT_SPEED2_MAX = 400;
    public static final long MOBJECT_SPEED3_MIN = 1;
    public static final long MOBJECT_SPEED3_MAX = 400;
    public static final long MOBJECT_SPEED4_MIN = 1;
    public static final long MOBJECT_SPEED4_MAX = 400;
    public static final long MOBJECT_SPEED5_MIN = 1;
    public static final long MOBJECT_SPEED5_MAX = 400;
    public static final long MOBJECT_MIN_SPEED = 1;
    public static final long MOBJECT_MAX_SPEED = 400;
    public static final long MOBJECT_ONLINETIME_MAX = 7200;
    public static final long MOBJECT_ONLINETIME_MIN = 60;
    public static final long MOBJECT_ONLINETIME = 900;
    public static final long MOBJECT_PARKINGTIME_MIN = 60;
    public static final long MOBJECT_PARKINGTIME_MAX = 3600;

    public static final long MOBJECT_TYPE_DEFAULT_TYPE = 1L;
    public static final long MOBJECT_TYPE_TSHTX_DEFAULT_TYPE = 3L;
    public static final long MOBJECT_STATE_DEFAULT_TYPE = 1L;
    public static final long MOBJECT_APPOINTMENT_DEFAULT = 1L;

    public static final int NOTIFICATION_MIN_SPEED_MIN = 1;
    public static final int NOTIFICATION_MIN_SPEED_MAX = 20;
    public static final int NOTIFICATION_MAX_SPEED_MIN = 1;
    public static final int NOTIFICATION_MAX_SPEED_MAX = 400;

    public static final int MONITORING_REFRESHINTERVAL_MIN = 1;
    public static final int MONITORING_REFRESHINTERVAL_MAX = 3600;
    public static final long MONITORING_TOOLTIPISVIEWQUANTITY_MAX = 50;
    public static final long MONITORING_TOOLTIPISVIEWQUANTITY_MIN = 1;
    public static final long MONITORING_TRECKLENGHTVALUE1_MIN = 1;
    public static final long MONITORING_TRECKLENGHTVALUE1_MAX = 10;
    public static final long MONITORING_TRECKLENGHTVALUE2_MAX = 60;
    public static final long MONITORING_TRECKLENGHTVALUE2_MIN = 10;

    public static final int COSTOMER_TRACKER_TBIG_MIN = 1;
    public static final int COSTOMER_TRACKER_TBIG_MAX = 86400;
    public static final int COSTOMER_TRACKER_DMIN_MIN = 1;
    public static final int COSTOMER_TRACKER_DMIN_MAX = 100;
    public static final int COSTOMER_TRACKER_DBIG_MIN = 1;
    public static final int COSTOMER_TRACKER_DBIG_MAX = 1000;
    public static final int COSTOMER_TRACKER_TMAXBIG_MIN = 1;
    public static final int COSTOMER_TRAKER_TMAXBIG_MAX = 86400;
    public static final int COSTOMER_TRAKER_TLOST_MIN = 1;
    public static final int COSTOMER_TRAKER_TLOST_MAX = 86400;
    public static final int COSTOMER_DEFAULT_TRACKER_TIME_MIN = 10;
    public static final int COSTOMER_DEFAULT_TRACKER_TIME_BIG = 7200;
    public static final int COSTOMER_DEFAULT_TRACKER_TIME_LOST = 300;
    public static final int COSTOMER_DEFAULT_TRACKER_DISTANCE_MIN = 10;
    public static final int COSTOMER_DEFAULT_TRACKER_DISTANCE_BIG = 1000;

    public static final boolean MTRACKER_DEFAULT_SETTINGS_HAS_PASSWORD = true;
    public static final int MTRACKER_DEFAULT_SETTINGS_PASSWORD = 2345;
    public static final int MTRACKER_DEFAULT_LOCATION_UPDATE_TIME = 300;
    public static final int MTRACKER_DEFAULT_LOCATION_UPDATE_DISTANCE = 10;
    public static final int MTRACKER_DEFAULT_LOCATION_UPDATE_ANGLE = 15;
    public static final int MTRACKER_DEFAULT_LOCATION_UPDATE_ACCURACY = 2;
    public static final boolean MTRACKER_DEFAULT_SHOULD_STATUS_CHANGE = true;
    public static int MTRACKER_DEFAULT_SERVER_PORT = 4000;
    //    static public String MTRACKER_DEFAULT_SERVER_IP = "195.158.26.17";
    public static String MTRACKER_DEFAULT_SERVER_IP = "83.69.136.55";
    public static final int MTRACKER_DEFAULT_RECORD_LIMIT = 10;
    public static final int MTRACKER_DEFAULT_HIDE_ICON = 0;
    public static final int MTRACKER_DEFAULT_SETTINGS_UPDATE_TIME = 900;
    public static final int MTRACKER_DEFAULT_LOCATION_SEND_TIME = 300;
    public static final boolean MTRACKER_DEFAULT_SHOULD_SEND_3G = true;
    public static final boolean MTRACKER_DEFAULT_SHOULD_SEND_WIFI = true;
    public static final int MTRACKER_DEFAULT_TRACK_LENGTH = 7;
    public static final int MTRACKER_DEFAULT_MAP_TYPE = 1;

    public static final int TRACKER_TYPE_MOBILE = 1;
    public static final int TRACKER_TYPE_GPS = 0;

    public static final int LOCATION_UPDATE_TIME_MIN = 1;
    public static final int LOCATION_UPDATE_TIME_MAX = 86400;
    public static final int LOCATION_UPDATE_DICTANSE_MIN = 0;
    public static final int LOCATION_UPDATE_DICTANSE_MAX = 1000;
    public static final int LOCATION_UPDATE_ANGLE_MIN = 0;
    public static final int LOCATION_UPDATE_ANGLE_MAX = 360;
    public static final int RECORD_LIMIT_MIN = 1;
    public static final int RECORD_LIMIT_MAX = 100;
    public static final int LOCATION_UPDATE_SEND_TIME_MIN = 1;
    public static final int LOCATION_UPDATE_SEND_TIME_MAX = 86400;
    public static final int TRACK_LENGTH_MIN = 0;
    public static final int TRACK_LENGTH_MAX = 7;

    public static final int ROUTE_ROAD_WIDTH_MIN = 0; //in meters
    public static final int ROUTE_ROAD_WIDTH_MAX = 1000; //in meters

    public static final int ROUTE_NAME_FONT_SIZE_MIN = 6;
    public static final int ROUTE_NAME_FONT_SIZE_MAX = 15;

    public static final int STATION_WIDTH_MIN = 0; //in meters
    public static final int STATION_WIDTH_MAX = 1000; //in meters

    public static final int STATION_RADIUS_MIN = 0; //in meters
    public static final int STATION_RADIUS_MAX = 1000 * 1000; //in meters

    public static final int STATION_NAME_FONT_SIZE_MIN = 6;
    public static final int STATION_NAME_FONT_SIZE_MAX = 15;


    public static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

    public enum ROLE {
        ADMIN(1),
        GUIDES(2),
        DOCUMENT_REGISTRATION(3),
        APPLICATION_REGISTRATION(4),
        DOCUMENT_RESOLUTION(5);

        private final Integer value;

        private ROLE(Integer value) {
            this.value = value;
        }

        public Integer getValue() {
            return value;
        }
    }

    public enum DOC_CATEGORY {
        INCOMING(new Short("1")),
        OUTGOING(new Short("2")),
        INTERNAL(new Short("3")),
        APPLICATION(new Short("4"));

        private final Short value;

        private DOC_CATEGORY(Short value) {
            this.value = value;
        }

        public Short getValue() {
            return value;
        }
    }

    public enum TRACK_VIEW_TYPE {
        BY_DAY(1),
        BY_DAY_AND_TRIP_PARKING(2),
        ALL(3);

        private final int value;

        TRACK_VIEW_TYPE(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    public enum KML_EXTRA_DATA_EVENT_TYPE {
        PARKING(1),
        TRIP(2);

        private final int value;

        KML_EXTRA_DATA_EVENT_TYPE(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    public enum AUTHENTICATION_METHOD {
        SIMPLE(1),                               // uses http form based login/password method
        OPENID(2),                               // uses OPENID method
        LDAP(4),                                 // uses LDAP method
        REQUIRE_CERTIFICATE(8),                  // requires certificate and digital signature on authorization digitally signed hash of (login+password+sessionID+salt)
        INCLUDE_PASSWORD_PREFACE(16),            // received password string includes preface as NNXXXXXX, where NN - 2 digit decimal length of original password, XXXXX original password characters
        INCLUDE_CRYPTED_PASSWORD_PREFACE(32);    // crypt password preface with the given pubic key

        private final int value;

        private AUTHENTICATION_METHOD(int value) {
            this.value = value;
        }

        public int getValue() {
            return value;
        }
    }

    // Functions, that change constant values on stating system

    public void setSystemInstalledName(String systemInstalledName) {
        SYSTEM_INSTALLED_NAME = systemInstalledName;
    }

    public void setMtrackerDefaultServerPort(int mtrackerDefaultServerPort) {
        MTRACKER_DEFAULT_SERVER_PORT = mtrackerDefaultServerPort;
    }

    public void setMtrackerDefaultServerIp(String mtrackerDefaultServerIp) {
        MTRACKER_DEFAULT_SERVER_IP = mtrackerDefaultServerIp;
    }
}
