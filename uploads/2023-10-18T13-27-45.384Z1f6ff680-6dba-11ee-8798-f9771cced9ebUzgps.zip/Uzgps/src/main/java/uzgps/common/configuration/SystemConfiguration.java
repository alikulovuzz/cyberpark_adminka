package uzgps.common.configuration;

/**
 * Created by Stanislav on 17.02.2019.
 */
public class SystemConfiguration {

    private static String systemServer;

    public static String getSystemServer() {
        return systemServer;
    }

    public void setSystemServer(String systemServer) {
        SystemConfiguration.systemServer = systemServer;
    }
}
