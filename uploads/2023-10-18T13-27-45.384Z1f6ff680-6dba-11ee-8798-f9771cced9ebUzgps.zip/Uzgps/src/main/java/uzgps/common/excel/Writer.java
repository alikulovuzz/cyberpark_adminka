package uzgps.common.excel;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import uzgps.excel.tripReports.objectMovement.CustomWorkSheetOM;
import uzgps.excel.tripReports.trip.CustomWorkSheet;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * Created by Stanislav on 30.03.2016 18:10.
 */
public class Writer {

    private static Logger logger = Logger.getLogger("service");

    /**
     * Writes the report to the output stream
     */
    public static void write(HttpServletResponse response, XSSFSheet worksheet) {

        logger.debug("Writing report to the stream");
        try {
            // Retrieve the output stream
            ServletOutputStream outputStream = response.getOutputStream();
            // Write to the output stream
            worksheet.getWorkbook().write(outputStream);
            // Flush the stream
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            logger.error("Unable to write report to the output stream");
        }
    }

    /**
     * Writes the report to the output stream
     */
    public static void write(HttpServletResponse response, List<CustomWorkSheet> customWorkSheetList) {

        logger.debug("Writing report to the stream");
        try {
            // Retrieve the output stream
            ServletOutputStream outputStream = response.getOutputStream();
            // Write to the output stream

            for (CustomWorkSheet customWorkSheet : customWorkSheetList) {
                customWorkSheet.getWorksheet().getWorkbook().write(outputStream);
            }

            // Flush the stream
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            logger.error("Unable to write report to the output stream");
        }
    }

    /**
     * Writes the report to the output stream
     */
    public static void writeOM(HttpServletResponse response, List<CustomWorkSheetOM> customWorkSheetList) {

        logger.debug("Writing report to the stream");
        try {
            // Retrieve the output stream
            ServletOutputStream outputStream = response.getOutputStream();
            // Write to the output stream

            for (CustomWorkSheetOM customWorkSheet : customWorkSheetList) {
                customWorkSheet.getWorksheet().getWorkbook().write(outputStream);
            }

            // Flush the stream
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            logger.error("Unable to write report to the output stream");
        }
    }

    /**
     * Writes the report to the output stream
     */
    public static void write(HttpServletResponse response, XSSFSheet worksheet, XSSFSheet chartWorksheet) {
        logger.debug("Writing report to the stream");
        try {
            // Retrieve the output stream
            ServletOutputStream outputStream = response.getOutputStream();

            // Write to the output stream
            chartWorksheet.getWorkbook().write(outputStream);
            worksheet.getWorkbook().write(outputStream);

            // Flush the stream
            outputStream.flush();

        } catch (Exception e) {
            logger.error("Unable to write report to the output stream");
        }
    }
}
