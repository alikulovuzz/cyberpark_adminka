package uzgps.common.excel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;

import java.util.Locale;

/**
 * Created by Stanislav on 29.08.2016 14:59.
 */
@Component
public class TextTranslator {

    @Autowired
    private MessageSource messageSource;

    private Locale locale;

    public TextTranslator() {

    }

    /**
     * Return translated string
     *
     * @param langCode
     * @return
     */
    public String translateText(String langCode) {
        try {
            locale = LocaleContextHolder.getLocale();
            return messageSource.getMessage(langCode, null, locale);
        } catch (Exception ex) {
            return langCode;
        }
    }

}


