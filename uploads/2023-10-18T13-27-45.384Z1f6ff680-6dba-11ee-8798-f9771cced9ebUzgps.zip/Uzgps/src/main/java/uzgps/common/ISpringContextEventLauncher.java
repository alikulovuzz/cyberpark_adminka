package uzgps.common;

import org.springframework.context.ApplicationEvent;

/**
 * Created by Sheroz Khaydarov
 * 16.03.14.
 */
public interface ISpringContextEventLauncher {
    void onContextEvent(ApplicationEvent event);
}
