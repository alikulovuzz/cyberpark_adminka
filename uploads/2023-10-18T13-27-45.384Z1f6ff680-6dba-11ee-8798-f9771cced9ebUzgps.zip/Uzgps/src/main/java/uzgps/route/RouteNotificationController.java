package uzgps.route;

import com.fasterxml.jackson.databind.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import uz.netex.datatype.MobjectBig;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.CoreEventNotificationSettings;
import uz.netex.routing.core.helpers.CoreEventType;
import uz.netex.routing.core.helpers.CoreNotificationSettings;
import uz.netex.routing.database.tables.EventNotificationSettings;
import uz.netex.routing.database.tables.EventType;
import uz.netex.routing.database.tables.NotificationSettings;
import uz.netex.uzgps.errors.Errors;
import uzgps.route.json.models.EventNotificationSettingsJSON;
import uzgps.route.json.response.ResponseEventNotification;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by G'ayrat on 05.05.15
 */
@Controller
public class RouteNotificationController extends AbstractRoutingController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTE_NOTIFICATION = "/route/notification.htm";
    private final static String VIEW_ROUTE_NOTIFICATION = "route/notification";

    private final static String URL_AJAX_EVENT_NOTIFICATION_SETTINGS = "/route/ajax-event-notification-settings.htm";
    private final static String VIEW_AJAX_EVENT_NOTIFICATION_SETTINGS = "/route/ajax-event-notification-settings";

    private final static String URL_AJAX_EVENT_NOTIFICATION_SETTINGS_SAVE = "/route/ajax-event-notification-settings-save.htm";

//    @Autowired
//    InternalResourceViewResolver htmlViewResolver;

    @Override
    protected String getActiveRouteTabMenu() {
        return "notification";
    }

    /**
     * Get MObject, EventType, NotificationSettings, EventNotificationSettings list models
     * and notification-left.jsp, notification-content.jsp view inside layout
     *
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_NOTIFICATION)
    private ModelAndView notificationMain(HttpSession session)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_NOTIFICATION);

        Map<String, Object> mapModels = new HashMap<>();
        List<MobjectBig> mobjectBigList = getMobjectList(session);
        MobjectBig mobjectBig = null;
        //Get first mobject
        if (mobjectBigList != null && mobjectBigList.size() > 0) {
            mobjectBig = mobjectBigList.get(0);
            modelAndView.addObject("mobjectName", mobjectBig.getName());
        }

        // Add mobjectBigList models
        mapModels.put("mobjectList", mobjectBigList);

        if (mobjectBig != null) {
            mapModels.putAll(getNotificationSettingsByMobjectId(session, mobjectBig.getId()));
            mapModels.putAll(getEventNotificationSettingsListByMobjectId(session, mobjectBig.getId()));
        }

        modelAndView.addAllObjects(mapModels);

        // Make json response
        ResponseEventNotification responseEventNotification = new ResponseEventNotification();
        responseEventNotification.setEventNotificationSettingsJSONList((List<EventNotificationSettings>) mapModels.get("eventNotfSettingsList"));

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            modelAndView.addObject("eventList", writer.writeValueAsString(responseEventNotification));
        } catch (Exception e) {
            logger.error("Error: ", e);
        }

        return modelAndView;
    }

    /**
     * Get List of EventNotificationSettings models and ajax-event-notification-settings.jsp view
     *
     * @param mobjectId
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_AJAX_EVENT_NOTIFICATION_SETTINGS)
    private void ajaxEventNotificationSettings(HttpSession session,
                                               HttpServletResponse response,
                                               HttpServletRequest request,
                                               @RequestParam(value = "mobject-id", required = false) String mobjectId)
            throws ServletException, IOException {

        Map<String, Object> mapModels = new HashMap<>();
        mapModels.putAll(getNotificationSettingsByMobjectId(session, strToLong(mobjectId, null)));
        mapModels.putAll(getEventNotificationSettingsListByMobjectId(session, strToLong(mobjectId, null)));

        MobjectBig mobjectBig = coreMain.getMobjectById(strToLong(mobjectId, null));
        if (mobjectBig != null) {
            mapModels.put("mobjectName", mobjectBig.getName());
        }

        mapModels.put("userAccessList", getUserAccessList(session));

        try {
            // Get rendered html from view
            View resolvedView = htmlViewResolver.resolveViewName(VIEW_AJAX_EVENT_NOTIFICATION_SETTINGS, response.getLocale());
            MockHttpServletResponse mockResp = new MockHttpServletResponse();
            mockResp.setCharacterEncoding("UTF-8");
            resolvedView.render(mapModels, request, mockResp);

            // Make json response
            ResponseEventNotification responseEventNotification = new ResponseEventNotification();
            responseEventNotification.setEventNotificationSettingsJSONList((List<EventNotificationSettings>) mapModels.get("eventNotfSettingsList"));
            responseEventNotification.setHtml(mockResp.getContentAsString().trim());

            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseEventNotification);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Save or update EventNotificationSettings and NotificationSettings
     *
     * @param mobjectId
     * @param email
     * @param phoneNumber
     * @param eventNotfList EventNotificationSettings list in json string
     * @return model view
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_AJAX_EVENT_NOTIFICATION_SETTINGS_SAVE)
    private String ajaxEventNotificationSettingsSave(HttpSession session,
                                                     @RequestParam(value = "notf-settings-id", required = false) String notfSettingsId,
                                                     @RequestParam(value = "mobject-id", required = false) String mobjectId,
                                                     @RequestParam(value = "email", required = false) String email,
                                                     @RequestParam(value = "phone", required = false) String phoneNumber,
                                                     @RequestParam(value = "event-list", required = false) String eventNotfList,
                                                     @RequestParam(value = "selected-objects", required = false) String[] selectedObjects,
                                                     RedirectAttributes redirectAttributes)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("ajaxEventNotificationSettingsSave eventNotfList: {}", eventNotfList);
        }

        EventNotificationSettingsJSON[] eventNotificationSettingsJSONs;
        if (eventNotfList != null && eventNotfList.length() > 0) {
            // Convert JSON string to Object
            try {
                eventNotificationSettingsJSONs = jsonMapper.readValue(eventNotfList, EventNotificationSettingsJSON[].class);
            } catch (Exception e) {
                eventNotificationSettingsJSONs = null;
            }

            if (eventNotificationSettingsJSONs != null) {
                if (selectedObjects != null && selectedObjects.length > 0) {
                    for (String selectedObject : selectedObjects) {
                        Long moId = strToLongExtended(selectedObject, 0L);
                        updateEventNotificationSettings(session, eventNotificationSettingsJSONs, moId);
                    }
                } else {
                    updateEventNotificationSettings(session, eventNotificationSettingsJSONs, null);
                }
            }
        }

        Integer errCode = 0;
        if (selectedObjects != null && selectedObjects.length > 0) {
            for (String selectedObject : selectedObjects) {
                Long moId = strToLongExtended(selectedObject, 0L);
                errCode = notificationSettingsSave(session, moId, email, phoneNumber);
            }
        } else {
            errCode = notificationSettingsSave(session, strToLong(notfSettingsId, null), strToLong(mobjectId, null), email, phoneNumber);
        }

        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("nsErrCode", errCode);
        }
        redirectAttributes.addAttribute("mobject-id", strToLong(mobjectId, null));

        return "redirect:" + URL_AJAX_EVENT_NOTIFICATION_SETTINGS;
    }

    /**
     * Update event notification settings
     *
     * @return
     */
    private synchronized void updateEventNotificationSettings(HttpSession session, EventNotificationSettingsJSON[]
            eventNotificationSettingsJSONs, Long selectedMObjectId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
        CoreEventNotificationSettings coreEventNotificationSettings = tripRoutingControl.getCoreEventNotificationSettings();

        for (EventNotificationSettingsJSON eventNotificationSettingsJSON1 : eventNotificationSettingsJSONs) {
            if (logger.isDebugEnabled()) {
                logger.debug("Event notification setting: {}", eventNotificationSettingsJSON1);
            }
            EventNotificationSettingsJSON eventNotificationSettingsJSON = eventNotificationSettingsJSON1;

            EventNotificationSettings eventNotificationSettings = getEventNotificationSettings(session,
                    eventNotificationSettingsJSON.getId());

            if (eventNotificationSettings == null) {
                eventNotificationSettings = new EventNotificationSettings();
            }

            if (selectedMObjectId != null) {
                eventNotificationSettings = coreEventNotificationSettings.getByMobjectAndEvent(selectedMObjectId,
                        eventNotificationSettingsJSON.getEventTypeId());
            } else {
                eventNotificationSettings.setMobjectId(eventNotificationSettingsJSON.getMobjectId());
            }

            eventNotificationSettings.setEventTypeId(eventNotificationSettingsJSON.getEventTypeId());
            eventNotificationSettings.setUseNotification(eventNotificationSettingsJSON.getUseNotification());
            eventNotificationSettings.setUseIcon(eventNotificationSettingsJSON.getUseIcon());
            eventNotificationSettings.setUseMessage(eventNotificationSettingsJSON.getUseMessage());
            eventNotificationSettings.setUseNarusheniye(eventNotificationSettingsJSON.getUseNarusheniye());
            eventNotificationSettings.setUseEmail(eventNotificationSettingsJSON.getUseEmail());
            eventNotificationSettings.setUseSms(eventNotificationSettingsJSON.getUseSms());
            eventNotificationSettings.setSound(eventNotificationSettingsJSON.getSound());
            eventNotificationSettings.setColor(eventNotificationSettingsJSON.getColor());

            eventNotificationSettingsSave(session, eventNotificationSettings);
        }
    }


    /**
     * Get list of EventType
     * "eventTypeList" key to get values from mapModel
     *
     * @return Map<String, List<EventType>>
     */
    private Map<String, List<EventType>> getEventTypeList() {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
        Map<String, List<EventType>> mapModel = new HashMap<>();

        if (tripRoutingControl != null) {
            CoreEventType coreEventType = tripRoutingControl.getCoreEventType();
            List<EventType> eventTypeList = coreEventType.getList();

            mapModel.put("eventTypeList", eventTypeList);
        }

        return mapModel;
    }

    /**
     * Get NotificationSettings by mobject id
     * "notfSettings" key to get value from mapModel
     *
     * @param mobjectId
     * @return Map<String, NotificationSettings>
     */
    private Map<String, NotificationSettings> getNotificationSettingsByMobjectId(HttpSession session, Long mobjectId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
        Map<String, NotificationSettings> mapModel = new HashMap<>();

        if (mobjectId == null) {
            return mapModel;
        }

        if (!hasAccessEditForMobject(session, mobjectId))
            return mapModel;

        if (tripRoutingControl != null) {
            CoreNotificationSettings coreNotificationSettings = tripRoutingControl.getCoreNotificationSettings();
            NotificationSettings notificationSettings = coreNotificationSettings.getByMobject(mobjectId);

            if (notificationSettings == null) {
                notificationSettings = new NotificationSettings();
                notificationSettings.setMobjectId(mobjectId);
            }
            mapModel.put("notfSettings", notificationSettings);
        }

        return mapModel;
    }

    /**
     * Get list EventNotificationSettings by mobject id
     * "eventNotfSettingsList" key to get value from mapModel
     *
     * @param mobjectId
     * @return Map<String, EventNotificationSettings>
     */
    private Map<String, List<EventNotificationSettings>> getEventNotificationSettingsListByMobjectId(HttpSession session, Long mobjectId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
        Map<String, List<EventNotificationSettings>> mapModel = new HashMap<>();

        if (mobjectId == null) {
            return mapModel;
        }

        if (!hasAccessEditForMobject(session, mobjectId))
            return mapModel;

        if (tripRoutingControl != null) {
            CoreEventNotificationSettings coreEventNotificationSettings = tripRoutingControl.getCoreEventNotificationSettings();
            List<EventType> eventTypeList = getEventTypeList().get("eventTypeList");
            List<EventNotificationSettings> eventNotificationSettingsList = null;

            if (eventTypeList != null) {
                eventNotificationSettingsList = new ArrayList<>();

                for (EventType eventType : eventTypeList) {
                    EventNotificationSettings eventNotificationSettings = coreEventNotificationSettings.getByMobjectAndEvent(mobjectId, eventType.getId());

                    if (eventNotificationSettings == null) {
                        eventNotificationSettings = new EventNotificationSettings();
                        eventNotificationSettings.setMobjectId(mobjectId);
                        eventNotificationSettings.setEventTypeId(eventType.getId());
                    }

                    eventNotificationSettingsList.add(eventNotificationSettings);
                }
            }

            mapModel.put("eventNotfSettingsList", eventNotificationSettingsList);
        }

        return mapModel;
    }

    /**
     * Get EventNotificationSettings by id
     *
     * @param eventNsId
     * @return
     */
    private EventNotificationSettings getEventNotificationSettings(HttpSession session, Long eventNsId) {
        if (eventNsId == null) {
            return null;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreEventNotificationSettings coreEventNotificationSettings = tripRoutingControl.getCoreEventNotificationSettings();
            EventNotificationSettings eventNotificationSettings = coreEventNotificationSettings.get(eventNsId);

            if (eventNotificationSettings != null) {
                if (hasAccessEditForMobject(session, eventNotificationSettings.getMobjectId())) {
                    return eventNotificationSettings;
                }
            }

            return null;
        }

        return null;
    }

    /**
     * Save or update notification settings
     *
     * @param nsId
     * @param mobjectId
     * @param email
     * @param phoneNumber
     * @return
     */
    private synchronized int notificationSettingsSave(HttpSession session, Long nsId, Long mobjectId, String email, String phoneNumber) {
        if (mobjectId == null)
            return Errors.ERR_OBJECT_IS_NULL;

        if (!hasAccessEditForMobject(session, mobjectId))
            return Errors.ERR_OBJECT_IS_NULL;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreNotificationSettings coreNotificationSettings = tripRoutingControl.getCoreNotificationSettings();
            NotificationSettings notificationSettings = coreNotificationSettings.get(nsId);

            if (notificationSettings == null) {
                notificationSettings = new NotificationSettings();
            }

            notificationSettings.setMobjectId(mobjectId);
            notificationSettings.setEmail(email);
            notificationSettings.setSms(phoneNumber);

            return coreNotificationSettings.save(notificationSettings);

        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Save or update notification settings
     *
     * @param mobjectId
     * @param email
     * @param phoneNumber
     * @return
     */
    private synchronized int notificationSettingsSave(HttpSession session, Long mobjectId, String email, String phoneNumber) {
        if (mobjectId == null)
            return Errors.ERR_OBJECT_IS_NULL;

        if (!hasAccessEditForMobject(session, mobjectId))
            return Errors.ERR_OBJECT_IS_NULL;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreNotificationSettings coreNotificationSettings = tripRoutingControl.getCoreNotificationSettings();
            NotificationSettings notificationSettings = coreNotificationSettings.getByMobject(mobjectId);

            if (notificationSettings == null) {
                notificationSettings = new NotificationSettings();
            }

            notificationSettings.setMobjectId(mobjectId);
            notificationSettings.setEmail(email);
            notificationSettings.setSms(phoneNumber);

            return coreNotificationSettings.save(notificationSettings);

        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Save or update event notification settings
     *
     * @param eventNotificationSettings
     * @return
     */
    private int eventNotificationSettingsSave(HttpSession session, EventNotificationSettings eventNotificationSettings) {
        if (eventNotificationSettings == null)
            return Errors.ERR_OBJECT_IS_NULL;

        if (eventNotificationSettings.getMobjectId() == null)
            return Errors.ERR_OBJECT_IS_NULL;

        if (!hasAccessEditForMobject(session, eventNotificationSettings.getMobjectId()))
            return Errors.ERR_OBJECT_IS_NULL;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreEventNotificationSettings coreEventNotificationSettings = tripRoutingControl.getCoreEventNotificationSettings();

            return coreEventNotificationSettings.save(eventNotificationSettings);

        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }
}
