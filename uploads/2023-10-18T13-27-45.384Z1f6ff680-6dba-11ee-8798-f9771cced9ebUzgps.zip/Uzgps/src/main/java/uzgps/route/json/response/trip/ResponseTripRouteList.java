package uzgps.route.json.response.trip;

import uz.netex.routing.database.tables.TripRoute;
import uz.netex.routing.database.tables.TripRouteStation;
import uz.netex.routing.database.tables.TripStation;
import uzgps.route.json.models.RouteJSON;
import uzgps.route.json.models.StationJSON;
import uzgps.route.json.response.ResponseRouteList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by Gayratjon on 7/4/2015.
 */
public class ResponseTripRouteList extends ResponseRouteList {

    public ResponseTripRouteList(List<TripRoute> tripRouteList) {
        super();

        if (tripRouteList != null) {
            this.routeList = new ArrayList<>();
            this.stationMap = new HashMap<>();

            for (TripRoute tripRoute : tripRouteList) {
                if (tripRoute != null) {
                    RouteJSON routeJSON = new RouteJSON(tripRoute);
                    List<Long> stationIdList = null;
                    List<TripRouteStation> tripRouteStationList = tripRoute.getTripRouteStationList();

                    if (tripRouteStationList != null) {
                        stationIdList = new ArrayList<>();

                        for (TripRouteStation tripRouteStation : tripRouteStationList) {
                            TripStation tripStation = tripRouteStation.getTripStation();

                            if (tripStation != null) {
                                stationIdList.add(tripStation.getStationId());
                                // Collect TripStation list for JSON
                                this.stationMap.put(tripStation.getStationId(), new StationJSON(tripStation));
                            }
                        }
                    }

                    routeJSON.setStationIdList(stationIdList);
                    // Collect TripRoute list for JSON
                    this.routeList.add(routeJSON);
                }
            }
        }
    }
}