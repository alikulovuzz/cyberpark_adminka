package uzgps.route;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.core.helper.CorePoi;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GPSTrackPointList;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectTracks;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Poi;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.CoreStaffAccess;
import uz.netex.routing.database.tables.StaffAccess;
import uz.netex.routing.database.tables.Trip;
import uz.netex.routing.database.tables.TripRoute;
import uz.netex.routing.database.tables.TripRouteStation;
import uz.netex.routing.service.TripRunnerService;
import uz.netex.uzgps.errors.Errors;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.models.MObjectTrackDataJSON;
import uzgps.map.models.MonitorData;
import uzgps.map.models.Point;
import uzgps.map.models.TrackPopupData;
import uzgps.map.models.notification.MessageNotification;
import uzgps.persistence.ContractSettings;
import uzgps.route.json.models.TripJSON;
import uzgps.route.json.response.trip.ResponseTripRouteList;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

import static uzgps.common.UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN_STR;

/**
 * Created by Gayratjon on 6/4/2015.
 */

@Controller
public class RouteControlController extends AbstractRoutingController {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public final static String URL_ROUTE_CONTROL_MAIN = "/route/control.htm";
    private final static String VIEW_ROUTE_CONTROL_MAIN = "route/route-control";

    private final static String AJAX_URL_SINGLE_TRIP_CONTROL = "/route/ajax-single-trip-control.htm";
    private final static String AJAX_VIEW_SINGLE_TRIP_CONTROL = "route/ajax-single-trip-control";

    private final static String AJAX_URL_TRIP_LIST = "/route/ajax-trip-list.htm";
    private final static String AJAX_VIEW_TRIP_LIST = "/route/ajax-trip-list";

    private final static String AJAX_URL_DISPATCHER_OBJECT_MONITORING = "/route/ajax-dispatcher-object-monitoring.htm";
    private final static String AJAX_URL_TRIPS_PROGRESS = "/route/ajax-trips-progress.htm";

    private final static String AJAX_URL_TRIP_REMOVE = "/route/trip-remove.htm";

    @Autowired
    SettingsService settingsService;

    @Autowired
    MonitoringController monitoringController;

    /**
     * Get map type
     *
     * @return Integer
     */
    @ModelAttribute("mapType")
    private Integer getMapType(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        return contractSettings.getMapType().intValue();
    }

    /**
     * Get color of drawing track points on map
     *
     * @param session
     * @return Long
     */
    @ModelAttribute("trackPointsColor")
    private String getTrackPointsColor(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        return contractSettings.getTrackLengthColor();
    }

    /**
     * Get number of notification to display coming from the bottom
     *
     * @return Integer
     */
    @ModelAttribute("numNotification")
    private Integer getNumberOfNotification(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        return contractSettings.getTooltipsViewQuantity().intValue();
    }

    @Override
    protected String getActiveRouteTabMenu() {
        return "control";
    }

    /**
     * Get Trip list and TripRoute list, TripRouteStation list models, render route-control-left.jsp to show Trip list
     *
     * @return ModelAndView
     */
    @RequestMapping(value = URL_ROUTE_CONTROL_MAIN)
    private ModelAndView routeControlMain(HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_CONTROL_MAIN);

        Map<String, Object> mapModels = getTripMapModels(session);
        modelAndView.addAllObjects(mapModels);

        List<TripRoute> tripRouteList = (List<TripRoute>) mapModels.get("tripRouteList");

        if (tripRouteList != null) {
            // Make json response
            ResponseTripRouteList responseTripRouteList = new ResponseTripRouteList(tripRouteList);

            Set<String> ignorableFieldNames = new HashSet<>();
            ignorableFieldNames.add("fstList");

            try {
                SimpleFilterProvider filterProvider = new SimpleFilterProvider();
                filterProvider.addFilter("ResponseRouteListFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFieldNames));

                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
                modelAndView.addObject("tripRouteStationListJson", writer.writeValueAsString(responseTripRouteList));
            } catch (Exception e) {
                logger.error("Error: ", e);
            }
        }

        modelAndView.addObject("lastTripNotificationTime", System.currentTimeMillis());

        return modelAndView;
    }

    /**
     * Loading last points and other data for each mobject from ajax call
     *
     * @param session
     * @param response
     * @throws javax.servlet.ServletException
     * @throws java.io.IOException
     */
    @RequestMapping(value = AJAX_URL_DISPATCHER_OBJECT_MONITORING, method = RequestMethod.GET)
    public void processGettingMovableObjects(HttpSession session,
                                             HttpServletResponse response)
            throws ServletException, IOException {

        // Get  accessed Trip list
        List<Trip> accessedTripList = getAccessedTripList(session);
        List<MobjectTracks> mObjectTracksList = new ArrayList<>();

        if (accessedTripList != null) {
            for (Trip trip : accessedTripList) {
                MobjectTracks mobjectTracks = coreMain.getMobjectTracksByMobject(trip.getMobjectId(), 0L);

                if (mobjectTracks != null) {
                    mObjectTracksList.add(mobjectTracks);
                }
            }
        }

        ContractSettings contractSettings = mainController.getContractSettings(session);

        List<MObjectTrackDataJSON> mObjectTrackDataJSONList = null;
        Set<String> ignorableMObjectTrackFieldNames = new HashSet<>();
//        Set<String> ignorablePopupFieldNames = new HashSet<>();
        Set<String> ignorableMonitorFieldNames = new HashSet<>();

        if (mObjectTracksList.size() > 0) {
            mObjectTrackDataJSONList = new ArrayList<>();
            Long trackPointsCount = contractSettings.getTrackLengthValue();
            Long trackPointsType = contractSettings.getTrackLengthType();

            // Collect mobject in Poi
            CorePoi corePoi = CorePoi.getInstance();
            // Collect mobject in Geofence
            CoreGeofence coreGeofence = CoreGeofence.getInstance();;

            if (corePoi != null) {
                corePoi.loadMobjectsInPoi();
            }

            if (coreGeofence != null) {
                coreGeofence.loadMobjectsInGeofence();
            }

            for (MobjectTracks mobjectTracks : mObjectTracksList) {
                MObjectTrackDataJSON mObjectTrackDataJSON = new MObjectTrackDataJSON();

                MonitorData monitorData = new MonitorData(mobjectTracks, contractSettings, session);
                mObjectTrackDataJSON.setMonitorData(monitorData);

                // Preparing popup data for mobject
                List<GPSTrackPoint> trackPoints = mobjectTracks.getTracks();
                GPSTrackPoint trackPoint = null;

                if (trackPoints != null && trackPoints.size() > 0) {
                    trackPoint = trackPoints.get(0);
                }

                MobjectBig mobjectBig = mobjectTracks.getMobject();

                TrackPopupData trackPopupData = new TrackPopupData();
                trackPopupData.setGPSTrackPoint(trackPoint);
                trackPopupData.setMobjectBig(mobjectBig);

                List<Poi> poiList = null;
                List<Geofence> geofenceList = null;

                if (corePoi != null) {
                    poiList = corePoi.getPoiWithMobjectInside(mobjectBig.getId());
                }

                if (coreGeofence != null) {
                    geofenceList = coreGeofence.getGeofencesWithMobjectInside(mobjectBig.getId());
                }

                trackPopupData.setPoiAndGeoFenceList(poiList, geofenceList);
                trackPopupData.setAssignedRoutes(monitoringController.getAssignedTripNamesToMobject(mobjectBig.getId()));

                mObjectTrackDataJSON.setTrackPopupData(trackPopupData);

                GPSTrackPointList gpsTrackPointList;
                if (trackPointsType == 1)
                    gpsTrackPointList = coreMain.getPointsByDate(mobjectTracks.getMobject().getId(), 0L, 0L, trackPointsCount.intValue());
                else
                    gpsTrackPointList = coreMain.getPointsByLastSeconds(mobjectTracks.getMobject().getId(), trackPointsCount);

                if (gpsTrackPointList.size() > 0) {
                    List<Point> pointList = new ArrayList<>();
                    for (GPSTrackPoint gpsTrackPoint : gpsTrackPointList.getGpsTrackPoints()) {
                        Point point = new Point();
                        point.setLatitude(gpsTrackPoint.getLatitude());
                        point.setLongitude(gpsTrackPoint.getLongitude());
                        point.setAltitude(gpsTrackPoint.getAltitude());
                        point.setTimeStamp(gpsTrackPoint.getTimestamp());
                        pointList.add(point);
                    }
                    mObjectTrackDataJSON.setPointList(pointList);
                }

                if (contractSettings.getTooltipsMassagesView()) {
                    MessageNotification messageNotification = new MessageNotification(mobjectTracks, contractSettings.getTooltipsMassagesColor());
                    mObjectTrackDataJSON.setMessageNot(messageNotification);
                }

                mObjectTrackDataJSONList.add(mObjectTrackDataJSON);
            }

            ignorableMObjectTrackFieldNames.add("messageData");
            if (!contractSettings.getTooltipsMassagesView())
                ignorableMObjectTrackFieldNames.add("messageNot");

            // Ignoring fields for monitoring
            ignorableMonitorFieldNames.add("ai");
            ignorableMonitorFieldNames.add("altitude");
            ignorableMonitorFieldNames.add("cell_id");
            ignorableMonitorFieldNames.add("dat");
            ignorableMonitorFieldNames.add("di_1");
            ignorableMonitorFieldNames.add("di_2");
            ignorableMonitorFieldNames.add("di_3");
            ignorableMonitorFieldNames.add("engineOn");
            ignorableMonitorFieldNames.add("epv");
            ignorableMonitorFieldNames.add("gnss");
            ignorableMonitorFieldNames.add("groupId");
            ignorableMonitorFieldNames.add("gsm_sl");
            ignorableMonitorFieldNames.add("hdop");
            ignorableMonitorFieldNames.add("ibv");
            ignorableMonitorFieldNames.add("lac");
            ignorableMonitorFieldNames.add("mov");
            ignorableMonitorFieldNames.add("objectPhotoUrl");
            ignorableMonitorFieldNames.add("odometer");
            ignorableMonitorFieldNames.add("online");
            ignorableMonitorFieldNames.add("op");
            ignorableMonitorFieldNames.add("pcb");
            ignorableMonitorFieldNames.add("pdo");
            ignorableMonitorFieldNames.add("satellites");
            ignorableMonitorFieldNames.add("speed");
            ignorableMonitorFieldNames.add("speedometer");
            ignorableMonitorFieldNames.add("staffId");
            ignorableMonitorFieldNames.add("staffName");
            ignorableMonitorFieldNames.add("staffPhone");
            ignorableMonitorFieldNames.add("staffPhotoUrl");

//            if (!contractSettings.getObjectStatusView())
//                ignorableMonitorFieldNames.add("movement");
//            if (!contractSettings.getIgnitionSensorView())
//                ignorableMonitorFieldNames.add("engineOn");
//            if (!contractSettings.getObjectLinkView())
//                ignorableMonitorFieldNames.add("online");
//            if (!contractSettings.getSatelliteVisibilityView())
//                ignorableMonitorFieldNames.add("satellites");
//            if (!contractSettings.getSensorStateView())
//                ignorableMonitorFieldNames.add("dat");
//            if (!contractSettings.getObjectDriverView()) {
//                ignorableMonitorFieldNames.add("staffName");
//                ignorableMonitorFieldNames.add("staffPhotoUrl");
//                ignorableMonitorFieldNames.add("staffPhone");
//            }

        }

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("MObjectTrackDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableMObjectTrackFieldNames));
            filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.monitoringPopupIgnoredFieldNames(contractSettings)));
//            filterProvider.addFilter("PopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorablePopupFieldNames));
            filterProvider.addFilter("MonitorDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableMonitorFieldNames));

            ObjectWriter objectWriter = jsonMapper.writer(filterProvider).withRootName("data");

            byte[] data = objectWriter.writeValueAsBytes(mObjectTrackDataJSONList);
            response.setContentType("application/json");
            response.setContentLength(data.length);
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Get trip list view
     *
     * @return ModelAndView
     */
    @RequestMapping(value = AJAX_URL_TRIP_LIST)
    private void getTripListView(HttpServletResponse response, HttpSession session,
                                 HttpServletRequest request,
                                 @RequestParam(value = "unchecked-routes-id", required = false) Long[] uncheckedRoutesId,
                                 @RequestParam(value = "selected-trip-id", required = false, defaultValue = "0") Long selectedTripId) {

        Map<String, Object> mapModels = getTripMapModels(session);
        mapModels = setUncheckedRoutesMap(mapModels, uncheckedRoutesId);
        mapModels.put("selectedTripId", selectedTripId);
        List<TripRoute> tripRouteList = (List<TripRoute>) mapModels.get("tripRouteList");

        try {
            // Get rendered html from view
            View resolvedView = htmlViewResolver.resolveViewName(AJAX_VIEW_TRIP_LIST, response.getLocale());
            MockHttpServletResponse mockResp = new MockHttpServletResponse();
            mockResp.setCharacterEncoding("UTF-8");
            resolvedView.render(mapModels, request, mockResp);

            // Make json response
            ResponseTripRouteList responseTripRouteList = new ResponseTripRouteList(tripRouteList);
            responseTripRouteList.setHtml(mockResp.getContentAsString().trim());

            Set<String> ignorableFieldNames = new HashSet<>();
            ignorableFieldNames.add("fstList");


            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseRouteListFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFieldNames));

            ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseTripRouteList);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Remove selected trip from service
     *
     * @param tpId - Trip id
     * @return ModelAndView
     */
    @RequestMapping(value = AJAX_URL_TRIP_REMOVE)
    private String ajaxTripRemove(@RequestParam(value = "trip-id", required = false) String tpId) {

        if (logger.isDebugEnabled()) {
            logger.debug("ajaxTripRemove tripId:{}", tpId);
        }

        // Remove trip from active trip list
        return String.valueOf(finishTrip(strToLong(tpId, null)));
    }

    /**
     * Get Dispatcher view for selected trip
     *
     * @param tpId - Trip id
     * @return ModelAndView
     */
    @RequestMapping(value = AJAX_URL_SINGLE_TRIP_CONTROL)
    private ModelAndView getTripDispatcherView(HttpSession session, @RequestParam(value = "trip-id", required = false) String tpId) {
        ModelAndView modelAndView = new ModelAndView(AJAX_VIEW_SINGLE_TRIP_CONTROL);

        Long tripId = strToLong(tpId, null);

        if (tripId != null) {
            Trip trip = getTripById(tripId, session);

            if (trip != null && trip.getTripRoute() != null) {
                TripRoute tripRoute = trip.getTripRoute();
                List<TripRouteStation> tripRouteStationList = tripRoute.getTripRouteStationList();

                // Get Mobject for necessity of its name
//                MobjectBig mobjectBig = coreMain.getMobjectById(trip.getMobjectId());
//                if (mobjectBig != null) {
//                    trip.setMobjectName(mobjectBig.getName());
//                }

                modelAndView.addObject("trip", trip);
//                modelAndView.addObject("tripRoute", tripRoute);
                modelAndView.addObject("tripRouteStationList", tripRouteStationList);

            }
        }

        return modelAndView;
    }

    /**
     * Get all trips' current progress
     *
     * @param session
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = AJAX_URL_TRIPS_PROGRESS, method = RequestMethod.GET)
    public void getAllTripsProgress(HttpSession session,
                                    HttpServletResponse response)
            throws ServletException, IOException {
        // Get  accessed Trip list
        List<Trip> accessedTripList = getAccessedTripList(session);
        List<TripJSON> tripList = new ArrayList<>();

        if (accessedTripList != null) {
            for (Trip trip : accessedTripList) {
                tripList.add(new TripJSON(trip));
            }
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(tripList);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Get Trip list models
     *
     * @return Map<String, Object>
     */
    private Map<String, Object> getTripMapModels(HttpSession session) {
        Map<String, Object> mapModels = new HashMap<>();

        // Get  accessed Trip list
        List<Trip> accessedTripList = getAccessedTripList(session);

        if (accessedTripList != null) {
            List<TripRoute> tripRouteList = new ArrayList<>();
            Map<Long, List<Trip>> tripListMap = new TreeMap<>();

            // Collect TripRoute list and Group Trip by Route
            for (Trip trip : accessedTripList) {
                if (trip.getTripRoute() == null) {
                    continue;
                }
                // Get Mobject for necessity of its name
                MobjectBig mobjectBig = coreMain.getMobjectById(trip.getMobjectId());
                if (mobjectBig != null) {
                    trip.setMobjectName(mobjectBig.getName());
                }

                List<Trip> tripTreeSet = null;

                if (tripListMap.containsKey(trip.getRouteId())) {

                    tripTreeSet = tripListMap.get(trip.getRouteId());
                } else {
                    tripRouteList.add(trip.getTripRoute());
                }

                if (tripTreeSet == null) {
//                    tripTreeSet = new ArrayList<>(new Comparator<Trip>() {
//                        // Sort Trip by Mobject name
//                        @Override
//                        public int compare(Trip o1, Trip o2) {
//                            if (o1 == null) return 1;
//                            if (o1.getMobjectName() == null) return 1;
//                            if (o2 == null) return -1;
//                            if (o2.getMobjectName() == null) return -1;
//                            return o1.getMobjectName().compareTo(o2.getMobjectName());
//                        }
//                    });
                    tripTreeSet = new ArrayList<>();
                    tripListMap.put(trip.getRouteId(), tripTreeSet);
                }

                tripTreeSet.add(trip);
                Collections.sort(tripTreeSet, new Comparator<Trip>() {
                    // Sort Trip by Mobject name
                    @Override
                    public int compare(Trip o1, Trip o2) {
                        if (o1 == null) return 1;
                        if (o1.getMobjectName() == null) return 1;
                        if (o2 == null) return -1;
                        if (o2.getMobjectName() == null) return -1;
                        return o1.getMobjectName().compareTo(o2.getMobjectName());
                    }
                });
            }

            mapModels.put("tripRouteList", tripRouteList);
            mapModels.put("tripListMap", tripListMap);
        }

        return mapModels;
    }

    private Map<String, Object> setUncheckedRoutesMap(Map<String, Object> mapModels, Long[] uncheckedRoutesId) {
        Map<Long, String> uncheckedRoutes = new HashMap<>();
        for (Long uncheckedRouteId : uncheckedRoutesId) {
            uncheckedRoutes.put(uncheckedRouteId, "unchecked");
        }
        mapModels.put("uncheckedRoutes", uncheckedRoutes);

        return mapModels;
    }

    /**
     * Get available trip list which are allowed to dispatch for current user
     *
     * @return List<Trip>
     */
    private List<Trip> getAccessedTripList(HttpSession session) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            TripRunnerService tripRunnerService = tripRoutingControl.getTripRunnerService();
            CoreStaffAccess coreStaffAccess = tripRoutingControl.getCoreStaffAccess();
            List<Trip> tripList = new ArrayList<>();
            // Check an access
            if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_CUSTOMER_ADMIN_STR)
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")) {
                tripList = tripRunnerService.getByContract(MainController.getUserContractId(session));
            } else {
                // Get accessed route list
                List<StaffAccess> staffAccessList = coreStaffAccess.getListByStaff(MainController.getInterfaceUserId(), StaffAccess.HAS_ACCESS);

                if (staffAccessList != null) {
                    tripList = new ArrayList<>();

                    // Make trip list by route
                    if (tripRunnerService != null) {
                        for (StaffAccess staffAccess : staffAccessList) {
                            List<Trip> trips = tripRunnerService.getByRoute(staffAccess.getRouteId());
                            if (trips != null) {
                                tripList.addAll(trips);
                            }
                        }
                    }
                }
            }

            // Sort trip by reg date
            if (tripList != null) {
                Collections.sort(tripList, new Comparator<Trip>() {
                    @Override
                    public int compare(Trip o1, Trip o2) {
                        if (o1 == null || o2 == null)
                            return -1;
                        if (o1.getRegDate() == null || o2.getRegDate() == null)
                            return -1;
                        if (o2.getRegDate().getTime() > o1.getRegDate().getTime()) {
                            return 1;
                        } else if (o2.getRegDate().getTime() < o1.getRegDate().getTime()) {
                            return -1;
                        } else {
                            return 0;
                        }
                    }
                });
            }

            return tripList;
        }

        return null;
    }

    /**
     * Get single Trip by id
     *
     * @param tripId
     * @return Trip
     */
    private Trip getTripById(Long tripId, HttpSession session) {
        if (tripId == null) {
            return null;
        }

        // Get accessed Trip list
        List<Trip> accessedTripList = getAccessedTripList(session);

        if (accessedTripList != null) {
            for (Trip trip : accessedTripList) {
                if (trip != null
                        && trip.getId() != null
                        && trip.getId().equals(tripId)) {
                    return trip;
                }
            }
        }

        return null;
    }

    /**
     * Finish selected trip
     *
     * @return int if returns zero then successfully completed
     */
    private int finishTrip(Long tripId) {
        if (tripId == null) {
            return Errors.ERR_OBJECT_IS_NULL;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            TripRunnerService tripRunnerService = tripRoutingControl.getTripRunnerService();

            return tripRunnerService.tripFinish(tripId);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }
}
