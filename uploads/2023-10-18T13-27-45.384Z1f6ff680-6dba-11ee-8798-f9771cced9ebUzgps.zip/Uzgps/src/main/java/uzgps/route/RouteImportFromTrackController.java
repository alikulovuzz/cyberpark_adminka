package uzgps.route;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GPSTrackPointList;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminService;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.map.kml.KMLObjectTrack;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.CustomDistancesForTracking;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;

/**
 * Created by G'ayrat on 05.05.15.
 */
@Controller
public class RouteImportFromTrackController extends AbstractRoutingController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTE_IMPORT_FROM_TRACK = "/route/import-from-track.htm";
    private final static String VIEW_ROUTE_IMPORT_FROM_TRACK = "route/import-from-track";

    private final static String URL_AJAX_MOBJECT_TRACKS_KML = "/route/mobject-tracks-kml.htm";

    @Autowired
    AdminService adminService;

    /**
     * Get map type
     *
     * @return Integer
     */
    @ModelAttribute("mapType")
    private Integer getMapType(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        return contractSettings.getMapType().intValue();
    }

    @Override
    protected String getActiveRouteTabMenu() {
        return "importFromTrack";
    }

    @RequestMapping(value = URL_ROUTE_IMPORT_FROM_TRACK)
    public ModelAndView importFromTrackMain(HttpSession session) throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_IMPORT_FROM_TRACK);

        List<MobjectBig> mObjectList = getMobjectList(session);

        // Sort list of objects
        if (mObjectList != null && mObjectList.size() > 0) {
            Collections.sort(mObjectList);
            modelAndView.addObject("mObjectList", mObjectList);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_AJAX_MOBJECT_TRACKS_KML, method = RequestMethod.GET)
    @ResponseBody
    public KMLObjectTrack getMovableObjectTracksById(@RequestParam(value = "object-id", required = false) Long mObjectId,
                                                     @RequestParam(value = "start-date", required = false) String startDate,
                                                     @RequestParam(value = "end-date", required = false) String endDate,
                                                     @RequestParam(value = "epsilon", required = false) Integer epsilon,
                                                     @RequestParam(value = "color", required = false, defaultValue = "#ff0000") String color,
                                                     @RequestParam(value = "line-width", required = false, defaultValue = "3") Integer lineWidth,
                                                     @RequestParam(value = "track-view-type", defaultValue = "1") String trackViewTypeStr) {

        if (logger.isDebugEnabled()) {
            logger.debug("Build tracks for parameters: object-id={}, start-date={}, end-date={}, epsilon={}",
                    mObjectId, startDate, endDate, epsilon);
        }

        /* ----- TRACK DRAWING ------ */
        KMLObjectTrack kmlObjectTrack = null;

        if (mObjectId != null) {
            int trackViewType = Converters.strToInt(trackViewTypeStr, 1);

            GPSTrackPointList gpsTrackPointList = getGpsTrackPointList(mObjectId, 0, startDate, endDate);

            // Clear NULL and ZERO coordinates - Delete ZERO points
            coreMain.deleteZeroPoints(gpsTrackPointList);

            MobjectBig mobject = coreMain.getMobjectById(mObjectId);

            if (gpsTrackPointList != null) {
                if (logger.isDebugEnabled()) {
                    logger.debug("GPSTrackPoint count before DouglasPeuckerReducer: {}",
                            gpsTrackPointList.getGpsTrackPoints().size());
                }

                // Clear NULL and ZERO coordinates - Delete ZERO points
                coreMain.deleteZeroPoints(gpsTrackPointList);
                List<GPSTrackPoint> gpsTrackPoints = gpsTrackPointList.getGpsTrackPoints();
                List<GPSTrackPoint> reducedGpsTrackPoints = DouglasPeuckerReducer.reduceWithTolerance(gpsTrackPointList.getGpsTrackPoints(), epsilon);
                gpsTrackPointList.setGpsTrackPoints(reducedGpsTrackPoints);

                if (logger.isDebugEnabled()) {
                    logger.debug("GPSTrackPoint count after DouglasPeuckerReducer: {}",
                            gpsTrackPointList.getGpsTrackPoints().size());
                }

                Timestamp startDateT = null;
                Timestamp endDateT = null;
                if (!startDate.equalsIgnoreCase("")) {
                    startDate = startDate.trim();
                    startDateT = Converters.dateFormatterTimestamp(startDate);
                }

                if (!endDate.equalsIgnoreCase("")) {
                    endDate = endDate.trim();
                    endDateT = Converters.dateFormatterTimestamp(endDate);
                }

                List<CustomDistancesForTracking> distancesList = adminService.getDistanceByObjectAndPeriod(mObjectId, startDateT, endDateT);

                kmlObjectTrack = new KMLObjectTrack(mobject, gpsTrackPointList, null, "solid",
                        color, lineWidth, reducedGpsTrackPoints.size(), distancesList, UZGPS_CONST.TRACK_VIEW_TYPE.BY_DAY.getValue(), null);

            }
        }

        return kmlObjectTrack;
    }

    /**
     * Get list of gps track point from DB for given period of time
     *
     * @param mObjectId
     * @param pointCount
     * @param startDate
     * @param endDate
     * @return
     */
    private GPSTrackPointList getGpsTrackPointList(Long mObjectId, Integer pointCount, String startDate, String endDate) {
        GPSTrackPointList gpsTrackPointList = null;
        if (pointCount == -1) {
            gpsTrackPointList = coreMain.getPointsFilteredByDate(mObjectId, startDate, endDate);
        } else {
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss.SSS");
            SimpleDateFormat dateFormat2 = new SimpleDateFormat("dd.MM.yyyy HH:mm");
            Date fromDate;
            Date toDate;
            try {
                fromDate = dateFormat1.parse(startDate);
                toDate = dateFormat1.parse(endDate);
            } catch (ParseException e) {
                fromDate = null;
                toDate = null;
            }

            if (fromDate == null && toDate == null) {
                try {
                    fromDate = dateFormat2.parse(startDate);
                    toDate = dateFormat2.parse(endDate);
                } catch (ParseException e) {
                    fromDate = null;
                    toDate = null;
                }
            }

            if (fromDate != null && toDate != null) {
                gpsTrackPointList = coreMain.getPointsByDate(mObjectId, new Timestamp(fromDate.getTime()).getTime(), new Timestamp(toDate.getTime()).getTime(), pointCount);
            }
        }

        return gpsTrackPointList;
    }

}
