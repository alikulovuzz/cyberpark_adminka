package uzgps.route;

import com.fasterxml.jackson.databind.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.*;
import uz.netex.routing.database.tables.*;
import uz.netex.uzgps.errors.Errors;
import uzgps.main.MainController;
import uzgps.route.json.models.RouteStationJSON;
import uzgps.route.json.response.ResponseRouteEdit;
import uzgps.route.json.response.ResponseTimeEvent;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by G'ayrat on 05.05.15.
 */
@Controller
public class RouteTimeEventController extends AbstractRoutingController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTE_TIME_EVENT = "/route/time-event.htm";
    private final static String URL_ROUTE_TIME_EVENT_FAST_LINK = "/route/time-event-form.htm";
    private final static String VIEW_ROUTE_TIME_EVENT = "route/time-event";

    private final static String URL_AJAX_TIME_EVENT_LIST = "/route/ajax-time-event-list.htm";
    private final static String VIEW_AJAX_TIME_EVENT_LIST = "route/ajax-time-event-list";

    private final static String URL_AJAX_TIME_EVENT_CONTENT = "/route/ajax-time-event-content.htm";
    private final static String VIEW_AJAX_TIME_EVENT_CONTENT = "route/ajax-time-event-content";
    private final static String VIEW_AJAX_TIME_EVENT = "route/ajax-time-event";
    private final static String VIEW_AJAX_EVENT_EMPTY = "route/ajax-event-empty";
    private final static String VIEW_AJAX_ROUTE_EVENT = "route/ajax-route-event";
    private final static String VIEW_AJAX_ROUTE_STATION_EVENT = "route/ajax-route-station-event";

    private final static String URL_AJAX_TIME_EVENT_CONTENT_SAVE = "/route/ajax-time-event-content-save.htm";
    private final static String URL_AJAX_ROUTE_EVENT_SAVE = "/route/ajax-route-event-save.htm";
    private final static String URL_AJAX_ROUTE_STATION_EVENT_SAVE = "/route/ajax-route-station-event-save.htm";

//    @Autowired
//    InternalResourceViewResolver htmlViewResolver;

    @Override
    protected String getActiveRouteTabMenu() {
        return "timeEvent";
    }

    /**
     * Get Route, Station, RouteStation models, and time-event-left.jsp, time-event-content.jsp view inside layout
     *
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_TIME_EVENT)
    private ModelAndView timeEventMain(HttpSession session,
                                       @RequestParam(value = "route-id", required = false) String rtId,
                                       @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber,
                                       @RequestParam(value = "search", required = false, defaultValue = "") String searchText)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_TIME_EVENT);
        putRouteStationModelToView(session, modelAndView, pageNumber, searchText, URL_AJAX_TIME_EVENT_LIST);

        Long routeId = strToLong(rtId, null);
        if (routeId == null) {
            fillTimeEventContent(session, modelAndView);
        } else {
            Map<String, Object> mapModels = getTimeEventMapModel(session, routeId, null);
            modelAndView.addAllObjects(mapModels);
            modelAndView.addObject("routeId", routeId);
        }

        // Make json response
        ResponseTimeEvent responseTimeEvent = new ResponseTimeEvent();
        responseTimeEvent.setRouteStationJSONList((List<RouteStation>) modelAndView.getModel().get("routeStationList"));

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            modelAndView.addObject("routeStationListJson", writer.writeValueAsString(responseTimeEvent));
        } catch (Exception e) {
            logger.error("Error: ", e);
        }

        return modelAndView;
    }

    /**
     * Get Route, Station, RouteStation models, and time-event-left.jsp, time-event-content.jsp view inside layout
     *
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_TIME_EVENT_FAST_LINK)
    private ModelAndView timeEventMainFastLink(HttpSession session,
                                               @RequestParam(value = "route-id", required = false) String rtId,
                                               @RequestParam(value = "show-route", required = false) String showRouteStr,
                                               @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber,
                                               @RequestParam(value = "search", required = false, defaultValue = "") String searchText)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_TIME_EVENT);

        Long routeId = strToLong(rtId, null);

        Route route = new Route();
        // Get selected route
        if (routeId != null && routeId > 0) {
            putRouteStationModelToViewSingle(session, routeId, modelAndView, searchText, URL_AJAX_TIME_EVENT_LIST);
        }

        if (routeId == null) {
            fillTimeEventContent(session, modelAndView);
        } else {
            Map<String, Object> mapModels = getTimeEventMapModel(session, routeId, null);
            modelAndView.addAllObjects(mapModels);
            modelAndView.addObject("routeId", routeId);
            modelAndView.addObject("showRoute", showRouteStr);
        }

        // Make json response
        ResponseTimeEvent responseTimeEvent = new ResponseTimeEvent();
        responseTimeEvent.setRouteStationJSONList((List<RouteStation>) modelAndView.getModel().get("routeStationList"));

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            modelAndView.addObject("routeStationListJson", writer.writeValueAsString(responseTimeEvent));
        } catch (Exception e) {
            logger.error("Error: ", e);
        }

        return modelAndView;
    }

    /**
     * Get Route, Station, RouteStation models, and ajax-time-event-list.jsp clean view without layout
     *
     * @param pageNumber
     * @param searchText
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_AJAX_TIME_EVENT_LIST)
    private void ajaxRouteList(HttpSession session,
                               HttpServletResponse response,
                               HttpServletRequest request,
                               @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber,
                               @RequestParam(value = "search", required = false, defaultValue = "") String searchText)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_TIME_EVENT_LIST);
        putRouteStationModelToView(session, modelAndView, pageNumber, searchText, URL_AJAX_TIME_EVENT_LIST);
        fillTimeEventContent(session, modelAndView);

        Map<String, Object> mapModels = modelAndView.getModel();

        try {
            // Get rendered html from view
            View resolvedView = htmlViewResolver.resolveViewName(modelAndView.getViewName(), response.getLocale());
            MockHttpServletResponse mockResp = new MockHttpServletResponse();
            mockResp.setCharacterEncoding("UTF-8");
            resolvedView.render(mapModels, request, mockResp);

            // Make json response
            ResponseRouteEdit responseRouteEdit = new ResponseRouteEdit();
            responseRouteEdit.setRoute((Route) mapModels.get("route"));
            responseRouteEdit.setHtml(mockResp.getContentAsString().trim());

            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseRouteEdit);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Get time event content's models: RouteStation, RouteStationEvent and ajax-time-event-content.jsp clean view without layout in JSON
     *
     * @param response
     * @param request
     * @param rtId      - route id
     * @param rsId      - route station id
     * @param eventType - event type for view name
     */
    @RequestMapping(value = URL_AJAX_TIME_EVENT_CONTENT)
    private void ajaxTimeEventContent(HttpSession session,
                                      HttpServletResponse response,
                                      HttpServletRequest request,
                                      @RequestParam(value = "route-id", required = false) String rtId,
                                      @RequestParam(value = "rs-id", required = false) String rsId,
                                      @RequestParam(value = "event-type", required = false) String eventType) {
        Long routeId = strToLong(rtId, null);
        Long routeStationId = strToLong(rsId, null);

        String viewName = VIEW_AJAX_TIME_EVENT_CONTENT;
        if (routeId == null && routeStationId != null) {
            // View name for route station event
            viewName = VIEW_AJAX_ROUTE_STATION_EVENT;
        }

        if (eventType != null) {
            // View name for empty view
            viewName = VIEW_AJAX_EVENT_EMPTY;

            if (eventType.equalsIgnoreCase("routeStation")) {
                // View name for route station event
                viewName = VIEW_AJAX_ROUTE_STATION_EVENT;
            } else if (eventType.equalsIgnoreCase("route")) {
                // View name for route event
                viewName = VIEW_AJAX_ROUTE_EVENT;
            } else if (eventType.equalsIgnoreCase("timeEvent")) {
                // View name for time event
                viewName = VIEW_AJAX_TIME_EVENT;
            }
        }

        Map<String, Object> mapModels = getTimeEventMapModel(session, routeId, routeStationId);
        Map<String, Object> flashMap = (Map<String, Object>) RequestContextUtils.getInputFlashMap(request);
        if (flashMap != null) {
            mapModels.putAll(flashMap);
        }
        mapModels.put("routeId", routeId);
        mapModels.put("routeStationId", routeStationId);
        mapModels.put("userAccessList", getUserAccessList(session));

        try {
            // Get rendered html from view
            View resolvedView = htmlViewResolver.resolveViewName(viewName, response.getLocale());
            MockHttpServletResponse mockResp = new MockHttpServletResponse();
            mockResp.setCharacterEncoding("UTF-8");
            resolvedView.render(mapModels, request, mockResp);

            // Make json response
            ResponseTimeEvent responseTimeEvent = new ResponseTimeEvent();
            responseTimeEvent.setRouteStationJSONList((List<RouteStation>) mapModels.get("routeStationList"));
            responseTimeEvent.setHtml(mockResp.getContentAsString().trim());

            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseTimeEvent);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error: ", e);
        }
    }
    /*@RequestMapping(value = URL_AJAX_TIME_EVENT_CONTENT)
    private void ajaxTimeEventContent(HttpServletResponse response,
                                      HttpServletRequest request,
                                      @RequestParam(value = "route-id", required = false) String rtId,
                                      @RequestParam(value = "rs-id", required = false) String rsId,
                                      @RequestParam(value = "event-type", required = false) String eventType) {
        Long routeId = strToLong(rtId, null);
        Long routeStationId = strToLong(rsId, null);

        String viewName = VIEW_AJAX_TIME_EVENT_CONTENT;
        if (routeId == null && routeStationId != null) {
            // View name for route station event
            viewName = VIEW_AJAX_ROUTE_STATION_EVENT;
        }

        Map<String, Object> mapModels = getTimeEventMapModel(routeId, routeStationId);
        Map<String, Object> flashMap = (Map<String, Object>) RequestContextUtils.getInputFlashMap(request);
        if (flashMap != null) {
            mapModels.putAll(flashMap);
        }

        try {
            // Get rendered html from view
            View resolvedView = htmlViewResolver.resolveViewName(viewName, response.getLocale());
            MockHttpServletResponse mockResp = new MockHttpServletResponse();
            mockResp.setCharacterEncoding("UTF-8");
            resolvedView.render(mapModels, request, mockResp);

            // Make json response
            ResponseTimeEvent responseTimeEvent = new ResponseTimeEvent();
            responseTimeEvent.setRouteStationJSONList((List<RouteStation>) mapModels.get("routeStationList"));
            responseTimeEvent.setHtml(mockResp.getContentAsString().trim());

            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseTimeEvent);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error: ", e);
        }
    }*/

    /**
     * Save time event content values
     *
     * @return String
     */
    @RequestMapping(value = URL_AJAX_TIME_EVENT_CONTENT_SAVE)
    private String ajaxTimeEventContentSave(HttpSession session,
                                            @RequestParam(value = "route-id", required = false) String rtId,
                                            @RequestParam(value = "rs-list", required = false) String rsList,
                                            RedirectAttributes redirectAttributes) {

        if (logger.isDebugEnabled()) {
            logger.debug("ajaxTimeEventContentSave rsList: {}", rsList);
        }

        RouteStationJSON[] routeStationJSONs = null;
        if (rsList != null && rsList.length() > 0) {
            // Convert JSON string to Object
            try {
                routeStationJSONs = jsonMapper.readValue(rsList, RouteStationJSON[].class);
            } catch (Exception e) {
                routeStationJSONs = null;
            }

            if (routeStationJSONs != null) {
                Integer errCode = Errors.ERR_SUCCESS;

                // Update route stations
                for (int i = 0; i < routeStationJSONs.length; i++) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("rsList: {}", routeStationJSONs[i]);
                    }
                    RouteStationJSON routeStationJSON = routeStationJSONs[i];
                    RouteStation routeStation = getRouteStation(session, routeStationJSON.getId());
                    routeStation.setTimeEnter(routeStationJSON.getTimeEnter());
                    routeStation.setTimeExit(routeStationJSON.getTimeExit());
                    routeStation.setTimeParking(routeStationJSON.getTimeParking());
                    routeStation.setTimeTravel(routeStationJSON.getTimeTravel());
                    routeStation.setTimeDeviation(routeStationJSON.getTimeDeviation());
                    Integer error = routeStationEdit(routeStation);
                    if (error != Errors.ERR_SUCCESS) {
                        errCode = error;
                    }
                }

                redirectAttributes.addFlashAttribute("errCode", errCode);
            }
        }

        Long routeId = strToLong(rtId, null);
        redirectAttributes.addAttribute("route-id", routeId);
        redirectAttributes.addAttribute("event-type", "timeEvent");

        return "redirect:" + URL_AJAX_TIME_EVENT_CONTENT;
    }
    /*private String ajaxTimeEventContentSave(@RequestParam(value = "route-id", required = false) String rtId,
                                            @RequestParam(value = "r-route-end-type", required = false) String routeEndType,
                                            @RequestParam(value = "cb-route-missing-more", required = false, defaultValue = "0") String useEventParking,
                                            @RequestParam(value = "e-route-missing-more-value", required = false) String useEventParkingValue,
                                            @RequestParam(value = "cb-drive-outside-route", required = false, defaultValue = "0") String useOutPath,
                                            @RequestParam(value = "cb-return-route", required = false, defaultValue = "0") String useInPath,
                                            @RequestParam(value = "rs-list", required = false) String rsList,
                                            RedirectAttributes redirectAttributes) {

        if (logger.isDebugEnabled()) {
            logger.debug("ajaxTimeEventContentSave rsList: {}", rsList);
        }

        RouteStationJSON[] routeStationJSONs = null;
        if (rsList != null && rsList.length() > 0) {
            // Convert JSON string to Object
            try {
                routeStationJSONs = jsonMapper.readValue(rsList, RouteStationJSON[].class);
            } catch (Exception e) {
                routeStationJSONs = null;
            }


            if (routeStationJSONs != null) {
                // Update route stations
                for (int i = 0; i < routeStationJSONs.length; i++) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("rsList: {}", routeStationJSONs[i]);
                    }
                    RouteStationJSON routeStationJSON = routeStationJSONs[i];
                    RouteStation routeStation = getRouteStation(routeStationJSON.getId());
                    routeStation.setTimeEnter(routeStationJSON.getTimeEnter());
                    routeStation.setTimeExit(routeStationJSON.getTimeExit());
                    routeStation.setTimeParking(routeStationJSON.getTimeParking());
                    routeStation.setTimeTravel(routeStationJSON.getTimeTravel());
                    routeStationEdit(routeStation);
                }
            }

        }

        Long routeId = strToLong(rtId, null);
        Route route = getRoute(routeId);
        if (route != null) {
            route.setEndType(strToInt(routeEndType, route.getEndType()));
        }
        // Update route
        Integer errCode = routeEdit(route);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("rtErrCode", errCode);
        }

        // Update route events
        errCode = routeEventEdit(routeId, Event.EVENT_STATION_OUT_PARKING_TIME_EXEED, strToInt(useEventParking, 0), useEventParkingValue);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("reErrParking", errCode);
        }

        errCode = routeEventEdit(routeId, Event.EVENT_ROUTE_OUT_OF_PATH, strToInt(useOutPath, 0), null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("reErrOutPath", errCode);
        }

        errCode = routeEventEdit(routeId, Event.EVENT_ROUTE_BACK_TO_PATH, strToInt(useInPath, 0), null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("reErrInPath", errCode);
        }

        redirectAttributes.addAttribute("route-id", routeId);

        return "redirect:" + URL_AJAX_TIME_EVENT_CONTENT;
    }*/

    /**
     * Save route event values
     *
     * @return String
     */
    @RequestMapping(value = URL_AJAX_ROUTE_EVENT_SAVE)
    private String ajaxRouteEventSave(HttpSession session,
                                      @RequestParam(value = "route-id", required = false) String rtId,
                                      @RequestParam(value = "r-route-end-type", required = false) String routeEndType,
                                      @RequestParam(value = "cb-route-missing-more", required = false, defaultValue = "0") String useEventParking,
                                      @RequestParam(value = "e-route-missing-more-value", required = false) String useEventParkingValue,
                                      @RequestParam(value = "cb-drive-outside-route", required = false, defaultValue = "0") String useOutPath,
                                      @RequestParam(value = "cb-return-route", required = false, defaultValue = "0") String useInPath,
                                      @RequestParam(value = "route-time-show-trip", required = false, defaultValue = "0") String timeShowTripStr,
                                      @RequestParam(value = "route-time-hide-trip", required = false, defaultValue = "0") String timeHideTripStr,
                                      RedirectAttributes redirectAttributes) {

        Long routeId = strToLong(rtId, null);

        Integer timeShowTrip = strToInt(timeShowTripStr, 0);
        timeShowTrip = (timeShowTrip > 1440) ? 1440 : timeShowTrip; // Max must be 1440
        timeShowTrip = (timeShowTrip < 0) ? 0 : timeShowTrip; // Min must be 0
        Integer timeHideTrip = strToInt(timeHideTripStr, 0);
        timeHideTrip = (timeHideTrip > 1440) ? 1440 : timeHideTrip; // Max must be 1440
        timeHideTrip = (timeHideTrip < 0) ? 0 : timeHideTrip; // Min must be 0

        Route route = getRoute(session, routeId);
        if (route != null) {
            route.setEndType(strToInt(routeEndType, route.getEndType()));
            route.setTimeShowTrip(timeShowTrip);
            route.setTimeHideTrip(timeHideTrip);
        }
        // Update route
        Integer errCode = routeEdit(session, route);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("rtErrCode", errCode);
        }

        // Update route events
        errCode = routeEventEdit(session, routeId, Event.EVENT_STATION_OUT_PARKING_TIME_EXEED, strToInt(useEventParking, 0),
                useEventParkingValue);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("reErrParking", errCode);
        }

        errCode = routeEventEdit(session, routeId, Event.EVENT_ROUTE_OUT_OF_PATH, strToInt(useOutPath, 0), null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("reErrOutPath", errCode);
        }

        errCode = routeEventEdit(session, routeId, Event.EVENT_ROUTE_BACK_TO_PATH, strToInt(useInPath, 0), null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("reErrInPath", errCode);
        }

        if (errCode == Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("errCode", errCode);
        }

        redirectAttributes.addAttribute("route-id", routeId);
        redirectAttributes.addAttribute("event-type", "route");

        return "redirect:" + URL_AJAX_TIME_EVENT_CONTENT;
    }

    /**
     * Save route station event values
     *
     * @return String
     */
    @RequestMapping(value = URL_AJAX_ROUTE_STATION_EVENT_SAVE)
    private String ajaxRouteStationEventSave(HttpSession session,
                                             @RequestParam(value = "rs-id", required = false) String rsId,
                                             @RequestParam(value = "cb-station-event-enter", required = false, defaultValue = "0") String useEventEnter,
                                             @RequestParam(value = "cb-station-event-exit", required = false, defaultValue = "0") String useEventExit,
                                             @RequestParam(value = "cb-station-event-parking", required = false, defaultValue = "0") String useEventParking,
                                             @RequestParam(value = "e-station-stopped-time-value", required = false, defaultValue = "0") String useEventParkingValue,
                                             @RequestParam(value = "cb-station-event-deviation", required = false, defaultValue = "0") String useEventDeviation,
                                             @RequestParam(value = "cb-station-event-skip", required = false, defaultValue = "0") String useEventSkip,
                                             RedirectAttributes redirectAttributes) {

        Integer errCode = routeStationEventEdit(session, strToLong(rsId, null), Event.EVENT_STATION_ENTER, strToInt(useEventEnter, 0),
                null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("rseErrEnter", errCode);
        }

        errCode = routeStationEventEdit(session, strToLong(rsId, null), Event.EVENT_STATION_EXIT, strToInt(useEventExit, 0), null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("rseErrExit", errCode);
        }

        errCode = routeStationEventEdit(session, strToLong(rsId, null), Event.EVENT_STATION_IN_PARKING_TIME_EXEED, strToInt(useEventParking, 0), useEventParkingValue);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("rseErrParking", errCode);
        }

        errCode = routeStationEventEdit(session, strToLong(rsId, null), Event.EVENT_DEVIATION, strToInt(useEventDeviation, 0), null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("rseErrEnter", errCode);
        }

        errCode = routeStationEventEdit(session, strToLong(rsId, null), Event.EVENT_STATION_SKIPPED, strToInt(useEventSkip, 0), null);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("rseErrEnter", errCode);
        }

        if (errCode == Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("errCode", errCode);
        }

        redirectAttributes.addAttribute("rs-id", strToLong(rsId, null));
        redirectAttributes.addAttribute("event-type", "routeStation");

        return "redirect:" + URL_AJAX_TIME_EVENT_CONTENT;
    }
    /*private String ajaxRouteStationEventSave(@RequestParam(value = "rs-id", required = false) String rsId,
                                             @RequestParam(value = "event-id", required = false) String eventId,
                                             @RequestParam(value = "use-event", required = false, defaultValue = "0") String useEvent,
                                             @RequestParam(value = "value", required = false) String value,
                                             RedirectAttributes redirectAttributes) {

        Integer errCode = routeStationEventEdit(strToLong(rsId, null), strToInt(eventId, null), strToInt(useEvent, 0), value);
        if (errCode != Errors.ERR_SUCCESS) {
            redirectAttributes.addFlashAttribute("errRsEventCode", errCode);
        }
        redirectAttributes.addAttribute("rs-id", strToLong(rsId, null));

        return "redirect:" + URL_AJAX_TIME_EVENT_CONTENT;
    }*/

    /**
     * Fill time event content with models
     *
     * @param modelAndView
     */
    private void fillTimeEventContent(HttpSession session, ModelAndView modelAndView) {
        if (modelAndView == null)
            return;

        Long routeId = null;
        List<Route> routeList = (List<Route>) modelAndView.getModel().get("routeList");

        if (routeList != null && routeList.size() > 0) {
            Route route = routeList.get(0);
            // Get first route id
            routeId = route.getId();
        }

        Map<String, Object> mapModels = getTimeEventMapModel(session, routeId, null);
        modelAndView.addAllObjects(mapModels);
        modelAndView.addObject("routeId", routeId);
    }

//    private void fillTimeEventContent(ModelAndView modelAndView) {
//        if (modelAndView == null)
//            return;
//
//        Long routeId = null;
//        Long routeStationId = null;
//
//        List<Route> routeList = (List<Route>) modelAndView.getModel().get("routeList");
//        Map<Long, List<RouteStation>> routeStationMap = (Map<Long, List<RouteStation>>) modelAndView.getModelMap().get("routeStationMap");
//
//        if (routeList != null && routeList.size() > 0) {
//            Route route = routeList.get(0);
//            // Get first route id
//            routeId = route.getId();
//
//            if (routeStationMap != null) {
//                List<RouteStation> routeStationList = routeStationMap.get(route.getId());
//
//                if (routeStationList != null && routeStationList.size() > 0) {
//                    RouteStation routeStation = routeStationList.get(0);
//                    // Get first route station id
//                    routeStationId = routeStation.getId();
//                }
//            }
//        }
//
//        Map<String, Object> mapModels = getTimeEventMapModel(routeId, routeStationId);
//        modelAndView.addAllObjects(mapModels);
//    }

    /**
     * Update route station values
     *
     * @param routeStation
     * @return
     */
    private int routeStationEdit(RouteStation routeStation) {
        if (routeStation == null)
            return Errors.ERR_OBJECT_IS_NULL;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreRouteStation().save(routeStation);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Update route event values
     *
     * @param rtId
     * @param eventId
     * @param useEvent
     * @param value
     * @return
     */
    private int routeEventEdit(HttpSession session, Long rtId, Integer eventId, Integer useEvent, String value) {
        if (rtId == null && eventId == null)
            return Errors.ERR_OBJECT_IS_NULL;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            CoreRouteEvent coreRouteEvent = tripRoutingControl.getCoreRouteEvent();
            Route route = coreRoute.get(rtId);

            if (route != null) {
                // For security safety, check contract matching
                if (route.getContractId().equals(MainController.getUserContractId(session))) {
                    // Get route event by routeId and eventId
                    RouteEvent routeEvent = coreRouteEvent.getByRouteAndEvent(rtId, eventId);

                    if (routeEvent != null) {
                        routeEvent.setUseEvent(useEvent);
                        if (routeEvent.getEventId() == Event.EVENT_STATION_OUT_PARKING_TIME_EXEED) {
                            routeEvent.setValueLong1(TimeUnit.MINUTES.toMillis(strToLong(value, routeEvent.getValueLong1())));
                        }

                        // Update route event
                        return coreRouteEvent.save(routeEvent);
                    }
                } else {
                    return Errors.ERR_ROUTE_ACCESS;
                }
            }

            return Errors.ERR_OBJECT_IS_NULL;

        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Update route station event values
     *
     * @param rsId
     * @param eventId
     * @param useEvent
     * @param value
     * @return
     */
    private int routeStationEventEdit(HttpSession session, Long rsId, Integer eventId, Integer useEvent, String value) {
        if (rsId == null && eventId == null)
            return Errors.ERR_OBJECT_IS_NULL;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();
            CoreRouteStationEvent coreRouteStationEvent = tripRoutingControl.getCoreRouteStationEvent();
            RouteStation routeStation = coreRouteStation.get(rsId);

            if (routeStation != null) {
                Route route = coreRoute.get(routeStation.getRouteId());

                if (route != null) {
                    // For security safety, check contract matching
                    if (route.getContractId().equals(MainController.getUserContractId(session))) {
                        // Get route station event by routeStationId and eventId
                        RouteStationEvent routeStationEvent = coreRouteStationEvent.getByRouteStationAndEvent(rsId, eventId);

                        if (routeStationEvent != null) {
                            routeStationEvent.setUseEvent(useEvent);
                            if (routeStationEvent.getEventId() == Event.EVENT_STATION_IN_PARKING_TIME_EXEED) {
                                routeStationEvent.setValueLong1(TimeUnit.MINUTES.toMillis(strToLong(value, routeStationEvent.getValueLong1())));
                            }

                            // Update route station event
                            return coreRouteStationEvent.save(routeStationEvent);
                        }
                    } else {
                        return Errors.ERR_ROUTE_ACCESS;
                    }
                }
            }

            return Errors.ERR_OBJECT_IS_NULL;
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Get common map models related to time event content
     *
     * @param routeId
     * @param routeStationId
     * @return Map<String, Object>
     */
    private Map<String, Object> getTimeEventMapModel(HttpSession session, Long routeId, Long routeStationId) {

        if (routeId == null && routeStationId == null) {
            return new HashMap<>();
        }

        Map<String, Object> mapModels = new HashMap<>();

        // Get time events for a given route id from RoutStation
        mapModels.putAll(getRouteStationMapModel(session, routeId));

        if (routeId != null) {
            if (routeStationId != null) {
                // Get events for a given route station id from RouteStationEvent
                mapModels.putAll(getRouteStationEventMapModel(session, routeStationId));
                // Get station by routeStationId
                mapModels.put("station", getStationByRouteStationId(session, routeStationId));
            } else {
                // Get events for a given route id from RouteEvent
                mapModels.putAll(getRouteEventMapModel(session, routeId));
            }
        } else {
            // Get events for a given route station id from RouteStationEvent
            mapModels.putAll(getRouteStationEventMapModel(session, routeStationId));
            // Get station by routeStationId
            mapModels.put("station", getStationByRouteStationId(session, routeStationId));
        }

        return mapModels;
    }
    /*private Map<String, Object> getTimeEventMapModel(Long routeId, Long routeStationId) {

        if (routeId == null && routeStationId == null) {
            return new HashMap<>();
        }

        Map<String, Object> mapModels = new HashMap<>();
        // Get time events for a given route id from RoutStation
        mapModels.putAll(getRouteStationMapModel(routeId));

        if (routeId != null && routeStationId == null) {
            List<RouteStation> routeStationList = (List<RouteStation>) mapModels.get("routeStationList");
            if (routeStationList != null && routeStationList.size() > 0) {
                routeStationId = routeStationList.get(0).getId();
            }
        }

        // Get events for a given route id from RouteEvent
        mapModels.putAll(getRouteEventMapModel(routeId));
        // Get events for a given route station id from RouteStationEvent
        mapModels.putAll(getRouteStationEventMapModel(routeStationId));
        // Get station by routeStationId
        mapModels.put("station", getStationByRouteStationId(routeStationId));

        return mapModels;
    }*/

    /**
     * Get Route, Station, RouteStation model in List and hMap
     * Get route by "route" key, route station list by "routeStationList" key, stations by "stationMap" key
     *
     * @param routeId
     * @return Map<String, Object>
     */
    private Map<String, Object> getRouteStationMapModel(HttpSession session, Long routeId) {

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
        Map<String, Object> mapModels = new HashMap<>();

        if (tripRoutingControl != null) {
            CoreStation coreStation = tripRoutingControl.getCoreStation();
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();

            // Get route by id
            Route route = getRoute(session, routeId);

            if (route != null) {

                // Make station map by its id
                Map<Long, Station> stationMap = new HashMap<>();

                // Get route station list by route id
                List<RouteStation> routeStationList = coreRouteStation.getByRoute(route.getId());

                if (routeStationList != null) {

                    // Get stations by station id
                    for (RouteStation routeStation : routeStationList) {
                        if (routeStation.getStationId() != null) {
                            Station station = coreStation.get(routeStation.getStationId());

                            if (station != null && station.getId() != null) {
                                stationMap.put(station.getId(), station);
                            }
                        }
                    }

                }

                // After getting all models from core, put it in our map model
                mapModels.put("route", route);
                mapModels.put("routeStationList", routeStationList);
                mapModels.put("teStationMap", stationMap);

            }
        }

        return mapModels;
    }

    /**
     * Get RouteStationEvent models for a given route station
     *
     * @param rsId - route station id
     * @return Map<String, RouteStationEvent>
     */
    private Map<String, RouteStationEvent> getRouteStationEventMapModel(HttpSession session, Long rsId) {
        Map<String, RouteStationEvent> mapModels = new HashMap<>();

        if (rsId == null)
            return mapModels;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();
            CoreRouteStationEvent coreRouteStationEvent = tripRoutingControl.getCoreRouteStationEvent();
            RouteStation routeStation = coreRouteStation.get(rsId);

            if (routeStation != null) {
                Route route = getRoute(session, routeStation.getRouteId());

                if (route != null) {
                    mapModels.put("eventEnter", coreRouteStationEvent.getByRouteStationAndEvent(rsId, Event.EVENT_STATION_ENTER));
                    mapModels.put("eventExit", coreRouteStationEvent.getByRouteStationAndEvent(rsId, Event.EVENT_STATION_EXIT));
                    mapModels.put("eventParking", coreRouteStationEvent.getByRouteStationAndEvent(rsId, Event.EVENT_STATION_IN_PARKING_TIME_EXEED));
                    mapModels.put("eventDeviation", coreRouteStationEvent.getByRouteStationAndEvent(rsId, Event.EVENT_DEVIATION));
                    mapModels.put("eventSkip", coreRouteStationEvent.getByRouteStationAndEvent(rsId, Event.EVENT_STATION_SKIPPED));
                }
            }

        }

        return mapModels;
    }

    /**
     * Get RouteEvent models for a given route
     *
     * @param rtId - route id
     * @return Map<String, RouteEvent>
     */
    private Map<String, RouteEvent> getRouteEventMapModel(HttpSession session, Long rtId) {
        Map<String, RouteEvent> mapModels = new HashMap<>();

        if (rtId == null)
            return mapModels;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRouteEvent coreRouteEvent = tripRoutingControl.getCoreRouteEvent();
            Route route = getRoute(session, rtId);

            if (route != null) {
                mapModels.put("rtEventParking", coreRouteEvent.getByRouteAndEvent(rtId, Event.EVENT_STATION_OUT_PARKING_TIME_EXEED));
                mapModels.put("rtEventOutPath", coreRouteEvent.getByRouteAndEvent(rtId, Event.EVENT_ROUTE_OUT_OF_PATH));
                mapModels.put("rtEventInPath", coreRouteEvent.getByRouteAndEvent(rtId, Event.EVENT_ROUTE_BACK_TO_PATH));
            }
        }

        return mapModels;
    }

    /**
     * Get Station by route station id
     *
     * @param rsId - route station id
     * @return Station
     */
    private Station getStationByRouteStationId(HttpSession session, Long rsId) {
        if (rsId == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();
            RouteStation routeStation = coreRouteStation.get(rsId);

            if (routeStation != null) {
                return getStation(session, routeStation.getStationId());
            }
        }

        return null;
    }
}
