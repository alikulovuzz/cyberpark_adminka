package uzgps.route.json.response;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.Route;
import uz.netex.routing.database.tables.RouteStation;
import uz.netex.routing.database.tables.Station;
import uzgps.route.json.models.RouteJSON;
import uzgps.route.json.models.StationJSON;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Gayratjon on 5/21/2015.
 */
@JsonFilter("ResponseRouteListFilter")
public class ResponseRouteList extends AbstractResponse {
    protected List<RouteJSON> routeList;
    protected Map<Long, List<Long>> routeStationMap;
    protected Map<Long, StationJSON> stationMap;
    protected List<StationJSON> freeStationList;

    public ResponseRouteList() {
        this.routeList = null;
        this.routeStationMap = null;
        this.stationMap = null;
        this.freeStationList = null;
        this.html = null;
    }

    public ResponseRouteList(Map<String, Object> mapModels) {
        if (mapModels != null) {
            List<Route> rtList = (List<Route>) mapModels.get("routeList");
            Map<Long, List<RouteStation>> rtStMap = (Map<Long, List<RouteStation>>) mapModels.get("routeStationMap");

            if (rtList != null) {
                this.routeList = new ArrayList<>();

                for (Route route : rtList) {
                    RouteJSON routeJSON = new RouteJSON(route);
                    List<Long> stationIdList = null;

                    if (rtStMap != null && rtStMap.containsKey(route.getId())) {
                        stationIdList = new ArrayList<>();

                        for (RouteStation routeStation : rtStMap.get(route.getId())) {
                            stationIdList.add(routeStation.getStationId());
                        }
                    }

                    routeJSON.setStationIdList(stationIdList);
                    this.routeList.add(routeJSON);
                }
            }

            setStationMap((Map<Long, Station>) mapModels.get("stationMap"));
            setFreeStationList((List<Station>) mapModels.get("freeStationList"));
        }
    }

    @JsonProperty("routes")
    public List<RouteJSON> getRouteList() {
        return routeList;
    }

    private void setRouteList(List<Route> routeList) {
        if (routeList != null) {
            this.routeList = new ArrayList<>();

            for (Route route : routeList) {
                this.routeList.add(new RouteJSON(route));
            }
        }
    }

//    @JsonProperty("rtStMap")
    @JsonIgnore
    public Map<Long, List<Long>> getRouteStationMap() {
        return routeStationMap;
    }

    private void setRouteStationMap(Map<Long, List<RouteStation>> routeStationMap) {
        if (routeStationMap != null) {
            this.routeStationMap = new HashMap<>();

            for (Map.Entry<Long, List<RouteStation>> entry : routeStationMap.entrySet()) {
                Long routeId = entry.getKey();
                List<Long> routeStationList = new ArrayList<>();

                for (RouteStation routeStation : entry.getValue()) {
                    routeStationList.add(routeStation.getStationId());
                }

                this.routeStationMap.put(routeId, routeStationList);
            }
        }
    }

    @JsonProperty("stMap")
    public Map<Long, StationJSON> getStationMap() {
        return stationMap;
    }

    private void setStationMap(Map<Long, Station> stationMap) {
        if (stationMap != null) {
            this.stationMap = new HashMap<>();

            for (Map.Entry<Long, Station> entry : stationMap.entrySet()) {
                this.stationMap.put(entry.getKey(), new StationJSON(entry.getValue()));
            }
        }
    }

    @JsonProperty("fstList")
    public List<StationJSON> getFreeStationList() {
        return freeStationList;
    }

    private void setFreeStationList(List<Station> freeStationList) {
        if (freeStationList != null) {
            this.freeStationList = new ArrayList<>();

            for (Station station: freeStationList) {
                this.freeStationList.add(new StationJSON(station));
            }
        }
    }
}
