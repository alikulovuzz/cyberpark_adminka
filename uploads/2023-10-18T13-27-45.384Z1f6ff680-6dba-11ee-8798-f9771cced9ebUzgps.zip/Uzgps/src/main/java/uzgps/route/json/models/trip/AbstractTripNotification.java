package uzgps.route.json.models.trip;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.CoreEventNotificationSettings;
import uz.netex.routing.database.tables.EventNotificationSettings;
import uz.netex.routing.database.tables.Notification;

import java.sql.Timestamp;

/**
 * Created by Gayratjon on 8/28/2015.
 */
@Component
abstract class AbstractTripNotification {

    protected Long eventType;
    protected Long time;
    protected String mobjectName;
    protected String routeName;
    protected String color;
    protected Integer sound;

    @JsonIgnore
    CoreMain coreMain;

    protected AbstractTripNotification() {
        this.eventType = null;
        this.time = null;
        this.mobjectName = null;
        this.routeName = null;
        this.color = "#000000";
        this.sound = 0;
    }

    protected AbstractTripNotification(Notification notification, CoreMain coreMain) {
        this();
        this.coreMain = coreMain;

        if (notification != null) {
            // Set event type
            this.eventType = notification.getEventTypeId();

            // Set event reg date
            if (notification.getRegDate() != null) {
                this.time = notification.getNtime().getTime();
            }

            // Get Mobject for necessity of its name
            MobjectBig mobjectBig = this.coreMain.getMobjectById(notification.getMobjectId());
            if (mobjectBig != null) {
                this.mobjectName = mobjectBig.getName();
            }

            // Set current trip route name
            this.routeName = notification.getValueStr1();

            EventNotificationSettings eventNotificationSettings = getEventNotificationSettings(notification.getMobjectId(), notification.getEventTypeId());

            if (eventNotificationSettings != null) {
                // Notification popup background color
                this.color = eventNotificationSettings.getColor();
                // Notification alarm sound
                this.sound = eventNotificationSettings.getSound();
            }
        }
    }

    @JsonProperty("ev")
    public Long getEventType() {
        return eventType;
    }

    public void setEventType(Long eventType) {
        this.eventType = eventType;
    }

    @JsonProperty("tm")
    public Long getTime() {
        return time;
    }

    public Timestamp getTimestamp() {
        return (time != null) ? new Timestamp(time) : null;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    @JsonProperty("obnm")
    public String getMobjectName() {
        return mobjectName;
    }

    public void setMobjectName(String mobjectName) {
        this.mobjectName = mobjectName;
    }

    @JsonProperty("rtnm")
    public String getRouteName() {
        return routeName;
    }

    public void setRouteName(String routeName) {
        this.routeName = routeName;
    }

    @JsonProperty("cl")
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @JsonProperty("sn")
    public Integer getSound() {
        return sound;
    }

    public void setSound(Integer sound) {
        this.sound = sound;
    }

    public void setCoreMain(CoreMain coreMain) {
        this.coreMain = coreMain;
    }

    /**
     * Get EventNotificationSettings
     *
     * @param mobjectId
     * @param eventTypeId
     * @return
     */
    private EventNotificationSettings getEventNotificationSettings(Long mobjectId, Long eventTypeId) {
        if (mobjectId == null || eventTypeId == null) {
            return null;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreEventNotificationSettings coreEventNotificationSettings = tripRoutingControl.getCoreEventNotificationSettings();

            return coreEventNotificationSettings.getByMobjectAndEvent(mobjectId, eventTypeId);
        }

        return null;
    }
}
