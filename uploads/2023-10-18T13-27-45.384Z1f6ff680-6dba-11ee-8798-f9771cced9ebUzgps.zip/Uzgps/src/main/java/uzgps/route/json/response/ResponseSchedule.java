package uzgps.route.json.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import uzgps.route.json.models.TripTemplateJSON;

import java.util.List;

/**
 * Created by Gayratjon on 6/4/2015.
 */
public class ResponseSchedule extends AbstractResponse {
    private TripTemplateJSON tripTemplateJSON;
    private List<TripTemplateJSON> tripTemplatesJSON;

    public ResponseSchedule() {
        this.tripTemplateJSON = null;
        this.html = null;
    }

    @JsonProperty("tripEvent")
    public TripTemplateJSON getTripTemplateJSON() {
        return tripTemplateJSON;
    }

    public void setTripTemplateJSON(TripTemplateJSON tripTemplateJSON) {
        this.tripTemplateJSON = tripTemplateJSON;
    }

    public List<TripTemplateJSON> getTripTemplatesJSON() {
        return tripTemplatesJSON;
    }

    public void setTripTemplatesJSON(List<TripTemplateJSON> tripTemplatesJSON) {
        this.tripTemplatesJSON = tripTemplatesJSON;
    }
}
