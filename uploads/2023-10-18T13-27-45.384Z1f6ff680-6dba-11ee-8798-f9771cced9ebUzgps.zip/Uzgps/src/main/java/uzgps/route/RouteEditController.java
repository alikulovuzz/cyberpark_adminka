package uzgps.route;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.CoreRoute;
import uz.netex.routing.core.helpers.CoreRouteStation;
import uz.netex.routing.core.helpers.CoreStation;
import uz.netex.routing.database.tables.Route;
import uz.netex.routing.database.tables.RouteStation;
import uz.netex.routing.database.tables.Station;
import uz.netex.uzgps.errors.Errors;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.persistence.ContractSettings;
import uzgps.route.json.response.ResponseRouteEdit;
import uzgps.route.json.response.ResponseRouteList;
import uzgps.route.json.response.ResponseStationEdit;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

/**
 * Created by Gayratjon on 5/1/2015.
 */

@Controller
public class RouteEditController extends AbstractRoutingController {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTE_MAIN = "/route.htm";
    private final static String URL_ROUTE_MAIN_FAST_LINK = "/route/route-form.htm";
    private final static String VIEW_ROUTE_MAIN = "route/route";

    private final static String URL_AJAX_ROUTE_LIST = "/route/ajax-route-list.htm";
    private final static String VIEW_AJAX_ROUTE_LIST = "route/ajax-route-list";

    private final static String URL_AJAX_ROUTE_MANAGE = "/route/ajax-route-manage.htm";
    private final static String VIEW_AJAX_ROUTE_EDIT = "route/ajax-route-edit";

    private final static String URL_AJAX_STATION_MANAGE = "/route/ajax-station-manage.htm";
    private final static String VIEW_AJAX_STATION_EDIT = "route/ajax-station-edit";

    private final static String URL_AJAX_STATIONS_SORT = "/route/ajax-stations-sort.htm";

//    @Autowired
//    InternalResourceViewResolver htmlViewResolver;

    /**
     * Get map type
     *
     * @return Integer
     */
    @ModelAttribute("mapType")
    private Integer getMapType(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        return contractSettings.getMapType().intValue();
    }

    @Override
    protected String getActiveRouteTabMenu() {
        return "route";
    }

    /**
     * Get Route, Station, RouteStation models, and route-left.jsp, route-content.jsp view inside layout
     *
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_MAIN)
    private ModelAndView routeMain(HttpSession session,
                                   @RequestParam(value = "wkt", required = false) String wkt)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_MAIN);
        putRouteStationModelToView(session, modelAndView, "0", "", URL_AJAX_ROUTE_LIST);

        // Make json response
        ResponseRouteList responseRouteList = new ResponseRouteList(modelAndView.getModel());
        Set<String> ignorableFieldNames = new HashSet<>();

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseRouteListFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFieldNames));

            ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
            modelAndView.addObject("routeStationListJson", writer.writeValueAsString(responseRouteList));
            modelAndView.addObject("userAccessList", getUserAccessList(session));
        } catch (Exception e) {
            logger.error("Error: ", e);
        }

        String wktString = "";
        // Import route from tracks
        if (wkt != null) {
            org.locationtech.jts.io.WKTReader wktReader = new org.locationtech.jts.io.WKTReader();
            org.locationtech.jts.geom.Geometry geometry = null;
            try {
                geometry = wktReader.read(wkt);
            } catch (org.locationtech.jts.io.ParseException e) {
             logger.error("Error in routeMain", e);
            }

            if (geometry != null && geometry.isValid()) {
                wktString = wkt;
            }
        }

        modelAndView.addObject("wktString", wktString);

        return modelAndView;
    }

    /**
     * Get Route, Station, RouteStation models, and route-left.jsp, route-content.jsp view inside layout
     *
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_MAIN_FAST_LINK)
    private ModelAndView routeMainFastLink(HttpSession session,
                                           @RequestParam(value = "wkt", required = false) String wkt,
                                           @RequestParam(value = "route-id") String routeId,
                                           @RequestParam(value = "contract-id", required = false) String name,
                                           @RequestParam(value = "show-route", required = false) String showRoutesStr)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_MAIN);

        Route route = new Route();
        // Get selected route
        if (routeId != null && routeId.length() > 0) {
            route = getRoute(session, strToLong(routeId, null));
            putRouteStationModelToViewSingle(session, route.getId(), modelAndView, "", URL_AJAX_ROUTE_LIST);
        }

        // Make json response
        ResponseRouteList responseRouteList = new ResponseRouteList(modelAndView.getModel());
        Set<String> ignorableFieldNames = new HashSet<>();

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseRouteListFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFieldNames));

            ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
            modelAndView.addObject("routeStationListJson", writer.writeValueAsString(responseRouteList));
            modelAndView.addObject("userAccessList", getUserAccessList(session));
        } catch (Exception e) {
            logger.error("Error: ", e);
        }


        modelAndView.addObject("wktString", "");
        modelAndView.addObject("routeId", routeId);
        modelAndView.addObject("route", route);
        modelAndView.addObject("showRoute", showRoutesStr);

        return modelAndView;
    }

    /**
     >>============================== ROUTE EDIT MANAGER METHODS ==============================>>
     */

    /**
     * Get Route, Station, RouteStation models, and ajax-route-list.jsp clean view without layout in JSON
     *
     * @param pageNumber
     * @param searchText
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_AJAX_ROUTE_LIST)
    private void ajaxRouteList(HttpSession session,
                               HttpServletResponse response,
                               HttpServletRequest request,
                               @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber,
                               @RequestParam(value = "search", required = false, defaultValue = "") String searchText,
                               @RequestParam(value = "sorted-route-id", required = false) String sortedRouteId,
                               @RequestParam(value = "sort-err-code", required = false) String sortErrCode,
                               @RequestParam(value = "unchecked-routes-id", required = false) Long[] uncheckedRoutesId)
            throws Exception {

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_ROUTE_LIST);
        putRouteStationModelToView(session, modelAndView, pageNumber, searchText, URL_AJAX_ROUTE_LIST);

        Map<String, Object> mapModels = modelAndView.getModel();
        mapModels = setUncheckedRoutesMap(mapModels, uncheckedRoutesId);

        mapModels.put("sortedRouteId", strToLong(sortedRouteId, null));
        mapModels.put("sortErrCode", strToInt(sortErrCode, null));
        mapModels.put("userAccessList", getUserAccessList(session));

        // Get rendered html from view
        View resolvedView = htmlViewResolver.resolveViewName(modelAndView.getViewName(), response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(mapModels, request, mockResp);

        // Make json response
        ResponseRouteList responseRouteList = new ResponseRouteList(mapModels);
        responseRouteList.setHtml(mockResp.getContentAsString().trim());

        Set<String> ignorableFieldNames = new HashSet<>();

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseRouteListFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFieldNames));

            ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseRouteList);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Manage routes: add, edit, delete
     * returns JSON with Route model and rendered hml from ajax-route-edit.jsp
     *
     * @param response
     * @param request
     * @param cmd
     * @param routeId
     * @param name
     * @param useName
     * @param comment
     * @param useRoad
     * @param roadWidth
     * @param useNavigation
     * @param fontSize
     * @param roadOpacity
     * @param roadColor
     * @param fontColor
     * @param wkt
     * @throws Exception
     */
    @RequestMapping(value = URL_AJAX_ROUTE_MANAGE)
    private void ajaxRouteManage(HttpSession session,
                                 HttpServletResponse response,
                                 HttpServletRequest request,
                                 @RequestParam(value = "cmd", required = false) String cmd,
                                 @RequestParam(value = "route-id", required = false) String routeId,
                                 @RequestParam(value = "e-route-name", required = false) String name,
                                 @RequestParam(value = "cb-route-name", required = false, defaultValue = "0") String useName,
                                 @RequestParam(value = "e-route-description", required = false) String comment,
                                 @RequestParam(value = "cb-route-width", required = false, defaultValue = "0") String useRoad,
                                 @RequestParam(value = "e-route-width-size", required = false) String roadWidth,
                                 @RequestParam(value = "cb-route-lengthwise", required = false, defaultValue = "0") String useNavigation,
                                 @RequestParam(value = "e-route-name-font-size", required = false) String fontSize,
                                 @RequestParam(value = "circle-opacity", required = false, defaultValue = "0.5") String roadOpacity,
                                 @RequestParam(value = "e-route-width-color", required = false) String roadColor,
                                 @RequestParam(value = "e-route-name-color", required = false) String fontColor,
                                 @RequestParam(value = "route-wkt", required = false) String wkt,
                                 @RequestParam(value = "route-wkt-path", required = false) String wktPath,
                                 @RequestParam(value = "unchecked-routes-id", required = false) Long[] uncheckedRoutesId)
            throws Exception {

        Route route = new Route();
        Map<String, Object> mapModels = new HashMap<>();
        mapModels = setUncheckedRoutesMap(mapModels, uncheckedRoutesId);

        if (cmd != null) {

            if (cmd.equals("save")) {
                /**
                 * Save Route
                 */
                route.setContractId(MainController.getUserContractId(session));
                route.setUseName(strToInt(useName, route.getUseName()));
                route.setUseRoad(strToInt(useRoad, route.getUseRoad()));
                route.setUseNavigation(strToInt(useNavigation, route.getUseNavigation()));
                route.setName(name);
                route.setFontSize(strToInt(fontSize, route.getFontSize()));
                route.setFontColor(fontColor);
                route.setComment(comment);
                route.setRoadWidth(strToDouble(roadWidth, route.getRoadWidth()));
                route.setRoadOpacity(strToDouble(roadOpacity, route.getRoadOpacity()));
                route.setRoadColor(roadColor);
                route.setWkt(wkt);
                route.setWktPath(wktPath);

                int errWkt = validateWKT(wkt);
                if (errWkt == Errors.ERR_ROUTE_WKT) {
                    mapModels.put("errCode", errWkt);
                }

                Map<String, Integer> valErrors = validateRouteFormFields(name, fontSize, roadWidth, useRoad, wkt);
                mapModels.putAll(valErrors);

                if (valErrors.isEmpty() && errWkt == Errors.ERR_SUCCESS) {
                    // errCode might get success code if successfully new route inserted into db
                    // or gets some other error codes if something happened while inserting
                    Integer errCode = routeAdd(route);
                    mapModels.put("errCode", errCode);
                }
            } else if (cmd.equals("edit")) {
                /**
                 * Edit Route
                 */

                route = getRoute(session, strToLong(routeId, null));

                if (route != null) {
                    route.setUseName(strToInt(useName, route.getUseName()));
                    route.setUseRoad(strToInt(useRoad, route.getUseRoad()));
                    route.setUseNavigation(strToInt(useNavigation, route.getUseNavigation()));
                    route.setName(name);
                    route.setFontSize(strToInt(fontSize, route.getFontSize()));
                    route.setFontColor(fontColor);
                    route.setComment(comment);
                    route.setRoadWidth(strToDouble(roadWidth, route.getRoadWidth()));
                    route.setRoadOpacity(strToDouble(roadOpacity, route.getRoadOpacity()));
                    route.setRoadColor(roadColor);
                    route.setWkt(wkt);
                    route.setWktPath(wktPath);
                }

                int errWkt = validateWKT(wkt);
                if (errWkt == Errors.ERR_ROUTE_WKT) {
                    mapModels.put("errCode", errWkt);
                }

                Map<String, Integer> valErrors = validateRouteFormFields(name, fontSize, roadWidth, useRoad, wkt);
                mapModels.putAll(valErrors);

                if (valErrors.isEmpty() && errWkt == Errors.ERR_SUCCESS) {
                    // errCode might get success code if successfully route updated into db
                    // or gets some other error codes if something happened while updating
                    Integer errCode = routeEdit(session, route);
                    mapModels.put("errCode", errCode);

                    if (errCode == Errors.ERR_SUCCESS) {
                        // Update distances between stations in route
                        routeStationUpdateDistances(route != null ? route.getId() : null);
                    }
                }
            } else if (cmd.equals("delete")) {
                /**
                 * Delete Route
                 */
                Long rtId = strToLong(routeId, null);
                // errCode might get success code if successfully route deleted from db
                // or gets some other error codes if something happened while deleting
                Integer errCode = routeDelete(session, rtId);
                if (errCode != Errors.ERR_SUCCESS) {
                    mapModels.put("errCode", errCode);
                }
            } else if (cmd.equals("clean")) {
                route.setId(strToLong(routeId, null));
            } else if (cmd.equals("import")) {
                route.setRoadWidth(strToDouble(roadWidth, route.getRoadWidth()));
                route.setRoadColor(roadColor);
                route.setUseNavigation(0);
                route.setWkt(wkt);

                int errWkt = validateWKT(wkt);
                if (errWkt == Errors.ERR_ROUTE_WKT) {
                    mapModels.put("errCode", errWkt);
                }
            }
        } else {
            // Get selected route
            if (routeId != null && routeId.length() > 0) {
                route = getRoute(session, strToLong(routeId, null));
            }
        }

        mapModels.put("cmd", cmd);
        mapModels.put("route", route);
        mapModels.put("userAccessList", getUserAccessList(session));

        // Calculate scheduled travel time
        Long scheduledTravelTime = null;
        List<RouteStation> routeStationList = getRouteStationListByRoute(route.getId());
        if (routeStationList != null) {
            scheduledTravelTime = 0L;
            for (RouteStation routeStation : routeStationList) {
                if (routeStation.getTimeTravel() != null) {
                    scheduledTravelTime += routeStation.getTimeTravel();
                }
            }
        }
        mapModels.put("scheduledTravelTime", scheduledTravelTime);

        // Get rendered html from view
        View resolvedView = htmlViewResolver.resolveViewName(VIEW_AJAX_ROUTE_EDIT, response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(mapModels, request, mockResp);

        // Make json response
        ResponseRouteEdit responseRouteEdit = new ResponseRouteEdit();
        if (cmd != null && cmd.equals("delete")) {
            // After route deletion
            if (mapModels.containsKey("errCode")) {
                // If there is an error, need to be returned previous view
                responseRouteEdit.setRoute(route);
                responseRouteEdit.setHtml(mockResp.getContentAsString().trim());
            } else {
                // If succeed, return empty view
                responseRouteEdit.setHtml("");
            }
        } else {
            responseRouteEdit.setRoute(route);
            responseRouteEdit.setHtml(mockResp.getContentAsString().trim());
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseRouteEdit);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Update sorted station in given route
     *
     * @param response
     * @param rtId
     * @param routeStationIdList
     * @throws Exception
     */
    @RequestMapping(value = URL_AJAX_STATIONS_SORT)
    private void ajaxStationsSort(HttpSession session,
                                  HttpServletResponse response,
                                  @RequestParam(value = "route-id", required = false) String rtId,
                                  @RequestParam(value = "route-stations[]", required = false) Long[] routeStationIdList)
            throws Exception {

        Long routeId = strToLong(rtId, null);
        Integer errCode = Errors.ERR_OBJECT_IS_NULL;

        if (routeStationIdList != null) {
            List<RouteStation> routeStationList = getRouteStationListByRoute(routeId);

            // Before updating sorted stations we should check if count of both station are same
            if (routeStationList != null
                    && routeStationList.size() == routeStationIdList.length) {
                List<RouteStation> sortedRouteStationList = new ArrayList<>();

                for (int i = 0, rtStCount = 0; i < routeStationIdList.length; i++) {
                    RouteStation routeStation = getRouteStation(session, routeStationIdList[i]);

                    if (routeStation != null
                            && routeStation.getRouteId() != null
                            && routeStation.getRouteId().equals(routeId)) {

                        if (sortedRouteStationList.size() == 0) {
                            routeStation.setPriority(RouteStation.PRIORITY_START);
                        } else {
                            routeStation.setPriority(rtStCount);
                        }

                        sortedRouteStationList.add(routeStation);
                        rtStCount++;
                    }
                }

                if (sortedRouteStationList.size() > 1) {
                    RouteStation routeStation = sortedRouteStationList.get(sortedRouteStationList.size() - 1);
                    routeStation.setPriority(RouteStation.PRIORITY_FINISH);
                }

                if (routeStationList.size() == sortedRouteStationList.size()) {
                    errCode = Errors.ERR_SUCCESS;

                    for (int i = 0; i < sortedRouteStationList.size(); i++) {
                        RouteStation routeStation = sortedRouteStationList.get(i);
                        // Update route station
                        routeStationUpdate(routeStation);
                    }
                }
            }
        }

        if (errCode == Errors.ERR_SUCCESS) {
            // Update distances between stations in route
            routeStationUpdateDistances(routeId);
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("errCode");
            byte[] data = writer.writeValueAsBytes(errCode);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Insert a given route into DB
     *
     * @param route
     * @return int if returns zero then successfully completed
     */
    private int routeAdd(Route route) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();

            // Insert new route
            return coreRoute.save(route);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Delete a given route from DB
     *
     * @param routeId
     * @return int if returns zero then successfully completed
     */
    private int routeDelete(HttpSession session, Long routeId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            if (routeId == null)
                return Errors.ERR_OBJECT_IS_NULL;

            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            Route route = coreRoute.get(routeId);

            if (route == null) {
                return Errors.ERR_OBJECT_IS_NULL;
            } else {
                if (route.getContractId().equals(MainController.getUserContractId(session))) {
                    // Delete
                    return coreRoute.delete(route);
                } else {
                    // Given route contract is matched with current user contract id
                    return Errors.ERR_ROUTE_ACCESS;
                }
            }
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Validate fields of route save form
     *
     * @param name      - route name
     * @param fontSize  - route name font size
     * @param roadWidth - road width
     * @param useRoad   - route will be used or not
     * @param wkt       - geometry
     * @return Map<String, Integer> contains error code with error keys if validation failed for specific fields
     */
    private Map<String, Integer> validateRouteFormFields(String name, String fontSize, String roadWidth, String useRoad, String wkt) {

        Map<String, Integer> errorCodes = new HashMap<>();

        // Validate name
        if (name == null || name.trim().length() == 0) {
            errorCodes.put("errRouteName", Errors.ERR_ROUTE_NAME);
        }

        // Validate route name font size
        Integer fSize = strToInt(fontSize, -1);
        // if i equals to -1 conversion error
        if (fSize == -1) {
//            errorCodes.put("errRouteFontSize", Errors.ERR_ROUTE_FONT_SIZE);
        } else {
            if (fSize > UZGPS_CONST.ROUTE_NAME_FONT_SIZE_MAX) {
                errorCodes.put("errRouteFontSize", Errors.ERR_ROUTE_FONT_SIZE_MAX);
            } else if (fSize < UZGPS_CONST.ROUTE_NAME_FONT_SIZE_MIN) {
                errorCodes.put("errRouteFontSize", Errors.ERR_ROUTE_FONT_SIZE_MIN);
            }
        }

        // Validate road width
        Integer rWidth = strToInt(roadWidth, -1);
        // if i equals to -1 conversion error
        if (rWidth == -1) {
//            errorCodes.put("errRoadWidth", Errors.ERR_ROUTE_ROAD_WIDTH);
        } else {
            if (rWidth > UZGPS_CONST.ROUTE_ROAD_WIDTH_MAX) {
                errorCodes.put("errRoadWidth", Errors.ERR_ROUTE_ROAD_WIDTH_MAX);
            } else if (rWidth < UZGPS_CONST.ROUTE_ROAD_WIDTH_MIN) {
                errorCodes.put("errRoadWidth", Errors.ERR_ROUTE_ROAD_WIDTH_MIN);
            }
        }

        // Validate if route is drawn when useRoad is checked
        Integer uRoad = strToInt(useRoad, -1);
        if (uRoad == 1 && (wkt == null || wkt.trim().length() == 0)) {
            errorCodes.put("errRouteWkt", Errors.ERR_ROUTE_WKT);
        }

        return errorCodes;
    }

    /**
     <<============================== ROUTE EDIT MANAGER METHODS ==============================<<
     */

    /**
     >>============================== STATION EDIT MANAGER METHODS ==============================>>
     */

    /**
     * Manage routes: add, edit, delete
     * returns JSON with Station model and rendered hml from ajax-station-edit.jsp
     *
     * @param response
     * @param request
     * @param cmd
     * @param routeId
     * @param stationId
     * @param selectedStId
     * @param name
     * @param useName
     * @param fontColor
     * @param fontSize
     * @param stationType
     * @param stationColor
     * @param stationRadius
     * @param stationWidth
     * @param wkt
     * @throws Exception
     */
    @RequestMapping(value = URL_AJAX_STATION_MANAGE)
    private void ajaxStationManage(HttpSession session,
                                   HttpServletResponse response,
                                   HttpServletRequest request,
                                   @RequestParam(value = "cmd", required = false) String cmd,
                                   @RequestParam(value = "route-id", required = false) String routeId,
                                   @RequestParam(value = "station-id", required = false) String stationId,
                                   @RequestParam(value = "rs-id", required = false) String rsId,
                                   @RequestParam(value = "e-select-station", required = false) String selectedStId,
                                   @RequestParam(value = "e-station-name", required = false) String name,
                                   @RequestParam(value = "cb-station-name", required = false, defaultValue = "0") String useName,
                                   @RequestParam(value = "e-station-name-color", required = false) String fontColor,
                                   @RequestParam(value = "e-station-name-font-size", required = false) String fontSize,
                                   @RequestParam(value = "e-station-type", required = false) String stationType,
                                   @RequestParam(value = "e-station-type-color", required = false) String stationColor,
                                   @RequestParam(value = "e-station-circle-radius", required = false) String stationRadius,
                                   @RequestParam(value = "e-station-line-thickness", required = false) String stationWidth,
                                   @RequestParam(value = "station-wkt", required = false) String wkt,
                                   @RequestParam(value = "unchecked-routes-id", required = false) Long[] uncheckedRoutesId)
            throws Exception {

        Station station = new Station();
        Map<String, Object> mapModels = new HashMap<>();
        mapModels = setUncheckedRoutesMap(mapModels, uncheckedRoutesId);

        if (cmd != null) {

            // Choose appropriate field for shape radius based station type
            int shapeType = strToInt(stationType, Station.SHAPE_TYPE_NONE);
            String shapeRadius = stationRadius;
            if (shapeType == Station.SHAPE_TYPE_LINE) {
                shapeRadius = stationWidth;
            }

            if (cmd.equals("save")) {
                /**
                 * Save Station
                 */

                // Get station by selected station id
                station = getStation(session, strToLong(selectedStId, null));
                Route route = getRoute(session, strToLong(routeId, null));

                if (route != null) {
                    if (station == null) {
                        station = new Station();
                        station.setContractId(MainController.getUserContractId(session));
                        station.setUseName(strToInt(useName, station.getUseName()));
                        station.setName(name);
                        station.setFontSize(strToInt(fontSize, station.getFontSize()));
                        station.setFontColor(fontColor);
                        station.setShapeType(shapeType);
                        station.setShapeRadius(strToDouble(shapeRadius, station.getShapeRadius()));
                        station.setShapeColor(stationColor);
                        station.setWkt(wkt);

                        int errWkt = validateWKT(wkt);
                        if (errWkt == Errors.ERR_ROUTE_WKT) {
                            mapModels.put("errCode", errWkt);
                        }

                        Map<String, Integer> valErrors = validateStationFormFields(name, fontSize, shapeType, stationRadius, stationWidth);
                        mapModels.putAll(valErrors);

                        if (valErrors.isEmpty() && errWkt == Errors.ERR_SUCCESS) {
                            // errCode might get success code if successfully new station inserted into db
                            // or gets some other error codes if something happened while inserting
                            Integer errCode = stationAdd(station);
                            mapModels.put("errCode", errCode);

                            if (errCode == Errors.ERR_SUCCESS) {
                                errCode = routeStationAdd(route.getId(), station.getId());

                                // Update distances between stations
                                if (errCode == Errors.ERR_SUCCESS) {
                                    routeStationUpdateDistances(route.getId());
                                }

                                mapModels.put("errCode", errCode);
                            }
                        }
                    } else {
                        // Adding existing station

                        Integer errCode = routeStationAdd(route.getId(), station.getId());

                        // Update distances between stations
                        if (errCode == Errors.ERR_SUCCESS) {
                            routeStationUpdateDistances(route.getId());
                        }
                        mapModels.put("errCode", errCode);

                        int errWkt = validateWKT(station.getWkt());
                        if (errWkt == Errors.ERR_ROUTE_WKT) {
                            mapModels.put("errCode", errWkt);
                        }

                    }
                } else {
                    mapModels.put("errCode", Errors.ERR_ROUTE_ACCESS);
                }
            } else if (cmd.equals("edit")) {
                /**
                 * Edit Station
                 */

                station = getStation(session, strToLong(stationId, null));

                if (station != null) {
                    station.setUseName(strToInt(useName, station.getUseName()));
                    station.setName(name);
                    station.setFontSize(strToInt(fontSize, station.getFontSize()));
                    station.setFontColor(fontColor);
                    station.setShapeType(shapeType);
                    station.setShapeRadius(strToDouble(shapeRadius, station.getShapeRadius()));
                    station.setShapeColor(stationColor);
                    station.setWkt(wkt);
                }

                int errWkt = validateWKT(wkt);
                if (errWkt == Errors.ERR_ROUTE_WKT) {
                    mapModels.put("errCode", errWkt);
                }

                Map<String, Integer> valErrors = validateStationFormFields(name, fontSize, shapeType, stationRadius, stationWidth);
                mapModels.putAll(valErrors);

                if (valErrors.isEmpty() && errWkt == Errors.ERR_SUCCESS) {
                    // errCode might get success code if successfully station updated into db
                    // or gets some other error codes if something happened while updating
                    Integer errCode = stationEdit(session, station);
                    // Update distances between stations
                    if (errCode == Errors.ERR_SUCCESS) {
                        stationUpdateDistances(station.getId());
                    }
                    mapModels.put("errCode", errCode);

                    Route route = getRoute(session, strToLong(routeId, null));
                    int errCodeRoute = routeEditWithoutAccessCheck(session, route);

                    if (errCodeRoute == Errors.ERR_SUCCESS) {
                        // Update distances between stations in route
                        routeStationUpdateDistances(route != null ? route.getId() : null);
                    }

                }
            } else if (cmd.equals("delete")) {
                // Delete Station

                Long rtId = strToLong(routeId, null);
                Long stId = strToLong(stationId, null);

                // errCode might get success code if successfully station deleted from db
                // or gets some other error codes if something happened while deleting
                Integer errCode;

                if (rtId == null) {
                    errCode = stationDelete(session, stId);
                } else {
                    errCode = routeStationDelete(session, rtId, stId);
                }

                // Update distances for this station
                if (errCode == Errors.ERR_SUCCESS) {
                    stationUpdateDistances(stId);
                }

                if (errCode != Errors.ERR_SUCCESS) {
                    mapModels.put("errCode", errCode);
                }
            } else if (cmd.equals("clean")) {
                station.setId(strToLong(stationId, null));
            }
        } else {
            // Get selected station
            if (stationId != null && stationId.length() > 0) {
                station = getStation(session, strToLong(stationId, null));
            }
        }

        mapModels.put("cmd", cmd);
        mapModels.put("station", station);
        mapModels.put("routeId", routeId);

        // Get route station by id
        mapModels.put("routeStation", getRouteStation(session, strToLong(rsId, null)));
        mapModels.put("userAccessList", getUserAccessList(session));

        if (station != null && station.getId() != null) {
            List<Route> routeList = getRouteListByStationId(station.getId());
            Route route = getRoute(session, strToLong(routeId, null));
            if (routeList != null) {
                // Remove current route
                routeList.remove(route);
            }
            mapModels.put("routeList", routeList);
        } else {
            List<Station> stationList = getStationListByContract(session);
            mapModels.put("stationList", stationList);
        }

        // Get rendered html from view
        View resolvedView = htmlViewResolver.resolveViewName(VIEW_AJAX_STATION_EDIT, response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(mapModels, request, mockResp);

        // Make json response
        ResponseStationEdit responseStationEdit = new ResponseStationEdit();
        if (cmd != null && cmd.equals("delete")) {
            // After station deletion
            if (mapModels.containsKey("errCode")) {
                // If there is an error, need to be returned previous view
                responseStationEdit.setStation(station);
                responseStationEdit.setHtml(mockResp.getContentAsString().trim());
            } else {
                // If succeed, return empty view
                responseStationEdit.setHtml("");
            }
        } else {
            responseStationEdit.setStation(station);
            responseStationEdit.setHtml(mockResp.getContentAsString().trim());
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseStationEdit);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Make new route station with a given station id and route id
     *
     * @param routeId
     * @param stationId
     * @return int if returns zero then successfully completed
     */
    private int routeStationAdd(Long routeId, Long stationId) {

        if (routeId == null || stationId == null) {
            return Errors.ERR_OBJECT_IS_NULL;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();

            // Get count of route station by route id
            List<RouteStation> routeStationList = coreRouteStation.getByRoute(routeId);
            int rtStCount = (routeStationList == null) ? 0 : routeStationList.size();

            // Make new route station
            RouteStation routeStation = new RouteStation();
            routeStation.setRouteId(routeId);
            routeStation.setStationId(stationId);
            routeStation.setPriority(rtStCount);

            if (rtStCount == 0) {
                routeStation.setPriority(RouteStation.PRIORITY_START);
            } else if (rtStCount == 1) {
                routeStation.setPriority(RouteStation.PRIORITY_FINISH);
            }

            // Insert new route station
            return coreRouteStation.save(routeStation);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Update route station
     *
     * @param routeStation
     * @return int if returns zero then successfully completed
     */
    private int routeStationUpdate(RouteStation routeStation) {

        if (routeStation == null) {
            return Errors.ERR_OBJECT_IS_NULL;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();

            // Update route station
            return coreRouteStation.save(routeStation);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Delete route station from DB
     *
     * @param routeId
     * @param stationId
     * @return int if returns zero then successfully completed
     */
    private int routeStationDelete(HttpSession session, Long routeId, Long stationId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            if (routeId == null || stationId == null)
                return Errors.ERR_OBJECT_IS_NULL;

            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            CoreStation coreStation = tripRoutingControl.getCoreStation();
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();

            Route route = coreRoute.get(routeId);
            Station station = coreStation.get(stationId);

            if (route == null || station == null) {
                return Errors.ERR_OBJECT_IS_NULL;
            } else {
                Long currentContractId = MainController.getUserContractId(session);

                if (currentContractId != null
                        && !Objects.equals(station.getContractId(), currentContractId)) {
                    // Given station contract is matched with current user contract id
                    return Errors.ERR_ROUTE_ACCESS;
                }

//                if (currentContractId != null
//                        && !Objects.equals(route.getContractId(), currentContractId)) {
//                    // Given route contract is matched with current user contract id
//                    return Errors.ERR_ROUTE_ACCESS;
//                }
            }

            List<RouteStation> routeStationList = coreRouteStation.getByStation(station.getId());

            if (routeStationList != null) {
                for (RouteStation routeStation : routeStationList) {
                    if (routeStation.getRouteId().equals(route.getId())) {
                        // Delete route station connected to route and station
                        return coreRouteStation.delete(routeStation);
                    }
                }
            }

            return Errors.ERR_SUCCESS;
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Updates distances between stations
     *
     * @param routeId Route Id
     * @return Errors#ERR_SUCCESS if updated
     */
    private int routeStationUpdateDistances(Long routeId) {
        if (routeId != null) {
            CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
            if (tripRoutingControl == null) {
                return Errors.ERR_OBJECT_IS_NULL;
            }
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();
            if (coreRouteStation == null) {
                return Errors.ERR_OBJECT_IS_NULL;
            }
            coreRouteStation.updateDistances(routeId);
        }
        return Errors.ERR_SUCCESS;
    }

    /**
     * Updates distances of all routes where this station take place.
     *
     * @param stationId Station ID
     * @return Errors#ERR_SUCCESS if updated
     */
    private int stationUpdateDistances(Long stationId) {
        if (stationId != null) {
            // Get all routes, where this station take place
            List<Route> routeList = getRouteListByStationId(stationId);
            if (routeList != null && routeList.size() > 0) {
                // update distances in all routes
                for (Route route : routeList) {
                    if (route != null && route.getId() != null) {
                        routeStationUpdateDistances(route.getId());
                    }
                }
            }
        }
        return Errors.ERR_SUCCESS;
    }


    /**
     * Insert a given station into DB
     *
     * @param station
     * @return int if returns zero then successfully completed
     */
    private int stationAdd(Station station) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreStation coreStation = tripRoutingControl.getCoreStation();

            // Insert new station
            return coreStation.save(station);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    private Map<String, Object> setUncheckedRoutesMap(Map<String, Object> mapModels, Long[] uncheckedRoutesId) {
        Map<Long, String> uncheckedRoutes = new HashMap<>();
        for (Long uncheckedRouteId : uncheckedRoutesId) {
            uncheckedRoutes.put(uncheckedRouteId, "unchecked");
        }
        mapModels.put("uncheckedRoutes", uncheckedRoutes);

        return mapModels;
    }


    /**
     * Update a given station into DB
     *
     * @param station
     * @return int if returns zero then successfully completed
     */
    private int stationEdit(HttpSession session, Station station) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            if (station == null || station.getId() == null)
                return Errors.ERR_OBJECT_IS_NULL;

            if (station.getContractId().equals(MainController.getUserContractId(session))) {
                // Update
                return tripRoutingControl.getCoreStation().save(station);
            } else {
                // Given station contract is not matched with current user contract id
                return Errors.ERR_ROUTE_ACCESS;
            }
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Delete a given station from DB
     *
     * @param stationId
     * @return int if returns zero then successfully completed
     */
    private int stationDelete(HttpSession session, Long stationId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            if (stationId == null)
                return Errors.ERR_OBJECT_IS_NULL;

            CoreStation coreStation = tripRoutingControl.getCoreStation();
            Station station = coreStation.get(stationId);

            if (station == null) {
                return Errors.ERR_OBJECT_IS_NULL;
            } else {
                if (station.getContractId().equals(MainController.getUserContractId(session))) {
                    // Delete
                    return coreStation.delete(station);
                } else {
                    // Given station contract is matched with current user contract id
                    return Errors.ERR_ROUTE_ACCESS;
                }
            }
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Validate fields of station save form
     *
     * @param name          - station name
     * @param fontSize      - station name font size
     * @param shapeType     - station type
     * @param stationRadius - station radius
     * @param stationWidth  - station width
     * @return Map<String, Integer> contains error code with error keys if validation failed for specific fields
     */
    private Map<String, Integer> validateStationFormFields(String name, String fontSize, int shapeType, String stationRadius, String stationWidth) {

        Map<String, Integer> errorCodes = new HashMap<>();

        // Validate name
        if (name == null || name.trim().length() == 0) {
            errorCodes.put("errStationName", Errors.ERR_STATION_NAME);
        }

        // Validate station name font size
        Integer fSize = strToInt(fontSize, -1);
        // if i equals to -1 conversion error
        if (fSize == -1) {
//            errorCodes.put("errStationFontSize", Errors.ERR_STATION_FONT_SIZE);
        } else {
            if (fSize > UZGPS_CONST.STATION_NAME_FONT_SIZE_MAX) {
                errorCodes.put("errStationFontSize", Errors.ERR_STATION_FONT_SIZE_MAX);
            } else if (fSize < UZGPS_CONST.STATION_NAME_FONT_SIZE_MIN) {
                errorCodes.put("errStationFontSize", Errors.ERR_STATION_FONT_SIZE_MIN);
            }
        }

        if (shapeType == Station.SHAPE_TYPE_CIRCLE) {
            // Validate station radius
            Integer rWidth = strToInt(stationRadius, -1);
            // if i equals to -1 conversion error
            if (rWidth == -1) {
//            errorCodes.put("errRoadWidth", Errors.ERR_STATION_ROAD_WIDTH);
            } else {
                if (rWidth > UZGPS_CONST.STATION_RADIUS_MAX) {
                    errorCodes.put("errStationRadius", Errors.ERR_STATION_RADIUS_MAX);
                } else if (rWidth < UZGPS_CONST.STATION_RADIUS_MIN) {
                    errorCodes.put("errStationRadius", Errors.ERR_STATION_RADIUS_MIN);
                }
            }
        } else if (shapeType == Station.SHAPE_TYPE_LINE) {
            // Validate station width
            Integer rWidth = strToInt(stationRadius, -1);
            // if i equals to -1 conversion error
            if (rWidth == -1) {
//            errorCodes.put("errRoadWidth", Errors.ERR_STATION_ROAD_WIDTH);
            } else {
                if (rWidth > UZGPS_CONST.STATION_WIDTH_MAX) {
                    errorCodes.put("errStationWidth", Errors.ERR_STATION_WIDTH_MAX);
                } else if (rWidth < UZGPS_CONST.STATION_WIDTH_MIN) {
                    errorCodes.put("errStationWidth", Errors.ERR_STATION_WIDTH_MIN);
                }
            }
        }
        return errorCodes;
    }

    private int validateWKT(String wktString) {
        if (wktString != null && !wktString.isEmpty() && wktString.length() > 1) {
            return Errors.ERR_SUCCESS;
        } else {
            return Errors.ERR_ROUTE_WKT;
        }
    }

    /**
     * Get list of routes by a given station id
     *
     * @param stationId
     * @return List<Route> - list of routes
     */
    private List<Route> getRouteListByStationId(Long stationId) {
        if (stationId == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            return coreRoute.getListByStation(stationId);
        }

        return null;
    }

    /**
     * Get list of stations by current contract id
     *
     * @return List<Route> - list of stations
     */
    private List<Station> getStationListByContract(HttpSession session) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreStation coreStation = tripRoutingControl.getCoreStation();

            return coreStation.getListByContract(MainController.getUserContractId(session));
        }

        return null;
    }

    /**
     <<============================== STATION EDIT MANAGER METHODS ==============================<<
     */
}
