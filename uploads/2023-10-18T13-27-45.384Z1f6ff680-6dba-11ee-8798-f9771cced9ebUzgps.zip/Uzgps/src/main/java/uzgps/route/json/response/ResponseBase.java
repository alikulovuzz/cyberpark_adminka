package uzgps.route.json.response;

/**
 * Created by Gayratjon on 6/25/2015.
 */
public class ResponseBase extends AbstractResponse {

    public ResponseBase() {
        this.html = null;
    }
}
