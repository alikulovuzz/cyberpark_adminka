package uzgps.route;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminReportController;
import uzgps.map.MonitoringController;
import uzgps.report.ReportController;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Created by Gayratjon on 9/16/2015.
 */
@Controller
public class RouteReportController extends AbstractRoutingController {

    private final static String URL_ROUTE_REPORT_MAIN = "/route/report.htm";
    private final static String VIEW_ROUTE_REPORT_MAIN = "route/route-report";

    @Autowired
    ReportController reportController;

    @Autowired
    private MonitoringController monitoringController;

    @Override
    protected String getActiveRouteTabMenu() {
        return "report";
    }

    @RequestMapping(value = URL_ROUTE_REPORT_MAIN)
    private ModelAndView routeReportMain(HttpSession session, Locale locale)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_REPORT_MAIN);

        List<MobjectBig> mobjectList = monitoringController.getMobjects(session, false);

        if (mobjectList != null && mobjectList.size() > 0) {
            Collections.sort(mobjectList);
            modelAndView.addObject("mObjectList", mobjectList);
        }

        modelAndView.addObject("routeListFull", getRouteList(session, -1, ""));

        reportController.processReportModel(session, modelAndView, locale, AdminReportController.REPORT_CATEGORY_ROUTING);

        return modelAndView;
    }
}
