package uzgps.route.json.response;

import uz.netex.routing.database.tables.Station;
import uzgps.route.json.models.StationJSON;

/**
 * Created by Gayratjon on 5/22/2015.
 */
public class ResponseStationEdit extends AbstractResponse {
    private StationJSON station;

    public ResponseStationEdit() {
        this.station = null;
        this.html = null;
    }

    public StationJSON getStation() {
        return station;
    }

    public void setStation(Station station) {
        if (station != null) {
            this.station = new StationJSON(station);
        }
    }
}
