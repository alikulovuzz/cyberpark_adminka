package uzgps.route.json.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.EventNotificationSettings;

import java.sql.Timestamp;

/**
 * Created by Gayratjon on 6/1/2015.
 */
public class EventNotificationSettingsJSON extends EventNotificationSettings {
    public EventNotificationSettingsJSON() {
        super();
    }

    public EventNotificationSettingsJSON(EventNotificationSettings eventNotificationSettings) {
        super();

        if (eventNotificationSettings != null) {
            this.id = eventNotificationSettings.getId();
            this.mobjectId = eventNotificationSettings.getMobjectId();
            this.eventTypeId = eventNotificationSettings.getEventTypeId();
            this.useNotification = eventNotificationSettings.getUseNotification();
            this.useIcon = eventNotificationSettings.getUseIcon();
            this.useMessage = eventNotificationSettings.getUseMessage();
            this.useNarusheniye = eventNotificationSettings.getUseNarusheniye();
            this.useEmail = eventNotificationSettings.getUseEmail();
            this.useSms = eventNotificationSettings.getUseSms();
            this.sound = eventNotificationSettings.getSound();
            this.color = eventNotificationSettings.getColor();
        }
    }

    @Override
    public Long getId() {
        return super.getId();
    }

    @JsonProperty("moid")
    @Override
    public Long getMobjectId() {
        return super.getMobjectId();
    }

    @JsonProperty("evid")
    @Override
    public Long getEventTypeId() {
        return super.getEventTypeId();
    }

    @JsonProperty("usnt")
    @Override
    public Integer getUseNotification() {
        return super.getUseNotification();
    }

    @JsonProperty("usms")
    @Override
    public Integer getUseMessage() {
        return super.getUseMessage();
    }

    @JsonProperty("usnr")
    @Override
    public Integer getUseNarusheniye() {
        return super.getUseNarusheniye();
    }

    @JsonProperty("usem")
    @Override
    public Integer getUseEmail() {
        return super.getUseEmail();
    }

    @JsonProperty("ussm")
    @Override
    public Integer getUseSms() {
        return super.getUseSms();
    }

    @JsonProperty("snd")
    @Override
    public Integer getSound() {
        return super.getSound();
    }

    @JsonProperty("clr")
    @Override
    public String getColor() {
        return super.getColor();
    }

    /**
     * <<========================== JSON IGNORE FIELDS ==========================>>
     */

    @JsonIgnore
    @Override
    public Integer getUseIcon() {
        return super.getUseIcon();
    }

    @JsonIgnore
    @Override
    public String getStatus() {
        return super.getStatus();
    }

    @JsonIgnore
    @Override
    public Timestamp getRegDate() {
        return super.getRegDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getModDate() {
        return super.getModDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getExpDate() {
        return super.getExpDate();
    }
}
