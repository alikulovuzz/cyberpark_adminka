package uzgps.route.json.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.EventNotificationSettings;
import uzgps.route.json.models.EventNotificationSettingsJSON;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 6/1/2015.
 */
public class ResponseEventNotification extends AbstractResponse {
    List<EventNotificationSettingsJSON> eventNotificationSettingsJSONList;

    public ResponseEventNotification() {
        this.eventNotificationSettingsJSONList = null;
        this.html = null;
    }

    @JsonProperty("eventList")
    public List<EventNotificationSettingsJSON> getEventNotificationSettingsJSONList() {
        return eventNotificationSettingsJSONList;
    }

    public void setEventNotificationSettingsJSONList(List<EventNotificationSettings> eventNotificationSettingsList) {
        if (eventNotificationSettingsList != null) {
            this.eventNotificationSettingsJSONList = new ArrayList<>();

            for (EventNotificationSettings eventNotificationSettings : eventNotificationSettingsList) {
                this.eventNotificationSettingsJSONList.add(new EventNotificationSettingsJSON(eventNotificationSettings));
            }
        }
    }
}
