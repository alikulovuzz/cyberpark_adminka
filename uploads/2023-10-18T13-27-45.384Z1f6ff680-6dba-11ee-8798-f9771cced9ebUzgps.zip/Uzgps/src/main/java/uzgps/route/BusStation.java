package uzgps.route;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreMobjectBig;
import uz.netex.datatype.MobjectBig;
import uz.netex.routing.busstation.Bus;
import uz.netex.routing.busstation.BusInStationStartContainer;
import uz.netex.routing.busstation.BusStationHolder;
import uz.netex.routing.busstation.train.TrainStationHolder;
import uz.netex.routing.busstation.train.TrainTabloInfo;
import uz.netex.routing.busstation.version3.Tablo3Container;
import uz.netex.routing.busstation.version3.TabloInfoAll;
import uz.netex.routing.database.tables.Trip;
import uzgps.common.Converters;

import java.sql.Timestamp;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
//import java.util.Date;
import java.util.List;

/**
 * Created by Saidolim on 07.04.2017.
 */

@Controller
public class BusStation {

    @Autowired
    CoreMain coreMain;

//    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_BUSSTATION_MAIN = "/busstation.htm";
    private final static String URL_BUSSTATION_MAIN_ALIAS = "/bus.htm";
    private final static String VIEW_BUSSTATION_MAIN = "busstation/tablo";
    private final static String VIEW_BUSSTATION_MAIN_AJAX = "busstation/api-tablo";

    private final static String URL_BUSSTATION_MAIN_V3 = "/bus3.htm";
    private final static String URL_BUSSTATION_MAIN_V3_VARIABLE = "busstation/tablo-vars";
    private final static String URL_BUSSTATION_MAIN_V3_REFRESH = "busstation/tablo-refresh";

    private final static String URL_TRAIN_STATION_GAJK = "/tablo-train.htm";
    private final static String VIEW_TRAIN_STATION_GAJK = "busstation/tablo-train";
    private final static String VIEW_TRAIN_STATION_GAJK_AJAX = "busstation/api-tablo-train";

    @RequestMapping(value = URL_BUSSTATION_MAIN)
    private ModelAndView busStationMain(@RequestParam(value = "stationId", required = false, defaultValue = "0") String stationIdStr,
                                       @RequestParam(value = "format", required = false, defaultValue = "html") String resultFormat) {

        ModelAndView modelAndView;
        if (resultFormat.equals("json")) {
            modelAndView = new ModelAndView(VIEW_BUSSTATION_MAIN_AJAX);
        } else {
            modelAndView = new ModelAndView(VIEW_BUSSTATION_MAIN);
        }
        List<Bus> busList = null;
        if (coreMain.getCoreTripRoutingControl() != null
                && coreMain.getCoreTripRoutingControl().busStationHolder != null
                && coreMain.getCoreTripRoutingControl().busStationHolder.getBusList() != null) {
            busList = coreMain.getCoreTripRoutingControl().busStationHolder.getBusList();
        }

        String[] stationIdListStr = stationIdStr.split(",");
        List<Long> stationIdList = new ArrayList<>();
        Long stationId = null;
        for (int k = 0; k < stationIdListStr.length; k++) {
            stationId = Converters.strToLong(stationIdListStr[k], null);
            if (stationId != null && stationId > 0) stationIdList.add(stationId);
        }

//        Long stationId = Converters.strToLong(stationIdStr, null);
        String stationName = getStationName(stationId);

        // Make bus list for JSP
        List<Bus> busListForView = new ArrayList<>();
        if (busList != null) {
            for (Bus bus : busList) {
                if (bus != null
                        && bus.getStationId() != null
                        && stationIdList.contains(bus.getStationId())) {
                    Bus busToTablo = new Bus(bus);
                    if (busToTablo.getMobjectName() == null) {
                        MobjectBig mobjectBig = CoreMobjectBig.getInstance().getById(busToTablo.getMobjectId());
                        if (mobjectBig != null)
                            busToTablo.setMobjectName(mobjectBig.getName());
                    }
                    busListForView.add(busToTablo);
                }
            }
        }

        modelAndView.addObject("stationId", stationIdList);
        modelAndView.addObject("stationName", stationName);
        modelAndView.addObject("busList", busListForView);
        modelAndView.addObject("timeNow", new Timestamp(System.currentTimeMillis()));

        List<Trip> listTrip = BusInStationStartContainer.getInstance().getTripList();
        modelAndView.addObject("listTrip", listTrip);

        return modelAndView;
    }

    private String getStationName(Long stationId) {
        try {
            return coreMain.getCoreTripRoutingControl().getCoreStation().get(stationId).getName();
        } catch (Exception e) {

        }
        return "";
    }

    @RequestMapping(value = URL_BUSSTATION_MAIN_ALIAS)
    private ModelAndView busStationMainAlias(@RequestParam(value = "s", required = false, defaultValue = "0") String stationIdStr,
                                            @RequestParam(value = "f", required = false, defaultValue = "html") String resultFormat) {
        return busStationMain(stationIdStr, resultFormat);
    }


    @RequestMapping(value = URL_BUSSTATION_MAIN_V3)
    private ModelAndView busStationMainV3(@RequestParam(value = "s", required = false, defaultValue = "0") String stationIdStr,
                                         @RequestParam(value = "f", required = false, defaultValue = "html") String resultFormat) {

        ModelAndView modelAndView;
        if (resultFormat.equals("json")) {
            modelAndView = new ModelAndView(VIEW_BUSSTATION_MAIN_AJAX);
        } else {
            modelAndView = new ModelAndView(VIEW_BUSSTATION_MAIN);
        }

        BusStationHolder busStationHolder = null;
        if (coreMain.getCoreTripRoutingControl() != null
                && coreMain.getCoreTripRoutingControl().busStationHolder != null) {
            busStationHolder = coreMain.getCoreTripRoutingControl().busStationHolder;
        }

        if (busStationHolder == null) {
            return modelAndView;
        }

        String[] stationIdListStr = stationIdStr.split(",");
        List<Bus> busListForView = new ArrayList<>();

        Long stationId = null;

        for (int k = 0; k < stationIdListStr.length; k++) {
            stationId = Converters.strToLong(stationIdListStr[k], null);
            if (stationId != null && stationId > 0) {
                List<Bus> busList = busStationHolder.getBusListByStationId(stationId);
                if (busList != null)
                    busListForView.addAll(busList);
            }
        }

        String stationName = getStationName(stationId);

//        modelAndView.addObject("stationId", stationIdList);
        modelAndView.addObject("stationName", stationName);
        modelAndView.addObject("busList", busListForView);
        modelAndView.addObject("timeNow", new Timestamp(System.currentTimeMillis()));

        List<TabloInfoAll> list3 = Tablo3Container.getInstance().getTabloInfoAllList();
        modelAndView.addObject("list3", list3);

        int counter = busStationHolder.getQueueCount();
        modelAndView.addObject("queueCount", counter);

        List<Trip> listTrip = BusInStationStartContainer.getInstance().getTripList();
        modelAndView.addObject("listTrip", listTrip);

        return modelAndView;
    }

    @RequestMapping(value = URL_BUSSTATION_MAIN_V3_VARIABLE)
    private String busStationMainV3Variables(@RequestParam(value = "s", required = false, defaultValue = "0") String stationIdStr,
                                            @RequestParam(value = "f", required = false, defaultValue = "html") String resultFormat) {
        return "";
    }

    @RequestMapping(value = URL_BUSSTATION_MAIN_V3_REFRESH)
    private String busStationMainV3Refresh(@RequestParam(value = "s", required = false, defaultValue = "0") String stationIdStr,
                                          @RequestParam(value = "f", required = false, defaultValue = "html") String resultFormat) {
        BusInStationStartContainer.getInstance().collectMobjectStationInfo();
        return "OK";
    }

    @RequestMapping(value = URL_TRAIN_STATION_GAJK)
    private ModelAndView trainStationGajk(@RequestParam(value = "c", required = false, defaultValue = "0") String contractIdStr,
                                         @RequestParam(value = "f", required = false, defaultValue = "html") String resultFormat) {

        ModelAndView modelAndView;
        if (resultFormat.equals("json")) {
            modelAndView = new ModelAndView(VIEW_TRAIN_STATION_GAJK_AJAX);
        } else {
            modelAndView = new ModelAndView(VIEW_TRAIN_STATION_GAJK);
        }

        TrainStationHolder trainStationHolder = null;
        if (coreMain.getCoreTripRoutingControl() != null
                && coreMain.getCoreTripRoutingControl().trainStationHolder != null) {
            trainStationHolder = coreMain.getCoreTripRoutingControl().trainStationHolder;
        }

        if (trainStationHolder == null) {
            return modelAndView;
        }

        List<TrainTabloInfo> list = trainStationHolder.getTableInfo();

        modelAndView.addObject("list", list);
        modelAndView.addObject("timeNow", new Timestamp(System.currentTimeMillis()));

        return modelAndView;
    }
}
