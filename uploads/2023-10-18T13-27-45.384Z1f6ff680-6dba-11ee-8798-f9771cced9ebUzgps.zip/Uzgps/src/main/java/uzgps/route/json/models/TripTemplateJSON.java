package uzgps.route.json.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.Route;
import uz.netex.routing.database.tables.TripTemplate;

import java.sql.Timestamp;

/**
 * Created by Gayratjon on 6/3/2015.
 */
public class TripTemplateJSON extends TripTemplate {

    private String title;
    private String color;
    private Long timeEnter;
    private Long timeExit;

    public TripTemplateJSON() {
        super();

        this.color = "#3a87ad";
        this.title = "Empty route name";
        this.timeEnter = null;
        this.timeExit = null;
    }

    public TripTemplateJSON(TripTemplate tripTemplate) {
        this();

        if (tripTemplate != null) {
            this.id = tripTemplate.getId();
            this.mobjectId = tripTemplate.getMobjectId();
            this.contractId = tripTemplate.getContractId();
            this.routeId = tripTemplate.getRouteId();
            this.repeatTimes = tripTemplate.getRepeatTimes();
            this.timeStart = tripTemplate.getTimeStart();
            this.timeEnd = tripTemplate.getTimeEnd();
            this.repeatEvery = tripTemplate.getRepeatEvery();
            this.weekdays = tripTemplate.getWeekdays();
            this.repeatCountType = tripTemplate.getRepeatCountType();
            this.repeatCount = tripTemplate.getRepeatCount();

            if (tripTemplate.getTimeStart() != null) {
                this.setTimeEnter(tripTemplate.getTimeStart());
            }

            if (tripTemplate.getTimeEnd() != null) {
                this.setTimeExit(tripTemplate.getTimeEnd());
            }

            if (tripTemplate.getRouteName() != null && tripTemplate.getMobjectName() != null) {
                this.setTitle(", " + tripTemplate.getMobjectName() + ", " + tripTemplate.getRouteName());
            }

            if (tripTemplate.getRoadColor() != null) {
                this.setColor(tripTemplate.getRoadColor());
            }

        }
    }

    @Override
    public Long getId() {
        return super.getId();
    }

    @JsonProperty("moid")
    @Override
    public Long getMobjectId() {
        return super.getMobjectId();
    }

    @JsonProperty("rtid")
    @Override
    public Long getRouteId() {
        return super.getRouteId();
    }

    @JsonProperty("ctid")
    @Override
    public Long getContractId() {
        return super.getContractId();
    }

    @JsonProperty("rptm")
    @Override
    public Long getRepeatTimes() {
        return super.getRepeatTimes();
    }

    @JsonProperty("tmst")
    @Override
    public Long getTimeStart() {
        return super.getTimeStart();
    }

    @JsonProperty("tmend")
    @Override
    public Long getTimeEnd() {
        return super.getTimeEnd();
    }

    @JsonProperty("rpev")
    @Override
    public Integer getRepeatEvery() {
        return super.getRepeatEvery();
    }

    @JsonProperty("wkdy")
    @Override
    public Integer getWeekdays() {
        return super.getWeekdays();
    }

    @JsonProperty("rptp")
    @Override
    public Integer getRepeatCountType() {
        return super.getRepeatCountType();
    }

    @JsonProperty("rpct")
    @Override
    public Long getRepeatCount() {
        return super.getRepeatCount();
    }

    @JsonProperty("clr")
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @JsonProperty("tl")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @JsonProperty("tmen")
    public Long getTimeEnter() {
        return timeEnter;
    }

    public void setTimeEnter(Long timeEnter) {
        this.timeEnter = timeEnter;
    }

    @JsonProperty("tmex")
    public Long getTimeExit() {
        return timeExit;
    }

    public void setTimeExit(Long timeExit) {
        this.timeExit = timeExit;
    }

    /**
     * <<========================== JSON IGNORE FIELDS ==========================>>
     */

    @JsonIgnore
    @Override
    public Route getRoute() {
        return super.getRoute();
    }

    @JsonIgnore
    @Override
    public String getStatus() {
        return super.getStatus();
    }

    @JsonIgnore
    @Override
    public Timestamp getRegDate() {
        return super.getRegDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getModDate() {
        return super.getModDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getExpDate() {
        return super.getExpDate();
    }
}
