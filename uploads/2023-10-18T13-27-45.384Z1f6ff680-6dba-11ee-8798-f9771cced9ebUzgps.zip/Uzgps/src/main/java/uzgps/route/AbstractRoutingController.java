package uzgps.route;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.CoreRoute;
import uz.netex.routing.core.helpers.CoreRouteStation;
import uz.netex.routing.core.helpers.CoreStaffAccess;
import uz.netex.routing.core.helpers.CoreStation;
import uz.netex.routing.database.tables.Route;
import uz.netex.routing.database.tables.RouteStation;
import uz.netex.routing.database.tables.StaffAccess;
import uz.netex.routing.database.tables.Station;
import uz.netex.uzgps.errors.Errors;
import uzgps.common.CommonUtils;
import uzgps.main.AppLastStatus;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.persistence.Contract;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.User;
import uzgps.persistence.UserAccessList;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Gayratjon on 5/13/2015
 */
public abstract class AbstractRoutingController {

    @Autowired
    MainController mainController;

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    ObjectMapper jsonMapper;

    @Autowired
    CoreMain coreMain;

    @Autowired
    InternalResourceViewResolver htmlViewResolver;

    /**
     * Get active route tab menu in order to add active class to tab menu in html
     *
     * @return String
     */
    @ModelAttribute("activeRouteTabMenu")
    abstract protected String getActiveRouteTabMenu();

    /**
     * Check whether system has an access for routing module
     *
     * @return
     */
    @ModelAttribute("hasRoutingAccess")
    private Boolean getRoutingAccess() {
        return CoreTripRoutingControl.hasAccess();
    }

    /**
     * Get active top menu in order to add active class to menu in html
     *
     * @return String
     */
    @ModelAttribute("activeTopMenu")
    private String getActiveTopMenu() {
        return "route";
    }

    /**
     * Get current user's company name
     *
     * @return String
     */
    @ModelAttribute("companyName")
    private String getCompanyName(HttpSession session) {

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            return MainController.getUserContract(session).getCompany().getName();
        } else {
            return MainController.getUserContract(session).getCustomerCompanyName();
        }
    }

    /**
     * Get current user's login
     *
     * @return String
     */
    @ModelAttribute("userLogin")
    private String getUserLogin() {
        // Get current logged in user
        User user = mainController.getUser();
        return user.getLogin();
    }

    /**
     * Get number of last track message
     *
     * @return Integer
     */
    @ModelAttribute("numLastTrackMessages")
    private Integer getNumLastTrackMessages() {
        return 0;
    }


    /**
     * Get last seen alert notification time
     *
     * @param appStatus
     * @return Long
     */
    @ModelAttribute("lastAlertNotificationTime")
    private Long getLastAlertNotificationTime(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String appStatus) {
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        Long lastAlertNotificationTime = appLastStatus.getUnseenNotificationsLastTime();
        if (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")) {
            // lastAlertNotificationTime = coreMain.getNotificationUnitLastTime(MainController.getUserContractId(session));
            lastAlertNotificationTime = System.currentTimeMillis();
        }

        return lastAlertNotificationTime;
    }

    /**
     * Get interval time for http request via AJAX
     *
     * @param session
     * @return Long
     */
    @ModelAttribute("requestIntervalTime")
    private Long getRequestIntervalTime(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        Integer requestIntervalTime = contractSettings.getMonitoringRefreshInterval();
        if (requestIntervalTime > MainController.REQUEST_INTERVAL_MAX) {
            requestIntervalTime = MainController.REQUEST_INTERVAL_MAX;
        } else if (requestIntervalTime < MainController.REQUEST_INTERVAL_MIN) {
            requestIntervalTime = MainController.REQUEST_INTERVAL_MIN;
        }

        return requestIntervalTime * 1000L;
    }

    /**
     * Get current user's access list
     *
     * @param session
     * @return UserAccessList
     */
    @ModelAttribute("userAccessList")
    public UserAccessList getUserAccessList(HttpSession session) {
        // Get user access list in session
        UserAccessList userAccessList = mainController.getUserAccessList(session);

        return userAccessList;
    }

    /**
     * Make common map models for all routing sections
     *
     * @param appStatus
     * @param session
     * @return Map<String, Object>
     */
    protected Map<String, Object> getCommonRouteMapModel(String appStatus, HttpSession session) {
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        // Get user access list in session
        UserAccessList userAccessList = mainController.getUserAccessList(session);

        // Get current logged in user
        User user = mainController.getUser();

        // Map keeps all models
        Map<String, Object> mapModels = new HashMap<>();

        Long lastAlertNotificationTime = appLastStatus.getUnseenNotificationsLastTime();
        if (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")) {
            // lastAlertNotificationTime = coreMain.getNotificationUnitLastTime(MainController.getUserContractId(session));
            lastAlertNotificationTime = System.currentTimeMillis();
        }

        Integer requestIntervalTime = contractSettings.getMonitoringRefreshInterval();
        if (requestIntervalTime > MainController.REQUEST_INTERVAL_MAX) {
            requestIntervalTime = MainController.REQUEST_INTERVAL_MAX;
        } else if (requestIntervalTime < MainController.REQUEST_INTERVAL_MIN) {
            requestIntervalTime = MainController.REQUEST_INTERVAL_MIN;
        }

        mapModels.put("activeTopMenu", "route");
        mapModels.put("numNotification", 0); // if zero, any notifications won't be showed coming from bottom
        mapModels.put("userAccessList", userAccessList);
        mapModels.put("lastAlertNotificationTime", lastAlertNotificationTime);
        mapModels.put("requestIntervalTime", requestIntervalTime * 1000); // in milliseconds
//        mapModels.put("companyName", user.getContract().getCompany().getName());
        mapModels.put("userLogin", user.getLogin());

        return mapModels;
    }

    /**
     * Put Route, Station, RouteStation models and other variable into given ModelAndView
     *
     * @param modelAndView
     * @param pageNumber
     * @param searchText
     */
    protected void putRouteStationModelToView(HttpSession session, ModelAndView modelAndView, String pageNumber, String searchText, String
            paginationUrl) {
        Integer currentPage = strToInt(pageNumber, 0);
        Integer pageCount = getNumRoutePages(session, searchText);

        if (currentPage >= pageCount
                && currentPage > 0
                && pageCount > 0) {
            currentPage = pageCount - 1;
        }

        List<Integer> pages = getPageNumbers(currentPage, pageCount);

        modelAndView.addAllObjects(getRouteStationMapModel(session, currentPage, searchText));
        modelAndView.addObject("pageNumber", currentPage);
        modelAndView.addObject("pageCount", pageCount);
        modelAndView.addObject("pagination", pages);
        modelAndView.addObject("paginationUrl", paginationUrl);
        modelAndView.addObject("searchText", searchText);
    }

    /**
     * Put Route, Station, RouteStation models and other variable into given ModelAndView
     *
     * @param modelAndView
     * @param searchText
     */
    protected void putRouteStationModelToViewSingle(HttpSession session, Long routeId, ModelAndView modelAndView,
                                                    String searchText, String paginationUrl) {
        Integer currentPage = strToInt("0", 0);
        Integer pageCount = 0;

        List<Integer> pages = getPageNumbers(currentPage, pageCount);

        modelAndView.addAllObjects(getRouteStationMapModelSingle(session, routeId, currentPage, searchText));
        modelAndView.addObject("pageNumber", currentPage);
        modelAndView.addObject("pageCount", pageCount);
        modelAndView.addObject("pagination", pages);
        modelAndView.addObject("paginationUrl", paginationUrl);
        modelAndView.addObject("searchText", searchText);
    }

    /**
     * Put route list models and page numbers into a given view
     *
     * @param modelAndView
     * @param pageNumber
     * @param searchText
     * @param paginationUrl
     */
    protected void putRouteListModelToView(HttpSession session, ModelAndView modelAndView, String pageNumber, String searchText, String
            paginationUrl) {
        Integer currentPage = strToInt(pageNumber, 0);
        Integer pageCount = getNumRoutePages(session, searchText);

        if (currentPage >= pageCount
                && currentPage > 0
                && pageCount > 0) {
            currentPage = pageCount - 1;
        }

        List<Integer> pages = getPageNumbers(currentPage, pageCount);

        modelAndView.addObject("routeList", getRouteList(session, currentPage, searchText));
        modelAndView.addObject("routeListFull", getRouteList(session, -1, searchText));
        modelAndView.addObject("pageNumber", currentPage);
        modelAndView.addObject("pageCount", pageCount);
        modelAndView.addObject("pagination", pages);
        modelAndView.addObject("paginationUrl", paginationUrl);
        modelAndView.addObject("searchText", searchText);
    }

    /**
     * Get Route, Station, RouteStation model in List and hMap
     * Get routes by "routeList" key, route station list by "routeStationMap" key, stations by "stationMap" key
     *
     * @param currentPage
     * @param searchText
     * @return Map<String, Object> returns null if CoreTripRoutingControl not initialized or all models not exist by contract id
     */
    protected Map<String, Object> getRouteStationMapModel(HttpSession session, Integer currentPage, String searchText) {

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            CoreStation coreStation = tripRoutingControl.getCoreStation();
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();

            Map<String, Object> mapModels = new HashMap<>();

            List<Station> freeStationList = null;
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<Station> tempFreeStationList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempFreeStationList = coreStation.getListFreeStations(contract.getId());

                    if (tempFreeStationList != null && tempFreeStationList.size() > 0) {
                        if (freeStationList == null) freeStationList = new ArrayList<>();
                        {
                            freeStationList.addAll(tempFreeStationList);
                        }
                    }
                }
            } else {
                // Get list of free stations which is not bind to any routes
                freeStationList = coreStation.getListFreeStations(MainController.getUserContractId(session));
            }


            if (freeStationList != null) {
                mapModels.put("freeStationList", freeStationList);
            }

            // Get list of routes by contract id
            List<Route> routeList = coreRoute.getListByContract(MainController.getUserContractId(session), searchText, currentPage.longValue());

            if (routeList != null) {
                // Make route station map by route id
                Map<Long, List<RouteStation>> routeStationMap = new HashMap<>();
                // Make station map by its id
                Map<Long, Station> stationMap = new HashMap<>();

                for (Route route : routeList) {
                    if (route != null && route.getId() != null) {
                        // Get route station list by route id
                        List<RouteStation> routeStationList = coreRouteStation.getByRoute(route.getId());

                        if (routeStationList != null) {

                            routeStationMap.put(route.getId(), routeStationList);

                            // Get stations by station id
                            for (RouteStation routeStation : routeStationList) {
                                if (routeStation.getStationId() != null) {
                                    Station station = coreStation.get(routeStation.getStationId());

                                    if (station != null && station.getId() != null) {
                                        stationMap.put(station.getId(), station);
                                    }
                                }
                            }

                        }
                    }
                }

                // After getting all models from core, put it in our map model
                mapModels.put("routeList", routeList);
                mapModels.put("routeStationMap", routeStationMap);
                mapModels.put("stationMap", stationMap);

                return mapModels;
            }
        }

        return null;
    }

    /**
     * Get Route, Station, RouteStation model in List and hMap
     * Get routes by "routeList" key, route station list by "routeStationMap" key, stations by "stationMap" key
     *
     * @param currentPage
     * @param searchText
     * @return Map<String, Object> returns null if CoreTripRoutingControl not initialized or all models not exist by contract id
     */
    protected Map<String, Object> getRouteStationMapModelSingle(HttpSession session, Long routeId, Integer currentPage, String searchText) {

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            CoreStation coreStation = tripRoutingControl.getCoreStation();
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();

            Map<String, Object> mapModels = new HashMap<>();

            List<Station> freeStationList = null;
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<Station> tempFreeStationList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempFreeStationList = coreStation.getListFreeStations(contract.getId());

                    if (tempFreeStationList != null && tempFreeStationList.size() > 0) {
                        if (freeStationList == null) freeStationList = new ArrayList<>();
                        {
                            freeStationList.addAll(tempFreeStationList);
                        }
                    }
                }
            } else {
                // Get list of free stations which is not bind to any routes
                freeStationList = coreStation.getListFreeStations(MainController.getUserContractId(session));
            }


            if (freeStationList != null) {
                mapModels.put("freeStationList", freeStationList);
            }

            // Get list of routes by contract id
            List<Route> routeList = new ArrayList<>();
            routeList.add(coreRoute.get(routeId));

            if (routeList.size() > 0) {
                // Make route station map by route id
                Map<Long, List<RouteStation>> routeStationMap = new HashMap<>();
                // Make station map by its id
                Map<Long, Station> stationMap = new HashMap<>();

                for (Route route : routeList) {
                    if (route != null && route.getId() != null) {
                        // Get route station list by route id
                        List<RouteStation> routeStationList = coreRouteStation.getByRoute(route.getId());

                        if (routeStationList != null) {

                            routeStationMap.put(route.getId(), routeStationList);

                            // Get stations by station id
                            for (RouteStation routeStation : routeStationList) {
                                if (routeStation.getStationId() != null) {
                                    Station station = coreStation.get(routeStation.getStationId());

                                    if (station != null && station.getId() != null) {
                                        stationMap.put(station.getId(), station);
                                    }
                                }
                            }

                        }
                    }
                }

                // After getting all models from core, put it in our map model
                mapModels.put("routeList", routeList);
                mapModels.put("routeStationMap", routeStationMap);
                mapModels.put("stationMap", stationMap);

                return mapModels;
            }
        }

        return null;
    }

    /**
     * Get list of Route by current user's contract id
     *
     * @param currentPage
     * @param searchText
     * @return List<Route> returns null if CoreTripRoutingControl not initialized or all models not exist by contract id
     */
    protected List<Route> getRouteList(HttpSession session, Integer currentPage, String searchText) {

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();

            List<Route> routeList = new ArrayList<>();
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<Route> tempRouteList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempRouteList = coreRoute.getListByContract(contract.getId(), searchText, currentPage.longValue());

                    if (tempRouteList != null && tempRouteList.size() > 0) {
                        {
                            routeList.addAll(tempRouteList);
                        }
                    }
                }
                return routeList;
            } else {
                // Get list of routes by contract id
                return coreRoute.getListByContract(MainController.getUserContractId(session), searchText, currentPage.longValue());
            }


        }

        return null;
    }

    /**
     * Get route by id
     *
     * @param routeId
     * @return Route
     */
    protected Route getRoute(HttpSession session, Long routeId) {
        if (routeId == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            Route route = coreRoute.get(routeId);

            // For security safety, check contract matching
//            if (route != null
//                    && route.getContractId() != null
//                    && route.getContractId().equals(MainController.getUserContractId(session))) {
            return route;
//            }
        }

        return null;
    }

    /**
     * Get station by id
     *
     * @param stationId
     * @return Station
     */
    protected Station getStation(HttpSession session, Long stationId) {
        if (stationId == null || stationId == 0)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreStation coreStation = tripRoutingControl.getCoreStation();
            Station station = coreStation.get(stationId);

            // For security safety, check contract matching
//            if (station != null
//                    && station.getContractId() != null
//                    && station.getContractId().equals(MainController.getUserContractId(session))) {
            return station;
//            }
        }

        return null;
    }

    /**
     * Get route station by id
     *
     * @param rsId - route station id
     * @return RouteStation
     */
    protected RouteStation getRouteStation(HttpSession session, Long rsId) {
        if (rsId == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();
            RouteStation routeStation = coreRouteStation.get(rsId);

            if (routeStation != null) {
                Route route = coreRoute.get(routeStation.getRouteId());
                if (route != null) {
                    // For security safety, check contract matching
//                    if (route.getContractId() != null
//                            && route.getContractId().equals(MainController.getUserContractId(session))) {
                    return routeStation;
//                    }
                }
            }
        }

        return null;
    }

    /**
     * Update a given route into DB
     *
     * @param route
     * @return int if returns zero then successfully completed
     */
    protected int routeEdit(HttpSession session, Route route) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            if (route == null || route.getId() == null)
                return Errors.ERR_OBJECT_IS_NULL;

            if (route.getContractId() != null
                    && route.getContractId().equals(MainController.getUserContractId(session))) {
                // Update
                return tripRoutingControl.getCoreRoute().save(route);
            } else {
                // Given route contract is not matched with current user contract id
                return Errors.ERR_ROUTE_ACCESS;
            }
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Update a given route into DB without checking access by contract
     *
     * @param route
     * @return int if returns zero then successfully completed
     */
    protected int routeEditWithoutAccessCheck(HttpSession session, Route route) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            if (route != null && route.getId() != null) {
                return tripRoutingControl.getCoreRoute().save(route);
            }
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Get route station list by route id from DB
     *
     * @param routeId
     * @return Route
     */
    protected List<RouteStation> getRouteStationListByRoute(Long routeId) {
        if (routeId == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRouteStation coreRouteStation = tripRoutingControl.getCoreRouteStation();

            return coreRouteStation.getByRoute(routeId);
        }

        return null;
    }

    /**
     * Get list of MobjectBig by current user id or contract id
     *
     * @return List<MobjectBig>
     */
    protected List<MobjectBig> getMobjectList(HttpSession session) {
        List<MobjectBig> mObjectList = null;

        mObjectList = monitoringController.getMobjectsFromCore(session);

        // Sort list of objects
        if (mObjectList != null && mObjectList.size() > 0) {
            Collections.sort(mObjectList);
        }

        return mObjectList;
    }

    /**
     * Check whether user has access to edit given mobject
     *
     * @param mobjectId
     * @return boolean return true if has access otherwise false
     */
    protected boolean hasAccessEditForMobject(HttpSession session, Long mobjectId) {
        List<MobjectBig> mObjectList = getMobjectList(session);

        if (mObjectList != null && mobjectId != null) {
            MobjectBig mobjectBig = new MobjectBig();
            mobjectBig.setId(mobjectId);

            return mObjectList.contains(mobjectBig);
        }

        return false;
    }

    /**
     * Get route access list by current user's contract id
     *
     * @return List<StaffAccess>
     */
    protected List<StaffAccess> getRouteAccessListByStaffId(Long staffId) {
        if (staffId == null) {
            return null;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreStaffAccess coreStaffAccess = tripRoutingControl.getCoreStaffAccess();

            return coreStaffAccess.getListByStaff(staffId);
        }

        return null;
    }

    /**
     * Get number pages of found route by search text
     *
     * @param searchText
     * @return Integer
     */
    protected Integer getNumRoutePages(HttpSession session, String searchText) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreRoute coreRoute = tripRoutingControl.getCoreRoute();
            return (int) coreRoute.getListByContractPages(MainController.getUserContractId(session), searchText);
        }

        return 0;
    }

    /**
     * Make page numbers based on a given currentPage and maxPage
     *
     * @param currentPage
     * @param maxPages
     * @return
     */
    protected List<Integer> getPageNumbers(Integer currentPage, Integer maxPages) {
        List<Integer> list = new ArrayList<>();
        if (currentPage != null && maxPages != null) {
            if (maxPages > 0) list.add(0); // 1 page
            if (maxPages > 1) list.add(1); // 2 page
            if (maxPages > 2) list.add(2); // 3 page

            if (currentPage > 1) {
                if (!list.contains(currentPage - 1) && (currentPage - 1 < maxPages))
                    list.add(currentPage - 1); // current - 1

                if (!list.contains(currentPage) && (currentPage < maxPages))
                    list.add(currentPage); // current

                if (!list.contains(currentPage + 1) && (currentPage + 1 < maxPages))
                    list.add(currentPage + 1); // current + 1
            }


            if (!list.contains(maxPages - 3) && (maxPages - 3 > 0)) list.add(maxPages - 3); // last-2 page
            if (!list.contains(maxPages - 2) && (maxPages - 3 > 0)) list.add(maxPages - 2); // last-1 page
            if (!list.contains(maxPages - 1) && (maxPages - 3 > 0)) list.add(maxPages - 1); // last page

            Collections.sort(list);

        }
        return list;
    }

    /**
     * Converts String type float value into Float.
     * Before convert, replaves all commas (,) to dots (.)
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return float value of result
     */
    protected Float strToFloat(String value, Float defaultValue) {
        try {
            String valueWithDot = value.replaceAll(",", ".");
            valueWithDot = valueWithDot.replaceAll(" ", "");
            Float f = Float.valueOf(valueWithDot);
            return f;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type double value into Float.
     * Before convert, replaves all commas (,) to dots (.)
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return double value of result
     */
    protected Double strToDouble(String value, Double defaultValue) {
        try {
            String valueWithDot = value.replaceAll(",", ".");
            valueWithDot = valueWithDot.replaceAll(" ", "");
            Double d = Double.valueOf(valueWithDot);
            return d;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type int value into Integer.
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return float value of result
     */
    protected Integer strToInt(String value, Integer defaultValue) {
        try {
            String valueWithDot = value.replaceAll(" ", "");
            Integer v = Integer.valueOf(valueWithDot);
            return v;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type int value into Long.
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return Long value of result
     */
    protected Long strToLong(String value, Long defaultValue) {
        try {
            String valueWithDot = value.replaceAll(" ", "");
            Long v = Long.valueOf(valueWithDot);
            return v;
        } catch (Exception e) {
        }
        return defaultValue;
    }

    /**
     * Converts String type int value into Long from string array
     *
     * @param value        value to convert
     * @param defaultValue default value if there is some error
     * @return Long value of result
     */
    protected Long strToLongExtended(String value, Long defaultValue) {
        try {
            String strValueForLong = value.replaceAll(" ", "");

            strValueForLong = strValueForLong.replaceAll("\\[", "");
            strValueForLong = strValueForLong.replaceAll("]", "");
            strValueForLong = strValueForLong.replaceAll("\"", "");

            Long resultVal = Long.valueOf(strValueForLong);
            return resultVal;
        } catch (Exception e) {
        }
        return defaultValue;
    }


    /**
     * Convert date string to Timestamp
     *
     * @param value
     * @param dateFormat   might be "dd.MM.yyyy HH:mm:ss.SSS" or
     *                     "dd.MM.yyyy HH:mm:ss" or "dd.MM.yyyy HH:mm"
     * @param defaultValue
     * @return Timestamp
     */
    protected Timestamp strToTimestamp(String value, String dateFormat, Long defaultValue) {
        if (value == null) {
            return new Timestamp(defaultValue);
        }
        SimpleDateFormat dateFormat1 = new SimpleDateFormat(dateFormat);
        Date date;
        try {
            date = dateFormat1.parse(value);
        } catch (ParseException e) {
            date = new Date(defaultValue);
        }

        return new Timestamp(date.getTime());
    }


}
