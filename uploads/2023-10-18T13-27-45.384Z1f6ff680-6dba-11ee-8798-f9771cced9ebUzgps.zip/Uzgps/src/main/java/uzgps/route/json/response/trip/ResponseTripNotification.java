package uzgps.route.json.response.trip;


import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.core.CoreMain;
import uz.netex.routing.database.tables.Event;
import uz.netex.routing.database.tables.Notification;
import uzgps.route.json.models.trip.TripRouteNotification;
import uzgps.route.json.models.trip.TripRouteStationNotification;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 8/28/2015.
 */
public class ResponseTripNotification {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private List<TripRouteNotification> notificationList;
    private Long count;

    public ResponseTripNotification() {
        this.notificationList = null;
        this.count = 0L;
    }

    public ResponseTripNotification(List<Notification> notifications, Long count, CoreMain coreMain) {
        this();

        this.notificationList = getFilteredNotificationList(notifications, coreMain);
        this.count = count;
    }

    @JsonProperty("nots")
    public List<TripRouteNotification> getNotificationList() {
        return notificationList;
    }

    public void setNotificationList(List<TripRouteNotification> notificationList) {
        this.notificationList = notificationList;
    }

    @JsonProperty("count")
    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }

    public List<TripRouteNotification> getFilteredNotificationList(List<Notification> notifications, CoreMain coreMain) {
        if (notifications != null) {
            List<TripRouteNotification> notificationList = new ArrayList<>();

            for (Notification notification : notifications) {
                if (notification != null) {
                    try {
                        switch (notification.getEventTypeId().intValue()) {
                            case Event.EVENT_ROUTE_START:
                                notificationList.add(new TripRouteNotification(notification, coreMain));
                                break;
                            case Event.EVENT_ROUTE_END:
                                notificationList.add(new TripRouteNotification(notification, coreMain));
                                break;
                            case Event.EVENT_ROUTE_OUT_OF_PATH:
                                notificationList.add(new TripRouteNotification(notification, coreMain));
                                break;
                            case Event.EVENT_ROUTE_BACK_TO_PATH:
                                notificationList.add(new TripRouteNotification(notification, coreMain));
                                break;
                            case Event.EVENT_STATION_ENTER:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_STATION_EXIT:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_DEVIATION_ENTER_LATE:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_DEVIATION_ENTER_EARLY:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_DEVIATION_EXIT_LATE:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_DEVIATION_EXIT_EARLY:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_STATION_IN_PARKING_TIME_EXEED:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_STATION_OUT_PARKING_TIME_EXEED:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            case Event.EVENT_STATION_SKIPPED:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                            default:
                                notificationList.add(new TripRouteStationNotification(notification, coreMain));
                                break;
                        }
                    } catch (Exception e) {
                            logger.error("Error in getFilteredNotificationList", e);
                    }
                }
            }

            return notificationList;
        }

        return null;
    }

    @Override
    public String toString() {
        return "ResponseTripNotification{" +
                "notificationList=" + notificationList +
                ", count=" + count +
                '}';
    }
}
