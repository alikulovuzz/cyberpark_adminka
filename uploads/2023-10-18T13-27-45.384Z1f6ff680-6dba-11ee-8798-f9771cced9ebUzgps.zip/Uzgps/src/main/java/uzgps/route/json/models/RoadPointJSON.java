package uzgps.route.json.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.RoadPoint;

import java.sql.Timestamp;

/**
 * Created by Gayratjon on 5/19/2015.
 */
public class RoadPointJSON extends RoadPoint {

    public RoadPointJSON() {
        super();
    }

    public RoadPointJSON(RoadPoint roadPoint) {
        super();

        if (roadPoint != null) {
            this.id = roadPoint.getId();
            this.routeId = roadPoint.getRouteId();
            this.routeIdOld = roadPoint.getRouteIdOld();
            this.latitude = roadPoint.getLatitude();
            this.longitude = roadPoint.getLongitude();
            this.realPoint = roadPoint.getRealPoint();
            this.priority = roadPoint.getPriority();
        }
    }

    @JsonProperty("rid")
    @Override
    public Long getRouteId() {
        return super.getRouteId();
    }

    @JsonProperty("lat")
    @Override
    public Double getLatitude() {
        return super.getLatitude();
    }

    @JsonProperty("lon")
    @Override
    public Double getLongitude() {
        return super.getLongitude();
    }

    @JsonProperty("rpt")
    @Override
    public Integer getRealPoint() {
        return super.getRealPoint();
    }

    @JsonProperty("pr")
    @Override
    public Integer getPriority() {
        return super.getPriority();
    }

    /**
     * <<========================== JSON IGNORE FIELDS ==========================>>
     */

    @JsonIgnore
    @Override
    public Long getRouteIdOld() {
        return super.getRouteIdOld();
    }

    @JsonIgnore
    @Override
    public Long getMobjectId() {
        return super.getMobjectId();
    }

    @JsonIgnore
    @Override
    public String getStatus() {
        return super.getStatus();
    }

    @JsonIgnore
    @Override
    public Timestamp getRegDate() {
        return super.getRegDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getModDate() {
        return super.getModDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getExpDate() {
        return super.getExpDate();
    }
}
