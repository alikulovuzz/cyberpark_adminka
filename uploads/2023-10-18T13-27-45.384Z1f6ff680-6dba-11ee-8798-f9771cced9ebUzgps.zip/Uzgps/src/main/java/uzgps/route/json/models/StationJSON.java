package uzgps.route.json.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.locationtech.jts.geom.Geometry;
import uz.netex.routing.database.tables.Station;
import uz.netex.routing.database.tables.TripStation;

import java.sql.Timestamp;

/**
 * Created by Gayratjon on 5/21/2015.
 */
public class StationJSON extends Station {

    public StationJSON() {
        super();
    }

    public StationJSON(Station station) {
        super();

        if (station != null) {
            this.id = station.getId();
            this.contractId = station.getContractId();
            this.name = station.getName();
            this.useName = station.getUseName();
            this.shapeType = station.getShapeType();
            this.shapeRadius = station.getShapeRadius();
            this.shapeArea = station.getShapeArea();
            this.shapePerimeter = station.getShapePerimeter();
            this.shapeColor = station.getShapeColor();
            this.fontColor = station.getFontColor();
            this.fontSize = station.getFontSize();
            this.wkt = station.getWkt();
            this.wktPath = station.getWktPath();
        }
    }

    public StationJSON(TripStation tripStation) {
        super();

        if (tripStation != null) {
            this.id = tripStation.getId();
            this.contractId = tripStation.getContractId();
            this.name = tripStation.getName();
            this.useName = tripStation.getUseName();
            this.shapeType = tripStation.getShapeType();
            this.shapeRadius = tripStation.getShapeRadius();
            this.shapeArea = tripStation.getShapeArea();
            this.shapePerimeter = tripStation.getShapePerimeter();
            this.shapeColor = tripStation.getShapeColor();
            this.fontColor = tripStation.getFontColor();
            this.fontSize = tripStation.getFontSize();
            this.wkt = tripStation.getWkt();
            this.wktPath = tripStation.getWktPath();
        }
    }

    @JsonProperty("nm")
    @Override
    public String getName() {
        return super.getName();
    }

    @JsonProperty("unm")
    @Override
    public Integer getUseName() {
        return super.getUseName();
    }

    @JsonProperty("sht")
    @Override
    public Integer getShapeType() {
        return super.getShapeType();
    }

    @JsonProperty("shr")
    @Override
    public Double getShapeRadius() {
        return super.getShapeRadius();
    }

    @JsonProperty("sha")
    @Override
    public Double getShapeArea() {
        return super.getShapeArea();
    }

    @JsonProperty("shp")
    @Override
    public Double getShapePerimeter() {
        return super.getShapePerimeter();
    }

    @JsonProperty("shc")
    @Override
    public String getShapeColor() {
        return super.getShapeColor();
    }

    @JsonProperty("ftc")
    @Override
    public String getFontColor() {
        return super.getFontColor();
    }

    @JsonProperty("fts")
    @Override
    public Integer getFontSize() {
        return super.getFontSize();
    }

    @JsonProperty("wkt")
    @Override
    public String getWkt() {
        return super.getWkt();
    }

    @JsonProperty("wktp")
    @Override
    public String getWktPath() {
        return super.getWktPath();
    }


    /**
     * <<========================== JSON IGNORE FIELDS ==========================>>
     */


    @JsonIgnore
    @Override
    public Geometry getWktPathGeometry() {
        return super.getWktPathGeometry();
    }

    @JsonIgnore
    @Override
    public Geometry getWktGeometry() {
        return super.getWktGeometry();
    }

    @JsonIgnore
    @Override
    public Long getContractId() {
        return super.getContractId();
    }

    @JsonIgnore
    @Override
    public Long getMobjectId() {
        return super.getMobjectId();
    }

    @JsonIgnore
    @Override
    public String getStatus() {
        return super.getStatus();
    }

    @JsonIgnore
    @Override
    public Timestamp getRegDate() {
        return super.getRegDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getModDate() {
        return super.getModDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getExpDate() {
        return super.getExpDate();
    }
}
