package uzgps.route;

import com.fasterxml.jackson.databind.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.database.tables.Route;
import uz.netex.routing.database.tables.StaffAccess;
import uz.netex.uzgps.errors.Errors;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.persistence.User;
import uzgps.route.json.response.ResponseBase;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by G'ayrat on 05.05.15.
 */
@Controller
public class RouteAccessController extends AbstractRoutingController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTE_ACCESS = "/route/route-access.htm";
    private final static String VIEW_ROUTE_ACCESS = "route/route-access";

    private final static String URL_AJAX_ROUTE_ACCESS_MANAGE = "/route/ajax-route-access-manage.htm";
    private final static String VIEW_AJAX_ROUTE_ACCESS_MANAGE = "route/ajax-route-access-content";

    @Autowired
    SettingsService settingsService;

    @Override
    protected String getActiveRouteTabMenu() {
        return "access";
    }

    @RequestMapping(value = URL_ROUTE_ACCESS)
    public ModelAndView accessMain(HttpSession session) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_ACCESS);

        List<User> staffList = settingsService.getUsersByContractIdAndRole(MainController.getUserContractId(session), UZGPS_CONST.USER_ROLE_USER);
        modelAndView.addObject("staffList", staffList);

        putRouteListModelToView(session, modelAndView, "0", "", URL_AJAX_ROUTE_ACCESS_MANAGE);

        if (staffList != null && staffList.size() > 0) {
            Long staffId = staffList.get(0).getId();
            User user = settingsService.getUserById(staffId);
            modelAndView.addObject("staff", user);

            // Get route access list for staff
            List<StaffAccess> routeAccessList = getRouteAccessListByStaffId(staffId);
            // Get route list
            List<Route> routeList = (List<Route>) modelAndView.getModel().get("routeList");
            modelAndView.addObject("routeAccessMap", getRouteAccessMap(routeAccessList, routeList));
        }

        return modelAndView;
    }

    /**
     * Manage route access: save or edit accessed route and remove unaccessedd route for a selected staff
     *
     * @param sfId
     * @param accessedRoutes
     * @param unaccessedRoutes
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_AJAX_ROUTE_ACCESS_MANAGE)
    public void accessManage(HttpSession session,
                             HttpServletResponse response,
                             HttpServletRequest request,
                             @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber,
                             @RequestParam(value = "search", required = false, defaultValue = "") String searchText,
                             @RequestParam(value = "cmd", required = false) String cmd,
                             @RequestParam(value = "staff-id", required = false) String sfId,
                             @RequestParam(value = "accessed-routes[]", required = false) Long[] accessedRoutes,
                             @RequestParam(value = "unaccessed-routes[]", required = false) Long[] unaccessedRoutes)
            throws Exception {

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_ROUTE_ACCESS_MANAGE);

        Long staffId = strToLong(sfId, null);

        if (!containsStaff(session, staffId)) {
            return;
        }

        User user = settingsService.getUserById(staffId);
        modelAndView.addObject("staff", user);

        // Get route access list for staff
        List<StaffAccess> routeAccessList = getRouteAccessListByStaffId(staffId);
        putRouteListModelToView(session, modelAndView, pageNumber, searchText, URL_AJAX_ROUTE_ACCESS_MANAGE);
        // Get route list
        List<Route> routeList = (List<Route>) modelAndView.getModel().get("routeList");

        if (cmd != null) {
            if (cmd.equals("edit")) {
                // Save or delete route access

                if (accessedRoutes != null) {
                    // Set an access
                    if (routeAccessList != null && routeAccessList.size() > 0) {
                        for (Long routeId : accessedRoutes) {
                            if (containsRoute(routeList, routeId)) {
                                StaffAccess staffAccess = getStaffAccess(routeAccessList, routeId);

                                if (staffAccess == null) {
                                    staffAccess = new StaffAccess();
                                    staffAccess.setStaffId(staffId);
                                    staffAccess.setRouteId(routeId);
                                    staffAccess.setStaffAccess(1);
                                } else {
                                    staffAccess.setStaffAccess(1);
                                    staffAccess.setModDate(new Timestamp(System.currentTimeMillis()));
                                }

                                // Insert
                                routeAccessSave(staffAccess);
                            }
                        }
                    } else {
                        for (Long routeId : accessedRoutes) {
                            if (containsRoute(routeList, routeId)) {
                                StaffAccess staffAccess = new StaffAccess();
                                staffAccess.setStaffId(staffId);
                                staffAccess.setRouteId(routeId);
                                staffAccess.setStaffAccess(1);

                                // Insert
                                routeAccessSave(staffAccess);
                            }
                        }
                    }
                }

                if (unaccessedRoutes != null) {
                    // Set no access
                    if (routeAccessList != null && routeAccessList.size() > 0) {
                        for (Long routeId : unaccessedRoutes) {
                            if (containsRoute(routeList, routeId)) {
                                for (StaffAccess staffAccess : routeAccessList) {
                                    if (staffAccess.getRouteId().equals(routeId)) {
                                        staffAccess.setStaffAccess(0);
                                        staffAccess.setModDate(new Timestamp(System.currentTimeMillis()));
                                        // Update
                                        routeAccessSave(staffAccess);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        routeAccessList = getRouteAccessListByStaffId(staffId);

        modelAndView.addObject("routeAccessMap", getRouteAccessMap(routeAccessList, routeList));
        modelAndView.addObject("userAccessList", getUserAccessList(session));

        // Get rendered html from view
        View resolvedView = htmlViewResolver.resolveViewName(modelAndView.getViewName(), response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(modelAndView.getModel(), request, mockResp);

        // Make json response
        ResponseBase responseBase = new ResponseBase();
        responseBase.setHtml(mockResp.getContentAsString().trim());

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseBase);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Check whether a staff has an access for the route
     * if has an access put 1 for route id key, otherwise put 0
     *
     * @param routeAccessList
     * @param routeList
     * @return Map<Long, Integer>
     */
    private Map<Long, Integer> getRouteAccessMap(List<StaffAccess> routeAccessList, List<Route> routeList) {
        Map<Long, Integer> routeAccessMap = new HashMap<>();

        if (routeAccessList != null && routeList != null) {
            for (Route route : routeList) {
                if (route.getId() != null) {
                    for (StaffAccess staffAccess : routeAccessList) {
                        // Check whether a staff has an access for the route
                        if (staffAccess.getRouteId().equals(route.getId())) {
                            routeAccessMap.put(route.getId(), staffAccess.getStaffAccess());

                            break;
                        }
                    }
                }
            }
        }

        return routeAccessMap;
    }

    /**
     * Insert or update StaffAccess
     *
     * @param staffAccess
     * @return
     */
    private int routeAccessSave(StaffAccess staffAccess) {
        if (staffAccess == null
                || staffAccess.getStaffId() == null
                || staffAccess.getRouteId() == null) {
            return Errors.ERR_OBJECT_IS_NULL;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreStaffAccess().save(staffAccess);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Get existence StaffAccess
     *
     * @param routeAccessList
     * @param routeId
     * @return StaffAccess
     */
    private StaffAccess getStaffAccess(List<StaffAccess> routeAccessList, Long routeId) {
        if (routeAccessList == null || routeId == null) {
            return null;
        }

        for (StaffAccess routeAccess : routeAccessList) {
            if (routeAccess.getRouteId().equals(routeId)) {
                return routeAccess;
            }
        }

        return null;
    }

    /**
     * Check if a given staffId belongs to the current user's contract
     * @param staffId
     * @return true if contains otherwise false
     */
    private boolean containsStaff(HttpSession session, Long staffId) {
        if (staffId == null) {
            return false;
        }

        List<User> staffList = settingsService.getCustomerUsersByContractId(MainController.getUserContractId(session));

        for (User staff : staffList) {
            if (staff.getId().equals(staffId)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if a given routeId belongs to the current user's contract
     *
     * @param routeList
     * @param routeId
     * @return true if contains otherwise false
     */
    private boolean containsRoute(List<Route> routeList, Long routeId) {
        if (routeList == null || routeId == null) {
            return false;
        }

        for (Route route: routeList) {
            if (route != null && route.getId().equals(routeId)) {
                return true;
            }
        }

        return false;
    }
}
