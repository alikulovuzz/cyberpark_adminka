package uzgps.route.json.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.RouteStation;
import uzgps.route.json.models.RouteStationJSON;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 5/25/2015.
 */
public class ResponseTimeEvent extends AbstractResponse {
    private List<RouteStationJSON> routeStationJSONList;

    public ResponseTimeEvent() {
        this.routeStationJSONList = null;
        this.html = null;
    }

    @JsonProperty("rsList")
    public List<RouteStationJSON> getRouteStationJSONList() {
        return routeStationJSONList;
    }

    public void setRouteStationJSONList(List<RouteStation> routeStationList) {
        if (routeStationList != null) {
            this.routeStationJSONList = new ArrayList<>();

            for (RouteStation routeStation : routeStationList) {
                this.routeStationJSONList.add(new RouteStationJSON(routeStation));
            }
        }
    }
}
