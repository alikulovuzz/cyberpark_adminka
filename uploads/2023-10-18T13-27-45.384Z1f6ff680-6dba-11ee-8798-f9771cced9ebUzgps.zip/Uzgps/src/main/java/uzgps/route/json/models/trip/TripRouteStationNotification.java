package uzgps.route.json.models.trip;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.core.CoreMain;
import uz.netex.routing.database.tables.Notification;
import uzgps.common.CommonUtils;

/**
 * Created by Gayratjon on 8/28/2015.
 */
public class TripRouteStationNotification extends TripRouteNotification {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private String stationName;
    private String deviationTime;
    private String deviationMaxTime;

    public TripRouteStationNotification(Notification notification, CoreMain coreMain) {
        super(notification, coreMain);

        try {
            if (notification != null) {
                // Set current working station name
                this.stationName = notification.getValueStr2();

                if (notification.getEventTypeId() != null && notification.getEventTypeId().equals(8L) || notification.getEventTypeId().equals
                        (9L)) {
                    this.deviationTime = CommonUtils.millisToHoursAndMinutes(notification.getValueLong2());
                    this.deviationMaxTime = CommonUtils.millisToHoursAndMinutes(notification.getValueLong1());
                }
            }
        } catch (Exception e) {
            logger.error("Error in TripRouteStationNotification", e);
        }

    }

    @JsonProperty("stnm")
    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    @JsonProperty("stdt")
    public String getDeviationTime() {
        return deviationTime;
    }

    public void setDeviationTime(String deviationTime) {
        this.deviationTime = deviationTime;
    }

    @JsonProperty("stdmt")
    public String getDeviationMaxTime() {
        return deviationMaxTime;
    }

    public void setDeviationMaxTime(String deviationMaxTime) {
        this.deviationMaxTime = deviationMaxTime;
    }
}
