package uzgps.route.json.models.trip;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.core.CoreMain;
import uz.netex.routing.database.tables.Notification;
import uzgps.common.CommonUtils;

/**
 * Created by Gayratjon on 8/28/2015.
 */
public class TripRouteNotification extends AbstractTripNotification {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private String deviationEnterLate;
    private String deviationEnterLateMax;

    private String deviationEnterEarly;
    private String deviationEnterEarlyMax;

    private String deviationExitLate;
    private String deviationExitLateMax;

    private String deviationExitEarly;
    private String deviationExitEarlyMax;

    public TripRouteNotification(Notification notification, CoreMain coreMain) {
        super(notification, coreMain);

        try {
            if (notification.getEventTypeId() != null && notification.getEventTypeId() > 50) {
                this.deviationEnterLate = CommonUtils.millisToHoursAndMinutes(notification.getValueLong2());
                this.deviationEnterLateMax = CommonUtils.millisToHoursAndMinutes(notification.getValueLong1());

                this.deviationEnterEarly = CommonUtils.millisToHoursAndMinutes(notification.getValueLong2());
                this.deviationEnterEarlyMax = CommonUtils.millisToHoursAndMinutes(notification.getValueLong1());

                this.deviationExitLate = CommonUtils.millisToHoursAndMinutes(notification.getValueLong2());
                this.deviationExitLateMax = CommonUtils.millisToHoursAndMinutes(notification.getValueLong1());

                this.deviationExitEarly = CommonUtils.millisToHoursAndMinutes(notification.getValueLong2());
                this.deviationExitEarlyMax = CommonUtils.millisToHoursAndMinutes(notification.getValueLong1());
            }
        } catch (Exception e) {
            logger.error("Error in TripRouteNotification", e);
        }
    }

    @JsonProperty("denl")
    public String getDeviationEnterLate() {
        return deviationEnterLate;
    }

    public void setDeviationEnterLate(String deviationEnterLate) {
        this.deviationEnterLate = deviationEnterLate;
    }

    @JsonProperty("denlm")
    public String getDeviationEnterLateMax() {
        return deviationEnterLateMax;
    }

    public void setDeviationEnterLateMax(String deviationEnterLateMax) {
        this.deviationEnterLateMax = deviationEnterLateMax;
    }

    @JsonProperty("dexl")
    public String getDeviationExitLate() {
        return deviationExitLate;
    }

    public void setDeviationExitLate(String deviationExitLate) {
        this.deviationExitLate = deviationExitLate;
    }

    @JsonProperty("dexlm")
    public String getDeviationExitLateMax() {
        return deviationExitLateMax;
    }

    public void setDeviationExitLateMax(String deviationExitLateMax) {
        this.deviationExitLateMax = deviationExitLateMax;
    }

    @JsonProperty("dene")
    public String getDeviationEnterEarly() {
        return deviationEnterEarly;
    }

    public void setDeviationEnterEarly(String deviationEnterEarly) {
        this.deviationEnterEarly = deviationEnterEarly;
    }

    @JsonProperty("denem")
    public String getDeviationEnterEarlyMax() {
        return deviationEnterEarlyMax;
    }

    public void setDeviationEnterEarlyMax(String deviationEnterEarlyMax) {
        this.deviationEnterEarlyMax = deviationEnterEarlyMax;
    }

    @JsonProperty("dexe")
    public String getDeviationExitEarly() {
        return deviationExitEarly;
    }

    public void setDeviationExitEarly(String deviationExitEarly) {
        this.deviationExitEarly = deviationExitEarly;
    }

    @JsonProperty("dexem")
    public String getDeviationExitEarlyMax() {
        return deviationExitEarlyMax;
    }

    public void setDeviationExitEarlyMax(String deviationExitEarlyMax) {
        this.deviationExitEarlyMax = deviationExitEarlyMax;
    }
}
