package uzgps.route;

import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GPSTrackPointList;
import uz.netex.datatype.MobjectBig;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.database.pojos.TripStatuses;
import uz.netex.routing.database.tables.Trip;
import uz.netex.routing.database.tables.TripRoute;
import uz.netex.routing.database.tables.TripRouteStation;
import uzgps.admin.AdminService;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.kml.KMLObjectTrack;
import uzgps.map.models.ResponseNearestPoint;
import uzgps.map.models.TrackPopupData;
import uzgps.persistence.Contract;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.CustomDistancesForTracking;
import uzgps.route.json.response.trip.ResponseTripRouteList;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Gayratjon on 6/4/2015
 */
@Controller
public class RouteHistoryController extends AbstractRoutingController {

    @Autowired
    private MonitoringController monitoringController;

    @Autowired
    AdminService adminService;

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTE_HISTORY_MAIN = "/route/history.htm";
    private final static String URL_ROUTE_HISTORY_FAST_LINK = "/route/history-form.htm";
    private final static String VIEW_ROUTE_HISTORY_MAIN = "route/route-history";

    private final static String URL_AJAX_TRIP_HISTORY_LIST = "/route/trip-history-list.htm";
    private final static String VIEW_AJAX_TRIP_HISTORY_LIST = "route/ajax-trip-history-list";

    private final static String URL_AJAX_SINGLE_TRIP_HISTORY = "/route/ajax-single-trip-history.htm";
    private final static String VIEW_AJAX_SINGLE_TRIP_HISTORY = "route/ajax-single-trip-control";

    private final static String URL_AJAX_TRIP_HISTORY_TRACKS = "/route/trip-history-tracks.htm";

    private final static String URL_MAP_NEAREST_TRACK_POINT = "/route/nearest-track-point.htm";
    private final static String VIEW_MAP_OBJECT_TRACKS_TABLE = "route/ajax-tracks-table";

    /**
     * Get map type
     *
     * @return Integer
     */
    @ModelAttribute("mapType")
    private Integer getMapType(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        return contractSettings.getMapType().intValue();
    }

    @Override
    protected String getActiveRouteTabMenu() {
        return "history";
    }

    @RequestMapping(value = URL_ROUTE_HISTORY_MAIN)
    private ModelAndView routeHistoryMain(HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_HISTORY_MAIN);

        List<MobjectBig> mobjectList = monitoringController.getMobjects(session, false);

        if (mobjectList != null && mobjectList.size() > 0) {
            Collections.sort(mobjectList);
            modelAndView.addObject("mObjectList", mobjectList);
        }

        modelAndView.addObject("contractId", MainController.getUserContractId(session));

        ContractSettings contractSettings = mainController.getContractSettings(session);
        int dottedLineThickness = 1;
        if (contractSettings != null) {
            dottedLineThickness = contractSettings.getDottedLineThickness();
        }
        modelAndView.addObject("dottedLineThickness", dottedLineThickness);

        putRouteListModelToView(session, modelAndView, "0", "", URL_ROUTE_HISTORY_MAIN);

        return modelAndView;
    }

    @RequestMapping(value = URL_ROUTE_HISTORY_FAST_LINK)
    private ModelAndView routeHistoryFastLink(HttpSession session,
                                              @RequestParam(value = "object-id", required = false) String mObjectIdStr,
                                              @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                              @RequestParam(value = "show-routes", required = false) String showRoutesStr,
                                              @RequestParam(value = "start-date", required = false) String startDate,
                                              @RequestParam(value = "end-date", required = false) String endDate) {
        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_HISTORY_MAIN);

        Long mObjectId = Converters.strToLong(mObjectIdStr, 0L);
        Long contractId = Converters.strToLong(contractIdStr, 0L);

        String fromDate = startDate;
        String toDate = endDate;

        modelAndView.addObject("mObjectId", mObjectId);
        modelAndView.addObject("contractId", contractId);
        modelAndView.addObject("fromDate", fromDate);
        modelAndView.addObject("toDate", toDate);
        modelAndView.addObject("showRoutes", showRoutesStr);

        List<MobjectBig> mobjectList = monitoringController.getMobjects(session, false);

        if (mobjectList != null && mobjectList.size() > 0) {
            Collections.sort(mobjectList);
            modelAndView.addObject("mObjectList", mobjectList);
        }

        modelAndView.addObject("contractId", MainController.getUserContractId(session));

        ContractSettings contractSettings = mainController.getContractSettings(session);
        int dottedLineThickness = 1;
        if (contractSettings != null) {
            dottedLineThickness = contractSettings.getDottedLineThickness();
        }
        modelAndView.addObject("dottedLineThickness", dottedLineThickness);

        putRouteListModelToView(session, modelAndView, "0", "", URL_ROUTE_HISTORY_MAIN);

        return modelAndView;
    }

    @RequestMapping(value = URL_MAP_NEAREST_TRACK_POINT, method = RequestMethod.GET)
    public void getNearestTrackPointForRouteHistory(HttpSession session,
                                                    HttpServletResponse response,
                                                    HttpServletRequest request,
                                                    @RequestParam(value = "object-id", required = false) Long mObjectId,
                                                    @RequestParam(value = "start-date", required = false) String startDateStr,
                                                    @RequestParam(value = "end-date", required = false) String endDateStr,
                                                    @RequestParam(value = "lat", required = false) Double latitude,
                                                    @RequestParam(value = "lon", required = false) Double longitude,
                                                    @RequestParam(value = "radius", required = false) Double radius)
            throws ServletException, IOException {
        if (logger.isDebugEnabled()) {
            logger.debug("Get nearest track point for parameters: object-id={}, start-date={}, end-date={}, radius={}, latitude={}, longitude={}",
                    mObjectId, startDateStr, endDateStr, radius, latitude, longitude);
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        long startDate;
        long endDate;

        startDate = Converters.dateFormatterTimestamp(startDateStr).getTime();
        endDate = Converters.dateFormatterTimestamp(endDateStr).getTime();

        if (mObjectId != null && startDate > 0 && endDate > 0) {

            GPSTrackPoint gpsTrackPoint = coreMain.getPointInRadius(mObjectId, startDate, endDate, latitude, longitude, null);

            if (gpsTrackPoint != null) {
//                Map<String, Object> mapModels = new HashMap<>();
                ContractSettings contractSettings = mainController.getContractSettings(session);

//                MobjectBig mObject = coreMain.getMobjectById(mObjectId);
                SimpleFilterProvider filterProvider = new SimpleFilterProvider();
                filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.trackPopupIgnoredFieldNames(contractSettings)));

                try {
                    // Make json response
                    ResponseNearestPoint responseNearestPoint = new ResponseNearestPoint();

                    responseNearestPoint.setTimestamp(gpsTrackPoint.getTimestamp());
                    responseNearestPoint.setRegDate(gpsTrackPoint.getRegDateLong());
                    responseNearestPoint.setParsingDate(gpsTrackPoint.getParsingDate().getTime());

                    responseNearestPoint.setSpeed(gpsTrackPoint.getSpeed());
                    responseNearestPoint.setOdometer(gpsTrackPoint.getIoData().getOdometer());
                    responseNearestPoint.setMovement(gpsTrackPoint.getIoData().getMovement());
                    responseNearestPoint.setEngineOn(gpsTrackPoint.getEngineOn());

                    responseNearestPoint.setGsmSignalLevel(gpsTrackPoint.getIoData().getGsmSignalLevel());
                    responseNearestPoint.setSatellites(gpsTrackPoint.getSatellites());

                    ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
                    byte[] data = writer.writeValueAsBytes(responseNearestPoint);
                    response.setContentType("application/json");
                    response.setContentLength(data.length);

                    // Write in output stream
                    ServletOutputStream outStream = response.getOutputStream();
                    outStream.write(data);
                    outStream.close();
                    outStream.flush();
                } catch (Exception e) {
                    logger.error("Error: ", e);
                }

            }
        }

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(null);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (Exception e) {
            logger.error("Error: ", e);
        }
    }

    @RequestMapping(value = URL_AJAX_TRIP_HISTORY_LIST)
    private ModelAndView getTripHistoryList(HttpSession session,
                                            @RequestParam(value = "route-id", required = false) String routeIdStr,
                                            @RequestParam(value = "object-id", required = false) String mObjectIdStr,
                                            @RequestParam(value = "contract-id", required = false) String contractIdStr,
                                            @RequestParam(value = "start-trip-id", required = false) String tripTypeStr,
                                            @RequestParam(value = "trip-status", required = false) String tripStatusStr,
                                            @RequestParam(value = "start-date", required = false) String startDate,
                                            @RequestParam(value = "end-date", required = false) String endDate,
                                            @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber) {

        if (logger.isDebugEnabled()) {
            logger.debug("Trip history for parameters: object-id={}, start-date={}, end-date={}, pageNumber={}",
                    routeIdStr, mObjectIdStr, tripTypeStr, tripStatusStr, startDate, endDate, pageNumber);
        }

        Long routeId = Converters.strToLong(routeIdStr, 0L);
        Long mObjectId = Converters.strToLong(mObjectIdStr, 0L);
        Long contractId = Converters.strToLong(contractIdStr, 0L);
        Integer tripType = Converters.strToInt(tripTypeStr, 2);
        Integer tripStatus = Converters.strToInt(tripStatusStr, 0);

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_TRIP_HISTORY_LIST);

        if (mObjectId != null) {
            Date fromDate = Converters.dateFormatterTimestamp(startDate);
            Date toDate = Converters.dateFormatterTimestamp(endDate);

            if (fromDate != null && toDate != null) {
                TripStatuses tripStatuses;

                // Get trip list
                List<Trip> tripList = getTripListByTimeMobjectContractRoute(session, routeId, mObjectId, contractId, tripType, tripStatus,
                        fromDate.getTime(), toDate.getTime(), strToLong(pageNumber, 0L));


                tripStatuses = getTripStatusesByTimeMobjectContractRoute(session, routeId, mObjectId, contractId, tripType,
                        fromDate.getTime(), toDate.getTime());

                if (tripList != null && tripList.size() == 0 && strToInt(pageNumber, 0) > 0) {
                    pageNumber = "0";
                    tripList = getTripListByTimeMobjectContractRoute(session, routeId, mObjectId, contractId, tripType, tripStatus,
                            fromDate.getTime(), toDate.getTime(), strToLong(pageNumber, 0L));

                    tripStatuses = getTripStatusesByTimeMobjectContractRoute(session, routeId, mObjectId, contractId, tripType,
                            fromDate.getTime(), toDate.getTime());
                }

                Trip fullTrip;
                if (tripList != null) {
                    for (Trip trip : tripList) {
                        fullTrip = getTripWithRouteStations(trip);
                        TripRoute tripRoute = fullTrip.getTripRoute();
                        trip.setTripRoute(tripRoute);

                        List<TripRouteStation> tripRouteStationList;

                        if (tripRoute.getTripRouteStationList() != null) {
                            tripRouteStationList = tripRoute.getTripRouteStationList();

                            if (tripRouteStationList.size() > 0) {
                                if (tripRouteStationList.get(0).getTripTimeExit() != null && tripRouteStationList.get(0).getTripTimeExit() > 0) {
                                    trip.setTimeStart(tripRouteStationList.get(0).getTripTimeExit());
                                } else if (tripRouteStationList.get(0).getTimeExit() != null && tripRouteStationList.get(0).getTimeExit() > 0) {
                                    trip.setTimeStart(tripRouteStationList.get(0).getTimeExit());
                                }

                                int indx = tripRouteStationList.size() - 1;
                                if (tripRouteStationList.get(indx).getTripTimeEnter() != null && tripRouteStationList.get(indx).getTripTimeEnter() > 0) {
                                    trip.setTimeEnd(tripRouteStationList.get(indx).getTripTimeEnter());
                                } else if (tripRouteStationList.get(indx).getTimeEnter() != null && tripRouteStationList.get(indx).getTimeEnter() > 0) {
                                    trip.setTimeEnd(tripRouteStationList.get(indx).getTimeEnter());
                                }
                            }
                        }
                    }
                }

                modelAndView.addObject("tripList", tripList);

                modelAndView.addObject("tripStatuses", tripStatuses);

                // Trip page calculation
                Integer currentPage = strToInt(pageNumber, 0);
                Integer pageCount = getTripListByTimeMobjectContractRoutePageCount(session, routeId, mObjectId, contractId, tripType, tripStatus,
                        fromDate.getTime(), toDate.getTime());

                if (currentPage >= pageCount
                        && currentPage > 0
                        && pageCount > 0) {
                    currentPage = pageCount - 1;
                }

                List<Integer> pages = getPageNumbers(currentPage, pageCount);

                modelAndView.addObject("pageNumber", currentPage);
                modelAndView.addObject("pageCount", pageCount);
                modelAndView.addObject("pagination", pages);

                if (tripList != null && tripList.size() == 0) {
                    modelAndView.addObject("emptyTripList", true);
                }
            }
        }

        return modelAndView;
    }

    /**
     * Get Dispatcher view for selected trip
     *
     * @param tpId - Trip id
     * @return ModelAndView
     */
    @RequestMapping(value = URL_AJAX_SINGLE_TRIP_HISTORY)
    private void getTripDispatcherView(HttpServletResponse response,
                                       HttpServletRequest request,
                                       @RequestParam(value = "trip-id", required = false) String tpId) throws Exception {

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_SINGLE_TRIP_HISTORY);
        List<TripRoute> tripRouteList = null;
        Long tripId = strToLong(tpId, null);

        if (tripId != null) {
            Trip trip = getTrip(tripId);

            if (trip != null && trip.getTripRoute() != null) {
                TripRoute tripRoute = trip.getTripRoute();
                List<TripRouteStation> tripRouteStationList = tripRoute.getTripRouteStationList();

                tripRouteList = new ArrayList<>();
                tripRouteList.add(tripRoute);

                // Get Mobject for necessity of its name
                MobjectBig mobjectBig = coreMain.getMobjectById(trip.getMobjectId());
                if (mobjectBig != null) {
                    trip.setMobjectName(mobjectBig.getName());
                }

                modelAndView.addObject("trip", trip);
                modelAndView.addObject("tripRoute", tripRoute);
                modelAndView.addObject("tripRouteStationList", tripRouteStationList);
            }
        }

        // Get rendered html from view
        View resolvedView = htmlViewResolver.resolveViewName(modelAndView.getViewName(), response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(modelAndView.getModel(), request, mockResp);

        // Make json response
        ResponseTripRouteList responseTripRouteList = new ResponseTripRouteList(tripRouteList);
        responseTripRouteList.setHtml(mockResp.getContentAsString().trim());
        Set<String> ignorableFieldNames = new HashSet<>();
        ignorableFieldNames.add("fstList");

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseRouteListFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFieldNames));

            ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseTripRouteList);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    @RequestMapping(value = URL_AJAX_TRIP_HISTORY_TRACKS, method = RequestMethod.GET)
    @ResponseBody
    public KMLObjectTrack getMovableObjectTracksByTripId(@RequestParam(value = "trip-id", required = false) String tpId) {

        if (logger.isDebugEnabled()) {
            logger.debug("Build tracks for parameters: tripId={}", tpId);
        }

        Long tripId = strToLong(tpId, null);
        Long mObjectId = null;
        Long startDate = null;
        Long endDate = null;

        if (tripId != null) {
            Trip trip = getTripForTP(tripId);

            if (trip != null) {
                mObjectId = trip.getMobjectId();
                startDate = trip.getTimeStart();
                if (startDate == null) {
                    startDate = trip.getTimeStartPlanned();
                }

                endDate = trip.getTimeEndPlanned();

                TripRoute tripRoute = trip.getTripRoute();
                if (tripRoute != null && trip.getTripPassStatus() != 100) {
                    Long deactivateTime = tripRoute.getTimeHideTripMillisecond();

                    if (deactivateTime != null && deactivateTime > 0) {
                        // add deactivate time to track end date
                        endDate += deactivateTime * 2;
                    }
                }
            }
        }

        if (mObjectId == null) {
            return null;
        }

        GPSTrackPointList gpsTrackPointList = null;
        if (startDate < endDate) {
            gpsTrackPointList = coreMain.getPointsByDate(mObjectId, startDate, endDate, 0);
        }

        MobjectBig mobject = coreMain.getMobjectById(mObjectId);
        KMLObjectTrack kmlObjectTrack = null;

        Timestamp startDateT = new Timestamp(startDate);
        Timestamp endDateT = new Timestamp(endDate);

        List<CustomDistancesForTracking> distancesList = adminService.getDistanceByObjectAndPeriod(mObjectId, startDateT, endDateT);

        if (gpsTrackPointList != null) {
            kmlObjectTrack = new KMLObjectTrack(mobject, gpsTrackPointList, null, "solid", "#ff0000", 3,
                    gpsTrackPointList.getGpsTrackPoints().size(), distancesList, UZGPS_CONST.TRACK_VIEW_TYPE.BY_DAY.getValue(), null);
        }

        return kmlObjectTrack;
    }

    /**
     * Get number pages of trips
     *
     * @param mObjectId
     * @param fromDate
     * @param toDate
     * @return
     */
    private Integer getTripsPageCount(Long mObjectId, Long fromDate, Long toDate) {
        if (mObjectId == null
                || fromDate == null
                || toDate == null) {
            return 0;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return (int) tripRoutingControl.getCoreTrip().getByTimePages(mObjectId, fromDate, toDate);
        }

        return 0;
    }

    /**
     * Get trip list those which given object ran within given intervals
     *
     * @param mObjectId
     * @param fromDate
     * @param toDate
     * @param pageNumber
     */
    private List<Trip> getTripList(Long mObjectId, Long fromDate, Long toDate, Long pageNumber) {
        if (mObjectId == null
                || fromDate == null
                || toDate == null) {
            return null;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreTrip().getByTime(mObjectId, fromDate, toDate, pageNumber);
        }

        return null;
    }

    /**
     * Get trip list those which given object ran within given intervals
     *
     * @param routeId
     * @param mObjectId
     * @param tripType
     * @param fromDate
     * @param toDate
     * @param pageNumber
     * @return
     */
    private List<Trip> getTripListByTimeMobjectRoute(Long routeId, Long mObjectId, Integer tripType,
                                                     Long fromDate, Long toDate, Long pageNumber) {
        if (mObjectId == null || fromDate == null || toDate == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreTrip().getByTimeMobjectRoute(routeId, mObjectId, tripType, fromDate, toDate, pageNumber);
        }

        return null;
    }


    private Integer getTripListByTimeMobjectRoutePageCount(Long routeId, Long mObjectId, Integer tripType, Integer tripStatus,
                                                           Long fromDate, Long toDate) {

        if (routeId == null || mObjectId == null || tripType == null || fromDate == null || toDate == null) {
            return 0;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return (int) tripRoutingControl.getCoreTrip().getByTimeMobjectRoutePages(routeId, mObjectId, tripStatus, fromDate, toDate);
        }

        return 0;
    }

    /**
     * Get trip list those which given object ran within given intervals
     *
     * @param routeId
     * @param mObjectId
     * @param contractId
     * @param tripType
     * @param fromDate
     * @param toDate
     * @param pageNumber
     * @return
     */
    private List<Trip>
    getTripListByTimeMobjectContractRoute(HttpSession session, Long routeId, Long mObjectId, Long contractId, Integer tripType, Integer tripStatus,
                                          Long fromDate, Long toDate, Long pageNumber) {
        if (mObjectId == null || contractId == null || fromDate == null || toDate == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            List<Trip> tripList;
            if (MainController.getIsShowObjectsOfAllContracts(session)) {


                tripList = tripRoutingControl.getCoreTrip().getByTimeMobjectRouteForAllContracts(routeId, mObjectId, tripType, tripStatus,
                        fromDate, toDate, pageNumber, MainController.getUser().getId());

                return tripList;
            } else {
                return tripRoutingControl.getCoreTrip().getByTimeMobjectRoute(routeId, mObjectId, contractId, tripType, tripStatus,
                        fromDate, toDate, pageNumber);
            }
        }

        return null;
    }

    /**
     * Get trip statuses those which given object ran within given intervals
     *
     * @param routeId
     * @param mObjectId
     * @param contractId
     * @param tripType
     * @param fromDate
     * @param toDate
     * @return
     */
    private TripStatuses getTripStatusesByTimeMobjectContractRoute(HttpSession session, Long routeId, Long mObjectId, Long contractId, Integer tripType,
                                                                   Long fromDate, Long toDate) {
        if (mObjectId == null || contractId == null || fromDate == null || toDate == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {

            TripStatuses tripStatuses = new TripStatuses();
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                TripStatuses tempTripStatuses;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempTripStatuses = tripRoutingControl.getCoreTrip().getTripStatusesByTimeMobjectRoute(routeId, mObjectId, contract.getId(), tripType,
                            fromDate, toDate);

                    if (tempTripStatuses.getAll() != null && tempTripStatuses.getAll() > 0) {
                        Long all = tripStatuses.getAll();
                        if (all == null) {
                            all = 0L;
                        }
                        all += tempTripStatuses.getAll();
                        tripStatuses.setAll(all);
                    }
                    if (tempTripStatuses.getActive() != null && tempTripStatuses.getActive() > 0) {
                        Long active = tripStatuses.getActive();
                        if (active == null) {
                            active = 0L;
                        }
                        active += tempTripStatuses.getActive();
                        tripStatuses.setActive(active);
                    }
                    if (tempTripStatuses.getFinished() != null && tempTripStatuses.getFinished() > 0) {
                        Long finished = tripStatuses.getFinished();
                        if (finished == null) {
                            finished = 0L;
                        }
                        finished += tempTripStatuses.getFinished();
                        tripStatuses.setFinished(finished);
                    }
                    if (tempTripStatuses.getNotFinished() != null && tempTripStatuses.getNotFinished() > 0) {
                        Long notFinished = tripStatuses.getNotFinished();
                        if (notFinished == null) {
                            notFinished = 0L;
                        }
                        notFinished += tempTripStatuses.getNotFinished();
                        tripStatuses.setNotFinished(notFinished);
                    }
                    if (tempTripStatuses.getNotStarted() != null && tempTripStatuses.getNotStarted() > 0) {
                        Long notStarted = tripStatuses.getNotStarted();
                        if (notStarted == null) {
                            notStarted = 0L;
                        }
                        notStarted += tempTripStatuses.getNotStarted();
                        tripStatuses.setNotStarted(notStarted);
                    }

                }
                return tripStatuses;
            } else {
                return tripRoutingControl.getCoreTrip().getTripStatusesByTimeMobjectRoute(routeId, mObjectId, contractId, tripType,
                        fromDate, toDate);
            }
        }
        return null;
    }

    /**
     * Get trip list pages count
     *
     * @param routeId
     * @param mObjectId
     * @param contractId
     * @param tripType
     * @param fromDate
     * @param toDate
     * @return
     */
    private Integer getTripListByTimeMobjectContractRoutePageCount(HttpSession session, Long routeId, Long mObjectId, Long
            contractId, Integer tripType, Integer tripStatus,
                                                                   Long fromDate, Long toDate) {
        if (routeId == null || mObjectId == null || contractId == null || tripType == null || fromDate == null || toDate == null) {
            return 0;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {

            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                long pagesCount = tripRoutingControl.getCoreTrip().getByTimeMobjectRoutePagesForAllContracts(routeId, mObjectId,
                        tripType, tripStatus, fromDate, toDate, MainController.getUser().getId());

                return Math.toIntExact(pagesCount);
            } else {
                return (int) tripRoutingControl.getCoreTrip().getByTimeMobjectRoutePages(routeId, mObjectId, contractId, tripType, tripStatus,
                        fromDate, toDate);
            }


        }

        return 0;
    }

    /**
     * Get trip by id
     *
     * @param tripId trip Id
     * @return Trip
     */
    private Trip getTrip(Long tripId) {
        if (tripId == null) {
            return null;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreTrip().readTrip(tripId);
        }

        return null;
    }

    /**
     * Get trip by id for Track
     *
     * @param tripId Trip id
     * @return Trip
     */
    private Trip getTripForTP(Long tripId) {
        if (tripId == null) {
            return null;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreTrip().readTripForRouteTrack(tripId);
        }

        return null;
    }

    /**
     * Get trip with route stations
     *
     * @param trip Trip
     * @return Trip
     */
    private Trip getTripWithRouteStations(Trip trip) {
        if (trip == null) {
            return null;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreTrip().readTripWithRouteStation(trip);
        }

        return null;
    }


}
