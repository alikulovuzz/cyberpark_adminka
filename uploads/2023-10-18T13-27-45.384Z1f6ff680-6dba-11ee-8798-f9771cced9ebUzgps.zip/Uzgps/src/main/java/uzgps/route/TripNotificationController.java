package uzgps.route;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import uz.netex.core.CoreMain;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.database.helpers.DBNotification;
import uz.netex.routing.database.tables.Notification;
import uzgps.main.MainController;
import uzgps.route.json.response.trip.ResponseTripNotification;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

import static uzgps.common.UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN_STR;

/**
 * Created by Gayratjon on 8/28/2015.
 */

@Controller
public class TripNotificationController {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_TRIP_NOTIFICATION_LIST = "/trip/notification-list.htm";

    @Autowired
    CoreMain coreMain;

    @Autowired
    ObjectMapper jsonMapper;

    @RequestMapping(value = URL_TRIP_NOTIFICATION_LIST, method = RequestMethod.GET)
    private void getTripNotificationList(HttpSession session,
                                         HttpServletResponse response,
                                         @RequestParam(value = "time", required = false) Long time)
            throws ServletException, IOException {
        if (logger.isDebugEnabled()) {
            logger.debug("getTripNotificationList: time={}", time);
        }

        if (time == null) {
            time = System.currentTimeMillis();
        }

        DBNotification dbNotification = getDbNotification();
        List<Notification> notificationList = null;
        Long notificationCount = 0L;

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_CUSTOMER_ADMIN_STR)
                || MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")) {
            // Get notification list from db by contract id
            if (dbNotification != null) {
                notificationList = dbNotification.getByContract(MainController.getUserContractId(session), time, Notification.TYPE_NOTIFICATION);
                notificationCount = dbNotification.getCountByContract(MainController.getUserContractId(session), time, Notification.TYPE_NOTIFICATION);
            }
        } else {
            // Get notification list from db by current user id
            if (dbNotification != null) {
                notificationList = dbNotification.getByUser(MainController.getUserContractId(session), time, Notification.TYPE_NOTIFICATION, MainController.getInterfaceUserId());
                notificationCount = dbNotification.getCountByUser(MainController.getUserContractId(session), time, Notification.TYPE_NOTIFICATION, MainController.getInterfaceUserId());
            }
        }

        if (logger.isDebugEnabled()) {
            logger.debug("notificationList:{}", notificationList);
        }

        ResponseTripNotification responseTripNotification = new ResponseTripNotification(notificationList, notificationCount, coreMain);

//        if (logger.isDebugEnabled()) {
//            logger.debug("responseTripNotification:{}", responseTripNotification);
//        }

        try {
            ObjectWriter writer = jsonMapper.writer();
            byte[] data = writer.writeValueAsBytes(responseTripNotification);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Get db connected table for getting notification list
     *
     * @return null if not init yet
     */
    private DBNotification getDbNotification() {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getDbNotification();
        }

        return null;
    }
}
