package uzgps.route.json.response;

/**
 * Created by Gayratjon on 5/25/2015.
 */
abstract class AbstractResponse {
    protected String html;

    public String getHtml() {
        return html;
    }

    public void setHtml(String html) {
        this.html = html;
    }
}
