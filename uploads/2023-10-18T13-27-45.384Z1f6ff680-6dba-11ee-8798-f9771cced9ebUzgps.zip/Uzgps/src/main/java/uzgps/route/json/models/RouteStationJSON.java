package uzgps.route.json.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.RouteStation;

import java.sql.Timestamp;

/**
 * Created by Gayratjon on 5/21/2015.
 */
public class RouteStationJSON extends RouteStation {
    public RouteStationJSON() {
        super();
    }

    public RouteStationJSON(RouteStation routeStation) {
        super();

        if (routeStation != null) {
            this.id = routeStation.getId();
            this.routeId = routeStation.getRouteId();
            this.routeIdOld = routeStation.getRouteIdOld();
            this.stationId = routeStation.getStationId();
            this.stationIdOld = routeStation.getStationIdOld();
            this.priority = routeStation.getPriority();
            this.timeEnter = routeStation.getTimeEnter();
            this.timeExit = routeStation.getTimeExit();
            this.timeParking = routeStation.getTimeParking();
            this.timeTravel = routeStation.getTimeTravel();
            this.timeDeviation = routeStation.getTimeDeviation();
            this.distance = routeStation.getDistance();
        }
    }

    @JsonProperty("rid")
    @Override
    public Long getRouteId() {
        return super.getRouteId();
    }

    @JsonProperty("sid")
    @Override
    public Long getStationId() {
        return super.getStationId();
    }

    @JsonProperty("tmen")
    @Override
    public Long getTimeEnter() {
        return super.getTimeEnter();
    }

    @JsonProperty("tmex")
    @Override
    public Long getTimeExit() {
        return super.getTimeExit();
    }

    @JsonProperty("tmpr")
    @Override
    public Long getTimeParking() {
        return super.getTimeParking();
    }

    @JsonProperty("tmtr")
    @Override
    public Long getTimeTravel() {
        return super.getTimeTravel();
    }

    @JsonProperty("tmdv")
    @Override
    public Long getTimeDeviation() {
        return super.getTimeDeviation();
    }

    @JsonProperty("dt")
    @Override
    public Double getDistance() {
        return super.getDistance();
    }

    /**
     * <<========================== JSON IGNORE FIELDS ==========================>>
     */


    @JsonIgnore
    @Override
    public Long getRouteIdOld() {
        return super.getRouteIdOld();
    }

    @JsonIgnore
    @Override
    public Long getStationIdOld() {
        return super.getStationIdOld();
    }

    @JsonIgnore
    @Override
    public Integer getPriority() {
        return super.getPriority();
    }

    @JsonIgnore
    @Override
    public Long getMobjectId() {
        return super.getMobjectId();
    }

    @JsonIgnore
    @Override
    public String getStatus() {
        return super.getStatus();
    }

    @JsonIgnore
    @Override
    public Timestamp getRegDate() {
        return super.getRegDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getModDate() {
        return super.getModDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getExpDate() {
        return super.getExpDate();
    }
}
