package uzgps.route.json.response;

import uz.netex.routing.database.tables.Route;
import uzgps.route.json.models.RouteJSON;

/**
 * Created by Gayratjon on 5/18/2015.
 */
public class ResponseRouteEdit extends AbstractResponse {
    private RouteJSON route;

    public ResponseRouteEdit() {
        this.route = null;
        this.html = null;
    }

    public RouteJSON getRoute() {
        return route;
    }

    public void setRoute(Route route) {
        if (route != null) {
            this.route = new RouteJSON(route);
        }
    }
}
