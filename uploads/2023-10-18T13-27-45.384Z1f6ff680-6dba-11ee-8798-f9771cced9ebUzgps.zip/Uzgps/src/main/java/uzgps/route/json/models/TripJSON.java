package uzgps.route.json.models;

import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.routing.database.tables.Trip;

/**
 * Created by Gayratjon on 7/7/2015.
 */
public class TripJSON{

    private Long id;
    protected Integer tripPassed; // In 100%
    protected Integer tripPassStatus;

    public TripJSON() {
        this.id = null;
        this.tripPassed = 0;
        this.tripPassStatus = Trip.PASS_STATUS_NOT_STARTED;
    }

    public TripJSON(Trip trip) {
        this();

        if (trip != null) {
            this.id = trip.getId();
            this.tripPassed = trip.getTripPassed();
            this.tripPassStatus = trip.getTripPassStatus();
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty("ps")
    public Integer getTripPassed() {
        return tripPassed;
    }

    public void setTripPassed(Integer tripPassed) {
        this.tripPassed = tripPassed;
    }

    @JsonProperty("st")
    public Integer getTripPassStatus() {
        return tripPassStatus;
    }

    public void setTripPassStatus(Integer tripPassStatus) {
        this.tripPassStatus = tripPassStatus;
    }
}
