package uzgps.route.json.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.locationtech.jts.geom.Geometry;
import uz.netex.routing.database.tables.Route;
import uz.netex.routing.database.tables.RouteEvent;
import uz.netex.routing.database.tables.RouteStation;
import uz.netex.routing.database.tables.TripRoute;

import java.sql.Timestamp;
import java.util.List;

/**
 * Created by Gayratjon on 5/19/2015.
 */
public class RouteJSON extends Route {

    private List<Long> stationIdList;

    public RouteJSON() {
        super();
    }

    public RouteJSON(Route route) {
        super();

        if (route != null) {
            this.id = route.getId();
            this.contractId = route.getContractId();
            this.contractIdOld = route.getContractIdOld();
            this.name = route.getName();
            this.useName = route.getUseName();
            this.comment = route.getComment();
            this.useRoad = route.getUseRoad();
            this.roadWidth = route.getRoadWidth();
            this.useNavigation = route.getUseNavigation();
            this.fontSize = route.getFontSize();
            this.roadOpacity = route.getRoadOpacity();
            this.active = route.getActive();
            this.fontColor = route.getFontColor();
            this.roadColor = route.getRoadColor();
            this.wkt = route.getWkt();
            this.wktPath = route.getWktPath();
            this.endType = route.getEndType();
        }
    }

    public RouteJSON(TripRoute tripRoute) {
        super();

        if (tripRoute != null) {
            this.id = tripRoute.getRouteId();
            this.contractId = tripRoute.getContractId();
            this.contractIdOld = tripRoute.getContractIdOld();
            this.name = tripRoute.getName();
            this.useName = tripRoute.getUseName();
            this.comment = tripRoute.getComment();
            this.useRoad = tripRoute.getUseRoad();
            this.roadWidth = tripRoute.getRoadWidth();
            this.useNavigation = tripRoute.getUseNavigation();
            this.fontSize = tripRoute.getFontSize();
            this.roadOpacity = tripRoute.getRoadOpacity();
            this.active = tripRoute.getActive();
            this.fontColor = tripRoute.getFontColor();
            this.roadColor = tripRoute.getRoadColor();
            this.wkt = tripRoute.getWkt();
            this.wktPath = tripRoute.getWktPath();
            this.endType = tripRoute.getEndType();
        }
    }

    @JsonProperty("nm")
    @Override
    public String getName() {
        return super.getName();
    }

    @JsonProperty("unm")
    @Override
    public Integer getUseName() {
        return super.getUseName();
    }

    @JsonProperty("cm")
    @Override
    public String getComment() {
        return super.getComment();
    }

    @JsonProperty("urd")
    @Override
    public Integer getUseRoad() {
        return super.getUseRoad();
    }

    @JsonProperty("rdw")
    @Override
    public Double getRoadWidth() {
        return super.getRoadWidth();
    }

    @JsonProperty("unv")
    @Override
    public Integer getUseNavigation() {
        return super.getUseNavigation();
    }

    @JsonProperty("fts")
    @Override
    public Integer getFontSize() {
        return super.getFontSize();
    }

    @JsonProperty("rdo")
    @Override
    public Double getRoadOpacity() {
        return super.getRoadOpacity();
    }

    @JsonProperty("wkt")
    @Override
    public String getWkt() {
        return super.getWkt();
    }

    @JsonProperty("wktp")
    @Override
    public String getWktPath() {
        return super.getWktPath();
    }

    @JsonProperty("rdc")
    @Override
    public String getRoadColor() {
        return super.getRoadColor();
    }

    @JsonProperty("ftc")
    @Override
    public String getFontColor() {
        return super.getFontColor();
    }

    @JsonProperty("stid")
    public List<Long> getStationIdList() {
        return stationIdList;
    }

    public void setStationIdList(List<Long> stationIdList) {
        this.stationIdList = stationIdList;
    }


    /**
     * <<========================== JSON IGNORE FIELDS ==========================>>
     */

    @JsonIgnore
    @Override
    public Integer getEndType() {
        return super.getEndType();
    }

    @JsonIgnore
    @Override
    public List<RouteEvent> getRouteEventList() {
        return super.getRouteEventList();
    }

    @JsonIgnore
    @Override
    public List<RouteStation> getRouteStationList() {
        return super.getRouteStationList();
    }

    @JsonIgnore
    @Override
    public Geometry getWktPathGeometry() {
        return super.getWktPathGeometry();
    }

    @JsonIgnore
    @Override
    public Geometry getWktGeometry() {
        return super.getWktGeometry();
    }

    @JsonIgnore
    @Override
    public Long getContractId() {
        return super.getContractId();
    }

    @JsonIgnore
    @Override
    public Long getContractIdOld() {
        return super.getContractIdOld();
    }

    @JsonIgnore
    @Override
    public Integer getActive() {
        return super.getActive();
    }

    @JsonIgnore
    @Override
    public Long getMobjectId() {
        return super.getMobjectId();
    }

    @JsonIgnore
    @Override
    public String getStatus() {
        return super.getStatus();
    }

    @JsonIgnore
    @Override
    public Timestamp getRegDate() {
        return super.getRegDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getModDate() {
        return super.getModDate();
    }

    @JsonIgnore
    @Override
    public Timestamp getExpDate() {
        return super.getExpDate();
    }
}
