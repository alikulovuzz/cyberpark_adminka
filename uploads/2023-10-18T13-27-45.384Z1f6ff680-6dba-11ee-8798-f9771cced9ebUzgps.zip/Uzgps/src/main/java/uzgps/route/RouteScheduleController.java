package uzgps.route;

import com.fasterxml.jackson.databind.ObjectWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import uz.netex.datatype.MobjectBig;
import uz.netex.routing.common.Constants;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.core.helpers.CoreTripTemplate;
import uz.netex.routing.database.tables.Route;
import uz.netex.routing.database.tables.RouteStation;
import uz.netex.routing.database.tables.Station;
import uz.netex.routing.database.tables.TripTemplate;
import uz.netex.uzgps.errors.Errors;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.route.json.models.TripTemplateJSON;
import uzgps.route.json.response.ResponseSchedule;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.*;

/**
 * Created by G'ayrat on 05.05.15
 */
@Controller
public class RouteScheduleController extends AbstractRoutingController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_ROUTE_SCHEDULE = "/route/schedule.htm";
    private final static String URL_ROUTE_SCHEDULE_FAST_LINK = "/route/schedule-form.htm";
    private final static String VIEW_ROUTE_SCHEDULE = "route/schedule";

    private final static String URL_ROUTE_SCHEDULE_CALENDAR = "/route/ajax-schedule-calendar.htm";
    private final static String VIEW_ROUTE_SCHEDULE_CALENDAR = "route/ajax-schedule-calendar";

    private final static String URL_ROUTE_SCHEDULE_COPY_AND_REMOVE = "/route/schedule-copy-and-remove.htm";

    private final static String URL_AJAX_TRIP_SCHEDULE_MANAGE = "/route/ajax-trip-schedule-manage.htm";
    private final static String VIEW_AJAX_TRIP_SCHEDULE_MANAGE = "route/ajax-trip-schedule-edit";

    private final static String URL_AJAX_ROUTE_LIST = "/route/ajax-schedule-route-list.htm";
    private final static String VIEW_AJAX_ROUTE_LIST = "route/ajax-schedule-route-list";

    @Override
    protected String getActiveRouteTabMenu() {
        return "schedule";
    }

    /**
     * Get Mobject and Route list models
     * and schedule-left.jsp, schedule-content rendered view in layout
     *
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_SCHEDULE)
    public ModelAndView scheduleMain(HttpSession session, Locale locale) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_SCHEDULE);

        // Add mobject list
        modelAndView.addObject("mobjectList", getMobjectList(session));
        modelAndView.addObject("routeListFull", getRouteList(session, -1, ""));

        putRouteStationModelToView(session, modelAndView, "0", "", URL_AJAX_ROUTE_LIST);
        TripTemplate tripTemplate = new TripTemplate();
        tripTemplate.setTimeStart(System.currentTimeMillis());

        modelAndView.addObject("tripTemplate", tripTemplate);
//        modelAndView.addObject("checkedDays", checkedWeekdays(tripTemplate.getWeekdays().byteValue()));

        // Get current language
        String language = getLanguage(locale);

        modelAndView.addObject("language", language.toLowerCase());

        try {
            // Making trip event json list in order to display in calendar
            List<TripTemplateJSON> tripTemplateJSONList = new ArrayList<>();
            String tripEventListJson = "\"\"";
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            tripEventListJson = writer.writeValueAsString(tripTemplateJSONList);
            modelAndView.addObject("tripEventListJson", tripEventListJson);
        } catch (Exception e) {
            logger.error("Error: ", e);
        }

        return modelAndView;
    }

    /**
     * Get Mobject and Route list models
     * and schedule-left.jsp, schedule-content rendered view in layout
     *
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_SCHEDULE_FAST_LINK)
    public ModelAndView scheduleMainFastLink(HttpSession session, Locale locale,
                                             @RequestParam(value = "route-id", required = false) String rtId
    ) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_SCHEDULE);

        Long routeId = strToLong(rtId, null);
        // Add mobject list

        modelAndView.addObject("mobjectList", getMobjectList(session));

        ArrayList<Route> routeListFull = new ArrayList<>();
        Route route = getRoute(session, routeId);
        routeListFull.add(route);

        modelAndView.addObject("routeListFull", routeListFull);

        putRouteStationModelToViewSingle(session, strToLong(rtId, null), modelAndView, "", URL_AJAX_ROUTE_LIST);

        TripTemplate tripTemplate = new TripTemplate();
        tripTemplate.setTimeStart(System.currentTimeMillis());

        modelAndView.addObject("tripTemplate", tripTemplate);
//        modelAndView.addObject("checkedDays", checkedWeekdays(tripTemplate.getWeekdays().byteValue()));

        // Get current language
        String language = getLanguage(locale);

        modelAndView.addObject("language", language.toLowerCase());

        modelAndView.addObject("routeId", rtId);
        modelAndView.addObject("showGraphicForSingleRoute", 1);

        try {
            // Making trip event json list in order to display in calendar
            List<TripTemplateJSON> tripTemplateJSONList = new ArrayList<>();
            String tripEventListJson = "\"\"";
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            tripEventListJson = writer.writeValueAsString(tripTemplateJSONList);
            modelAndView.addObject("tripEventListJson", tripEventListJson);
        } catch (Exception e) {
            logger.error("Error: ", e);
        }

        return modelAndView;
    }

    /**
     * Get Mobject and Route list models
     * and schedule-left.jsp, schedule-content rendered view in layout
     *
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_ROUTE_SCHEDULE_CALENDAR)
    public void scheduleCalendar(HttpSession session, Locale locale, HttpServletResponse response, HttpServletRequest request,
                                 @RequestParam(value = "f-start-date", required = false) String startDate,
                                 @RequestParam(value = "f-end-date", required = false) String endDate,
                                 @RequestParam(value = "f-route-id", required = false) String routeIdStr,
                                 @RequestParam(value = "f-object-id", required = false) String mobjectIdStr,
                                 @RequestParam(value = "f-single-route", required = false) String singleRoute
    ) throws Exception {

        Long startTS = (strToLong(startDate, System.currentTimeMillis()));
        Long endTS = (strToLong(endDate, System.currentTimeMillis()));
        Long routeId = strToLong(routeIdStr, null);
        Long mobjectId = strToLong(mobjectIdStr, null);

        ModelAndView modelAndView = new ModelAndView(VIEW_ROUTE_SCHEDULE_CALENDAR);

        List<TripTemplateJSON> tripTemplateJSONList = new ArrayList<>();

        if (routeId != null && mobjectId != null) {
            try {
                // Making trip event json list in order to display in calendar
                tripTemplateJSONList = getTripTemplateJSONList(session, routeId, mobjectId, startTS, endTS);
                String tripEventListJson = "\"\"";
                ObjectWriter writer = jsonMapper.writer().withRootName("data");
                tripEventListJson = writer.writeValueAsString(tripTemplateJSONList);


                modelAndView.addObject("tripEventListJson", tripEventListJson);
            } catch (Exception e) {
                logger.error("Error: ", e);
            }
        }

        if (singleRoute != null && singleRoute.equals("1")) {
            // Add mobject list
            modelAndView.addObject("mobjectList", getMobjectList(session));

            ArrayList<Route> routeListFull = new ArrayList<>();
            Route route = getRoute(session, routeId);
            routeListFull.add(route);

            modelAndView.addObject("routeListFull", routeListFull);

            modelAndView.addObject("routeId", routeId);
            modelAndView.addObject("showGraphicForSingleRoute", 1);

            putRouteStationModelToViewSingle(session, routeId, modelAndView, "", URL_AJAX_ROUTE_LIST);
        } else {
            // Add mobject list
            modelAndView.addObject("mobjectList", getMobjectList(session));
            modelAndView.addObject("routeListFull", getRouteList(session, -1, ""));
            putRouteStationModelToView(session, modelAndView, "0", "", URL_AJAX_ROUTE_LIST);
        }

        TripTemplate tripTemplate = new TripTemplate();
        tripTemplate.setTimeStart(System.currentTimeMillis());

        modelAndView.addObject("tripTemplate", tripTemplate);
//        modelAndView.addObject("checkedDays", checkedWeekdays(tripTemplate.getWeekdays().byteValue()));

        // Get current language
        String language = getLanguage(locale);
        modelAndView.addObject("language", language.toLowerCase());

//        return modelAndView;

        Map<String, Object> mapModels = new HashMap<>();
        mapModels.putAll(modelAndView.getModel());

        // Get rendered html from view
        View resolvedView = htmlViewResolver.resolveViewName(VIEW_ROUTE_SCHEDULE_CALENDAR, response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(mapModels, request, mockResp);

        // Make json response
        ResponseSchedule responseSchedule = new ResponseSchedule();

        responseSchedule.setTripTemplatesJSON(tripTemplateJSONList);

        responseSchedule.setHtml(mockResp.getContentAsString().trim());

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseSchedule);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Manage trip schedule: add, edit, delete
     * returns JSON with Route model and rendered hml from ajax-route-edit.jsp
     *
     * @param response
     * @param request
     * @param cmd
     * @param routeId
     * @throws Exception
     */
    @RequestMapping(value = URL_AJAX_TRIP_SCHEDULE_MANAGE)
    private void ajaxTripScheduleManage(HttpSession session,
                                        HttpServletResponse response,
                                        HttpServletRequest request,
                                        @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber,
                                        @RequestParam(value = "search", required = false, defaultValue = "") String searchText,
                                        @RequestParam(value = "cmd", required = false) String cmd,
                                        @RequestParam(value = "e-trip-template-id", required = false) String tripTemplateId,
                                        @RequestParam(value = "e-object-id", required = false) String mobjectId,
                                        @RequestParam(value = "e-route-name", required = false) String routeId,
                                        @RequestParam(value = "e-route-start-date", required = false) String timeStart,
//                                        @RequestParam(value = "cb-route-repeat", required = false) String useRepeat,
//                                        @RequestParam(value = "e-route-repeat-type", required = false) String repeatTimes,
//                                        @RequestParam(value = "every-repeat", required = false) String repeatEvery,
                                        @RequestParam(value = "cd-week-days[]", required = false) String[] weekdays
//                                        @RequestParam(value = "r-repeat-count-type", required = false) String repeatCountType,
//                                        @RequestParam(value = "e-repeat-occurrences", required = false) String repeatCountAfter,
//                                        @RequestParam(value = "e-repeat-end-date", required = false) String repeatCountOn
    )
            throws Exception {

        TripTemplate tripTemplate = new TripTemplate();
        String simpleDateFormatPattern = "dd.MM.yyyy HH:mm";


//        if (timeStart.length() == 10) {
//            simpleDateFormatPattern = "dd.MM.yyyy";
//        } else {
//            simpleDateFormatPattern = "dd.MM.yyyy HH:mm";
//        }

        if (timeStart != null && timeStart.length() > 0) {
            timeStart = timeStart.trim();
        }

        tripTemplate.setTimeStart(strToTimestamp(timeStart, simpleDateFormatPattern, System.currentTimeMillis()).getTime());
        Map<String, Object> mapModels = new HashMap<>();
        Integer errCode = Errors.ERR_SUCCESS;

        if (cmd != null) {

            if (cmd.equals("save")) {
                // Save trip template
                tripTemplate.setMobjectId(strToLong(mobjectId, null));
                tripTemplate.setRouteId(strToLong(routeId, null));
                tripTemplate.setContractId(MainController.getUserContractId(session));
                tripTemplate.setTimeStart(strToTimestamp(timeStart, simpleDateFormatPattern, tripTemplate.getTimeStart()).getTime());

                errCode = tripTemplateSave(tripTemplate);
                mapModels.put("errCode", errCode);
            } else if (cmd.equals("edit")) {
                // Update trip template
                tripTemplate = getTripTemplate(session, strToLong(tripTemplateId, null));

                if (tripTemplate != null) {
                    tripTemplate.setMobjectId(strToLong(mobjectId, null));
                    tripTemplate.setRouteId(strToLong(routeId, null));
                    tripTemplate.setTimeStart(strToTimestamp(timeStart, simpleDateFormatPattern, System.currentTimeMillis()).getTime());

                    tripTemplate.setRepeatTimes(0L);
                    tripTemplate.setRepeatEvery(Constants.DEFAULT_REPEAT_EVERY);
                    tripTemplate.setWeekdays(Constants.DEFAULT_WEEKDAYS);
                    tripTemplate.setRepeatCountType(Constants.DEFAULT_REPEAT_COUNT_TYPE);
                    tripTemplate.setRepeatCount(Constants.DEFAULT_REPEAT_COUNT);
                }

                errCode = tripTemplateSave(tripTemplate);

                mapModels.put("errCode", errCode);
            } else if (cmd.equals("delete")) {
                // Delete trip template
                errCode = tripTemplateDelete(session, strToLong(tripTemplateId, null));
                if (errCode != Errors.ERR_SUCCESS) {
                    mapModels.put("errCode", errCode);
                } else if (errCode == Errors.ERR_SUCCESS) {
                    tripTemplate = null;
                }
            } else if (cmd.equals("clean")) {
                TripTemplate tmpTripTemplate = getTripTemplate(session, strToLong(tripTemplateId, null));

                if (tmpTripTemplate != null) {
                    tripTemplate.setId(tmpTripTemplate.getId());
                    tripTemplate.setMobjectId(tmpTripTemplate.getMobjectId());
                    tripTemplate.setRouteId(tmpTripTemplate.getRouteId());
                }
            } else if (cmd.equals("event")) {
                // Get selected trip template
                if (tripTemplateId != null && tripTemplateId.length() > 0) {
                    tripTemplate = getTripTemplate(session, strToLong(tripTemplateId, null));
                }
            }
        }

        if (tripTemplate == null) {
            tripTemplate = new TripTemplate();
            tripTemplate.setTimeStart(strToTimestamp(timeStart, simpleDateFormatPattern, System.currentTimeMillis()).getTime());
        }

        mapModels.put("tripTemplate", tripTemplate);
        // Add mobject list
        mapModels.put("mobjectList", getMobjectList(session));
//        mapModels.put("checkedDays", checkedWeekdays(tripTemplate.getWeekdays().byteValue()));
        mapModels.put("userAccessList", getUserAccessList(session));

        if (tripTemplate.getId() != null && tripTemplate.getRouteId() != null) {
            Route route = getRoute(session, tripTemplate.getRouteId());
            mapModels.put("route", route);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_TRIP_SCHEDULE_MANAGE);
        putRouteListModelToView(session, modelAndView, pageNumber, searchText, URL_AJAX_ROUTE_LIST);
        mapModels.putAll(modelAndView.getModel());

        // Get rendered html from view
        View resolvedView = htmlViewResolver.resolveViewName(VIEW_AJAX_TRIP_SCHEDULE_MANAGE, response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(mapModels, request, mockResp);

        // Make json response
        ResponseSchedule responseSchedule = new ResponseSchedule();
        if (cmd != null) {
            TripTemplateJSON tripTemplateJSON = new TripTemplateJSON(tripTemplate);
            if ((cmd.equals("save") || cmd.equals("edit"))
                    && errCode == Errors.ERR_SUCCESS) {
                setTripTemplateTimes(session, tripTemplateJSON);
            }

            if (!cmd.equals("event") && !cmd.equals("clean")) {
                responseSchedule.setTripTemplateJSON(tripTemplateJSON);
            }

            if (cmd.equals("delete")) {
                tripTemplateJSON.setId(strToLong(tripTemplateId, null));
            }
        }
        responseSchedule.setHtml(mockResp.getContentAsString().trim());

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data = writer.writeValueAsBytes(responseSchedule);
            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Manage trip schedule: add, edit, delete
     * returns JSON with Route model and rendered hml from ajax-route-edit.jsp
     *
     * @param response
     * @param request
     * @param cmd
     * @param routeId
     * @throws Exception
     */
    @RequestMapping(value = URL_ROUTE_SCHEDULE_COPY_AND_REMOVE)
    public void scheduleCopyOrRemove(HttpSession session,
                                        HttpServletResponse response,
                                        HttpServletRequest request,
                                        @RequestParam(value = "page", required = false, defaultValue = "0") String pageNumber,
                                        @RequestParam(value = "search", required = false, defaultValue = "") String searchText,
                                        @RequestParam(value = "cmd", required = false) String cmd,
                                        @RequestParam(value = "e-trip-template-id", required = false) String tripTemplateId,
                                        @RequestParam(value = "e-object-id", required = false) String mobjectId,
                                        @RequestParam(value = "e-route-name", required = false) String routeId,
                                        @RequestParam(value = "e-route-start-date", required = false) String timeStart,
                                        @RequestParam(value = "sch_action_type", required = false) String schActionType,
                                        @RequestParam(value = "dateStartFrom", required = false) String dateStartFrom,
                                        @RequestParam(value = "dateEndFrom", required = false) String dateEndFrom,
                                        @RequestParam(value = "dateStartTo", required = false) String dateStartTo,
                                        @RequestParam(value = "dateEndTo", required = false) String dateEndTo,
                                        @RequestParam(value = "datestart", required = false) String dateStart,
                                        @RequestParam(value = "dateend", required = false) String dateEnd,
//                                        @RequestParam(value = "cb-route-repeat", required = false) String useRepeat,
//                                        @RequestParam(value = "e-route-repeat-type", required = false) String repeatTimes,
//                                        @RequestParam(value = "every-repeat", required = false) String repeatEvery,s
                                        @RequestParam(value = "cd-week-days[]", required = false) String[] weekdays
//                                        @RequestParam(value = "r-repeat-count-type", required = false) String repeatCountType,
//                                        @RequestParam(value = "e-repeat-occurrences", required = false) String repeatCountAfter,
//                                        @RequestParam(value = "e-repeat-end-date", required = false) String repeatCountOn
    )
            throws Exception {

        TripTemplate tripTemplate = new TripTemplate();
        String simpleDateFormatPattern = "dd.MM.yyyy HH:mm";
        Long routeID = strToLong(routeId, null);
        Timestamp fromStartDate = strToTimestamp(dateStartFrom, "dd.MM.yyyy",0l);
        Timestamp fromEndDate = strToTimestamp(dateEndFrom, "dd.MM.yyyy",0l);
        Timestamp toStartDate = strToTimestamp(dateStartTo, "dd.MM.yyyy",0l);
        Timestamp toEndDate = strToTimestamp(dateEndTo, "dd.MM.yyyy",0l);
        Timestamp startDateForDel = strToTimestamp(dateStart, "dd.MM.yyyy",0l);
        Timestamp endDateForDel = strToTimestamp(dateEnd, "dd.MM.yyyy",0l);
        Contract contract = MainController.getUserContract(session);

//        if (timeStart.length() == 10) {
//            simpleDateFormatPattern = "dd.MM.yyyy";
//        } else {
//            simpleDateFormatPattern = "dd.MM.yyyy HH:mm";
//        }


        if (timeStart != null && timeStart.length() > 0) {
            timeStart = timeStart.trim();
        }

        tripTemplate.setTimeStart(strToTimestamp(timeStart, simpleDateFormatPattern, System.currentTimeMillis()).getTime());
        Map<String, Object> mapModels = new HashMap<>();
        Integer errCode = Errors.ERR_SUCCESS;

        if (schActionType != null) {
            CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();
            CoreTripTemplate coreTripTemplate = tripRoutingControl.getCoreTripTemplate();

            if (schActionType.equals("1")) {
                // Copy trip template
                errCode = coreTripTemplate.copyRouteSchedulesByPeriods(contract.getId(), fromStartDate,  fromEndDate,  toStartDate,  toEndDate);

                mapModels.put("errCode", errCode);
            }
            else if (schActionType.equals("0")) {
                // Delete trip template
                errCode = coreTripTemplate.deleteRouteSchedulesByPeriods(contract.getId(), startDateForDel,  endDateForDel);

                mapModels.put("errCode", errCode);
            }
        }
       /* modelAndView.addObject("errCode", errCode);

        return modelAndView;*/

        mapModels.put("tripTemplate", tripTemplate);
        // Add mobject list
        mapModels.put("mobjectList", getMobjectList(session));
//        mapModels.put("checkedDays", checkedWeekdays(tripTemplate.getWeekdays().byteValue()));
        mapModels.put("userAccessList", getUserAccessList(session));

        if (tripTemplate.getId() != null && tripTemplate.getRouteId() != null) {
            Route route = getRoute(session, tripTemplate.getRouteId());
            mapModels.put("route", route);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_TRIP_SCHEDULE_MANAGE);
        putRouteListModelToView(session, modelAndView, pageNumber, searchText, URL_AJAX_ROUTE_LIST);
        mapModels.putAll(modelAndView.getModel());
        View resolvedView = htmlViewResolver.resolveViewName(VIEW_AJAX_TRIP_SCHEDULE_MANAGE, response.getLocale());
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        mockResp.setCharacterEncoding("UTF-8");
        resolvedView.render(mapModels, request, mockResp);
        // Make json response
        ResponseSchedule responseSchedule = new ResponseSchedule();
       /* if (cmd != null) {
            TripTemplateJSON tripTemplateJSON = new TripTemplateJSON(tripTemplate);
            if ((cmd.equals("save") || cmd.equals("edit"))
                    && errCode == Errors.ERR_SUCCESS) {
                setTripTemplateTimes(session, tripTemplateJSON);
            }

            if (!cmd.equals("event") && !cmd.equals("clean")) {
                responseSchedule.setTripTemplateJSON(tripTemplateJSON);
            }

            if (cmd.equals("delete")) {
                tripTemplateJSON.setId(strToLong(tripTemplateId, null));
            }
        }*/
        responseSchedule.setHtml(mockResp.getContentAsString().trim());

        try {
            ObjectWriter writer = jsonMapper.writer().withRootName("data");
            byte[] data;
            if( errCode == Errors.ERR_SUCCESS || errCode == Errors.ERR_TRIP_TEMPLATE_DELETE){
                data = writer.writeValueAsBytes(responseSchedule);
            }else{
                data = writer.writeValueAsBytes(resolvedView);
            }

            response.setContentType("application/json");
            response.setContentLength(data.length);

            // Write in output stream
            ServletOutputStream outStream = response.getOutputStream();
            outStream.write(data);
            outStream.close();
            outStream.flush();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    /**
     * Get Route list model and view
     *
     * @param pageNumber
     * @param searchText
     * @return ModelAndView
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_AJAX_ROUTE_LIST, method = RequestMethod.GET)
    private ModelAndView ajaxRouteList(HttpSession session,
                                       @RequestParam(value = "page", required = false, defaultValue = "0") String
                                               pageNumber,
                                       @RequestParam(value = "search", required = false, defaultValue = "") String searchText)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_ROUTE_LIST);
        putRouteListModelToView(session, modelAndView, pageNumber, searchText, URL_AJAX_ROUTE_LIST);

        return modelAndView;
    }

    /**
     * Get trip template by its id
     *
     * @param tpId trip template id
     * @return TripTemplate returns null if not exists or no access for its mobject or its route
     */
    private TripTemplate getTripTemplate(HttpSession session, Long tpId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null && tpId != null) {
            CoreTripTemplate coreTripTemplate = tripRoutingControl.getCoreTripTemplate();
            TripTemplate tripTemplate = coreTripTemplate.getFromDb(tpId);

            if (tripTemplate != null) {
                // Check mobject access for editing
                if (!hasAccessEditForMobject(session, tripTemplate.getMobjectId()))
                    return null;

                Route route = getRoute(session, tripTemplate.getRouteId());
                // If route is available not null means that is belongs to current user contract
                if (route != null) {
                    return tripTemplate;
                }
            }
        }

        return null;
    }

    /**
     * Get trip template list by current user's contract id
     *
     * @return List<TripTemplate>
     */
    private List<TripTemplate> getTripTemplateList(HttpSession session) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreTripTemplate coreTripTemplate = tripRoutingControl.getCoreTripTemplate();

            List<TripTemplate> tripTemplateList = null;
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<TripTemplate> tempTripTemplateList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempTripTemplateList = coreTripTemplate.getListByContract(contract.getId());

                    if (tempTripTemplateList != null && tempTripTemplateList.size() > 0) {
                        if (tripTemplateList == null) tripTemplateList = new ArrayList<>();
                        {
                            tripTemplateList.addAll(tempTripTemplateList);
                        }
                    }
                }
                return tripTemplateList;
            } else {
                return coreTripTemplate.getListByContract(MainController.getUserContractId(session));
            }
        }

        return null;
    }

    /**
     * Get trip template list by current user's contract id
     *
     * @return List<TripTemplate>
     */
    private List<TripTemplate> getTripTemplateListByParams(HttpSession session,
                                                           Long routeId, Long mobjectId,
                                                           Long startCalendar, Long endCalendar) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreTripTemplate coreTripTemplate = tripRoutingControl.getCoreTripTemplate();

            List<TripTemplate> tripTemplateList = null;
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<TripTemplate> tempTripTemplateList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempTripTemplateList = coreTripTemplate.getListByParamsForSchedule(contract.getId(),
                            routeId, mobjectId, startCalendar, endCalendar);

                    if (tempTripTemplateList != null && tempTripTemplateList.size() > 0) {
                        if (tripTemplateList == null) tripTemplateList = new ArrayList<>();
                        {
                            tripTemplateList.addAll(tempTripTemplateList);
                        }
                    }
                }
                return tripTemplateList;
            } else {
                return coreTripTemplate.getListByParamsForSchedule(MainController.getUserContractId(session),
                        routeId, mobjectId, startCalendar, endCalendar);
            }


        }

        return null;
    }

    /**
     * Insert or update TripTemplate
     *
     * @param tripTemplate
     * @return
     */
    private int tripTemplateSave(TripTemplate tripTemplate) {
        if (tripTemplate == null
                || tripTemplate.getMobjectId() == null
                || tripTemplate.getRouteId() == null) {
            return Errors.ERR_OBJECT_IS_NULL;
        }

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            return tripRoutingControl.getCoreTripTemplate().save(tripTemplate);
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Delete trip template by id
     *
     * @param tpId - trip template id
     * @return
     */
    private int tripTemplateDelete(HttpSession session, Long tpId) {
        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            CoreTripTemplate coreTripTemplate = tripRoutingControl.getCoreTripTemplate();
            TripTemplate tripTemplate = getTripTemplate(session, tpId);

            if (tripTemplate == null) {
                return Errors.ERR_OBJECT_IS_NULL;
            } else {
                return coreTripTemplate.delete(tripTemplate);
            }
        }

        return Errors.ERR_MODULE_ROUTING_CONTROLLER;
    }

    /**
     * Get TripTemplateJSON list
     *
     * @return List<TripTemplateJSON>
     */
    private List<TripTemplateJSON> getTripTemplateJSONList(HttpSession session, Long routeId, Long mobjectId,
                                                           Long startCalendar, Long endCalendar) {

        List<TripTemplate> tripTemplateList = getTripTemplateListByParams(session, routeId, mobjectId, startCalendar, endCalendar);
        List<TripTemplateJSON> tripTemplateJSONList = new ArrayList<>();

        if (tripTemplateList != null) {
//            if (routeId == 0 && mobjectId == 0) {
            for (TripTemplate tpTemplate : tripTemplateList) {
//                    if (tpTemplate.getTimeStart() >= startCalendar && tpTemplate.getTimeEnd() <= endCalendar) {
                TripTemplateJSON tripTemplateJSON = new TripTemplateJSON(tpTemplate);
//                    setTripTemplateTimes(session, tripTemplateJSON);
                tripTemplateJSONList.add(tripTemplateJSON);
//                    }

            }
//                return tripTemplateJSONList;
//            }
        }

//        for (TripTemplate tpTemplate : tripTemplateList) {
////            if (tpTemplate.getTimeStart() >= startCalendar && tpTemplate.getTimeEnd() <= endCalendar) {
//            TripTemplateJSON tripTemplateJSON = new TripTemplateJSON(tpTemplate);
//
//            if (tpTemplate.getRouteId().equals(routeId) && mobjectId.equals(0L)) {
//                setTripTemplateTimes(session, tripTemplateJSON);
//                tripTemplateJSONList.add(tripTemplateJSON);
//                continue;
//            }
//
//            if (tpTemplate.getMobjectId().equals(mobjectId) && routeId.equals(0L)) {
//                setTripTemplateTimes(session, tripTemplateJSON);
//                tripTemplateJSONList.add(tripTemplateJSON);
//                continue;
//            }
//
//            if (tpTemplate.getRouteId().equals(routeId) && tpTemplate.getMobjectId().equals(mobjectId)) {
//                setTripTemplateTimes(session, tripTemplateJSON);
//                tripTemplateJSONList.add(tripTemplateJSON);
//                continue;
//            }
//        }


//        }

        return tripTemplateJSONList;
    }

    /**
     * Set time enter and time exit to trip template
     *
     * @param tripTemplateJSON
     */

    private void setTripTemplateTimes(HttpSession session, TripTemplateJSON tripTemplateJSON) {
        if (tripTemplateJSON == null) {
            return;
        }

        Route route = getRoute(session, tripTemplateJSON.getRouteId());
        MobjectBig mobjectBig = coreMain.getMobjectById(tripTemplateJSON.getMobjectId());

        if (route != null && mobjectBig != null) {
            List<RouteStation> routeStationList = getRouteStationListByRoute(route.getId());
//            tripTemplateJSON.setTitle(route.getName() + "-(" + mobjectBig.getName() + ")");
            tripTemplateJSON.setTitle(", " + mobjectBig.getName() + ", " + route.getName());
            tripTemplateJSON.setColor(route.getRoadColor());

            // Get route station time exit and time enter
            if (routeStationList != null && routeStationList.size() >= 2) {
                tripTemplateJSON.setTimeExit(routeStationList.get(0).getTimeExit());
                tripTemplateJSON.setTimeEnter(routeStationList.get(routeStationList.size() - 1).getTimeEnter());
            }
        }
    }

//    /**
//     * Check whether week days are checked or not based on  byte of weekdays
//     *
//     * @param weekdays
//     * @return
//     */
//    private Integer[] checkedWeekdays(byte weekdays) {
//        Integer[] checkedDays = new Integer[7];
//
//        for (int i = 0; i < checkedDays.length; i++) {
//            checkedDays[i] = 0;
//        }
//
//        if ((weekdays & TripTemplate.DAY_MONDAY) > 0) {
//            // Monday checked
//            checkedDays[0] = 1;
//        }
//        if ((weekdays & TripTemplate.DAY_TUESDAY) > 0) {
//            // Tuesday checked
//            checkedDays[1] = 1;
//        }
//        if ((weekdays & TripTemplate.DAY_WEDNESDAY) > 0) {
//            // Wednesday checked
//            checkedDays[2] = 1;
//        }
//        if ((weekdays & TripTemplate.DAY_THURSDAY) > 0) {
//            // Thursday checked
//            checkedDays[3] = 1;
//        }
//        if ((weekdays & TripTemplate.DAY_FRIDAY) > 0) {
//            // Friday checked
//            checkedDays[4] = 1;
//        }
//        if ((weekdays & TripTemplate.DAY_SATURDAY) > 0) {
//            // Saturday checked
//            checkedDays[5] = 1;
//        }
//        if ((weekdays & TripTemplate.DAY_SUNDAY) > 0) {
//            // Sunday checked
//            checkedDays[6] = 1;
//        }
//
//        return checkedDays;
//    }

    private String getLanguage(Locale locale) {
        // Get current language
        String language = "en";
        if (locale != null) {
            language = locale.getLanguage();

            String region = locale.getCountry();
            if (region != null && region.length() > 0) {
                language += "-" + region;
            }
        }
        return language;

    }


}
