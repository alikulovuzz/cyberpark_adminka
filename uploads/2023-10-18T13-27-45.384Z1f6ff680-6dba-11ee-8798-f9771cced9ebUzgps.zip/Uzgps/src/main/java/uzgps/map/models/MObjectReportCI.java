package uzgps.map.models;

/**
 * Created by Gayratjon on 4/29/14.
 */
public class MObjectReportCI extends MObjectActionCI {
    public MObjectReportCI(int position, String idName, String title, String icon, int hasAccess) {
        super(position, idName, title, icon, hasAccess);
    }
}
