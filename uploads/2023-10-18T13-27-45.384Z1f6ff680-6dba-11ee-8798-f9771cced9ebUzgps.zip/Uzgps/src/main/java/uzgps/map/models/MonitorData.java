package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectTracks;
import uzgps.common.FileStorageService;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.persistence.ContractSettings;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;

import static uzgps.common.Converters.*;

/**
 * Created by Gayratjon on 5/3/14.
 *
 * @author Saidolim
 * @since 18.05.2018 15:45
 */

@JsonFilter("MonitorDataFilter")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MonitorData {
    private byte movement;
    private byte engineOn;
    private byte online;
    private byte satellites;
    private short angle;
    private byte dat;
    private double latitude;
    private double longitude;
    private double altitude;
    private long groupId;
    private long date;
    @JsonProperty("dstr")
    private String dateFormatted;
    @JsonProperty("dsmp")
    private String dateSimple;
    @JsonProperty("urlIcon")
    private String urlIcon;
    private int speed;
    private long objectId;
    @JsonProperty("timemovement")
    private Long timeMovement; // movement time
    @JsonProperty("tmsmp")
    private String timeMovementSimple;
    private long pinId;
    @JsonIgnore
    private long objectPhotoId;
    @JsonIgnore
    private String objectPhotoName;
    private String objectPhotoUrl;
    @JsonIgnore
    private Boolean defaultIcon;
    private long objectLabelSize;
    private String objectLabel;
    private String objectName;
    private long staffId;
    private String staffName;
    private String staffPhone;
    private String staffPhoneMobile;
    @JsonIgnore
    private long staffPhotoId;
    @JsonIgnore
    private String staffPhoto;
    private String staffPhotoUrl;

    private Integer bak1;
    private Integer bak2;
    private Integer bak3;
    private Integer bak4;
    private Integer totalIndicationDut;
    private Double bak1Litr;
    private Double bak2Litr;
    private Double bak3Litr;
    private Double bak4Litr;
    private Double bakTotalLitr;
    private Long canFuelConsumption;
    private Integer canFuelLevelLiter;
    private Integer canFuelLevelPercentage;
    private Long countSms;

    @JsonProperty("di_1")  // Digital Input Status 1 , code = 1
    private Byte digital1; // 1
    @JsonProperty("di_2")  // Digital Input Status 2 , code = 2
    private Byte digital2; // 2
    @JsonProperty("di_3")  // Digital Input Status 3 , code = 3
    private Byte digital3; // 3
    @JsonProperty("ai")  // Analog Input , code = 9
    private Short analog1; // 9
    @JsonProperty("gsm_sl")  // GSM Signal Level, code = 21
    private Byte gsmSignalLevel; // 21
    @JsonProperty("speedometer")  // Speedometer , code = 24
    private Short speedometer; // 24
    @JsonIgnore//@JsonProperty("epv")  // External Power Voltage , code = 66
    private Short externalPowerVoltage; // 66
    @JsonIgnore//@JsonProperty("ibv")  // Internal Power Voltage , code = 67
    private Short internalBatteryVoltage; // 67
    @JsonProperty("epv")  // External Power Voltage , code = 66
    private Double externalPowerVoltageDouble; // 66
    @JsonProperty("ibv")  // Internal Power Voltage , code = 67
    private Double internalBatteryVoltageDouble; // 67
    @JsonProperty("gnss")  // GNSS status , code = 71
    private Byte gnssStatus; // 71
    @JsonProperty("pdo")  // GPS PDOP , code = 181
    private Short gpsPdop; // 181
    @JsonProperty("hdop")  // GPS HDOP , code = 182
    private Short gpsHdop; // 182
    @JsonProperty("odometer")  // Odometer , code = 199
    private Integer odometer; // 199
    @JsonProperty("cell_id")  // Cell ID , code = 205
    private Short cellId; // 205
    @JsonProperty("lac")  // Area Code , code = 206
    private Short areaCode; // 206
    @JsonProperty("mov")  // Movement , code = 240
    private Byte movementValue; // 240
    @JsonProperty("pcb")
    private Integer pcbTemperature; // 70
    @JsonProperty("op")
    private Integer currentOperatorCode; // 241
    @JsonProperty("bp")
    private Integer batteryPercent; // Уровень заряда батареи %

    public MonitorData() {
        this.movement = -1;
        this.engineOn = -1;
        this.online = -1;
        this.satellites = -1;
        this.angle = 0;
        this.dat = -1;
        this.latitude = 0;
        this.longitude = 0;
        this.altitude = 0;
        this.date = 0;
        this.dateFormatted = "---";
        this.dateSimple = "";
        this.speed = 0;
        this.objectId = 0;
        this.pinId = 0;
        this.urlIcon = calculateIconUrl(this.movement, this.online);
        this.objectPhotoId = 0;
        this.objectPhotoName = "";
        this.defaultIcon = true;
        this.objectPhotoUrl = "";
        this.objectLabelSize = 0;
        this.objectLabel = "";
        this.objectName = "";
        this.timeMovement = null;
        this.timeMovementSimple = "";

        this.staffId = 0;
        this.staffName = "";
        this.staffPhotoId = 0;
        this.staffPhone = "";
        this.staffPhoneMobile = "";
        this.staffPhoto = "";
        this.staffPhotoUrl = "";

        this.digital1 = 0;
        this.digital2 = 0;
        this.digital3 = 0;
        this.analog1 = 0;
        this.gsmSignalLevel = 0;
        this.speedometer = 0;
        this.externalPowerVoltage = 0;
        this.internalBatteryVoltage = 0;
        this.externalPowerVoltageDouble = 0.0;
        this.internalBatteryVoltageDouble = 0.0;
        this.gnssStatus = 0;
        this.gpsPdop = 0;
        this.gpsHdop = 0;
        this.odometer = 0;
        this.cellId = 0;
        this.areaCode = 0;
        this.movementValue = 0;
        this.pcbTemperature = 0;
        this.currentOperatorCode = 0;
        this.bak1 = null;
        this.bak2 = null;
        this.bak3 = null;
        this.bak4 = null;
        this.totalIndicationDut = null;
        this.bak1Litr = null;
        this.bak2Litr = null;
        this.bak3Litr = null;
        this.bak4Litr = null;
        this.bakTotalLitr = null;
        this.canFuelConsumption = null;
        this.canFuelLevelLiter = null;
        this.canFuelLevelPercentage = null;
        this.countSms = null;
    }

    public MonitorData(MobjectTracks mObjectTracks, ContractSettings contractSettings, HttpSession session) {
        this();

        if (mObjectTracks.getTracks().size() > 0) {

            GPSTrackPoint gpsTrackPoint = mObjectTracks.getTracks().get(0);
            Contract contract = MainController.getUserContract(session);

            this.movement = gpsTrackPoint.getMovement();
            this.engineOn = gpsTrackPoint.getEngineOn();
            this.online = gpsTrackPoint.getOnline();
            this.satellites = gpsTrackPoint.getSatellites();
            this.angle = gpsTrackPoint.getAngle();
            this.urlIcon = calculateIconUrl(this.movement, this.online);
//            this.dat = gpsTrackPoint.getDat();
            this.dat = 1;
            this.latitude = gpsTrackPoint.getLatitude();
            this.longitude = gpsTrackPoint.getLongitude();
            this.altitude = gpsTrackPoint.getAltitude();
            this.date = gpsTrackPoint.getTimestamp();
            this.timeMovement = gpsTrackPoint.getTimeMovement();
            this.speed = gpsTrackPoint.getSpeed();
            if (gpsTrackPoint.getStaff() != null) {
                this.staffId = gpsTrackPoint.getStaff().getId();
                this.staffPhotoId = gpsTrackPoint.getStaff().getPhotoId();
                this.staffName = gpsTrackPoint.getStaff().getSurName() + " " + gpsTrackPoint.getStaff().getName() + " " + gpsTrackPoint.getStaff().getMiddleName();
                this.staffPhoto = gpsTrackPoint.getStaff().getPhotoFilename();
                this.staffPhone = gpsTrackPoint.getStaff().getPhoneLine();
                this.staffPhoneMobile = gpsTrackPoint.getStaff().getPhoneMobile();
            }

            if (gpsTrackPoint.getIoData().getDigital1() != null)
                this.digital1 = gpsTrackPoint.getIoData().getDigital1();
            if (gpsTrackPoint.getIoData().getDigital2() != null)
                this.digital2 = gpsTrackPoint.getIoData().getDigital2();
            if (gpsTrackPoint.getIoData().getDigital3() != null)
                this.digital3 = gpsTrackPoint.getIoData().getDigital3();
            if (gpsTrackPoint.getIoData().getAnalog1() != null)
                this.analog1 = gpsTrackPoint.getIoData().getAnalog1();
            if (gpsTrackPoint.getIoData().getGsmSignalLevel() != null)
                this.gsmSignalLevel = gpsTrackPoint.getIoData().getGsmSignalLevel();
            if (gpsTrackPoint.getIoData().getSpeedometer() != null)
                this.speedometer = gpsTrackPoint.getIoData().getSpeedometer();
            if (gpsTrackPoint.getIoData().getExternalPowerVoltage() != null)
                this.externalPowerVoltage = gpsTrackPoint.getIoData().getExternalPowerVoltage();
            if (gpsTrackPoint.getIoData().getInternalBatteryVoltage() != null)
                this.internalBatteryVoltage = gpsTrackPoint.getIoData().getInternalBatteryVoltage();
            if (gpsTrackPoint.getIoData().getExternalPowerVoltageDouble() != null)
                this.externalPowerVoltageDouble = gpsTrackPoint.getIoData().getExternalPowerVoltageDouble();
            if (gpsTrackPoint.getIoData().getInternalBatteryVoltageDouble() != null)
                this.internalBatteryVoltageDouble = gpsTrackPoint.getIoData().getInternalBatteryVoltageDouble();
            if (gpsTrackPoint.getIoData().getGnssStatus() != null)
                this.gnssStatus = gpsTrackPoint.getIoData().getGnssStatus();
            if (gpsTrackPoint.getIoData().getGpsPdop() != null)
                this.gpsPdop = gpsTrackPoint.getIoData().getGpsPdop();
            if (gpsTrackPoint.getIoData().getGpsHdop() != null)
                this.gpsHdop = gpsTrackPoint.getIoData().getGpsHdop();
            if (gpsTrackPoint.getIoData().getOdometer() != null)
                this.odometer = gpsTrackPoint.getIoData().getOdometer();
            if (gpsTrackPoint.getIoData().getCellId() != null)
                this.cellId = gpsTrackPoint.getIoData().getCellId();
            if (gpsTrackPoint.getIoData().getAreaCode() != null)
                this.areaCode = gpsTrackPoint.getIoData().getAreaCode();
            if (gpsTrackPoint.getIoData().getMovementValue() != null)
                this.movementValue = gpsTrackPoint.getIoData().getMovementValue();
            if (gpsTrackPoint.getIoData().getPcbTemperature() != null)
                this.pcbTemperature = (gpsTrackPoint.getIoData().getPcbTemperature()) / 10;
            if (gpsTrackPoint.getIoData().getCurrentOperatorCode() != null)
                this.currentOperatorCode = gpsTrackPoint.getIoData().getCurrentOperatorCode();
            setBakDatas(gpsTrackPoint);
            this.canFuelConsumption = gpsTrackPoint.getIoData().getFuelCounterTotal() != null ? gpsTrackPoint.getIoData().getFuelCounterTotal() / 1000 : null;
            this.canFuelLevelPercentage = gpsTrackPoint.getIoData().getFuelLevel() != null ? gpsTrackPoint.getIoData().getFuelLevel() / 10 : null;         //	уровень топлива can (%)
            this.canFuelLevelLiter = gpsTrackPoint.getIoData().getFuelLevelLitr();
            this.countSms = contract.getMaxSmsCmdCount();
            this.dateFormatted = calculateDateFormatted(this.date);
            this.dateSimple = timeToStr(gpsTrackPoint.getDate());
            this.timeMovementSimple = timeToStr(new Timestamp(this.timeMovement));
            this.batteryPercent = gpsTrackPoint.getIoData().getBatteryPercent();
        }

        if (mObjectTracks.getMobject() != null) {
            MobjectBig mObject = mObjectTracks.getMobject();
            this.groupId = mObject.getGroupId();
            this.objectId = mObject.getId();
            this.pinId = mObject.getPinId();
            this.objectPhotoId = mObject.getPhotoId();
            this.objectPhotoName = mObject.getPhotoName();
            this.defaultIcon = mObject.isDefaultIcon();
            this.objectLabelSize = mObject.getLabelSize();
            this.objectName = mObject.getName();

            if (contractSettings.getMappingObjectType() == 1) {
                if (this.defaultIcon) {
                    this.objectPhotoUrl = null;
                } else {
                    if (this.objectPhotoId != 0 && !"".equals(this.objectPhotoName)) {
                        this.objectPhotoUrl = FileStorageService.generateFileName(this.objectPhotoId, this.objectPhotoName);
                    } else {
                        this.objectPhotoUrl = null;
                    }
                }
            } else {
                this.objectPhotoUrl = null;
            }
        }


        changeObjectLabel(mObjectTracks, contractSettings.getObjectLabel());
    }

    public MonitorData(GPSTrackPoint gpsTrackPoint, HttpSession session) {
        this();
//        this.movement = -1;
//        this.engineOn = -1;
//        this.online = -1;
//        this.satellites = -1;
//        this.dat = -1;
//        this.latitude = 0;
//        this.longitude = 0;
//        this.altitude = 0;
//        this.date = 0;
//        this.speed = 0;
//        this.objectId = 0;
//        this.objectPhotoId = 0;
//        this.objectPhotoName = "";
//        this.defaultIcon = true;
//        this.objectPhotoUrl = "";
//        this.objectLabelSize = 0;
//        this.objectLabel = "";
//        this.objectName = "";
//        this.timeMovement = null;
//
//        this.staffId = 0;
//        this.staffName = "";
//        this.staffPhotoId = 0;
//        this.staffPhone = "";
//        this.staffPhoneMobile = "";
//        this.staffPhoto = "";
//        this.staffPhotoUrl = "";
//
//        this.digital1 = 0;
//        this.digital2 = 0;
//        this.digital3 = 0;
//        this.analog1 = 0;
//        this.gsmSignalLevel = 0;
//        this.speedometer = 0;
//        this.externalPowerVoltage = 0;
//        this.internalBatteryVoltage = 0;
//        this.externalPowerVoltageDouble = 0.0;
//        this.internalBatteryVoltageDouble = 0.0;
//        this.gnssStatus = 0;
//        this.gpsPdop = 0;
//        this.gpsHdop = 0;
//        this.odometer = 0;
//        this.cellId = 0;
//        this.areaCode = 0;
//        this.movementValue = 0;
//        this.pcbTemperature = 0;
//        this.currentOperatorCode = 0;
//        this.countSms = null;
//        this.bak1 = null;
//        this.bak2 = null;
//        this.totalIndicationDut = null;

        if (gpsTrackPoint != null) {
            this.movement = gpsTrackPoint.getMovement();
            this.engineOn = gpsTrackPoint.getEngineOn();
            this.online = gpsTrackPoint.getOnline();
            this.satellites = gpsTrackPoint.getSatellites();
            this.angle = gpsTrackPoint.getAngle();
//            this.dat = gpsTrackPoint.getDat();
            this.dat = 1;
            this.latitude = gpsTrackPoint.getLatitude();
            this.longitude = gpsTrackPoint.getLongitude();
            this.altitude = gpsTrackPoint.getAltitude();
            this.date = gpsTrackPoint.getTimestamp();
            this.timeMovement = gpsTrackPoint.getTimeMovement();
            this.speed = gpsTrackPoint.getSpeed();
            if (gpsTrackPoint.getStaff() != null) {
                this.staffId = gpsTrackPoint.getStaff().getId();
                this.staffPhotoId = gpsTrackPoint.getStaff().getPhotoId();
                this.staffName = gpsTrackPoint.getStaff().getSurName() + " " + gpsTrackPoint.getStaff().getName() + " " + gpsTrackPoint.getStaff().getMiddleName();
                this.staffPhoto = gpsTrackPoint.getStaff().getPhotoFilename();
                this.staffPhone = gpsTrackPoint.getStaff().getPhoneLine();
                this.staffPhoneMobile = gpsTrackPoint.getStaff().getPhoneMobile();
            }

            if (gpsTrackPoint.getIoData().getDigital1() != null)
                this.digital1 = gpsTrackPoint.getIoData().getDigital1();
            if (gpsTrackPoint.getIoData().getDigital2() != null)
                this.digital2 = gpsTrackPoint.getIoData().getDigital2();
            if (gpsTrackPoint.getIoData().getDigital3() != null)
                this.digital3 = gpsTrackPoint.getIoData().getDigital3();
            if (gpsTrackPoint.getIoData().getAnalog1() != null)
                this.analog1 = gpsTrackPoint.getIoData().getAnalog1();
            if (gpsTrackPoint.getIoData().getGsmSignalLevel() != null)
                this.gsmSignalLevel = gpsTrackPoint.getIoData().getGsmSignalLevel();
            if (gpsTrackPoint.getIoData().getSpeedometer() != null)
                this.speedometer = gpsTrackPoint.getIoData().getSpeedometer();
            if (gpsTrackPoint.getIoData().getExternalPowerVoltage() != null)
                this.externalPowerVoltage = gpsTrackPoint.getIoData().getExternalPowerVoltage();
            if (gpsTrackPoint.getIoData().getInternalBatteryVoltage() != null)
                this.internalBatteryVoltage = gpsTrackPoint.getIoData().getInternalBatteryVoltage();
            if (gpsTrackPoint.getIoData().getExternalPowerVoltageDouble() != null)
                this.externalPowerVoltageDouble = gpsTrackPoint.getIoData().getExternalPowerVoltageDouble();
            if (gpsTrackPoint.getIoData().getInternalBatteryVoltageDouble() != null)
                this.internalBatteryVoltageDouble = gpsTrackPoint.getIoData().getInternalBatteryVoltageDouble();
            if (gpsTrackPoint.getIoData().getGnssStatus() != null)
                this.gnssStatus = gpsTrackPoint.getIoData().getGnssStatus();
            if (gpsTrackPoint.getIoData().getGpsPdop() != null)
                this.gpsPdop = gpsTrackPoint.getIoData().getGpsPdop();
            if (gpsTrackPoint.getIoData().getGpsHdop() != null)
                this.gpsHdop = gpsTrackPoint.getIoData().getGpsHdop();
            if (gpsTrackPoint.getIoData().getOdometer() != null)
                this.odometer = gpsTrackPoint.getIoData().getOdometer();
            if (gpsTrackPoint.getIoData().getCellId() != null)
                this.cellId = gpsTrackPoint.getIoData().getCellId();
            if (gpsTrackPoint.getIoData().getAreaCode() != null)
                this.areaCode = gpsTrackPoint.getIoData().getAreaCode();
            if (gpsTrackPoint.getIoData().getMovementValue() != null)
                this.movementValue = gpsTrackPoint.getIoData().getMovementValue();
            if (gpsTrackPoint.getIoData().getPcbTemperature() != null)
                this.pcbTemperature = (gpsTrackPoint.getIoData().getPcbTemperature()) / 10;
            if (gpsTrackPoint.getIoData().getCurrentOperatorCode() != null)
                this.currentOperatorCode = gpsTrackPoint.getIoData().getCurrentOperatorCode();

            Contract contract = MainController.getUserContract(session);
            if (contract != null)
                this.countSms = contract.getMaxSmsCmdCount();

            setBakDatas(gpsTrackPoint);
        }
    }

    private void setBakDatas(GPSTrackPoint gpsTrackPoint) {
        this.bak1 = gpsTrackPoint.getBak1();
        this.bak2 = gpsTrackPoint.getBak2();
        this.bak3 = gpsTrackPoint.getBak3();
        this.bak4 = gpsTrackPoint.getBak4();
        this.totalIndicationDut = gpsTrackPoint.getBakTotal();
        this.bak1Litr = gpsTrackPoint.getBak1Litr();
        this.bak2Litr = gpsTrackPoint.getBak2Litr();
        this.bak3Litr = gpsTrackPoint.getBak3Litr();
        this.bak4Litr = gpsTrackPoint.getBak4Litr();
        this.bakTotalLitr = gpsTrackPoint.getBakTotalLitr();
    }

    private void changeObjectLabel(MobjectTracks mobjectTracks, long objectLabelType) {
        if (objectLabelType == 0) {
            this.objectLabel = "";
        } else if (objectLabelType == 4) {
            if (mobjectTracks != null && mobjectTracks.getTracks().size() > 0) {
                GPSTrackPoint gpsTrackPoint = mobjectTracks.getTracks().get(0);
                if (gpsTrackPoint.getStaff() != null) {
                    this.objectLabel = gpsTrackPoint.getStaff().getName();
                }
            }
        } else {
            if (mobjectTracks.getMobject() != null) {
                MobjectBig mObject = mobjectTracks.getMobject();
                if (objectLabelType == 1 && mObject.getName() != null) {
                    this.objectLabel = mObject.getName();
                } else if (objectLabelType == 2) {
                    this.objectLabel = mObject.getType();
                } else if (objectLabelType == 3) {
                    this.objectLabel = mObject.getPlateNumber();
                }
            }
        }
    }

    public byte getMovement() {
        return movement;
    }

    public void setMovement(byte movement) {
        this.movement = movement;
    }

    public byte getEngineOn() {
        return engineOn;
    }

    public void setEngineOn(byte engineOn) {
        this.engineOn = engineOn;
    }

    public byte getOnline() {
        return online;
    }

    public void setOnline(byte online) {
        this.online = online;
    }

    public byte getDat() {
        return dat;
    }

    public String getDateFormatted() {
        return dateFormatted;
    }

    public void setDateFormatted(String dateFormatted) {
        this.dateFormatted = dateFormatted;
    }

    public String getDateSimple() {
        return dateSimple;
    }

    public void setDateSimple(String dateSimple) {
        this.dateSimple = dateSimple;
    }

    public String getUrlIcon() {
        return urlIcon;
    }

    public void setUrlIcon(String urlIcon) {
        this.urlIcon = urlIcon;
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public void setDat(byte dat) {
        this.dat = dat;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public long getStaffPhotoId() {
        return staffPhotoId;
    }

    public void setStaffPhotoId(long staffPhotoId) {
        this.staffPhotoId = staffPhotoId;
    }

    public long getObjectId() {
        return objectId;
    }

    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    public long getPinId() {
        return pinId;
    }

    public void setPinId(long pinId) {
        this.pinId = pinId;
    }

    public long getObjectPhotoId() {
        return objectPhotoId;
    }

    public void setObjectPhotoId(long objectPhotoId) {
        this.objectPhotoId = objectPhotoId;
    }

    public String getObjectPhotoName() {
        return objectPhotoName;
    }

    public void setObjectPhotoName(String objectPhotoName) {
        this.objectPhotoName = objectPhotoName;
    }

    public String getObjectPhotoUrl() {
        return this.objectPhotoUrl;
    }

    public void setObjectPhotoUrl(String objectPhotoUrl) {
        this.objectPhotoUrl = objectPhotoUrl;
    }

    public Boolean getDefaultIcon() {
        return defaultIcon;
    }

    public void setDefaultIcon(Boolean defaultIcon) {
        this.defaultIcon = defaultIcon;
    }

    public long getObjectLabelSize() {
        return objectLabelSize;
    }

    public void setObjectLabelSize(long objectLabelSize) {
        this.objectLabelSize = objectLabelSize;
    }

    public String getObjectLabel() {
        return objectLabel;
    }

    public void setObjectLabel(String objectLabel) {
        this.objectLabel = objectLabel;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public Double getExternalPowerVoltageDouble() {
        return externalPowerVoltageDouble;
    }

    public void setExternalPowerVoltageDouble(Double externalPowerVoltageDouble) {
        this.externalPowerVoltageDouble = externalPowerVoltageDouble;
    }

    public Double getInternalBatteryVoltageDouble() {
        return internalBatteryVoltageDouble;
    }

    public void setInternalBatteryVoltageDouble(Double internalBatteryVoltageDouble) {
        this.internalBatteryVoltageDouble = internalBatteryVoltageDouble;
    }

    public byte getSatellites() {
        return satellites;
    }

    public void setSatellites(byte satellites) {
        this.satellites = satellites;
    }

    public short getAngle() {
        return angle;
    }

    public void setAngle(short angle) {
        this.angle = angle;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getAltitude() {
        return altitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    public long getStaffId() {
        return staffId;
    }

    public void setStaffId(long staffId) {
        this.staffId = staffId;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffPhoto() {
        return staffPhoto;
    }

    public void setStaffPhoto(String staffPhoto) {
        this.staffPhoto = staffPhoto;
    }

    public String getStaffPhotoUrl() {
        this.staffPhotoUrl = (this.staffPhotoId != 0 && !"".equals(this.staffPhoto)) ? FileStorageService.generateFileName(this.staffPhotoId, this.staffPhoto) : "";
        return staffPhotoUrl;
    }

    public void setStaffPhotoUrl(String staffPhotoUrl) {
        this.staffPhotoUrl = staffPhotoUrl;
    }

    public String getStaffPhone() {
        return staffPhone;
    }

    public void setStaffPhone(String staffPhone) {
        this.staffPhone = staffPhone;
    }

    public Byte getDigital1() {
        return digital1;
    }

    public void setDigital1(Byte digital1) {
        this.digital1 = digital1;
    }

    public Byte getDigital2() {
        return digital2;
    }

    public void setDigital2(Byte digital2) {
        this.digital2 = digital2;
    }

    public Byte getDigital3() {
        return digital3;
    }

    public void setDigital3(Byte digital3) {
        this.digital3 = digital3;
    }

    public Short getAnalog1() {
        return analog1;
    }

    public void setAnalog1(Short analog1) {
        this.analog1 = analog1;
    }

    public Byte getGsmSignalLevel() {
        return gsmSignalLevel;
    }

    public void setGsmSignalLevel(Byte gsmSignalLevel) {
        this.gsmSignalLevel = gsmSignalLevel;
    }

    public Short getSpeedometer() {
        return speedometer;
    }

    public void setSpeedometer(Short speedometer) {
        this.speedometer = speedometer;
    }

    public Short getExternalPowerVoltage() {
        return externalPowerVoltage;
    }

    public void setExternalPowerVoltage(Short externalPowerVoltage) {
        this.externalPowerVoltage = externalPowerVoltage;
    }

    public Short getInternalBatteryVoltage() {
        return internalBatteryVoltage;
    }

    public void setInternalBatteryVoltage(Short internalBatteryVoltage) {
        this.internalBatteryVoltage = internalBatteryVoltage;
    }

    public Byte getGnssStatus() {
        return gnssStatus;
    }

    public void setGnssStatus(Byte gnssStatus) {
        this.gnssStatus = gnssStatus;
    }

    public Short getGpsPdop() {
        return gpsPdop;
    }

    public void setGpsPdop(Short gpsPdop) {
        this.gpsPdop = gpsPdop;
    }

    public Short getGpsHdop() {
        return gpsHdop;
    }

    public void setGpsHdop(Short gpsHdop) {
        this.gpsHdop = gpsHdop;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Short getCellId() {
        return cellId;
    }

    public void setCellId(Short cellId) {
        this.cellId = cellId;
    }

    public Short getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(Short areaCode) {
        this.areaCode = areaCode;
    }

    public Byte getMovementValue() {
        return movementValue;
    }

    public void setMovementValue(Byte movementValue) {
        this.movementValue = movementValue;
    }

    public Integer getPcbTemperature() {
        return pcbTemperature;
    }

    public void setPcbTemperature(Integer pcbTemperature) {
        this.pcbTemperature = pcbTemperature;
    }

    public Integer getCurrentOperatorCode() {
        return currentOperatorCode;
    }

    public void setCurrentOperatorCode(Integer currentOperatorCode) {
        this.currentOperatorCode = currentOperatorCode;
    }

    public Integer getBatteryPercent() {
        return batteryPercent;
    }

    public void setBatteryPercent(Integer batteryPercent) {
        this.batteryPercent = batteryPercent;
    }

    public Integer getBak1() {
        return bak1;
    }

    public void setBak1(Integer bak1) {
        this.bak1 = bak1;
    }

    public Integer getBak2() {
        return bak2;
    }

    public void setBak2(Integer bak2) {
        this.bak2 = bak2;
    }

    public Integer getBak3() {
        return bak3;
    }

    public void setBak3(Integer bak3) {
        this.bak3 = bak3;
    }

    public Integer getBak4() {
        return bak4;
    }

    public void setBak4(Integer bak4) {
        this.bak4 = bak4;
    }

    public Double getBak1Litr() {
        return bak1Litr;
    }

    public void setBak1Litr(Double bak1Litr) {
        this.bak1Litr = bak1Litr;
    }

    public Double getBak2Litr() {
        return bak2Litr;
    }

    public void setBak2Litr(Double bak2Litr) {
        this.bak2Litr = bak2Litr;
    }

    public Double getBak3Litr() {
        return bak3Litr;
    }

    public void setBak3Litr(Double bak3Litr) {
        this.bak3Litr = bak3Litr;
    }

    public Double getBak4Litr() {
        return bak4Litr;
    }

    public void setBak4Litr(Double bak4Litr) {
        this.bak4Litr = bak4Litr;
    }

    public Double getBakTotalLitr() {
        return bakTotalLitr;
    }

    public void setBakTotalLitr(Double bakTotalLitr) {
        this.bakTotalLitr = bakTotalLitr;
    }

    public String getStaffPhoneMobile() {
        return staffPhoneMobile;
    }

    public void setStaffPhoneMobile(String staffPhoneMobile) {
        this.staffPhoneMobile = staffPhoneMobile;
    }

    public Integer getTotalIndicationDut() {
        return totalIndicationDut;
    }

    public void setTotalIndicationDut(Integer totalIndicationDut) {
        this.totalIndicationDut = totalIndicationDut;
    }

    public Long getCanFuelConsumption() {
        return canFuelConsumption;
    }

    public void setCanFuelConsumption(Long canFuelConsumption) {
        this.canFuelConsumption = canFuelConsumption;
    }

    public Integer getCanFuelLevelLiter() {
        return canFuelLevelLiter;
    }

    public void setCanFuelLevelLiter(Integer canFuelLevelLiter) {
        this.canFuelLevelLiter = canFuelLevelLiter;
    }

    public Integer getCanFuelLevelPercentage() {
        return canFuelLevelPercentage;
    }

    public void setCanFuelLevelPercentage(Integer canFuelLevelPercentage) {
        this.canFuelLevelPercentage = canFuelLevelPercentage;
    }

    public Long getCountSms() {
        return countSms;
    }

    public void setCountSms(Long countSms) {
        this.countSms = countSms;
    }

    public Long getTimeMovement() {
        return timeMovement;
    }

    public void setTimeMovement(Long timeMovement) {
        this.timeMovement = timeMovement;
    }

    public String getTimeMovementSimple() {
        return timeMovementSimple;
    }

    public void setTimeMovementSimple(String timeMovementSimple) {
        this.timeMovementSimple = timeMovementSimple;
    }
}
