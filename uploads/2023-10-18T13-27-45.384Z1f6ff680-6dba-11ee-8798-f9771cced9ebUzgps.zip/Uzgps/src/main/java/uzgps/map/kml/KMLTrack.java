package uzgps.map.kml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by Gayratjon on 1/29/14.
 */
@XmlRootElement(name = "gx:Track", namespace = "")
public class KMLTrack {

    private List<Date> kmlWhenList;
    private List<String> kmlCoordList;
    private List<Short> kmlAngelsList;
    private List<Integer> kmlSpeedList;

    public KMLTrack() {
        kmlWhenList = new ArrayList<>();
        kmlCoordList = new ArrayList<>();
        kmlAngelsList = new ArrayList<>();
        kmlSpeedList = new ArrayList<>();
    }

    @XmlElement(name = "when")
    public List<Date> getKmlWhenList() {
        return kmlWhenList;
    }

    public void setKmlWhenList(ArrayList<Date> kmlWhenList) {
        this.kmlWhenList = kmlWhenList;
    }

    @XmlElement(name = "gx:coord")
    public List<String> getKmlCoordList() {
        return kmlCoordList;
    }

    public void setKmlCoordList(List<String> kmlCoordList) {
        this.kmlCoordList = kmlCoordList;
    }

    @XmlElement(name = "gx:angles")
    public List<Short> getKmlAngelsList() {
        return kmlAngelsList;
    }

    public void setKmlAngelsList(List<Short> kmlAngelsList) {
        this.kmlAngelsList = kmlAngelsList;
    }

    public void setKmlWhenList(List<Date> kmlWhenList) {
        this.kmlWhenList = kmlWhenList;
    }

    @XmlElement(name = "speed")
    public List<Integer> getKmlSpeedList() {
        return kmlSpeedList;
    }

    public void setKmlSpeedList(List<Integer> kmlSpeedList) {
        this.kmlSpeedList = kmlSpeedList;
    }

    public int size() {
        return kmlWhenList.size();
    }
}
