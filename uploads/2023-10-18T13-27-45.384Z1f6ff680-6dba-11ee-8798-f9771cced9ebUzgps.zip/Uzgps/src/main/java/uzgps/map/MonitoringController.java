package uzgps.map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.core.helper.CorePoi;
import uz.netex.datatype.*;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Poi;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.routing.database.tables.Trip;
import uz.netex.routing.database.tables.TripRoute;
import uz.netex.routing.service.TripRunnerService;
import uzgps.common.CommonUtils;
import uzgps.common.UZGPS_CONST;
import uzgps.main.AppLastStatus;
import uzgps.main.MainController;
import uzgps.map.models.*;
import uzgps.map.models.notification.MessageNotification;
import uzgps.persistence.Contract;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.UserAccessList;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.Serializable;
import java.util.*;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

/**
 * Created by Gayrat on 09.01.14
 */

@SuppressWarnings("JavaDoc")
@Controller
public class MonitoringController {

    private final static String URL_MAP_MONITORING_PANEL = "/map/monitoring.htm";
    private final static String VIEW_MAP_MONITORING_PANEL = "map/ajax-map-monitoring";
    private final static String URL_ZONED_MOBJECT_LIST = "/map/zoned-mobject-list.htm";
    private final static String VIEW_ZONED_MOBJECT_LIST = "/map/ajax-zoned-mobject-list";
    private final static String URL_MAP_MONITORING_OBJECT_LIST_JSON = "/map/monitoring-object-list-json.htm";

    @Autowired
    CoreMain coreMain;

    @Autowired
    SettingsService settingsService;

    @Autowired
    MainController mainController;

    @Autowired
    ObjectMapper jsonMapper;

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public void processMapMonitoringModel(HttpSession session, ModelAndView modelAndView, String cmd) throws IOException {
        ContractSettings contractSettings = mainController.getContractSettings(session);

        if (cmd != null) {
            List<MobjectBig> mObjectList = getMobjects(session, true);

            // Sort list of objects
            if (mObjectList != null && mObjectList.size() > 0) {
                Collections.sort(mObjectList);
            }

            switch (cmd) {
                case MonitoringObjectSelectionOption.KEY_MONITORING_OBJECTS_ALL -> {
                    if (mObjectList != null && mObjectList.size() > 0) {
                        Gson mObjectListGson = new GsonBuilder().create();
                        String mObjectListJson = mObjectListGson.toJson(mObjectList);

                        modelAndView.addObject("mObjectList", mObjectList);
                        modelAndView.addObject("mObjectListJson", mObjectListJson);
//                    modelAndView.addObject("trackedObjectsMinZoom", contractSettings.getTrackedObjectsMinZoom());
                        modelAndView.addObject("trackedObjectsMaxZoom", contractSettings.getTrackedObjectsMaxZoom());
                    }
                }
                case MonitoringObjectSelectionOption.KEY_MONITORING_OBJECTS_GROUP -> {
                    if (mObjectList != null && mObjectList.size() > 0) {
                        Map<Long, List<MobjectBig>> groupedMObjectList = new HashMap<>();

                        for (MobjectBig mObject : mObjectList) {
                            if (groupedMObjectList.containsKey(mObject.getGroupId())) {
                                groupedMObjectList.get(mObject.getGroupId()).add(mObject);
                            } else {
                                List<MobjectBig> mObjects = new ArrayList<>();
                                mObjects.add(mObject);
                                groupedMObjectList.put(mObject.getGroupId(), mObjects);
                            }
                        }
                        modelAndView.addObject("groupedMObjectList", groupedMObjectList);
                    }
                }
                case MonitoringObjectSelectionOption.KEY_MONITORING_OBJECTS_ZONE -> {
                    modelAndView.addObject("mObjectList", mObjectList);
                    getMobjectListByZones(modelAndView, session);
                }
            }

            Long trackPointsCount = contractSettings.getTrackLengthValue();
            Long trackPointsType = contractSettings.getTrackLengthType();
            Boolean showObjectsInCluster = contractSettings.getShowObjectsInCluster();
            Boolean poiLoadStartup = contractSettings.getPoiLoadStartup();
            Boolean geozoneLoadStartup = contractSettings.getGeozoneLoadStartup();
            Map<Long, List<Point>> trackPointsMap = new HashMap<>();

            if (mObjectList != null && mObjectList.size() > 0) {
                for (MobjectBig mObject : mObjectList) {
                    GPSTrackPointList gpsTrackPointList;
                    if (trackPointsType == 1)
                        gpsTrackPointList = coreMain.getPointsByDate(mObject.getId(), 0L, 0L, trackPointsCount.intValue());
                    else
                        gpsTrackPointList = coreMain.getPointsByLastSeconds(mObject.getId(), trackPointsCount);

                    // Delete ZERO points
                    coreMain.deleteZeroPoints(gpsTrackPointList);

                    if (gpsTrackPointList.size() > 0) {
                        List<Point> pointList = new ArrayList<>();
                        for (GPSTrackPoint gpsTrackPoint : gpsTrackPointList.getGpsTrackPoints()) {
                            Point point = new Point();
                            point.setLatitude(gpsTrackPoint.getLatitude());
                            point.setLongitude(gpsTrackPoint.getLongitude());
                            point.setAltitude(gpsTrackPoint.getAltitude());
                            point.setTimeStamp(gpsTrackPoint.getTimestamp());
                            pointList.add(point);
                        }
                        trackPointsMap.put(mObject.getId(), pointList);

                        mObject.setStatusDat(gpsTrackPointList.getGpsTrackPoints().get(0).getSpeed());
                    }
                }
            }
            modelAndView.addObject("showObjectsInCluster", showObjectsInCluster);
            modelAndView.addObject("poiLoadStartup", poiLoadStartup);
            modelAndView.addObject("geozoneLoadStartup", geozoneLoadStartup);
            modelAndView.addObject("trackPointsMap", jsonMapper.writeValueAsString(trackPointsMap));
            modelAndView.addObject("trackPointsCount", trackPointsCount);
            modelAndView.addObject("trackPointsType", trackPointsType);
            modelAndView.addObject("trackPointsColor", contractSettings.getTrackLengthColor());
            modelAndView.addObject("objectMovementType", contractSettings.getObjectMovementType());
            modelAndView.addObject("isShowSuspendedObjects", contractSettings.getIsShowSuspendedObjects());
        }

        UserAccessList userAccessList = (UserAccessList) session.getAttribute(MainController.SESSION_USER_ACCESS_LIST);

        MObjectCIList mObjectCIList = new MObjectCIList(contractSettings, userAccessList);
        modelAndView.addObject("objectSelectionOptions", MonitoringObjectSelectionOption.list());
        modelAndView.addObject("mObjectCIList", mObjectCIList.get());

        modelAndView.addObject("cmd", cmd);
//        modelAndView.addObject("accessPoi", userAccessList.getPoi());
//        modelAndView.addObject("accessZoi", userAccessList.getGeoZone());
    }

    @RequestMapping(value = URL_MAP_MONITORING_PANEL)
    public ModelAndView processMapMonitoringPanel(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String
                                                          appStatus,
                                                  HttpSession session,
                                                  @RequestParam(value = "cmd", required = false) String cmd) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_MAP_MONITORING_PANEL);
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        modelAndView.addObject("appLastStatus", appLastStatus);
        processMapMonitoringModel(session, modelAndView, cmd);

        return modelAndView;
    }

    @RequestMapping(value = URL_ZONED_MOBJECT_LIST)
    public ModelAndView processZonedMobjectList(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String
                                                        appStatus,
                                                HttpSession session)
            throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_ZONED_MOBJECT_LIST);
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        modelAndView.addObject("appLastStatus", appLastStatus);

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        UserAccessList userAccessList = (UserAccessList) session.getAttribute(MainController.SESSION_USER_ACCESS_LIST);

        MObjectCIList mObjectCIList = new MObjectCIList(contractSettings, userAccessList);
        modelAndView.addObject("mObjectCIList", mObjectCIList.get());

        getMobjectListByZones(modelAndView, session);

        return modelAndView;
    }

    /**
     * Loading last points and other data for each mobject from ajax call
     *
     * @param session
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_MAP_MONITORING_OBJECT_LIST_JSON, method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String processGettingMovableObjects(HttpSession session,
                                               @RequestParam(value = "updtime", required = false, defaultValue = "0") Long updTime)
            throws ServletException, IOException {

        List<MobjectTracks> mObjectTracksList = getMobjectTracksList(session);

        ContractSettings contractSettings = mainController.getContractSettings(session);
        MObjectTrackDataJSONList mObjectTrackDataJSONList = new MObjectTrackDataJSONList();
        Set<String> ignorableMObjectTrackFieldNames = new HashSet<>();
        Set<String> ignorableMonitorFieldNames = new HashSet<>();

        if (mObjectTracksList.size() > 0) {
            mObjectTrackDataJSONList.newArrayList();
            Long trackPointsCount = contractSettings.getTrackLengthValue();
            Long trackPointsType = contractSettings.getTrackLengthType();

            // Collect mobject in Poi
            CorePoi corePoi = CorePoi.getInstance();
            // Collect mobject in Geofence
            CoreGeofence coreGeofence = CoreGeofence.getInstance();


            if (corePoi != null) {
                corePoi.loadMobjectsInPoi();
            }

            if (coreGeofence != null) {
                coreGeofence.loadMobjectsInGeofence();
            }

            for (MobjectTracks mobjectTracks : mObjectTracksList) {
                MObjectTrackDataJSON mObjectTrackDataJSON = new MObjectTrackDataJSON();

                // Preparing monitor data for indicator icons on the left side
                MonitorData monitorData = new MonitorData(mobjectTracks, contractSettings, session);
                mObjectTrackDataJSON.setMonitorData(monitorData);

                // Preparing popup data for mobject
                List<GPSTrackPoint> trackPoints = mobjectTracks.getTracks();
                GPSTrackPoint trackPoint = null;

                if (trackPoints != null && trackPoints.size() > 0) {
                    trackPoint = trackPoints.get(0);
                }

                MobjectBig mobjectBig = mobjectTracks.getMobject();

                TrackPopupData trackPopupData = new TrackPopupData();
                trackPopupData.setGPSTrackPoint(trackPoint);
                trackPopupData.setSensorDisplayList(contractSettings.getSensorDisplayList());
                trackPopupData.setMobjectBig(mobjectBig);

                List<Poi> poiList = null;
                List<Geofence> geofenceList = null;

                if (corePoi != null) {
                    poiList = corePoi.getPoiWithMobjectInside(mobjectBig.getId());
                }

                if (coreGeofence != null) {
                    geofenceList = coreGeofence.getGeofencesWithMobjectInside(mobjectBig.getId());
                }

                trackPopupData.setPoiAndGeoFenceList(poiList, geofenceList);

                trackPopupData.setAssignedRoutes(getAssignedTripNamesToMobject(mobjectBig.getId()));

                mObjectTrackDataJSON.setTrackPopupData(trackPopupData);

                // Collect each mobject's tail track
                GPSTrackPointList gpsTrackPointList;
                if (trackPointsType == 1)
                    gpsTrackPointList = coreMain.getPointsByDate(mobjectTracks.getMobject().getId(), 0L, 0L, trackPointsCount.intValue());
                else
                    gpsTrackPointList = coreMain.getPointsByLastSeconds(mobjectTracks.getMobject().getId(), trackPointsCount);

                // Delete ZERO points
                coreMain.deleteZeroPoints(gpsTrackPointList);

                if (gpsTrackPointList.size() > 0) {
                    List<Point> pointList = new ArrayList<>();
                    for (GPSTrackPoint gpsTrackPoint : gpsTrackPointList.getGpsTrackPoints()) {
                        Point point = new Point();
                        point.setLatitude(gpsTrackPoint.getLatitude());
                        point.setLongitude(gpsTrackPoint.getLongitude());
                        point.setAltitude(gpsTrackPoint.getAltitude());
                        point.setTimeStamp(gpsTrackPoint.getTimestamp());
                        pointList.add(point);
                    }
                    mObjectTrackDataJSON.setPointList(pointList);
                }

//                mObjectTrackDataJSON.setPointList(pointList);
                if (contractSettings.getTooltipsMassagesView()) {
                    MessageNotification messageNotification = new MessageNotification(mobjectTracks, contractSettings.getTooltipsMassagesColor());
//                    messageNotification.englishText();
                    mObjectTrackDataJSON.setMessageNot(messageNotification);
                }

                // Check if this object changed before?
                // TODO - Need Update time !!! From Core side
                if (updTime > 0) {
                    if (monitorData.getDate() >= updTime)
                        mObjectTrackDataJSONList.add(mObjectTrackDataJSON);
                } else {
                    mObjectTrackDataJSONList.add(mObjectTrackDataJSON);
                }

                if (mObjectTrackDataJSONList.getNextUpdTime() == 0) {
                    mObjectTrackDataJSONList.setNextUpdTime(monitorData.getDate());
                } else {
                    if (mObjectTrackDataJSONList.getNextUpdTime() < monitorData.getDate())
                        mObjectTrackDataJSONList.setNextUpdTime(monitorData.getDate());
                }

            }

            ignorableMObjectTrackFieldNames.add("messageData");
            if (!contractSettings.getTooltipsMassagesView())
                ignorableMObjectTrackFieldNames.add("messageNot");

            // Ignoring fields for monitoring
            if (!contractSettings.getObjectStatusView())
                ignorableMonitorFieldNames.add("movement");
            if (!contractSettings.getIgnitionSensorView())
                ignorableMonitorFieldNames.add("engineOn");
//            if (!contractSettings.getObjectLinkView())
//                ignorableMonitorFieldNames.add("online");
            if (!contractSettings.getSatelliteVisibilityView())
                ignorableMonitorFieldNames.add("satellites");
            if (!contractSettings.getSensorStateView())
                ignorableMonitorFieldNames.add("dat");
            if (!contractSettings.getObjectDriverView()) {
                ignorableMonitorFieldNames.add("staffName");
                ignorableMonitorFieldNames.add("staffPhotoUrl");
                ignorableMonitorFieldNames.add("staffPhone");
            }

            if (!contractSettings.getBakPositionView()) {
                ignorableMonitorFieldNames.add("bak1");
                ignorableMonitorFieldNames.add("bak2");
                ignorableMonitorFieldNames.add("bak3");
                ignorableMonitorFieldNames.add("bak4");
                ignorableMonitorFieldNames.add("totalIndicationDut");
                ignorableMonitorFieldNames.add("canFuelConsumption");
                ignorableMonitorFieldNames.add("canFuelLevelLiter");
                ignorableMonitorFieldNames.add("canFuelLevelPercentage");

            } else {
                Integer value = contractSettings.getMonitoringValuesPart2() != null ? contractSettings.getMonitoringValuesPart2() : 0;

                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_1) == 0)
                    ignorableMonitorFieldNames.add("bak1");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_2) == 0)
                    ignorableMonitorFieldNames.add("bak2");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TOTAL_INDICATION_DUT) == 0)
                    ignorableMonitorFieldNames.add("totalIndicationDut");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_CONSUMPTION) == 0)
                    ignorableMonitorFieldNames.add("canFuelConsumption");


                value = contractSettings.getMonitoringValuesPart3() != null ? contractSettings.getMonitoringValuesPart3() : 0;

                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_LEVEL_LITER) == 0)
                    ignorableMonitorFieldNames.add("canFuelLevelLiter");

                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_LEVEL_PERCENTAGE) == 0)
                    ignorableMonitorFieldNames.add("canFuelLevelPercentage");

                value = contractSettings.getMonitoringValuesPart4() != null ? contractSettings.getMonitoringValuesPart4() : 0;

                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_3) == 0)
                    ignorableMonitorFieldNames.add("bak3");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_4) == 0)
                    ignorableMonitorFieldNames.add("bak4");


            }
            if (!contractSettings.getSmsSendView())
                ignorableMonitorFieldNames.add("countSms");
        }

//        try {
        SimpleFilterProvider filterProvider = new SimpleFilterProvider();
        filterProvider.addFilter("MObjectTrackDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableMObjectTrackFieldNames));
        filterProvider.addFilter("TrackPopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(TrackPopupData.monitoringPopupIgnoredFieldNames(contractSettings)));
//            filterProvider.addFilter("PopupDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorablePopupFieldNames));
        filterProvider.addFilter("MonitorDataFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableMonitorFieldNames));

        jsonMapper.configure(SerializationFeature.WRITE_NULL_MAP_VALUES, false);

        ObjectWriter objectWriter = jsonMapper.writer(filterProvider);//.withRootName("data");

        return objectWriter.writeValueAsString(mObjectTrackDataJSONList);
    }

    private void getMobjectListByZones(ModelAndView modelAndView, HttpSession session) {
        if (modelAndView == null) {
            return;
        }

        List<MobjectTracks> mObjectTracksList = getMobjectTracksList(session);

        List<MobjectBigZoned> mObjectList = new ArrayList<>();
        Set<MobjectBigZoned> mobjectInZoneList = new HashSet<>();
        TreeSet<MobjectBigZoned> mobjectOutZoneList = new TreeSet<>();
        ContractSettings contractSettings = mainController.getContractSettings(session);

        for (MobjectTracks mobjectTracks : mObjectTracksList) {
            MobjectBigZoned mobjectBigZoned = new MobjectBigZoned();
            mobjectBigZoned.setMobjectBig(mobjectTracks.getMobject());

            // Preparing monitor data for indicator icons on the left side
            MonitorData monitorData = new MonitorData(mobjectTracks, contractSettings, session);
            mobjectBigZoned.setMonitorData(monitorData);

            mObjectList.add(mobjectBigZoned);
            mobjectOutZoneList.add(mobjectBigZoned);
        }

        // Collect mobject in Poi
        CorePoi corePoi = CorePoi.getInstance();
        // Collect mobject in Geofence
        CoreGeofence coreGeofence = CoreGeofence.getInstance();


        // Collect mobject in Poi
        if (corePoi != null) {
            List<Poi> poiList = getPoiList(corePoi, session);

            Map<Long, List<MobjectBigZoned>> poiMobjectList =
                    getMobjectListInPoiList(
                            corePoi,
                            poiList,
                            mObjectList,
                            mobjectInZoneList,
                            mobjectOutZoneList);

            modelAndView.addObject("poiList", poiList);
            modelAndView.addObject("poiMobjectList", poiMobjectList);
        }
        modelAndView.addObject("mobjectOutZoneList", new ArrayList<>(mobjectOutZoneList));

        // Collect mobject in Geofence
        if (coreGeofence != null) {
            List<Geofence> geofenceList = getGeofenceList(coreGeofence, session);

            Map<Long, List<MobjectBigZoned>> geofenceMobjectList =
                    getMobjectListInGeofenceList(
                            coreGeofence,
                            geofenceList,
                            mObjectList,
                            mobjectInZoneList,
                            mobjectOutZoneList);

            modelAndView.addObject("geofenceList", geofenceList);
            modelAndView.addObject("geofenceMobjectList", geofenceMobjectList);
        }
        modelAndView.addObject("mobjectOutZoneList", new ArrayList<>(mobjectOutZoneList));

    }

    public List<String> getAssignedTripNamesToMobject(Long mobjectId) {
        if (mobjectId == null)
            return null;

        CoreTripRoutingControl tripRoutingControl = coreMain.getCoreTripRoutingControl();

        if (tripRoutingControl != null) {
            TripRunnerService tripRunnerService = tripRoutingControl.getTripRunnerService();
            if (tripRunnerService != null) {
                List<Trip> tripList = tripRunnerService.getByMobject(mobjectId);
                List<String> tripNames = new ArrayList<>();

                if (tripList != null && !tripList.isEmpty()) {
                    for (Trip trip : tripList) {
                        TripRoute tripRoute = trip.getTripRoute();
                        String tripName = tripRoute.getName();
                        tripNames.add(tripName);
                    }
                }
                return tripNames;
            }
        }

        return null;
    }

    /**
     * corePoi
     *
     * @param corePoi
     * @param poiList
     * @param mobjectList
     * @param mobjectInZoneList
     * @param mobjectOutZoneList
     * @return
     */
    private Map<Long, List<MobjectBigZoned>> getMobjectListInPoiList(
            CorePoi corePoi,
            List<Poi> poiList,
            List<MobjectBigZoned> mobjectList,
            Set<MobjectBigZoned> mobjectInZoneList,
            TreeSet<MobjectBigZoned> mobjectOutZoneList) {

        Map<Long, List<MobjectBigZoned>> poiMobjectListMap = new HashMap<>();
        List<MobjectBigZoned> foundMobjectsInPoi;

        if (poiList != null && !poiList.isEmpty()
                && mobjectList != null && !mobjectList.isEmpty()
                && mobjectInZoneList != null) {

            // Get all poi IDs and Mobject IDs, where Mobject is inside Poi
            Map<Long, List<MobjectInPoiGeofence>> mapByPoiForMobjectInPoi = null;
            if (corePoi != null) {
                corePoi.loadMobjectsInPoi();
                mapByPoiForMobjectInPoi = corePoi.getMapByPoiForMobjectInPoi();
            }

            // If there is some Mobjects inside Poi, use them
            if (mapByPoiForMobjectInPoi != null) {
                for (Poi poi : poiList) {
                    foundMobjectsInPoi = new ArrayList<>();

                    List<MobjectInPoiGeofence> mobjectsInPoi = mapByPoiForMobjectInPoi.get(poi.getId());

                    if (mobjectsInPoi != null) {

                        for (MobjectInPoiGeofence mobjectInPoi : mobjectsInPoi) {

                            MobjectBigZoned mobz = mobjectList.stream().filter(o -> o.getMobjectBig().getId().equals(mobjectInPoi.getMobjectId())).findFirst().orElse(null);

                            if (mobz != null) {
                                foundMobjectsInPoi.add(mobz);
                                mobjectOutZoneList.remove(mobz);
                            }

                        }
                    }

                    poiMobjectListMap.put(poi.getId(), foundMobjectsInPoi);
                }
            }
        }

        return poiMobjectListMap;

    }

    /**
     * Get list of mobject which is currently in given poi list
     *
     * @param geofenceList
     * @param mobjectList
     * @param mobjectInZoneList
     * @return
     */
    private Map<Long, List<MobjectBigZoned>> getMobjectListInGeofenceList(
            CoreGeofence coreGeofence,
            List<Geofence> geofenceList,
            List<MobjectBigZoned> mobjectList,
            Set<MobjectBigZoned> mobjectInZoneList,
            TreeSet<MobjectBigZoned> mobjectOutZoneList) {

        Map<Long, List<MobjectBigZoned>> geofenceMobjectListMap = new HashMap<>();
        List<MobjectBigZoned> foundMobjectsInGeofence;

        if (geofenceList != null && !geofenceList.isEmpty()
                && mobjectList != null && !mobjectList.isEmpty()
                && mobjectInZoneList != null) {

            // Get all geofence IDs and Mobject IDs, where Mobject is inside Geofence
            Map<Long, List<MobjectInPoiGeofence>> mapByGeofenceForMobjectInGeofence = null;
            if (coreGeofence != null) {
                coreGeofence.loadMobjectsInGeofence();
                mapByGeofenceForMobjectInGeofence = coreGeofence.getMapByGeofenceForMobjectInGeofence();
            }

            // If there is some Mobjects inside Geofence, use them
            if (mapByGeofenceForMobjectInGeofence != null) {
                for (Geofence geofence : geofenceList) {
                    foundMobjectsInGeofence = new ArrayList<>();

                    List<MobjectInPoiGeofence> mobjectsInPoi = mapByGeofenceForMobjectInGeofence.get(geofence.getId());

                    if (mobjectsInPoi != null) {
                        for (MobjectInPoiGeofence mobjectInGeofence : mobjectsInPoi) {

                            MobjectBigZoned mobz = mobjectList.stream().filter(o -> o.getMobjectBig().getId().equals(mobjectInGeofence.getMobjectId())).findFirst().orElse(null);

                            if (mobz != null) {
                                foundMobjectsInGeofence.add(mobz);
                                mobjectOutZoneList.remove(mobz);
                            }
                        }
                    }
                    geofenceMobjectListMap.put(geofence.getId(), foundMobjectsInGeofence);
                }
            }
        }

        return geofenceMobjectListMap;
    }

    public static class MonitoringObjectSelectionOption implements Serializable {
        public final static String KEY_MONITORING_OBJECTS_ALL = "allObjects";
        public final static String KEY_MONITORING_OBJECTS_GROUP = "groupedObjects";
        public final static String KEY_MONITORING_OBJECTS_ZONE = "zonedObjects";
        private final static String VALUE_MONITORING_OBJECTS_ALL = "all.object";
        private final static String VALUE_MONITORING_OBJECTS_GROUP = "objects.group";

        public static List<Option> list() {
            List<Option> optionList = new ArrayList<>();
            optionList.add(new Option(KEY_MONITORING_OBJECTS_ALL, VALUE_MONITORING_OBJECTS_ALL));
            optionList.add(new Option(KEY_MONITORING_OBJECTS_GROUP, VALUE_MONITORING_OBJECTS_GROUP));

            return optionList;
        }
    }

    public static class Option {
        private String key;
        private String value;

        public Option(String key, String value) {
            this.key = key;
            this.value = value;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }

    public List<MobjectTracks> getMobjectTracksList(HttpSession session) {
        List<MobjectTracks> mObjectTracksList = null;

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            mObjectTracksList = coreMain.getMobjectTracksListByUser(MainController.getInterfaceUserId(), 0L);
        } else {
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<MobjectTracks> tempMobjectTracksList;

                List<Contract> contracts = MainController.getUserContracts(session);

                for (Contract contract : contracts) {
                    tempMobjectTracksList = coreMain.getMobjectTracksListByContract(contract.getId(), 0L);

                    if (tempMobjectTracksList != null && tempMobjectTracksList.size() > 0) {
                        if (mObjectTracksList == null) mObjectTracksList = new ArrayList<>();
                        {
                            mObjectTracksList.addAll(tempMobjectTracksList);
                        }
                    }
                }
            } else {
                mObjectTracksList = coreMain.getMobjectTracksListByContract(MainController.getUserContractId(session), 0L);
            }
        }

        return mObjectTracksList;
    }

    public List<Poi> getPoiList(CorePoi corePoi, HttpSession session) {
        List<Poi> poiList = null;

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            List<Poi> tempPoiList;

            List<Contract> contracts = MainController.getUserContracts(session);

            for (Contract contract : contracts) {
                tempPoiList = corePoi.getListByContractId(contract.getId());

                if (tempPoiList != null && tempPoiList.size() > 0) {
                    if (poiList == null) poiList = new ArrayList<>();
                    {
                        poiList.addAll(tempPoiList);
                    }
                }
            }
        } else {
            poiList = corePoi.getListByContractId(MainController.getUserContractId(session));
        }

        return poiList;
    }

    public List<Geofence> getGeofenceList(CoreGeofence coreGeofence, HttpSession session) {
        List<Geofence> geofenceList = null;

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            List<Geofence> tempGeofenceList;
            List<Contract> contracts = MainController.getUserContracts(session);

            for (Contract contract : contracts) {
                tempGeofenceList = coreGeofence.getListByContractId(contract.getId());

                if (tempGeofenceList != null && tempGeofenceList.size() > 0) {
                    if (geofenceList == null) geofenceList = new ArrayList<>();
                    {
                        geofenceList.addAll(tempGeofenceList);
                    }
                }
            }
        } else {
            geofenceList = coreGeofence.getListByContractId(MainController.getUserContractId(session));
        }

        return geofenceList;
    }

    /**
     * return active mobjects from DB
     * And exclude suspended objects if needed
     *
     * @param session
     * @param checkSuspendedObjects
     * @return
     */
    public List<MobjectBig> getMobjects(HttpSession session, boolean checkSuspendedObjects) {
        if (!checkSuspendedObjects) {
            return getMobjectsFromCore(session);
        } else {
            List<MobjectBig> mObjectList;

            ContractSettings contractSettings = mainController.getContractSettings(session);

            boolean isShowSuspendedObjects = contractSettings.getIsShowSuspendedObjects();

            try {
                mObjectList = getMobjectsFromCore(session);
                if (isShowSuspendedObjects) {
                    return mObjectList;
                } else {
                    List<MobjectBig> mObjectListFiltered = new ArrayList<>(mObjectList);
                    mObjectListFiltered.removeIf(mObject -> mObject.getGpsUnitId() != null && mObject.getGpsUnitBig() != null && mObject.getGpsUnitBig().getBlock().equals(UZGPS_CONST.STATUS_BLOCK));
                    return mObjectListFiltered;
                }
            } catch (Exception e) {
                logger.error("Error in getMobjects", e);
            }
        }
        return Collections.emptyList();
    }

    public List<MobjectBig> getMobjectsFromCore(HttpSession session) {
        List<MobjectBig> mObjectList = null;

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            mObjectList = coreMain.getMobjectListByUser(MainController.getInterfaceUserId());
        } else {
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<MobjectBig> tempMobjectList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempMobjectList = coreMain.getMobjectListByContract(contract.getId());

                    if (tempMobjectList != null && !tempMobjectList.isEmpty()) {
                        if (mObjectList == null) mObjectList = new ArrayList<>();
                        {
                            mObjectList.addAll(tempMobjectList);
                        }
                    }
                }
            } else {
                mObjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session));
            }
        }

        return mObjectList;
    }

    public final class Icon {
        public static final String STATE_OBJECT = "state-span"; // Состояние объекта
        public static final String IGNITION_SENSOR = "icon-dashboard"; // Датчик зажигания
        public static final String CONNECTION_OBJECT = "icon-signal"; // Связь с объектом
        public static final String SATELLITE_VISIBILITY = "icon-rss"; // Видимость спутников
        public static final String STAFF = "icon-user"; // Персонал, назначенный на ПО
        public static final String STATE_SENSOR = "icon-off"; // Состояние датчиков
        public static final String MESSAGE_OBJECT = "icon-envelope"; // Сообщения объекта
        public static final String TRACK_OBJECT = "icon-road"; // Построить трек объекта
        public static final String VIEW_REPORT = "icon-list-alt"; // Вывести отчет
        public static final String SEND_SMS = "icon-comment"; // Послать команду через SMS
        public static final String EDIT_OBJECT = "icon-edit"; // Редактор свойств объекта
        public static final String BAK_STATUS = "icon-bak";
        public static final String EXTERNAL_POWER_VOLTAGE = "fa fa-calendar-plus-o"; //Индикатор внешнего питания
        public static final String LAST_MSG_TIME = "fa fa-clock-o"; //Индикатор внешнего питания
        public static final String OBJECT_BATTERY = "fa fa-battery-full border"; //Процент заряда батарейки устройства

    }

}
