package uzgps.map.models.notification;

import org.springframework.context.i18n.LocaleContextHolder;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreSensorNotification;
import uz.netex.dbtables.NotificationUnit;
import uz.netex.uzgps.core.models.sensor.SensorDataType;
import uz.netex.uzgps.core.models.sensor.Translator;
import uzgps.persistence.ContractSettings;

public class SensorNotification extends BaseNotification {
    private Integer value;
    private Integer valueLimit;
    private Boolean isOverValueLimit;
    private String sdtName;
    private String sdtUnit;

    public SensorNotification(NotificationUnit notificationUnit, CoreMain coreMain, ContractSettings contractSettings) {
        super(notificationUnit, coreMain, contractSettings);

        if (notificationUnit != null) {
            this.value = notificationUnit.getValueLong().intValue();
            this.valueLimit = notificationUnit.getValueInt();
            SensorDataType sensorDataType = CoreSensorNotification.getInstance()
                    .getById(notificationUnit.getSnId())
                    .getSensorDataType();
            if (sensorDataType != null) {
                this.sdtName = Translator.getSensorName(sensorDataType, LocaleContextHolder.getLocale());
                this.sdtUnit = sensorDataType.getUnit();
            }

            if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SENSOR_MIN) {
                this.isOverValueLimit = false;
            } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SENSOR_MAX) {
                this.isOverValueLimit = true;
            }
        }
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public Integer getValueLimit() {
        return valueLimit;
    }

    public void setValueLimit(Integer valueLimit) {
        this.valueLimit = valueLimit;
    }

    public Boolean getOverValueLimit() {
        return isOverValueLimit;
    }

    public void setOverValueLimit(Boolean overValueLimit) {
        isOverValueLimit = overValueLimit;
    }

    public String getSdtName() {
        return sdtName;
    }

    public void setSdtName(String sdtName) {
        this.sdtName = sdtName;
    }

    public String getSdtUnit() {
        return sdtUnit;
    }

    public void setSdtUnit(String sdtUnit) {
        this.sdtUnit = sdtUnit;
    }
}
