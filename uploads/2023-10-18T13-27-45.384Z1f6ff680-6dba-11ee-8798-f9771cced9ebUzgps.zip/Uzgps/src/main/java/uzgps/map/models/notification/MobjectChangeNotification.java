package uzgps.map.models.notification;

import uz.netex.core.CoreMain;
import uz.netex.dbtables.NotificationUnit;
import uzgps.persistence.ContractSettings;

/**
 * Created by Gayratjon on 9/27/14.
 */
public class MobjectChangeNotification extends BaseNotification {

    private String plateNumber;
    private String simNumber;
    private String carType;

    public MobjectChangeNotification(NotificationUnit notificationUnit, CoreMain coreMain,
                                     ContractSettings contractSettings) {
        super(notificationUnit, coreMain, contractSettings);

        if (notificationUnit != null) {

            // Staff connected to object time
            if (notificationUnit.getTpTime() != null)
                this.time = notificationUnit.getTpTime().getTime();

            // Staff name
            this.objectName = notificationUnit.getValueStr();

            // Plate number
            this.plateNumber = notificationUnit.getValueStr2();
            this.carType = notificationUnit.getValueStr3();
            this.simNumber = notificationUnit.getValueStr4();
        }
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    public void setPlateNumber(String plateNumber) {
        this.plateNumber = plateNumber;
    }

    public String getCarType() {
        return carType;
    }

    public void setCarType(String carType) {
        this.carType = carType;
    }

    public String getSimNumber() {
        return simNumber;
    }

    public void setSimNumber(String simNumber) {
        this.simNumber = simNumber;
    }
}
