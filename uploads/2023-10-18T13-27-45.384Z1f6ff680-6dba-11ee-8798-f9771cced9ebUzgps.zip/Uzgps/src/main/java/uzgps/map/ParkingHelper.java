package uzgps.map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.core.helper.CorePoi;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Poi;
import uz.netex.routing.database.tables.Trip;
import uz.netex.routing.database.tables.TripRoute;
import uz.netex.routing.service.TripRunnerService;
import uzgps.common.UZGPS_CONST;
import uzgps.map.kml.KMLExtraDataEvent;
import uzgps.map.models.TrackPopupData;
import uzgps.persistence.MObjectSettings;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

public class ParkingHelper {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public final static String SESSION_OBJECT_SETTINGS = "sessionMObjectSettings";
    TripRunnerService tripRunnerService;

    public List<TrackPopupData> getParkingPinsForTracking(HttpSession session,
                                                          MobjectBig mobjectBig,
                                                          long parkingTime,
                                                          TripRunnerService tripRunnerService,
                                                          List<GPSTrackPoint> trackPointList) {
        if (trackPointList == null || trackPointList.size() == 0) {
            return null;
        }


        if (tripRunnerService != null) {
            this.tripRunnerService = tripRunnerService;
        }

        Long mObjectId = mobjectBig.getId();

        List<TrackPopupData> parkingPins = new ArrayList<>();

        GPSTrackPoint trackPoint1;
        GPSTrackPoint trackPoint2 = trackPointList.get(trackPointList.size() - 1);

        boolean isInParking = false;
        TrackPopupData parkingPoint = null;

        // Collect mobject in Poi
        CorePoi corePoi = CorePoi.getInstance();
        // Collect mobject in Geofence
        CoreGeofence coreGeofence = CoreGeofence.getInstance();

        if (corePoi != null) {
            corePoi.loadMobjectsInPoi();
        }

        if (coreGeofence != null) {
            coreGeofence.loadMobjectsInGeofence();
        }

        for (int i = trackPointList.size() - 2; i >= 0; i--) {
            trackPoint1 = trackPoint2;
            trackPoint2 = trackPointList.get(i);

            if (trackPoint1.getSpeed() == 0) {
                if (trackPoint2.getSpeed() == 0) {
                    // Keep stopping...
                    if (parkingPoint == null) {
                        // Put parking flag
                        parkingPoint = makeParkingSosPoint(trackPoint1);
                    }
                } else {
                    // Check if parking happened
                    if (parkingPoint != null) {
                        if ((trackPoint2.getDate().getTime() - parkingPoint.getParkingFromDate().getTime() >= parkingTime)) {
                            // Add to parking list
                            isInParking = true;
                            parkingPins.add(parkingPoint);
                        }
                    }

                    if (isInParking) {
                        // Parking finished
                        parkingPoint.setParkingToDate(trackPoint2.getDate());
                        parkingPoint.setGPSTrackPoint(trackPoint1);

                        parkingPoint.setMobjectBig(mobjectBig);

                        List<Poi> poiList = null;
                        List<Geofence> geofenceList = null;

                        if (corePoi != null) {
                            poiList = corePoi.getPoiWithMobjectInside(mObjectId);
                        }

                        if (coreGeofence != null) {
                            geofenceList = coreGeofence.getGeofencesWithMobjectInside(mObjectId);
                        }

                        parkingPoint.setPoiAndGeoFenceList(poiList, geofenceList);
                        parkingPoint.setAssignedRoutes(getAssignedTripNamesToMobject(mObjectId));
                    }

                    // Switching from stop to move
                    isInParking = false;
                    parkingPoint = null;
                }
            } else {
                if (trackPoint2.getSpeed() == 0) {
                    // Switching from move to stop
                    if (parkingPoint == null) {
                        // Put parking flag
                        parkingPoint = makeParkingSosPoint(trackPoint2);
                    }
                } else {
                    // Keep moving
                    parkingPoint = null;
                }
            }
        }

        return parkingPins;
    }

    public List<KMLExtraDataEvent> getParkingEventsForKMLExtraData(MobjectBig mobjectBig,
                                                                   MObjectSettings mObjectSettings,
                                                                   List<GPSTrackPoint> trackPointList) {
        if (trackPointList == null || trackPointList.size() == 0) {
            return null;
        }

        Long mObjectId = mobjectBig.getId();

        // Get default min parking time from
        long minParkingTime = UZGPS_CONST.MIN_PARKING_TIME_DEFAULT;

        if (mObjectSettings != null && mObjectSettings.getParkingTime() != null) {
            minParkingTime = mObjectSettings.getParkingTime() * 1000;
        }

        List<KMLExtraDataEvent> parkingEventList = new ArrayList<>();

        GPSTrackPoint previousTrack;
        GPSTrackPoint currentTrack = trackPointList.get(trackPointList.size() - 1);

        boolean isInParking = false;
        KMLExtraDataEvent parkingEvent = null;

        for (int i = trackPointList.size() - 2; i >= 0; i--) {
            previousTrack = currentTrack;
            currentTrack = trackPointList.get(i);

            if (previousTrack.getSpeed() == 0) {
                if (currentTrack.getSpeed() == 0) {
                    // Keep stopping...
                    if (parkingEvent == null) {
                        // Put parking flag
                        parkingEvent = makeParkingEvent(previousTrack);
                    }
                } else {
                    // Check if parking happened
                    if (parkingEvent != null) {
                        if ((currentTrack.getDate().getTime() - parkingEvent.getFromDate() >= minParkingTime)) {
                            // Add to parking list
                            isInParking = true;
                            parkingEventList.add(parkingEvent);
                        }
                    }

                    if (isInParking) {
                        // Parking finished
                        parkingEvent.setToDate(currentTrack.getTimestamp());
                        parkingEvent.setGPSTrackPoint(previousTrack);
                        parkingEvent.setObjectId(mobjectBig.getId());
                        parkingEvent.setObjectName(mobjectBig.getName());
                    }

                    // Switching from stop to move
                    isInParking = false;
                    parkingEvent = null;
                }
            } else {
                if (currentTrack.getSpeed() == 0) {
                    // Switching from move to stop
                    if (parkingEvent == null) {
                        // Put parking flag
                        parkingEvent = makeParkingEvent(currentTrack);
                    }
                } else {
                    // Keep moving
                    parkingEvent = null;
                }
            }
        }

        setDurations(parkingEventList);

        return parkingEventList;
    }

    private TrackPopupData makeParkingSosPoint(GPSTrackPoint trackPoint) {
        if (trackPoint == null)
            return null;

        TrackPopupData parkingPoint = new TrackPopupData();
        parkingPoint.setLat(trackPoint.getLatitude());
        parkingPoint.setLon(trackPoint.getLongitude());
        parkingPoint.setTimestamp(trackPoint.getDate().getTime());
        parkingPoint.setTpRegDate(trackPoint.getRegDate().getTime());
        parkingPoint.setParkingFromDate(trackPoint.getDate());
        parkingPoint.setParkingToDate(null);

        return parkingPoint;
    }

    private KMLExtraDataEvent makeParkingEvent(GPSTrackPoint trackPoint) {
        if (trackPoint == null) {
            return null;
        }

        KMLExtraDataEvent parkingPoint = new KMLExtraDataEvent();
        parkingPoint.setType(1);
        parkingPoint.setLat(trackPoint.getLatitude());
        parkingPoint.setLon(trackPoint.getLongitude());
//        parkingPoint.setTimestamp(trackPoint.getTimestamp());
        parkingPoint.setTpRegDate(trackPoint.getRegDate().getTime());
        parkingPoint.setFromDate(trackPoint.getTimestamp());
        parkingPoint.setGPSTrackPoint(trackPoint);
        parkingPoint.setToDate(null);

        return parkingPoint;
    }

    public List<String> getAssignedTripNamesToMobject(Long mobjectId) {
        if (mobjectId == null) {
            return null;
        }

        try {
            if (tripRunnerService != null) {
                List<Trip> tripList = tripRunnerService.getByMobject(mobjectId);
                List<String> tripNames = new ArrayList<>();

                if (tripList != null && !tripList.isEmpty()) {
                    for (Trip trip : tripList) {
                        TripRoute tripRoute = trip.getTripRoute();
                        String tripName = tripRoute.getName();
                        tripNames.add(tripName);
                    }
                }
                return tripNames;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private void setDurations(List<KMLExtraDataEvent> parkingList) {
        try {
            // set parking durations
            if (parkingList != null) {
                for (KMLExtraDataEvent parking : parkingList) {
                    long durationSec = 0L;

                    durationSec = (parking.getToDate() - parking.getFromDate()) / 1000;

                    parking.setDurationSec(durationSec);
                }
            }
        } catch (Exception e) {
            logger.error("Error in setDurations", e);
        }
    }
}
