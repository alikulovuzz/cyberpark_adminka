package uzgps.map.kml;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by Gayratjon on 1/30/14.
 */

@XmlRootElement(name = "LineStyle")
public class KMLLineStyle {
    private String color;
    private Integer width;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        String r = color.substring(1, 3);
        String g = color.substring(3, 5);
        String b = color.substring(5, 7);
        String kmlColor = "ff" + b + g + r;
        this.color = kmlColor;
    }

    public Integer getWidth() {
        return width;
    }

    public void setWidth(Integer width) {
        this.width = width;
    }
}
