package uzgps.map.kml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by Gayratjon on 1/29/14.
 */

@XmlRootElement(name = "Placemark")
public class KMLPlacemark {
    private String name;
    private String styleUrl;
    private KMLTrack kmlTrack;

    public KMLPlacemark() {
        styleUrl = "";
        kmlTrack = new KMLTrack();
    }

    @XmlElement(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlElement(name = "styleUrl")
    public String getStyleUrl() {
        return styleUrl;
    }

    public void setStyleUrl(String styleUrl) {
        this.styleUrl = "#" + styleUrl;
    }

    @XmlElement(name = "gx:Track", namespace = "")
    public KMLTrack getKmlTrack() {
        return kmlTrack;
    }

    public void setKmlTrack(KMLTrack kmlTrack) {
        this.kmlTrack = kmlTrack;
    }
}
