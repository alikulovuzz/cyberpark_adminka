package uzgps.map.models;

import uzgps.route.json.response.ResponseBase;

/**
 * Created by Gayratjon on 11/25/2015.
 */
public class ResponseNearestPoint extends ResponseBase {
    private Long timestamp;
    private Long regDate;
    private Long parsingDate;

    private Byte movement;
    private Byte engineOn;
    private Byte online;
    private Byte satellites;
    private Byte dat;
    private Integer speed;
    private Integer odometer;
    private Byte gsmSignalLevel;

    public Byte getGsmSignalLevel() {
        return gsmSignalLevel;
    }

    public void setGsmSignalLevel(Byte gsmSignalLevel) {
        this.gsmSignalLevel = gsmSignalLevel;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }


    public Long getRegDate() {
        return regDate;
    }

    public void setRegDate(Long regDate) {
        this.regDate = regDate;
    }


    public Byte getMovement() {
        return movement;
    }

    public void setMovement(Byte movement) {
        this.movement = movement;
    }

    public Byte getEngineOn() {
        return engineOn;
    }

    public void setEngineOn(Byte engineOn) {
        this.engineOn = engineOn;
    }

    public Byte getOnline() {
        return online;
    }

    public void setOnline(Byte online) {
        this.online = online;
    }

    public Byte getSatellites() {
        return satellites;
    }

    public void setSatellites(Byte satellites) {
        this.satellites = satellites;
    }

    public Byte getDat() {
        return dat;
    }

    public void setDat(Byte dat) {
        this.dat = dat;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Long getParsingDate() {
        return parsingDate;
    }

    public void setParsingDate(Long parsingDate) {
        this.parsingDate = parsingDate;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }
}
