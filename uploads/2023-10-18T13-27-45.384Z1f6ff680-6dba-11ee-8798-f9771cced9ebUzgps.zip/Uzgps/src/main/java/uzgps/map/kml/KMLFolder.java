package uzgps.map.kml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 1/29/14.
 */

@XmlRootElement(name = "Folder")
public class KMLFolder {
    private List<KMLPlacemark> kmlPlacemarkList;

    public KMLFolder() {
        kmlPlacemarkList = new ArrayList<KMLPlacemark>();
    }

    @XmlElement(name = "Placemark")
    public List<KMLPlacemark> getKmlPlacemarkList() {
        return kmlPlacemarkList;
    }

    public void setKmlPlacemarkList(List<KMLPlacemark> kmlPlacemarkList) {
        this.kmlPlacemarkList = kmlPlacemarkList;
    }

    public boolean add(KMLPlacemark kmlPlacemark) {
        return kmlPlacemarkList.add(kmlPlacemark);
    }
}
