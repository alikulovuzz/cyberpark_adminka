package uzgps.map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminService;
import uzgps.map.kml.KMLObjectTrack;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.MObjectSettings;
import uzgps.persistence.User;
import uzgps.rest.smpov2.map.TrackingBase;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER;

/**
 * Created by Gayratjon on 1/27/14
 */

@Controller
public class TrackingController extends TrackingBase {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());


    @Autowired
    AdminService adminService;

    @Autowired
    InternalResourceViewResolver htmlViewResolver;


    private final static String URL_MAP_OBJECT_TRACKS_KML = "/map/tracking-object-tracks-kml.htm";
    private final static String URL_MAP_OBJECT_TRACKS_TABLE = TrackingBase.URL_MAP_OBJECT_TRACKS_TABLE;
    private final static String URL_MAP_TRACK_DATA_DOWNLOAD_XLS = "/map/track-data-download-xls.htm";
    private final static String URL_MAP_TRACK_DATA_DOWNLOAD_XLS_API = "/api/track-data-download-xls.json";
    private static final String URL_GET_TRACKS_COUNT_BY_PERIOD = "/map/tracks-count-by-period.htm";
    private final static String URL_MAP_OBJECT_FULL_TRACKS = "/map/object-full-tracks.htm";
    private final static String URL_MAP_PARKING_SOS_PINS = "/map/track-points-pins.htm";
    private final static String URL_MAP_NEAREST_TRACK_POINT = "/map/nearest-track-point.htm";
    private final static String URL_TRACK_COLORS = "/map/track-colors.htm";
    private final static String VIEW_URL_TRACK_COLORS = "map/ajax-track-colors";
    public final static String SESSION_OBJECT_SETTINGS = TrackingBase.SESSION_OBJECT_SETTINGS;

//    private final static int POINTS_PER_TRACK = 1000;

    public void processMapTrackingModel(ModelAndView modelAndView, HttpSession session) {
        List<MobjectBig> mObjectList;

        if (modelAndView.getModel().containsKey("mObjectList")) {
            mObjectList = (List<MobjectBig>) modelAndView.getModel().get("mObjectList");
        } else {
            mObjectList = monitoringController.getMobjects(session, false);
        }

        if (mObjectList != null && mObjectList.size() > 0) {
            // Sort list of objects
            Collections.sort(mObjectList);
            modelAndView.addObject("mObjectListTracking", mObjectList);
            processTrackColorsModel(session, modelAndView, mObjectList.get(0).getId());
        }

        ContractSettings contractSettings = mainController.getContractSettings(session);
        int deletePrevTrack = 1;
        int dottedLineThickness = 1;
        int linearLineThickness = 3;
        boolean isShowTrackingTable = false;
        boolean isShowTrackingChart = true;
        if (contractSettings != null) {
            deletePrevTrack = contractSettings.getDeletePrevTrack() ? 1 : 0;
            dottedLineThickness = contractSettings.getDottedLineThickness();
            linearLineThickness = contractSettings.getLinearLineThickness();
            isShowTrackingTable = contractSettings.getIsShowTrackingTable();
            isShowTrackingChart = contractSettings.getIsShowTrackingChart();
        }

        modelAndView.addObject("deletePrevTrack", deletePrevTrack);
        modelAndView.addObject("dottedLineThickness", dottedLineThickness);
        modelAndView.addObject("linearLineThickness", linearLineThickness);
        modelAndView.addObject("isShowTrackingTable", isShowTrackingTable);
        modelAndView.addObject("isShowTrackingChart", isShowTrackingChart);
    }

    @RequestMapping(value = URL_MAP_OBJECT_TRACKS_KML, method = RequestMethod.GET)
    @ResponseBody
    public KMLObjectTrack getMovableObjectTracksById(HttpSession session,
                                                     @RequestParam(value = "object-id", required = false) Long mObjectId,
                                                     @RequestParam(value = "start-date", required = false) String startDate,
                                                     @RequestParam(value = "end-date", required = false) String endDate,
                                                     @RequestParam(value = "point-count", required = false) Integer pointCount,
                                                     @RequestParam(value = "track-type-color", required = false) String trackTypeColor,
                                                     @RequestParam(value = "color", required = false) String color,
                                                     @RequestParam(value = "line-width", required = false, defaultValue = "1") Integer lineWidth,
                                                     @RequestParam(value = "track-view-type", defaultValue = "1") String trackViewTypeStr) {


        return getKmlObjectTrack(session, mObjectId, startDate, endDate, pointCount, trackTypeColor, color, lineWidth, trackViewTypeStr);
    }


    @RequestMapping(value = URL_MAP_OBJECT_TRACKS_TABLE, method = RequestMethod.GET)
    public ModelAndView loadDataForTracking(HttpSession session,
                                            @RequestParam(value = "object-id", required = false) Long mObjectId,
                                            @RequestParam(value = "start-date", required = false) String startDateStr,
                                            @RequestParam(value = "end-date", required = false) String endDateStr,
                                            @RequestParam(value = "point-count", required = false, defaultValue = "0") String limitStr,
                                            @RequestParam(value = "need-load-track-table", required = false, defaultValue = "false")
                                            String needLoadTracksTableStr,
                                            @RequestParam(value = "page-id", required = false, defaultValue = "0") String pageIdStr)
            throws IOException {

        return loadDataForTrackingService(session, mObjectId, startDateStr, endDateStr, limitStr, needLoadTracksTableStr, pageIdStr);
    }


    /**
     * Downloads the report in Excel format.
     * <p/>
     * Make sure this method doesn't return any model. Otherwise, you'll get
     * an "IllegalStateException: getOutputStream() has already been called for this response"
     */
    @RequestMapping(value = URL_MAP_TRACK_DATA_DOWNLOAD_XLS, method = RequestMethod.GET)
    public void getXLS(HttpServletResponse response, HttpServletRequest request,
                       HttpSession session,
                       @RequestParam(value = "object-id", required = false) Long mObjectId,
                       @RequestParam(value = "start-date", required = false) String startDate,
                       @RequestParam(value = "end-date", required = false) String endDate,
                       @RequestParam(value = "point-count", required = false) Integer pointCount) throws Exception {

        getXLSService(response, request, mObjectId, startDate, endDate, pointCount);
    }


    @RequestMapping(value = URL_MAP_TRACK_DATA_DOWNLOAD_XLS_API, method = RequestMethod.GET)
    public void getXLSByApi(HttpServletResponse response, HttpServletRequest request,
                            HttpSession session,
                            @RequestParam(value = "token", required = false, defaultValue = "none") String token,
                            @RequestParam(value = "object-id", required = false) Long mObjectId,
                            @RequestParam(value = "start-date", required = false) String startDate,
                            @RequestParam(value = "end-date", required = false) String endDate,
                            @RequestParam(value = "point-count", required = false) Integer pointCount) throws Exception {

        if (token == null || token.equals("none"))
            return;

        User user = settingsService.getUserByToken(token);
        MobjectBig mobject = coreMain.getMobjectById(mObjectId);
        if (user != null && user.getId() != null
                && mobject != null && mobject.getId() != null) {

            boolean hasAccess = true;

            // check if this user has access
            if (user.getRoleId() == USER_ROLE_USER) {
                List<MobjectBig> mobjectBigList = coreMain.getMobjectListByUser(user.getId());
                hasAccess = (mobjectBigList.contains(mobject));
            }

            if (hasAccess) {
                getXLS(response, request, session, mobject.getId(), startDate, endDate, pointCount);
            }
        }
    }


    @RequestMapping(value = URL_GET_TRACKS_COUNT_BY_PERIOD, method = RequestMethod.GET)
    public ModelAndView getTrackPointsCountByPeriod(@RequestParam(value = "object-id", required = false) Long mObjectId,
                                                    @RequestParam(value = "start-date", required = false) String startDate,
                                                    @RequestParam(value = "end-date", required = false) String endDate,
                                                    @RequestParam(value = "point-count", required = false) Integer pointCount) {

        return getTrackPointsCountByPeriodService(mObjectId, startDate, endDate);
    }


    @RequestMapping(value = URL_MAP_PARKING_SOS_PINS, method = RequestMethod.GET)
    public void getTrackPointsPins(HttpSession session,
                                   HttpServletResponse response,
                                   @RequestParam(value = "object-id", required = false) Long mObjectId,
                                   @RequestParam(value = "start-date", required = false) String startDate,
                                   @RequestParam(value = "end-date", required = false) String endDate,
                                   @RequestParam(value = "point-count", required = false) Integer pointsCount)
            throws IOException {

        getTrackPointsPinsService(session, response, mObjectId, startDate, endDate, pointsCount);
    }

    @RequestMapping(value = URL_MAP_NEAREST_TRACK_POINT, method = RequestMethod.GET)
    public void getNearestTrackPoint(HttpSession session,
                                     HttpServletResponse response,
                                     HttpServletRequest request,
                                     @RequestParam(value = "object-id", required = false) Long mObjectId,
                                     @RequestParam(value = "start-date", required = false) String startDateStr,
                                     @RequestParam(value = "end-date", required = false) String endDateStr,
                                     @RequestParam(value = "lat", required = false) Double latitude,
                                     @RequestParam(value = "lon", required = false) Double longitude,
                                     @RequestParam(value = "radius", required = false) Double radius)
            throws IOException {
        getNearestTrackPointService(session, response, mObjectId, startDateStr, endDateStr, latitude, longitude, radius);
    }


    @RequestMapping(value = URL_TRACK_COLORS, method = RequestMethod.GET)
    public ModelAndView processTrackColors(HttpSession session,
                                           @RequestParam(value = "object-id", required = false) Long mObjectId) {

        ModelAndView modelAndView = new ModelAndView(VIEW_URL_TRACK_COLORS);
        processTrackColorsModel(session, modelAndView, mObjectId);

        return modelAndView;
    }

    @RequestMapping(value = URL_MAP_OBJECT_FULL_TRACKS, method = RequestMethod.GET)
    @ResponseBody
    public KMLObjectTrack getMovableObjectReduces(@RequestParam(value = "object-id", required = false) Long mObjectId,
                                                  @RequestParam(value = "start-date", required = false) String startDate,
                                                  @RequestParam(value = "end-date", required = false) String endDate,
                                                  @RequestParam(value = "color", required = false) String color,
                                                  @RequestParam(value = "line-width", required = false, defaultValue = "3") Integer lineWidth,
                                                  @RequestParam(value = "epsilon", required = false) Integer epsilon,
                                                  @RequestParam(value = "track-view-type", defaultValue = "1") String trackViewTypeStr) {

        return getMovableObjectReducesService(mObjectId, startDate, endDate, color, lineWidth, epsilon);
    }


    private void processTrackColorsModel(HttpSession session, ModelAndView modelAndView, Long mObjectId) {
        if (logger.isDebugEnabled()) {
            logger.debug("Get the list of colors that belong to object-id={}", mObjectId);
        }

        if (mObjectId != null) {
            MObjectSettings mObjectSettings = (MObjectSettings) session.getAttribute(SESSION_OBJECT_SETTINGS + mObjectId);
            ColorPicker colorPicker = new ColorPicker();
            SpeedColor speedColor = new SpeedColor();

            if (mObjectSettings == null) {
                mObjectSettings = settingsService.getObjectSettingsByObjectId(mObjectId);

                if (mObjectSettings != null) {
                    colorPicker.setDefaultColor(mObjectSettings.getDefaultTrackColor());
                    speedColor.setSpeedColorList(mObjectSettings);
                    session.setAttribute(SESSION_OBJECT_SETTINGS + mObjectId, mObjectSettings);
                } else {
                    if (logger.isDebugEnabled()) {
                        logger.debug("mObjectSettings is not available in DB and set defaults...");
                    }
                    speedColor.setDefault();
                }
            } else {
                if (logger.isDebugEnabled()) {
                    logger.debug("Getting mObjectSettings from session...");
                }
                colorPicker.setDefaultColor(mObjectSettings.getDefaultTrackColor());
                speedColor.setSpeedColorList(mObjectSettings);
            }

            modelAndView.addObject("colorList", colorPicker.getColorList());
            modelAndView.addObject("speedColorList", speedColor.getSpeedColorList());
        }
    }


    public class ColorPicker {
        private List<String> colorList;

        public ColorPicker() {
            colorList = new ArrayList<>();
            colorList.add("#ffffff");
            colorList.add("#ff0000");
            colorList.add("#ff6600");
            colorList.add("#ffff00");
            colorList.add("#66ff00");
            colorList.add("#00ffff");
            colorList.add("#0000ff");
            colorList.add("#9900ff");
        }

        public List<String> getColorList() {
            return colorList;
        }

        public void setDefaultColor(String defaultColor) {
            colorList.remove(0);
            colorList.add(0, defaultColor);
        }
    }

    public static class SpeedColor {
        private List<SpeedColorItem> speedColorList;
        private int maxSpeedLimit = 100;

        public SpeedColor() {
            speedColorList = new ArrayList<>();
        }

        public void setDefault() {
            speedColorList.clear();
            speedColorList.add(new SpeedColorItem(0, 30, "#029508"));
            speedColorList.add(new SpeedColorItem(31, 50, "#456aa8"));
            speedColorList.add(new SpeedColorItem(51, 70, "#D72ec1"));
            speedColorList.add(new SpeedColorItem(71, 90, "#ff6600"));
            speedColorList.add(new SpeedColorItem(91, 100, "#C80A0A"));
            speedColorList.add(new SpeedColorItem(101, 1000, "#C80A0A"));
        }

        public List<SpeedColorItem> getSpeedColorList() {
            return speedColorList;
        }

        public void setSpeedColorList(MObjectSettings mObjectSettings) {
            maxSpeedLimit = mObjectSettings.getSpeedValue6().intValue();
            speedColorList.add(new SpeedColorItem(0, mObjectSettings.getSpeedValue1().intValue(), mObjectSettings.getSpeedColor1()));
            speedColorList.add(new SpeedColorItem(mObjectSettings.getSpeedValue1().intValue() + 1, mObjectSettings.getSpeedValue2().intValue(), mObjectSettings.getSpeedColor2()));
            speedColorList.add(new SpeedColorItem(mObjectSettings.getSpeedValue2().intValue() + 1, mObjectSettings.getSpeedValue3().intValue(), mObjectSettings.getSpeedColor3()));
            speedColorList.add(new SpeedColorItem(mObjectSettings.getSpeedValue3().intValue() + 1, mObjectSettings.getSpeedValue4().intValue(), mObjectSettings.getSpeedColor4()));
            speedColorList.add(new SpeedColorItem(mObjectSettings.getSpeedValue4().intValue() + 1, mObjectSettings.getSpeedValue5().intValue(), mObjectSettings.getSpeedColor5()));
            speedColorList.add(new SpeedColorItem(mObjectSettings.getSpeedValue5().intValue() + 1, 1000, mObjectSettings.getSpeedColor6()));
        }

        public SpeedColorItem getSpeedColorItemBySpeed(Integer speed) {
            for (SpeedColorItem speedColorItem : speedColorList) {
                if (speedColorItem.getMinSpeed() <= speed && speed <= speedColorItem.getMaxSpeed()) {
                    return speedColorItem;
                }
            }

            return null;
        }

        public class SpeedColorItem {
            private Integer minSpeed;
            private Integer maxSpeed;
            private String color;
            private String joinedSpeeds;

            private SpeedColorItem(Integer minSpeed, Integer maxSpeed, String color) {
                this.minSpeed = (minSpeed != null || minSpeed < 0) ? minSpeed : 0;
                this.maxSpeed = (maxSpeed != null) ? maxSpeed : 0;
                this.color = (color != null) ? color : "#000000";
                makeJoinedSpeedsString();
            }

            public Integer getMinSpeed() {
                return minSpeed;
            }

            public void setMinSpeed(Integer minSpeed) {
                this.minSpeed = minSpeed;
            }

            public Integer getMaxSpeed() {
                return maxSpeed;
            }

            public void setMaxSpeed(Integer maxSpeed) {
                this.maxSpeed = maxSpeed;
            }

            public String getColor() {
                return color;
            }

            public void setColor(String color) {
                this.color = color;
            }

            public String getJoinedSpeeds() {
                return joinedSpeeds;
            }

            public void setJoinedSpeeds(String joinedSpeeds) {
                this.joinedSpeeds = joinedSpeeds;
            }

            private void makeJoinedSpeedsString() {
                if (maxSpeed > maxSpeedLimit)
                    joinedSpeeds = minSpeed + " .. " + "~";
                else
                    joinedSpeeds = minSpeed + " .. " + maxSpeed;
            }

            public String getStyleIdForSpeedColorItem() {
                return "speed-color-" + minSpeed + "-" + maxSpeed;
            }
        }
    }

}
