package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonFilter;
import uzgps.persistence.POI;
import uzgps.persistence.PoiGroup;

/**
 * Created by Gayratjon on 4/25/14.
 */
@JsonFilter(value = "POIJSONFilter")
public class POIJSON {
    private Integer id;
    private String name;
    private Long groupId;
    private PoiGroup group;
    private String fontColor;
    private Integer fontSize;
    private String description;
    private Double longitude;
    private Double latitude;
    private Float radius;
    private Boolean isCircleDisplayed;
    private Boolean isNameDisplayed;
    private Boolean isLimitOver;
    private String circleColor;
    private Float circleOpacity;
    private String url;

    public POIJSON() {
    }

    public POIJSON(POI poi, boolean isNameDisplayed) {
        if (poi != null) {
            this.id = poi.getId().intValue();
            this.name = poi.getName();
            this.fontColor = poi.getFontColor();
            this.fontSize = poi.getFontSize();
            this.groupId = poi.getGroupId();
            this.group = poi.getGroup();
            this.description = poi.getDescription();
            this.longitude = poi.getLongitude();
            this.latitude = poi.getLatitude();
            this.radius = poi.getRadius();
            this.isCircleDisplayed = poi.getIsCircleDisplayed();
            this.isNameDisplayed = isNameDisplayed;
            this.circleColor = poi.getCircleColor();
            this.circleOpacity = poi.getCircleOpacity();
            this.url = poi.getUrl();
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getGroupId() { return groupId; }

    public void setGroupId(Long groupId) { this.groupId = groupId; }

    public PoiGroup getGroup() { return group; }

    public void setGroup(PoiGroup group) { this.group = group; }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public void setFontSize(Integer fontSize) {
        this.fontSize = fontSize;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Float getRadius() {
        return radius;
    }

    public void setRadius(Float radius) {
        this.radius = radius;
    }

    public Boolean getIsCircleDisplayed() {
        return isCircleDisplayed;
    }

    public void setIsCircleDisplayed(Boolean isCircleDisplayed) {
        this.isCircleDisplayed = isCircleDisplayed;
    }

    public Boolean getIsNameDisplayed() {
        return isNameDisplayed;
    }

    public void setIsNameDisplayed(Boolean isNameDisplayed) {
        this.isNameDisplayed = isNameDisplayed;
    }

    public String getCircleColor() {
        return circleColor;
    }

    public void setCircleColor(String circleColor) {
        this.circleColor = circleColor;
    }

    public Float getCircleOpacity() {
        return circleOpacity;
    }

    public void setCircleOpacity(Float circleOpacity) {
        this.circleOpacity = circleOpacity;
    }

    public Boolean getIsLimitOver() {
        return isLimitOver;
    }

    public void setIsLimitOver(Boolean isLimitOver) {
        this.isLimitOver = isLimitOver;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
