package uzgps.map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.geom.LineString;
import org.locationtech.jts.geom.Polygon;
import org.locationtech.jts.io.ParseException;
import org.locationtech.jts.io.WKTReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.dbtables.Geofence;
import uzgps.common.FileStorageService;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.map.models.GeoFenceJSON;
import uzgps.persistence.*;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.*;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

/**
 * Created by Gayratjon on 3/31/14.
 */


@Controller
public class GeoFenceController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_MAP_GEO_FENCE_IMPORT_DATA_POST = "/map/geo-fence-import-data-post.htm";
    private final static String URL_MAP_GEO_FENCE_POST = "/map/geo-fence-post.htm";
    private final static String URL_MAP_GEO_FENCE_POST_WITH_IMAGE = "/map/geo-fence-post-with-image.htm";
    private final static String URL_MAP_GEO_FENCE_REMOVE = "/map/geo-fence-remove.htm";
    private final static String URL_MAP_GEO_FENCE_LIST_JSON = "/map/geo-fence-list-json.htm";
    private final static String URL_MAP_GEO_FENCE_DUBLICATE = "/map/geo-fence-duplicate.htm";

    private final static String URL_MAP_GEO_FENCE_PANEL = "/map/geo-fence.htm";
    private final static String VIEW_MAP_GEO_FENCE_PANEL = "map/ajax-geofence-list";

    @Autowired
    GeoFenceService geoFenceService;

    @Autowired
    SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @Autowired
    private ObjectMapper jsonMapper;

    @Autowired
    FileStorageService storageService;

    public void processMapGeoFenceModel(ModelAndView modelAndView, HttpSession session) throws ServletException, IOException {
        List<GeoFence> geoFenceList = getGeoFenceList(session);
        List<ZoiGroup> groups = settingsService.getZoiGroupByContractId(MainController.getUserContractId(session));

        modelAndView.addObject("geoFenceList", geoFenceList);
        modelAndView.addObject("zoiGroups", groups);

        Map<Long, List<GeoFence>> groupedGeoFenceList = new HashMap<>();

        if (geoFenceList != null) {
            for (GeoFence geoFence : geoFenceList) {
                if (groupedGeoFenceList.containsKey(geoFence.getGroupId())) {
                    groupedGeoFenceList.get(geoFence.getGroupId()).add(geoFence);
                } else {
                    List<GeoFence> geoFences = new ArrayList<>();
                    geoFences.add(geoFence);
                    groupedGeoFenceList.put(geoFence.getGroupId(), geoFences);
                }
            }
        }

        modelAndView.addObject("groupedGeoFenceList", groupedGeoFenceList);
    }

    @RequestMapping(value = URL_MAP_GEO_FENCE_LIST_JSON, method = RequestMethod.GET, produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getGeoFenceListByContractId(HttpSession session) throws ServletException, IOException {
        List<GeoFence> geoFenceList = getGeoFenceList(session);

        List<GeoFenceJSON> geoFenceJSONList = new ArrayList<>();
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        boolean isNameDisplayed = true;
        if (contractSettings != null)
            isNameDisplayed = contractSettings.getShowNameGeoZone();

        if (geoFenceList != null)
            for (GeoFence geoFence : geoFenceList) {
                GeoFenceJSON geoFenceJSON = new GeoFenceJSON(geoFence, isNameDisplayed);
                geoFenceJSONList.add(geoFenceJSON);
            }

        Set<String> ignorableFields = new HashSet<>();
        ignorableFields.add("isLimitOver");
        SimpleFilterProvider filterProvider = new SimpleFilterProvider();
        filterProvider.addFilter("GeoFenceJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));
        ObjectWriter writer = jsonMapper.writer(filterProvider);

        return writer.writeValueAsString(geoFenceJSONList);
    }

    /**
     * Save imported geometries to DB
     */
    @RequestMapping(value = URL_MAP_GEO_FENCE_IMPORT_DATA_POST, method = RequestMethod.POST)
    public void postGeoFenceImportData(HttpSession session, HttpServletResponse response,
                                       @RequestBody List<GeofencesModel> geofenceModelList) throws IOException {

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        if (contractSettings != null) {
            GeoFenceJSON geoFenceJSON;
            List<GeoFenceJSON> geoFenceJSONList = new ArrayList<>();
            Set<String> ignorableFields = new HashSet<>();

            Long geoFenceCount = getGeoFenceCount(session);
            Long geoFenceLimit = contractSettings.getContract().getActiveMaxGeoFanceCount();
            Boolean showGeoZoneName = contractSettings.getShowNameGeoZone();

            if (geofenceModelList != null) {
                for (GeofencesModel geofencesModel : geofenceModelList) {

                    geoFenceJSON = addNewGeofence(ignorableFields, MainController.getUserContractId(session),
                            geofencesModel.getGroupId(), showGeoZoneName, geoFenceCount, geoFenceLimit,
                            geofencesModel.getName(), geofencesModel.getFontSize(), geofencesModel.getFontColor(),
                            null, null, geofencesModel.getDescription(),
                            geofencesModel.getGeometryColor(), geofencesModel.getGeometryOpacity(),
                            geofencesModel.getRadius(), geofencesModel.getGeometryWKT());

                    geoFenceJSONList.add(geoFenceJSON);
                }
            }
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("GeoFenceJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            try {
                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("geofence");
                byte[] data;
//                data = writer.writeValueAsBytes(geoFenceJSON);
                data = writer.writeValueAsBytes(geoFenceJSONList);
                response.setContentType("application/json");
                response.setContentLength(data.length);
                ServletOutputStream outStream;
                outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
            } catch (IOException e) {
                logger.error("Error: ", e);
            }
        }
    }

    @RequestMapping(value = URL_MAP_GEO_FENCE_POST_WITH_IMAGE, method = RequestMethod.POST)
    public void postGeoFenceWithImage(HttpSession session, HttpServletResponse response,
                                      @RequestParam(value = "files", required = false) List<MultipartFile> files,
                                      @RequestParam(value = "image", required = false) MultipartFile image,
                                      @RequestParam(value = "geoFenceId", required = false) Long geoFenceId,
                                      @RequestParam(value = "groupId", required = false) Long groupId,
                                      @RequestParam(value = "name", required = false) String name,
                                      @RequestParam(value = "fontColor", required = false) String fontColor,
                                      @RequestParam(value = "fontSize", required = false) Integer fontSize,
                                      @RequestParam(value = "description", required = false) String description,
                                      @RequestParam(value = "geometryColor", required = false) String geometryColor,
                                      @RequestParam(value = "radius", required = false) Float radius,
                                      @RequestParam(value = "geometryOpacity", required = false, defaultValue = "0.5") Double geometryOpacity,
                                      @RequestParam(value = "geometry", required = false) String wkt
    ) throws ServletException, IOException {

        MultipartFile file = null;

        if (files.size() > 0) {
            file = files.get(0);
            if (files.size() > 1) {
                image = files.get(1);
            }
        }

        this.localPostGeoFence(session, response, geoFenceId, groupId, name, image, file, fontColor, fontSize, description, geometryColor, radius, geometryOpacity, wkt, false, false);
    }

    @RequestMapping(value = URL_MAP_GEO_FENCE_POST, method = RequestMethod.POST)
    public void postGeoFence(HttpSession session, HttpServletResponse response,
                             @RequestParam(value = "isImageDelete", required = false, defaultValue = "false") boolean isImageDelete,
                             @RequestParam(value = "isFileDelete", required = false, defaultValue = "false") boolean isFileDelete,
                             @RequestParam(value = "geoFenceId", required = false) Long geoFenceId,
                             @RequestParam(value = "groupId", required = false) Long groupId,
                             @RequestParam(value = "name", required = false) String name,
                             @RequestParam(value = "fontColor", required = false) String fontColor,
                             @RequestParam(value = "fontSize", required = false) Integer fontSize,
                             @RequestParam(value = "description", required = false) String description,
                             @RequestParam(value = "geometryColor", required = false) String geometryColor,
                             @RequestParam(value = "radius", required = false) Float radius,
                             @RequestParam(value = "geometryOpacity", required = false, defaultValue = "0.5") Double geometryOpacity,
                             @RequestParam(value = "geometry", required = false) String wkt
    ) throws ServletException, IOException {
        this.localPostGeoFence(session, response, geoFenceId, groupId, name, null, null, fontColor, fontSize, description, geometryColor, radius, geometryOpacity, wkt, isImageDelete, isFileDelete);
    }


    private void localPostGeoFence(HttpSession session, HttpServletResponse response, Long geoFenceId, Long groupId, String name, MultipartFile image,
                                   MultipartFile file, String fontColor, Integer fontSize, String description, String geometryColor,
                                   Float radius, Double geometryOpacity, String wkt, boolean isImageDelete, boolean isFileDelete) {
        if (logger.isDebugEnabled()) {
            logger.debug("Post geo-fence: geoFenceId={}, groupId={}, name={}, fontName={}, fontSize={}, geometryColor={}, radius={}, geometry={}",
                    geoFenceId, groupId, name, fontColor, fontSize, geometryColor, radius, wkt);
        }

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        if (contractSettings != null) {

            GeoFenceJSON geoFenceJSON = null;
            Set<String> ignorableFields = new HashSet<>();

            if (geoFenceId == null) {
                Long geoFenceCount = getGeoFenceCount(session);
                Long geoFenceLimit = contractSettings.getContract().getActiveMaxGeoFanceCount();
                Boolean showGeoZoneName = contractSettings.getShowNameGeoZone();

                geoFenceJSON = addNewGeofence(ignorableFields, MainController.getUserContractId(session),
                        groupId, showGeoZoneName, geoFenceCount, geoFenceLimit, name, fontSize,
                        fontColor, file, image, description, geometryColor, geometryOpacity, radius, wkt);
            } else {
                if (wkt != null) {
                    WKTReader wktReader = new WKTReader();
                    Geometry geometry = null;

                    try {
                        geometry = wktReader.read(wkt);
                    } catch (ParseException e) {
                        logger.error("error wktReader.read(wkt)" + e.getMessage());
                    }

                    tryAnotherWktReader(wkt, geometry);

                    if (geometry != null && geometry.isValid()) {
                        double EARTH_RADIUS = 6371000;
                        Geometry tmpGeometry = (Geometry) geometry.clone();
                        for (int i = 0; i < tmpGeometry.getCoordinates().length; i++) {
                            double longitude = tmpGeometry.getCoordinates()[i].x;
                            double latitude = tmpGeometry.getCoordinates()[i].y;
                            tmpGeometry.getCoordinates()[i].x = longitude * EARTH_RADIUS * Math.PI / 180.;
                            tmpGeometry.getCoordinates()[i].y = EARTH_RADIUS * Math.sin(Math.toRadians(latitude));
                        }

                        double area = 0;
                        double perimeter = 0;

                        if (geometry.getGeometryType().equalsIgnoreCase("point")) {
                            area = Math.PI * Math.pow(radius, 2);
                            perimeter = 2 * Math.PI * radius;
                        } else if (geometry.getGeometryType().equalsIgnoreCase("linestring")) {
                            perimeter = getPerimeter((LineString) geometry);
                        } else if (geometry.getGeometryType().equalsIgnoreCase("polygon")) {
                            area = getArea((Polygon) tmpGeometry);
                            perimeter = getPerimeter((Polygon) geometry);
                        }

                        GeoFence geoFence = geoFenceService.getGeoFenceById(geoFenceId);
                        geoFence.setModDate(new Timestamp(System.currentTimeMillis()));
                        geoFence.setName(name);
                        geoFence.setFontSize(fontSize);
                        geoFence.setFontColor(fontColor);
                        geoFence.setType(geometry.getGeometryType());
                        geoFence.setColor(geometryColor);
                        geoFence.setGroupId(groupId);
                        geoFence.setGroup(settingsService.getZoiGroupById(groupId));

                        if (isImageDelete) {
                            geoFence.setImage(null);
                            geoFence.setImageId(null);
                        }

                        if (isFileDelete) {
                            geoFence.setFile(null);
                            geoFence.setFileId(null);
                        }

                        if (file != null && file.getSize() > 0) {
                            FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                            geoFence.setFile(fileStorage);
                            geoFence.setFileId(fileStorage.getId());
                        }
                        if (image != null && image.getSize() > 0) {
                            FileStorage imageStorage = storageService.saveMultipartFileToStorage(image);
                            geoFence.setImage(imageStorage);
                            geoFence.setImageId(imageStorage.getId());
                        }
                        geoFence.setDescription(description);

                        if (radius != null) {
                            geoFence.setRadius(radius);
                        }

                        if (geometryOpacity != null) {
                            geoFence.setGeometryOpacity(geometryOpacity);
                        }

                        geoFence.setArea(area);
                        geoFence.setPerimeter(perimeter);

                        geoFence.setWktString(wkt);
                        geoFenceService.saveGeoFence(geoFence);
                        geoFenceService.removeGeoFencePointListByGeoFenceId(geoFenceId, session);

                        addUserZoiAccess(geoFence);

                        Coordinate[] coordinates = geometry.getCoordinates();
                        List<GeoFencePoint> geoFencePointList = new ArrayList<>();

                        for (Coordinate coordinate : coordinates) {
                            GeoFencePoint geoFencePoint = new GeoFencePoint();
                            geoFencePoint.setLongitude(coordinate.x);
                            geoFencePoint.setLatitude(coordinate.y);
                            geoFencePoint.setGeoFence(geoFence);
                            geoFencePointList.add(geoFencePoint);
                            geoFenceService.saveGeoFencePoint(geoFencePoint);
                        }

                        geoFence.setGeoFencePointList(geoFencePointList);
                        boolean isNameDisplayed = contractSettings.getShowNameGeoZone();
                        geoFenceJSON = new GeoFenceJSON(geoFence, isNameDisplayed);
                        geoFenceJSON.setIsLimitOver(false);

                        // Update core for GeoFence by Mobject
                        coreMain.coreUpdater.updateGeofenceById(geoFenceId);
                    }
                }
            }

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("GeoFenceJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            try {
                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("geofence");
                byte[] data;
                data = writer.writeValueAsBytes(geoFenceJSON);
                response.setContentType("application/json");
                response.setContentLength(data.length);
                ServletOutputStream outStream;
                outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
            } catch (IOException e) {
                logger.error("Error: ", e);
            }
        }
    }

    private void tryAnotherWktReader(String wkt, Geometry geometry) {
        if (geometry == null || !geometry.isValid()) {
            try {
                WKTReader wktReaderCandidate = new WKTReader();
                Geometry geometryCandidate = null;

                geometryCandidate = wktReaderCandidate.read(wkt);

                if (geometryCandidate != null && geometryCandidate.isValid()) {
                    logger.error("try new wkt reader test OK");
                } else {
                    logger.error("try new wkt reader test FAILED");
                }
            } catch (ParseException e) {
                logger.error("error locationtech wktReader.read(wkt)");
            }
        }
    }


    @RequestMapping(value = URL_MAP_GEO_FENCE_REMOVE, method = RequestMethod.POST)
    public void removeGeoFence(HttpSession session, HttpServletResponse response,
                               @RequestParam(value = "geoFenceId", required = false) Long geoFenceId)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("removeGeoFence: geo-fence-id={}", geoFenceId);
        }

        ResponseEntity responseEntity;

        if (geoFenceId != null) {
            GeoFence geoFence = geoFenceService.getGeoFenceById(geoFenceId);
            geoFence.setStatus(UZGPS_CONST.STATUS_DELETE);
            geoFence.setExpDate(new Timestamp(System.currentTimeMillis()));

            geoFenceService.saveGeoFence(geoFence);

            List<MObjectGeoFence> mObjectGeoFenceList = settingsService.getMObjectGeoFenceListByGeoFenceId(geoFenceId);
            if (mObjectGeoFenceList != null) {
                for (MObjectGeoFence mObjectGeoFence : mObjectGeoFenceList) {
                    if (mObjectGeoFence != null) {
                        mObjectGeoFence.setStatus(UZGPS_CONST.STATUS_DELETE);
                        mObjectGeoFence.setExpDate(new Timestamp(System.currentTimeMillis()));
                        settingsService.saveMObjectGeoFence(mObjectGeoFence);
                    }
                }
            }

            // Update core for GeoFence by Mobject
            coreMain.coreUpdater.updateGeofenceById(geoFenceId);
            coreMain.coreUpdater.updateUserZoiAccessByZoiId(geoFenceId);

            responseEntity = new ResponseEntity(HttpStatus.OK);
        } else {
            responseEntity = new ResponseEntity(HttpStatus.FAILED_DEPENDENCY);
        }

        ObjectWriter writer = jsonMapper.writer();
        byte[] data;
        data = writer.writeValueAsBytes(responseEntity);
        response.setContentType("application/json");
        response.setContentLength(data.length);
        ServletOutputStream outStream;
        outStream = response.getOutputStream();
        outStream.write(data);
        outStream.close();
    }

    @RequestMapping(value = URL_MAP_GEO_FENCE_PANEL)
    public ModelAndView processMapGeofencePanel(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String
                                                          appStatus,
                                                  HttpSession session) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_MAP_GEO_FENCE_PANEL);
        processMapGeoFenceModel(modelAndView, session);

        return modelAndView;
    }

    private double distance(Coordinate coordinate1, Coordinate coordinate2) {
        return distance(coordinate1.y, coordinate1.x, coordinate2.y, coordinate2.x);
    }

    private double distance(double userLat, double userLng, double venueLat, double venueLng) {
        double latDistance = Math.toRadians(userLat - venueLat);
        double lngDistance = Math.toRadians(userLng - venueLng);

        double a = (Math.sin(latDistance / 2) * Math.sin(latDistance / 2)) +
                (Math.cos(Math.toRadians(userLat))) *
                        (Math.cos(Math.toRadians(venueLat))) *
                        (Math.sin(lngDistance / 2)) *
                        (Math.sin(lngDistance / 2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return 6371000 * c;
    }

//    private double getPerimeter(Coordinate[] coordinates) {
//        double perimeter = 0;
//        if (coordinates.length > 0) {
//            Coordinate coordinate1 = coordinates[0];
//            for (int i = 1; i < coordinates.length; i++) {
//                Coordinate coordinate2 = coordinates[i];
//                perimeter += distance(coordinate1, coordinate2);
//                coordinate1 = coordinate2;
//            }
//        }
//
//        return perimeter;
//    }


    /**
     * Returns the area of a Polygon.
     *
     * @param polygon the Polygon for which the area is calculated.
     * @return The area of the polygon.
     */
    protected double getArea(Polygon polygon) {
        double area = 0.0d;
        double interiorArea = 0.0d;
        Coordinate[] exteriorRingCoordinates = polygon.getExteriorRing().getCoordinates();
        int numberOfExteriorRingCoordinates = exteriorRingCoordinates.length;
        // Calculate the boundingBox of polygon1 aligned with the axes x and y
        double minx = Double.POSITIVE_INFINITY;
        double maxx = Double.NEGATIVE_INFINITY;
        double miny = Double.POSITIVE_INFINITY;
        double maxy = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < numberOfExteriorRingCoordinates; i++) {
            minx = Math.min(minx, exteriorRingCoordinates[i].x);
            maxx = Math.max(maxx, exteriorRingCoordinates[i].x);
            miny = Math.min(miny, exteriorRingCoordinates[i].y);
            maxy = Math.max(maxy, exteriorRingCoordinates[i].y);
        }
        // Calculate area of each trapezoid formed by dropping lines from
        // each pair of coordinates in exteriorRingCoordinates to the x-axis.
        // x[i]<x[i-1] will contribute a negative area
        for (int i = 0; i < (numberOfExteriorRingCoordinates - 1); i++) {
            area += (((exteriorRingCoordinates[i + 1].x - minx) -
                    (exteriorRingCoordinates[i].x - minx)) *
                    (((exteriorRingCoordinates[i + 1].y - miny) +
                            (exteriorRingCoordinates[i].y - miny)) / 2d));
        }
        area = Math.abs(area);
        // Calculate area of each trapezoid formed by dropping lines
        // from each pair of coordinates in interiorRingCoorinates to the x-axis.
        int numberOfInteriorRings = polygon.getNumInteriorRing();
        int numberOfInteriorRingCoordinates;
        Coordinate[] interiorRingCoordinates;
        for (int i = 0; i < numberOfInteriorRings; i++) {
            interiorArea = 0.0d;
            interiorRingCoordinates = polygon.getInteriorRingN(i).getCoordinates();
            numberOfInteriorRingCoordinates = interiorRingCoordinates.length;
            minx = Double.POSITIVE_INFINITY;
            maxx = Double.NEGATIVE_INFINITY;
            miny = Double.POSITIVE_INFINITY;
            maxy = Double.NEGATIVE_INFINITY;
            for (int j = 0; j < numberOfInteriorRingCoordinates; j++) {
                minx = Math.min(minx, interiorRingCoordinates[j].x);
                maxx = Math.max(maxx, interiorRingCoordinates[j].x);
                miny = Math.min(miny, interiorRingCoordinates[j].y);
                maxy = Math.max(maxy, interiorRingCoordinates[j].y);
            }
            for (int j = 0; j < (numberOfInteriorRingCoordinates - 1); j++) {
                interiorArea += (((interiorRingCoordinates[j + 1].x - minx) -
                        (interiorRingCoordinates[j].x - minx)) *
                        (((interiorRingCoordinates[j + 1].y - miny) +
                                (interiorRingCoordinates[j].y - miny)) / 2d));
            }
            area -= Math.abs(interiorArea);
        }
        return area;
    }

    /**
     * Returns the perimeter of a LineString.
     *
     * @param lineString the LineString for which the perimeter is calculated.
     * @return the perimeter (length) of the lineString.
     */
    protected double getPerimeter(LineString lineString) {
        double perimeter = 0.0d;
        int numberOfPoints = lineString.getNumPoints();
        Coordinate[] coordinates = lineString.getCoordinates();
        for (int i = 0; i < (numberOfPoints - 1); i++) {
            perimeter += distance(coordinates[i], coordinates[i + 1]);
//            perimeter += coordinates[i].distance(coordinates[i + 1]);
        }
        return perimeter;
    }

    /**
     * Returns the perimeter of a Polygon.
     *
     * @param polygon the Polygon for which the perimeter is calculated.
     * @return The perimeter of the polygon.
     */
    protected double getPerimeter(Polygon polygon) {
        double perimeter = 0.0d;
        LineString lineString = polygon.getExteriorRing();
        perimeter += getPerimeter(lineString);
        int numberOfHoles = polygon.getNumInteriorRing();
        for (int i = 0; i < numberOfHoles; i++) {
            perimeter += getPerimeter(polygon.getInteriorRingN(i));
        }
        return perimeter;
    }

    @RequestMapping(value = URL_MAP_GEO_FENCE_DUBLICATE, method = RequestMethod.POST)
    public void geoFenceDuplicate(HttpSession session, HttpServletResponse response,
                                  @RequestParam(value = "gf-id", required = false) Long geoFenceId,
                                  @RequestParam(value = "geometry") String wkt) throws ServletException, IOException {

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        GeoFenceJSON geoFenceJSON = null;
        Set<String> ignorableFields = new HashSet<>();

        if (contractSettings != null) {
            if (geoFenceId != null) {

                Long geoFenceCount = getGeoFenceCount(session);

                Long geoFenceLimit = contractSettings.getContract().getActiveMaxGeoFanceCount();

                if (geoFenceCount + 1 <= geoFenceLimit) {
                    GeoFence geoFence = geoFenceService.getGeoFenceById(geoFenceId);

                    Long geoFenceNameCount = getGeoFencesCountByName(geoFence.getName(), session);

                    if (wkt != null) {
                        WKTReader wktReader = new WKTReader();
                        Geometry geometry = null;
                        try {
                            geometry = wktReader.read(wkt);
                        } catch (ParseException e) {
                            logger.error("error wktReader.read(wkt)", e);
                        }

                        tryAnotherWktReader(wkt, geometry);

                        if (geometry != null && geometry.isValid()) {
                            double EARTH_RADIUS = 6371000;
                            Geometry tmpGeometry = (Geometry) geometry.clone();
                            for (int i = 0; i < tmpGeometry.getCoordinates().length; i++) {
                                double longitude = tmpGeometry.getCoordinates()[i].x;
                                double latitude = tmpGeometry.getCoordinates()[i].y;
                                tmpGeometry.getCoordinates()[i].x = longitude * EARTH_RADIUS * Math.PI / 180.;
                                tmpGeometry.getCoordinates()[i].y = EARTH_RADIUS * Math.sin(Math.toRadians(latitude));
                            }


                            GeoFence geoFenceD = new GeoFence();

                            geoFenceD.setContractId(MainController.getUserContractId(session));
                            geoFenceD.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                            geoFenceD.setRegDate(new Timestamp(System.currentTimeMillis()));
                            geoFenceD.setName(geoFence.getName() + "(" + geoFenceNameCount + ")");
                            geoFenceD.setFontSize(geoFence.getFontSize());
                            geoFenceD.setFontColor(geoFence.getFontColor());

                            geoFenceD.setType(geoFence.getType());
                            geoFenceD.setColor(geoFence.getColor());
                            geoFenceD.setRadius(geoFence.getRadius());
                            geoFenceD.setArea(geoFence.getArea());
                            geoFenceD.setPerimeter(geoFence.getPerimeter());
                            geoFenceD.setGeometryOpacity(geoFence.getGeometryOpacity());

                            geoFenceD.setImageId(geoFence.getImageId());
                            geoFenceD.setImage(geoFence.getImage());
                            geoFenceD.setDescription(geoFence.getDescription());

                            geoFenceService.saveGeoFence(geoFenceD);

                            addUserZoiAccess(geoFence);

                            Coordinate[] coordinates = geometry.getCoordinates();
                            List<GeoFencePoint> geoFencePointList = new ArrayList<>();

                            for (Coordinate coordinate : coordinates) {
                                GeoFencePoint geoFencePoint = new GeoFencePoint();
                                geoFencePoint.setLongitude(coordinate.x);
                                geoFencePoint.setLatitude(coordinate.y);
                                geoFencePoint.setGeoFence(geoFenceD);
                                geoFencePointList.add(geoFencePoint);
                                geoFenceService.saveGeoFencePoint(geoFencePoint);
                            }

                            geoFenceD.setGeoFencePointList(geoFencePointList);
                            boolean isNameDisplayed = contractSettings.getShowNameGeoZone();
                            geoFenceJSON = new GeoFenceJSON(geoFenceD, isNameDisplayed);
                            geoFenceJSON.setIsLimitOver(false);

                            // Update core for GeoFence by Mobject
                            coreMain.coreUpdater.updateGeofenceById(geoFenceId);

                        }
                    }
                }
            }

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("GeoFenceJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            try {
                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("geofence");
                byte[] data;
                data = writer.writeValueAsBytes(geoFenceJSON);
                response.setContentType("application/json");
                response.setContentLength(data.length);
                ServletOutputStream outStream;
                outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
            } catch (IOException e) {
                logger.error("Error: ", e);
            }

        }
    }

    private List<GeoFence> getGeoFenceList(HttpSession session) {
        List<GeoFence> geoFenceList = null;

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            List<Geofence> poiListFromCore = coreMain.getZoiListByUser(MainController.getInterfaceUserId());

            geoFenceList = convertZoiToGeofenceType(poiListFromCore);
        } else {
            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                List<GeoFence> tempGeoFenceList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempGeoFenceList = geoFenceService.getGeoFenceListByContractIdAndStatus(contract.getId(), UZGPS_CONST.STATUS_ACTIVE);

                    if (tempGeoFenceList != null && tempGeoFenceList.size() > 0) {
                        if (geoFenceList == null) geoFenceList = new ArrayList<>();
                        {
                            geoFenceList.addAll(tempGeoFenceList);
                        }
                    }
                }
            } else {
                geoFenceList = geoFenceService.getGeoFenceListByContractIdAndStatus(
                        MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE);
            }
        }
        return geoFenceList;
    }

    private Long getGeoFenceCount(HttpSession session) {
        Long geoFenceCount = 0L;
        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            Long tempGeoFenceCount;

            List<Contract> contracts = MainController.getUserContracts(session);
            for (Contract contract : contracts) {
                tempGeoFenceCount = geoFenceService.getGeoFenceCountByContractIdAndStatus(contract.getId(), UZGPS_CONST
                        .STATUS_ACTIVE);

                if (tempGeoFenceCount != null && tempGeoFenceCount > 0) {
                    if (geoFenceCount == null) geoFenceCount = 0L;
                    {
                        geoFenceCount += tempGeoFenceCount;
                    }
                }
            }
        } else {
            geoFenceCount = geoFenceService.getGeoFenceCountByContractIdAndStatus(MainController.getUserContractId(session), UZGPS_CONST
                    .STATUS_ACTIVE);
        }

        return geoFenceCount;
    }

    private Long getGeoFencesCountByName(String geoFenceName, HttpSession session) {
        Long geoFencesCount = null;
        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            Long tempGeoFencesCount;

            List<Contract> contracts = MainController.getUserContracts(session);
            for (Contract contract : contracts) {
                tempGeoFencesCount = geoFenceService.getGeoFenceNameCountByContractId(contract.getId(), UZGPS_CONST.STATUS_ACTIVE,
                        geoFenceName);

                if (tempGeoFencesCount != null && tempGeoFencesCount > 0) {
                    if (geoFencesCount == null) geoFencesCount = 0L;
                    {
                        geoFencesCount += tempGeoFencesCount;
                    }
                }
            }
        } else {
            geoFencesCount = geoFenceService.getGeoFenceNameCountByContractId(MainController.getUserContractId(session), UZGPS_CONST
                    .STATUS_ACTIVE, geoFenceName);
        }

        return geoFencesCount;
    }

    private GeoFenceJSON addNewGeofence(Set<String> ignorableFields,
                                        Long contractId,
                                        Long groupId,
                                        Boolean showGeoZoneName,
                                        Long geoFenceCount,
                                        Long geoFenceLimit,
                                        String name,
                                        Integer fontSize,
                                        String fontColor,
                                        MultipartFile file,
                                        MultipartFile image,
                                        String description,
                                        String geometryColor,
                                        Double geometryOpacity,
                                        Float radius,
                                        String wkt) {

        GeoFenceJSON geoFenceJSON = null;

        try {
            if (geoFenceCount + 1 <= geoFenceLimit) {
                if (wkt != null) {
                    WKTReader wktReader = new WKTReader();
                    Geometry geometry = null;

                    try {
                        geometry = wktReader.read(wkt);
                    } catch (ParseException e) {
                        logger.error("error wktReader.read(wkt)" + e.getMessage());
                    }

                    // Change PolygonZ geom to Polygon
                    if (geometry == null || !geometry.isValid()) {
                        try {
                            wkt = wkt.replace(" Z(", "(");
                            wkt = wkt.replace(" 0,", ",");
                            wkt = wkt.replace(" 0)", ")");
                            geometry = wktReader.read(wkt);
                        } catch (ParseException e) {
                            logger.error("error wktReader.read(wkt)" + e.getMessage());
                        }
                    }

                    if (geometry != null && geometry.isValid()) {
                        double EARTH_RADIUS = 6371000;
                        Geometry tmpGeometry = (Geometry) geometry.clone();
                        for (int i = 0; i < tmpGeometry.getCoordinates().length; i++) {
                            double longitude = tmpGeometry.getCoordinates()[i].x;
                            double latitude = tmpGeometry.getCoordinates()[i].y;
                            tmpGeometry.getCoordinates()[i].x = longitude * EARTH_RADIUS * Math.PI / 180.;
                            tmpGeometry.getCoordinates()[i].y = EARTH_RADIUS * Math.sin(Math.toRadians(latitude));
                        }

                        double area = 0;
                        double perimeter = 0;

                        if (geometry.getGeometryType().equalsIgnoreCase("point")) {
                            area = Math.PI * Math.pow(radius, 2);
                            perimeter = 2 * Math.PI * radius;
                        } else if (geometry.getGeometryType().equalsIgnoreCase("linestring")) {
                            perimeter = getPerimeter((LineString) geometry);
                        } else if (geometry.getGeometryType().equalsIgnoreCase("polygon")) {
                            area = getArea((Polygon) tmpGeometry);
                            perimeter = getPerimeter((Polygon) geometry);
                        }
                        GeoFence geoFence = new GeoFence();
                        geoFence.setContractId(contractId);

                        if (groupId != null) {
                            geoFence.setGroupId(groupId);
                            geoFence.setGroup(settingsService.getZoiGroupById(groupId));
                        } else {
                            geoFence.setGroupId(0L);
                            geoFence.setGroup(settingsService.getZoiGroupById(0L));
                        }

                        geoFence.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        geoFence.setRegDate(new Timestamp(System.currentTimeMillis()));
                        geoFence.setName(name);
                        geoFence.setFontSize(fontSize);
                        geoFence.setFontColor(fontColor);
                        geoFence.setType(geometry.getGeometryType());
                        geoFence.setColor(geometryColor);

                        if (file != null && file.getSize() > 0) {
                            FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                            geoFence.setFileId(fileStorage.getId());
                            geoFence.setFile(fileStorage);
                        }
                        if (image != null && image.getSize() > 0) {
                            FileStorage imageStorage = storageService.saveMultipartFileToStorage(image);
                            geoFence.setImageId(imageStorage.getId());
                            geoFence.setImage(imageStorage);
                        }
                        geoFence.setDescription(description);

                        geoFence.setRadius(radius);
                        geoFence.setGeometryOpacity(geometryOpacity);

                        geoFence.setArea(area);
                        geoFence.setPerimeter(perimeter);

                        geoFence.setWktString(wkt);
                        geoFenceService.saveGeoFence(geoFence);

                        addUserZoiAccess(geoFence);

                        Coordinate[] coordinates = geometry.getCoordinates();
                        List<GeoFencePoint> geoFencePointList = new ArrayList<>();

                        for (Coordinate coordinate : coordinates) {
                            GeoFencePoint geoFencePoint = new GeoFencePoint();
                            geoFencePoint.setLongitude(coordinate.x);
                            geoFencePoint.setLatitude(coordinate.y);
                            geoFencePoint.setGeoFence(geoFence);
                            geoFencePointList.add(geoFencePoint);
                            geoFenceService.saveGeoFencePoint(geoFencePoint);
                        }

                        geoFence.setGeoFencePointList(geoFencePointList);
                        geoFenceJSON = new GeoFenceJSON(geoFence, showGeoZoneName);
                        geoFenceJSON.setIsLimitOver(false);

                        // Update core for GeoFence by Mobject
                        coreMain.coreUpdater.updateGeofenceById(geoFence.getId());
                    }
                }
            } else {
                ignorableFields.add("id");
                ignorableFields.add("name");
                ignorableFields.add("fontColor");
                ignorableFields.add("fontSize");
                ignorableFields.add("type");
                ignorableFields.add("color");
                ignorableFields.add("radius");
                ignorableFields.add("area");
                ignorableFields.add("perimeter");
                ignorableFields.add("wktString");
                ignorableFields.add("isNameDisplayed");
                ignorableFields.add("geometryOpacity");

                geoFenceJSON = new GeoFenceJSON();
                geoFenceJSON.setIsLimitOver(true);
            }
        } catch (Exception ex) {
            logger.error("Error: ", ex);
        }

        return geoFenceJSON;
    }

    /**
     * Add user zoi access when new zoi added
     *
     * @param zoi GeoFence
     */
    private void addUserZoiAccess(GeoFence zoi) {
        try {
            UserZoiAccess userZoiAccess = settingsService.getUserZoiAccessByUserIdAndZoiId(MainController.getUserId(), zoi.getId());

            if (userZoiAccess == null) {
                userZoiAccess = new UserZoiAccess();

                userZoiAccess.setZoi(zoi);
                userZoiAccess.setUserId(MainController.getUserId());
                userZoiAccess.setPermission(15);
                userZoiAccess.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                userZoiAccess.setRegDate(new Timestamp(System.currentTimeMillis()));

                settingsService.saveUserZoiAccess(userZoiAccess);
            }

            coreMain.coreUpdater.updateUserZoiAccessById(userZoiAccess.getId());
        } catch (Exception e) {
            logger.error("Error in addUserZoiAccess: " + e.getMessage());
        }
    }

    private List<GeoFence> convertZoiToGeofenceType(List<Geofence> zoiListFromCore) {
        List<GeoFence> zoiList = new ArrayList<>();

        try {
            for (Geofence zoiFromCore : zoiListFromCore) {
                GeoFence zoi = new GeoFence();

                zoi.setId(zoiFromCore.getId());
                zoi.setContractId(zoiFromCore.getContractId());
                zoi.setGroupId(zoiFromCore.getGroupId());
                zoi.setName(zoiFromCore.getName());
                zoi.setType(zoiFromCore.getType());
                zoi.setRadius(zoiFromCore.getRadius().floatValue());
                zoi.setArea(zoiFromCore.getArea());
                zoi.setPerimeter(zoiFromCore.getPerimeter());

                zoi.setColor(zoiFromCore.getColor());
                zoi.setFontColor(zoiFromCore.getFontColor());
                zoi.setFontSize(zoiFromCore.getFontSize());
                zoi.setGeometryOpacity(zoiFromCore.getGeometryOpacity());
                zoi.setWktString(zoiFromCore.getWktString());

                if (zoiFromCore.getImageId() != null && zoiFromCore.getImageId() > 0) {
                    zoi.setImageId(zoiFromCore.getImageId());
                    if (zoi.getImageId() != null && zoi.getImageId() > 0) {
                        zoi.setImage(storageService.getFileStorage(zoi.getImageId()));
                    } else {
                        zoi.setImage(null);
                    }
                }

                zoi.setDescription(zoiFromCore.getDescription());

                zoi.setUserPermission(zoiFromCore.getUserPermission());

//                GeoFence tempZOI = geoFenceService.getGeoFenceById(zoiFromCore.getId());

                zoiList.add(zoi);
            }
        } catch (Exception e) {
            logger.error("Error in convertZoiToGeofenceType", e);
        }

        return zoiList;
    }

}
