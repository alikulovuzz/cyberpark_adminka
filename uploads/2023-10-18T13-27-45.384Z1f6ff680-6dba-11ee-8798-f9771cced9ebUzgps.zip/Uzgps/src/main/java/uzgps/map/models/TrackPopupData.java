package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.vertx.core.json.JsonObject;
import org.springframework.context.i18n.LocaleContextHolder;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GpsUnitBig;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Poi;
import uz.netex.dbtables.Staff;
import uz.netex.uzgps.core.models.sensor.SensorDataType;
import uz.netex.uzgps.core.models.sensor.SensorMap;
import uz.netex.uzgps.core.models.sensor.Translator;
import uzgps.common.FileStorageService;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.SensorDisplay;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Gayratjon on 2/8/2016.
 */
@JsonFilter("TrackPopupDataFilter")
public class TrackPopupData {

    private Long tpRegDate;
    private Timestamp parkingFromDate;
    private Timestamp parkingToDate;
    private Long timestamp;
    private Double lat;
    private Double lon;

    private Long objectId;
    private String objectName;                      //	наименование объекта
    private String objectModel;                     //	марка объекта
    @JsonProperty("objectNumber")
    private String objectPlatenumber;               //	госномер
    private String objectAdditionalInfo;            //	Доп информация
    @JsonProperty("objectLifting")
    private String objectLiftingCapacity;          //	грузоподъемность
    private String trackerType;                     //	тип трекера
    @JsonProperty("trackerSim")
    private String trackerSimNumber;                //	телефонный номер трекера
    private String imea;                            //	imea
    private String trackDate;                       //	дата трека
    private String trackTime;                       //	время трека
    private String dateReceived;                    //	дата получения
    private String timeReceived;                    //	время получения
    private String parkingTime;                     //	время парковки
    @JsonProperty("parkingStart")
    private String parkingDateStart;                //	начало парковки
    @JsonProperty("parkingEnd")
    private String parkingDateEnd;                  //	окончание парковки
    private Double latitude;                        //	широта
    private Double longitude;                       //	долгота
    private Short altitude;                        //	высота (м)
    private Short angle;                          //	угол (гр)
    private Integer speedTrack;                     //	скорость трека (км/ч)
    private Short speedIo;                        //	скорость io (км/ч)
    private Integer odometr;                        //	одометр (м)
    private String address;                         //	адрес
    @JsonProperty("zones")
    private List<String> locatedZones;              //	нахождение в геозонах
    @JsonProperty("routes")
    private List<String> assignedRoutes;            //	назначенные маршруты
    @JsonProperty("movement")
    private Byte motionSensor;                   //	датчик движения
    @JsonProperty("engine")
    private Byte ignitionSensor;                 //	датчик зажигания
    @JsonProperty("sos")
    private Integer alarmButton;                    //	тревожная кнопка
    @JsonProperty("digital1")
    private Byte digitalInput1;                  //	цифровой вход 1
    @JsonProperty("digital2")
    private Byte digitalInput2;                  //	цифровой вход 2
    @JsonProperty("digital3")
    private Byte digitalInput3;                  //	цифровой вход 3
    @JsonProperty("digital4")
    private Byte digitalInput4;                  //	цифровой вход 4
    @JsonProperty("analog1")
    private Short analogInput1;                   //	аналоговый вход 1 (мВ)
    @JsonProperty("analog2")
    private Short analogInput2;                   //	аналоговый вход 2 (мВ)
    @JsonProperty("analog3")
    private Short analogInput3;                   //	аналоговый вход 3 (мВ)
    @JsonProperty("analog4")
    private Short analogInput4;                   //	аналоговый вход 4 (мВ)
    @JsonProperty("trackerBatt")
    private Double trackerBattery;                 //	батарея трекера (в)
    @JsonProperty("trackerCurr")
    private Short trackerChargingCurrent;         //	ток заряда трекера (ма)
    @JsonProperty("power")
    private Double externalPower;                  //	внешнее питание (в)
    @JsonProperty("gsmOperator")
    private Integer gsmOperatorCode;                //	код оператора gsm
    @JsonProperty("gsmSignal")
    private Byte gsmSignalLevel;                 //	уровень сигнала gsm
    private Short cellId;                         //	cell id
    private Short lac;                            //	lac
    private Byte gnss;                           //	gnss
    @JsonProperty("satellites")
    private Byte satelliteCount;                 //	количество спутников
    private Short pdop;                           //	pdop
    private Short hdop;                           //	hdop
    private Integer pcb;                            //	pcb t°c
    @JsonProperty("trackerProf")
    private Byte trackerProfile;                 //	профиль трекера
    private Byte deepSleep;                      //	deep sleep
    @JsonProperty("modeHome")
    private Integer modeHomeRoaming;
    @JsonProperty("dut1")
    private Double indicationDut1;                 //	показания дут 1 (л)
    @JsonProperty("dut2")
    private Double indicationDut2;                 //	показания дут 2 (л)
    @JsonProperty("dut3")
    private Double indicationDut3;                 //	показания дут 3 (л)
    @JsonProperty("dut4")
    private Double indicationDut4;                 //	показания дут 4 (л)
    @JsonProperty("totalDut")
    private Double totalIndicationDut;             //	суммарно показания дут (л)
    //    private Short com11;                          //	com 1 (квант)
//    private Byte com12;                          //	com 1 (t°c)
    //    private Short com21;                          //	com 2 (квант)
//    private Byte com22;                          //	com 2 (t°c)
    private Integer canSpeed;                       //	скорость can (км/ч)
    @JsonProperty("canDist")
    private Long canDistance;                    //	пробег can (км)
    @JsonProperty("canDistServ")
    private Integer canDistanceTillService;         //	пробег до обслуживания can (км)
    @JsonProperty("canFc")
    private Long canFuelConsumption;             //	расход топлива can (л)
    @JsonProperty("canFlPer")
    private Integer canFuelLevelPercentage;         //	уровень топлива can (%)
    @JsonProperty("canFlLit")
    private Integer canFuelLevelLiter;              //	уровень топлива can (л)
    @JsonProperty("exactFc")
    private Integer exactFuelConsumption;           //	точный расход топлива (л)
    private Integer engineSpeed;                    //	обороты двигателя (об/мин)
    private Integer accelatorPedal;                 //	педаль акселератора (%)
    private Long workingTime;                    //	время работы (ч)
    @JsonProperty("fc100km")
    private Integer feulConsumption100km;           //	относительный расход топлива (км/л)
    @JsonProperty("fcHour")
    private Integer feulConsumptionHour;            //	относительный расход топлива (л/ч)
    @JsonProperty("engineTemp")
    private Integer engineTemperature;              //	температура двигателя (t°c)
    @JsonProperty("cabTemp")
    private Integer cabTemperature;                 //	температура кабины (t°c)
    private String vin;                             //	vin
    private String sensorsData;
    private transient SensorMap sensorMap;
    private String staffName;                       //	имя персонала
    @JsonProperty("staffNumber")
    private String staffPhoneNumber;                //	телефон персонала
    private String staffPhoto;                      //	фото персонала

    public Long getTpRegDate() {
        return tpRegDate;
    }

    public void setTpRegDate(Long tpRegDate) {
        this.tpRegDate = tpRegDate;
    }

    public Timestamp getParkingFromDate() {
        return parkingFromDate;
    }

    public void setParkingFromDate(Timestamp parkingFromDate) {
        this.parkingFromDate = parkingFromDate;
    }

    public Timestamp getParkingToDate() {
        return parkingToDate;
    }

    public void setParkingToDate(Timestamp parkingToDate) {
        this.parkingToDate = parkingToDate;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getObjectModel() {
        return objectModel;
    }

    public void setObjectModel(String objectModel) {
        this.objectModel = objectModel;
    }

    public String getObjectPlatenumber() {
        return objectPlatenumber;
    }

    public void setObjectPlatenumber(String objectPlatenumber) {
        this.objectPlatenumber = objectPlatenumber;
    }

    public String getObjectAdditionalInfo() {
        return objectAdditionalInfo;
    }

    public void setObjectAdditionalInfo(String objectAdditionalInfo) {
        this.objectAdditionalInfo = objectAdditionalInfo;
    }

    public String getObjectLiftingCapacity() {
        return objectLiftingCapacity;
    }

    public void setObjectLiftingCapacity(String objectLiftingCapacity) {
        this.objectLiftingCapacity = objectLiftingCapacity;
    }

    public String getTrackerType() {
        return trackerType;
    }

    public void setTrackerType(String trackerType) {
        this.trackerType = trackerType;
    }

    public String getTrackerSimNumber() {
        return trackerSimNumber;
    }

    public void setTrackerSimNumber(String trackerSimNumber) {
        this.trackerSimNumber = trackerSimNumber;
    }

    public String getImea() {
        return imea;
    }

    public void setImea(String imea) {
        this.imea = imea;
    }

    public String getTrackDate() {
        if (this.timestamp != null) {
            return dateInDayFormat(this.timestamp);
        }

        return null;
    }

    public void setTrackDate(String trackDate) {
        this.trackDate = trackDate;
    }

    public String getTrackTime() {
        if (this.timestamp != null) {
            return dateInHourFormat(this.timestamp);
        }

        return null;
    }

    public void setTrackTime(String trackTime) {
        this.trackTime = trackTime;
    }

    public String getDateReceived() {
        if (this.tpRegDate != null) {
            return dateInDayFormat(this.tpRegDate);
        }

        return null;
    }

    public void setDateReceived(String dateReceived) {
        this.dateReceived = dateReceived;
    }

    public String getTimeReceived() {
        if (this.tpRegDate != null) {
            return dateInHourFormat(this.tpRegDate);
        }

        return null;
    }

    public void setTimeReceived(String timeReceived) {
        this.timeReceived = timeReceived;
    }

    public String getParkingTime() {
        if (this.parkingFromDate != null && this.parkingToDate != null) {
            Long millis = this.parkingToDate.getTime() - this.parkingFromDate.getTime();

            return millisToHoursAndMinutes(millis);
        }

        return null;
    }

    public void setParkingTime(String parkingTime) {
        this.parkingTime = parkingTime;
    }

    public String getParkingDateStart() {
        if (this.parkingFromDate != null) {
            return dateInFullFormat(this.parkingFromDate.getTime());
        }

        return null;
    }

    public void setParkingDateStart(String parkingDateStart) {
        this.parkingDateStart = parkingDateStart;
    }

    public String getParkingDateEnd() {
        if (this.parkingToDate != null) {
            return dateInFullFormat(this.parkingToDate.getTime());
        }

        return null;
    }

    public void setParkingDateEnd(String parkingDateEnd) {
        this.parkingDateEnd = parkingDateEnd;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Short getAltitude() {
        return altitude;
    }

    public void setAltitude(Short altitude) {
        this.altitude = altitude;
    }

    public Short getAngle() {
        return angle;
    }

    public void setAngle(Short angle) {
        this.angle = angle;
    }

    public Integer getSpeedTrack() {
        return speedTrack;
    }

    public void setSpeedTrack(Integer speedTrack) {
        this.speedTrack = speedTrack;
    }

    public Short getSpeedIo() {
        return speedIo;
    }

    public void setSpeedIo(Short speedIo) {
        this.speedIo = speedIo;
    }

    public Integer getOdometr() {
        return odometr;
    }

    public void setOdometr(Integer odometr) {
        this.odometr = odometr;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<String> getLocatedZones() {
        return locatedZones;
    }

    public void setLocatedZones(List<String> locatedZones) {
        this.locatedZones = locatedZones;
    }

    public List<String> getAssignedRoutes() {
        return assignedRoutes;
    }

    public void setAssignedRoutes(List<String> assignedRoutes) {
        this.assignedRoutes = assignedRoutes;
    }

    public Byte getMotionSensor() {
        return motionSensor;
    }

    public void setMotionSensor(Byte motionSensor) {
        this.motionSensor = motionSensor;
    }

    public Byte getIgnitionSensor() {
        return ignitionSensor;
    }

    public void setIgnitionSensor(Byte ignitionSensor) {
        this.ignitionSensor = ignitionSensor;
    }

    public Integer getAlarmButton() {
        return alarmButton;
    }

    public void setAlarmButton(Integer alarmButton) {
        this.alarmButton = alarmButton;
    }

    public Byte getDigitalInput1() {
        return digitalInput1;
    }

    public void setDigitalInput1(Byte digitalInput1) {
        this.digitalInput1 = digitalInput1;
    }

    public Byte getDigitalInput2() {
        return digitalInput2;
    }

    public void setDigitalInput2(Byte digitalInput2) {
        this.digitalInput2 = digitalInput2;
    }

    public Byte getDigitalInput3() {
        return digitalInput3;
    }

    public void setDigitalInput3(Byte digitalInput3) {
        this.digitalInput3 = digitalInput3;
    }

    public Byte getDigitalInput4() {
        return digitalInput4;
    }

    public void setDigitalInput4(Byte digitalInput4) {
        this.digitalInput4 = digitalInput4;
    }

    public Short getAnalogInput1() {
        return analogInput1;
    }

    public void setAnalogInput1(Short analogInput1) {
        this.analogInput1 = analogInput1;
    }

    public Short getAnalogInput2() {
        return analogInput2;
    }

    public void setAnalogInput2(Short analogInput2) {
        this.analogInput2 = analogInput2;
    }

    public Short getAnalogInput3() {
        return analogInput3;
    }

    public void setAnalogInput3(Short analogInput3) {
        this.analogInput3 = analogInput3;
    }

    public Short getAnalogInput4() {
        return analogInput4;
    }

    public void setAnalogInput4(Short analogInput4) {
        this.analogInput4 = analogInput4;
    }

    public Double getTrackerBattery() {
        return trackerBattery;
    }

    public void setTrackerBattery(Double trackerBattery) {
        this.trackerBattery = trackerBattery;
    }

    public Short getTrackerChargingCurrent() {
        return trackerChargingCurrent;
    }

    public void setTrackerChargingCurrent(Short trackerChargingCurrent) {
        this.trackerChargingCurrent = trackerChargingCurrent;
    }

    public Double getExternalPower() {
        return externalPower;
    }

    public void setExternalPower(Double externalPower) {
        this.externalPower = externalPower;
    }

    public Integer getGsmOperatorCode() {
        return gsmOperatorCode;
    }

    public void setGsmOperatorCode(Integer gsmOperatorCode) {
        this.gsmOperatorCode = gsmOperatorCode;
    }

    public Byte getGsmSignalLevel() {
        return gsmSignalLevel;
    }

    public void setGsmSignalLevel(Byte gsmSignalLevel) {
        this.gsmSignalLevel = gsmSignalLevel;
    }

    public Short getCellId() {
        return cellId;
    }

    public void setCellId(Short cellId) {
        this.cellId = cellId;
    }

    public Short getLac() {
        return lac;
    }

    public void setLac(Short lac) {
        this.lac = lac;
    }

    public Byte getGnss() {
        return gnss;
    }

    public void setGnss(Byte gnss) {
        this.gnss = gnss;
    }

    public Byte getSatelliteCount() {
        return satelliteCount;
    }

    public void setSatelliteCount(Byte satelliteCount) {
        this.satelliteCount = satelliteCount;
    }

    public Short getPdop() {
        return pdop;
    }

    public void setPdop(Short pdop) {
        this.pdop = pdop;
    }

    public Short getHdop() {
        return hdop;
    }

    public void setHdop(Short hdop) {
        this.hdop = hdop;
    }

    public Integer getPcb() {
        return pcb;
    }

    public void setPcb(Integer pcb) {
        this.pcb = pcb;
    }

    public Byte getTrackerProfile() {
        return trackerProfile;
    }

    public void setTrackerProfile(Byte trackerProfile) {
        this.trackerProfile = trackerProfile;
    }

    public Byte getDeepSleep() {
        return deepSleep;
    }

    public void setDeepSleep(Byte deepSleep) {
        this.deepSleep = deepSleep;
    }

    public Double getIndicationDut1() {
        return indicationDut1;
    }

    public void setIndicationDut1(Double indicationDut1) {
        this.indicationDut1 = indicationDut1;
    }

    public Double getIndicationDut2() {
        return indicationDut2;
    }

    public void setIndicationDut2(Double indicationDut2) {
        this.indicationDut2 = indicationDut2;
    }

    public Double getIndicationDut3() {
        return indicationDut3;
    }

    public void setIndicationDut3(Double indicationDut3) {
        this.indicationDut3 = indicationDut3;
    }

    public Double getIndicationDut4() {
        return indicationDut4;
    }

    public void setIndicationDut4(Double indicationDut4) {
        this.indicationDut4 = indicationDut4;
    }

    public Double getTotalIndicationDut() {
        return totalIndicationDut;
    }

    public void setTotalIndicationDut(Double totalIndicationDut) {
        this.totalIndicationDut = totalIndicationDut;
    }

    public Integer getCanSpeed() {
        return canSpeed;
    }

    public void setCanSpeed(Integer canSpeed) {
        this.canSpeed = canSpeed;
    }

    public Long getCanDistance() {
        return canDistance;
    }

    public void setCanDistance(Long canDistance) {
        this.canDistance = canDistance;
    }

    public Integer getCanDistanceTillService() {
        return canDistanceTillService;
    }

    public void setCanDistanceTillService(Integer canDistanceTillService) {
        this.canDistanceTillService = canDistanceTillService;
    }

    public Long getCanFuelConsumption() {
        return canFuelConsumption;
    }

    public void setCanFuelConsumption(Long canFuelConsumption) {
        this.canFuelConsumption = canFuelConsumption;
    }

    public Integer getCanFuelLevelPercentage() {
        return canFuelLevelPercentage;
    }

    public void setCanFuelLevelPercentage(Integer canFuelLevelPercentage) {
        this.canFuelLevelPercentage = canFuelLevelPercentage;
    }

    public Integer getCanFuelLevelLiter() {
        return canFuelLevelLiter;
    }

    public void setCanFuelLevelLiter(Integer canFuelLevelLiter) {
        this.canFuelLevelLiter = canFuelLevelLiter;
    }

    public Integer getExactFuelConsumption() {
        return exactFuelConsumption;
    }

    public void setExactFuelConsumption(Integer exactFuelConsumption) {
        this.exactFuelConsumption = exactFuelConsumption;
    }

    public Integer getEngineSpeed() {
        return engineSpeed;
    }

    public void setEngineSpeed(Integer engineSpeed) {
        this.engineSpeed = engineSpeed;
    }

    public Integer getAccelatorPedal() {
        return accelatorPedal;
    }

    public void setAccelatorPedal(Integer accelatorPedal) {
        this.accelatorPedal = accelatorPedal;
    }

    public Long getWorkingTime() {
        return workingTime;
    }

    public void setWorkingTime(Long workingTime) {
        this.workingTime = workingTime;
    }

    public Integer getFeulConsumption100km() {
        return feulConsumption100km;
    }

    public void setFeulConsumption100km(Integer feulConsumption100km) {
        this.feulConsumption100km = feulConsumption100km;
    }

    public Integer getFeulConsumptionHour() {
        return feulConsumptionHour;
    }

    public void setFeulConsumptionHour(Integer feulConsumptionHour) {
        this.feulConsumptionHour = feulConsumptionHour;
    }

    public Integer getEngineTemperature() {
        return engineTemperature;
    }

    public void setEngineTemperature(Integer engineTemperature) {
        this.engineTemperature = engineTemperature;
    }

    public Integer getCabTemperature() {
        return cabTemperature;
    }

    public void setCabTemperature(Integer cabTemperature) {
        this.cabTemperature = cabTemperature;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getSensorsData() {
        return sensorsData;
    }

    public void setSensorsData(String sensorsData) {
        this.sensorsData = sensorsData;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffPhoneNumber() {
        return staffPhoneNumber;
    }

    public void setStaffPhoneNumber(String staffPhoneNumber) {
        this.staffPhoneNumber = staffPhoneNumber;
    }

    public String getStaffPhoto() {
        return staffPhoto;
    }

    public void setStaffPhoto(String staffPhoto) {
        this.staffPhoto = staffPhoto;
    }

    public Integer getModeHomeRoaming() {
        return modeHomeRoaming;
    }

    public void setModeHomeRoaming(Integer modeHomeRoaming) {
        this.modeHomeRoaming = modeHomeRoaming;
    }

    /**
     * Format date in 'dd.MM.yyyy'
     *
     * @param dateLong
     * @return
     */
    private String dateInDayFormat(Long dateLong) {
        if (dateLong != null) {
            Date date = new Date(dateLong);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");

            return dateFormat.format(date);
        }

        return null;
    }

    /**
     * Format date in 'dd.MM.yyyy'
     *
     * @param dateLong
     * @return
     */
    private String dateInHourFormat(Long dateLong) {
        if (dateLong != null) {
            Date date = new Date(dateLong);
            DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

            return dateFormat.format(date);
        }

        return null;
    }

    /**
     * Format date in 'dd.MM.yyyy HH:mm:ss'
     *
     * @param dateLong
     * @return
     */
    private String dateInFullFormat(Long dateLong) {
        if (dateLong != null) {
            Date date = new Date(dateLong);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

            return dateFormat.format(date);
        }

        return null;
    }

    /**
     * Convert milliseconds to hours ans minutes HH:mm format
     *
     * @param millis
     */
    private String millisToHoursAndMinutes(Long millis) {
        Long hours = (long) Math.floor(millis / 3600000);
        Long minutes = ((millis % 3600000) / 60000);

        return (hours < 10 ? "0" : "") + hours + ":" + (minutes < 10 ? "0" : "") + minutes;
    }

    /**
     * Set ignored field names of monitoring popup for JSON
     *
     * @param contractSettings
     * @return
     */
    public static Set<String> monitoringPopupIgnoredFieldNames(ContractSettings contractSettings) {
        Set<String> ignorableFieldNames = allIgnorableFieldNames();

        if (contractSettings != null) {
            // Checking monitoring value part1
            Integer value = contractSettings.getMonitoringValuesPart1() != null ? contractSettings.getMonitoringValuesPart1() : 0;

            ignorableFieldNames.remove("objectId");
            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.OBJECT_NAME) == 1)
                    ignorableFieldNames.remove("objectName");
                if (contractSettings.hasValueInPosition(value, ContractSettings.OBJECT_MODEL) == 1)
                    ignorableFieldNames.remove("objectModel");
                if (contractSettings.hasValueInPosition(value, ContractSettings.OBJECT_PLATENUMBER) == 1)
                    ignorableFieldNames.remove("objectNumber");
                if (contractSettings.hasValueInPosition(value, ContractSettings.OBJECT_ADDITIONAL_INFO) == 1)
                    ignorableFieldNames.remove("objectAdditionalInfo");
                if (contractSettings.hasValueInPosition(value, ContractSettings.OBJECT_LIFTING_CAPACITY) == 1)
                    ignorableFieldNames.remove("objectLifting");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_TYPE) == 1)
                    ignorableFieldNames.remove("trackerType");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_SIM_NUMBER) == 1)
                    ignorableFieldNames.remove("trackerSim");
                if (contractSettings.hasValueInPosition(value, ContractSettings.IMEA) == 1)
                    ignorableFieldNames.remove("imea");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_DATE) == 1)
                    ignorableFieldNames.remove("trackDate");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_TIME) == 1)
                    ignorableFieldNames.remove("trackTime");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DATE_RECEIVED) == 1)
                    ignorableFieldNames.remove("dateReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TIME_RECEIVED) == 1)
                    ignorableFieldNames.remove("timeReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.LATITUDE) == 1)
                    ignorableFieldNames.remove("latitude");
                if (contractSettings.hasValueInPosition(value, ContractSettings.LONGITUDE) == 1)
                    ignorableFieldNames.remove("longitude");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ALTITUDE) == 1)
                    ignorableFieldNames.remove("altitude");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANGLE) == 1)
                    ignorableFieldNames.remove("angle");
                if (contractSettings.hasValueInPosition(value, ContractSettings.SPEED_TRACK) == 1)
                    ignorableFieldNames.remove("speedTrack");
                if (contractSettings.hasValueInPosition(value, ContractSettings.SPEED_IO) == 1)
                    ignorableFieldNames.remove("speedIo");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ODOMETR) == 1)
                    ignorableFieldNames.remove("odometr");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ADDRESS) == 1)
                    ignorableFieldNames.remove("address");
                if (contractSettings.hasValueInPosition(value, ContractSettings.LOCATED_ZONES) == 1)
                    ignorableFieldNames.remove("zones");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ASSIGNED_ROUTES) == 1)
                    ignorableFieldNames.remove("routes");
                if (contractSettings.hasValueInPosition(value, ContractSettings.MOTION_SENSOR) == 1)
                    ignorableFieldNames.remove("movement");
                if (contractSettings.hasValueInPosition(value, ContractSettings.IGNITION_SENSOR) == 1)
                    ignorableFieldNames.remove("engine");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ALARM_BUTTON) == 1)
                    ignorableFieldNames.remove("sos");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_3) == 1)
                    ignorableFieldNames.remove("digital3");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_4) == 1)
                    ignorableFieldNames.remove("digital4");
            }

            // Checking monitoring value part2
            value = contractSettings.getMonitoringValuesPart2() != null ? contractSettings.getMonitoringValuesPart2() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_1) == 1)
                    ignorableFieldNames.remove("analog1");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_2) == 1)
                    ignorableFieldNames.remove("analog2");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_3) == 1)
                    ignorableFieldNames.remove("analog3");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_4) == 1)
                    ignorableFieldNames.remove("analog4");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_BATTERY) == 1)
                    ignorableFieldNames.remove("trackerBatt");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_CHARGING_CURRENT) == 1)
                    ignorableFieldNames.remove("trackerCurr");
                if (contractSettings.hasValueInPosition(value, ContractSettings.EXTERNAL_POWER) == 1)
                    ignorableFieldNames.remove("power");
                if (contractSettings.hasValueInPosition(value, ContractSettings.GSM_OPERATOR_CODE) == 1)
                    ignorableFieldNames.remove("gsmOperator");
                if (contractSettings.hasValueInPosition(value, ContractSettings.GSM_SIGNAL_LEVEL) == 1)
                    ignorableFieldNames.remove("gsmSignal");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CELL_ID) == 1)
                    ignorableFieldNames.remove("cellId");
                if (contractSettings.hasValueInPosition(value, ContractSettings.LAC) == 1)
                    ignorableFieldNames.remove("lac");
                if (contractSettings.hasValueInPosition(value, ContractSettings.GNSS) == 1)
                    ignorableFieldNames.remove("gnss");
                if (contractSettings.hasValueInPosition(value, ContractSettings.SATELLITE_COUNT) == 1)
                    ignorableFieldNames.remove("satellites");
                if (contractSettings.hasValueInPosition(value, ContractSettings.PDOP) == 1)
                    ignorableFieldNames.remove("pdop");
                if (contractSettings.hasValueInPosition(value, ContractSettings.HDOP) == 1)
                    ignorableFieldNames.remove("hdop");
                if (contractSettings.hasValueInPosition(value, ContractSettings.PCB) == 1)
                    ignorableFieldNames.remove("pcb");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_PROFILE) == 1) {
                    ignorableFieldNames.remove("trackerProf");
                    ignorableFieldNames.remove("modeHome");
                }
                if (contractSettings.hasValueInPosition(value, ContractSettings.DEEP_SLEEP) == 1)
                    ignorableFieldNames.remove("deepSleep");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_1) == 1)
                    ignorableFieldNames.remove("dut1");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_2) == 1)
                    ignorableFieldNames.remove("dut2");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TOTAL_INDICATION_DUT) == 1)
                    ignorableFieldNames.remove("totalDut");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_SPEED) == 1)
                    ignorableFieldNames.remove("canSpeed");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_DISTANCE) == 1)
                    ignorableFieldNames.remove("canDist");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_DISTANCE_TILL_SERVICE) == 1)
                    ignorableFieldNames.remove("canDistServ");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_CONSUMPTION) == 1)
                    ignorableFieldNames.remove("canFc");
            }

            // Checking monitoring value part3
            value = contractSettings.getMonitoringValuesPart3() != null ? contractSettings.getMonitoringValuesPart3() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_LEVEL_PERCENTAGE) == 1)
                    ignorableFieldNames.remove("canFlPer");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_LEVEL_LITER) == 1)
                    ignorableFieldNames.remove("canFlLit");
                if (contractSettings.hasValueInPosition(value, ContractSettings.EXACT_FUEL_CONSUMPTION) == 1)
                    ignorableFieldNames.remove("exactFc");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ENGINE_SPEED) == 1)
                    ignorableFieldNames.remove("engineSpeed");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ACCELATOR_PEDAL) == 1)
                    ignorableFieldNames.remove("accelatorPedal");
                if (contractSettings.hasValueInPosition(value, ContractSettings.WORKING_TIME) == 1)
                    ignorableFieldNames.remove("workingTime");
                if (contractSettings.hasValueInPosition(value, ContractSettings.FEUL_CONSUMPTION_100KM) == 1)
                    ignorableFieldNames.remove("fc100km");
                if (contractSettings.hasValueInPosition(value, ContractSettings.FEUL_CONSUMPTION_HOUR) == 1)
                    ignorableFieldNames.remove("fcHour");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ENGINE_TEMPERATURE) == 1)
                    ignorableFieldNames.remove("engineTemp");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAB_TEMPERATURE) == 1)
                    ignorableFieldNames.remove("cabTemp");
                if (contractSettings.hasValueInPosition(value, ContractSettings.VIN) == 1)
                    ignorableFieldNames.remove("vin");
                if (contractSettings.hasValueInPosition(value, ContractSettings.STAFF_NAME) == 1)
                    ignorableFieldNames.remove("staffName");
                if (contractSettings.hasValueInPosition(value, ContractSettings.STAFF_PHONE_NUMBER) == 1)
                    ignorableFieldNames.remove("staffNumber");
                if (contractSettings.hasValueInPosition(value, ContractSettings.STAFF_PHOTO) == 1)
                    ignorableFieldNames.remove("staffPhoto");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_1) == 1)
                    ignorableFieldNames.remove("digital1");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_2) == 1)
                    ignorableFieldNames.remove("digital2");
            }

            // Checking monitoring value part3
            value = contractSettings.getMonitoringValuesPart4() != null ? contractSettings.getMonitoringValuesPart4() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_3) == 1)
                    ignorableFieldNames.remove("dut3");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_4) == 1)
                    ignorableFieldNames.remove("dut4");
            }

        }

        return ignorableFieldNames;
    }

    /**
     * Set ignored field names of track popup for JSON
     *
     * @param contractSettings
     * @return
     */
    public static Set<String> trackPopupIgnoredFieldNames(ContractSettings contractSettings) {
        Set<String> ignorableFieldNames = allIgnorableFieldNames();

        if (contractSettings != null) {
            // Checking track value part1
            Integer value = contractSettings.getTrackPopupValuesPart1() != null ? contractSettings.getTrackPopupValuesPart1() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_DATE) == 1)
                    ignorableFieldNames.remove("trackDate");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_TIME) == 1)
                    ignorableFieldNames.remove("trackTime");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DATE_RECEIVED) == 1)
                    ignorableFieldNames.remove("dateReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TIME_RECEIVED) == 1)
                    ignorableFieldNames.remove("timeReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.LATITUDE) == 1)
                    ignorableFieldNames.remove("latitude");
                if (contractSettings.hasValueInPosition(value, ContractSettings.LONGITUDE) == 1)
                    ignorableFieldNames.remove("longitude");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ALTITUDE) == 1)
                    ignorableFieldNames.remove("altitude");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANGLE) == 1)
                    ignorableFieldNames.remove("angle");
                if (contractSettings.hasValueInPosition(value, ContractSettings.SPEED_TRACK) == 1)
                    ignorableFieldNames.remove("speedTrack");
                if (contractSettings.hasValueInPosition(value, ContractSettings.SPEED_IO) == 1)
                    ignorableFieldNames.remove("speedIo");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ODOMETR) == 1)
                    ignorableFieldNames.remove("odometr");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ADDRESS) == 1)
                    ignorableFieldNames.remove("address");
//                if (contractSettings.hasValueInPosition(value, ContractSettings.LOCATED_ZONES) == 1)
//                    ignorableFieldNames.remove("zones");
//                if (contractSettings.hasValueInPosition(value, ContractSettings.ASSIGNED_ROUTES) == 1)
//                    ignorableFieldNames.remove("routes");
                if (contractSettings.hasValueInPosition(value, ContractSettings.MOTION_SENSOR) == 1)
                    ignorableFieldNames.remove("movement");
                if (contractSettings.hasValueInPosition(value, ContractSettings.IGNITION_SENSOR) == 1)
                    ignorableFieldNames.remove("engine");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ALARM_BUTTON) == 1)
                    ignorableFieldNames.remove("sos");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_3) == 1)
                    ignorableFieldNames.remove("digital3");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_4) == 1)
                    ignorableFieldNames.remove("digital4");
            }

            // Checking track value part2
            value = contractSettings.getTrackPopupValuesPart2() != null ? contractSettings.getTrackPopupValuesPart2() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_1) == 1)
                    ignorableFieldNames.remove("analog1");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_2) == 1)
                    ignorableFieldNames.remove("analog2");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_3) == 1)
                    ignorableFieldNames.remove("analog3");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ANALOG_INPUT_4) == 1)
                    ignorableFieldNames.remove("analog4");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_BATTERY) == 1)
                    ignorableFieldNames.remove("trackerBatt");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_CHARGING_CURRENT) == 1)
                    ignorableFieldNames.remove("trackerCurr");
                if (contractSettings.hasValueInPosition(value, ContractSettings.EXTERNAL_POWER) == 1)
                    ignorableFieldNames.remove("power");
                if (contractSettings.hasValueInPosition(value, ContractSettings.GSM_OPERATOR_CODE) == 1)
                    ignorableFieldNames.remove("gsmOperator");
                if (contractSettings.hasValueInPosition(value, ContractSettings.GSM_SIGNAL_LEVEL) == 1)
                    ignorableFieldNames.remove("gsmSignal");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CELL_ID) == 1)
                    ignorableFieldNames.remove("cellId");
                if (contractSettings.hasValueInPosition(value, ContractSettings.LAC) == 1)
                    ignorableFieldNames.remove("lac");
                if (contractSettings.hasValueInPosition(value, ContractSettings.GNSS) == 1)
                    ignorableFieldNames.remove("gnss");
                if (contractSettings.hasValueInPosition(value, ContractSettings.SATELLITE_COUNT) == 1)
                    ignorableFieldNames.remove("satellites");
                if (contractSettings.hasValueInPosition(value, ContractSettings.PDOP) == 1)
                    ignorableFieldNames.remove("pdop");
                if (contractSettings.hasValueInPosition(value, ContractSettings.HDOP) == 1)
                    ignorableFieldNames.remove("hdop");
                if (contractSettings.hasValueInPosition(value, ContractSettings.PCB) == 1)
                    ignorableFieldNames.remove("pcb");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_PROFILE) == 1) {
                    ignorableFieldNames.remove("trackerProf");
                    ignorableFieldNames.remove("modeHome");
                }
                if (contractSettings.hasValueInPosition(value, ContractSettings.DEEP_SLEEP) == 1)
                    ignorableFieldNames.remove("deepSleep");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_1) == 1)
                    ignorableFieldNames.remove("dut1");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_2) == 1)
                    ignorableFieldNames.remove("dut2");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TOTAL_INDICATION_DUT) == 1)
                    ignorableFieldNames.remove("totalDut");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_SPEED) == 1)
                    ignorableFieldNames.remove("canSpeed");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_DISTANCE) == 1)
                    ignorableFieldNames.remove("canDist");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_DISTANCE_TILL_SERVICE) == 1)
                    ignorableFieldNames.remove("canDistServ");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_CONSUMPTION) == 1)
                    ignorableFieldNames.remove("canFc");
            }

            // Checking track value part3
            value = contractSettings.getTrackPopupValuesPart3() != null ? contractSettings.getTrackPopupValuesPart3() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_LEVEL_PERCENTAGE) == 1)
                    ignorableFieldNames.remove("canFlPer");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAN_FUEL_LEVEL_LITER) == 1)
                    ignorableFieldNames.remove("canFlLit");
                if (contractSettings.hasValueInPosition(value, ContractSettings.EXACT_FUEL_CONSUMPTION) == 1)
                    ignorableFieldNames.remove("exactFc");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ENGINE_SPEED) == 1)
                    ignorableFieldNames.remove("engineSpeed");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ACCELATOR_PEDAL) == 1)
                    ignorableFieldNames.remove("accelatorPedal");
                if (contractSettings.hasValueInPosition(value, ContractSettings.WORKING_TIME) == 1)
                    ignorableFieldNames.remove("workingTime");
                if (contractSettings.hasValueInPosition(value, ContractSettings.FEUL_CONSUMPTION_100KM) == 1)
                    ignorableFieldNames.remove("fc100km");
                if (contractSettings.hasValueInPosition(value, ContractSettings.FEUL_CONSUMPTION_HOUR) == 1)
                    ignorableFieldNames.remove("fcHour");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ENGINE_TEMPERATURE) == 1)
                    ignorableFieldNames.remove("engineTemp");
                if (contractSettings.hasValueInPosition(value, ContractSettings.CAB_TEMPERATURE) == 1)
                    ignorableFieldNames.remove("cabTemp");
                if (contractSettings.hasValueInPosition(value, ContractSettings.VIN) == 1)
                    ignorableFieldNames.remove("vin");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_1) == 1)
                    ignorableFieldNames.remove("digital1");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DIGITAL_INPUT_2) == 1)
                    ignorableFieldNames.remove("digital2");
            }

            // Checking track value part3
            value = contractSettings.getTrackPopupValuesPart4() != null ? contractSettings.getTrackPopupValuesPart4() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_3) == 1)
                    ignorableFieldNames.remove("dut3");
                if (contractSettings.hasValueInPosition(value, ContractSettings.INDICATION_DUT_4) == 1)
                    ignorableFieldNames.remove("dut4");
            }
        }

        return ignorableFieldNames;
    }

    /**
     * Set ignored field names of parking popup for JSON
     *
     * @param contractSettings
     * @return
     */
    public static Set<String> parkingPopupIgnoredFieldNames(ContractSettings contractSettings) {
        Set<String> ignorableFieldNames = allIgnorableFieldNames();

        ignorableFieldNames.remove("timestamp");
        ignorableFieldNames.remove("lat");
        ignorableFieldNames.remove("lon");

        if (contractSettings != null) {
            // Checking parking value part1
            Integer value = contractSettings.getParkingPopupValuesPart1() != null ? contractSettings.getParkingPopupValuesPart1() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.OBJECT_NAME) == 1)
                    ignorableFieldNames.remove("objectName");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_DATE) == 1)
                    ignorableFieldNames.remove("trackDate");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_TIME) == 1)
                    ignorableFieldNames.remove("trackTime");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DATE_RECEIVED) == 1)
                    ignorableFieldNames.remove("dateReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TIME_RECEIVED) == 1)
                    ignorableFieldNames.remove("timeReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.PARKING_TIME) == 1)
                    ignorableFieldNames.remove("parkingTime");
                if (contractSettings.hasValueInPosition(value, ContractSettings.PARKING_DATE_START) == 1)
                    ignorableFieldNames.remove("parkingStart");
                if (contractSettings.hasValueInPosition(value, ContractSettings.PARKING_DATE_END) == 1)
                    ignorableFieldNames.remove("parkingEnd");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ADDRESS) == 1)
                    ignorableFieldNames.remove("address");
//                if (contractSettings.hasValueInPosition(value, ContractSettings.LOCATED_ZONES) == 1)
//                    ignorableFieldNames.remove("zones");
//                if (contractSettings.hasValueInPosition(value, ContractSettings.ASSIGNED_ROUTES) == 1)
//                    ignorableFieldNames.remove("routes");
            }
        }

        return ignorableFieldNames;
    }

    /**
     * Set ignored field names of sos popup for JSON
     *
     * @param contractSettings
     * @return
     */
    public static Set<String> sosPopupIgnoredFieldNames(ContractSettings contractSettings) {
        Set<String> ignorableFieldNames = allIgnorableFieldNames();

        ignorableFieldNames.remove("timestamp");
        ignorableFieldNames.remove("lat");
        ignorableFieldNames.remove("lon");

        if (contractSettings != null) {
            // Checking sos value part1
            Integer value = contractSettings.getSosPopupValuesPart1() != null ? contractSettings.getSosPopupValuesPart1() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.OBJECT_NAME) == 1)
                    ignorableFieldNames.remove("objectName");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_SIM_NUMBER) == 1)
                    ignorableFieldNames.remove("trackerSim");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_DATE) == 1)
                    ignorableFieldNames.remove("trackDate");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACK_TIME) == 1)
                    ignorableFieldNames.remove("trackTime");
                if (contractSettings.hasValueInPosition(value, ContractSettings.DATE_RECEIVED) == 1)
                    ignorableFieldNames.remove("dateReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.TIME_RECEIVED) == 1)
                    ignorableFieldNames.remove("timeReceived");
                if (contractSettings.hasValueInPosition(value, ContractSettings.ADDRESS) == 1)
                    ignorableFieldNames.remove("address");
                if (contractSettings.hasValueInPosition(value, ContractSettings.MOTION_SENSOR) == 1)
                    ignorableFieldNames.remove("movement");
                if (contractSettings.hasValueInPosition(value, ContractSettings.IGNITION_SENSOR) == 1)
                    ignorableFieldNames.remove("engine");
            }

            // Checking sos value part2
            value = contractSettings.getSosPopupValuesPart2() != null ? contractSettings.getSosPopupValuesPart2() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.TRACKER_BATTERY) == 1)
                    ignorableFieldNames.remove("trackerBatt");
                if (contractSettings.hasValueInPosition(value, ContractSettings.GSM_SIGNAL_LEVEL) == 1)
                    ignorableFieldNames.remove("gsmSignal");
                if (contractSettings.hasValueInPosition(value, ContractSettings.SATELLITE_COUNT) == 1)
                    ignorableFieldNames.remove("satellites");
            }

            // Checking sos value part3
            value = contractSettings.getSosPopupValuesPart3() != null ? contractSettings.getSosPopupValuesPart3() : 0;

            if (value > 0) {
                if (contractSettings.hasValueInPosition(value, ContractSettings.STAFF_NAME) == 1)
                    ignorableFieldNames.remove("staffName");
                if (contractSettings.hasValueInPosition(value, ContractSettings.STAFF_PHONE_NUMBER) == 1)
                    ignorableFieldNames.remove("staffNumber");
                if (contractSettings.hasValueInPosition(value, ContractSettings.STAFF_PHOTO) == 1)
                    ignorableFieldNames.remove("staffPhoto");
            }
        }

        return ignorableFieldNames;
    }

    private static Set<String> allIgnorableFieldNames() {
        Set<String> ignorableFieldNames = new HashSet<>();

        ignorableFieldNames.add("tpRegDate");
        ignorableFieldNames.add("parkingFromDate");
        ignorableFieldNames.add("parkingToDate");
        ignorableFieldNames.add("timestamp");
        ignorableFieldNames.add("lat");
        ignorableFieldNames.add("lon");

        ignorableFieldNames.add("objectId");
        ignorableFieldNames.add("objectName");
        ignorableFieldNames.add("objectModel");
        ignorableFieldNames.add("objectNumber");
        ignorableFieldNames.add("objectAdditionalInfo");
        ignorableFieldNames.add("objectLifting");
        ignorableFieldNames.add("trackerType");
        ignorableFieldNames.add("trackerSim");
        ignorableFieldNames.add("imea");
        ignorableFieldNames.add("trackDate");
        ignorableFieldNames.add("trackTime");
        ignorableFieldNames.add("dateReceived");
        ignorableFieldNames.add("timeReceived");
        ignorableFieldNames.add("parkingTime");
        ignorableFieldNames.add("parkingStart");
        ignorableFieldNames.add("parkingEnd");
        ignorableFieldNames.add("latitude");
        ignorableFieldNames.add("longitude");
        ignorableFieldNames.add("altitude");
        ignorableFieldNames.add("angle");
        ignorableFieldNames.add("speedTrack");
        ignorableFieldNames.add("speedIo");
        ignorableFieldNames.add("odometr");
        ignorableFieldNames.add("address");
        ignorableFieldNames.add("zones");
        ignorableFieldNames.add("routes");
        ignorableFieldNames.add("movement");
        ignorableFieldNames.add("engine");
        ignorableFieldNames.add("sos");
        ignorableFieldNames.add("digital3");
        ignorableFieldNames.add("digital4");
        ignorableFieldNames.add("analog1");
        ignorableFieldNames.add("analog2");
        ignorableFieldNames.add("analog3");
        ignorableFieldNames.add("analog4");
        ignorableFieldNames.add("trackerBatt");
        ignorableFieldNames.add("trackerCurr");
        ignorableFieldNames.add("power");
        ignorableFieldNames.add("gsmOperator");
        ignorableFieldNames.add("gsmSignal");
        ignorableFieldNames.add("cellId");
        ignorableFieldNames.add("lac");
        ignorableFieldNames.add("gnss");
        ignorableFieldNames.add("satellites");
        ignorableFieldNames.add("pdop");
        ignorableFieldNames.add("hdop");
        ignorableFieldNames.add("pcb");
        ignorableFieldNames.add("trackerProf");
        ignorableFieldNames.add("modeHome");
        ignorableFieldNames.add("deepSleep");
        ignorableFieldNames.add("dut1");
        ignorableFieldNames.add("dut2");
        ignorableFieldNames.add("dut3");
        ignorableFieldNames.add("dut4");
        ignorableFieldNames.add("totalDut");
        ignorableFieldNames.add("canSpeed");
        ignorableFieldNames.add("canDist");
        ignorableFieldNames.add("canDistServ");
        ignorableFieldNames.add("canFc");
        ignorableFieldNames.add("canFlPer");
        ignorableFieldNames.add("canFlLit");
        ignorableFieldNames.add("exactFc");
        ignorableFieldNames.add("engineSpeed");
        ignorableFieldNames.add("accelatorPedal");
        ignorableFieldNames.add("workingTime");
        ignorableFieldNames.add("fc100km");
        ignorableFieldNames.add("fcHour");
        ignorableFieldNames.add("engineTemp");
        ignorableFieldNames.add("cabTemp");
        ignorableFieldNames.add("vin");
        ignorableFieldNames.add("staffName");
        ignorableFieldNames.add("staffNumber");
        ignorableFieldNames.add("staffPhoto");
        ignorableFieldNames.add("digital1");
        ignorableFieldNames.add("digital2");

        return ignorableFieldNames;
    }

    public void setGPSTrackPoint(GPSTrackPoint gpsTrackPoint) {
        if (gpsTrackPoint != null) {
            if (this.timestamp == null) {
                this.timestamp = gpsTrackPoint.getDate().getTime();
            }

            if (this.tpRegDate == null) {
                this.tpRegDate = gpsTrackPoint.getRegDate().getTime();
            }

            this.latitude = gpsTrackPoint.getLatitude();                        //	широта
            this.longitude = gpsTrackPoint.getLongitude();                       //	долгота
            this.altitude = gpsTrackPoint.getAltitude();                        //	высота (м)
            this.angle = gpsTrackPoint.getAngle();                          //	угол (гр)
            this.speedTrack = gpsTrackPoint.getSpeed();                     //	скорость трека (км/ч)
            this.speedIo = gpsTrackPoint.getIoData().getSpeedometer();                        //	скорость io (км/ч)
            this.odometr = gpsTrackPoint.getIoData().getOdometer();                        //	одометр (м)
            this.motionSensor = gpsTrackPoint.getMovement();                   //	датчик движения
            this.ignitionSensor = gpsTrackPoint.getEngineOn();                 //	датчик зажигания
            this.alarmButton = gpsTrackPoint.getSosStatus();                    //	тревожная кнопка
            this.digitalInput1 = gpsTrackPoint.getIoData().getDigital1();                  //	цифровой вход 1
            this.digitalInput2 = gpsTrackPoint.getIoData().getDigital2();                  //	цифровой вход 2
            this.digitalInput3 = gpsTrackPoint.getIoData().getDigital3();                  //	цифровой вход 3
            this.digitalInput4 = gpsTrackPoint.getIoData().getDigital4();                  //	цифровой вход 4
            this.analogInput1 = gpsTrackPoint.getIoData().getAnalog1();                   //	аналоговый вход 1 (мВ)
            this.analogInput2 = gpsTrackPoint.getIoData().getAnalog4();                   //	аналоговый вход 2 (мВ)
            this.analogInput3 = gpsTrackPoint.getIoData().getAnalog3();                   //	аналоговый вход 3 (мВ)
            this.analogInput4 = gpsTrackPoint.getIoData().getAnalog4();                   //	аналоговый вход 4 (мВ)
            this.trackerBattery = gpsTrackPoint.getIoData().getBatteryVoltageDouble();                 //	батарея трекера (в)
            this.trackerChargingCurrent = gpsTrackPoint.getIoData().getBatteryCurrent();         //	ток заряда трекера (ма)
            this.externalPower = gpsTrackPoint.getIoData().getExternalPowerVoltageDouble();                  //	внешнее питание (в)
            this.gsmOperatorCode = gpsTrackPoint.getIoData().getCurrentOperatorCode();                //	код оператора gsm
            this.gsmSignalLevel = gpsTrackPoint.getIoData().getGsmSignalLevel();                 //	уровень сигнала gsm
            this.cellId = gpsTrackPoint.getIoData().getCellId();                         //	cell id
            this.lac = gpsTrackPoint.getIoData().getAreaCode();                            //	lac
            this.gnss = gpsTrackPoint.getIoData().getGnssStatus();                           //	gnss
            this.satelliteCount = gpsTrackPoint.getSatellites();                 //	количество спутников
            this.pdop = gpsTrackPoint.getIoData().getGpsPdop();                           //	pdop
            this.hdop = gpsTrackPoint.getIoData().getGpsHdop();                           //	hdop
            this.pcb = gpsTrackPoint.getIoData().getPcbTemperature() != null ? gpsTrackPoint.getIoData().getPcbTemperature() / 10 : null;                            //	pcb t°c
            this.trackerProfile = gpsTrackPoint.getIoData().getActualProfile();                 //	профиль трекера
            this.modeHomeRoaming = gpsTrackPoint.getIoData().getModeHomeRoaming();
            this.deepSleep = gpsTrackPoint.getIoData().getDeepSleep();                      //	deep sleep

            setBakDatas(gpsTrackPoint); // показания дут (л)

            this.canSpeed = gpsTrackPoint.getIoData().getSpeedVechicle();                       //	скорость can (км/ч)
            this.canDistance = gpsTrackPoint.getIoData().getDistanceTotal() != null ? gpsTrackPoint.getIoData().getDistanceTotal() / 1000 : null;                    //	пробег can (км)
            this.canDistanceTillService = gpsTrackPoint.getIoData().getDistanceService() != null ? gpsTrackPoint.getIoData().getDistanceService() / 1000 : null;         //	пробег до обслуживания can (км)
            this.canFuelConsumption = gpsTrackPoint.getIoData().getFuelCounterTotal() != null ? gpsTrackPoint.getIoData().getFuelCounterTotal() / 1000 : null;             //	расход топлива can (л)
            this.canFuelLevelPercentage = gpsTrackPoint.getIoData().getFuelLevel() != null ? gpsTrackPoint.getIoData().getFuelLevel() / 10 : null;         //	уровень топлива can (%)
            this.canFuelLevelLiter = gpsTrackPoint.getIoData().getFuelLevelLitr() != null ? gpsTrackPoint.getIoData().getFuelLevelLitr() : null;                 //	уровень топлива can (л)
            this.exactFuelConsumption = null;           //	точный расход топлива (л)
            this.engineSpeed = gpsTrackPoint.getIoData().getEngineRpm() != null ? gpsTrackPoint.getIoData().getEngineRpm() / 1000 : null;                    //	обороты двигателя (об/мин)
            this.accelatorPedal = gpsTrackPoint.getIoData().getEnginePedalAccelerator() != null ? gpsTrackPoint.getIoData().getEnginePedalAccelerator() / 10 : null;                 //	педаль акселератора (%)
            this.workingTime = gpsTrackPoint.getIoData().getEngineWorkHour();                    //	время работы (ч)
            this.feulConsumption100km = gpsTrackPoint.getIoData().getFuelEconomyDistPerLitr() != null ? gpsTrackPoint.getIoData().getFuelEconomyDistPerLitr() / 1000 : null;           //	относительный расход топлива (км/л)
            this.feulConsumptionHour = gpsTrackPoint.getIoData().getFuelEconomyLitrPerHour() != null ? gpsTrackPoint.getIoData().getFuelEconomyLitrPerHour() / 1000 : null;            //	относительный расход топлива (л/ч)
            this.engineTemperature = gpsTrackPoint.getIoData().getEngineCoolantTemperature() != null ? gpsTrackPoint.getIoData().getEngineCoolantTemperature() / 10 : null;              //	температура двигателя (t°c)
            this.cabTemperature = gpsTrackPoint.getIoData().getAirTemperature() != null ? gpsTrackPoint.getIoData().getAirTemperature() / 10 : null;                 //	температура кабины (t°c)
            this.sensorMap = gpsTrackPoint.getIoData().getSensorMap();

            // Set data related to Staff
            Staff staff = gpsTrackPoint.getStaff();
            if (staff != null) {
                this.staffName = staff.getSurName() + " " + staff.getName() + " " + staff.getMiddleName();

                // Set staff photo url
                this.staffPhoto = "";

                if (staff.getPhotoId() != null
                        && staff.getPhotoId() != 0
                        && staff.getPhotoFilename() != null
                        && !staff.getPhotoFilename().equals("")) {
                    this.staffPhoto = FileStorageService.generateFileName(staff.getPhotoId(), staff.getPhotoFilename());
                }

                // Set staff phone numbers
                String phoneNumber = "";

                if (staff.getPhoneLine() != null) {
                    phoneNumber += staff.getPhoneLine();
                }

                if (!phoneNumber.equals("")) {
                    phoneNumber += " <br> ";
                }

                if (staff.getPhoneMobile() != null) {
                    phoneNumber += staff.getPhoneMobile();
                }

                this.staffPhoneNumber = phoneNumber;
            }
        }
    }

    private void setBakDatas(GPSTrackPoint gpsTrackPoint) {
        this.indicationDut1 = gpsTrackPoint.getIoData().getBak1Litr();                 //	показания дут 1 (л)
        this.indicationDut2 = gpsTrackPoint.getIoData().getBak2Litr();                 //	показания дут 2 (л)
        this.indicationDut3 = gpsTrackPoint.getIoData().getBak3Litr();                 //	показания дут 3 (л)
        this.indicationDut4 = gpsTrackPoint.getIoData().getBak4Litr();                 //	показания дут 4 (л)
        this.totalIndicationDut = gpsTrackPoint.getIoData().getBakTotalLitr(); //	суммарно показания дут (л)
    }

    public void setMobjectBig(MobjectBig mobjectBig) {
        if (mobjectBig != null) {
            this.objectId = mobjectBig.getId();
            this.objectName = mobjectBig.getName();
            this.objectModel = mobjectBig.getType();
            this.objectPlatenumber = mobjectBig.getPlateNumber();
            this.objectLiftingCapacity = mobjectBig.getCapacity();
            this.objectAdditionalInfo = mobjectBig.getObjectAdditionalInfo();

            GpsUnitBig gpsUnitBig = mobjectBig.getGpsUnitBig();
            if (gpsUnitBig != null) {
                this.trackerType = gpsUnitBig.getTypeName();
                this.trackerSimNumber = gpsUnitBig.getPhone();
                this.imea = gpsUnitBig.getImei();
            }
        }
    }

    public void setPoiAndGeoFenceList(List<Poi> poiList, List<Geofence> geofenceList) {
        if (this.locatedZones == null) {
            this.locatedZones = new ArrayList<>();
        }

        if (poiList != null) {
            for (Poi poi : poiList) {
                if (poi != null) {
                    this.locatedZones.add(poi.getName());
                }
            }
        }

        if (geofenceList != null) {
            for (Geofence geofence : geofenceList) {
                if (geofence != null) {
                    this.locatedZones.add(geofence.getName());
                }
            }
        }
    }

    /**
     * Set to make sensorsData
     * @param sensorDisplayList
     */
    public void setSensorDisplayList(List<SensorDisplay> sensorDisplayList) {
        if (sensorDisplayList != null && !sensorDisplayList.isEmpty()) {
            Map<String, Object> map = new HashMap<>();
            for (SensorDisplay display : sensorDisplayList) {
                if (display.isMonitoring()) {
                    Map<SensorDataType, Object> sensor = sensorMap != null
                            ? sensorMap.getSensorByName(display.getName())
                            : null;

                    String key = display.getName().toUpperCase() + " " +
                            Translator.getName(display.getType(), LocaleContextHolder.getLocale());
                    String value = sensor != null
                            ? sensor.get(display.getType()) != null
                            ? sensor.get(display.getType()) + " " + display.getType().getUnit()
                            : ""
                            : "";
                    map.put(key, value);
                }
            }
            this.sensorsData = JsonObject.mapFrom(map).toString();
        }
    }
}
