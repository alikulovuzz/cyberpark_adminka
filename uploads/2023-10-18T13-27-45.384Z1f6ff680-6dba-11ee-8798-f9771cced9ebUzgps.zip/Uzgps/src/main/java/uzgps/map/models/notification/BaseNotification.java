package uzgps.map.models.notification;

import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreSensorNotification;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.MobjectNotifications;
import uz.netex.dbtables.NotificationUnit;
import uz.netex.dbtables.SensorNotification;
import uzgps.persistence.ContractSettings;

/**
 * Created by Gayratjon on 9/29/14.
 */

public class BaseNotification extends Notification {

    public BaseNotification() {
        super();
    }

    public BaseNotification(NotificationUnit notificationUnit, CoreMain coreMain, ContractSettings contractSettings) {
        super();

        if (notificationUnit != null) {
            MobjectBig mobjectBig = coreMain.getMobjectById(notificationUnit.getMobjectId());
            if (mobjectBig != null) {
                this.objectId = mobjectBig.getId();
                this.objectName = mobjectBig.getName();
                MobjectNotifications mobjectNotifications = coreMain.getMobjectNotificationByMobjectId(mobjectBig.getId());

                if (mobjectNotifications != null) {
                    if (notificationUnit.getEventType() == NotificationUnit.EVENT_TYPE_UVEDOMLENIYE) {
                        this.shouldPopup = mobjectNotifications.isPopUpWindow() && contractSettings.getTooltipsCommandView();

                        if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SOS_BUTTON) {
                            this.soundId = mobjectNotifications.getuSosSound();
                            this.color = mobjectNotifications.getuSosColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_ENGINE_ON
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_ENGINE_OFF) {
                            this.soundId = mobjectNotifications.getuEngineSound();
                            this.color = mobjectNotifications.getuEngineColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_EXTERNAL_POWER_ON
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_EXTERNAL_POWER_OFF) {
                            this.soundId = mobjectNotifications.getuExternalPowerSound();
                            this.color = mobjectNotifications.getuExternalPowerColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SPEED_MIN) {
                            this.soundId = mobjectNotifications.getuSpeedMinSound();
                            this.color = mobjectNotifications.getuSpeedMinColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SPEED_MAX) {
                            this.soundId = mobjectNotifications.getuSpeedMaxSound();
                            this.color = mobjectNotifications.getuSpeedMaxColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SENSOR_MIN
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SENSOR_MAX
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SENSOR_CHANGE
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SENSOR_ABSENT) {
                            SensorNotification sn = CoreSensorNotification.getInstance()
                                    .getById(notificationUnit.getSnId());
                            if (sn != null) {
                                this.soundId = sn.getNotificationSound();
                                this.color = sn.getNotificationColor();
                            }
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_ONLINE_ON
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_ONLINE_OFF) {
                            this.soundId = mobjectNotifications.getuOnlineSound();
                            this.color = mobjectNotifications.getuOnlineColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_STAFF_EDIT
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_STAFF_DELETE) {
                            this.shouldPopup = mobjectNotifications.isPopUpWindow() && mobjectNotifications.isuStaff() && contractSettings.getTooltipsCommandView();
                            this.soundId = mobjectNotifications.getuStaffSound();
                            this.color = mobjectNotifications.getuStaffColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_MOBJECT_EDIT
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_MOBJECT_DELETE) {
                            this.soundId = mobjectNotifications.getuSettingsSound();
                            this.color = mobjectNotifications.getuSettingsColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_POI) {
                            this.soundId = mobjectNotifications.getuPoiSound();
                            this.color = mobjectNotifications.getuPoiColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_ZOI) {
                            this.soundId = mobjectNotifications.getuZoiSound();
                            this.color = mobjectNotifications.getuZoiColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_AUDIO_CALL) {
                            this.soundId = mobjectNotifications.getuAudioCallSound();
                            this.color = mobjectNotifications.getuAudioCallColor();
                        } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_DOOR_OPENED
                                || notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_DOOR_CLOSED) {
                            this.soundId = mobjectNotifications.getuDoorOpenSound();
                            this.color = mobjectNotifications.getuDoorOpenColor();
                        }
                    } else if (notificationUnit.getEventType() == NotificationUnit.EVENT_TYPE_NARUSHENIYE) {
                        this.shouldPopup = mobjectNotifications.isnPopUpWindow() && contractSettings.getTooltipsEventView();
                        this.color = contractSettings.getTooltipsEventColor();
                    } else {
                        this.shouldPopup = false;
                    }

                }
            }

            this.setTime(notificationUnit.getValueTime().getTime());
            this.eventType = notificationUnit.getEventType();
            this.messageType = notificationUnit.getMessageType();
            this.setRegDate(notificationUnit.getRegDateLong());
            this.setTpTime(notificationUnit.getTpTime().getTime());
        }
    }

    @Override
    public int compareTo(Notification o) {
        if (o == null)
            return 1;
        if (o.getTime() == null)
            return 1;
        if (this.getTime() == null)
            return -1;

        long l = (o.getTime() - this.getTime());

        if (l > 0) return 1;
        else if (l == 0) return 0;

        return -1;
    }
}
