package uzgps.map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.locationtech.jts.geom.Coordinate;
import org.locationtech.jts.geom.Geometry;
import org.locationtech.jts.io.WKTReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.dbtables.Poi;
import uzgps.common.FileStorageService;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.map.models.POIJSON;
import uzgps.persistence.*;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.*;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

/**
 * Created by Gayratjon on 2/5/14.
 */

@Controller
public class POIController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_MAP_POI_IMPORT_DATA_POST = "/map/poi-import-data-post.htm";
    private final static String URL_MAP_POI_POST = "/map/poi-post.htm";
    private final static String URL_MAP_POI_POST_WITH_IMAGE = "/map/poi-post-image.htm";
    private final static String URL_MAP_POI_REMOVE = "/map/poi-remove.htm";
    private final static String URL_MAP_POI_LIST_JSON = "/map/poi-list-json.htm";
    private final static String URL_MAP_POI_DUPLICATE = "/map/poi-duplicate.htm";

    private final static String URL_MAP_POI_PANEL = "/map/poi-list.htm";
    private final static String VIEW_MAP_POI_PANEL = "map/ajax-poi-list";

    @Autowired
    POIService poiService;

    @Autowired
    SettingsService settingsService;

    @Autowired
    FileStorageService storageService;

    @Autowired
    private ObjectMapper jsonMapper;

    @Autowired
    private CoreMain coreMain;

    public void processMapPOIModel(ModelAndView modelAndView, HttpSession session)
            throws ServletException, IOException {

        List<POI> poiList = getPoiList(session);
        List<PoiGroup> groups = settingsService.getPoiGroupByContractId(MainController.getUserContractId(session));

        modelAndView.addObject("poiList", poiList);
        modelAndView.addObject("poiGroups", groups);

        Map<Long, List<POI>> groupedPoiList = new HashMap<>();

        if (poiList != null){
            for (POI poi : poiList) {
                if (groupedPoiList.containsKey(poi.getGroupId())) {
                    groupedPoiList.get(poi.getGroupId()).add(poi);
                } else {
                    List<POI> pois = new ArrayList<>();
                    pois.add(poi);
                    groupedPoiList.put(poi.getGroupId(), pois);
                }
            }
        }

        modelAndView.addObject("groupedPoiList", groupedPoiList);
    }

    @RequestMapping(value = URL_MAP_POI_LIST_JSON, method = RequestMethod.GET, produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getPOIListByContractId(HttpSession session) throws ServletException, IOException {

        List<POI> poiList = getPoiList(session);

        List<POIJSON> poiJsonList = new ArrayList<>();
        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);
        boolean isNameDisplayed = true;

        if (contractSettings != null) {
            isNameDisplayed = contractSettings.getShowNamePoi();
        }

        if (poiList != null) {
            for (POI poi : poiList) {
                POIJSON poiJson = new POIJSON(poi, isNameDisplayed);
                poiJsonList.add(poiJson);
            }
        }

        Set<String> ignorableFields = new HashSet<>();
        ignorableFields.add("isLimitOver");
        SimpleFilterProvider filterProvider = new SimpleFilterProvider();
        filterProvider.addFilter("POIJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));
        ObjectWriter writer = jsonMapper.writer(filterProvider);

        return writer.writeValueAsString(poiJsonList);
    }

    @RequestMapping(value = URL_MAP_POI_POST_WITH_IMAGE, method = RequestMethod.POST)
    @ResponseBody
    public void postPlaceWithImage(HttpSession session, HttpServletResponse response,
                                   @RequestParam(value = "file", required = false) MultipartFile file,
                                   @RequestParam(value = "poiId", required = false) Long poiId,
                                   @RequestParam(value = "groupId", required = false) Long groupId,
                                   @RequestParam(value = "placeName", required = false) String placeName,
                                   @RequestParam(value = "fontColor", required = false) String fontColor,
                                   @RequestParam(value = "fontSize", required = false) Integer fontSize,
                                   @RequestParam(value = "description", required = false) String description,
                                   @RequestParam(value = "latitude", required = false) Double latitude,
                                   @RequestParam(value = "longitude", required = false) Double longitude,
                                   @RequestParam(value = "radius", required = false) Float radius,
                                   @RequestParam(value = "isCircleDisplayed", required = false) Boolean isCircleDisplayed,
                                   @RequestParam(value = "circleColor", required = false) String circleColor,
                                   @RequestParam(value = "circleOpacity", required = false, defaultValue = "0.5") Float circleOpacity)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            if (file != null)
                logger.debug("Received file, name={}, size={}, content-type={}, contractId={}", file.getOriginalFilename(), file.getSize
                        (), file.getContentType(), MainController.getUserContractId(session));
            else
                logger.debug("Received file is null");

            logger.debug("Post place poiId={}, name={}, fontName={}, fontSize={}, latitude={}, longitude={}, radius={}, isCircleDisplayed={}, circleColor={}",
                    poiId, placeName, fontColor, fontSize, latitude, longitude, radius, isCircleDisplayed, circleColor);
        }

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        if (contractSettings != null) {
            Long poiCount = poiService.getPOICountByContractIdAndStatus(MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE);
            Long poiLimit = contractSettings.getContract().getActiveMaxPoiCount();

            if (logger.isDebugEnabled()) {
                logger.debug("POI count={}, and limit={}", poiCount, poiLimit);
            }

            POIJSON poiJson = null;
            Set<String> ignorableFields = new HashSet<>();

            if (poiCount + 1 <= poiLimit) {

                if (file != null && file.getSize() > 0) {
                    FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);

                    if (fileStorage.getId() != null) {
                        if (latitude != null && longitude != null) {
                            POI poi = new POI();
                            poi.setId(poiId);
                            poi.setContractId(MainController.getUserContractId(session));
                            poi.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                            poi.setName(placeName);
                            poi.setImage(fileStorage);
                            poi.setFontSize(fontSize);
                            poi.setFontColor(fontColor);
                            poi.setDescription(description);
                            poi.setLatitude(latitude);
                            poi.setLongitude(longitude);
                            poi.setRadius(50f);
                            poi.setCircleOpacity(circleOpacity);
                            poi.setGroupId(groupId);
                            poi.setGroup(settingsService.getPoiGroupById(groupId));
                            if (radius != null) {
                                poi.setRadius(radius);
                            }
                            poi.setUrl(fileStorage.getFileUrl());
                            poi.setIsCircleDisplayed(isCircleDisplayed);
                            poi.setRegDate(new Timestamp(System.currentTimeMillis()));
                            if (!poi.getIsCircleDisplayed()) poi.setCircleColor(null);
                            else poi.setCircleColor(circleColor);

                            if (poiId != null) {
                                POI poi1 = poiService.getPOIById(poiId);

                                if (poi1 != null) {
                                    // Remove image of POI if exists
                                    FileStorage fileStorage1 = poi1.getImage();
                                    if (fileStorage1 != null) {
                                        storageService.removeFileFromStorage(fileStorage1);
                                    }
                                }
                            }

                            poiService.savePOI(poi);

                            addUserPoiAccess(poi);

                            // Update poi in core
                            coreMain.coreUpdater.updatePoiByContract(MainController.getUserContractId(session));

                            if (logger.isDebugEnabled())
                                logger.debug("Stored a new place: {}", poi.toString());

                            boolean isNameDisplayed = contractSettings.getShowNamePoi();
                            poiJson = new POIJSON(poi, isNameDisplayed);
                            poiJson.setIsLimitOver(false);
                        }
                    }
                }
            } else {
                ignorableFields.add("id");
                ignorableFields.add("name");
                ignorableFields.add("fontColor");
                ignorableFields.add("fontSize");
                ignorableFields.add("description");
                ignorableFields.add("longitude");
                ignorableFields.add("latitude");
                ignorableFields.add("radius");
                ignorableFields.add("isCircleDisplayed");
                ignorableFields.add("isNameDisplayed");
                ignorableFields.add("circleColor");
                ignorableFields.add("url");
                ignorableFields.add("circleOpacity");

                poiJson = new POIJSON();
                poiJson.setIsLimitOver(true);
            }

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("POIJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            try {
                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("place");
                byte[] data;
                data = writer.writeValueAsBytes(poiJson);
                response.setContentType("application/json");
                response.setContentLength(data.length);
                ServletOutputStream outStream;
                outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
            } catch (IOException e) {
                logger.error("Error: ", e);
            }
        }
    }

    /**
     * Save imported geometries to DB
     */
    @RequestMapping(value = URL_MAP_POI_IMPORT_DATA_POST, method = RequestMethod.POST)
    public void postPoiImportData(HttpSession session, HttpServletResponse response,
                                  @RequestBody List<PoiModel> poiModelList) throws IOException {

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        if (contractSettings != null) {
            List<POIJSON> poiJSONList = new ArrayList<>();

            POIJSON poiJson;
            Long contractId = MainController.getUserContractId(session);
            Boolean showPoiName = contractSettings.getShowNamePoi();
            Set<String> ignorableFields = new HashSet<>();

            Long poiCount = poiService.getPOICountByContractIdAndStatus(contractId, UZGPS_CONST.STATUS_ACTIVE);
            Long poiLimit = contractSettings.getContract().getActiveMaxPoiCount();

            if (poiModelList != null) {
                for (PoiModel poiModel : poiModelList) {

                    if (poiModel.getType().equals("Point")) {
                        updateCoordinates(poiModel);
                        poiJson = addNewPoi(ignorableFields, contractId, poiCount, poiLimit,
                                poiModel.getLongitude(), poiModel.getLatitude(), poiModel.getName(),
                                poiModel.getGroupId(),
                                poiModel.getDescription(), poiModel.getCircleDisplayed(), showPoiName,
                                poiModel.getFontSize(), poiModel.getFontColor(),
                                poiModel.getCircleColor(), poiModel.getCircleOpacity(), poiModel.getRadius());

                        poiJSONList.add(poiJson);
                    }
                }
            }

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("POIJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            try {
                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("place");
                byte[] data;
                data = writer.writeValueAsBytes(poiJSONList);
                response.setContentType("application/json");
                response.setContentLength(data.length);
                ServletOutputStream outStream;
                outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
            } catch (IOException e) {
                logger.error("Error: ", e);
            }
        }
    }

    @RequestMapping(value = URL_MAP_POI_POST, method = RequestMethod.POST)
    @ResponseBody
    public void postPlace(HttpSession session, HttpServletResponse response,
                          @RequestParam(value = "poiId", required = false) Long poiId,
                          @RequestParam(value = "groupId", required = false) Long groupId,
                          @RequestParam(value = "file-name", required = false) String fileName,
                          @RequestParam(value = "placeName", required = false) String name,
                          @RequestParam(value = "fontColor", required = false) String fontColor,
                          @RequestParam(value = "fontSize", required = false) Integer fontSize,
                          @RequestParam(value = "description", required = false) String description,
                          @RequestParam(value = "latitude", required = false) Double latitude,
                          @RequestParam(value = "longitude", required = false) Double longitude,
                          @RequestParam(value = "radius", required = false) Float radius,
                          @RequestParam(value = "isCircleDisplayed", required = false) Boolean isCircleDisplayed,
                          @RequestParam(value = "circleColor", required = false) String circleColor,
                          @RequestParam(value = "circleOpacity", required = false, defaultValue = "0.5") Float circleOpacity)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("Post place without image poiId={}, fileName={} name={}, fontName={}, fontSize={}, latitude={}, longitude={}, radius={}, isCircleDisplayed={}, circleColor={}",
                    poiId, fileName, name, fontColor, fontSize, latitude, longitude, radius, isCircleDisplayed, circleColor);
        }

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        if (contractSettings != null) {
            POIJSON poiJson = null;
            Long contractId = MainController.getUserContractId(session);
            Boolean showPoiName = contractSettings.getShowNamePoi();
            Set<String> ignorableFields = new HashSet<>();

            if (poiId == null) {
                Long poiCount = poiService.getPOICountByContractIdAndStatus(contractId, UZGPS_CONST.STATUS_ACTIVE);
                Long poiLimit = contractSettings.getContract().getActiveMaxPoiCount();

                poiJson = addNewPoi(ignorableFields, contractId, poiCount, poiLimit,
                        longitude, latitude, name, groupId, description, isCircleDisplayed,
                        showPoiName, fontSize, fontColor, circleColor, circleOpacity, radius);
            } else {
                if (latitude != null && longitude != null) {
                    POI poi = poiService.getPOIById(poiId);
                    poi.setImage(poi.getImage());
                    poi.setModDate(new Timestamp(System.currentTimeMillis()));
                    poi.setName(name);
                    poi.setFontSize(fontSize);
                    poi.setFontColor(fontColor);
                    poi.setDescription(description);
                    poi.setLatitude(latitude);
                    poi.setLongitude(longitude);
                    poi.setCircleOpacity(circleOpacity);
                    poi.setRadius(50f);
                    poi.setGroupId(groupId);
                    poi.setGroup(settingsService.getPoiGroupById(groupId));
                    if (radius != null) {
                        poi.setRadius(radius);
                    }
                    poi.setUrl(null);
                    poi.setIsCircleDisplayed(isCircleDisplayed);
                    if (!poi.getIsCircleDisplayed()) poi.setCircleColor(null);
                    else poi.setCircleColor(circleColor);

                    try {
                        // Remove image of POI if exists
                        FileStorage fileStorage = poi.getImage();
                        if (fileStorage != null && fileName.length() == 0) {
                            storageService.removeFileFromStorage(fileStorage);
                            poi.setImage(null);
                        }
                    } catch (Exception e) {
                        logger.error("error when remove file: " + e.getMessage());
                        poi.setImage(null);
                    }

                    poiService.savePOI(poi);

                    addUserPoiAccess(poi);

                    // Update poi in core
                    coreMain.coreUpdater.updatePoiByContract(contractId);

                    if (logger.isDebugEnabled())
                        logger.debug("Updated a place: {}", poi.toString());

                    boolean isNameDisplayed = showPoiName;
                    poiJson = new POIJSON(poi, isNameDisplayed);
                    poiJson.setIsLimitOver(false);
                }
            }

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("POIJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            try {
                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("place");
                byte[] data;
                data = writer.writeValueAsBytes(poiJson);
                response.setContentType("application/json");
                response.setContentLength(data.length);
                ServletOutputStream outStream;
                outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
            } catch (IOException e) {
                logger.error("Error: ", e);
            }
        }
    }

    @RequestMapping(value = URL_MAP_POI_REMOVE, method = RequestMethod.POST)
    public void removePlace(HttpServletResponse response, HttpSession session,
                            @RequestParam(value = "poi-id", required = false) Long poiId)
            throws ServletException, IOException {

        if (logger.isDebugEnabled())
            logger.debug("removePlace: contractId={}, poi-id={}", MainController.getUserContractId(session), poiId);

        ResponseEntity responseEntity;

        if (poiId != null) {
            POI poi = poiService.getPOIById(poiId);
            poi.setStatus(UZGPS_CONST.STATUS_DELETE);
            poi.setExpDate(new Timestamp(System.currentTimeMillis()));
            poiService.savePOI(poi);

            List<MObjectPoI> mObjectPoIList = settingsService.getMObjectPoIListByPoIId(poiId);
            if (mObjectPoIList != null) {
                for (MObjectPoI mObjectPoI : mObjectPoIList) {
                    if (mObjectPoI != null) {
                        mObjectPoI.setStatus(UZGPS_CONST.STATUS_DELETE);
                        mObjectPoI.setExpDate(new Timestamp(System.currentTimeMillis()));
                        settingsService.saveMObjectPoI(mObjectPoI);
                    }
                }
            }

            // Update poi in core
            coreMain.coreUpdater.updatePoiByContract(MainController.getUserContractId(session));
            coreMain.coreUpdater.updateUserPoiAccessByPoiId(poiId);

            responseEntity = new ResponseEntity(HttpStatus.OK);
        } else {
            responseEntity = new ResponseEntity(HttpStatus.FAILED_DEPENDENCY);
        }

        ObjectWriter writer = jsonMapper.writer();
        byte[] data;
        data = writer.writeValueAsBytes(responseEntity);
        response.setContentType("application/json");
        response.setContentLength(data.length);
        ServletOutputStream outStream;
        outStream = response.getOutputStream();
        outStream.write(data);
        outStream.close();
    }

    @RequestMapping(value = URL_MAP_POI_DUPLICATE, method = RequestMethod.POST)
    @ResponseBody
    public void poiDuplicate(HttpSession session, HttpServletResponse response,
                             @RequestParam(value = "poi-id") Long poiId)
            throws ServletException, IOException {

        ContractSettings contractSettings = (ContractSettings) session.getAttribute(MainController.SESSION_CONTRACT_SETTINGS);

        POIJSON poiJson = null;
        Set<String> ignorableFields = new HashSet<>();

        if (poiId != null) {
            POI poi = poiService.getPOIById(poiId);
            Long poiNameCount = poiService.getNameByContractId(MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE, poi
                    .getName());

            Long poiCount = poiService.getPOICountByContractIdAndStatus(MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE);
            Long poiLimit = contractSettings.getContract().getActiveMaxPoiCount();

            if (poiCount + 1 <= poiLimit) {
                if (poi.getContractId().equals(MainController.getUserContractId(session))) {

                    POI nPoi = new POI();
                    nPoi.setName(poi.getName() + "(" + poiNameCount + ")");
                    nPoi.setContractId(poi.getContractId());
                    nPoi.setFontSize(poi.getFontSize());
                    nPoi.setFontColor(poi.getFontColor());
                    nPoi.setLatitude(poi.getLatitude());
                    nPoi.setLongitude(poi.getLongitude());
                    nPoi.setDescription(poi.getDescription());
                    nPoi.setRadius(poi.getRadius());
                    nPoi.setUrl(poi.getUrl());
                    nPoi.setIsCircleDisplayed(poi.getIsCircleDisplayed());
                    nPoi.setStatus(poi.getStatus());
                    nPoi.setRegDate(poi.getRegDate());
                    nPoi.setCircleColor(poi.getCircleColor());
                    nPoi.setCircleOpacity(poi.getCircleOpacity());
                    poiService.savePOI(nPoi);

                    coreMain.coreUpdater.updatePoiByContract(MainController.getUserContractId(session));
                    boolean isNameDisplayed = contractSettings.getShowNamePoi();
                    poiJson = new POIJSON(nPoi, isNameDisplayed);
                    poiJson.setIsLimitOver(false);

                }
            }

            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("POIJSONFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            try {
                ObjectWriter writer = jsonMapper.writer(filterProvider).withRootName("place");
                byte[] data;
                data = writer.writeValueAsBytes(poiJson);
                response.setContentType("application/json");
                response.setContentLength(data.length);
                ServletOutputStream outStream;
                outStream = response.getOutputStream();
                outStream.write(data);
                outStream.close();
            } catch (IOException e) {
                logger.error("Error: ", e);
            }

        }
    }

    @RequestMapping(value = URL_MAP_POI_PANEL)
    public ModelAndView processMapPoIPanel(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String
                                                          appStatus,
                                                  HttpSession session) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_MAP_POI_PANEL);
        processMapPOIModel(modelAndView, session);

        return modelAndView;
    }

    public List<POI> getPoiList(HttpSession session) {
        List<POI> poiList = null;

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            List<Poi> poiListFromCore = coreMain.getPoiListByUser(MainController.getInterfaceUserId());

            poiList = convertPoiToPOIType(poiListFromCore);
        } else {
            if (MainController.getIsShowObjectsOfAllContracts(session) == true) {
                List<POI> tempPoiList;

                List<Contract> contracts = MainController.getUserContracts(session);
                for (Contract contract : contracts) {
                    tempPoiList = poiService.getPOIListByContractIdAndStatus(contract.getId(), UZGPS_CONST.STATUS_ACTIVE);

                    if (tempPoiList != null && tempPoiList.size() > 0) {
                        if (poiList == null) poiList = new ArrayList<>();
                        {
                            poiList.addAll(tempPoiList);
                        }
                    }
                }
            } else {
                poiList = poiService.getPOIListByContractIdAndStatus(MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE);
            }
        }

        return poiList;
    }

    private POIJSON addNewPoi(Set<String> ignorableFields,
                              Long contractId,
                              Long poiCount,
                              Long poiLimit,
                              Double longitude,
                              Double latitude,
                              String name,
                              Long groupId,
                              String description,
                              Boolean isCircleDisplayed,
                              Boolean showPoiName,
                              Integer fontSize,
                              String fontColor,
                              String circleColor,
                              Float circleOpacity,
                              Float radius) {

        POIJSON poiJson = new POIJSON();

        try {
            if (logger.isDebugEnabled()) {
                logger.debug("POI count={}, and limit={}", poiCount, poiLimit);
            }

            if (poiCount + 1 <= poiLimit) {
                if (latitude != null && longitude != null) {
                    POI poi = new POI();
                    poi.setImage(null);
                    poi.setContractId(contractId);
                    poi.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                    poi.setRegDate(new Timestamp(System.currentTimeMillis()));
                    poi.setName(name);
                    poi.setFontSize(fontSize);
                    poi.setFontColor(fontColor);
                    poi.setDescription(description);
                    poi.setLatitude(latitude);
                    poi.setLongitude(longitude);
                    poi.setRadius(50f);

                    if (groupId != null) {
                        poi.setGroupId(groupId);
                        poi.setGroup(settingsService.getPoiGroupById(groupId));
                    } else {
                        poi.setGroupId(0L);
                        poi.setGroup(settingsService.getPoiGroupById(0L));
                    }

                    poi.setCircleOpacity(circleOpacity);
                    if (radius != null) {
                        poi.setRadius(radius);
                    }
                    poi.setUrl(null);
                    poi.setIsCircleDisplayed(isCircleDisplayed);
                    if (!poi.getIsCircleDisplayed()) poi.setCircleColor(null);
                    else poi.setCircleColor(circleColor);
                    poiService.savePOI(poi);

                    addUserPoiAccess(poi);

                    // Update poi in core
                    coreMain.coreUpdater.updatePoiByContract(contractId);

                    if (logger.isDebugEnabled())
                        logger.debug("Stored a new place: {}", poi.toString());

                    boolean isNameDisplayed = showPoiName;
                    poiJson = new POIJSON(poi, isNameDisplayed);
                    poiJson.setIsLimitOver(false);
                }
            } else {
                ignorableFields.add("id");
                ignorableFields.add("name");
                ignorableFields.add("fontColor");
                ignorableFields.add("fontSize");
                ignorableFields.add("description");
                ignorableFields.add("longitude");
                ignorableFields.add("latitude");
                ignorableFields.add("radius");
                ignorableFields.add("isCircleDisplayed");
                ignorableFields.add("isNameDisplayed");
                ignorableFields.add("circleColor");
                ignorableFields.add("url");
                ignorableFields.add("circleOpacity");

                poiJson = new POIJSON();
                poiJson.setIsLimitOver(true);
            }

            return poiJson;
        } catch (Exception ex) {
            logger.error("Error: ", ex);
        }
        return poiJson;
    }

    /**
     * Set coordinates from wkt string
     *
     * @param poiModel
     */
    private void updateCoordinates(PoiModel poiModel) {
        Geometry geometry = null;
        try {
            WKTReader wktReader = new WKTReader();
            geometry = wktReader.read(poiModel.getGeometryWKT());

            if (geometry != null && geometry.isValid()) {
                Coordinate[] coordinates = geometry.getCoordinates();

                if (poiModel.getLongitude() == null) {
                    poiModel.setLongitude(coordinates[0].x);
                }

                if (poiModel.getLatitude() == null) {
                    poiModel.setLatitude(coordinates[0].y);
                }
            }
        } catch (org.locationtech.jts.io.ParseException e) {
            logger.error("Error in updateCoordinates", e);
        }

    }

    /**
     * Add user poi access when new poi added
     *
     * @param poi
     */
    private void addUserPoiAccess(POI poi) {
        try {
            UserPoiAccess userPoiAccess = settingsService.getUserPoiAccessByUserIdAndPoiId(MainController.getUserId(), poi.getId());

            if (userPoiAccess == null) {
                // Core Add new User poi Access
                userPoiAccess = new UserPoiAccess();

                userPoiAccess.setPoi(poi);
                userPoiAccess.setUserId(MainController.getUserId());
                userPoiAccess.setPermission(15);
                userPoiAccess.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                userPoiAccess.setRegDate(new Timestamp(System.currentTimeMillis()));

                settingsService.saveUserPoiAccess(userPoiAccess);
            }

            coreMain.coreUpdater.updateUserPoiAccessById(userPoiAccess.getId());
        } catch (Exception e) {
            logger.error("Error in addUserPoiAccess: " + e.getMessage());
        }
    }

    private List<POI> convertPoiToPOIType(List<Poi> poiListFromCore) {
        List<POI> poiList = new ArrayList<>();

        try {
            for (Poi poiFromCore : poiListFromCore) {
                POI poi = new POI();

                poi.setId(poiFromCore.getId());
                poi.setDescription(poiFromCore.getDescription());
                poi.setLatitude(poiFromCore.getLatitude());
                poi.setLongitude(poiFromCore.getLongitude());
                poi.setName(poiFromCore.getName());
                poi.setRadius(poiFromCore.getRadius().floatValue());
                poi.setContractId(poiFromCore.getContractId());
                poi.setFontColor(poiFromCore.getFontColor());
                poi.setFontSize(poiFromCore.getFontSize());
                poi.setImageId(poiFromCore.getImageId());

                if (poiFromCore.getImageId() != null && poiFromCore.getImageId() > 0) {
                    poi.setImage(storageService.getFileStorage(poiFromCore.getImageId()));
                } else {
                    poi.setImage(null);
                }

                poi.setIsCircleDisplayed(poiFromCore.getIsCircleDisplayed());
                poi.setCircleColor(poiFromCore.getCircleColor());
                poi.setCircleOpacity(poiFromCore.getCircleOpacity().floatValue());

                poi.setUserPermission(poiFromCore.getUserPermission());

//                POI tempPOI = poiService.getPOIById(poiFromCore.getId());

//                System.out.println(tempPOI);
//                System.out.println(poi);

                poiList.add(poi);
            }
        } catch (Exception e) {
            logger.error("Error in convertPoiToPOIType", e);
        }

        return poiList;
    }

}
