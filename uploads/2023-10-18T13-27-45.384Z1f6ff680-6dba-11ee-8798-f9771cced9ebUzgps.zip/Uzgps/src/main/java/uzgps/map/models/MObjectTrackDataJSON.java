package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import uzgps.map.models.notification.MessageNotification;

import java.util.List;

/**
 * Created by Gayratjon on 5/3/14.
 */

@JsonFilter("MObjectTrackDataFilter")
public class MObjectTrackDataJSON {
    private MonitorData monitorData = null;

    @JsonIgnore
    private PopupData popupData = null;
    @JsonProperty("popupData")

    private TrackPopupData trackPopupData = null;
    private MessageData messageData = null;
    private MessageNotification messageNot = null;
    List<Point> pointList = null;

    public MonitorData getMonitorData() {
        return monitorData;
    }

    public void setMonitorData(MonitorData monitorData) {
        this.monitorData = monitorData;
    }

    public PopupData getPopupData() {
        return popupData;
    }

    public void setPopupData(PopupData popupData) {
        this.popupData = popupData;
    }

    public MessageData getMessageData() {
        return messageData;
    }

    public void setMessageData(MessageData messageData) {
        this.messageData = messageData;
    }

    public MessageNotification getMessageNot() {
        return messageNot;
    }

    public void setMessageNot(MessageNotification messageNot) {
        this.messageNot = messageNot;
    }

    public List<Point> getPointList() {
        return pointList;
    }

    public void setPointList(List<Point> pointList) {
        this.pointList = pointList;
    }

    public TrackPopupData getTrackPopupData() {
        return trackPopupData;
    }

    public void setTrackPopupData(TrackPopupData trackPopupData) {
        this.trackPopupData = trackPopupData;
    }
}
