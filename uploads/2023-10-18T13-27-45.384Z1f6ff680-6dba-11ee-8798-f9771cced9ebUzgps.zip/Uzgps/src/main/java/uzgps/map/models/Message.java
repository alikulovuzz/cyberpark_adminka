package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.uzgps.core.models.sensor.SensorMap;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Gayratjon on 5/6/14.
 */
public class Message {
    private byte movement;
    private byte engineOn;
    private byte online;
    private byte satellites;
    private byte dat;
    private int speed;
    private double latitude;
    private double longitude;
    private double altitude;
    private long date;
    private long regDate;
    @JsonIgnore
    private String regDateFormatDate;
    @JsonIgnore
    private String regDateFormatTime;
    @JsonIgnore
    private String formattedDate;
    @JsonIgnore
    private String dateFormatDate;
    @JsonIgnore
    private String dateFormatTime;
    @JsonIgnore
    private short angle;
    @JsonIgnore
    private String json;

    @JsonIgnore
    private Byte digital1; // 1
    @JsonIgnore
    private Byte digital2; // 2
    @JsonIgnore
    private Byte digital3; // 3
    @JsonIgnore
    private Byte digital4; //4
    @JsonIgnore
    private Short analog1; // 9
    @JsonIgnore
    private Short analog2;// 10
    @JsonIgnore
    private Short analog3; //11
    @JsonIgnore
    private Short analog4; //19
    @JsonIgnore
    private Byte gsmSignalLevel; // 21
    @JsonIgnore
    private Byte actualProfile; // 22
    @JsonIgnore
    private Short speedometer; // 24
    @JsonIgnore
    private Short externalPowerVoltage; // 66
    @JsonIgnore
    private Short internalBatteryVoltage; // 67
    @JsonIgnore
    private Double externalPowerVoltageDouble; // 66
    @JsonIgnore
    private Double internalBatteryVoltageDouble; // 67
    @JsonIgnore
    private Integer batteryPercent; // Уровень заряда батареи %
    @JsonIgnore
    private Short internalBatteryCurrent; // 68
    @JsonIgnore
    private Integer pcbTemperature; // 70
    @JsonIgnore
    private Byte gnssStatus; // 71
    @JsonIgnore
    private Short gpsPdop; // 181
    @JsonIgnore
    private Short gpsHdop; // 182
    @JsonIgnore
    private Integer odometer; // 199
    @JsonIgnore
    private Byte deepSleep; // 200
    @JsonIgnore
    private Short cellId; // 205
    @JsonIgnore
    private Short areaCode; // 206
    @JsonIgnore
    private Byte movementValue; // 240
    @JsonIgnore
    private Integer currentOperatorCode; // 241
    @JsonIgnore
    private Integer bak1; // Fuel bak1
    @JsonIgnore
    private Integer bak2; // Fuel bak2
    @JsonIgnore
    private Integer bak3; // Fuel bak3
    @JsonIgnore
    private Integer bak4; // Fuel bak4
    @JsonIgnore
    private Integer bak1Enabled; // Fuel bak1Enabled
    @JsonIgnore
    private Integer bak2Enabled; // Fuel bak2Enabled
    @JsonIgnore
    private Integer bak3Enabled; // Fuel bak3Enabled
    @JsonIgnore
    private Integer bak4Enabled; // Fuel bak4Enabled
    @JsonIgnore
    private Integer bakTotal; // Fuel bakTotal
    @JsonIgnore
    private Short fuelLevelMeter1; // 201
    @JsonIgnore
    private Byte fuelTemperature1; // 202
    @JsonIgnore
    private Short fuelLevelMeter2; // 203
    @JsonIgnore
    private Byte fuelTemperature2; // 204

    private Integer lls1Code; // LLS 1 Code
    private Integer lls2Code; // LLS 2 Code
    private Integer lls3Temperature; // LLS 3 Temperature
    private Integer lls3Level; // LLS 3 Level
    private Integer lls3Code; // LLS 3 Code
    private Integer lls4Temperature; // LLS 4 Temperature
    private Integer lls4Level; // LLS 4 Level
    private Integer lls4Code; // LLS 4 Code
    private Integer lls5Temperature; // LLS 5 Temperature
    private Integer lls5Level; // LLS 5 Level
    private Integer lls5Code; // LLS 5 Code
    private Integer lls6Temperature; // LLS 6 Temperature
    private Integer lls6Level; // LLS 6 Level
    private Integer lls6Code; // LLS 6 Code
    private Integer lls7Temperature; // LLS 7 Temperature
    private Integer lls7Level; // LLS 7 Level
    private Integer lls7Code; // LLS 7 Code
    private Integer lls8Temperature; // LLS 8 Temperature
    private Integer lls8Level; // LLS 8 Level
    private Integer lls8Code; // LLS 8 Code

    @JsonIgnore
    private Integer speedVechicle;
    @JsonIgnore
    private Integer engineRpm;
    @JsonIgnore
    private Integer enginePedalAccelerator;
    @JsonIgnore
    private Long engineWorkHour;
    @JsonIgnore
    private Long distanceTotal;
    @JsonIgnore
    private Integer distanceService;
    @JsonIgnore
    private Long fuelCounterTotal;
    @JsonIgnore
    private Integer fuelLevel;
    @JsonIgnore
    private Integer fuelEconomyDistPerLitr;
    @JsonIgnore
    private Integer fuelEconomyLitrPerHour;
    @JsonIgnore
    private Integer engineCoolantTemperature;
    @JsonIgnore
    private String vinNumber;
    @JsonIgnore
    private Long fuelCounterTotalHigh;
    @JsonIgnore
    private Integer airTemperature;
    @JsonIgnore
    private String mObjectname;
    @JsonProperty
    private Integer sosButtonPressed;
    @JsonIgnore
    private Integer modeHomeRoaming;
    @JsonIgnore
    private Integer fuelLevelLitr;

    @JsonIgnore
    private Integer engineLoadPercent; // OBD 5* = 10 * % - Engine Percent Load At Current Speed :: 0-125 %
    @JsonIgnore
    private Integer engineThrottlePosition; // 10 * % -	This is the reading from the potentiometer at the manifold - it is not a reading from the accelerator pedal :: 0-100 %
    @JsonIgnore
    private Integer gpsTimeout; // 0-not expired, 1-expired
    @JsonIgnore
    private Integer gpsVdop; // 10 * вероятность - GPS VDOP  :: 10*вероятность
    @JsonIgnore
    private Long iButtonId; // 78
    @JsonIgnore
    private Byte immobilizer; // 251
    @JsonIgnore
    private Byte overSpeeding; // 255 - km/h - Over Speeding (превишение скорости) :: км/ч
    @JsonIgnore
    private Long rfidId; // 207 - ID RFID :: для RFID - в HEX, для RFID M7 - в DEC
    @JsonIgnore
    private Integer timeLive; // second	- Live Time :: Device work time after last reboot [sec]
    @JsonIgnore
    private Integer timeTTFF; // second	- Time To First Fix (TTFF) is a measure of the time required for a GPS receiver to acquire satellite signals and navigation data, and calculate a position solution (called a fix). [sec]
    @JsonIgnore
    private Byte trip; // 250 - 0-1 -	Trip :: 1 - trip started 0 - trip finished (stop)
    @JsonIgnore
    private Integer priority; //    - Track Priority ::  0-Low 1-High 2-Panic 3-Security
    @JsonIgnore
    private Integer dtcCount; //    - Number of DTCs ::  0 - 255
    @JsonIgnore
    private Integer timingAdvance; // 10 * C     - Timing advance ::  -64 - 63.5
    @JsonIgnore
    private Integer timeWithMILon; // seconds    - Time run with MIL on :: 0 - 65535
    @JsonIgnore
    private Integer timeCodesCleared; // seconds - Time since trouble codes cleared :: 0 - 65535
    @JsonIgnore
    private Integer engineOilTemperature; // 10 * C - Engine oil temperature :: -40 - 210 C
    @JsonIgnore
    private Integer fuelInjectionTiming; // 1000 * o - Fuel injection timing :: -210.00 - 301.992
    @JsonIgnore
    private Integer timeEngineStart; // seconds - Fuel injection timing :: 0 - 65,535
    @JsonIgnore
    private Integer shortTermFuelTrim; // 10 * % - Short term fuel trim 1 :: -100 ~ +99 %
    @JsonIgnore
    private Integer pressureIntakeManifoldAbsolute; // 1000 * kPa - Intake Manifold Absolute Pressure
    @JsonIgnore
    private Integer temperatureIntakeAir; // 10 * C - Intake air temperature
    @JsonIgnore
    private Integer airFlowRate; // 100 * g/sec - MAF Air Flow Rate
    @JsonIgnore
    private Integer pressureRelativeFuelRail; // Pa - Relative fuel rail pressure
    @JsonIgnore
    private Integer pressureDirectFuelRail; // Pa - Direct fuel rail pressure
    @JsonIgnore
    private Integer commandedEGR; // 10 * % - Commanded EGR
    @JsonIgnore
    private Integer errorEGR; // 10 * % - EGR error
    @JsonIgnore
    private Integer pressureBarometric; // Pa - Barometric pressure
    @JsonIgnore
    private Integer voltageControlModule; // mV - Control module voltage
    @JsonIgnore
    private Integer loadAbsoluteValue; // 10 * % - Absolute load value
    @JsonIgnore
    private Integer pressureAbsoluteFuelRail; // 10 * % - Absolute fuel rail pressure
    @JsonIgnore
    private Integer batteryRemainingLife; // 10 * % - Hybrid battery pack remaining life
    @JsonIgnore
    private Integer distanceAfterCodesClear; // OBD 11*  = metr // 31 Дистанция, пройденная со времени очистки кодов нейсправностей (Distance traveled since codes cleared)
    @JsonIgnore
    private Integer distanceWithMilOn; // OBD 10* = metr - 21 Дистанция, пройденная с зажженной лампой «проверь двигатель» (Distance traveled with malfunction indicator lamp (MIL) on)
    private SensorMap sensorMap;

    public Message(GPSTrackPoint gpsTrackPoint) {
        this.movement = -1;
        this.engineOn = -1;
        this.online = -1;
        this.satellites = -1;
        this.dat = -1;
        this.latitude = 0;
        this.longitude = 0;
        this.altitude = 0;
        this.date = 0;
        this.speed = 0;
        this.regDate = 0;

        if (gpsTrackPoint != null) {
            this.movement = gpsTrackPoint.getMovement();
            this.engineOn = gpsTrackPoint.getEngineOn();
            this.online = gpsTrackPoint.getOnline();
            this.satellites = gpsTrackPoint.getSatellites();
            this.dat = gpsTrackPoint.getDat();
            this.speed = gpsTrackPoint.getSpeed();
            this.latitude = gpsTrackPoint.getLatitude();
            this.longitude = gpsTrackPoint.getLongitude();
            this.altitude = gpsTrackPoint.getAltitude();
            this.date = gpsTrackPoint.getTimestamp();
            this.regDate = gpsTrackPoint.getRegDateLong();
            this.angle = gpsTrackPoint.getAngle();
            Date date = new Date(this.date);
            Date regdate = new Date(this.regDate);

            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            DateFormat FormatDate = new SimpleDateFormat("dd.MM.yyyy");
            DateFormat FormatTime = new SimpleDateFormat("HH:mm:ss");

            this.dateFormatDate = FormatDate.format(date);
            this.dateFormatTime = FormatTime.format(date);
            this.formattedDate = dateFormat.format(date);
            this.regDateFormatDate = FormatDate.format(regdate);
            this.regDateFormatTime = FormatTime.format(regdate);

            this.digital1 = gpsTrackPoint.getIoData().getDigital1();
            this.digital2 = gpsTrackPoint.getIoData().getDigital2();
            this.digital3 = gpsTrackPoint.getIoData().getDigital3();
            this.digital4 = gpsTrackPoint.getIoData().getDigital4();
            this.analog1 = gpsTrackPoint.getIoData().getAnalog1();
            this.analog2 = gpsTrackPoint.getIoData().getAnalog4();
            this.analog3 = gpsTrackPoint.getIoData().getAnalog3();
            this.analog4 = gpsTrackPoint.getIoData().getAnalog4();
            this.gsmSignalLevel = gpsTrackPoint.getIoData().getGsmSignalLevel();
            this.actualProfile = gpsTrackPoint.getIoData().getActualProfile();
            this.modeHomeRoaming = gpsTrackPoint.getIoData().getModeHomeRoaming();
            this.speedometer = gpsTrackPoint.getIoData().getSpeedometer();
            this.externalPowerVoltage = gpsTrackPoint.getIoData().getExternalPowerVoltage();
            this.internalBatteryVoltage = gpsTrackPoint.getIoData().getBatteryVoltage();
            this.externalPowerVoltageDouble = gpsTrackPoint.getIoData().getExternalPowerVoltageDouble();
            this.internalBatteryVoltageDouble = gpsTrackPoint.getIoData().getBatteryVoltageDouble();
            this.batteryPercent = gpsTrackPoint.getIoData().getBatteryPercent();
            this.internalBatteryCurrent = gpsTrackPoint.getIoData().getBatteryCurrent();
            this.pcbTemperature = gpsTrackPoint.getIoData().getPcbTemperature() != null ? gpsTrackPoint.getIoData().getPcbTemperature() / 10 : null;
            this.gnssStatus = gpsTrackPoint.getIoData().getGnssStatus();
            this.gpsPdop = gpsTrackPoint.getIoData().getGpsPdop();
            this.gpsHdop = gpsTrackPoint.getIoData().getGpsHdop();
            this.odometer = gpsTrackPoint.getIoData().getOdometer();
            this.deepSleep = gpsTrackPoint.getIoData().getDeepSleep();
            this.cellId = gpsTrackPoint.getIoData().getCellId();
            this.areaCode = gpsTrackPoint.getIoData().getAreaCode();
            this.movementValue = gpsTrackPoint.getIoData().getMovementValue();
            this.currentOperatorCode = gpsTrackPoint.getIoData().getCurrentOperatorCode();
            this.bak1 = gpsTrackPoint.getIoData().getBak1();
            this.bak2 = gpsTrackPoint.getIoData().getBak2();
            this.bak3 = gpsTrackPoint.getIoData().getBak3();
            this.bak4 = gpsTrackPoint.getIoData().getBak4();
            this.bak1Enabled = gpsTrackPoint.getIoData().getBak1Enabled();
            this.bak2Enabled = gpsTrackPoint.getIoData().getBak2Enabled();
            this.bak3Enabled = gpsTrackPoint.getIoData().getBak3Enabled();
            this.bak4Enabled = gpsTrackPoint.getIoData().getBak4Enabled();
            this.bakTotal = gpsTrackPoint.getIoData().getBakTotal();

            this.fuelLevelMeter1 = gpsTrackPoint.getIoData().getFuelLevelMeter1(); // 201
            this.fuelTemperature1 = gpsTrackPoint.getIoData().getFuelTemperature1(); // 202
            this.fuelLevelMeter2 = gpsTrackPoint.getIoData().getFuelLevelMeter2(); // 203
            this.fuelTemperature2 = gpsTrackPoint.getIoData().getFuelTemperature2(); // 204

            this.lls1Code = gpsTrackPoint.getIoData().getLls1Code(); // LLS 1 CODE
            this.lls2Code = gpsTrackPoint.getIoData().getLls2Code(); // LLS 2 CODE
            this.lls3Temperature = gpsTrackPoint.getIoData().getLls3Temperature(); // LLS 3 temp
            this.lls3Level = gpsTrackPoint.getIoData().getLls3Level(); // LLS 3 Level
            this.lls3Code = gpsTrackPoint.getIoData().getLls3Code(); // LLS 3 CODE
            this.lls4Temperature = gpsTrackPoint.getIoData().getLls4Temperature(); // LLS 4 temp
            this.lls4Level = gpsTrackPoint.getIoData().getLls4Level(); // LLS 4 Level
            this.lls4Code = gpsTrackPoint.getIoData().getLls4Code(); // LLS 4 CODE
            this.lls5Temperature = gpsTrackPoint.getIoData().getLls5Temperature(); // LLS 5 temp
            this.lls5Level = gpsTrackPoint.getIoData().getLls5Level(); // LLS 5 Level
            this.lls5Code = gpsTrackPoint.getIoData().getLls5Code(); // LLS 5 CODE
            this.lls6Temperature = gpsTrackPoint.getIoData().getLls6Temperature(); // LLS 6 temp
            this.lls6Level = gpsTrackPoint.getIoData().getLls6Level(); // LLS 6 Level
            this.lls6Code = gpsTrackPoint.getIoData().getLls6Code(); // LLS 6 CODE
            this.lls7Temperature = gpsTrackPoint.getIoData().getLls7Temperature(); // LLS 7 temp
            this.lls7Level = gpsTrackPoint.getIoData().getLls7Level(); // LLS 7 Level
            this.lls7Code = gpsTrackPoint.getIoData().getLls7Code(); // LLS 7 CODE
            this.lls8Temperature = gpsTrackPoint.getIoData().getLls8Temperature(); // LLS 8 temp
            this.lls8Level = gpsTrackPoint.getIoData().getLls8Level(); // LLS 8 Level
            this.lls8Code = gpsTrackPoint.getIoData().getLls8Code(); // LLS 8 CODE

            this.speedVechicle = gpsTrackPoint.getIoData().getSpeedVechicle();
            this.engineRpm = gpsTrackPoint.getIoData().getEngineRpm(); // != null ? gpsTrackPoint.getIoData().getEngineRpm() : null;
            this.enginePedalAccelerator = gpsTrackPoint.getIoData().getEnginePedalAccelerator() != null ? gpsTrackPoint.getIoData().getEnginePedalAccelerator() / 10 : null;
            this.engineWorkHour = gpsTrackPoint.getIoData().getEngineWorkHour();
            this.distanceTotal = gpsTrackPoint.getIoData().getDistanceTotal() != null ? gpsTrackPoint.getIoData().getDistanceTotal() / 1000 : null;
            this.distanceService = gpsTrackPoint.getIoData().getDistanceService() != null ? gpsTrackPoint.getIoData().getDistanceService() / 1000 : null;
            this.fuelCounterTotal = gpsTrackPoint.getIoData().getFuelCounterTotal() != null ? gpsTrackPoint.getIoData().getFuelCounterTotal() / 1000 : null;
            this.fuelLevel = gpsTrackPoint.getIoData().getFuelLevel() != null ? gpsTrackPoint.getIoData().getFuelLevel() / 10 : null;
            this.fuelEconomyDistPerLitr = gpsTrackPoint.getIoData().getFuelEconomyDistPerLitr();
            this.fuelEconomyLitrPerHour = gpsTrackPoint.getIoData().getFuelEconomyLitrPerHour();
            this.engineCoolantTemperature = gpsTrackPoint.getIoData().getEngineCoolantTemperature() != null ? gpsTrackPoint.getIoData().getEngineCoolantTemperature() / 10 : null;
            this.vinNumber = gpsTrackPoint.getIoData().getVinNumber();
            this.fuelCounterTotalHigh = gpsTrackPoint.getIoData().getFuelCounterTotalHigh();
            this.airTemperature = gpsTrackPoint.getIoData().getAirTemperature() != null ? gpsTrackPoint.getIoData().getAirTemperature() / 10 : null;
            this.sosButtonPressed = gpsTrackPoint.getSosStatus();
            this.fuelLevelLitr = gpsTrackPoint.getIoData().getFuelLevelLitr();
            this.gpsTimeout = gpsTrackPoint.getIoData().getFuelLevelLitr();
//            this.mObjectname = gpsTrackPoint.getMobjectBig().getName();

            this.engineThrottlePosition = gpsTrackPoint.getIoData().getEngineThrottlePosition();
            this.gpsTimeout = gpsTrackPoint.getIoData().getGpsTimeout();
            this.gpsVdop = gpsTrackPoint.getIoData().getGpsVdop();
            this.iButtonId = gpsTrackPoint.getIoData().getiButtonId();
            this.immobilizer = gpsTrackPoint.getIoData().getImmobilizer();
            this.overSpeeding = gpsTrackPoint.getIoData().getOverSpeeding();
            this.rfidId = gpsTrackPoint.getIoData().getRfidId();
            this.timeLive = gpsTrackPoint.getIoData().getTimeLive();
            this.timeTTFF = gpsTrackPoint.getIoData().getTimeTTFF();
            this.trip = gpsTrackPoint.getIoData().getTrip();
            this.priority = gpsTrackPoint.getIoData().getPriority();
            this.dtcCount = gpsTrackPoint.getIoData().getDtcCount();
            this.timingAdvance = gpsTrackPoint.getIoData().getTimingAdvance();
            this.timeWithMILon = gpsTrackPoint.getIoData().getTimeWithMILon();
            this.timeCodesCleared = gpsTrackPoint.getIoData().getTimeCodesCleared();
            this.engineOilTemperature = gpsTrackPoint.getIoData().getEngineOilTemperature();
            this.fuelInjectionTiming = gpsTrackPoint.getIoData().getFuelInjectionTiming();
            this.timeEngineStart = gpsTrackPoint.getIoData().getTimeEngineStart();
            this.shortTermFuelTrim = gpsTrackPoint.getIoData().getShortTermFuelTrim();
            this.pressureIntakeManifoldAbsolute = gpsTrackPoint.getIoData().getPressureIntakeManifoldAbsolute();
            this.temperatureIntakeAir = gpsTrackPoint.getIoData().getTemperatureIntakeAir();
            this.airFlowRate = gpsTrackPoint.getIoData().getAirFlowRate();
            this.pressureRelativeFuelRail = gpsTrackPoint.getIoData().getPressureRelativeFuelRail();
            this.pressureDirectFuelRail = gpsTrackPoint.getIoData().getPressureDirectFuelRail();
            this.commandedEGR = gpsTrackPoint.getIoData().getCommandedEGR();
            this.errorEGR = gpsTrackPoint.getIoData().getErrorEGR();
            this.pressureBarometric = gpsTrackPoint.getIoData().getPressureBarometric();
            this.voltageControlModule = gpsTrackPoint.getIoData().getVoltageControlModule();
            this.loadAbsoluteValue = gpsTrackPoint.getIoData().getLoadAbsoluteValue();
            this.pressureAbsoluteFuelRail = gpsTrackPoint.getIoData().getPressureAbsoluteFuelRail();
            this.batteryRemainingLife = gpsTrackPoint.getIoData().getBatteryRemainingLife();
            this.sensorMap = gpsTrackPoint.getIoData().getSensorMap();
        }
    }

    public Byte getDigital4() {
        return digital4;
    }

    public void setDigital4(Byte digital4) {
        this.digital4 = digital4;
    }

    public Short getAnalog2() {
        return analog2;
    }

    public void setAnalog2(Short analog2) {
        this.analog2 = analog2;
    }

    public Short getAnalog3() {
        return analog3;
    }

    public void setAnalog3(Short analog3) {
        this.analog3 = analog3;
    }

    public Short getAnalog4() {
        return analog4;
    }

    public void setAnalog4(Short analog4) {
        this.analog4 = analog4;
    }

    public Byte getActualProfile() {
        return actualProfile;
    }

    public void setActualProfile(Byte actualProfile) {
        this.actualProfile = actualProfile;
    }

    public Short getInternalBatteryCurrent() {
        return internalBatteryCurrent;
    }

    public void setInternalBatteryCurrent(Short internalBatteryCurrent) {
        this.internalBatteryCurrent = internalBatteryCurrent;
    }

    public Integer getPcbTemperature() {
        return pcbTemperature;
    }

    public void setPcbTemperature(Integer pcbTemperature) {
        this.pcbTemperature = pcbTemperature;
    }

    public Integer getCurrentOperatorCode() {
        return currentOperatorCode;
    }

    public void setCurrentOperatorCode(Integer currentOperatorCode) {
        this.currentOperatorCode = currentOperatorCode;
    }

    public Byte getDeepSleep() {
        return deepSleep;
    }

    public void setDeepSleep(Byte deepSleep) {
        this.deepSleep = deepSleep;
    }

    public String getDateFormatDate() {
        return dateFormatDate;
    }

    public void setDateFormatDate(String dateFormatDate) {
        this.dateFormatDate = dateFormatDate;
    }

    public String getDateFormatTime() {
        return dateFormatTime;
    }

    public void setDateFormatTime(String dateFormatTime) {
        this.dateFormatTime = dateFormatTime;
    }

    public byte getMovement() {
        return movement;
    }

    public void setMovement(byte movement) {
        this.movement = movement;
    }

    public byte getEngineOn() {
        return engineOn;
    }

    public void setEngineOn(byte engineOn) {
        this.engineOn = engineOn;
    }

    public byte getOnline() {
        return online;
    }

    public void setOnline(byte online) {
        this.online = online;
    }

    public byte getSatellites() {
        return satellites;
    }

    public void setSatellites(byte satellites) {
        this.satellites = satellites;
    }

    public byte getDat() {
        return dat;
    }

    public void setDat(byte dat) {
        this.dat = dat;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getAltitude() {
        return altitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getFormattedDate() {
        return formattedDate;
    }

    public void setFormattedDate(String formattedDate) {
        this.formattedDate = formattedDate;
    }

    public short getAngle() {
        return angle;
    }

    public void setAngle(short angle) {
        this.angle = angle;
    }

    public String getJson() {
        return json;
    }

    public void setJson(String json) {
        this.json = json;
    }

    public Byte getDigital1() {
        return digital1;
    }

    public void setDigital1(Byte digital1) {
        this.digital1 = digital1;
    }

    public Byte getDigital2() {
        return digital2;
    }

    public void setDigital2(Byte digital2) {
        this.digital2 = digital2;
    }

    public Byte getDigital3() {
        return digital3;
    }

    public void setDigital3(Byte digital3) {
        this.digital3 = digital3;
    }

    public Short getAnalog1() {
        return analog1;
    }

    public void setAnalog1(Short analog1) {
        this.analog1 = analog1;
    }

    public Byte getGsmSignalLevel() {
        return gsmSignalLevel;
    }

    public void setGsmSignalLevel(Byte gsmSignalLevel) {
        this.gsmSignalLevel = gsmSignalLevel;
    }

    public Short getSpeedometer() {
        return speedometer;
    }

    public void setSpeedometer(Short speedometer) {
        this.speedometer = speedometer;
    }

    public Short getExternalPowerVoltage() {
        return externalPowerVoltage;
    }

    public void setExternalPowerVoltage(Short externalPowerVoltage) {
        this.externalPowerVoltage = externalPowerVoltage;
    }

    public Short getInternalBatteryVoltage() {
        return internalBatteryVoltage;
    }

    public void setInternalBatteryVoltage(Short internalBatteryVoltage) {
        this.internalBatteryVoltage = internalBatteryVoltage;
    }

    public Double getExternalPowerVoltageDouble() {
        return externalPowerVoltageDouble;
    }

    public void setExternalPowerVoltageDouble(Double externalPowerVoltageDouble) {
        this.externalPowerVoltageDouble = externalPowerVoltageDouble;
    }

    public Double getInternalBatteryVoltageDouble() {
        return internalBatteryVoltageDouble;
    }

    public void setInternalBatteryVoltageDouble(Double internalBatteryVoltageDouble) {
        this.internalBatteryVoltageDouble = internalBatteryVoltageDouble;
    }

    public Integer getBatteryPercent() {
        return batteryPercent;
    }

    public void setBatteryPercent(Integer batteryPercent) {
        this.batteryPercent = batteryPercent;
    }

    public Byte getGnssStatus() {
        return gnssStatus;
    }

    public void setGnssStatus(Byte gnssStatus) {
        this.gnssStatus = gnssStatus;
    }

    public Short getGpsPdop() {
        return gpsPdop;
    }

    public void setGpsPdop(Short gpsPdop) {
        this.gpsPdop = gpsPdop;
    }

    public Short getGpsHdop() {
        return gpsHdop;
    }

    public void setGpsHdop(Short gpsHdop) {
        this.gpsHdop = gpsHdop;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Short getCellId() {
        return cellId;
    }

    public void setCellId(Short cellId) {
        this.cellId = cellId;
    }

    public Short getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(Short areaCode) {
        this.areaCode = areaCode;
    }

    public Byte getMovementValue() {
        return movementValue;
    }

    public void setMovementValue(Byte movementValue) {
        this.movementValue = movementValue;
    }

    public Integer getBak1() {
        return bak1;
    }

    public Double getBak1Litr() {
        return (bak1 == null) ? null : bak1 / 1.;
    }

    public void setBak1(Integer bak1) {
        this.bak1 = bak1;
    }

    public Integer getBak2() {
        return bak2;
    }

    public Double getBak2Litr() {
        return (bak2 == null) ? null : bak2 / 1.;
    }

    public void setBak2(Integer bak2) {
        this.bak2 = bak2;
    }

    public Integer getBak3() {
        return bak3;
    }

    public Double getBak3Litr() {
        return (bak3 == null) ? null : bak3 / 1.;
    }

    public void setBak3(Integer bak3) {
        this.bak3 = bak3;
    }

    public Integer getBak4() {
        return bak4;
    }

    public Double getBak4Litr() {
        return (bak4 == null) ? null : bak4 / 1.;
    }

    public void setBak4(Integer bak4) {
        this.bak4 = bak4;
    }


    public Integer getBak1Enabled() {
        return bak1Enabled;
    }

    public void setBak1Enabled(Integer bak1Enabled) {
        this.bak1Enabled = bak1Enabled;
    }

    public Integer getBak2Enabled() {
        return bak2Enabled;
    }

    public void setBak2Enabled(Integer bak2Enabled) {
        this.bak2Enabled = bak2Enabled;
    }

    public Integer getBak3Enabled() {
        return bak3Enabled;
    }

    public void setBak3Enabled(Integer bak3Enabled) {
        this.bak3Enabled = bak3Enabled;
    }

    public Integer getBak4Enabled() {
        return bak4Enabled;
    }

    public void setBak4Enabled(Integer bak4Enabled) {
        this.bak4Enabled = bak4Enabled;
    }

    public Integer getBakTotal() {
        return bakTotal;
    }

    public Double getBakTotalLitr() {
        return (bakTotal == null) ? null : bakTotal / 1.;
    }


    public void setBakTotal(Integer bakTotal) {
        this.bakTotal = bakTotal;
    }

    public String getAnalog1Str() {
        if (this.analog1 != null) {
            return String.format("%.1f", (this.analog1 / 1f));
        }
        return "0";
    }

    public String getAnalog2Str() {
        if (this.analog2 != null) {
            return String.format("%.1f", (this.analog2 / 1f));
        }
        return "0";
    }

    public String getAnalog3Str() {
        if (this.analog3 != null) {
            return String.format("%.1f", (this.analog3 / 1f));
        }
        return "0";
    }


    public String getAnalog4Str() {
        if (this.analog4 != null) {
            return String.format("%.1f", (this.analog4 / 1f));
        }
        return "0";
    }


    public Short getFuelLevelMeter1() {
        return fuelLevelMeter1;
    }

    public void setFuelLevelMeter1(Short fuelLevelMeter1) {
        this.fuelLevelMeter1 = fuelLevelMeter1;
    }

    public Byte getFuelTemperature1() {
        return fuelTemperature1;
    }

    public void setFuelTemperature1(Byte fuelTemperature1) {
        this.fuelTemperature1 = fuelTemperature1;
    }

    public Short getFuelLevelMeter2() {
        return fuelLevelMeter2;
    }

    public void setFuelLevelMeter2(Short fuelLevelMeter2) {
        this.fuelLevelMeter2 = fuelLevelMeter2;
    }

    public Byte getFuelTemperature2() {
        return fuelTemperature2;
    }

    public void setFuelTemperature2(Byte fuelTemperature2) {
        this.fuelTemperature2 = fuelTemperature2;
    }

    public Integer getLls3Temperature() {
        return lls3Temperature;
    }

    public void setLls3Temperature(Integer lls3Temperature) {
        this.lls3Temperature = lls3Temperature;
    }

    public Integer getLls3Level() {
        return lls3Level;
    }

    public void setLls3Level(Integer lls3Level) {
        this.lls3Level = lls3Level;
    }

    public Integer getLls3Code() {
        return lls3Code;
    }

    public Integer getLls1Code() {
        return lls1Code;
    }

    public void setLls1Code(Integer lls1Code) {
        this.lls1Code = lls1Code;
    }

    public Integer getLls2Code() {
        return lls2Code;
    }

    public void setLls2Code(Integer lls2Code) {
        this.lls2Code = lls2Code;
    }

    public void setLls3Code(Integer lls3Code) {
        this.lls3Code = lls3Code;
    }

    public Integer getLls4Temperature() {
        return lls4Temperature;
    }

    public void setLls4Temperature(Integer lls4Temperature) {
        this.lls4Temperature = lls4Temperature;
    }

    public Integer getLls4Level() {
        return lls4Level;
    }

    public void setLls4Level(Integer lls4Level) {
        this.lls4Level = lls4Level;
    }

    public Integer getLls4Code() {
        return lls4Code;
    }

    public void setLls4Code(Integer lls4Code) {
        this.lls4Code = lls4Code;
    }

    public Integer getLls5Temperature() {
        return lls5Temperature;
    }

    public void setLls5Temperature(Integer lls5Temperature) {
        this.lls5Temperature = lls5Temperature;
    }

    public Integer getLls5Level() {
        return lls5Level;
    }

    public void setLls5Level(Integer lls5Level) {
        this.lls5Level = lls5Level;
    }

    public Integer getLls5Code() {
        return lls5Code;
    }

    public void setLls5Code(Integer lls5Code) {
        this.lls5Code = lls5Code;
    }

    public Integer getLls6Temperature() {
        return lls6Temperature;
    }

    public void setLls6Temperature(Integer lls6Temperature) {
        this.lls6Temperature = lls6Temperature;
    }

    public Integer getLls6Level() {
        return lls6Level;
    }

    public void setLls6Level(Integer lls6Level) {
        this.lls6Level = lls6Level;
    }

    public Integer getLls6Code() {
        return lls6Code;
    }

    public void setLls6Code(Integer lls6Code) {
        this.lls6Code = lls6Code;
    }

    public Integer getLls7Temperature() {
        return lls7Temperature;
    }

    public void setLls7Temperature(Integer lls7Temperature) {
        this.lls7Temperature = lls7Temperature;
    }

    public Integer getLls7Level() {
        return lls7Level;
    }

    public void setLls7Level(Integer lls7Level) {
        this.lls7Level = lls7Level;
    }

    public Integer getLls7Code() {
        return lls7Code;
    }

    public void setLls7Code(Integer lls7Code) {
        this.lls7Code = lls7Code;
    }

    public Integer getLls8Temperature() {
        return lls8Temperature;
    }

    public void setLls8Temperature(Integer lls8Temperature) {
        this.lls8Temperature = lls8Temperature;
    }

    public Integer getLls8Level() {
        return lls8Level;
    }

    public void setLls8Level(Integer lls8Level) {
        this.lls8Level = lls8Level;
    }

    public Integer getLls8Code() {
        return lls8Code;
    }

    public void setLls8Code(Integer lls8Code) {
        this.lls8Code = lls8Code;
    }

    public long getRegDate() {
        return regDate;
    }

    public void setRegDate(long regDate) {
        this.regDate = regDate;
    }

    public String getRegDateFormatDate() {
        return regDateFormatDate;
    }

    public void setRegDateFormatDate(String regDateFormatDate) {
        this.regDateFormatDate = regDateFormatDate;
    }

    public String getRegDateFormatTime() {
        return regDateFormatTime;
    }

    public void setRegDateFormatTime(String regDateFormatTime) {
        this.regDateFormatTime = regDateFormatTime;
    }

    public Integer getEngineRpm() {
        return engineRpm;
    }

    public void setEngineRpm(Integer engineRpm) {
        this.engineRpm = engineRpm;
    }

    public Integer getEnginePedalAccelerator() {
        return enginePedalAccelerator;
    }

    public void setEnginePedalAccelerator(Integer enginePedalAccelerator) {
        this.enginePedalAccelerator = enginePedalAccelerator;
    }

    public Long getEngineWorkHour() {
        return engineWorkHour;
    }

    public void setEngineWorkHour(Long engineWorkHour) {
        this.engineWorkHour = engineWorkHour;
    }

    public Long getDistanceTotal() {
        return distanceTotal;
    }

    public void setDistanceTotal(Long distanceTotal) {
        this.distanceTotal = distanceTotal;
    }

    public Integer getDistanceService() {
        return distanceService;
    }

    public void setDistanceService(Integer distanceService) {
        this.distanceService = distanceService;
    }

    public Long getFuelCounterTotal() {
        return fuelCounterTotal;
    }

    public void setFuelCounterTotal(Long fuelCounterTotal) {
        this.fuelCounterTotal = fuelCounterTotal;
    }

    public Integer getFuelLevel() {
        return fuelLevel;
    }

    public void setFuelLevel(Integer fuelLevel) {
        this.fuelLevel = fuelLevel;
    }

    public Integer getFuelEconomyDistPerLitr() {
        return fuelEconomyDistPerLitr;
    }

    public void setFuelEconomyDistPerLitr(Integer fuelEconomyDistPerLitr) {
        this.fuelEconomyDistPerLitr = fuelEconomyDistPerLitr;
    }

    public Integer getFuelEconomyLitrPerHour() {
        return fuelEconomyLitrPerHour;
    }

    public void setFuelEconomyLitrPerHour(Integer fuelEconomyLitrPerHour) {
        this.fuelEconomyLitrPerHour = fuelEconomyLitrPerHour;
    }

    public Integer getEngineCoolantTemperature() {
        return engineCoolantTemperature;
    }

    public void setEngineCoolantTemperature(Integer engineCoolantTemperature) {
        this.engineCoolantTemperature = engineCoolantTemperature;
    }

    public String getVinNumber() {
        return vinNumber;
    }

    public void setVinNumber(String vinNumber) {
        this.vinNumber = vinNumber;
    }

    public Integer getSpeedVechicle() {
        return speedVechicle;
    }

    public void setSpeedVechicle(Integer speedVechicle) {
        this.speedVechicle = speedVechicle;
    }

    public Long getFuelCounterTotalHigh() {
        return fuelCounterTotalHigh;
    }

    public void setFuelCounterTotalHigh(Long fuelCounterTotalHigh) {
        this.fuelCounterTotalHigh = fuelCounterTotalHigh;
    }

    public Integer getAirTemperature() {
        return airTemperature;
    }

    public void setAirTemperature(Integer airTemperature) {
        this.airTemperature = airTemperature;
    }

    public String getmObjectname() {
        return mObjectname;
    }

    public void setmObjectname(String mObjectname) {
        this.mObjectname = mObjectname;
    }

    public Integer getSosButtonPressed() {
        return sosButtonPressed;
    }

    public void setSosButtonPressed(Integer sosButtonPressed) {
        this.sosButtonPressed = sosButtonPressed;
    }

    public Integer getModeHomeRoaming() {
        return modeHomeRoaming;
    }

    public void setModeHomeRoaming(Integer modeHomeRoaming) {
        this.modeHomeRoaming = modeHomeRoaming;
    }

    public Integer getFuelLevelLitr() {
        return fuelLevelLitr;
    }

    public void setFuelLevelLitr(Integer fuelLevelLitr) {
        this.fuelLevelLitr = fuelLevelLitr;
    }

    public Integer getGpsTimeout() {
        return gpsTimeout;
    }

    public void setGpsTimeout(Integer gpsTimeout) {
        this.gpsTimeout = gpsTimeout;
    }

    public Integer getGpsVdop() {
        return gpsVdop;
    }

    public void setGpsVdop(Integer gpsVdop) {
        this.gpsVdop = gpsVdop;
    }

    public Long getiButtonId() {
        return iButtonId;
    }

    public void setiButtonId(Long iButtonId) {
        this.iButtonId = iButtonId;
    }

    public Byte getImmobilizer() {
        return immobilizer;
    }

    public void setImmobilizer(Byte immobilizer) {
        this.immobilizer = immobilizer;
    }

    public Byte getOverSpeeding() {
        return overSpeeding;
    }

    public void setOverSpeeding(Byte overSpeeding) {
        this.overSpeeding = overSpeeding;
    }

    public Long getRfidId() {
        return rfidId;
    }

    public void setRfidId(Long rfidId) {
        this.rfidId = rfidId;
    }

    public Integer getTimeLive() {
        return timeLive;
    }

    public void setTimeLive(Integer timeLive) {
        this.timeLive = timeLive;
    }

    public Integer getTimeTTFF() {
        return timeTTFF;
    }

    public void setTimeTTFF(Integer timeTTFF) {
        this.timeTTFF = timeTTFF;
    }

    public Byte getTrip() {
        return trip;
    }

    public void setTrip(Byte trip) {
        this.trip = trip;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer getDtcCount() {
        return dtcCount;
    }

    public void setDtcCount(Integer dtcCount) {
        this.dtcCount = dtcCount;
    }

    public Integer getTimingAdvance() {
        return timingAdvance;
    }

    public void setTimingAdvance(Integer timingAdvance) {
        this.timingAdvance = timingAdvance;
    }

    public Integer getTimeWithMILon() {
        return timeWithMILon;
    }

    public void setTimeWithMILon(Integer timeWithMILon) {
        this.timeWithMILon = timeWithMILon;
    }

    public Integer getTimeCodesCleared() {
        return timeCodesCleared;
    }

    public void setTimeCodesCleared(Integer timeCodesCleared) {
        this.timeCodesCleared = timeCodesCleared;
    }

    public Integer getEngineOilTemperature() {
        return engineOilTemperature;
    }

    public void setEngineOilTemperature(Integer engineOilTemperature) {
        this.engineOilTemperature = engineOilTemperature;
    }

    public Integer getFuelInjectionTiming() {
        return fuelInjectionTiming;
    }

    public void setFuelInjectionTiming(Integer fuelInjectionTiming) {
        this.fuelInjectionTiming = fuelInjectionTiming;
    }

    public Integer getTimeEngineStart() {
        return timeEngineStart;
    }

    public void setTimeEngineStart(Integer timeEngineStart) {
        this.timeEngineStart = timeEngineStart;
    }

    public Integer getShortTermFuelTrim() {
        return shortTermFuelTrim;
    }

    public void setShortTermFuelTrim(Integer shortTermFuelTrim) {
        this.shortTermFuelTrim = shortTermFuelTrim;
    }

    public Integer getPressureIntakeManifoldAbsolute() {
        return pressureIntakeManifoldAbsolute;
    }

    public void setPressureIntakeManifoldAbsolute(Integer pressureIntakeManifoldAbsolute) {
        this.pressureIntakeManifoldAbsolute = pressureIntakeManifoldAbsolute;
    }

    public Integer getTemperatureIntakeAir() {
        return temperatureIntakeAir;
    }

    public void setTemperatureIntakeAir(Integer temperatureIntakeAir) {
        this.temperatureIntakeAir = temperatureIntakeAir;
    }

    public Integer getAirFlowRate() {
        return airFlowRate;
    }

    public void setAirFlowRate(Integer airFlowRate) {
        this.airFlowRate = airFlowRate;
    }

    public Integer getPressureRelativeFuelRail() {
        return pressureRelativeFuelRail;
    }

    public void setPressureRelativeFuelRail(Integer pressureRelativeFuelRail) {
        this.pressureRelativeFuelRail = pressureRelativeFuelRail;
    }

    public Integer getPressureDirectFuelRail() {
        return pressureDirectFuelRail;
    }

    public void setPressureDirectFuelRail(Integer pressureDirectFuelRail) {
        this.pressureDirectFuelRail = pressureDirectFuelRail;
    }

    public Integer getCommandedEGR() {
        return commandedEGR;
    }

    public void setCommandedEGR(Integer commandedEGR) {
        this.commandedEGR = commandedEGR;
    }

    public Integer getErrorEGR() {
        return errorEGR;
    }

    public void setErrorEGR(Integer errorEGR) {
        this.errorEGR = errorEGR;
    }

    public Integer getPressureBarometric() {
        return pressureBarometric;
    }

    public void setPressureBarometric(Integer pressureBarometric) {
        this.pressureBarometric = pressureBarometric;
    }

    public Integer getVoltageControlModule() {
        return voltageControlModule;
    }

    public void setVoltageControlModule(Integer voltageControlModule) {
        this.voltageControlModule = voltageControlModule;
    }

    public Integer getLoadAbsoluteValue() {
        return loadAbsoluteValue;
    }

    public void setLoadAbsoluteValue(Integer loadAbsoluteValue) {
        this.loadAbsoluteValue = loadAbsoluteValue;
    }

    public Integer getPressureAbsoluteFuelRail() {
        return pressureAbsoluteFuelRail;
    }

    public void setPressureAbsoluteFuelRail(Integer pressureAbsoluteFuelRail) {
        this.pressureAbsoluteFuelRail = pressureAbsoluteFuelRail;
    }

    public Integer getBatteryRemainingLife() {
        return batteryRemainingLife;
    }

    public void setBatteryRemainingLife(Integer batteryRemainingLife) {
        this.batteryRemainingLife = batteryRemainingLife;
    }

    public Integer getEngineThrottlePosition() {
        return engineThrottlePosition;
    }

    public void setEngineThrottlePosition(Integer engineThrottlePosition) {
        this.engineThrottlePosition = engineThrottlePosition;
    }

    public Integer getEngineLoadPercent() {
        return engineLoadPercent;
    }

    public void setEngineLoadPercent(Integer engineLoadPercent) {
        this.engineLoadPercent = engineLoadPercent;
    }

    public Integer getDistanceAfterCodesClear() {
        return distanceAfterCodesClear;
    }

    public void setDistanceAfterCodesClear(Integer distanceAfterCodesClear) {
        this.distanceAfterCodesClear = distanceAfterCodesClear;
    }

    public Integer getDistanceWithMilOn() {
        return distanceWithMilOn;
    }

    public void setDistanceWithMilOn(Integer distanceWithMilOn) {
        this.distanceWithMilOn = distanceWithMilOn;
    }

    public SensorMap getSensorMap() {
        return sensorMap;
    }

    public void setSensorMap(SensorMap sensorMap) {
        this.sensorMap = sensorMap;
    }
}