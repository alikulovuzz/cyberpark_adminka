package uzgps.map.models.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import uz.netex.core.CoreMain;
import uz.netex.dbtables.NotificationUnit;
import uzgps.persistence.ContractSettings;

/**
 * Created by Gayratjon on 9/27/14.
 */
public class MobjectStaffAttacheNotification extends BaseNotification {

    private String staffName;
    private Long dateStart;
    private Long dateEnd;
    @JsonProperty("dt_start")
    private String dateStartFormatted;
    @JsonProperty("dt_end")
    private String dateEndFormatted;
    private Integer endless;


    public MobjectStaffAttacheNotification(NotificationUnit notificationUnit, CoreMain coreMain,
                                           ContractSettings contractSettings) {
        super(notificationUnit, coreMain, contractSettings);

        if (notificationUnit != null) {

            // Staff connected to object time
            if (notificationUnit.getTpTime() != null)
                this.time = notificationUnit.getTpTime().getTime();

            // Staff name
            this.staffName = notificationUnit.getValueStr();

            // Start and end dates
            if (notificationUnit.getValueTime() != null)
                this.setDateStart(notificationUnit.getValueTime().getTime());
            if (notificationUnit.getValueTime2() != null)
                this.setDateEnd(notificationUnit.getValueTime2().getTime());
            // Endless 0-has end date, 1-endless
            this.setEndless(notificationUnit.getValueInt());
        }
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public Long getDateStart() {
        return dateStart;
    }

    public void setDateStart(Long dateStart) {
        this.dateStart = dateStart;
        this.dateStartFormatted = getFormattedDate(dateStart);
    }

    public Long getDateEnd() {
        return dateEnd;
    }

    public void setDateEnd(Long dateEnd) {
        this.dateEnd = dateEnd;
        this.dateEndFormatted = getFormattedDate(dateEnd);

    }

    public Integer getEndless() {
        return endless;
    }

    public void setEndless(Integer endless) {
        this.endless = endless;
    }

    public String getFormattedDateStart() {
        return getFormattedDate(this.dateStart);
    }

    public String getFormattedDateEnd() {
        return getFormattedDate(this.dateEnd);
    }

    public String getDateStartFormatted() {
        return dateStartFormatted;
    }

    public void setDateStartFormatted(String dateStartFormatted) {
        this.dateStartFormatted = dateStartFormatted;
    }

    public String getDateEndFormatted() {
        return dateEndFormatted;
    }

    public void setDateEndFormatted(String dateEndFormatted) {
        this.dateEndFormatted = dateEndFormatted;
    }


}
