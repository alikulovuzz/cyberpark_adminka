package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonFilter;
import org.locationtech.jts.geom.*;
import org.locationtech.jts.io.WKTWriter;
import uzgps.persistence.GeoFence;
import uzgps.persistence.GeoFencePoint;
import uzgps.persistence.ZoiGroup;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.List;

/**
 * Created by Gayratjon on 4/25/14.
 */

@JsonFilter("GeoFenceJSONFilter")
public class GeoFenceJSON implements Serializable {
    private Integer id;
    private String name;
    private Long fileId;
    private Long groupId;
    private ZoiGroup group;
    private Long imageId;
    private String description;
    private String urlFile;
    private String urlImage;
    private String fontColor;
    private Integer fontSize;
    private String type;
    private String color;
    private Float radius;
    private String area;
    private String perimeter;
    private String wktString;
    private Boolean isNameDisplayed;
    private Boolean isLimitOver;
    private Double geometryOpacity;

    DecimalFormat decimalFormat = new DecimalFormat("#0.000");
    WKTWriter wktWriter = new WKTWriter();

    public GeoFenceJSON() {
    }

    public GeoFenceJSON(GeoFence geoFence, boolean isNameDisplayed) {
        if (geoFence != null) {
            this.id = geoFence.getId().intValue();
            this.name = geoFence.getName();
            this.description = geoFence.getDescription();
            this.fileId = geoFence.getFileId();
            this.groupId = geoFence.getGroupId();
            this.group = geoFence.getGroup();
            this.imageId = geoFence.getImageId();
            this.urlFile = geoFence.getUrlFile();
            this.urlImage = geoFence.getUrlImage();
            this.fontColor = geoFence.getFontColor();
            this.fontSize = geoFence.getFontSize();
            this.type = geoFence.getType();
            this.color = geoFence.getColor();
            this.radius = geoFence.getRadius();

            this.area = decimalFormat.format(geoFence.getArea());
            this.perimeter = decimalFormat.format(geoFence.getPerimeter());
            this.wktString = geoFence.getWktString();
            this.isNameDisplayed = isNameDisplayed;
            this.geometryOpacity = geoFence.getGeometryOpacity();

            if (this.id != null && !this.type.isEmpty() &&(this.wktString == null || this.wktString.length() < 2)) {
                Geometry geometry = createGeometry(geoFence.getGeoFencePointList());
                if (geometry != null) {
                    wktString = wktWriter.write(geometry);
                }
            }
        }
    }

    private Geometry createGeometry(List<GeoFencePoint> geoFencePointList) {
        Geometry geometry = null;
        if (geoFencePointList.size() > 0) {
            CoordinateList coordinateList = new CoordinateList();
            for (GeoFencePoint geoFencePoint : geoFencePointList) {
                Coordinate coordinate = new Coordinate(geoFencePoint.getLongitude(), geoFencePoint.getLatitude());
                coordinateList.add(coordinate);
            }

            GeometryFactory geometryFactory = new GeometryFactory();
            try {
                if (this.type.equalsIgnoreCase("point")) {
                    geometry = geometryFactory.createPoint(coordinateList.getCoordinate(0));
                } else if (this.type.equalsIgnoreCase("LineString")) {
                    geometry = geometryFactory.createLineString(coordinateList.toCoordinateArray());
                } else if (this.type.equalsIgnoreCase("polygon")) {
                    LinearRing linearRing = geometryFactory.createLinearRing(coordinateList.toCoordinateArray());
                    geometry = geometryFactory.createPolygon(linearRing, null);
                }
            } catch (Exception err) {
                geometry = null;
            }
        }

        return geometry;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getGroupId() { return groupId; }

    public void setGroupId(Long groupId) { this.groupId = groupId; }

    public ZoiGroup getGroup() { return group; }

    public void setGroup(ZoiGroup group) { this.group = group; }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public Long getImageId() {
        return imageId;
    }

    public void setImageId(Long imageId) {
        this.imageId = imageId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUrlFile() {
        return urlFile;
    }

    public void setUrlFile(String url) {
        this.urlFile = url;
    }

    public String getUrlImage() {
        return urlImage;
    }

    public void setUrlImage(String url) {
        this.urlImage = url;
    }

    public String getFontColor() {
        return fontColor;
    }

    public void setFontColor(String fontColor) {
        this.fontColor = fontColor;
    }

    public Integer getFontSize() {
        return fontSize;
    }

    public void setFontSize(Integer fontSize) {
        this.fontSize = fontSize;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Float getRadius() {
        return radius;
    }

    public void setRadius(Float radius) {
        this.radius = radius;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getPerimeter() {
        return perimeter;
    }

    public void setPerimeter(String perimeter) {
        this.perimeter = perimeter;
    }

    public String getWktString() {
        return wktString;
    }

    public void setWktString(String wktString) {
        this.wktString = wktString;
    }

    public Boolean getIsNameDisplayed() {
        return isNameDisplayed;
    }

    public void setIsNameDisplayed(Boolean isNameDisplayed) {
        this.isNameDisplayed = isNameDisplayed;
    }

    public Boolean getIsLimitOver() {
        return isLimitOver;
    }

    public Double getGeometryOpacity() {
        return geometryOpacity;
    }

    public void setGeometryOpacity(Double geometryOpacity) {
        this.geometryOpacity = geometryOpacity;
    }

    public void setIsLimitOver(Boolean isLimitOver) {
        this.isLimitOver = isLimitOver;
    }

    @Override
    public String toString() {
        return "GeoFenceJSON{" +
                "name='" + name + '\'' +
                ", groupId='" + groupId + '\'' +
                ", group='" + group + '\'' +
                ", fileId='" + fileId + '\'' +
                ", imageId='" + imageId + '\'' +
                ", description='" + description + '\'' +
                ", urlFile='" + urlFile + '\'' +
                ", urlImage='" + urlImage + '\'' +
                ", fontColor='" + fontColor + '\'' +
                ", fontSize=" + fontSize +
                ", type='" + type + '\'' +
                ", color='" + color + '\'' +
                ", radius=" + radius +
                ", area=" + area +
                ", perimeter=" + perimeter +
                ", wktString='" + wktString + '\'' +
                ", geometryOpacity='" + geometryOpacity + '\'' +
                '}';
    }
}
