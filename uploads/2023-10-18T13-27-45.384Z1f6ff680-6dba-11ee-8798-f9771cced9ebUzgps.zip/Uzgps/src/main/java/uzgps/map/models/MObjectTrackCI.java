package uzgps.map.models;

import java.util.concurrent.TimeUnit;

/**
 * Created by Gayratjon on 4/29/14.
 */
public class MObjectTrackCI extends  MObjectActionCI{
    private static final String TRACK_BY_POINT = "by-point";
    private static final String TRACK_BY_TIME = "by-time";

    private String typeTrack;
    private long valueTrack;

    public MObjectTrackCI(int position, String idName, String title, String icon, int hasAccess, int typeTrack, long valueTrack) {
        super(position, idName, title, icon, hasAccess);
        setTypeTrack(typeTrack);
        this.valueTrack = valueTrack;
    }

    public String getTypeTrack() {
        return typeTrack;
    }

    public void setTypeTrack(int typeTrack) {
        if (typeTrack == 1) {
            this.typeTrack = TRACK_BY_POINT;
        } else {
            this.typeTrack = TRACK_BY_TIME;
        }
    }

    public long getValueTrack() {
        return valueTrack;
    }

    public void setValueTrack(long valueTrack) {
        this.valueTrack = valueTrack;
    }
}
