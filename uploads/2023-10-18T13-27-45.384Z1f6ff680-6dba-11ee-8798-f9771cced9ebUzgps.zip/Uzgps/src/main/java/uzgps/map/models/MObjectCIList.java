package uzgps.map.models;

import uzgps.map.MonitoringController;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.UserAccessList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by Gayratjon on 4/29/14.
 */
public class MObjectCIList {
    private List<MObjectCI> mObjectCIList = null;

    public MObjectCIList(ContractSettings contractSettings, UserAccessList userAccessList) {

        if (contractSettings != null) {
            mObjectCIList = new ArrayList<>();
            if (contractSettings.getObjectStatusView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getObjectStatusPosition(), "state-object", "state.object", MonitoringController.Icon.STATE_OBJECT);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getIgnitionSensorView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getIgnitionSensorPosition(), "ignition-sensor", "ignition.sensor", MonitoringController.Icon.IGNITION_SENSOR);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getObjectLinkView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getObjectLinkPosition(), "connection-object", "connection.object", MonitoringController.Icon.CONNECTION_OBJECT);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getSatelliteVisibilityView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getSatelliteVisibilityPosition(), "satellite-visibility", "satellite.visibility", MonitoringController.Icon.SATELLITE_VISIBILITY);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getSensorStateView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getSensorStatePosition(), "state-sensor", "state.sensor", MonitoringController.Icon.STATE_SENSOR);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getObjectDriverView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getObjectDriverPosition(), "staff", "staff.object", MonitoringController.Icon.STAFF);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getObjectMassageView()) {
                MObjectCI mObjectCI = new MObjectMessageCI(contractSettings.getObjectMassagePosition(), "message-object", "message.object", MonitoringController.Icon.MESSAGE_OBJECT, userAccessList.getMessage());
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getBuildTrackView()) {
                MObjectCI mObjectCI = new MObjectTrackCI(contractSettings.getBuildTrackPosition(), "track-object", "build.track", MonitoringController.Icon.TRACK_OBJECT, userAccessList.getTracker(), contractSettings.getFastTrackType().intValue(), contractSettings.getFastTrackValue());
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getReportView()) {
                MObjectCI mObjectCI = new MObjectReportCI(contractSettings.getReportPosition(), "report-object", "report.object", MonitoringController.Icon.VIEW_REPORT, userAccessList.getReport());
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getSmsSendView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getSmsSendPosition(), "sms-object", "sms.message", MonitoringController.Icon.SEND_SMS);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getObjectPropertiesView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getObjectPropertiesPosition(), "edit-object", "edit.object", MonitoringController.Icon.EDIT_OBJECT);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getBakPositionView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getBakPosition(), "bak-status", "bak.status", MonitoringController.Icon.BAK_STATUS);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getExternalPowerVoltageView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getExternalPowerVoltagePosition(), "epv-object", "epv.object", MonitoringController.Icon.EXTERNAL_POWER_VOLTAGE);
                mObjectCIList.add(mObjectCI);
            }
            if (contractSettings.getObjBatteryView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getObjBatteryPosition(), "obj-battery", "battery.percent", MonitoringController.Icon.OBJECT_BATTERY);
                mObjectCIList.add(mObjectCI);
            }

            if (contractSettings.getLastMsgTimeView()) {
                MObjectCI mObjectCI = new MObjectCI(contractSettings.getLastMsgTimePosition(), "last-msg-time", "last.msg.time", MonitoringController.Icon.LAST_MSG_TIME);
                mObjectCIList.add(mObjectCI);
            }

            Collections.sort(mObjectCIList, new Comparator<MObjectCI>() {
                @Override
                public int compare(MObjectCI o1, MObjectCI o2) {
                    return o1.getPosition() - o2.getPosition();
                }
            });
        }
    }

    public List<MObjectCI> get() {
        return mObjectCIList;
    }
}
