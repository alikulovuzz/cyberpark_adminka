package uzgps.map.kml;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 3/4/14.
 */
@XmlRootElement(name = "ExtraData")
@XmlAccessorType(XmlAccessType.FIELD)
public class KMLExtraData {
    private Long mObjectId;
    private String mObjectName;
    private String fromDate;
    private String toDate;
    private Integer fromPoint;
    private Integer toPoint;
    private Integer kmlPointCount;
    private String kmlDistance;

    private KMLExtraDataEventList events;

    private Double distance;

    public KMLExtraData() {
    }

    public KMLExtraData(String mObjectName, Long mObjectId,
                        String fromDate, String toDate, Integer fromPoint, Integer toPoint,
                        Integer kmlPointCount, Double distance, List<KMLExtraDataEvent> kmlExtraDataEvents) {
        this.mObjectName = mObjectName;
        this.mObjectId = mObjectId;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.fromPoint = fromPoint;
        this.toPoint = toPoint;
        this.kmlPointCount = kmlPointCount;
        this.events = new KMLExtraDataEventList();

        if (kmlExtraDataEvents != null) {

            for (KMLExtraDataEvent event : kmlExtraDataEvents) {
                this.events.add(event);
            }
        }
        setDistance(distance);
    }

    public String getmObjectName() {
        return mObjectName;
    }

    public void setmObjectName(String mObjectName) {
        this.mObjectName = mObjectName;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public Integer getFromPoint() {
        return fromPoint;
    }

    public void setFromPoint(Integer fromPoint) {
        this.fromPoint = fromPoint;
    }

    public Integer getToPoint() {
        return toPoint;
    }

    public void setToPoint(Integer toPoint) {
        this.toPoint = toPoint;
    }

    public Integer getKmlPointCount() {
        return kmlPointCount;
    }

    public void setKmlPointCount(Integer kmlPointCount) {
        this.kmlPointCount = kmlPointCount;
    }

    public String getKmlDistance() {
        return kmlDistance;
    }

    public void setKmlDistance(String kmlDistance) {
        this.kmlDistance = kmlDistance;
    }

    public KMLExtraDataEventList getEvents() {
        return events;
    }

    public void setEvents(KMLExtraDataEventList events) {
        this.events = events;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
        DecimalFormat decimalFormat = new DecimalFormat("#0.000");
        this.kmlDistance = decimalFormat.format(this.distance);
    }

}
