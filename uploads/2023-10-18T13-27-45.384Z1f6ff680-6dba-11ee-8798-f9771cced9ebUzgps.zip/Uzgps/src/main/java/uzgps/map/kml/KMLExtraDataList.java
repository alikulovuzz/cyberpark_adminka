package uzgps.map.kml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 3/27/14.
 */
@XmlRootElement(name = "ExtraDataList")
public class KMLExtraDataList {
    private List<KMLExtraData> kmlExtraDataList;

    public KMLExtraDataList() {
        kmlExtraDataList = new ArrayList<>();
    }

    @XmlElement(name = "ExtraData")
    public List<KMLExtraData> getKmlExtraDataList() {
        return kmlExtraDataList;
    }

    public void setKmlExtraDataList(List<KMLExtraData> kmlExtraDataList) {
        this.kmlExtraDataList = kmlExtraDataList;
    }

    public boolean add(KMLExtraData kmlExtraData) {
        return kmlExtraDataList.add(kmlExtraData);
    }

    public int size() {
        return kmlExtraDataList.size();
    }

    public KMLExtraData get(int index) {
        return kmlExtraDataList.get(index);
    }
}
