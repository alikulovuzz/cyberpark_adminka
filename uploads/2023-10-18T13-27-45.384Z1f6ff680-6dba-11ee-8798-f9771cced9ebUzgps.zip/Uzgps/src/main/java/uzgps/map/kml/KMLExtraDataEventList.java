package uzgps.map.kml;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 3/27/14.
 */
@XmlRootElement(name = "ExtraDataEventList")
public class KMLExtraDataEventList {
    private List<KMLExtraDataEvent> kmlExtraDataEventList;

    public KMLExtraDataEventList() {
        kmlExtraDataEventList = new ArrayList<>();
    }

    @XmlElement(name = "event")
    public List<KMLExtraDataEvent> getKmlExtraDataEventList() {
        return kmlExtraDataEventList;
    }

    public void setKmlExtraDataEventList(List<KMLExtraDataEvent> kmlExtraDataEventList) {
        this.kmlExtraDataEventList = kmlExtraDataEventList;
    }

    public boolean add(KMLExtraDataEvent kmlExtraDataEvent) {
        return kmlExtraDataEventList.add(kmlExtraDataEvent);
    }

    public int size() {
        return kmlExtraDataEventList.size();
    }

    public KMLExtraDataEvent get(int index) {
        return kmlExtraDataEventList.get(index);
    }
}
