package uzgps.map.models.notification;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectTracks;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Gayratjon on 5/7/14.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MessageNotification extends BaseNotification {

    public MessageNotification(MobjectTracks mObjectTracks, String color) {
        if (mObjectTracks.getTracks().size() > 0) {
            GPSTrackPoint gpsTrackPoint = mObjectTracks.getTracks().get(0);
            this.regDate = gpsTrackPoint.getRegDateLong();
            this.time = gpsTrackPoint.getTimestamp();
        }

        if (mObjectTracks.getMobject() != null) {
            MobjectBig mObject = mObjectTracks.getMobject();
            this.objectName = mObject.getName();
        }
        this.color = color;
    }

}
