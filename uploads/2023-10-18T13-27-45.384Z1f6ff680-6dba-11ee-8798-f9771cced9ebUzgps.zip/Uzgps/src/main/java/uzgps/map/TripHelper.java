package uzgps.map;

import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;
import uzgps.common.UZGPS_CONST;
import uzgps.map.kml.KMLExtraDataEvent;

import java.util.ArrayList;
import java.util.List;

@Deprecated
public class TripHelper {

    public List<KMLExtraDataEvent> getTripEventsForKMLExtraData(MobjectBig mobjectBig,
                                                                List<GPSTrackPoint> trackPointList) {
        if (trackPointList == null || trackPointList.size() == 0) {
            return null;
        }

        List<KMLExtraDataEvent> tripEventList = null;
        try {
            Long mObjectId = mobjectBig.getId();

            // Get default min trip time
            long minTripTime = UZGPS_CONST.MIN_TRIP_TIME_DEFAULT;

            // Get default min parking time from
//            long minParkingTime = UZGPS_CONST.MIN_PARKING_TIME_DEFAULT;
            long minParkingTime = 120000L;

//            if (mObjectSettings != null && mObjectSettings.getParkingTime() != null) {
//                minParkingTime = mObjectSettings.getParkingTime() * 1000;
//            }

            tripEventList = new ArrayList<>();

            GPSTrackPoint previousTrack;
            GPSTrackPoint currentTrack = trackPointList.get(trackPointList.size() - 1);

            boolean isStoppedMoving = false;
            KMLExtraDataEvent tripEvent = null;

//        long startStoppingTime = 0;
            GPSTrackPoint startStoppingTrack = null;

            for (int i = trackPointList.size() - 2; i >= 0; i--) {
                previousTrack = currentTrack;
                currentTrack = trackPointList.get(i);

                if (previousTrack.getSpeed() > 0) {
                    startStoppingTrack = null;

                    if (currentTrack.getSpeed() > 0) {
                        // Keeps moving...
                        if (tripEvent == null) {
                            // Put trip flag
                            tripEvent = makeTripEvent(previousTrack);
                        }
                    } else {
                        // Check if object is stopped
                        if (tripEvent != null) {
                            long tripTime = currentTrack.getDate().getTime() - tripEvent.getFromDate();

                            if ((tripTime >= minTripTime)) {
                                // Detect stop after moving
                                isStoppedMoving = true;
                            }
                        }

                    }
                } else if (previousTrack.getSpeed() == null || previousTrack.getSpeed() == 0) {
                    if (currentTrack.getSpeed() > 0) {

                        if (isStoppedMoving) {
                            long diffBetweenTracks = currentTrack.getDate().getTime() - previousTrack.getDate().getTime();

                            // stop trip
                            if (diffBetweenTracks > 3600000) {
                                addTrip(startStoppingTrack, tripEvent, previousTrack,
                                        currentTrack, mobjectBig);

                                tripEventList.add(tripEvent);

                                // Switching from move to stop
                                isStoppedMoving = false;
                                startStoppingTrack = null;
                                tripEvent = null;
                            }
                        }

                        // Object start moving
                        if (tripEvent == null) {
                            tripEvent = makeTripEvent(currentTrack);
                            startStoppingTrack = null;
                        }
                    } else {
                        // object is stopped
                        if (isStoppedMoving) {
                            long stoppedTime;

                            if (startStoppingTrack == null) {
                                stoppedTime = currentTrack.getDate().getTime() - previousTrack.getDate().getTime();
                            } else {
                                stoppedTime = currentTrack.getDate().getTime() - startStoppingTrack.getTimestamp();
                            }

                            if ((stoppedTime >= minParkingTime)) {
                                // Trip finished. Add to trip List
                                addTrip(startStoppingTrack, tripEvent, previousTrack,
                                        currentTrack, mobjectBig);

                                tripEventList.add(tripEvent);

                                // Switching from move to stop
                                isStoppedMoving = false;
                                startStoppingTrack = null;
                                tripEvent = null;
                            } else {
                                // Too short stop, continue waiting
                                if (startStoppingTrack == null) {
                                    startStoppingTrack = previousTrack;
                                }
                            }
                        } else {
                            // Object is steel stopped
                            tripEvent = null;
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return tripEventList;
    }


    private void addTrip(GPSTrackPoint startStoppingTrack, KMLExtraDataEvent tripEvent,
                         GPSTrackPoint previousTrack, GPSTrackPoint currentTrack, MobjectBig mobjectBig) {
        if (startStoppingTrack == null) {
            tripEvent.setToDate(previousTrack.getTimestamp());
            tripEvent.setGPSTrackPoint(previousTrack);
        } else {
            tripEvent.setToDate(startStoppingTrack.getTimestamp());
            tripEvent.setGPSTrackPoint(startStoppingTrack);
        }

        tripEvent.setObjectId(mobjectBig.getId());
        tripEvent.setObjectName(mobjectBig.getName());
    }

    private KMLExtraDataEvent makeTripEvent(GPSTrackPoint trackPoint) {
        if (trackPoint == null) {
            return null;
        }

        KMLExtraDataEvent parkingPoint = new KMLExtraDataEvent();
        parkingPoint.setType(2);
        parkingPoint.setLat(trackPoint.getLatitude());
        parkingPoint.setLon(trackPoint.getLongitude());
//        parkingPoint.setTimestamp(trackPoint.getTimestamp());
        parkingPoint.setTpRegDate(trackPoint.getRegDate().getTime());
        parkingPoint.setFromDate(trackPoint.getTimestamp());
        parkingPoint.setToDate(null);

        return parkingPoint;
    }

}
