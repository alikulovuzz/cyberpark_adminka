package uzgps.map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import uzgps.common.Converters;
import uzgps.persistence.MObjectPins;
import uzgps.settings.SettingsService;

/**
 * Created by Saidolim on 13.07.2017.
 */
@Controller
public class ImageSvgController {
    // base url "imgsvg"
    private final static String URL_SVG_PIN = "/pin-{idStr}-{colour}.svg";
    private final static String URL_SVG_PIN_WITH_ROTATE = "/pinr-{idStr}-{colour}-{rotate}.svg";
    private final static String URL_SVG_PIN_WITH_COLORS = "/pinc-{idStr}-{colour}-{colourInner}-{colourContour}-{colourMask}.svg";
    //    private final static String URL_SVG_PIN_BASE = "/pin-base-{idStr}-{colour}.svg";
    private final static String VIEW_FOLDER = "imgsvg/";

    @Autowired
    private SettingsService settingsService;

    @ResponseBody
    @RequestMapping(value = URL_SVG_PIN)
    public ModelAndView makeSvgimage(@PathVariable String idStr,
                                     @PathVariable String colour) {

        Long pinId = Converters.strToLong(idStr, 0L);

        MObjectPins pin = settingsService.getMObjectPinById(pinId);
        if (pin == null) return null;

        ModelAndView modelAndView = new ModelAndView(VIEW_FOLDER + pin.getIconBase());

        pin.setColorBase(strToColor(colour, pin.getColorBase()));
        pin.setColorBaseInner("#ffffff");
        modelAndView.addObject("pin", pin);

        return modelAndView;

    }

    @RequestMapping(value = URL_SVG_PIN_WITH_ROTATE)
    @ResponseBody
    public ModelAndView makeSvgImageWithRotate(@PathVariable String idStr,
                                     @PathVariable String colour,
                                     @PathVariable String rotate) {

        Long pinId = Converters.strToLong(idStr, 0L);
        Integer maskRotate = Converters.strToInt(rotate, 0);

        MObjectPins pin = settingsService.getMObjectPinById(pinId);
        if (pin == null) return null;

        ModelAndView modelAndView = new ModelAndView(VIEW_FOLDER + pin.getIconBase());

        pin.setColorBase(strToColor(colour, pin.getColorBase()));
        pin.setColorBaseInner("#ffffff");
        pin.setMaskRotate(maskRotate);
        modelAndView.addObject("pin", pin);

        return modelAndView;

    }

    @ResponseBody
    @RequestMapping(value = URL_SVG_PIN_WITH_COLORS)
    public ModelAndView makeSvgImageWithColors(@PathVariable("idStr") String idStr,
                                               @PathVariable("colour") String colour,
                                               @PathVariable("colourInner") String colourInner,
                                               @PathVariable("colourContour") String colourContour,
                                               @PathVariable("colourMask") String colourMask) {

        Long pinId = Converters.strToLong(idStr, 0L);

        MObjectPins pin = settingsService.getMObjectPinById(pinId);
        if (pin == null) return null;

        ModelAndView modelAndView = new ModelAndView(VIEW_FOLDER + pin.getIconBase());

        pin.setColorBase(strToColor(colour, pin.getColorBase()));
        pin.setColorBaseInner(strToColor(colourInner, pin.getColorBaseInner()));
        pin.setColorBaseContour(strToColor(colourContour, pin.getColorBaseContour()));
        pin.setColorMask(strToColor(colourMask, pin.getColorMask()));

        modelAndView.addObject("pin", pin);

        return modelAndView;

    }

    public String strToColor(String colorTxt, String defaultValue) {
        if (colorTxt.length() < 3) {
            return defaultValue;
        } else {
            switch (colorTxt) {
                case "big-black":
                    return "#08a0f4";
                case "black":
                    return "#000";
                case "blue":
                    return "#08a0f4";
                case "green":
                    return "#0ce202";
                case "grey":
                    return "#a8a8a8";
                case "red":
                    return "#f91249";
                case "yellow":
                    return "#ffc41d";
                default:
                    return "#" + colorTxt;
            }
        }
    }

//    @ResponseBody
//    @RequestMapping(value = URL_SVG_PIN_BASE)
//    public ModelAndView makeBaseImage(@PathVariable String idStr, @PathVariable String colour) {
//
//        Long pinId = Converters.strToLong(idStr, 0L);
//
//        MObjectPins pin = settingsService.getMObjectPinById(pinId);
//        if (pin == null) return null;
//
//        ModelAndView modelAndView = new ModelAndView(VIEW_FOLDER + pin.getIconBase());
//
//        pin.setColorBase(strToColor(colour, pin.getColorBase()));
//
//        return modelAndView;
//
//
//    }
}
