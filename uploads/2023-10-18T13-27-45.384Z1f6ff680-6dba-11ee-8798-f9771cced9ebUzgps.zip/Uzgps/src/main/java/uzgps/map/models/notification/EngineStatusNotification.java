package uzgps.map.models.notification;

/**
 * Created by Gayratjon on 9/27/14.
 */
public class EngineStatusNotification {
}
