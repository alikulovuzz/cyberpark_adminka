package uzgps.map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.admin.AdminJournal;
import uzgps.persistence.GeoFence;
import uzgps.persistence.GeoFencePoint;

import javax.persistence.*;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by Gayratjon on 3/31/14.
 */

@Service
@Component
public class GeoFenceService {

//    @Autowired
//    private AdminJournal adminJournal;

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @Transactional
    public GeoFence saveGeoFence(GeoFence geoFence) {
        if (geoFence.getId() != null) {
            entityManager.merge(geoFence);
//            if (geoFence.getStatus().equals(UZGPS_CONST.STATUS_DELETE))
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_DELETE, UZGPS_CONST.JOURNAL_GEOFANCE_DELETED, geoFence);
//            else
//                adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_GEOFANCE_UPDATED, geoFence);
        } else {
            entityManager.persist(geoFence);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_GEOFANCE_INSERT, geoFence);
        }
        return geoFence;
    }

    @Transactional
    public GeoFencePoint saveGeoFencePoint(GeoFencePoint geoFencePoint) {
        if (geoFencePoint.getId() != null) {
            entityManager.merge(geoFencePoint);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_UPDATE, UZGPS_CONST.JOURNAL_GEOFANCE_POINT_UPDATED, geoFencePoint);
        } else {
            entityManager.persist(geoFencePoint);
//            adminJournal.log(UZGPS_CONST.JOURNAL_ACT_INSERT, UZGPS_CONST.JOURNAL_GEOFANCE_POINT_INSERT, geoFencePoint);
        }
        return geoFencePoint;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<GeoFence> getGeoFenceListByContractIdAndStatus(Long contractId, String status) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<GeoFence> query;
            query = entityManager.createNamedQuery("GeoFence.getListByContractIdAndStatus", GeoFence.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<GeoFencePoint> getGeoFencePointListByGeoFenceId(Long geoFenceId) {

        if (geoFenceId == null)
            return null;

        Query query;
        query = entityManager.createNamedQuery("GeoFencePoint.getListByGeoFenceId");
        query.setParameter("geoFenceId", geoFenceId);
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional()
    public void removeGeoFencePointListByGeoFenceId(Long geoFenceId, HttpSession session) {
        if (geoFenceId != null) {
            try {
                Query query;
                query = entityManager.createNamedQuery("GeoFencePoint.removeByGeoFenceId");
                query.setParameter("geoFenceId", geoFenceId);
                query.executeUpdate();
            } catch (Exception e) {
                logger.error("Error: ", e);
            }
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public GeoFence getGeoFenceById(Long id) {
        if (id == null)
            return null;

        try {
            TypedQuery<GeoFence> query;
            query = entityManager.createNamedQuery("GeoFence.findById", GeoFence.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getGeoFenceCountByContractIdAndStatus(Long contractId, String status) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("GeoFence.getGeoFenceCountByContractIdAndStatus", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getGeoFenceNameCountByContractId(Long contractId, String status, String name) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("GeoFence.getGeoFenceCountNameByContractId", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            query.setParameter("name", name);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
}
