package uzgps.map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.datatype.MobjectBig;
import uzgps.map.kml.KMLExtraDataEvent;

import java.util.ArrayList;
import java.util.List;

public class TripHelperV2 {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public List<KMLExtraDataEvent> getTripEventsForKMLExtraData(MobjectBig mobjectBig,
                                                                List<KMLExtraDataEvent> parkings) {
        if (parkings == null || parkings.isEmpty()) {
            return null;
        }

        List<KMLExtraDataEvent> tripEventList = null;

        try {
//            Long mObjectId = mobjectBig.getId();

            // Get default min trip time
//            long minTripTime = UZGPS_CONST.MIN_TRIP_TIME_DEFAULT;

            tripEventList = new ArrayList<>();

//            boolean isStoppedMoving = false;
            KMLExtraDataEvent tripEvent;

            KMLExtraDataEvent firstParking = null;
            KMLExtraDataEvent secondParking = null;

            for (KMLExtraDataEvent parking : parkings) {
                if (firstParking == null) { // detect first parking
                    firstParking = parking;
                } else if (secondParking == null) { // detect and make first trip
                    secondParking = parking;

                    tripEvent = makeTrip(firstParking, secondParking, mobjectBig);
                    tripEventList.add(tripEvent);
                } else { // detect and make next trip
                    firstParking = secondParking;
                    secondParking = parking;

                    tripEvent = makeTrip(firstParking, secondParking, mobjectBig);
                    tripEventList.add(tripEvent);
                }
            }

        } catch (Exception e) {
            logger.error("Error in TripHelperV2", e);
        }

        return tripEventList;
    }

    private KMLExtraDataEvent makeTrip(KMLExtraDataEvent firstParking, KMLExtraDataEvent secondParking, MobjectBig mobjectBig) {
        KMLExtraDataEvent tripEvent = new KMLExtraDataEvent();

        tripEvent.setType(2);
        tripEvent.setLat(firstParking.getLat());
        tripEvent.setLon(firstParking.getLon());
        tripEvent.setTpRegDate(firstParking.getTpRegDate());

        tripEvent.setFromDate(firstParking.getToDate());
        tripEvent.setToDate(secondParking.getFromDate());

        tripEvent.setGPSTrackPoint(firstParking.getGPSTrackPoint());

        tripEvent.setObjectId(mobjectBig.getId());
        tripEvent.setObjectName(mobjectBig.getName());
        return tripEvent;
    }

}
