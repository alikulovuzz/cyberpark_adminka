package uzgps.map.models;

/**
 * Created by Saidolim on 23.01.2017.
 * <p>
 * Conditional item for Track Chart
 */
public class ChartDataCI {
    private Long time;
    private String speed;
    private String bak;
    private String engineOn;
    private int externalBattery;

    public ChartDataCI(Long time, String speed, String bak, Integer engineOn) {
        this.time = (time != null) ? time : 0;
        this.speed = speed;
        this.bak = bak;
        this.engineOn = engineOn.toString();
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public String getBak() {
        return bak;
    }

    public void setBak(String bak) {
        this.bak = bak;
    }

    public String getEngineOn() {
        return engineOn;
    }

    public void setEngineOn(String engineOn) {
        this.engineOn = engineOn;
    }

//    public void addTime(Timestamp timestamp) {
//        this.time += (timestamp != null) ? '"' + Converters.timeToStr(timestamp) + "\", " : " null, ";
//    }

    public void addSpeed(Integer value) {
        this.speed += (value != null) ? value + ", " : " null, ";
    }

    public void addBak(Double value) {
        this.bak += (value != null) ? value + ", " : " null, ";
    }

    public void addEngineOn(Integer value) {
        this.engineOn += (value != null) ? (value * 5) + ", " : " null, ";
    }

    public void addExternalBattery(Integer value) {
        this.externalBattery += (value != null) ? (value / 1000) : 0;
    }

    public int getExternalBattery() {
        return externalBattery;
    }

    public void setExternalBattery(int externalBattery) {
        this.externalBattery = externalBattery / 1000;
    }
}
