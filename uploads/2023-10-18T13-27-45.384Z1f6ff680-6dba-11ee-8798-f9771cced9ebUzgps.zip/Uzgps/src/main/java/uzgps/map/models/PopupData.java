package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GpsUnitBig;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectTracks;
import uz.netex.dbtables.Geofence;
import uz.netex.dbtables.Poi;
import uzgps.common.FileStorageService;
import uzgps.settings.SettingsService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 5/3/14.
 */

@JsonFilter("PopupDataFilter")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PopupData {
    private long objectId;
    private String objectName;
    private String objectType;
    private String objectNumber;
    private String capacity;
    @JsonIgnore
    private String fuel;
    @JsonIgnore
    private double latitude;
    @JsonIgnore
    private double longitude;
    @JsonIgnore
    private double altitude;
    private byte satellites;
    private int speed;
    private String gpsType;
    private String gpsImei;
    private String gpsPhone;
    private String staffName;
    private String staffPhone;
    private String staffPhoneMobile;
    @JsonIgnore
    private long staffPhotoId;
    @JsonIgnore
    private String staffPhoto;
    private String staffPhotoUrl;
    private List<String> zoneList;
    private Long time;
    private Integer bak1;
    private Integer bak2;
    private List<String> tripList;
    private Integer mtIndex;
    private String mtStatus;
    private String mtColor;
    private String address;

    public PopupData() {
        this.objectId = 0;
        this.objectName = "";
        this.objectType = "";
        this.objectNumber = "";
        this.capacity = "";
        this.fuel = "";
        this.latitude = 0;
        this.longitude = 0;
        this.altitude = 0;
        this.satellites = 0;
        this.speed = 0;
        this.gpsType = "";
        this.gpsImei = "";
        this.gpsPhone = "";
        this.staffName = "";
        this.staffPhotoId = 0;
        this.staffPhoto = "";
        this.staffPhotoUrl = "";
        this.staffPhone = "";
        this.staffPhoneMobile = "";
        this.zoneList = new ArrayList<>();
        this.time = null;
        this.bak1 = null;
        this.bak2 = null;
        this.tripList = new ArrayList<>();
        this.mtIndex = -1;
        this.mtStatus = null;
        this.mtColor = null;
        this.address = "address";
    }

    public PopupData(MobjectTracks mObjectTracks, SettingsService settingsService) {
        this();

        if (mObjectTracks.getTracks().size() > 0) {
            GPSTrackPoint gpsTrackPoint = mObjectTracks.getTracks().get(0);
            this.latitude = gpsTrackPoint.getLatitude();
            this.longitude = gpsTrackPoint.getLongitude();
            this.altitude = gpsTrackPoint.getAltitude();
            this.satellites = gpsTrackPoint.getSatellites();
            this.speed = gpsTrackPoint.getSpeed();
            if (gpsTrackPoint.getStaff() != null) {
                this.staffPhotoId = gpsTrackPoint.getStaff().getPhotoId();
                this.staffName = gpsTrackPoint.getStaff().getSurName() + " " + gpsTrackPoint.getStaff().getName() + " " + gpsTrackPoint.getStaff().getMiddleName();
                this.staffPhoto = gpsTrackPoint.getStaff().getPhotoFilename();
                this.staffPhone = gpsTrackPoint.getStaff().getPhoneLine();
                this.staffPhoneMobile = gpsTrackPoint.getStaff().getPhoneMobile();
            }
            this.time = gpsTrackPoint.getTimestamp();
            this.bak1 = gpsTrackPoint.getBak1();
            this.bak2 = gpsTrackPoint.getBak2();
        }

        if (mObjectTracks.getMobject() != null) {
            MobjectBig mObject = mObjectTracks.getMobject();
            this.objectId = mObject.getId();
            this.objectName = mObject.getName();
            this.objectType = mObject.getType();
            this.objectNumber = mObject.getPlateNumber();
            this.capacity = mObject.getCapacity();
            this.fuel = mObject.getFuel();

            GpsUnitBig gpsUnitBig = mObject.getGpsUnitBig();
            if (gpsUnitBig != null) {
                this.gpsType = gpsUnitBig.getTypeName();
                this.gpsImei = gpsUnitBig.getImei();
                this.gpsPhone = gpsUnitBig.getPhone();

                if (gpsUnitBig.getIsMobile() != null && gpsUnitBig.getIsMobile() == 1) {
                    this.mtIndex = 1;
//                    MobileTrackerStatus mtStatus = settingsService.getMobileTrackerStatusBySerial(gpsUnitBig.getImei());
//
//                    if (mtStatus != null) {
//                        this.mtIndex = mtStatus.getIndex();
//                        this.mtStatus = mtStatus.getName();
//                        this.mtColor = mtStatus.getColor();
//                    }
                }
            }
        }
    }

    public void setGPSTrackPoint(GPSTrackPoint gpsTrackPoint) {
        if (gpsTrackPoint != null) {
            this.latitude = gpsTrackPoint.getLatitude();
            this.longitude = gpsTrackPoint.getLongitude();
            this.altitude = gpsTrackPoint.getAltitude();
            this.satellites = gpsTrackPoint.getSatellites();
            this.speed = gpsTrackPoint.getSpeed();
            if (gpsTrackPoint.getStaff() != null) {
                this.staffPhotoId = gpsTrackPoint.getStaff().getPhotoId();
                this.staffName = gpsTrackPoint.getStaff().getSurName() + " " + gpsTrackPoint.getStaff().getName() + " " + gpsTrackPoint.getStaff().getMiddleName();
                this.staffPhoto = gpsTrackPoint.getStaff().getPhotoFilename();
                this.staffPhone = gpsTrackPoint.getStaff().getPhoneLine();
                this.staffPhoneMobile = gpsTrackPoint.getStaff().getPhoneMobile();
            }
            this.time = gpsTrackPoint.getTimestamp();
            this.bak1 = gpsTrackPoint.getBak1();
            this.bak2 = gpsTrackPoint.getBak2();
        }
    }

    public void setMobjectBig(MobjectBig mObject) {
        if (mObject != null) {
            this.objectId = mObject.getId();
            this.objectName = mObject.getName();
            this.objectType = mObject.getType();
            this.objectNumber = mObject.getPlateNumber();
            this.capacity = mObject.getCapacity();
            this.fuel = mObject.getFuel();
            this.gpsType = mObject.getGpsUnitBig().getTypeName();
            this.gpsImei = mObject.getGpsUnitBig().getImei();
            this.gpsPhone = mObject.getGpsUnitBig().getPhone();
        }
    }

    public void setPoiAndGeoFenceList(List<Poi> poiList, List<Geofence> geofenceList) {
        if (poiList != null) {
            for (Poi poi : poiList) {
                if (poi != null) {
                    zoneList.add(poi.getName());
                }
            }
        }

        if (geofenceList != null) {
            for (Geofence geofence : geofenceList) {
                if (geofence != null) {
                    zoneList.add(geofence.getName());
                }
            }
        }
    }

    public long getObjectId() {
        return objectId;
    }

    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectNumber() {
        return objectNumber;
    }

    public void setObjectNumber(String objectNumber) {
        this.objectNumber = objectNumber;
    }

    public String getCapacity() {
        return capacity;
    }

    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }

    public String getFuel() {
        return fuel;
    }

    public void setFuel(String fuel) {
        this.fuel = fuel;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public double getAltitude() {
        return altitude;
    }

    public void setAltitude(double altitude) {
        this.altitude = altitude;
    }

    public byte getSatellites() {
        return satellites;
    }

    public void setSatellites(byte satellites) {
        this.satellites = satellites;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public String getGpsType() {
        return gpsType;
    }

    public void setGpsType(String gpsType) {
        this.gpsType = gpsType;
    }

    public String getGpsImei() {
        return gpsImei;
    }

    public void setGpsImei(String gpsImei) {
        this.gpsImei = gpsImei;
    }

    public String getGpsPhone() {
        return gpsPhone;
    }

    public void setGpsPhone(String gpsPhone) {
        this.gpsPhone = gpsPhone;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffPhoto() {
        return staffPhoto;
    }

    public void setStaffPhoto(String staffPhoto) {
        this.staffPhoto = staffPhoto;
    }

    public String getStaffPhone() {
        return staffPhone;
    }

    public void setStaffPhone(String staffPhone) {
        this.staffPhone = staffPhone;
    }

    public long getStaffPhotoId() {
        return staffPhotoId;
    }

    public void setStaffPhotoId(long staffPhotoId) {
        this.staffPhotoId = staffPhotoId;
    }

    public String getStaffPhotoUrl() {
        this.staffPhotoUrl = (this.staffPhotoId != 0 && !"".equals(this.staffPhoto)) ? FileStorageService.generateFileName(this.staffPhotoId, this.staffPhoto) : "";
        return staffPhotoUrl;
    }

    public void setStaffPhotoUrl(String staffPhotoUrl) {
        this.staffPhotoUrl = staffPhotoUrl;
    }

    public List<String> getZoneList() {
        return zoneList;
    }

    public void setZoneList(List<String> zoneList) {
        this.zoneList = zoneList;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Integer getBak1() {
        return bak1;
    }

    public void setBak1(Integer bak1) {
        this.bak1 = bak1;
    }

    public Integer getBak2() {
        return bak2;
    }

    public void setBak2(Integer bak2) {
        this.bak2 = bak2;
    }

    public List<String> getTripList() {
        return tripList;
    }

    public void setTripList(List<String> tripList) {
        this.tripList = tripList;
    }

    public String getStaffPhoneMobile() {
        return staffPhoneMobile;
    }

    public void setStaffPhoneMobile(String staffPhoneMobile) {
        this.staffPhoneMobile = staffPhoneMobile;
    }

    public Integer getMtIndex() {
        return mtIndex;
    }

    public void setMtIndex(Integer mtIndex) {
        this.mtIndex = mtIndex;
    }

    public String getMtStatus() {
        return mtStatus;
    }

    public void setMtStatus(String mtStatus) {
        this.mtStatus = mtStatus;
    }

    public String getMtColor() {
        return mtColor;
    }

    public void setMtColor(String mtColor) {
        this.mtColor = mtColor;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
