package uzgps.map.kml;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by Gayratjon on 1/30/14.
 */
@XmlRootElement(name = "Style")
public class KMLStyle {

    private String id;
    private KMLLineStyle kmlLineStyle;

    @XmlAttribute(name = "id")
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @XmlElement(name = "LineStyle")
    public KMLLineStyle getKmlLineStyle() {
        return kmlLineStyle;
    }

    public void setKmlLineStyle(KMLLineStyle kmlLineStyle) {
        this.kmlLineStyle = kmlLineStyle;
    }
}
