package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MObjectTrackDataJSONList {

    @JsonProperty("data")
    List<MObjectTrackDataJSON> mObjectTrackDataJSONList = null;
    @JsonProperty("nextUpdTime")
    Long nextUpdTime = 0L; // Client will give this date next time

    public List<MObjectTrackDataJSON> getmObjectTrackDataJSONList() {
        return mObjectTrackDataJSONList;
    }

    public void setmObjectTrackDataJSONList(List<MObjectTrackDataJSON> mObjectTrackDataJSONList) {
        this.mObjectTrackDataJSONList = mObjectTrackDataJSONList;
    }

    public Long getNextUpdTime() {
        return nextUpdTime;
    }

    public void setNextUpdTime(Long nextUpdTime) {
        this.nextUpdTime = nextUpdTime;
    }

    public void newArrayList(){
        mObjectTrackDataJSONList = new ArrayList<>();
    }

    public boolean add(MObjectTrackDataJSON mObjectTrackDataJSON) {
        return mObjectTrackDataJSONList.add(mObjectTrackDataJSON);
    }
}
