package uzgps.map.models;

import uz.netex.datatype.GpsUnitBig;
import uz.netex.datatype.MobjectBig;

import javax.management.monitor.Monitor;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/**
 * Created by Gayratjon on 6/2/2016.
 */
public class MobjectBigZoned implements Comparable<MobjectBigZoned> {
    private MobjectBig mobjectBig;
    private MonitorData monitorData;

    public MobjectBigZoned() {
    }

    public MobjectBig getMobjectBig() {
        return mobjectBig;
    }

    public void setMobjectBig(MobjectBig mobjectBig) {
        this.mobjectBig = mobjectBig;
    }

    public Long getId() {
        return mobjectBig.getId();
    }

    public void setStatusOnline(Integer statusOnline) {
        mobjectBig.setStatusOnline(statusOnline);
    }

    public void setName(String name) {
        mobjectBig.setName(name);
    }

    public Integer getFuelShowOnSpeed() {
        return mobjectBig.getFuelShowOnSpeed();
    }

    public void setType(String type) {
        mobjectBig.setType(type);
    }

    public Integer getStatusEngineOn() {
        return mobjectBig.getStatusEngineOn();
    }

    public Integer getFuelShowOnSpeedValue() {
        return mobjectBig.getFuelShowOnSpeedValue();
    }

    public void setLabelSize(Long labelSize) {
        mobjectBig.setLabelSize(labelSize);
    }

    public Long getLabelSize() {
        return mobjectBig.getLabelSize();
    }

    public Boolean isDefaultIcon() {
        return mobjectBig.isDefaultIcon();
    }

    public void setSpeedMax(Long speedMax) {
        mobjectBig.setSpeedMax(speedMax);
    }

    public void setColorDefault(String colorDefault) {
        mobjectBig.setColorDefault(colorDefault);
    }

    public Integer getStatusOnline() {
        return mobjectBig.getStatusOnline();
    }

    public void setStatusDat(Integer statusDat) {
        mobjectBig.setStatusDat(statusDat);
    }

    public void setOnlineTime(Long onlineTime) {
        mobjectBig.setOnlineTime(onlineTime);
    }

    public void setId(Long id) {
        mobjectBig.setId(id);
    }

    public void setSettingsId(Long settingsId) {
        mobjectBig.setSettingsId(settingsId);
    }

    public void setContractId(Long contractId) {
        mobjectBig.setContractId(contractId);
    }

    public void setFuel(String fuel) {
        mobjectBig.setFuel(fuel);
    }

    public void setFuelShowOnSpeedValue(Integer fuelShowOnSpeedValue) {
        mobjectBig.setFuelShowOnSpeedValue(fuelShowOnSpeedValue);
    }

    public String getGroupName() {
        return mobjectBig.getGroupName();
    }

    public Long getContractId() {
        return mobjectBig.getContractId();
    }

    public void setGpsUnitId(Long gpsUnitId) {
        mobjectBig.setGpsUnitId(gpsUnitId);
    }

    public Long getSpeedMax() {
        return mobjectBig.getSpeedMax();
    }

    public GpsUnitBig getGpsUnitBig() {
        return mobjectBig.getGpsUnitBig();
    }

    public void setGpsUnitBig(GpsUnitBig gpsUnitBig) {
        mobjectBig.setGpsUnitBig(gpsUnitBig);
    }

    public Integer getStatusMovement() {
        return mobjectBig.getStatusMovement();
    }

    public Long getGroupId() {
        return mobjectBig.getGroupId();
    }

    public void setDefaultIcon(Boolean defaultIcon) {
        mobjectBig.setDefaultIcon(defaultIcon);
    }

    public Integer getStatusSatellites() {
        return mobjectBig.getStatusSatellites();
    }

    public String getName() {
        return mobjectBig.getName();
    }

    public void setStatusMovement(Integer statusMovement) {
        mobjectBig.setStatusMovement(statusMovement);
    }

    public Long getPinId() {
        return mobjectBig.getPinId();
    }

    public String getFuel() {
        return mobjectBig.getFuel();
    }

    public void setPinId(Long pinId) {
        mobjectBig.setPinId(pinId);
    }

    public String getCapacity() {
        return mobjectBig.getCapacity();
    }

    public void setGroupId(Long groupId) {
        mobjectBig.setGroupId(groupId);
    }

    public Integer getStatusDat() {
        return mobjectBig.getStatusDat();
    }

    public void setFuelShowOnEngineon(Integer fuelShowOnEngineon) {
        mobjectBig.setFuelShowOnEngineon(fuelShowOnEngineon);
    }

    public String getType() {
        return mobjectBig.getType();
    }

    public Integer getFuelShowOnEngineon() {
        return mobjectBig.getFuelShowOnEngineon();
    }

    public void setStatusEngineOn(Integer statusEngineOn) {
        mobjectBig.setStatusEngineOn(statusEngineOn);
    }

    public void setPhotoName(String photoName) {
        mobjectBig.setPhotoName(photoName);
    }

    public Long getSettingsId() {
        return mobjectBig.getSettingsId();
    }

    public void setGroupName(String groupName) {
        mobjectBig.setGroupName(groupName);
    }

    public String getColorDefault() {
        return mobjectBig.getColorDefault();
    }

    public void clone(MobjectBig mobjectBig) {
        this.mobjectBig.clone(mobjectBig);
    }

    public void setParkingTime(Long parkingTime) {
        mobjectBig.setParkingTime(parkingTime);
    }

    public void setPhotoId(Long photoId) {
        mobjectBig.setPhotoId(photoId);
    }

    public String getPlateNumber() {
        return mobjectBig.getPlateNumber();
    }

    public void setPlateNumber(String plateNumber) {
        mobjectBig.setPlateNumber(plateNumber);
    }

    public void setFuelShowOnSpeed(Integer fuelShowOnSpeed) {
        mobjectBig.setFuelShowOnSpeed(fuelShowOnSpeed);
    }

    public void setCapacity(String capacity) {
        mobjectBig.setCapacity(capacity);
    }

    public Long getPhotoId() {
        return mobjectBig.getPhotoId();
    }

    public void setStatusSatellites(Integer statusSatellites) {
        mobjectBig.setStatusSatellites(statusSatellites);
    }

    public Long getParkingTime() {
        return mobjectBig.getParkingTime();
    }

    public String getPhotoName() {
        return mobjectBig.getPhotoName();
    }

    public Long getOnlineTime() {
        return mobjectBig.getOnlineTime();
    }

    public Long getGpsUnitId() {
        return mobjectBig.getGpsUnitId();
    }

    public MobjectBigZoned(MonitorData monitorData) {
        this.monitorData = monitorData;
    }

    public MonitorData getMonitorData() {
        return monitorData;
    }

    public void setMonitorData(MonitorData monitorData) {
        this.monitorData = monitorData;
    }

    public byte getMovement() {
        return monitorData.getMovement();
    }

    public void setStaffPhoto(String staffPhoto) {
        monitorData.setStaffPhoto(staffPhoto);
    }

    public int getSpeed() {
        return monitorData.getSpeed();
    }

    public void setStaffName(String staffName) {
        monitorData.setStaffName(staffName);
    }

    public void setDat(byte dat) {
        monitorData.setDat(dat);
    }

    public double getLatitude() {
        return monitorData.getLatitude();
    }

    public Integer getOdometer() {
        return monitorData.getOdometer();
    }

    public String getStaffPhoneMobile() {
        return monitorData.getStaffPhoneMobile();
    }

    public long getObjectPhotoId() {
        return monitorData.getObjectPhotoId();
    }

    public void setDigital1(Byte digital1) {
        monitorData.setDigital1(digital1);
    }

    public byte getOnline() {
        return monitorData.getOnline();
    }

    public void setOdometer(Integer odometer) {
        monitorData.setOdometer(odometer);
    }

    public String getObjectPhotoUrl() {
        return monitorData.getObjectPhotoUrl();
    }

    public Double getExternalPowerVoltageDouble() {
        return monitorData.getExternalPowerVoltageDouble();
    }

    public void setStaffPhone(String staffPhone) {
        monitorData.setStaffPhone(staffPhone);
    }

    public Byte getMovementValue() {
        return monitorData.getMovementValue();
    }

    public Integer getBak1() {
        return monitorData.getBak1();
    }

    public Short getInternalBatteryVoltage() {
        return monitorData.getInternalBatteryVoltage();
    }

    public void setCanFuelConsumption(Long canFuelConsumption) {
        monitorData.setCanFuelConsumption(canFuelConsumption);
    }

    public void setCanFuelLevelLiter(Integer canFuelLevelLiter) {
        monitorData.setCanFuelLevelLiter(canFuelLevelLiter);
    }

    public Byte getDigital1() {
        return monitorData.getDigital1();
    }

    public void setObjectName(String objectName) {
        monitorData.setObjectName(objectName);
    }

    public Byte getDigital2() {
        return monitorData.getDigital2();
    }

    public void setGsmSignalLevel(Byte gsmSignalLevel) {
        monitorData.setGsmSignalLevel(gsmSignalLevel);
    }

    public Byte getDigital3() {
        return monitorData.getDigital3();
    }

    public String getStaffPhone() {
        return monitorData.getStaffPhone();
    }

    public byte getDat() {
        return monitorData.getDat();
    }

    public void setDigital3(Byte digital3) {
        monitorData.setDigital3(digital3);
    }

    public Short getSpeedometer() {
        return monitorData.getSpeedometer();
    }

    public double getLongitude() {
        return monitorData.getLongitude();
    }

    public long getObjectId() {
        return monitorData.getObjectId();
    }

    public void setExternalPowerVoltageDouble(Double externalPowerVoltageDouble) {
        monitorData.setExternalPowerVoltageDouble(externalPowerVoltageDouble);
    }

    public double getAltitude() {
        return monitorData.getAltitude();
    }

    public void setStaffId(long staffId) {
        monitorData.setStaffId(staffId);
    }

    public void setCanFuelLevelPercentage(Integer canFuelLevelPercentage) {
        monitorData.setCanFuelLevelPercentage(canFuelLevelPercentage);
    }

    public void setAreaCode(Short areaCode) {
        monitorData.setAreaCode(areaCode);
    }

    public void setObjectLabelSize(long objectLabelSize) {
        monitorData.setObjectLabelSize(objectLabelSize);
    }

    public void setCurrentOperatorCode(Integer currentOperatorCode) {
        monitorData.setCurrentOperatorCode(currentOperatorCode);
    }

    public long getObjectLabelSize() {
        return monitorData.getObjectLabelSize();
    }

    public long getStaffPhotoId() {
        return monitorData.getStaffPhotoId();
    }

    public Short getCellId() {
        return monitorData.getCellId();
    }

    public Integer getTotalIndicationDut() {
        return monitorData.getTotalIndicationDut();
    }

    public void setPinId(long pinId) {
        monitorData.setPinId(pinId);
    }

    public void setCountSms(Long countSms) {
        monitorData.setCountSms(countSms);
    }

    public void setOnline(byte online) {
        monitorData.setOnline(online);
    }

    public void setPcbTemperature(Integer pcbTemperature) {
        monitorData.setPcbTemperature(pcbTemperature);
    }

    public void setInternalBatteryVoltage(Short internalBatteryVoltage) {
        monitorData.setInternalBatteryVoltage(internalBatteryVoltage);
    }

    public void setGpsPdop(Short gpsPdop) {
        monitorData.setGpsPdop(gpsPdop);
    }

    public void setSatellites(byte satellites) {
        monitorData.setSatellites(satellites);
    }

    public void setObjectLabel(String objectLabel) {
        monitorData.setObjectLabel(objectLabel);
    }

    public Integer getBak2() {
        return monitorData.getBak2();
    }

    public String getObjectLabel() {
        return monitorData.getObjectLabel();
    }

    public void setLatitude(double latitude) {
        monitorData.setLatitude(latitude);
    }

    public String getStaffPhoto() {
        return monitorData.getStaffPhoto();
    }

    public Integer getCanFuelLevelPercentage() {
        return monitorData.getCanFuelLevelPercentage();
    }

    public void setGnssStatus(Byte gnssStatus) {
        monitorData.setGnssStatus(gnssStatus);
    }

    public void setTotalIndicationDut(Integer totalIndicationDut) {
        monitorData.setTotalIndicationDut(totalIndicationDut);
    }

    public Long getCountSms() {
        return monitorData.getCountSms();
    }

    public String getObjectName() {
        return monitorData.getObjectName();
    }

    public void setBak2(Integer bak2) {
        monitorData.setBak2(bak2);
    }

    public long getStaffId() {
        return monitorData.getStaffId();
    }

    public void setGroupId(long groupId) {
        monitorData.setGroupId(groupId);
    }

    public void setAltitude(double altitude) {
        monitorData.setAltitude(altitude);
    }

    public String getStaffPhotoUrl() {
        return monitorData.getStaffPhotoUrl();
    }

    public void setStaffPhotoUrl(String staffPhotoUrl) {
        monitorData.setStaffPhotoUrl(staffPhotoUrl);
    }

    public void setObjectPhotoUrl(String objectPhotoUrl) {
        monitorData.setObjectPhotoUrl(objectPhotoUrl);
    }

    public void setDigital2(Byte digital2) {
        monitorData.setDigital2(digital2);
    }

    public void setMovement(byte movement) {
        monitorData.setMovement(movement);
    }

    public Double getInternalBatteryVoltageDouble() {
        return monitorData.getInternalBatteryVoltageDouble();
    }

    public Short getGpsPdop() {
        return monitorData.getGpsPdop();
    }

    public void setAnalog1(Short analog1) {
        monitorData.setAnalog1(analog1);
    }

    public void setObjectId(long objectId) {
        monitorData.setObjectId(objectId);
    }

    public void setEngineOn(byte engineOn) {
        monitorData.setEngineOn(engineOn);
    }

    public Short getAnalog1() {
        return monitorData.getAnalog1();
    }

    public void setCellId(Short cellId) {
        monitorData.setCellId(cellId);
    }

    public void setObjectPhotoName(String objectPhotoName) {
        monitorData.setObjectPhotoName(objectPhotoName);
    }

    public Short getAreaCode() {
        return monitorData.getAreaCode();
    }

    public Boolean getDefaultIcon() {
        return monitorData.getDefaultIcon();
    }

    public void setInternalBatteryVoltageDouble(Double internalBatteryVoltageDouble) {
        monitorData.setInternalBatteryVoltageDouble(internalBatteryVoltageDouble);
    }

    public void setSpeed(int speed) {
        monitorData.setSpeed(speed);
    }

    public Short getGpsHdop() {
        return monitorData.getGpsHdop();
    }

    public Byte getGnssStatus() {
        return monitorData.getGnssStatus();
    }

    public Integer getCurrentOperatorCode() {
        return monitorData.getCurrentOperatorCode();
    }

    public void setStaffPhoneMobile(String staffPhoneMobile) {
        monitorData.setStaffPhoneMobile(staffPhoneMobile);
    }

    public void setStaffPhotoId(long staffPhotoId) {
        monitorData.setStaffPhotoId(staffPhotoId);
    }

    public void setMovementValue(Byte movementValue) {
        monitorData.setMovementValue(movementValue);
    }

    public byte getEngineOn() {
        return monitorData.getEngineOn();
    }

    public void setExternalPowerVoltage(Short externalPowerVoltage) {
        monitorData.setExternalPowerVoltage(externalPowerVoltage);
    }

    public Byte getGsmSignalLevel() {
        return monitorData.getGsmSignalLevel();
    }

    public void setDate(long date) {
        monitorData.setDate(date);
    }

    public Long getCanFuelConsumption() {
        return monitorData.getCanFuelConsumption();
    }

    public Short getExternalPowerVoltage() {
        return monitorData.getExternalPowerVoltage();
    }

    public String getObjectPhotoName() {
        return monitorData.getObjectPhotoName();
    }

    public void setGpsHdop(Short gpsHdop) {
        monitorData.setGpsHdop(gpsHdop);
    }

    public Integer getCanFuelLevelLiter() {
        return monitorData.getCanFuelLevelLiter();
    }

    public byte getSatellites() {
        return monitorData.getSatellites();
    }

    public long getDate() {
        return monitorData.getDate();
    }

    public void setSpeedometer(Short speedometer) {
        monitorData.setSpeedometer(speedometer);
    }

    public String getStaffName() {
        return monitorData.getStaffName();
    }

    public Integer getPcbTemperature() {
        return monitorData.getPcbTemperature();
    }

    public void setLongitude(double longitude) {
        monitorData.setLongitude(longitude);
    }

    public void setObjectPhotoId(long objectPhotoId) {
        monitorData.setObjectPhotoId(objectPhotoId);
    }

    public void setBak1(Integer bak1) {
        monitorData.setBak1(bak1);
    }

    public String dateStr() {
        return dateInFullFormat(getDate());
    }

    /**
     * Format date in 'dd.MM.yyyy HH:mm:ss'
     * @param dateLong
     * @return
     */
    private String dateInFullFormat(Long dateLong) {
        if (dateLong != null) {
            Date date = new Date(dateLong);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

            return dateFormat.format(date);
        }

        return  null;
    }
    /**
     * For sorting we need this.
     *
     * @param o outside object
     * @return for search
     */
    @Override
    public int compareTo(MobjectBigZoned o) {
        return this.mobjectBig.getName().compareToIgnoreCase(o.getName());
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.mobjectBig.getId());
        return hash;
    }

    /**
     * Uses for list to remove element by id
     *
     * @param obj
     * @return is equal or not
     */
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final MobjectBig other = (MobjectBig) obj;
        return Objects.equals(this.mobjectBig.getGpsUnitId(), other.getGpsUnitId());
    }

}
