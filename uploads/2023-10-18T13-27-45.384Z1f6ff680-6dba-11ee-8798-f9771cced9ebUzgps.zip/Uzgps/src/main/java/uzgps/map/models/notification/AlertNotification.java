package uzgps.map.models.notification;

import com.fasterxml.jackson.annotation.JsonIgnore;
import uz.netex.datatype.PoiNotification;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Gayratjon on 5/14/14.
 */
public class AlertNotification extends BaseNotification {
    @JsonIgnore
    private PoiNotification poiNotification;
    private int zoneType;
    private long zoneId;
    private String zoneName;
    private int direction;

    public AlertNotification(PoiNotification poiNotification) {
        if (poiNotification != null) {
            this.poiNotification = poiNotification;
            this.time = poiNotification.getTimeLong();

            Date date = new Date(this.time);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

            this.formattedTime = dateFormat.format(date);

            if (this.poiNotification.getMobjectBig() != null) {
                this.objectId = this.poiNotification.getMobjectBig().getId();
                this.objectName = this.poiNotification.getMobjectBig().getName();
            }

            zoneType = this.poiNotification.getType();
            if (this.poiNotification.getType() == this.poiNotification.TYPE_POI) {
                this.zoneName = getPoiName();
                this.zoneId = getPoiId();
            } else if (this.poiNotification.getType() == this.poiNotification.TYPE_FANCE) {
                this.zoneName = getGeoFenceName();
                this.zoneId = getGeoFenceId();
            }

            this.direction = this.poiNotification.getDirection();

            if (this.poiNotification.getMobjectNotifications() != null)
                this.shouldPopup = this.poiNotification.getMobjectNotifications().isPopUpWindow();
        }
    }

    private String getMObjectName() {
        if (this.poiNotification.getMobjectBig() != null)
            return this.poiNotification.getMobjectBig().getName();

        return null;
    }

    private String getPoiName() {
        if (this.poiNotification.getPoi() != null)
            return this.poiNotification.getPoi().getName();

        return null;
    }

    private long getPoiId() {
        if (this.poiNotification.getPoi() != null)
            return this.poiNotification.getPoi().getId();

        return 0L;
    }

    private String getGeoFenceName() {
        if (this.poiNotification.getGeofence() != null)
            return this.poiNotification.getGeofence().getName();

        return null;
    }

    private long getGeoFenceId() {
        if (this.poiNotification.getGeofence() != null)
            return this.poiNotification.getGeofence().getId();

        return 0L;
    }

    public String getFormattedTime() {
        Date date = new Date(this.time);
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        formattedTime = dateFormat.format(date);

        return formattedTime;
    }

    public void setFormattedTime(String formattedTime) {
        this.formattedTime = formattedTime;
    }

    public long getZoneId() {
        return zoneId;
    }

    public void setZoneId(long zoneId) {
        this.zoneId = zoneId;
    }

    public PoiNotification getPoiNotification() {
        return poiNotification;
    }

    public void setPoiNotification(PoiNotification poiNotification) {
        this.poiNotification = poiNotification;
    }

    public int getZoneType() {
        return zoneType;
    }

    public void setZoneType(int zoneType) {
        this.zoneType = zoneType;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }


}
