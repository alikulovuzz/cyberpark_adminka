package uzgps.map.models;


/**
 * Created by Gayratjon on 2/11/2016.
 */
public class ResponsePins {
    String parkingPins = null;
    String sosPins = null;

    public String getParkingPins() {
        return parkingPins;
    }

    public void setParkingPins(String parkingPins) {
        this.parkingPins = parkingPins;
    }

    public String getSosPins() {
        return sosPins;
    }

    public void setSosPins(String sosPins) {
        this.sosPins = sosPins;
    }
}
