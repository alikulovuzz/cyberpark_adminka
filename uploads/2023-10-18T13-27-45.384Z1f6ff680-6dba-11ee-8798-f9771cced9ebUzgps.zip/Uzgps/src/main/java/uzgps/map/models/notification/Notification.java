package uzgps.map.models.notification;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Gayratjon on 5/7/14.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
abstract class Notification implements Comparable<Notification> {

    protected Long objectId;
    protected String objectName;
    protected Long time;
    protected Long tpTime;
    //    @JsonIgnore
    protected String formattedTime;
    protected Integer eventType;
    protected Integer messageType;
    protected Boolean shouldPopup;
    protected String color;
    protected Long regDate;
    @JsonProperty("dt_reg")
    protected String regDateFormatted;
    protected Integer soundId;

    protected Notification() {
        this.objectId = null;
        this.objectName = null;
        this.time = null;
        this.formattedTime = null;
        this.eventType = null;
        this.messageType = null;
        this.shouldPopup = null;
        this.regDate = null;
        this.soundId = null;
    }

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
        this.formattedTime = getFormattedTime();
    }

    public Long getTpTime() {
        return tpTime;
    }

    public void setTpTime(Long tpTime) {
        this.tpTime = tpTime;
    }

    public String getFormattedTime() {
        if (this.time != null) {
            Date date = new Date(this.time);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            formattedTime = dateFormat.format(date);
        }
        return formattedTime;
    }

    public void setFormattedTime(String formattedTime) {
        this.formattedTime = formattedTime;
    }

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }

    public Integer getMessageType() {
        return messageType;
    }

    public void setMessageType(Integer messageType) {
        this.messageType = messageType;
    }

    public Boolean getShouldPopup() {
        return shouldPopup;
    }

    public void setShouldPopup(Boolean shouldPopup) {
        this.shouldPopup = shouldPopup;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Long getRegDate() {
        return regDate;
    }

    public void setRegDate(Long regDate) {
        this.regDate = regDate;
        this.regDateFormatted = getFormattedDate(regDate);
    }

    public String getRegDateFormatted() {
        return regDateFormatted;
    }

    public void setRegDateFormatted(String regDateFormatted) {
        this.regDateFormatted = regDateFormatted;
    }

    public Integer getSoundId() {
        return soundId;
    }

    public void setSoundId(Integer soundId) {
        this.soundId = soundId;
    }

    public String getFormattedDate(Long datetime) {
        if (datetime != null) {
            Date date = new Date(datetime);
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            return dateFormat.format(date);
        }
        return null;
    }
}
