package uzgps.map.kml;

import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.GPSTrackPointList;
import uz.netex.datatype.MobjectBig;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.map.TrackingController.SpeedColor;
import uzgps.map.TrackingController.SpeedColor.SpeedColorItem;
import uzgps.persistence.CustomDistancesForTracking;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.OptionalInt;
import java.util.stream.IntStream;

/**
 * Created by Gayratjon on 1/29/14.
 */

@SuppressWarnings("UnnecessaryLocalVariable")
@XmlRootElement(name = "kml")
public class KMLObjectTrack {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private KMLExtraDataList kmlExtraDataList;
    private List<KMLStyle> kmlStyleList;
    private KMLFolder kmlFolder;
    private List<KMLExtraDataEvent> kmlExtraDataEvents;

    public KMLObjectTrack() {
    }

    public KMLObjectTrack(MobjectBig mobject, GPSTrackPointList gpsTrackPointList, SpeedColor speedColor, String trackTypeColor,
                          String color, Integer lineWidth, int pointsPerTrack, List<CustomDistancesForTracking> distancesList,
                          int trackViewType, List<KMLExtraDataEvent> kmlExtraDataEvents) {
        this.kmlExtraDataEvents = kmlExtraDataEvents;

        kmlExtraDataList = new KMLExtraDataList();
//        kmlExtraDataList.add(kmlExtraData(gpsTrackPointList, mobject));
        kmlStyleList = makeKmlStyleList(speedColor, trackTypeColor, color, lineWidth);
        kmlFolder = new KMLFolder();

        if (trackViewType == UZGPS_CONST.TRACK_VIEW_TYPE.ALL.getValue()) {
            kmlExtraDataList.add(kmlExtraData(gpsTrackPointList, mobject));
            generateDataByTrackViewTypeAll(mobject, gpsTrackPointList, speedColor, trackTypeColor, color, lineWidth, distancesList);
        } else if (trackViewType == UZGPS_CONST.TRACK_VIEW_TYPE.BY_DAY.getValue()) {
            generateDataByTrackViewTypeDays(mobject, gpsTrackPointList, speedColor, trackTypeColor, color, lineWidth, distancesList);
        } else if (trackViewType == UZGPS_CONST.TRACK_VIEW_TYPE.BY_DAY_AND_TRIP_PARKING.getValue()) {
            generateDataByTrackViewTypeDays(mobject, gpsTrackPointList, speedColor, trackTypeColor, color, lineWidth, distancesList);
        }

    }

    /**
     * Generate KML data as one row for all tracks
     *
     * @param mobject
     * @param gpsTrackPointList
     * @param speedColor
     * @param trackTypeColor
     * @param color
     * @param lineWidth
     * @param distancesList
     */
    private void generateDataByTrackViewTypeAll(MobjectBig mobject, GPSTrackPointList gpsTrackPointList, SpeedColor speedColor, String trackTypeColor,
                                                String color, Integer lineWidth, List<CustomDistancesForTracking> distancesList) {
        int POINTS_PER_TRACK = 1000;

        List<GPSTrackPoint> trackPointList = gpsTrackPointList.getGpsTrackPoints();

        if (trackPointList != null && trackPointList.size() > 0) {
            POINTS_PER_TRACK = trackPointList.size();
        }

        if (trackTypeColor.equalsIgnoreCase("solid")) {
            KMLPlacemark kmlPlacemark = new KMLPlacemark();
            kmlPlacemark.setStyleUrl("solid" + "-#-" + lineWidth);

            KMLTrack kmlTrack = kmlPlacemark.getKmlTrack();

            // Reverse track points in ascending order by dates
            if (trackPointList != null && trackPointList.size() > 0) {
                trackPointList = Lists.reverse(trackPointList);
            }

            GPSTrackPoint gpsTrackPoint = null;

            double distanceAllTracks = 0;
            for (CustomDistancesForTracking customDistancesForTracking : distancesList) {
                distanceAllTracks += customDistancesForTracking.getDistance();
            }

            if (trackPointList != null) {
                for (int i = 0; i < trackPointList.size(); i++) {
                    if (i < POINTS_PER_TRACK) {
                        gpsTrackPoint = trackPointList.get(i);
                        fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
                    }

                    if (i % POINTS_PER_TRACK == 0 && POINTS_PER_TRACK <= i) {
                        int fromPoint = i - POINTS_PER_TRACK;
                        int toPoint = i;
                        Date fromDate = trackPointList.get(toPoint - 1).getDate();
                        Date toDate = trackPointList.get(fromPoint).getDate();


                        KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(),
                                simpleDateFormat(fromDate), simpleDateFormat(toDate), fromPoint + 1,
                                toPoint, POINTS_PER_TRACK, distanceAllTracks, null);
                        kmlExtraDataList.add(kmlExtraData);
                    }

                    if (i == trackPointList.size() - 1) {
                        int length = trackPointList.size();

                        if (length == POINTS_PER_TRACK) {
                            length--;
                        }

                        int fromPoint = (length / POINTS_PER_TRACK) * POINTS_PER_TRACK;
                        int toPoint = i;
                        Date fromDate = trackPointList.get(toPoint).getDate();
                        Date toDate = trackPointList.get(fromPoint).getDate();

                        KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(), simpleDateFormat(fromDate),
                                simpleDateFormat(toDate),
                                fromPoint + 1,
                                toPoint + 1,
                                toPoint - fromPoint,
                                distanceAllTracks, null);
                        kmlExtraDataList.add(kmlExtraData);
                    }
                }
            }

            kmlPlacemark.setKmlTrack(kmlTrack);
            while (kmlTrack.size() < 3 && gpsTrackPoint != null) {
                fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
            }

            setKmlExtraDataDistance(kmlExtraDataList, distanceAllTracks);
            kmlFolder.add(kmlPlacemark);
        } else {
            trackPointList = gpsTrackPointList.getGpsTrackPoints();

            // Reverse track points in ascending order by dates
            if (trackPointList != null && trackPointList.size() > 0) {
                trackPointList = Lists.reverse(trackPointList);
            }

            KMLPlacemark kmlPlacemark = null;
            SpeedColorItem speedColorItem = null;
            GPSTrackPoint gpsTrackPoint = null;

            double distanceAllTracks = 0;
            for (CustomDistancesForTracking customDistancesForTracking : distancesList) {
                distanceAllTracks += customDistancesForTracking.getDistance();
            }

            if (trackPointList != null) {
                for (int i = 0; i < trackPointList.size(); i++) {
                    if (i < POINTS_PER_TRACK) {
                        gpsTrackPoint = trackPointList.get(i);
                    }

                    if (kmlPlacemark == null && gpsTrackPoint != null && gpsTrackPoint.getSpeed() != null) {
                        int speed = gpsTrackPoint.getSpeed();

                        kmlPlacemark = new KMLPlacemark();
                        kmlPlacemark.setName(gpsTrackPoint.getDate().toString());
                        speedColorItem = speedColor.getSpeedColorItemBySpeed(speed);
                        kmlPlacemark.setStyleUrl(speedColorItem.getStyleIdForSpeedColorItem() + "-#-" + lineWidth);

                        KMLTrack kmlTrack = kmlPlacemark.getKmlTrack();

                        if (i - 1 >= 0) {
                            GPSTrackPoint prevGpsTrackPoint = trackPointList.get(i - 1);
                            fillKmlTrackWithGpsTrackPoint(kmlTrack, prevGpsTrackPoint);
                        }
                    }

                    if (kmlPlacemark != null) {
                        KMLTrack kmlTrack = kmlPlacemark.getKmlTrack();
                        if (i < POINTS_PER_TRACK) {
                            fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
                        }

                        if (i % POINTS_PER_TRACK == 0 && POINTS_PER_TRACK <= i) {
                            int fromPoint = i - POINTS_PER_TRACK;

                            int toPoint = i;
                            Date fromDate = trackPointList.get(toPoint - 1).getDate();
                            Date toDate = trackPointList.get(fromPoint).getDate();

                            double distance = distancesList.get((i / POINTS_PER_TRACK) - 1).getDistance();

                            KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(), simpleDateFormat(fromDate), simpleDateFormat(toDate),
                                    fromPoint + 1, toPoint, POINTS_PER_TRACK, distance, null);
                            kmlExtraDataList.add(kmlExtraData);
                        }

                        if (i + 1 < trackPointList.size()) {
                            GPSTrackPoint nextGpsTrackPoint = trackPointList.get(i + 1);

                            int nextSpeed = nextGpsTrackPoint.getSpeed();

                            if (!(speedColorItem.getMinSpeed() <= nextSpeed && nextSpeed <= speedColorItem.getMaxSpeed()) && i < POINTS_PER_TRACK) {
                                fillKmlTrackWithGpsTrackPoint(kmlTrack, nextGpsTrackPoint);

                                while (kmlTrack.size() < 4) {
                                    fillKmlTrackWithGpsTrackPoint(kmlTrack, nextGpsTrackPoint);
                                }

                                setKmlExtraDataDistance(kmlExtraDataList, distanceAllTracks);
                                kmlFolder.add(kmlPlacemark);
                                kmlPlacemark = null;
                                speedColorItem = null;
                            }
                        } else {
                            if (i == trackPointList.size() - 1) {
                                int length = trackPointList.size();

                                if (length == POINTS_PER_TRACK) {
                                    length--;
                                }

                                int fromPoint = (length / POINTS_PER_TRACK) * POINTS_PER_TRACK;
                                int toPoint = i + 1;
                                Date fromDate = trackPointList.get(toPoint - 1).getDate();
                                Date toDate = trackPointList.get(fromPoint).getDate();

                                double lastDistance = distancesList.get(distancesList.size() - 1).getDistance();

                                KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(),
                                        simpleDateFormat(fromDate),
                                        simpleDateFormat(toDate),
                                        fromPoint + 1,
                                        toPoint,
                                        toPoint - fromPoint,
                                        lastDistance, null);

                                kmlExtraDataList.add(kmlExtraData);
                            }

                            while (kmlTrack.size() < 4) {
                                fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
                            }

                            setKmlExtraDataDistance(kmlExtraDataList, distanceAllTracks);
                            kmlFolder.add(kmlPlacemark);
                        }
                    }
                }
            }

            if (trackPointList != null && trackPointList.size() == 0) {
                kmlPlacemark = new KMLPlacemark();
                kmlFolder.add(kmlPlacemark);
            }
        }

    }


    /**
     * Generate KML data for track type preview by days
     * @param mobject
     * @param gpsTrackPointList
     * @param speedColor
     * @param trackTypeColor
     * @param color
     * @param lineWidth
     * @param distancesList
     */
    private void generateDataByTrackViewTypeDays(MobjectBig mobject, GPSTrackPointList gpsTrackPointList, SpeedColor speedColor, String trackTypeColor,
                                                 String color, Integer lineWidth, List<CustomDistancesForTracking> distancesList) {

        List<GPSTrackPoint> trackPointList = gpsTrackPointList.getGpsTrackPoints();

        int POINTS_COUNT = 0;

        if (trackPointList != null && trackPointList.size() > 0) {
            POINTS_COUNT = trackPointList.size();
        }

        double distanceAllTracks = 0;
        for (CustomDistancesForTracking customDistancesForTracking : distancesList) {
            distanceAllTracks += customDistancesForTracking.getDistance();
        }

        if (trackTypeColor.equalsIgnoreCase("solid")) {
            KMLPlacemark kmlPlacemark = new KMLPlacemark();
            kmlPlacemark.setStyleUrl("solid" + "-#-" + lineWidth);

            KMLTrack kmlTrack = kmlPlacemark.getKmlTrack();

//            // Reverse track points in ascending order by dates
            if (trackPointList != null && trackPointList.size() > 0) {
                trackPointList = Lists.reverse(trackPointList);
            }

            GPSTrackPoint gpsTrackPoint = null;

            String previousDay = null;
            String currentDay = null;

            if (trackPointList != null) {
                int fromPointExt = 0;

                for (int i = 0; i < trackPointList.size(); i++) {
                    if (i < POINTS_COUNT) {
                        gpsTrackPoint = trackPointList.get(i);
                    }

                    if (i == 0) {
//                        int length = trackPointList.size();
                        int fromPoint = i;
                        int toPoint = POINTS_COUNT - 1;
                        Date fromDate = trackPointList.get(fromPoint).getDate();
                        Date toDate = trackPointList.get(toPoint).getDate();

                        double lastDistance = 0;
                        if (distancesList.size() > 0) {
                            lastDistance = distancesList.get(distancesList.size() - 1).getDistance();
                        }

                        KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(), simpleDateFormat(fromDate),
                                simpleDateFormat(toDate), fromPoint + 1, toPoint + 1,
                                (toPoint - fromPoint) + 1, lastDistance, null);
                        kmlExtraDataList.add(kmlExtraData);
                    }

                    if (gpsTrackPoint != null) {
                        previousDay = currentDay;
                        currentDay = Converters.dateFormatterTimestampToStringSimple(
                                new Timestamp(gpsTrackPoint.getTimestamp())
                        );
                    }

                    if ((previousDay != null && !currentDay.equals(previousDay) && i > 1) || (POINTS_COUNT == i + 1)) {
                        int fromPoint = fromPointExt;
                        fromPointExt = i;
                        int toPoint;

                        if ((POINTS_COUNT != i + 1)) {
                            toPoint = i - 1;
                        } else {
                            toPoint = i;
                        }

                        Date fromDate = trackPointList.get(fromPoint).getDate();
                        Date toDate = trackPointList.get(toPoint).getDate();

                        double distance = 0;
                        distance = getDistanceByDate(distancesList, fromDate, distance);

                        List<KMLExtraDataEvent> filteredEvents = new ArrayList<>();

                        if (kmlExtraDataEvents != null) {
                            for (KMLExtraDataEvent filteredEvent : kmlExtraDataEvents) {
                                if (filteredEvent.getFromDateShortFmt().equals(previousDay)) {
                                    filteredEvents.add(filteredEvent);
                                }
                            }
                        }

                        KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(),
                                simpleDateFormat(toDate),
                                simpleDateFormat(fromDate),
                                fromPoint + 1,
                                toPoint + 1,
                                (toPoint) - fromPoint + 1,
                                distance, filteredEvents);
                        kmlExtraDataList.add(kmlExtraData);
                    }

                    if (kmlExtraDataList.getKmlExtraDataList().size() <= 1) {
                        fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
                    }

                }
            }

            kmlPlacemark.setKmlTrack(kmlTrack);
            while (kmlTrack.size() < 3 && gpsTrackPoint != null) {
                fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
            }

            setKmlExtraDataDistance(kmlExtraDataList, distanceAllTracks);
            kmlFolder.add(kmlPlacemark);
        } else {
            //////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////
            //////////////////////////////////////////////////////////////
            // Reverse track points in ascending order by dates
            if (trackPointList != null && trackPointList.size() > 0) {
                trackPointList = Lists.reverse(trackPointList);
            }

            KMLPlacemark kmlPlacemark = null;
            SpeedColorItem speedColorItem = null;
            GPSTrackPoint gpsTrackPoint = null;

            String previousDay;
            String currentDay = null;

            if (trackPointList != null) {
                int fromPointExt = 0;

                for (int i = 0; i < trackPointList.size(); i++) {
                    if (i < POINTS_COUNT) {
                        gpsTrackPoint = trackPointList.get(i);
                    }

                    if (kmlPlacemark == null && gpsTrackPoint != null && gpsTrackPoint.getSpeed() != null) {
                        int speed = gpsTrackPoint.getSpeed();

                        kmlPlacemark = new KMLPlacemark();
                        kmlPlacemark.setName(gpsTrackPoint.getDate().toString());
                        speedColorItem = speedColor.getSpeedColorItemBySpeed(speed);
                        kmlPlacemark.setStyleUrl(speedColorItem.getStyleIdForSpeedColorItem() + "-#-" + lineWidth);

                        KMLTrack kmlTrack = kmlPlacemark.getKmlTrack();

                        if (i - 1 >= 0) {
                            GPSTrackPoint prevGpsTrackPoint = trackPointList.get(i - 1);

                            if (kmlExtraDataList.getKmlExtraDataList().size() <= 1) {
                                fillKmlTrackWithGpsTrackPoint(kmlTrack, prevGpsTrackPoint);
                            }
                        }
                    }

                    if (kmlPlacemark != null) {
                        KMLTrack kmlTrack;

                        kmlTrack = kmlPlacemark.getKmlTrack();

                        if (i < POINTS_COUNT) {
                            if (kmlExtraDataList.getKmlExtraDataList().size() <= 1) {
                                fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
                            }
                        }

                        if (i == 0) {
                            int length = trackPointList.size();

                            int fromPoint = i;
                            int toPoint = POINTS_COUNT - 1;
                            Date fromDate = trackPointList.get(fromPoint).getDate();
                            Date toDate = trackPointList.get(toPoint).getDate();

                            double lastDistance = 0;
                            if (distancesList.size() > 0) {
                                lastDistance = distancesList.get(distancesList.size() - 1).getDistance();
                            }

                            KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(),
                                    simpleDateFormat(fromDate),
                                    simpleDateFormat(toDate),
                                    fromPoint + 1,
                                    toPoint + 1,
                                    (toPoint - fromPoint) + 1,
                                    lastDistance, null);
                            kmlExtraDataList.add(kmlExtraData);
                        }

                        previousDay = currentDay;
                        currentDay = Converters.dateFormatterTimestampToStringSimple(
                                new Timestamp(gpsTrackPoint.getTimestamp())
                        );

                        if ((previousDay != null && !currentDay.equals(previousDay) && i > 1) || (POINTS_COUNT == i + 1)) {
                            int fromPoint = 0;
                            int toPoint = 0;
                            Date fromDate = null;
                            Date toDate = null;

                            fromPoint = fromPointExt;
                            fromPointExt = i;

                            if ((POINTS_COUNT != i + 1)) {
                                toPoint = i - 1;
                            } else {
                                toPoint = i;
                            }

                            fromDate = trackPointList.get(fromPoint).getDate();
                            toDate = trackPointList.get(toPoint).getDate();

                            double distance = 0;
                            distance = getDistanceByDate(distancesList, fromDate, distance);

                            List<KMLExtraDataEvent> filteredEvents = new ArrayList<>();

                            if (kmlExtraDataEvents != null) {
                                for (KMLExtraDataEvent filteredEvent : kmlExtraDataEvents) {
                                    if (filteredEvent.getFromDateShortFmt().equals(previousDay)) {
                                        filteredEvents.add(filteredEvent);
                                    }
                                }
                            }

                            KMLExtraData kmlExtraData = new KMLExtraData(mobject.getName(), mobject.getId(),
                                    simpleDateFormat(toDate),
                                    simpleDateFormat(fromDate),
                                    fromPoint + 1,
                                    toPoint + 1,
                                    (toPoint) - fromPoint + 1,
                                    distance, filteredEvents);
                            kmlExtraDataList.add(kmlExtraData);
                        }

                        if (i + 1 < trackPointList.size()) {

                            GPSTrackPoint nextGpsTrackPoint = trackPointList.get(i + 1);

                            int nextSpeed = nextGpsTrackPoint.getSpeed();

                            if (!(speedColorItem.getMinSpeed() <= nextSpeed && nextSpeed <= speedColorItem.getMaxSpeed()) && i < POINTS_COUNT) {
                                if (kmlExtraDataList.getKmlExtraDataList().size() <= 1) {
                                    fillKmlTrackWithGpsTrackPoint(kmlTrack, nextGpsTrackPoint);
                                }

                                if (kmlExtraDataList.getKmlExtraDataList().size() <= 1) {
                                    while (kmlTrack.size() < 4) {
                                        fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
                                    }
                                }

                                setKmlExtraDataDistance(kmlExtraDataList, distanceAllTracks);
                                kmlFolder.add(kmlPlacemark);
                                kmlPlacemark = null;
                                speedColorItem = null;
                            }

                        } else if (i == trackPointList.size() - 1) {

                            kmlPlacemark.setKmlTrack(kmlTrack);

                            if (kmlExtraDataList.getKmlExtraDataList().size() <= 1) {
                                while (kmlTrack.size() < 4) {
                                    fillKmlTrackWithGpsTrackPoint(kmlTrack, gpsTrackPoint);
                                }
                            }

                            setKmlExtraDataDistance(kmlExtraDataList, distanceAllTracks);
                            kmlFolder.add(kmlPlacemark);
                        }

                    }
                }
            }

            if (trackPointList != null && trackPointList.size() == 0) {
                kmlPlacemark = new KMLPlacemark();
                kmlFolder.add(kmlPlacemark);
            }
        }

    }

    private double getDistanceByDate(List<CustomDistancesForTracking> distancesList, Date fromDate, double distance) {
        if (!distancesList.isEmpty()) {
            try {
                String finalFindingDistanceDate = Converters.simpleDateFormat(fromDate);
                OptionalInt distanceIndex = IntStream.range(0, distancesList.size())
                        .filter(k -> Converters.dateFormatterTimestampToStringSimple(
                                distancesList.get(k).getStartDate()).equals(finalFindingDistanceDate))
                        .findFirst();

                if (distanceIndex.isPresent()) {
                    distance = distancesList.get(distanceIndex.getAsInt()).getDistance();
                }
            } catch (Exception e) {
                logger.error("Error in generateDataByTrackViewTypeDays", e);
            }
        }
        return distance;
    }


    private List<KMLStyle> makeKmlStyleList(SpeedColor speedColor, String trackTypeColor, String color, Integer width) {
        List<KMLStyle> kmlStyles = new ArrayList<>();

        if (trackTypeColor.equalsIgnoreCase("solid")) {
            kmlStyles.add(kmlStyle(color, width, "solid"));
        } else {
            for (SpeedColorItem speedColorItem : speedColor.getSpeedColorList())
                kmlStyles.add(kmlStyle(speedColorItem.getColor(), width, speedColorItem.getStyleIdForSpeedColorItem()));
        }

        return kmlStyles;
    }

    private KMLExtraData kmlExtraData(GPSTrackPointList gpsTrackPointList, MobjectBig mobject) {
        Date fromDate = new Date();
        Date toDate = new Date();
        if (gpsTrackPointList.getGpsTrackPoints().size() > 0) {
            fromDate = gpsTrackPointList.getGpsTrackPoints().get(gpsTrackPointList.size() - 1).getDate();
            toDate = gpsTrackPointList.getGpsTrackPoints().get(0).getDate();
        }

        return new KMLExtraData(mobject.getName(),
                mobject.getId(), simpleDateFormat(fromDate),
                simpleDateFormat(toDate), 0, 0,
                gpsTrackPointList.size(), 0.0, null);
    }

    private void setKmlExtraDataDistance(KMLExtraDataList kmlExtraDataList, double distance) {
        try {
            if (kmlExtraDataList != null) {
                if (kmlExtraDataList.size() > 0) {
                    KMLExtraData kmlExtraData = kmlExtraDataList.get(0);
                    kmlExtraData.setDistance(distance);
                }
            }
        } catch (Exception e) {
            logger.error("Error in setKmlExtraDataDistance", e);
        }
    }

    private KMLStyle kmlStyle(String color, Integer width, String id) {
        KMLStyle kmlStyle = null;
        try {
            kmlStyle = new KMLStyle();
            KMLLineStyle kmlLineStyle = new KMLLineStyle();
            kmlLineStyle.setColor(color);
            kmlLineStyle.setWidth(width);
            kmlStyle.setId(id);
            kmlStyle.setKmlLineStyle(kmlLineStyle);
        } catch (Exception e) {
            logger.error("Error in kmlStyle", e);
        }

        return kmlStyle;
    }

    private void fillKmlTrackWithGpsTrackPoint(KMLTrack kmlTrack, GPSTrackPoint gpsTrackPoint) {
        try {
            if (kmlTrack != null && gpsTrackPoint != null) {
                Date date = new Date(gpsTrackPoint.getDate().getTime());
                kmlTrack.getKmlWhenList().add(date);
                kmlTrack.getKmlCoordList().add(gpsTrackPoint.getLongitude() + " " + gpsTrackPoint.getLatitude() + " " + gpsTrackPoint.getAltitude());
                kmlTrack.getKmlAngelsList().add(gpsTrackPoint.getAngle());
                kmlTrack.getKmlSpeedList().add(gpsTrackPoint.getSpeed());
            }
        } catch (Exception e) {
            logger.error("Error in fillKmlTrackWithGpsTrackPoint", e);
        }
    }

    private String simpleDateFormat(Date date) {
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss.SSS");

        return dateFormat.format(date);
    }

    @XmlElement(name = "ExtraDataList")
    public KMLExtraDataList getKmlExtraDataList() {
        return kmlExtraDataList;
    }

    public void setKmlExtraDataList(KMLExtraDataList kmlExtraDataList) {
        this.kmlExtraDataList = kmlExtraDataList;
    }

    @XmlElement(name = "Style")
    public List<KMLStyle> getKmlStyleList() {
        return kmlStyleList;
    }

    public void setKmlStyleList(List<KMLStyle> kmlStyleList) {
        this.kmlStyleList = kmlStyleList;
    }

    @XmlElement(name = "Folder")
    public KMLFolder getKmlFolder() {
        return kmlFolder;
    }

    public void setKmlFolder(KMLFolder kmlFolder) {
        this.kmlFolder = kmlFolder;
    }
}
