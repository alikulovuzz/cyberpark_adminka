package uzgps.map.kml;

import uz.netex.datatype.GPSTrackPoint;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

/**
 * Created by Stanislav on 27/01/21.
 */
@XmlRootElement(name = "event")
@XmlAccessorType(XmlAccessType.FIELD)
public class KMLExtraDataEvent {
    private int eType;
    private Long eObjectId;
    private String eObjectName;

    private Long eFromDate;
    private Long eToDate;

    private String eFromDateFullFmt;
    private String eFromDateShortFmt;

    private String eToDateFullFmt;
    private String eToDateShortFmt;

    private Double eLat;
    private Double eLon;
    private Long eTpRegDate;
//    private Long timestamp;

    private Integer eFromPoint;
    private Integer eToPoint;
    private Integer eKmlPointCount;
    private String eKmlDistance;

    private Long eDurationSec;

    @XmlTransient
    private Double eTripDistDouble;

    private String eTripDist;

    @XmlTransient
    private Double distance;

    @XmlTransient
    GPSTrackPoint trackPoint;

    public KMLExtraDataEvent() {
    }

    public KMLExtraDataEvent(String mObjectName, Long mObjectId, Long fromDate, Long toDate, Integer fromPoint, Integer toPoint, Integer kmlPointCount, Double distance) {
        this.eObjectName = mObjectName;
        this.eObjectId = mObjectId;
        this.eFromDate = fromDate;
        this.eToDate = toDate;
        this.eFromDateFullFmt = null;
        this.eFromDateShortFmt = null;

        this.eToDateFullFmt = null;
        this.eToDateShortFmt = null;
        this.eFromPoint = fromPoint;
        this.eToPoint = toPoint;
        this.eKmlPointCount = kmlPointCount;
        this.eType = 1;
        this.eDurationSec = 0L;
        this.eTripDistDouble = 0D;
        this.eTripDist = "0";
        this.trackPoint = null;

        setDistance(distance);
    }


    public void setGPSTrackPoint(GPSTrackPoint trackPoint) {
        if (trackPoint != null) {
//            if (this.timestamp == null) {
//                this.timestamp = trackPoint.getDate().getTime();
//            }

            if (this.eTpRegDate == null) {
                this.eTpRegDate = trackPoint.getRegDate().getTime();
            }

            this.eLat = trackPoint.getLatitude(); // А	широта
            this.eLon = trackPoint.getLongitude(); //	долгота
        }
    }

    public GPSTrackPoint getGPSTrackPoint() {
        return this.trackPoint;
    }

    public String getObjectName() {
        return eObjectName;
    }

    public void setObjectName(String eObjectName) {
        this.eObjectName = eObjectName;
    }

    public Long getObjectId() {
        return eObjectId;
    }

    public void setObjectId(Long eObjectId) {
        this.eObjectId = eObjectId;
    }

    public Long getFromDate() {
        return eFromDate;
    }

    public void setFromDate(Long eFromDate) {
        this.eFromDate = eFromDate;

        if (eFromDate != null) {
            setFromDateFormattedFull(new Timestamp(eFromDate));
            setFromDateFormattedShort(new Timestamp(eFromDate));
        }

    }

    public void setFromDateFormattedFull(Timestamp fromDate) {
        if (fromDate != null) {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            eFromDateFullFmt = df.format(fromDate);
        }
    }

    public void setFromDateFormattedShort(Timestamp fromDate) {
        if (fromDate != null) {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            eFromDateShortFmt = df.format(fromDate);
        }
    }

    public String getFromDateFullFmt() {
        return eFromDateFullFmt;
    }

    public String getFromDateShortFmt() {
        return eFromDateShortFmt;
    }

    public String getToDateFullFmt() {
        return eToDateFullFmt;
    }

    public String getToDateShortFmt() {
        return eToDateShortFmt;
    }

    public void setToDateShortFmt(String eToDateShortFmt) {
        this.eToDateShortFmt = eToDateShortFmt;
    }

    public Long getToDate() {
        return eToDate;
    }

    public void setToDate(Long eToDate) {
        this.eToDate = eToDate;

        if (eToDate != null) {
            setDateFormattedFull(new Timestamp(eToDate));
            setDateFormattedShort(new Timestamp(eToDate));
        }
    }

    public void setDateFormattedFull(Timestamp value) {
        if (value != null) {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
            eToDateFullFmt = df.format(value);
        }
    }

    public void setDateFormattedShort(Timestamp value) {
        if (value != null) {
            DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
            eToDateShortFmt = df.format(value);
        }
    }

    public Integer getFromPoint() {
        return eFromPoint;
    }

    public void setFromPoint(Integer eFromPoint) {
        this.eFromPoint = eFromPoint;
    }

    public Integer getToPoint() {
        return eToPoint;
    }

    public void setToPoint(Integer eToPoint) {
        this.eToPoint = eToPoint;
    }

    public Integer getKmlPointCount() {
        return eKmlPointCount;
    }

    public void setKmlPointCount(Integer eKmlPointCount) {
        this.eKmlPointCount = eKmlPointCount;
    }

    public String getKmlDistance() {
        return eKmlDistance;
    }

    public void setKmlDistance(String eKmlDistance) {
        this.eKmlDistance = eKmlDistance;
    }

    public int getType() {
        return eType;
    }

    public void setType(int eType) {
        this.eType = eType;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
        DecimalFormat decimalFormat = new DecimalFormat("#0.000");
        this.eKmlDistance = decimalFormat.format(this.distance);
    }

    public Double getLat() {
        return eLat;
    }

    public void setLat(Double eLat) {
        this.eLat = eLat;
    }

    public Double getLon() {
        return eLon;
    }

    public void setLon(Double eLon) {
        this.eLon = eLon;
    }

    public Long getTpRegDate() {
        return eTpRegDate;
    }

    public void setTpRegDate(Long eTpRegDate) {
        this.eTpRegDate = eTpRegDate;
    }

    public Long getDurationSec() {
        return eDurationSec;
    }

    public void setDurationSec(Long eDurationSec) {
        this.eDurationSec = eDurationSec;
    }

    public Double geteTripDistDouble() {
        return eTripDistDouble;
    }

    public void seteTripDistDouble(Double eTripDistDouble) {
        this.eTripDistDouble = eTripDistDouble;
        DecimalFormat decimalFormat = new DecimalFormat("#0.00");
        this.eTripDist = decimalFormat.format(this.eTripDistDouble);
    }

    public String geteTripDist() {
        return eTripDist;
    }

    public void seteTripDist(String eTripDist) {
        this.eTripDist = eTripDist;
    }

    //    public Long getTimestamp() {
//        return timestamp;
//    }
//
//    public void setTimestamp(Long timestamp) {
//        this.timestamp = timestamp;
//    }


}
