package uzgps.map.models;

/**
 * Created by Gayratjon on 4/29/14.
 */

public class MObjectMessageCI extends MObjectActionCI{
    public MObjectMessageCI(int position, String idName, String title, String icon, int hasAccess) {
        super(position, idName, title, icon, hasAccess);
    }
}
