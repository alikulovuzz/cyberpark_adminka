/**
 * Created by Gayratjon on 1/29/14.
 */

@XmlSchema(
        namespace = "http://www.opengis.net/kml/2.2",
        xmlns = {
                @XmlNs(prefix = "gx", namespaceURI="http://www.google.com/kml/ext/2.2")
        }
)
package uzgps.map.kml;

import javax.xml.bind.annotation.XmlNs;
import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
