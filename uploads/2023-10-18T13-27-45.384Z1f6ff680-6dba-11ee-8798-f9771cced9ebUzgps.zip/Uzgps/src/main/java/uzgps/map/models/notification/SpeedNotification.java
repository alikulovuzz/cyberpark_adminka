package uzgps.map.models.notification;

import uz.netex.core.CoreMain;
import uz.netex.dbtables.NotificationUnit;
import uzgps.persistence.ContractSettings;

/**
 * Created by Gayratjon on 9/27/14.
 */
public class SpeedNotification extends BaseNotification {

    private Long speed;
    private Long speedLimit;
    private Boolean isOverSpeedLimit;

    public SpeedNotification() {
        super();

        this.speed = null;
        this.speedLimit = null;
        this.isOverSpeedLimit =  null;
    }

    public SpeedNotification(NotificationUnit notificationUnit, CoreMain coreMain, ContractSettings contractSettings) {
        super(notificationUnit, coreMain, contractSettings);

        this.speed = null;
        this.speedLimit = null;
        this.isOverSpeedLimit =  null;

        if (notificationUnit != null) {
            this.speed = notificationUnit.getValueLong();
            this.speedLimit = notificationUnit.getValueInt().longValue();

            if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SPEED_MIN) {
                this.isOverSpeedLimit = false;
            } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_SPEED_MAX) {
                this.isOverSpeedLimit = true;
            }
        }
    }

    public Long getSpeed() {
        return speed;
    }

    public void setSpeed(Long speed) {
        this.speed = speed;
    }

    public Long getSpeedLimit() {
        return speedLimit;
    }

    public void setSpeedLimit(Long speedLimit) {
        this.speedLimit = speedLimit;
    }

    public Boolean getIsOverSpeedLimit() {
        return isOverSpeedLimit;
    }

    public void setIsOverSpeedLimit(Boolean isOverSpeedLimit) {
        this.isOverSpeedLimit = isOverSpeedLimit;
    }
}
