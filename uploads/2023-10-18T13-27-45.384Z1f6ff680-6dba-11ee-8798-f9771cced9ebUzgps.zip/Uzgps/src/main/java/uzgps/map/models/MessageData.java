package uzgps.map.models;

import com.fasterxml.jackson.annotation.JsonInclude;
import uz.netex.datatype.GPSTrackPoint;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.MobjectTracks;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Gayratjon on 5/6/14.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MessageData {
    private long groupId;
    private long objectId;
    private String objectName;
    private List<MonitorData> messageList = null;

    public MessageData(HttpSession session, MobjectTracks mObjectTracks) {
        if (mObjectTracks.getMobject() != null) {
            MobjectBig mObject = mObjectTracks.getMobject();
            this.groupId = mObject.getGroupId();
            this.objectId = mObject.getId();
            this.objectName = mObject.getName();
        }

        List<GPSTrackPoint> gpsTrackPointList = mObjectTracks.getTracks();

        this.messageList = new ArrayList<>();
        if (gpsTrackPointList.size() > 0) {
            for (GPSTrackPoint gpsTrackPoint : gpsTrackPointList) {
                MonitorData monitorData = new MonitorData(gpsTrackPoint, session);
                this.messageList.add(monitorData);
            }
        } else {
            MonitorData monitorData = new MonitorData(null, session);
            this.messageList.add(monitorData);
        }
    }

    public long getGroupId() {
        return groupId;
    }

    public void setGroupId(long groupId) {
        this.groupId = groupId;
    }

    public long getObjectId() {
        return objectId;
    }

    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    public List<MonitorData> getMessageList() {
        return messageList;
    }

    public void setMessageList(List<MonitorData> messageList) {
        this.messageList = messageList;
    }
}
