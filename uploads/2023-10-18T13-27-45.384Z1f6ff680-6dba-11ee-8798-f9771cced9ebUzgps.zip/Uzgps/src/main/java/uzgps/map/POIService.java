package uzgps.map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.admin.AdminJournal;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.POI;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * Created by Gayratjon on 2/5/14.
 */

@Service
@Component
public class POIService {

//    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    private AdminJournal adminJournal;


    /**
     * @param poi
     * @return
     */
    @Transactional
    public POI savePOI(POI poi) {
        //
        if (poi.getId() != null) {
            entityManager.merge(poi);
        } else {
            entityManager.persist(poi);
        }
        return poi;
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<POI> getPOIListByContractIdAndStatus(Long contractId, String status) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<POI> query;
            query = entityManager.createNamedQuery("POI.getListByContractIdAndStatus", POI.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public POI getPOIById(Long id) {
        if (id == null)
            return null;

        try {
            TypedQuery<POI> query;
            query = entityManager.createNamedQuery("POI.findById", POI.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getPOICountByContractIdAndStatus(Long contractId, String status) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("POI.getPOICountByContractIdAndStatus", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getNameByContractId(Long contractId, String status, String name){
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("POI.getCountByContractIdName", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            query.setParameter("name", name);
            return query.getSingleResult();
        }catch (NoResultException e){
            return null;
        }
    }
}
