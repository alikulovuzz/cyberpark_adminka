package uzgps.map;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uz.netex.datatype.TrackStaticticsMotochasi;
import uz.netex.datatype.TrackStaticticsRow;
import uzgps.common.CommonUtils;
import uzgps.common.Converters;
import uzgps.main.AppLastStatus;
import uzgps.main.MainController;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Gayratjon on 3/18/14
 */

@Controller
public class TrackStaticticsController {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_TRACK_STATISTICS_PANEL = "/map/track-statistics-panel.htm";
    private final static String AJAX_TRACK_STATISTICS_LEFT = "map/ajax-map-statistics-left";

    private final static String URL_TRACK_STATISTICS_TABLE = "/map/track-statistics-table.htm";
    private final static String AJAX_TRACK_STATISTICS_TABLE = "map/ajax-map-statistics-table";
    private final static String AJAX_TRACK_STATISTICS_MOTOCHASI_TABLE = "map/ajax-map-statistics-motochasi-table";

    @Autowired
    CoreMain coreMain;

    @Autowired
    ObjectMapper jsonMapper;

    @Autowired
    MonitoringController monitoringController;

    /**
     * Left Panel
     *
     * @param appStatus
     * @param session
     * @param cmd
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_TRACK_STATISTICS_PANEL)
    public ModelAndView processTrackStatisticsPanel(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String appStatus, HttpSession session,
                                                    @RequestParam(value = "cmd", required = false) String cmd) throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(AJAX_TRACK_STATISTICS_LEFT);
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        modelAndView.addObject("appLastStatus", appLastStatus);
        monitoringController.processMapMonitoringModel(session, modelAndView, cmd);

        return modelAndView;
    }


    /**
     * Table on Right side
     *
     * @param response
     * @param session
     * @param stcTypeStr
     * @param dateStartStr
     * @param dateEndStr
     * @param selectedMObjectList
     * @param pageId
     * @return ajax result as table
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_TRACK_STATISTICS_TABLE, method = RequestMethod.GET)
    private ModelAndView takeTrackStatisticsTable(HttpServletResponse response, HttpSession session,
                                                  @RequestParam(value = "stc-type", required = false) String stcTypeStr,
                                                  @RequestParam(value = "stc-date-start", required = false) String dateStartStr,
                                                  @RequestParam(value = "stc-date-end", required = false) String dateEndStr,
                                                  //@RequestParam(value = "stc-selected-mObject-list", required = false) Long[] selectedMObjectList,
                                                  @RequestParam(value = "stc-selected-mObject-list", required = false) String selectedMObjectList,
                                                  @RequestParam(value = "page-id", required = false) Integer pageId) throws ServletException, IOException {


        if (logger.isDebugEnabled()) {
            logger.debug(stcTypeStr, dateStartStr, dateEndStr, selectedMObjectList);
        }

        // All object list
        List<MobjectBig> mObjectList = monitoringController.getMobjects(session, false);

        // Take all mobject IDs send from client to list, massivdan listga olish hammma MObjectIdlar
        List<Long> mobjectIds = new ArrayList<>();

        // make new list of objects, from all objects and selected IDs
        List<MobjectBig> mObjectListSelected = new ArrayList<>();
        if (mObjectList != null && mObjectList.size() > 0) {
            // Sort MObject list
            Collections.sort(mObjectList);
            String selectedMObjectListTemp = "," + selectedMObjectList + ",";
            for (MobjectBig mobjectBig : mObjectList) {
                if (mobjectBig != null && selectedMObjectListTemp.contains("," + mobjectBig.getId() + ",")) {
                    mObjectListSelected.add(mobjectBig);
                    mobjectIds.add(mobjectBig.getId());
                }
            }
        }

        // Otchet turini olish
        Integer stcType = Converters.strToInt(stcTypeStr, -1);

        // vaqt Timestamp  ga utqazish
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        Date startDate = null;
        Date endDate = null;
        try {
            startDate = dateFormat.parse(dateStartStr);
            endDate = dateFormat.parse(dateEndStr);
        } catch (ParseException e) {
        }

        Timestamp timestampStartDate = null;
        Timestamp timestampEndDate = null;
        Timestamp timestampCurrent = new Timestamp(System.currentTimeMillis());

        if (startDate != null && endDate != null) {
            timestampStartDate = new Timestamp(startDate.getTime());
            timestampEndDate = new Timestamp(endDate.getTime());
        }
        String timestampCurrentStr = new SimpleDateFormat("dd.MM.yyyy HH:mm").format(timestampCurrent);


        // Table header
        List<String> upperRow = new ArrayList<>();
        List<Integer> upperRowColspan = new ArrayList<>();
        List<String> lowerRow = new ArrayList<>();
        List<Integer> lowerRowDate = new ArrayList<>(); // Date ID for loop

        SimpleDateFormat upperRowFormat = new SimpleDateFormat("MM"); // Format to display upper row
        SimpleDateFormat lowerRowFormat = new SimpleDateFormat("d"); // Format to display upper row
        SimpleDateFormat lowerRowDateFormat = new SimpleDateFormat("MMdd"); // Format to display upper row

        Calendar calendarStart = Calendar.getInstance();
        calendarStart.setTimeInMillis(timestampStartDate.getTime());
        Calendar calendarEnd = Calendar.getInstance();
        calendarEnd.setTimeInMillis(timestampEndDate.getTime());


        int calendarIncreaseValue = Calendar.DATE;
        if (stcType == 1) // hour
        {
            upperRowFormat = new SimpleDateFormat("d.MM.YYYY"); // Format to display upper row
            lowerRowFormat = new SimpleDateFormat("HH:00"); // Format to display upper row
            lowerRowDateFormat = new SimpleDateFormat("MMddHH"); // Format to display upper row
            calendarIncreaseValue = Calendar.HOUR;
            calendarStart.set(Calendar.MINUTE, 0);
            calendarStart.set(Calendar.SECOND, 0);
            calendarStart.set(Calendar.MILLISECOND, 0);
        } else if (stcType == 24) // day
        {
            upperRowFormat = new SimpleDateFormat("MM"); // Format to display upper row
            lowerRowFormat = new SimpleDateFormat("d"); // Format to display upper row
            lowerRowDateFormat = new SimpleDateFormat("MMdd"); // Format to display upper row
            calendarIncreaseValue = Calendar.DATE;
            calendarStart.set(Calendar.HOUR, 0);
            calendarStart.set(Calendar.MINUTE, 0);
            calendarStart.set(Calendar.SECOND, 0);
            calendarStart.set(Calendar.MILLISECOND, 0);
        } else if (stcType == 100) // motochasi
        {
            upperRowFormat = new SimpleDateFormat("MM"); // Format to display upper row
            lowerRowFormat = new SimpleDateFormat("d"); // Format to display upper row
            lowerRowDateFormat = new SimpleDateFormat("MMdd"); // Format to display upper row
            calendarIncreaseValue = Calendar.DATE;
            calendarStart.set(Calendar.HOUR, 0);
            calendarStart.set(Calendar.MINUTE, 0);
            calendarStart.set(Calendar.SECOND, 0);
            calendarStart.set(Calendar.MILLISECOND, 0);
        }

        String upperStr = "";
        Integer upperRowColspanValue = 0;
        for (Calendar calendarLoop = calendarStart;
             calendarLoop.before(calendarEnd);
             calendarLoop.add(calendarIncreaseValue, 1)) {
            upperStr = upperRowFormat.format(calendarLoop.getTime());
            if (!upperRow.contains(upperStr)) {
                upperRow.add(upperStr);
                upperRowColspan.add(upperRowColspanValue);
                upperRowColspanValue = 0;
            }
            upperRowColspanValue++;
            lowerRow.add(lowerRowFormat.format(calendarLoop.getTime()));
            Integer lowerRowDateId = Converters.strToInt(lowerRowDateFormat.format(calendarLoop.getTime()), -1);
            lowerRowDate.add(lowerRowDateId);
        }
        upperRowColspan.add(upperRowColspanValue);

        ModelAndView modelAndView = null;
        if (stcType == 1 || stcType == 24) { // Statistics
            modelAndView = new ModelAndView(AJAX_TRACK_STATISTICS_TABLE);

            List<TrackStaticticsRow> trackStaticticsRows = coreMain.getTrackStatistics(mobjectIds, timestampStartDate.getTime(), timestampEndDate.getTime(), stcType);

            if (trackStaticticsRows != null) {
                Map<Long, Map<Integer, TrackStaticticsRow>> rowsMap = new HashMap<>();
                for (TrackStaticticsRow rowOne : trackStaticticsRows) {
                    try {
                        long mobjectId = rowOne.getUnitId().longValue();
                        Map<Integer, TrackStaticticsRow> mapForUnitId;
                        // get mobject id
                        if (!rowsMap.containsKey(mobjectId)) {
                            mapForUnitId = new HashMap<>();
                            rowsMap.put(mobjectId, mapForUnitId);
                        }
                        mapForUnitId = rowsMap.get(mobjectId);

                        // make Id for looper
                        Integer lowerRowDateId = Converters.strToInt(rowOne.getDateStr(), -1);

                        // check for month
                        mapForUnitId.put(lowerRowDateId, rowOne);

                    } catch (Exception e) {
                    }
                }
                modelAndView.addObject("rowsMap", rowsMap);
            }

        } else if (stcType == 100) { // Motochasi
            modelAndView = new ModelAndView(AJAX_TRACK_STATISTICS_MOTOCHASI_TABLE);

            List<TrackStaticticsMotochasi> trackStaticticsMotochasiRows = coreMain.getTrackStatisticsMotochasi(mobjectIds, timestampStartDate.getTime(), timestampEndDate.getTime());

            if (trackStaticticsMotochasiRows != null) {
                Map<Long, Map<Integer, TrackStaticticsMotochasi>> rowsMap = new HashMap<>();
                for (TrackStaticticsMotochasi rowOne : trackStaticticsMotochasiRows) {
                    try {
                        long mobjectId = rowOne.getUnitId().longValue();
                        Map<Integer, TrackStaticticsMotochasi> mapForUnitId;
                        // get mobject id
                        if (!rowsMap.containsKey(mobjectId)) {
                            mapForUnitId = new HashMap<>();
                            rowsMap.put(mobjectId, mapForUnitId);
                        }
                        mapForUnitId = rowsMap.get(mobjectId);

                        // make Id for looper
                        Integer lowerRowDateId = Converters.strToInt(rowOne.getPeriod(), -1);

                        // check for month
                        mapForUnitId.put(lowerRowDateId, rowOne);

                    } catch (Exception e) {
                    }
                }
                modelAndView.addObject("rowsMap", rowsMap);
            }

        }


        if (modelAndView != null) {
            modelAndView.addObject("dateStartStr", dateStartStr);
            modelAndView.addObject("dateEndStr", dateEndStr);
            modelAndView.addObject("dateGenerated", timestampCurrentStr);
            modelAndView.addObject("stcType", stcType);
            modelAndView.addObject("upperRow", upperRow);
            modelAndView.addObject("lowerRow", lowerRow);
            modelAndView.addObject("lowerRowDate", lowerRowDate);
            modelAndView.addObject("upperRowColspan", upperRowColspan);
            modelAndView.addObject("mObjectListSelected", mObjectListSelected);
        }
        return modelAndView;
    }

}
