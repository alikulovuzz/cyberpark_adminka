package uzgps.map.models;

/**
 * Created by Gayratjon on 4/29/14.
 */

/**
 * Conditional item of each movable object
 */

public class MObjectCI {
    private int position;
    private String idName;
    private String title;
    private String icon;

    public MObjectCI(int position, String idName, String title, String icon) {
        this.position = position;
        this.idName = idName;
        this.title = title;
        this.icon = icon;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getIdName() {
        return idName;
    }

    public void setIdName(String idName) {
        this.idName = idName;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
