package uzgps.map.models;

/**
 * Created by Gayratjon on 4/30/14.
 */
public class MObjectActionCI extends MObjectCI {
    private Boolean hasAccess;
    private String color;

    public MObjectActionCI(int position, String idName, String title, String icon, int hasAccess) {
        super(position, idName, title, icon);
        setHasAccess(hasAccess);
    }

    public Boolean getHasAccess() {
        return hasAccess;
    }

    public void setHasAccess(int access) {
        if (access > 0) {
            this.hasAccess = true;
            this.color = "green";
        } else {
            this.hasAccess = false;
            this.color = "";
        }
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
