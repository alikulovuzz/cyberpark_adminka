package uzgps.map.models.notification;

import uz.netex.core.CoreMain;
import uz.netex.datatype.PoiNotification;
import uz.netex.dbtables.NotificationUnit;
import uzgps.persistence.ContractSettings;

/**
 * Created by Gayratjon on 9/27/14.
 */

public class GeoFenceNotification extends BaseNotification {

    private Long geoFenceId;
    private String geoFenceName;
    private Integer geoFenceType;
    private Integer direction;

    public GeoFenceNotification() {
        super();

        this.geoFenceId = null;
        this.geoFenceName = null;
        this.geoFenceType = null;
        this.direction = null;
    }

    public GeoFenceNotification(NotificationUnit notificationUnit, CoreMain coreMain, ContractSettings contractSettings) {
        super(notificationUnit, coreMain, contractSettings);

        this.geoFenceId = null;
        this.geoFenceName = null;
        this.geoFenceType = null;
        this.direction = null;


        if (notificationUnit != null) {
            this.geoFenceId = notificationUnit.getMessageId();
            this.geoFenceName = notificationUnit.getValueStr();
            if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_POI) {
                this.geoFenceType = PoiNotification.TYPE_POI;
            } else if (notificationUnit.getMessageType() == NotificationUnit.MESSAGE_TYPE_ZOI) {
                this.geoFenceType = PoiNotification.TYPE_FANCE;
            }
            this.direction = notificationUnit.getValueInt();
        }
    }

    public Long getGeoFenceId() {
        return geoFenceId;
    }

    public void setGeoFenceId(Long geoFenceId) {
        this.geoFenceId = geoFenceId;
    }

    public String getGeoFenceName() {
        return geoFenceName;
    }

    public void setGeoFenceName(String geoFenceName) {
        this.geoFenceName = geoFenceName;
    }

    public Integer getGeoFenceType() {
        return geoFenceType;
    }

    public void setGeoFenceType(Integer geoFenceType) {
        this.geoFenceType = geoFenceType;
    }

    public Integer getDirection() {
        return direction;
    }

    public void setDirection(Integer direction) {
        this.direction = direction;
    }
}
