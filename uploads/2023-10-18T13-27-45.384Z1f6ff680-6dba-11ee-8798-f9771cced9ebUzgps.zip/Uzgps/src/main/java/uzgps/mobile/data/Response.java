package uzgps.mobile.data;

import com.fasterxml.jackson.annotation.JsonFilter;

/**
 * Created by Gayratjon on 11/8/2014.
 */
@JsonFilter("ResponseFilter")
public class Response <T> {

    private ResponseError error;
    private T data;

    public Response() {
        this.error = null;
        this.data = null;
    }

    public Response(ResponseError error, T data) {
        this.error = error;
        this.data = data;
    }

    public Response(T data, int error) {
        this.data = data;
        processError(error);
    }

    public ResponseError getError() {
        return error;
    }

    public void setError(ResponseError error) {
        this.error = error;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    private void processError(int error) {
        if (error == Errors.CODE_SUCCESS) {
            this.error = new ResponseError(Errors.CODE_SUCCESS, Errors.MESSAGE_SUCCESS);
        } else if (error == Errors.CODE_FAIL) {
            this.error = new ResponseError(Errors.CODE_FAIL, Errors.MESSAGE_FAIL);
        } else {
            this.error = new ResponseError();
        }
    }
}
