package uzgps.mobile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uzgps.admin.AdminService;
import uzgps.common.RoleInfo;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.EMailConfiguration;
import uzgps.common.configuration.MobileConfiguration;
import uzgps.common.configuration.RoleConfiguration;
import uzgps.main.MainController;
import uzgps.mobile.data.*;
import uzgps.persistence.*;
import uzgps.security.MD5;
import uzgps.settings.SettingsService;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import static uzgps.common.UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN_STR;

/**
 * Created by Gayratjon on 11/19/2014.
 */

@Controller
public class MobileUserController {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_MOBILE_USER_CONFIRM = "/mobile/user-confirm.htm";
    private final static String VIEW_MOBILE_USER_CONFIRM = "mobile/user-confirm";

    private static final String API_USER_INFO = "/user/info?data={data}";
    private static final String API_USER_STATUS_CHANGE = "/user/status/change?data={data}";
    private static final String API_MOBILE_INFO = "/mobile/info?data={data}";
    private static final String API_MOBILE_STATUS_CHANGE = "/mobile/status/change?data={data}";

    @Autowired
    EMailConfiguration eMailConfiguration;

    @Autowired
    CoreMain coreMain;

    @Autowired
    ObjectMapper jsonMapper;

    @Autowired
    AdminService adminService;

    @Autowired
    SettingsService settingsService;

    @Autowired
    AppConfiguration appConfiguration;

    @Autowired
    MobileConfiguration mobileConfiguration;

    @Autowired
    MobileTrackerController mobileTrackerController;

    @RequestMapping(value = URL_MOBILE_USER_CONFIRM)
    private ModelAndView processMobileUserConfirmation(HttpSession session,
                                                       @RequestParam(value = "email", required = false) String email,
                                                       @RequestParam(value = "key", required = false) String key) {

        if (logger.isDebugEnabled()) {
            logger.debug("Mobile user confirmation email={}, key={}", email, key);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_MOBILE_USER_CONFIRM);
        String message;

        // If manager and gps unit type are created yet for mobile
        // then we will stop the progress of registration
        if (mobileConfiguration.getManagerId() <= 0 && mobileConfiguration.getGpsUnitType() <= 0) {
            message = "Registration temporarily unavailable!";
            modelAndView.addObject("message", message);

            return modelAndView;
        }

        if (email != null && key != null) {
            try {
                RestTemplate restTemplate = new RestTemplate();

                MobileUser mobileUser = new MobileUser();
                mobileUser.setEmail(email);
                mobileUser.setEntranceKey(key);
                String jsonString = jsonMapper.writeValueAsString(mobileUser);

                // Gets user info from API DB
                String responseString = restTemplate.getForObject(mobileConfiguration.getApiUrl() + API_USER_INFO, String.class, jsonString);
                Response<MobileUser> response = jsonMapper.readValue(responseString, new TypeReference<Response<MobileUser>>() {
                });

                if (response != null) {
                    ResponseError error = response.getError();

                    if (error.getCode() == Errors.CODE_SUCCESS) {
                        mobileUser = response.getData();

                        if (mobileUser != null) {
                            if (mobileUser.getEntranceExp().getTime() >= System.currentTimeMillis()) {
                                User user = adminService.getUserByLogin(mobileUser.getEmail());

                                if (user == null) {
                                    // User with a given email is not registered yet
                                    int errorCode = makeClient(mobileUser);

                                    if (errorCode == Errors.CODE_SUCCESS) {
                                        message = "User successfully registered!";

                                        jsonString = jsonMapper.writeValueAsString(mobileUser);
                                        // Tell API that user can be usable and change status
                                        restTemplate.getForObject(mobileConfiguration.getApiUrl() + API_USER_STATUS_CHANGE, String.class, jsonString);

                                        if (logger.isInfoEnabled()) {
                                            logger.info("User successfully registered: {}", mobileUser.toString());
                                        }

                                        errorCode = processMobileInfo(mobileUser.getEmail(), mobileUser.getSerial(), session);

                                        if (errorCode == Errors.CODE_SUCCESS) {
                                            if (logger.isInfoEnabled()) {
                                                logger.info("Mobile info successfully stored for email={} and serial={}", mobileUser.getEmail(), mobileUser.getSerial());
                                            }
                                        }
                                    } else {
                                        message = Errors.MESSAGE_FAIL;
                                    }
                                } else {
                                    message = "User with this login " + mobileUser.getEmail() + " was already registered!";
                                }
                            } else {
                                message = "Registration date expired!";
                            }
                        } else {
                            message = "User does not exist!";
                        }
                    } else {
                        message = Errors.MESSAGE_FAIL;
                    }
                } else {
                    message = Errors.MESSAGE_FAIL;
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
                message = e.getMessage();
            }
        } else {
            message = Errors.MESSAGE_FAIL;
        }

        modelAndView.addObject("message", message);

        return modelAndView;
    }

    /* ========================== NEW CLIENT REGISTRATION ========================== >> */

    private int makeClient(MobileUser mobileUser) {
        if (mobileUser != null && mobileUser.getId() != null) {
            try {
                Company company = makeCompany();
                Contract contract = makeContract(company);
                User user = makeUser(mobileUser, contract);
                UserAccessList userAccessList = makeUserAccessList(user);
                ContractSettings contractSettings = makeContractSettings(contract);
                UserRole userRole = makeUserRole(user);

                if (company != null && company.getId() != null
                        && contract != null && contract.getId() != null
                        && user != null && user.getId() != null
                        && userAccessList != null
                        && contractSettings != null
                        && userRole != null && userRole.getId() != null) {
                    return Errors.CODE_SUCCESS;
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
                return Errors.CODE_FAIL;
            }
        }

        return Errors.CODE_FAIL;
    }

    private Company makeCompany() {
        Company company = new Company();
        company.setName("");
        company.setSettlementAccount("");
        company.setBankDetails("");
        company.setOkonh("");
        company.setInn("");
        company.setContact("");
        company.setContactPhoneMobile("");
        company.setContactEmail("");
        company.setAddress("");
        company.setPhoneLine("");
        company.setPhoneMobile("");
        company.setEmail("");

        adminService.saveCompany(company);

        return company;
    }

    private Contract makeContract(Company company) {
        if (company != null && company.getId() != null) {

            // Making contract number automatically
            Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
            String currentDateString = dateFormat.format(new Date(currentTimestamp.getTime()));
            String contractNumber = UZGPS_CONST.CONTRACT_TYPE_INDIVIDUAL + "-" + currentDateString + "-" + (adminService.getMaxContractId() + 1);

            Contract contract = new Contract();
            contract.setContractNumber(contractNumber);
            contract.setContractRegDate(currentTimestamp);
            contract.setBlock(UZGPS_CONST.USER_BLOCK_STATUS_UNBLOCK);
            contract.setStatus(UZGPS_CONST.USER_STATUS_ACTIVE);
            contract.setContractType(UZGPS_CONST.CONTRACT_TYPE_ORGANIZATION);
            contract.setActiveMaxUnitCount(UZGPS_CONST.CONTRACT_MAX_UNIT_COUNT_DEFAULT);
            contract.setActiveMaxUserCount(UZGPS_CONST.CONTRACT_MAX_USER_COUNT_DEFAULT);
            contract.setActiveMaxStaffCount(UZGPS_CONST.CONTRACT_MAX_STAFF_COUNT_DEFAULT);
            contract.setActiveMaxPoiCount(UZGPS_CONST.CONTRACT_MAX_POI_COUNT_DEFAULT);
            contract.setActiveMaxGeoFanceCount(UZGPS_CONST.CONTRACT_MAX_GEO_FANCE_COUNT_DEFAULT);
            contract.setMaxUnitCount(UZGPS_CONST.CONTRACT_MAX_UNIT_COUNT_DEFAULT);
            contract.setExistUnitCount(0L);
            contract.setMaxUserCount(UZGPS_CONST.CONTRACT_MAX_USER_COUNT_DEFAULT);
            contract.setMaxStaffCount(UZGPS_CONST.CONTRACT_MAX_STAFF_COUNT_DEFAULT);
            contract.setMaxPoiCount(UZGPS_CONST.CONTRACT_MAX_POI_COUNT_DEFAULT);
            contract.setMaxGeoFanceCount(UZGPS_CONST.CONTRACT_MAX_GEO_FANCE_COUNT_DEFAULT);
            contract.setMaxReportCount(UZGPS_CONST.CONTRACT_MAX_REPORT_COUNT_DEFAULT);
            contract.setMaxEmailCount(UZGPS_CONST.CONTRACT_MAX_EMAIL_COUNT_DEFAULT);
            contract.setMaxSmsCount(UZGPS_CONST.CONTRACT_MAX_SMS_COUNT_DEFAULT);
            contract.setMaxSmsCmdCount(UZGPS_CONST.CONTRACT_MAX_SMS_CMD_COUNT_DEFAULT);
            contract.setRegistrationDate(new Timestamp(System.currentTimeMillis()));
            contract.setCompany(company);
            adminService.saveContract(contract);

            return contract;
        }

        return null;
    }

    private User makeUser(MobileUser mobileUser, Contract contract) {
        if (mobileUser != null && mobileUser.getId() != null
                && contract != null && contract.getId() != null) {

            Profile profile = new Profile();
            adminService.saveProfile(profile);

            User customer = new User();
            customer.setManagerId(mobileConfiguration.getManagerId());
//            customer.setUserTypeId(UZGPS_CONST.USER_TYPE_CUSTOMER);
            Role role = adminService.getRoleById(UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN);
            customer.setRole(role);
            customer.setLogin(mobileUser.getEmail().trim().toLowerCase());

            MD5 md5 = new MD5();
            String password = md5.getMD5(mobileUser.getPassword().trim());

            customer.setPassword(password);
            customer.setSurName("");
            customer.setName(mobileUser.getName());
            customer.setMiddleName("");
            customer.setBlock(UZGPS_CONST.USER_BLOCK_STATUS_UNBLOCK);
            customer.setStatus(UZGPS_CONST.USER_STATUS_ACTIVE);
            customer.setRegDate(new Timestamp(System.currentTimeMillis()));
            customer.setContract(contract);
            customer.setProfile(profile);
            adminService.saveUser(customer);

            return customer;
        }

        return null;
    }

    private UserAccessList makeUserAccessList(User user) {
        if (user != null && user.getId() != null) {
            UserAccessList userAccessList = new UserAccessList();
            userAccessList.setUser(user);
            userAccessList.setMonitoring(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setTracker(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setPoi(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setGeoZone(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setMessage(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setReport(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setDashboard(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setFms(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettings(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsMap(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsMonitoring(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsObject(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsGroup(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsStaff(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsUsers(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsNotifications(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsDisplayData(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsDashboard(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsUserPoiZoiAccess(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setSettingsExternalServices(UZGPS_CONST.USER_ACCESS_FULL);

            userAccessList.setRouting(UZGPS_CONST.USER_ACCESS_NONE);
//            userAccessList.setTrackStatistics(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setMap(UZGPS_CONST.USER_ACCESS_FULL);
            userAccessList.setRegDate(new Timestamp(System.currentTimeMillis()));
            adminService.saveUserAccessList(userAccessList);

            return userAccessList;
        }

        return null;
    }

    private ContractSettings makeContractSettings(Contract contract) {
        if (contract != null && contract.getId() != null) {
            ContractSettings contractSettings = ContractSettings.createDefault();
            contractSettings.setContract(contract);
//            ContractSettings contractSettings = new ContractSettings();
//            contractSettings.setContract(contract);
//            contractSettings.setMapType(1L);
//            contractSettings.setSaveCurrentPosition(true);
//            contractSettings.setShowNamePoi(true);
//            contractSettings.setBindingTracksToMap(false);
//            contractSettings.setShowNameGeoZone(true);
//            contractSettings.setObjectLabel(1L);
//            contractSettings.setObjectNameMonitoring(true);
//            contractSettings.setObjectNameTracking(true);
//            contractSettings.setTypeTrackerMonitoring(false);
//            contractSettings.setTypeTrackerTracking(true);
//            contractSettings.setTrackerIdMonitoring(false);
//            contractSettings.setTrackerIdTracking(false);
//            contractSettings.setTrackerPhoneNumberMonitoring(true);
//            contractSettings.setTrackerPhoneNumberTracking(false);
//            contractSettings.setObjectTypeMonitoring(true);
//            contractSettings.setObjectTypeTracking(false);
//            contractSettings.setObjectPlateNumberMonitoring(true);
//            contractSettings.setObjectPlateNumberTracking(false);
//            contractSettings.setObjectCapacityMonitoring(false);
//            contractSettings.setObjectCapacityTracking(false);
//            contractSettings.setObjectFuelMonitoring(false);
//            contractSettings.setObjectFuelTracking(false);
//            contractSettings.setObjectAddressMonitoring(true);
//            contractSettings.setObjectAddressTracking(true);
//            contractSettings.setObjectCoordinatesMonitoring(true);
//            contractSettings.setObjectCoordinatesTracking(true);
//            contractSettings.setObjectSpeedMonitoring(true);
//            contractSettings.setObjectSpeedTracking(true);
//            contractSettings.setObjectSatelliteMonitoring(true);
//            contractSettings.setObjectSatelliteTracking(true);
//            contractSettings.setObjectOdometerMonitoring(false);
//            contractSettings.setObjectOdometerTracking(true);
//            contractSettings.setObjectHourmeterMonitoring(false);
//            contractSettings.setObjectHourmeterTracking(true);
//            contractSettings.setBeingGeozonMonitoring(false);
//            contractSettings.setBeingGeozonTracking(false);
//            contractSettings.setDesignRoutMonitoring(false);
//            contractSettings.setDesignRoutTracking(false);
//            contractSettings.setNameStaffMonitoring(true);
//            contractSettings.setNameStaffTracking(false);
//            contractSettings.setPhotoStaffMonitoring(true);
//            contractSettings.setPhotoStaffTracking(false);
//            contractSettings.setPhoneStaffMonitoring(true);
//            contractSettings.setPhoneStaffTracking(false);
//            contractSettings.setObjectStatusPosition(0);
//            contractSettings.setObjectStatusView(true);
//            contractSettings.setIgnitionSensorPosition(1);
//            contractSettings.setIgnitionSensorView(true);
//            contractSettings.setSatelliteVisibilityPosition(2);
//            contractSettings.setSatelliteVisibilityView(true);
//            contractSettings.setObjectLinkPosition(3);
//            contractSettings.setObjectLinkView(true);
//            contractSettings.setBuildTrackPosition(4);
//            contractSettings.setBuildTrackView(true);
//            contractSettings.setSmsSendPosition(5);
//            contractSettings.setSmsSendView(true);
//            contractSettings.setObjectDriverPosition(6);
//            contractSettings.setObjectDriverView(false);
//            contractSettings.setSensorStatePosition(7);
//            contractSettings.setSensorStateView(false);
//            contractSettings.setObjectMassagePosition(8);
//            contractSettings.setObjectMassageView(false);
//            contractSettings.setReportPosition(9);
//            contractSettings.setReportView(false);
//            contractSettings.setObjectPropertiesPosition(10);
//            contractSettings.setObjectPropertiesView(true);
//            contractSettings.setFastTrackType(1L);
//            contractSettings.setFastTrackValue(100L);
//            contractSettings.setTrackLengthType(1L);
//            contractSettings.setTrackLengthValue(3L);
//            contractSettings.setTrackLengthColor("#f90000");
//            contractSettings.setMappingObjectType(2L);
//            contractSettings.setTooltipsViewQuantity(3L);
//            contractSettings.setTooltipsMassagesView(true);
//            contractSettings.setTooltipsMassagesColor("#1eb050");
//            contractSettings.setTooltipsSmsView(true);
//            contractSettings.setTooltipsSmsColor("#0618f9");
//            contractSettings.setTooltipsCommandView(true);
//            contractSettings.setTooltipsCommandColor("#f9dd04");
//            contractSettings.setTooltipsEventView(true);
//            contractSettings.setTooltipsEventColor("#f20303");
//            contractSettings.setMonitoringRefreshInterval(10);
//            contractSettings.setBakPositionView(false);
//            contractSettings.setBakPosition(11);
//            contractSettings.setViewTrack(77798);
//            contractSettings.setViewNextTrack(108928);
//            contractSettings.setViewMessage(2965478);
//            contractSettings.setViewNextMessage(129408);

            adminService.saveContractSettings(contractSettings);

            return contractSettings;
        }

        return null;
    }

    private UserRole makeUserRole(User user) {
        if (user != null && user.getId() != null) {
            UserRole userRole = new UserRole();
            userRole.setUser(user);

            RoleConfiguration roleConfiguration = appConfiguration.getRoleConfiguration();
            RoleInfo[] roleInfos = roleConfiguration.getRoleInfo();
            for (RoleInfo roleInfo : roleInfos) {
                if (roleInfo.getType().equalsIgnoreCase(USER_ROLE_CUSTOMER_ADMIN_STR)) {
                    userRole.setRoleId((long) roleInfo.getId());
                }
            }
            adminService.saveUseRole(userRole);

            return userRole;
        }

        return null;
    }

    /* ========================== NEW CLIENT REGISTRATION ========================== << */

    /* ========================== NEW MOBJECT REGISTRATION ========================== >> */

    public int processMobileInfo(String login, String mobileSerial, HttpSession session) {
        if (login != null && mobileSerial != null) {
            User user = adminService.getUserByLogin(login);
            if (user != null) {
                Contract contract = MainController.getUserContract(session);
                // Before making a new mobject we should check if count of mobject is not exceed from the max limit
                long mObjectCount = adminService.getMobjectCountByContractId(contract.getId());
                if (mObjectCount >= contract.getActiveMaxUnitCount()) {
                    return Errors.CODE_OVER_MAX_UNIT_LIMIT;
                }

                try {
                    RestTemplate restTemplate = new RestTemplate();

                    MobileInfo mobileInfo = new MobileInfo();
                    mobileInfo.setSerial(mobileSerial);
                    String jsonString = jsonMapper.writeValueAsString(mobileInfo);

                    // Gets mobile info from API DB
                    String responseString = restTemplate.getForObject(mobileConfiguration.getApiUrl() + API_MOBILE_INFO, String.class, jsonString);
                    Response<MobileInfo> response = jsonMapper.readValue(responseString, new TypeReference<Response<MobileInfo>>() {
                    });

                    if (response != null) {
                        ResponseError error = response.getError();

                        if (error.getCode() == Errors.CODE_SUCCESS) {
                            mobileInfo = response.getData();

                            if (mobileInfo != null) {
                                int errorCode = attachMobjectAndGpsUnit(mobileInfo, contract);

                                if (errorCode == Errors.CODE_SUCCESS) {
                                    jsonString = jsonMapper.writeValueAsString(mobileInfo);
                                    // Tell API that mobile can be usable, change status
                                    restTemplate.getForObject(mobileConfiguration.getApiUrl() + API_MOBILE_STATUS_CHANGE, String.class, jsonString);
                                }
                                return errorCode;
                            }
                        }
                    }
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }
            }
        }

        return Errors.CODE_FAIL;
    }

    private int attachMobjectAndGpsUnit(MobileInfo mobileInfo, Contract contract) {
        if (mobileInfo != null && mobileInfo.getId() != null
                && contract != null && contract.getId() != null) {

            MObject mObject = makeMObject(mobileInfo, contract);
            makeMObjectSettings(mObject);
            makeMObjectNotifications(mObject);

            Sim sim = makeSim(mobileInfo);
            GPSUnit gpsUnit = makeGPSUnit(mobileInfo, sim);
            makeGPSUnitSim(gpsUnit, sim);
            makeMobileTrackerSettings(mobileInfo, mObject);

            MObjectGPSUnit mObjectGPSUnit = makeMObjectGPSUnit(mObject, gpsUnit);

            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                // Save Mobject count for Contract
                contract.setExistUnitCount(adminService.getMobjectCountByContractId(contract.getId()));
                adminService.saveContract(contract);

                try {
                    // Update core
                    coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }

                return Errors.CODE_SUCCESS;
            }
        }

        return Errors.CODE_FAIL;
    }

    public int processMObjectSerialReplacement(MObject mObject, String mobileSerial) {
        if (mObject != null && mObject.getId() != null
                && mobileSerial != null && mobileSerial.trim().length() > 0) {
            try {
                RestTemplate restTemplate = new RestTemplate();

                MobileInfo mobileInfo = new MobileInfo();
                mobileInfo.setSerial(mobileSerial);
                String jsonString = jsonMapper.writeValueAsString(mobileInfo);

                // Gets mobile info from API DB
                String responseString = restTemplate.getForObject(mobileConfiguration.getApiUrl() + API_MOBILE_INFO, String.class, jsonString);
                Response<MobileInfo> response = jsonMapper.readValue(responseString, new TypeReference<Response<MobileInfo>>() {
                });

                if (response != null) {
                    ResponseError error = response.getError();

                    if (error.getCode() == Errors.CODE_SUCCESS) {
                        mobileInfo = response.getData();

                        if (mobileInfo != null) {
                            int errorCode = attachGivenMobjectAndNewGpsUnit(mObject, mobileInfo);

                            if (errorCode == Errors.CODE_SUCCESS) {
                                jsonString = jsonMapper.writeValueAsString(mobileInfo);
                                // Tell API that mobile can be usable, change status
                                restTemplate.getForObject(mobileConfiguration.getApiUrl() + API_MOBILE_STATUS_CHANGE, String.class, jsonString);
                            }
                            return errorCode;
                        }
                    }
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

        return Errors.CODE_FAIL;
    }

    public int attachGivenMobjectAndNewGpsUnit(MObject mObject, MobileInfo mobileInfo) {
        if (mObject != null && mObject.getId() != null
                && mobileInfo != null && mobileInfo.getId() != null) {

            Sim sim = makeSim(mobileInfo);
            GPSUnit gpsUnit = makeGPSUnit(mobileInfo, sim);
            makeGPSUnitSim(gpsUnit, sim);

            MObjectGPSUnit mObjectGPSUnit = makeMObjectGPSUnit(mObject, gpsUnit);

            if (mObjectGPSUnit != null && mObjectGPSUnit.getId() != null) {
                try {
                    // Update core
                    coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }

                return Errors.CODE_SUCCESS;
            }
        }

        return Errors.CODE_FAIL;
    }

    public MobileInfo getMobileInfo(String mobileSerial) {
        if (mobileSerial != null && mobileSerial.trim().length() > 0) {
            try {
                RestTemplate restTemplate = new RestTemplate();

                MobileInfo mobileInfo = new MobileInfo();
                mobileInfo.setSerial(mobileSerial);
                String jsonString = jsonMapper.writeValueAsString(mobileInfo);

                // Gets mobile info from API DB
                String responseString = restTemplate.getForObject(mobileConfiguration.getApiUrl() + API_MOBILE_INFO, String.class, jsonString);
                Response<MobileInfo> response = jsonMapper.readValue(responseString, new TypeReference<Response<MobileInfo>>() {
                });

                if (response != null) {
                    ResponseError error = response.getError();

                    if (error.getCode() == Errors.CODE_SUCCESS) {
                        mobileInfo = response.getData();

                        if (mobileInfo != null)
                            return mobileInfo;
                    }
                }

            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        }

        return null;
    }


    private MObject makeMObject(MobileInfo mobileInfo, Contract contract) {
        if (mobileInfo != null && mobileInfo.getId() != null
                && contract != null && contract.getId() != null) {
            Group group = adminService.getGroupById(0L);
//            MobileTrackerStatus mobileTrackerStatus = mobileTrackerController.saveMobileTrackerStatus(null, 0, "0");
            MobileTrackerStatus mobileTrackerStatus = new MobileTrackerStatus();
            mobileTrackerStatus.setMobileSerial(mobileInfo.getSerial());
            mobileTrackerStatus.setIndex(MobileTrackerController.MOBJECT_STATUS_FREE_INDEX);
            mobileTrackerStatus.setName(MobileTrackerController.MOBJECT_STATUS_FREE);
            mobileTrackerStatus.setColor(MobileTrackerController.MOBJECT_STATUS_FREE_COLOR);

            mobileTrackerStatus = mobileTrackerController.saveMobileTrackerStatus(mobileTrackerStatus);

            MObject mObject = new MObject();
            mObject.setGroup(group);
            mObject.setContract(contract);
            mObject.setMobileTrackerStatus(mobileTrackerStatus);
            mObject.setmObjectName(mobileInfo.getSerial());
            mObject.setmObjectType(mobileInfo.getOs());
            mObject.setmObjectPlateNumber(mobileInfo.getModel());
            mObject.setDefaultIcon(true);
            mObject.setPhoto(null);
            mObject.setPinId(UZGPS_CONST.MAP_MOBJECT_ICON_MOBILE);
            mObject.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            mObject.setRegDate(new Timestamp(System.currentTimeMillis()));

            adminService.saveMObject(mObject);

            return mObject;
        }

        return null;
    }

    private MObjectSettings makeMObjectSettings(MObject mObject) {
        if (mObject != null && mObject.getId() != null) {
            MObjectSettings mObjectSettings = new MObjectSettings();
            mObjectSettings.setmObject(mObject);
            mObjectSettings.setDefaultTrackColor("#ff0000");
            mObjectSettings.setSpeedColor1("#1cf0f0");
            mObjectSettings.setSpeedColor2("#3442f4");
            mObjectSettings.setSpeedColor3("#28ec50");
            mObjectSettings.setSpeedColor4("#ff25e5");
            mObjectSettings.setSpeedColor5("#ffa500");
            mObjectSettings.setSpeedColor6("#ff0000");
            mObjectSettings.setSpeedValue1(30L);
            mObjectSettings.setSpeedValue2(50L);
            mObjectSettings.setSpeedValue3(70L);
            mObjectSettings.setSpeedValue4(90L);
            mObjectSettings.setSpeedValue5(100L);
            mObjectSettings.setSpeedValue6(120L);
            mObjectSettings.setLabelSize(10L);
            mObjectSettings.setMaxSpeed(70L);
            mObjectSettings.setOnlineTime(300L);
            mObjectSettings.setParkingTime(300L);
            mObjectSettings.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            mObjectSettings.setRegDate(new Timestamp(System.currentTimeMillis()));

            adminService.saveMObjectSettings(mObjectSettings);

            return mObjectSettings;
        }

        return null;
    }

    private MObjectNotifications makeMObjectNotifications(MObject mObject) {
        if (mObject != null && mObject.getId() != null) {
            MObjectNotifications mObjectNotifications = new MObjectNotifications();
            mObjectNotifications.setmObjectId(mObject.getId());
            mObjectNotifications.setPanicButton(true);
            mObjectNotifications.setMinSpeed(20);
            mObjectNotifications.setMaxSpeed(70);
            mObjectNotifications.setSendSms(false);
            mObjectNotifications.setSendMail(false);
            mObjectNotifications.setPopUpWindow(true);
            mObjectNotifications.setnPopUpWindow(true);
            mObjectNotifications.setRegisterDatabase(false);
            mObjectNotifications.setRegisterDatabaseViolation(false);

            mObjectNotifications.setuSos(true);
            mObjectNotifications.setuEngine(false);
            mObjectNotifications.setuExternalPower(false);
            mObjectNotifications.setuSpeedMin(false);
            mObjectNotifications.setuSpeedMax(false);
            mObjectNotifications.setuOnline(false);
            mObjectNotifications.setuStaff(false);
            mObjectNotifications.setuSettings(false);
            mObjectNotifications.setuPoi(true);
            mObjectNotifications.setuZoi(true);

            mObjectNotifications.setsSos(true);
            mObjectNotifications.setsEngine(true);
            mObjectNotifications.setsExternalPower(true);
            mObjectNotifications.setsSpeedMin(false);
            mObjectNotifications.setsSpeedMax(true);
            mObjectNotifications.setsOnline(false);
            mObjectNotifications.setsStaff(true);
            mObjectNotifications.setsSettings(true);
            mObjectNotifications.setsPoi(true);
            mObjectNotifications.setsZoi(true);

            mObjectNotifications.setnSos(false);
            mObjectNotifications.setnEngine(false);
            mObjectNotifications.setnExternalPower(false);
            mObjectNotifications.setnSpeedMin(false);
            mObjectNotifications.setnSpeedMax(true);
            mObjectNotifications.setnOnline(false);
            //mObjectNotifications.setnStaff(false);
            //mObjectNotifications.setnSettings(false);
            mObjectNotifications.setnPoi(false);
            mObjectNotifications.setnZoi(false);

            mObjectNotifications.seteSos(false);
            mObjectNotifications.seteEngine(false);
            mObjectNotifications.seteExternalPower(false);
            mObjectNotifications.seteSpeedMin(false);
            mObjectNotifications.seteSpeedMax(false);
            mObjectNotifications.seteOnline(false);
            mObjectNotifications.seteStaff(false);
            mObjectNotifications.seteSettings(false);
            mObjectNotifications.setePoi(false);
            mObjectNotifications.seteZoi(false);

            mObjectNotifications.setmSos(false);
            mObjectNotifications.setmEngine(false);
            mObjectNotifications.setmExternalPower(false);
            mObjectNotifications.setmSpeedMin(false);
            mObjectNotifications.setmSpeedMax(false);
            mObjectNotifications.setmOnline(false);
            mObjectNotifications.setmStaff(false);
            mObjectNotifications.setmSettings(false);
            mObjectNotifications.setmPoi(false);
            mObjectNotifications.setmZoi(false);
            mObjectNotifications.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            mObjectNotifications.setRegDate(new Timestamp(System.currentTimeMillis()));

            adminService.saveMObjectNotifications(mObjectNotifications);

            coreMain.coreUpdater.updateMobjectNotificationsById(mObjectNotifications.getId());

            return mObjectNotifications;
        }

        return null;
    }

    private GPSUnit makeGPSUnit(MobileInfo mobileInfo, Sim sim) {
        if (mobileInfo != null && mobileInfo.getId() != null) {
            GPSUnitType gpsUnitType = adminService.getGPSUniteTypeById(mobileConfiguration.getGpsUnitType());

            if (gpsUnitType != null) {
                GPSUnit gpsUnit = new GPSUnit();
                gpsUnit.setBlock(UZGPS_CONST.STATUS_UNBLOCK);
                gpsUnit.setGpsUnitLogin("");
                gpsUnit.setGpsUnitPassword("");
                gpsUnit.setGpsUnitType(gpsUnitType);
                gpsUnit.setImei(mobileInfo.getSerial());
                gpsUnit.setName(mobileInfo.getOs() + "-" + mobileInfo.getSerial());
//                gpsUnit.setSim(sim);
                gpsUnit.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                gpsUnit.setIsMobile(UZGPS_CONST.TRACKER_TYPE_MOBILE);
                gpsUnit.setRegDate(new Timestamp(System.currentTimeMillis()));

                adminService.saveGPSUnit(gpsUnit);

                return gpsUnit;
            }
        }

        return null;
    }

    private Sim makeSim(MobileInfo mobileInfo) {
        if (mobileInfo != null && mobileInfo.getId() != null) {
            Sim sim = new Sim();
            sim.setSimPhone(mobileInfo.getSim());
            sim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            sim.setRegDate(new Timestamp(System.currentTimeMillis()));

            adminService.saveSim(sim);

            return sim;
        }

        return null;
    }

    private GPSUnitSim makeGPSUnitSim(GPSUnit gpsUnit, Sim sim) {
        if (gpsUnit != null && gpsUnit.getId() != null
                && sim != null && sim.getId() != null) {
            GPSUnitSim gpsUnitSim = new GPSUnitSim();
            gpsUnitSim.setSim(sim);
            gpsUnitSim.setGpsUnit(gpsUnit);
            gpsUnitSim.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            gpsUnitSim.setRegDate(new Timestamp(System.currentTimeMillis()));

            adminService.saveGPSUnitSim(gpsUnitSim);

            return gpsUnitSim;
        }
        return null;
    }

    private MObjectGPSUnit makeMObjectGPSUnit(MObject mObject, GPSUnit gpsUnit) {
        if (mObject != null && mObject.getId() != null
                && gpsUnit != null && gpsUnit.getId() != null) {
            MObjectGPSUnit mObjectGPSUnit = new MObjectGPSUnit();
            mObjectGPSUnit.setmObject(mObject);
            mObjectGPSUnit.setGpsUnit(gpsUnit);
            mObjectGPSUnit.setTimeMin(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_MIN);
            mObjectGPSUnit.setTimeBig(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_BIG);
            mObjectGPSUnit.setTimeLost(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_TIME_LOST);
            mObjectGPSUnit.setDistanceMin(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_DISTANCE_MIN);
            mObjectGPSUnit.setDistanceBig(UZGPS_CONST.COSTOMER_DEFAULT_TRACKER_DISTANCE_BIG);
            mObjectGPSUnit.setMovementStatus((short) 1);
            mObjectGPSUnit.setEngineOnStatus((short) 1);
            mObjectGPSUnit.setDatStatus((short) 1);
            mObjectGPSUnit.setOnlineStatus((short) 1);
            mObjectGPSUnit.setSatellitesStatus((short) 1);
            mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_ACTIVE);

//            mObjectGPSUnit.setIsMobile(UZGPS_CONST.TRACKER_TYPE_MOBILE);
            mObjectGPSUnit.setRegDate(new Timestamp(System.currentTimeMillis()));

            adminService.saveMObjectGPSUnit(mObjectGPSUnit);

            return mObjectGPSUnit;
        }

        return null;
    }
    /* ========================== NEW MOBJECT REGISTRATION ========================== << */

    /* ========================== NEW MOBILE TRACKER SETTINGS ========================== >> */
    private MobileTrackerSettings makeMobileTrackerSettings(MobileInfo mobileInfo, MObject mObject) {
        if (mobileInfo != null && mobileInfo.getId() != null
                && mObject != null && mObject.getId() != null) {
            MobileTrackerSettings mobileTrackerSettings = new MobileTrackerSettings();
            mobileTrackerSettings.setmObjectId(mObject.getId());
            mobileTrackerSettings.setMobileSerial(mobileInfo.getSerial());
            mobileTrackerSettings.setHasPassword(UZGPS_CONST.MTRACKER_DEFAULT_SETTINGS_HAS_PASSWORD);
            mobileTrackerSettings.setPassword(UZGPS_CONST.MTRACKER_DEFAULT_SETTINGS_PASSWORD);
            mobileTrackerSettings.setHideIcon(UZGPS_CONST.MTRACKER_DEFAULT_HIDE_ICON);
            mobileTrackerSettings.setSettingsUpdateTime(UZGPS_CONST.MTRACKER_DEFAULT_SETTINGS_UPDATE_TIME);
            mobileTrackerSettings.setLocationUpdateTime(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_TIME);
            mobileTrackerSettings.setLocationUpdateDistance(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_DISTANCE);
            mobileTrackerSettings.setLocationUpdateAccuracy(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_ACCURACY);
            mobileTrackerSettings.setLocationUpdateAngle(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_UPDATE_ANGLE);
            mobileTrackerSettings.setShouldChangeStatus(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_STATUS_CHANGE);
            mobileTrackerSettings.setRecordLimit(UZGPS_CONST.MTRACKER_DEFAULT_RECORD_LIMIT);
            mobileTrackerSettings.setLocationSendTime(UZGPS_CONST.MTRACKER_DEFAULT_LOCATION_SEND_TIME);
            mobileTrackerSettings.setShouldSend3G(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_SEND_3G);
            mobileTrackerSettings.setShouldSendWiFi(UZGPS_CONST.MTRACKER_DEFAULT_SHOULD_SEND_WIFI);
            mobileTrackerSettings.setTrackLength(UZGPS_CONST.MTRACKER_DEFAULT_TRACK_LENGTH);
            mobileTrackerSettings.setMapType(UZGPS_CONST.MTRACKER_DEFAULT_MAP_TYPE);
            mobileTrackerSettings.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            mobileTrackerSettings.setServerIp(UZGPS_CONST.MTRACKER_DEFAULT_SERVER_IP);
            mobileTrackerSettings.setServerPort(UZGPS_CONST.MTRACKER_DEFAULT_SERVER_PORT);
            mobileTrackerSettings.setRegDate(new Timestamp(System.currentTimeMillis()));

            settingsService.saveMobileTrackerSettings(mobileTrackerSettings);

            return mobileTrackerSettings;
        }

        return null;
    }
    /* ========================== NEW MOBILE TRACKER SETTINGS ========================== << */
}
