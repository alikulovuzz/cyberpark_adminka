package uzgps.mobile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import uzgps.admin.AdminService;
import uzgps.common.UZGPS_CONST;
import uzgps.mobile.data.Errors;
import uzgps.mobile.data.Response;
import uzgps.persistence.*;
import uzgps.settings.SettingsService;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by Gayratjon on 12/12/2014.
 */

@Controller
public class MobileTrackerController {
    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_MOBILE_TRACKER_SETTINGS = "/mobile-tracker/settings.json";
    private final static String URL_MOBILE_TRACKER_SETTINGS_SAVE = "/mobile-tracker/settings-save.json";
    private final static String URL_MOBILE_TRACKER_VIEW_STATUS_SAVE = "/mobile-tracker/status-save.json";

    public final static int  MOBJECT_STATUS_FREE_INDEX = 0;
    private final static int MOBJECT_STATUS_BUSY_INDEX = 1;
    private final static int MOBJECT_STATUS_ON_ROUTE_INDEX = 2;
    private final static int MOBJECT_STATUS_ARRIVED_INDEX = 3;

    public final static String MOBJECT_STATUS_FREE = "mobject.status.free";
    private final static String MOBJECT_STATUS_BUSY = "mobject.status.busy";
    private final static String MOBJECT_STATUS_ON_ROUTE = "mobject.status.on.route";
    private final static String MOBJECT_STATUS_ARRIVED = "mobject.status.arrived";

    public final static String MOBJECT_STATUS_FREE_COLOR = "#0000FF";
    private final static String MOBJECT_STATUS_BUSY_COLOR = "#FF0000";
    private final static String MOBJECT_STATUS_ON_ROUTE_COLOR = "#FFFF00";
    private final static String MOBJECT_STATUS_ARRIVED_COLOR = "#00FF00";

    @Autowired
    ObjectMapper jsonMapper;

    @Autowired
    SettingsService settingsService;

    @Autowired
    AdminService adminService;

    @RequestMapping(value = URL_MOBILE_TRACKER_SETTINGS)
    private void getMobileTrackerSettings(HttpServletResponse httpServletResponse,
                                 @RequestParam(value = "data") String data) {
        if (logger.isDebugEnabled()) {
            logger.debug("data: {}", data);
        }

        Response<MobileTrackerSettings> response;
        Set<String> ignorableFields = new HashSet<>();
        if (data != null && data.length() > 0) {
            try {
                JsonNode jsonNode = jsonMapper.readTree(data);
                String serial = jsonNode.get("serial").asText();

                if (logger.isDebugEnabled()) {
                    logger.debug("Mobile serial: {}", serial);
                }

                MobileTrackerSettings mobileTrackerSettings = settingsService.getMobileTrackerSettingsBySerial(serial);
                response = new Response<>(mobileTrackerSettings, Errors.CODE_SUCCESS);
            } catch (Exception e) {
                logger.error(e.getMessage());
                response = new Response<>(null, Errors.CODE_FAIL);
                ignorableFields.add("data");
            }
        } else {
            response = new Response<>(null, Errors.CODE_FAIL);
            ignorableFields.add("data");
        }

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            ObjectWriter objectWriter = jsonMapper.writer(filterProvider);

            byte[] jsonData = objectWriter.writeValueAsBytes(response);
            httpServletResponse.setContentType("application/json");
            httpServletResponse.setContentLength(jsonData.length);
            ServletOutputStream outStream = httpServletResponse.getOutputStream();
            outStream.write(jsonData);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    @RequestMapping(value = URL_MOBILE_TRACKER_SETTINGS_SAVE)
    private void saveMobileTrackerSettings(HttpServletResponse httpServletResponse,
                                          @RequestParam(value = "data") String data) {
        if (logger.isDebugEnabled()) {
            logger.debug("data: {}", data);
        }

        Response<MobileTrackerSettings> response;
        Set<String> ignorableFields = new HashSet<>();

        if (data != null && data.length() > 0) {
            try {
                MobileTrackerSettings mobileTrackerSettings = jsonMapper.readValue(data, MobileTrackerSettings.class);

                if (logger.isDebugEnabled()) {
                    logger.debug("Converted mobileTrackerSettings from Json: {}", mobileTrackerSettings.toString());
                }

                MobileTrackerSettings mTrackerSettings = settingsService.getMobileTrackerSettingsBySerial(mobileTrackerSettings.getMobileSerial());

                if (mTrackerSettings != null) {
                    mTrackerSettings.setHasPassword(mobileTrackerSettings.getHasPassword());
                    mTrackerSettings.setPassword(mobileTrackerSettings.getPassword());
                    mTrackerSettings.setLocationUpdateTime(mobileTrackerSettings.getLocationUpdateTime());
                    mTrackerSettings.setLocationUpdateDistance(mobileTrackerSettings.getLocationUpdateDistance());
                    mTrackerSettings.setLocationUpdateAngle(mobileTrackerSettings.getLocationUpdateAngle());
                    mTrackerSettings.setLocationUpdateAccuracy(mobileTrackerSettings.getLocationUpdateAccuracy());
                    mTrackerSettings.setShouldChangeStatus(mobileTrackerSettings.getShouldChangeStatus());
                    mTrackerSettings.setRecordLimit(mobileTrackerSettings.getRecordLimit());
                    mTrackerSettings.setLocationSendTime(mobileTrackerSettings.getLocationSendTime());
                    mTrackerSettings.setShouldSend3G(mobileTrackerSettings.getShouldSend3G());
                    mTrackerSettings.setShouldSendWiFi(mobileTrackerSettings.getShouldSendWiFi());
                    mTrackerSettings.setMapType(mobileTrackerSettings.getMapType());
                    mTrackerSettings.setTrackLength(mobileTrackerSettings.getTrackLength());
                    mTrackerSettings.setSosNumber1(mobileTrackerSettings.getSosNumber1());
                    mTrackerSettings.setSosNumber2(mobileTrackerSettings.getSosNumber2());
                    mTrackerSettings.setSosNumber3(mobileTrackerSettings.getSosNumber3());
                    mTrackerSettings.setSosNumber4(mobileTrackerSettings.getSosNumber4());
                    mTrackerSettings.setSosNumber5(mobileTrackerSettings.getSosNumber5());
                    mTrackerSettings.setSosNumber6(mobileTrackerSettings.getSosNumber6());
                    mTrackerSettings.setSosNumber7(mobileTrackerSettings.getSosNumber7());
                    mTrackerSettings.setModDate(new Timestamp(System.currentTimeMillis()));

                    settingsService.saveMobileTrackerSettings(mTrackerSettings);

                    response = new Response<>(mTrackerSettings, Errors.CODE_SUCCESS);
                } else {
                    response = new Response<>(null, Errors.CODE_FAIL);
                    ignorableFields.add("data");
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
                response = new Response<>(null, Errors.CODE_FAIL);
                ignorableFields.add("data");
            }
        } else {
            response = new Response<>(null, Errors.CODE_FAIL);
            ignorableFields.add("data");
        }

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            ObjectWriter objectWriter = jsonMapper.writer(filterProvider);

            byte[] jsonData = objectWriter.writeValueAsBytes(response);
            httpServletResponse.setContentType("application/json");
            httpServletResponse.setContentLength(jsonData.length);
            ServletOutputStream outStream = httpServletResponse.getOutputStream();
            outStream.write(jsonData);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    @RequestMapping(value = URL_MOBILE_TRACKER_VIEW_STATUS_SAVE)
    private void saveMobileTrackerViewStatus(HttpServletResponse httpServletResponse,
                                           @RequestParam(value = "data") String data) {
        if (logger.isDebugEnabled()) {
            logger.debug("data: {}", data);
        }

        Response<MobileTrackerSettings> response;
        Set<String> ignorableFields = new HashSet<>();
        ignorableFields.add("data");

        int errorCode;

        if (data != null && data.length() > 0) {
            try {
                MobileTrackerStatus mobileTrackerStatus = jsonMapper.readValue(data, MobileTrackerStatus.class);

                if (logger.isDebugEnabled()) {
                    logger.debug("Converted mobileTrackerStatus from Json: {}", mobileTrackerStatus.toString());
                }

                if (mobileTrackerStatus != null) {
                    // At First find out which object is attached to the given mobile tracker
                    GPSUnit gpsUnit = adminService.getGPSUniteByIMEI(mobileTrackerStatus.getMobileSerial());

                    if (gpsUnit != null) {
                        List<MObjectGPSUnit> mObjectGPSUnitList = adminService.getMObjectGPSUnitByUnitId(gpsUnit.getId());

                        if (mObjectGPSUnitList != null && mObjectGPSUnitList.size() > 0) {
                            MObjectGPSUnit mObjectGPSUnit = mObjectGPSUnitList.get(0);
                            MObject mObject = mObjectGPSUnit.getmObject();

                            if (mObject != null) {
//                                Integer stIndex = mobileTrackerStatus.getIndex();
//                                String stSerial = mobileTrackerStatus.getMobileSerial();
//                                String stSerial = "0";
//
//                                // If index is greater than 100 that means mobile tracker status is user generated, not system's
//                                if (stIndex >= 100) {
//                                    stSerial = mobileTrackerStatus.getMobileSerial();
//                                }
//                                MobileTrackerStatus mtStatus = saveMobileTrackerStatus(mobileTrackerStatus, stIndex, stSerial);

                                mobileTrackerStatus = saveMobileTrackerStatus(mobileTrackerStatus);
                                mObject.setMobileTrackerStatus(mobileTrackerStatus);
                                settingsService.saveMObject(mObject);

                                errorCode = Errors.CODE_SUCCESS;
                            } else {
                                errorCode = Errors.CODE_FAIL;
                            }
                        } else {
                            errorCode = Errors.CODE_FAIL;
                        }
                    } else {
                        errorCode = Errors.CODE_FAIL;
                    }
                } else {
                    errorCode = Errors.CODE_FAIL;
                }
            } catch (Exception e) {
                logger.error(e.getMessage());
                errorCode = Errors.CODE_FAIL;
            }
        } else {
            errorCode = Errors.CODE_FAIL;
        }

        response = new Response<>(null, errorCode);

        try {
            SimpleFilterProvider filterProvider = new SimpleFilterProvider();
            filterProvider.addFilter("ResponseFilter", SimpleBeanPropertyFilter.serializeAllExcept(ignorableFields));

            ObjectWriter objectWriter = jsonMapper.writer(filterProvider);

            byte[] jsonData = objectWriter.writeValueAsBytes(response);
            httpServletResponse.setContentType("application/json");
            httpServletResponse.setContentLength(jsonData.length);
            ServletOutputStream outStream = httpServletResponse.getOutputStream();
            outStream.write(jsonData);
            outStream.close();
        } catch (IOException e) {
            logger.error("Error: ", e);
        }
    }

    public MobileTrackerStatus saveMobileTrackerStatus(MobileTrackerStatus mobileTrackerStatus, Integer index, String serial) {
        MobileTrackerStatus mtStatus = settingsService.getMobileTrackerStatusByIndexAndSerial(index, serial);

        String stName = "";
        String stColor = "";

        if (mobileTrackerStatus != null) {
            stName = mobileTrackerStatus.getName();
            stColor = mobileTrackerStatus.getColor();
        }

        // Update or save the given mobile tracker status
        if (mtStatus != null && index >= 100) {
            mtStatus.setName(stName);
            mtStatus.setColor(stColor);
            mtStatus.setModDate(new Timestamp(System.currentTimeMillis()));
            settingsService.saveMobileTrackerStatus(mtStatus);
        } else if (mtStatus == null) {
            switch (index) {
                case MOBJECT_STATUS_FREE_INDEX: {
                    stName = MOBJECT_STATUS_FREE;
                    stColor = MOBJECT_STATUS_FREE_COLOR;
                }
                break;
                case MOBJECT_STATUS_BUSY_INDEX: {
                    stName = MOBJECT_STATUS_BUSY;
                    stColor = MOBJECT_STATUS_BUSY_COLOR;
                }
                break;
                case MOBJECT_STATUS_ON_ROUTE_INDEX: {
                    stName = MOBJECT_STATUS_ON_ROUTE;
                    stColor = MOBJECT_STATUS_ON_ROUTE_COLOR;
                }
                break;
                case MOBJECT_STATUS_ARRIVED_INDEX: {
                    stName = MOBJECT_STATUS_ARRIVED;
                    stColor = MOBJECT_STATUS_ARRIVED_COLOR;
                }
                break;
            }

            mtStatus = new MobileTrackerStatus();
            mtStatus.setIndex(index);
            mtStatus.setMobileSerial(serial);
            mtStatus.setName(stName);
            mtStatus.setColor(stColor);
            mtStatus.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            mtStatus.setRegDate(new Timestamp(System.currentTimeMillis()));
            settingsService.saveMobileTrackerStatus(mtStatus);
        }

        return mtStatus;
    }

    public MobileTrackerStatus saveMobileTrackerStatus(MobileTrackerStatus mobileTrackerStatus) {
        if (mobileTrackerStatus == null) {
            return null;
        }

        MobileTrackerStatus mtStatus = settingsService.getMobileTrackerStatusBySerial(mobileTrackerStatus.getMobileSerial());

        String stName = mobileTrackerStatus.getName();
        String stColor = mobileTrackerStatus.getColor();

        switch (mobileTrackerStatus.getIndex()) {
            case MOBJECT_STATUS_FREE_INDEX: {
                stName = MOBJECT_STATUS_FREE;
                stColor = MOBJECT_STATUS_FREE_COLOR;
            }
            break;
            case MOBJECT_STATUS_BUSY_INDEX: {
                stName = MOBJECT_STATUS_BUSY;
                stColor = MOBJECT_STATUS_BUSY_COLOR;
            }
            break;
            case MOBJECT_STATUS_ON_ROUTE_INDEX: {
                stName = MOBJECT_STATUS_ON_ROUTE;
                stColor = MOBJECT_STATUS_ON_ROUTE_COLOR;
            }
            break;
            case MOBJECT_STATUS_ARRIVED_INDEX: {
                stName = MOBJECT_STATUS_ARRIVED;
                stColor = MOBJECT_STATUS_ARRIVED_COLOR;
            }
            break;
        }

        // Update or save the given mobile tracker status
        if (mtStatus == null) {
            mtStatus = new MobileTrackerStatus();
            mtStatus.setMobileSerial(mobileTrackerStatus.getMobileSerial());
            mtStatus.setStatus(UZGPS_CONST.STATUS_ACTIVE);
            mtStatus.setRegDate(new Timestamp(System.currentTimeMillis()));
        } else {
            mtStatus.setModDate(new Timestamp(System.currentTimeMillis()));
        }

        mtStatus.setIndex(mobileTrackerStatus.getIndex());
        mtStatus.setName(stName);
        mtStatus.setColor(stColor);

        settingsService.saveMobileTrackerStatus(mtStatus);

        return mtStatus;
    }
}
