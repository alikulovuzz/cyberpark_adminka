package uzgps.mobile.data;

/**
 * Created by Gayratjon on 11/10/2014.
 */
public class MobileInfo {

    private Long id;
    private String serial;
    private String imei;
    private String model;
    private String os;
    private String sim;
    private Integer battery;
    private Integer gsm;
    private Long time;
    private String status;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSerial() {
        return serial;
    }

    public void setSerial(String serial) {
        this.serial = serial;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getOs() {
        return os;
    }

    public void setOs(String os) {
        this.os = os;
    }

    public String getSim() {
        return sim;
    }

    public void setSim(String sim) {
        this.sim = sim;
    }

    public Integer getBattery() {
        return battery;
    }

    public void setBattery(Integer battery) {
        this.battery = battery;
    }

    public Integer getGsm() {
        return gsm;
    }

    public void setGsm(Integer gsm) {
        this.gsm = gsm;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "MobileInfo{" +
                "id=" + id +
                ", serial='" + serial + '\'' +
                ", imei='" + imei + '\'' +
                ", model='" + model + '\'' +
                ", os='" + os + '\'' +
                ", sim='" + sim + '\'' +
                ", battery=" + battery +
                ", gsm=" + gsm +
                ", time=" + time +
                ", status='" + status + '\'' +
                '}';
    }
}
