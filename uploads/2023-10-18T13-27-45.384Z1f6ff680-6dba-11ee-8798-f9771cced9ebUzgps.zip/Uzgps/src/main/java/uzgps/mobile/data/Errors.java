package uzgps.mobile.data;

/**
 * Created by Gayratjon on 11/8/2014.
 */
public class Errors {
    public static final int CODE_SUCCESS = 0;
    public static final int CODE_FAIL = 1;

    public static final int CODE_OVER_MAX_UNIT_LIMIT = 10;

    public static final String MESSAGE_SUCCESS = "success";
    public static final String MESSAGE_FAIL = "fail";
}
