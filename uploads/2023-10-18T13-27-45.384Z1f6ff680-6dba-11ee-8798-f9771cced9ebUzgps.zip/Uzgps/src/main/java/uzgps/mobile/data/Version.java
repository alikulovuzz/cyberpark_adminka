package uzgps.mobile.data;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Created by Gayratjon on 11/8/2014.
 */
public class Version {
    @JsonProperty("ver")
    private Integer number;
    private String url;

    public Version(Integer number, String url) {
        this.number = number;
        this.url = url;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
