package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminService;
import uzgps.common.FileStorageService;
import uzgps.common.RoleInfo;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.RoleConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.*;
import uzgps.security.MD5;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

//import sun.applet.Main;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsUsersController extends AbstractSettingsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_USERS = "/settings/users.htm";
    private final static String VIEW_SETTINGS_USERS = "settings/settings-users";

    private final static String URL_SETTINGS_USERS_MANAGE = "/settings/user-manage.htm";
    private final static String VIEW_SETTINGS_USERS_MANAGE = "settings/settings-user-manage";

    private final static String URL_SETTINGS_USER_PROFILE = "/settings/user-profile.htm";
    private final static String URL_SETTINGS_USER_PROFILE_MANAGE = "/settings/user-profile-manage.htm";
    private final static String URL_SETTINGS_USER_PROFILE_ACCESS = "/settings/user-access-manage.htm";
    private final static String VIEW_SETTINGS_USER_PROFILE = "settings/settings-user-profile";

    private final static String URL_SETTINGS_USER_PROFILE_PASSWORD = "/settings/user-password-manage.htm";
    private final static String VIEW_SETTINGS_USER_PROFILE_PASSWORD = "settings/settings-user-password";

    private final static String URL_SETTINGS_THIRD_PARTY_USERS = "/settings/third-party-users.htm";
    private final static String VIEW_SETTINGS_THIRD_PARTY_USERS = "settings/settings-third-party-users";

    private final static String URL_SETTINGS_THIRD_PARTY_USERS_MANAGE = "/settings/third-party-users-manage.htm";

    private final static String URL_SETTINGS_AJAX_CHECK_VALUE = "/settings/ajax-check-value.htm";
    private final static String VIEW_SETTINGS_AJAX_CHECK_VALUE = "settings/ajax-check-value";
    private final static String SESSION_SETTINGS_STAFF_USER_SEARCH = "sessionUserTextSearch";
    private final static String SESSION_SETTINGS_THIRD_PARTY_USER_SEARCH = "sessionThirdPartyUserTextSearch";

    private final static String URL_SETTINGS_USER_POI_ZOI_ACCESS = "/settings/user-poi-zoi-access.htm";
    private final static String URL_SETTINGS_USER_POI_ZOI_ACCESS_SAVE = "/settings/user-poi-zoi-access-save.htm";

    private final static String VIEW_SETTINGS_USER_POI_ZOI_ACCESS = "settings/settings-user-poi-zoi-access";


    @Autowired
    private SettingsService settingsService;

    @Autowired
    private AdminService adminService;

    @Autowired
    CoreMain coreMain;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    FileStorageService storageService;

    @RequestMapping(value = URL_SETTINGS_USERS)
    public ModelAndView processSettingsUsers(HttpSession session, @RequestParam(value = "errorNumber", required = false) String errorNumber,
                                             @RequestParam(value = "textSearch", required = false, defaultValue = "") String textSearch,
                                             @RequestParam(value = "cmd", required = false) String cmd) {
        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_USERS);

        if (cmd != null) {
            if (cmd.equalsIgnoreCase("clear")) {
                session.removeAttribute(SESSION_SETTINGS_STAFF_USER_SEARCH);
            }
        }

        if (textSearch.length() == 0) {
            textSearch = (String) session.getAttribute(SESSION_SETTINGS_STAFF_USER_SEARCH);
        }

        // Count numbers for each type of objebts
        long userMaxCount = 0;
        long mobjectMaxCount = 0;
        long staffMaxCount = 0;
//        long poiMaxCount = 0;
//        long zoiMaxCount = 0;

        // Contract for this user
        Contract contract = settingsService.getContractById(MainController.getUserContractId(session));

        // if contract exists, take limits for max counts
        if (contract != null) {
            // Available number of users
            if (contract.getActiveMaxUserCount() != null) {
                userMaxCount = contract.getActiveMaxUserCount();
            }

            // Available number of MObjects
            if (contract.getActiveMaxUnitCount() != null) {
                mobjectMaxCount = contract.getActiveMaxUnitCount();
            }

            // Available number of Staff
            if (contract.getActiveMaxStaffCount() != null) {
                staffMaxCount = contract.getActiveMaxStaffCount();
            }

        }
        modelAndView.addObject("userMaxCount", userMaxCount);
        modelAndView.addObject("mobjectMaxCount", mobjectMaxCount);
        modelAndView.addObject("staffMaxCount", staffMaxCount);

        // Get User list for this contract
        List<User> thirdPartyUsers = settingsService.getThirdPartyUsersByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("thirdPartyUsers", thirdPartyUsers);
        List<User> users = settingsService.getCustomerUsersByContractIdAndText(MainController.getUserContractId(session), textSearch);
        modelAndView.addObject("users", users);
        session.setAttribute(SESSION_SETTINGS_STAFF_USER_SEARCH, textSearch);
        modelAndView.addObject("textSearch", textSearch);

        // get User count
        int userCount = 0;
        if (users != null) {
            userCount = users.size();
        }
        modelAndView.addObject("usersCount", userCount);
        modelAndView.addObject("userId", "0");
        modelAndView.addObject("errorNumber", errorNumber);

        addObjectsCountToModel(session, modelAndView);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        modelAndView.addObject("selectedLeftMenu", "users");

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_THIRD_PARTY_USERS)
    public ModelAndView processSettingsThirdPartyUsers(HttpSession session, @RequestParam(value = "errorNumber", required = false) String errorNumber,
                                                       @RequestParam(value = "textSearch", required = false, defaultValue = "") String textSearch,
                                                       @RequestParam(value = "cmd", required = false) String cmd) {
        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_THIRD_PARTY_USERS);

        if (cmd != null) {
            if (cmd.equalsIgnoreCase("clear")) {
                session.removeAttribute(SESSION_SETTINGS_THIRD_PARTY_USER_SEARCH);
            }
        }

        if (textSearch.length() == 0) {
            textSearch = (String) session.getAttribute(SESSION_SETTINGS_THIRD_PARTY_USER_SEARCH);
        }

        // Contract for this user
        Contract contract = settingsService.getContractById(MainController.getUserContractId(session));

        //get All Company Users for select element

        Long userId = 0L;
        if (MainController.getInterfaceUserId() != null) {
            userId = MainController.getInterfaceUserId();
        } else {
            userId = MainController.getUserId();
        }

        List<Contract> userContractsByUserId = settingsService.getUserContractsByUserId(userId);
        List<Long> userContractIds = new ArrayList<>();

        if (userContractsByUserId != null) {
            userContractIds = userContractsByUserId
                    .stream()
                    .map(Contract::getId)
                    .filter(id -> !Objects.equals(id, contract.getId()))
                    .collect(Collectors.toList());
        }

        List<User> usersByCustomerAdminContracts = settingsService.getUsersByContractIdList(userContractIds, contract.getId());
        modelAndView.addObject("usersByCustomerAdminContracts", usersByCustomerAdminContracts);

        //get attached users from another contract
        List<User> thirdPartyUsers = settingsService.getThirdPartyUsersByContractIdAndText(MainController.getUserContractId(session), textSearch);
        modelAndView.addObject("thirdPartyUsers", thirdPartyUsers);

        //get regular user
        List<User> users = settingsService.getCustomerUsersByContractId(contract.getId());
        modelAndView.addObject("users", users);

        session.setAttribute(SESSION_SETTINGS_THIRD_PARTY_USER_SEARCH, textSearch);
        modelAndView.addObject("textSearch", textSearch);

        modelAndView.addObject("userId", "-1");
        modelAndView.addObject("errorNumber", errorNumber);

        addObjectsCountToModel(session, modelAndView);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        modelAndView.addObject("selectedLeftMenu", "users");

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_THIRD_PARTY_USERS_MANAGE)
    public ModelAndView processSettingsThirdPartyUserManage(HttpSession session,
                                                            @RequestParam(value = "cmd", required = false) String cmd,
                                                            @RequestParam(value = "user-id", required = false) Long userId) {


        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_THIRD_PARTY_USERS);

        if (userId == null || userId <= 0) {
            return modelAndView;
        }

        if (cmd != null && cmd.equalsIgnoreCase("save")) {

            User user = settingsService.getUserByUserId(userId);
            UserAccessList userAccessList;

            UserAccessList accessListByUserContractId = settingsService.getUserAccessListByUserContractId(userId, MainController.getUserContractId(session));

            if (accessListByUserContractId != null) {
                userAccessList = accessListByUserContractId;
            } else {
                userAccessList = new UserAccessList();
            }

            userAccessList.setUser(user);
            userAccessList.setMap(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setMonitoring(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setTracker(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setPoi(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setGeoZone(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setMessage(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setReport(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setDashboard(UZGPS_CONST.USER_ACCESS_NONE);
            userAccessList.setFms(UZGPS_CONST.USER_ACCESS_NONE);

            userAccessList.setRegDate(new Timestamp(System.currentTimeMillis()));
            userAccessList.setContract(MainController.getUserContract(session));
            settingsService.saveUserAccessList(userAccessList);

            UserRole userRole = new UserRole();
            userRole.setUser(user);

            RoleConfiguration roleConfiguration = appConfiguration.getRoleConfiguration();
            RoleInfo[] roleInfos = roleConfiguration.getRoleInfo();
            for (RoleInfo roleInfo : roleInfos) {
                if (roleInfo.getType().equalsIgnoreCase("ROLE_USER")) {
                    userRole.setRoleId((long) roleInfo.getId());
                    userRole.setContract(MainController.getUserContract(session));
                    userRole.setRegDate(new Timestamp(System.currentTimeMillis()));
                    userRole.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                }
            }
            settingsService.saveUseRole(userRole);


        } else if (cmd != null && cmd.equalsIgnoreCase("remove")) {

            UserRole userRole = settingsService.findUserRoleByUserIdAndContractId(userId, MainController.getUserContractId(session));
            userRole.setStatus(UZGPS_CONST.STATUS_DELETE);

            settingsService.saveUseRole(userRole);

            UserAccessList userAccessList = settingsService.getUserAccessListByUserContractId(userId, MainController.getUserContractId(session));

            if (userAccessList != null) {
                userAccessList.setMap(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setMonitoring(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setTracker(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setPoi(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setGeoZone(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setMessage(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setReport(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setDashboard(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setFms(UZGPS_CONST.USER_ACCESS_NONE);
                userAccessList.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveUserAccessList(userAccessList);
            }

        }

        return modelAndView;
    }

    /**
     * Add or edit a user with the given parameters
     *
     * @param cmd
     * @param surName
     * @param name
     * @param middleName
     * @param login
     * @param password
     * @param userId
     * @param rUsersIdList
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_SETTINGS_USERS_MANAGE)
    public ModelAndView processSettingsUserManage(HttpSession session,
                                                  @RequestParam(value = "cmd", required = false) String cmd,
                                                  @RequestParam(value = "sur-name", required = false) String surName,
                                                  @RequestParam(value = "name", required = false) String name,
                                                  @RequestParam(value = "middle-name", required = false) String middleName,
                                                  @RequestParam(value = "user-l", required = false) String login,
                                                  @RequestParam(value = "user-p", required = false) String password,
                                                  @RequestParam(value = "id", required = false) Long userId,
                                                  @RequestParam(value = "r-id[]", required = false) Long[] rUsersIdList) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsUserManage cmd={}, sur-name={}, name={}, middle-name={}, login={}, password={}, id={}, r-id[]={}",
                    cmd, surName, name, middleName, login, password, userId, rUsersIdList);
        }

        ModelAndView modelAndView = null;

        if (cmd != null) {

            if (cmd.equalsIgnoreCase("save")) {

                // Clear login
                login = (login != null) ? login.trim().toLowerCase() : "";

                User user1 = adminService.getUserByLogin(login);
                if (user1 != null && user1.getId() != null) {
                    modelAndView = new ModelAndView(VIEW_SETTINGS_USERS_MANAGE);
                    Profile profile = new Profile();
                    user1.setProfile(profile);
//                    user1.setUserTypeId(UZGPS_CONST.USER_TYPE_CUSTOMER_USER);
                    Role role = adminService.getRoleById(UZGPS_CONST.USER_ROLE_USER);
                    user1.setRole(role);
                    user1.setLogin(login);

                    MD5 md5 = new MD5();
                    password = md5.getMD5(password);
                    user1.setPassword(password);

                    user1.setSurName(surName);
                    user1.setName(name);
                    user1.setMiddleName(middleName);

                    user1.setStatus(UZGPS_CONST.USER_STATUS_ACTIVE);
                    user1.setBlock(UZGPS_CONST.USER_BLOCK_STATUS_UNBLOCK);
                    user1.setRegDate(new Timestamp(System.currentTimeMillis()));
                    modelAndView.addObject("user", user1);
                    modelAndView.addObject("cmd", "save");
                    modelAndView.addObject("error_txt", "Такой Login существует в базе!");
                } else {
                    // Try to save user
                    User user = new User();

                    user.setManagerId(MainController.getUserId());

                    Profile profile = new Profile();
                    settingsService.saveProfile(profile);

                    user.setProfile(profile);
//                    user.setUserTypeId(UZGPS_CONST.USER_TYPE_CUSTOMER_USER);
                    Role role = adminService.getRoleById(UZGPS_CONST.USER_ROLE_USER);
                    user.setRole(role);
                    user.setLogin(login);

                    MD5 md5 = new MD5();
                    password = md5.getMD5(password);
                    user.setPassword(password);

                    user.setSurName(surName);
                    user.setName(name);
                    user.setMiddleName(middleName);

                    user.setContract(MainController.getUserContract(session));

                    user.setStatus(UZGPS_CONST.USER_STATUS_ACTIVE);
                    user.setBlock(UZGPS_CONST.USER_BLOCK_STATUS_UNBLOCK);
                    user.setRegDate(new Timestamp(System.currentTimeMillis()));
                    settingsService.saveUser(user);

                    UserAccessList userAccessList = new UserAccessList();
                    userAccessList.setUser(user);
                    userAccessList.setMap(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setMonitoring(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setTracker(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setPoi(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setGeoZone(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setMessage(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setReport(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setDashboard(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setFms(UZGPS_CONST.USER_ACCESS_NONE);
//                    userAccessList.setTrackStatistics(UZGPS_CONST.USER_ACCESS_NONE);
                    userAccessList.setRegDate(new Timestamp(System.currentTimeMillis()));
                    userAccessList.setContract(MainController.getUserContract(session));
                    settingsService.saveUserAccessList(userAccessList);

                    UserRole userRole = new UserRole();
                    userRole.setUser(user);

                    RoleConfiguration roleConfiguration = appConfiguration.getRoleConfiguration();
                    RoleInfo[] roleInfos = roleConfiguration.getRoleInfo();
                    for (RoleInfo roleInfo : roleInfos) {
                        if (roleInfo.getType().equalsIgnoreCase(USER_ROLE_USER_STR)) {
                            userRole.setRoleId((long) roleInfo.getId());
                            userRole.setContract(MainController.getUserContract(session));
                            userRole.setRegDate(new Timestamp(System.currentTimeMillis()));
                            userRole.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        }
                    }
                    settingsService.saveUseRole(userRole);

                    // After Save Redirect to User Profile to next edit
                    modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USER_PROFILE + "?user-id=" + user.getId());
                }
            } else if (cmd.equalsIgnoreCase("edit")) {
                // Redirect to Staff Profile to edit
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USER_PROFILE + "?user-id=" + userId);

            } else if (cmd.equalsIgnoreCase("update")) {
                User user = settingsService.getUserById(userId);
                user.setSurName(surName);
                user.setName(name);
                user.setMiddleName(middleName);
                user.setLogin(login.toLowerCase());

                // user's password should not be null and its length greater than 1
                if (password != null && password.length() > 1) {
                    MD5 md5 = new MD5();
                    password = md5.getMD5(password);
                    user.setPassword(password);
                }

                user.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveUser(user);
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USERS);
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rUsersId : rUsersIdList) {
                    User user = settingsService.getUserById(rUsersId);
                    user.setExpDate(new Timestamp(System.currentTimeMillis()));
                    user.setStatus(UZGPS_CONST.STATUS_DELETE);
                    settingsService.saveUser(user);

                    settingsService.updateUserMObjectAccessList(rUsersId);

                    // Core Update for User Mobject Access By User Id
                    coreMain.coreUpdater.updateUserMobjectAccessByUserId(rUsersId);
                }

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USERS);
            }
        } else {
            Long counter = settingsService.getUsersCountByContractId(MainController.getUserContractId(session));
            Long maxUsersCount = MainController.getUserContract(session).getActiveMaxUserCount();

            if (counter != null && counter.equals(maxUsersCount)) {
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USERS + "?errorNumber=1");
            } else {
                modelAndView = new ModelAndView(VIEW_SETTINGS_USERS_MANAGE);
                modelAndView.addObject("cmd", "save");

                List<User> thirdPartyUsers = settingsService.getThirdPartyUsersByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("thirdPartyUsers", thirdPartyUsers);

                List<User> users = settingsService.getCustomerUsersByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("users", users);

                addObjectsCountToModel(session, modelAndView);

                Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

                Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

                modelAndView.addObject("userId", "0");
            }
        }


        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_USER_PROFILE)
    public ModelAndView processSettingsStaffProfile(HttpSession session,
                                                    @RequestParam(value = "user-id", required = false) Long userId) {

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_USER_PROFILE);

        List<User> thirdPartyUsers = settingsService.getThirdPartyUsersByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("thirdPartyUsers", thirdPartyUsers);
        User user = settingsService.getUserById(userId);
        modelAndView.addObject("user", user);

        UserAccessList userAccessList = settingsService.getUserAccessListByUserContractId(userId, MainController.getUserContractId(session));
        modelAndView.addObject("userAccessList", userAccessList);

        UserAccessList customerAdminAccessList = settingsService.getUserAccessListByUserContractId(MainController.getUser().getId(), MainController.getUserContractId(session));
        modelAndView.addObject("customerAdminAccessList", customerAdminAccessList);

        List<UserMObjectAccessList> userMObjectAccessList = settingsService.getUserMObjectAccessListByUserIdAndContractId(userId,
                MainController.getUserContractId(session));
        modelAndView.addObject("userMObjectAccessList", userMObjectAccessList);
        modelAndView.addObject("cmd", "save");
        modelAndView.addObject("userId", userId);

        addObjectsCountToModel(session, modelAndView);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        List<User> users = settingsService.getUsersByContractIdAndRole(MainController.getUserContractId(session), UZGPS_CONST.USER_ROLE_USER);
        modelAndView.addObject("users", users);
        modelAndView.addObject("usersCount", (users != null) ? users.size() : 0);

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_USER_PROFILE_MANAGE)
    public ModelAndView processSettingsStaffProfile(@RequestParam(value = "cmd", required = false) String cmd,
                                                    @RequestParam(value = "file", required = false) MultipartFile file,
                                                    @RequestParam(value = "login", required = false) String login,
                                                    @RequestParam(value = "sur-name", required = false) String surName,
                                                    @RequestParam(value = "name", required = false) String name,
                                                    @RequestParam(value = "middle-name", required = false) String middleName,
                                                    @RequestParam(value = "position", required = false) String position,
                                                    @RequestParam(value = "phone-mobile", required = false) String phoneMobile,
                                                    @RequestParam(value = "phone-line", required = false) String phoneLine,
                                                    @RequestParam(value = "user-id", required = false) Long userId) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsStaffProfile cmd={}, sur-name={}, name={}, middle-name={}, position={}, phone-mobile={}, phone-line={}, user-id={}",
                    cmd, surName, name, middleName, position, phoneMobile, phoneLine, userId);
        }

        ModelAndView modelAndView;

        if (cmd != null) {
            User user = settingsService.getUserById(userId);

            if (file != null && file.getSize() > 0) {
                if (user.getPhoto() != null) {
                    // Remove the image of Profile if exists
                    FileStorage oldFileStorage = user.getPhoto();
                    user.setPhoto(null);
                    settingsService.saveUser(user);
                    storageService.removeFileFromStorage(oldFileStorage);
                }

                FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                user.setPhoto(fileStorage);
            } else if (file == null) {
                // Remove the image of Profile if exists
                FileStorage fileStorage = user.getPhoto();
                if (fileStorage != null) {
                    user.setPhoto(null);
                    settingsService.saveUser(user);
                    storageService.removeFileFromStorage(fileStorage);
                }
            }

            user.setLogin(login.toLowerCase());
            user.setSurName(surName);
            user.setName(name);
            user.setMiddleName(middleName);

            if (user.getProfile() != null) {
                if (position != null) {
                    user.getProfile().setPosition(position);
                }
                if (phoneMobile != null) {
                    user.getProfile().setMobilePhone(phoneMobile.replaceAll("[^0-9]", ""));
                }
                if (phoneLine != null) {
                    user.getProfile().setLinePhone(phoneLine.replaceAll("[^0-9]", ""));
                }
            }

            user.setModDate(new Timestamp(System.currentTimeMillis()));
            settingsService.saveUser(user);
        }
        modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USER_PROFILE + "?user-id=" + userId);

        return modelAndView;
    }

    /**
     * Update a given user's password with new password
     *
     * @param cmd
     * @param userId
     * @param newPassword
     * @return
     * @throws ServletException
     * @throws IOException
     */
    @RequestMapping(value = URL_SETTINGS_USER_PROFILE_PASSWORD)
    public ModelAndView processSettingsUserProfilePassword(HttpSession session,
                                                           @RequestParam(value = "cmd", required = false) String cmd,
                                                           @RequestParam(value = "user-id", required = false) Long userId,
                                                           @RequestParam(value = "new-password", required = false) String newPassword,
                                                           @RequestParam(value = "confirm-new-password", required = false) String newPassword2) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsUserProfilePassword cmd={}, user-id={}, new-password={}, confirm-new-password={}",
                    cmd, userId, newPassword, newPassword2);
        }

        ModelAndView modelAndView;

        if (cmd != null) {

            if (cmd.equalsIgnoreCase("save")) {
                /*try {*/
                MD5 md5 = new MD5();
                User user = settingsService.getUserByIdAndContractId(userId, MainController.getUserContractId(session));
                newPassword = md5.getMD5(newPassword);
                newPassword2 = md5.getMD5(newPassword2);
                if (newPassword.equalsIgnoreCase(newPassword2)) {
                    user.setPassword(newPassword);
                    settingsService.saveUser(user);
                }
            }

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USER_PROFILE + "?user-id=" + userId);
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_USER_PROFILE_PASSWORD);
            modelAndView.addObject("cmd", "save");
            modelAndView.addObject("userId", userId);

            addObjectsCountToModel(session, modelAndView);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            List<User> users = settingsService.getUsersByContractIdAndRole(MainController.getUserContractId(session), UZGPS_CONST.USER_ROLE_USER);
            modelAndView.addObject("users", users);
            modelAndView.addObject("usersCount", (users != null) ? users.size() : 0);
        }

        return modelAndView;
    }


    @RequestMapping(value = URL_SETTINGS_USER_PROFILE_ACCESS)
    public ModelAndView processSettingsUserProfileAccess(HttpSession session,
                                                         @RequestParam(value = "cmd", required = false) String cmd,
                                                         @RequestParam(value = "user-id", required = false) Long userId,
                                                         @RequestParam(value = "map-access", defaultValue = "0", required = false) Integer mapAccess,
                                                         @RequestParam(value = "monitoring-access", defaultValue = "0", required = false) Integer monitoringAccess,
                                                         @RequestParam(value = "tracker-access", defaultValue = "0", required = false) Integer trackerAccess,
                                                         @RequestParam(value = "poi-access", defaultValue = "0", required = false) Integer poiAccess,
                                                         @RequestParam(value = "geo-zone-access", defaultValue = "0", required = false) Integer geozoneAccess,
                                                         @RequestParam(value = "message-access", defaultValue = "0", required = false) Integer messageAccess,
                                                         @RequestParam(value = "report-access", defaultValue = "0", required = false) Integer reportAccess,
                                                         @RequestParam(value = "routing-access", defaultValue = "0", required = false) Integer routingAccess,
                                                         @RequestParam(value = "dashboardAccess", defaultValue = "0", required = false) Integer dashboardAccess,
                                                         @RequestParam(value = "fms-access", defaultValue = "0", required = false) Integer fmsAccess,
                                                         @RequestParam(value = "statistics-access", defaultValue = "0", required = false) Integer statisticsAccess,
                                                         @RequestParam(value = "mobject-access[]", required = false) Long[] mObjectAccessList,
                                                         @RequestParam(value = "mobject-id[]", required = false) Long[] mObjectIdList,
                                                         @RequestParam(value = "id-list[]", required = false) Long[] idList) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsUserProfileAccess cmd={}, user-id={}, monitoring-access={}, tracker-access={}, poi-access={}, geozone-access={}, message-access={}, report-access={}, mobject-access[]={}, mobject-id[]={}, id-list[]={}",
                    cmd, userId, monitoringAccess, trackerAccess, poiAccess, geozoneAccess, messageAccess, reportAccess, mObjectAccessList, mObjectIdList, idList);
        }

        ModelAndView modelAndView;

        if (cmd != null) {
            UserAccessList userAccessList = settingsService.getUserAccessListByUserContractId(userId, MainController.getUserContractId(session));
            userAccessList.setMap(mapAccess);
            userAccessList.setMonitoring(monitoringAccess);
            userAccessList.setTracker(trackerAccess);
            userAccessList.setPoi(poiAccess);
            userAccessList.setGeoZone(geozoneAccess);
            userAccessList.setMessage(messageAccess);
            userAccessList.setReport(reportAccess);
            userAccessList.setRouting(routingAccess);
            userAccessList.setDashboard(dashboardAccess);
            userAccessList.setFms(fmsAccess);
//            userAccessList.setTrackStatistics(statisticsAccess);
            userAccessList.setModDate(new Timestamp(System.currentTimeMillis()));
            settingsService.saveUserAccessList(userAccessList);

            for (int i = 0; i < mObjectAccessList.length; i++) {
                MObject mObject = settingsService.getObjectByObjectId(mObjectIdList[i]);
                UserMObjectAccessList userMObjectAccessList;

                if (idList[i] == 0) {
                    userMObjectAccessList = new UserMObjectAccessList();
                } else {
                    userMObjectAccessList = settingsService.getUserMObjectAccessById(idList[i]);
                }

                userMObjectAccessList.setmObject(mObject);
                userMObjectAccessList.setUserId(userId);
                userMObjectAccessList.setPermission(mObjectAccessList[i].intValue());

                settingsService.saveUserMObjectAccess(userMObjectAccessList);

                // Core Update for User Mobject Access
                coreMain.coreUpdater.updateUserMobjectAccessById(userMObjectAccessList.getId());
            }
        }
        modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USER_PROFILE + "?user-id=" + userId);

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_AJAX_CHECK_VALUE)
    public ModelAndView processMapMonitoringPanel(@RequestParam(value = "cmd", required = false) String cmd,
                                                  @RequestParam(value = "key", required = false) String key) {
        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_AJAX_CHECK_VALUE);

        if (cmd.equalsIgnoreCase("login")) {
            User user = settingsService.getUserByLogin(key.toLowerCase());
            if (user != null && user.getId() != null)
                modelAndView.addObject("error_txt", "Такой Login существует в базе!");
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_USER_POI_ZOI_ACCESS)
    public ModelAndView getUserPoiZoiAccess(HttpSession session,
                                            @RequestParam(value = "user-id", required = false) Long userId) {

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_USER_POI_ZOI_ACCESS);

        modelAndView.addObject("cmd", "save");

        List<User> users = settingsService.getUsersByContractIdAndRole(MainController.getUserContractId(session), UZGPS_CONST.USER_ROLE_USER);

        if (users != null && users.size() > 0) {
            if (userId == null) {
                if (users.get(0) != null) {
                    userId = users.get(0).getId();
                }
            }
        }

        modelAndView.addObject("nUserId", userId);
        modelAndView.addObject("userId", userId);

        modelAndView.addObject("selectedLeftMenu", "user-access-poi-zoi");

        List<UserPoiAccess> userPoiAccessList = settingsService.getUserPoiAccessListByUserIdAndContractId(userId,
                MainController.getUserContractId(session));

        List<UserZoiAccess> userZoiAccessList = settingsService.getUserZoiAccessListByUserIdAndContractId(userId,
                MainController.getUserContractId(session));

        modelAndView.addObject("userPoiAccesses", userPoiAccessList);
        modelAndView.addObject("userZoiAccesses", userZoiAccessList);

//        modelAndView.addObject("user", user);

//        UserAccessList userAccessList = settingsService.getUserAccessListByUserContractId(userId, MainController.getUserContractId(session));
//        modelAndView.addObject("userAccessList", userAccessList);

//        UserAccessList customerAdminAccessList = settingsService.getUserAccessListByUserContractId(MainController.getUser().getId(), MainController.getUserContractId(session));
//        modelAndView.addObject("customerAdminAccessList", customerAdminAccessList);

        addObjectsCountToModel(session, modelAndView);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        modelAndView.addObject("users", users);
        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        return modelAndView;
    }

    private void addObjectsCountToModel(HttpSession session, ModelAndView modelAndView) {
        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);
    }

    @RequestMapping(value = URL_SETTINGS_USER_POI_ZOI_ACCESS_SAVE)
    public ModelAndView saveUserPoiZoiAccess(HttpSession session,
                                             @RequestParam(value = "user-id", required = false) Long selectedUserId,
                                             @RequestParam(value = "id-list", required = false) Long[] checkedUsersIds,
                                             @RequestParam(value = "user-poi-accesses-ids[]", required = false) Long[] userPoiAccessesIds,
                                             @RequestParam(value = "user-poi-access[]", required = false) Long[] userPoiAccesses,
                                             @RequestParam(value = "poi-ids[]", required = false) Long[] poiIds,
                                             @RequestParam(value = "user-zoi-accesses-ids[]", required = false) Long[] userZoiAccessesIds,
                                             @RequestParam(value = "user-zoi-access[]", required = false) Long[] userZoiAccesses,
                                             @RequestParam(value = "zoi-ids[]", required = false) Long[] zoiIds) {
        ModelAndView modelAndView;

        try {
            // Add Poi Accesses
            applyPoiAccessesToUser(selectedUserId,
                    userPoiAccesses, userPoiAccessesIds, poiIds);

            // Add Poi Accesses to selected users
            applyPoiAccessesToSelectedUsers(selectedUserId, checkedUsersIds,
                    userPoiAccesses, userPoiAccessesIds, poiIds);

        } catch (Exception e) {
            logger.error("ERROR in SettingsUsersController - saveUserPoiAccess: " + e.getMessage());
        }

        try {
            // Add Zoi Accesses
            applyZoiAccessesToUser(selectedUserId,
                    userZoiAccesses, userZoiAccessesIds, zoiIds);

            // Add Zoi Accesses to selected users
            applyZoiAccessesToSelectedUsers(selectedUserId, checkedUsersIds,
                    userZoiAccesses, zoiIds);

        } catch (Exception e) {
            logger.error("ERROR in SettingsUsersController - saveUserZoiAccess: " + e.getMessage());
        }

        modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_USER_POI_ZOI_ACCESS + "?user-id=" + selectedUserId);

        return modelAndView;
    }

    /**
     * Apply user poi accesses to user
     *
     * @param selectedUserId
     * @param userPoiAccesses
     * @param userPoiAccessesIds
     * @param poiIds
     */
    private void applyPoiAccessesToUser(Long selectedUserId,
                                        Long[] userPoiAccesses,
                                        Long[] userPoiAccessesIds,
                                        Long[] poiIds) {

        for (int i = 0; i < userPoiAccesses.length; i++) {
            UserPoiAccess userPoiAccess;

            if (userPoiAccessesIds[i] == 0 && userPoiAccesses[i].intValue() != 0) {
                POI poi = settingsService.getPOIById(poiIds[i]);
                // Add new User poi Access
                userPoiAccess = new UserPoiAccess();

                userPoiAccess.setPoi(poi);
                userPoiAccess.setUserId(selectedUserId);
                userPoiAccess.setPermission(userPoiAccesses[i].intValue());
                userPoiAccess.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                userPoiAccess.setRegDate(new Timestamp(System.currentTimeMillis()));

                saveUserPoiAccess(userPoiAccess);
            } else if (userPoiAccessesIds[i] != 0) {
                // Update for User poi Access
                userPoiAccess = settingsService.getUserPoiAccessById(userPoiAccessesIds[i]);

                if (userPoiAccess.getPermission() != userPoiAccesses[i].intValue()) {
                    userPoiAccess.setPermission(userPoiAccesses[i].intValue());
                    userPoiAccess.setModDate(new Timestamp(System.currentTimeMillis()));

                    saveUserPoiAccess(userPoiAccess);
                }
            }
        }
    }

    /**
     * Apply user poi accesses to checked users
     *
     * @param selectedUserId
     * @param checkedUsersIds
     * @param userPoiAccesses
     * @param userPoiAccessesIds
     * @param poiIds
     */
    private void applyPoiAccessesToSelectedUsers(Long selectedUserId,
                                                 Long[] checkedUsersIds,
                                                 Long[] userPoiAccesses,
                                                 Long[] userPoiAccessesIds,
                                                 Long[] poiIds) {

        if (selectedUserId != null && checkedUsersIds != null) {

            for (Long checkedUserId : checkedUsersIds) {
                if (selectedUserId.equals(checkedUserId)) {
                    continue;
                }

                for (int i = 0; i < userPoiAccesses.length; i++) {
                    UserPoiAccess userPoiAccess = settingsService.getUserPoiAccessByUserIdAndPoiId(checkedUserId, poiIds[i]);

                    if (userPoiAccess == null && userPoiAccesses[i].intValue() != 0) {
                        POI poi = settingsService.getPOIById(poiIds[i]);

                        // Core Add new User poi Access
                        userPoiAccess = new UserPoiAccess();

                        userPoiAccess.setPoi(poi);
                        userPoiAccess.setUserId(checkedUserId);
                        userPoiAccess.setPermission(userPoiAccesses[i].intValue());
                        userPoiAccess.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        userPoiAccess.setRegDate(new Timestamp(System.currentTimeMillis()));

                        saveUserPoiAccess(userPoiAccess);
                    } else if (userPoiAccess != null) {
                        if (userPoiAccess.getPermission() != userPoiAccesses[i].intValue()) {
                            userPoiAccess.setPermission(userPoiAccesses[i].intValue());
                            userPoiAccess.setModDate(new Timestamp(System.currentTimeMillis()));

                            saveUserPoiAccess(userPoiAccess);
                        }
                    }
                }
            }
        }

    }

    /**
     * Apply user zoi accesses to user
     *
     * @param selectedUserId
     * @param userZoiAccesses
     * @param userZoiAccessesIds
     * @param zoiIds
     */
    private void applyZoiAccessesToUser(Long selectedUserId,
                                        Long[] userZoiAccesses,
                                        Long[] userZoiAccessesIds,
                                        Long[] zoiIds) {

        for (int i = 0; i < userZoiAccesses.length; i++) {
            UserZoiAccess userZoiAccess;

            if (userZoiAccessesIds[i] == 0 && userZoiAccesses[i].intValue() != 0) {
                GeoFence zoi = settingsService.getGeoFenceById(zoiIds[i]);

                // Add new User zoi Access
                userZoiAccess = new UserZoiAccess();

                userZoiAccess.setZoi(zoi);
                userZoiAccess.setUserId(selectedUserId);
                userZoiAccess.setPermission(userZoiAccesses[i].intValue());
                userZoiAccess.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                userZoiAccess.setRegDate(new Timestamp(System.currentTimeMillis()));

                saveUserZoiAccess(userZoiAccess);
            } else if (userZoiAccessesIds[i] != 0) {
                // Update for User zoi Access
                userZoiAccess = settingsService.getUserZoiAccessById(userZoiAccessesIds[i]);

                if (userZoiAccess.getPermission() != userZoiAccesses[i].intValue()) {
                    userZoiAccess.setPermission(userZoiAccesses[i].intValue());
                    userZoiAccess.setModDate(new Timestamp(System.currentTimeMillis()));

                    saveUserZoiAccess(userZoiAccess);
                }
            }
        }
    }

    /**
     * Apply user zoi accesses to checked users
     *
     * @param selectedUserId
     * @param checkedUsersIds
     * @param userZoiAccesses
     * @param zoiIds
     */
    private void applyZoiAccessesToSelectedUsers(Long selectedUserId,
                                                 Long[] checkedUsersIds,
                                                 Long[] userZoiAccesses,
                                                 Long[] zoiIds) {

        if (selectedUserId != null && checkedUsersIds != null) {

            for (Long checkedUserId : checkedUsersIds) {
                if (selectedUserId.equals(checkedUserId)) {
                    continue;
                }

                for (int i = 0; i < userZoiAccesses.length; i++) {
                    UserZoiAccess userZoiAccess = settingsService.getUserZoiAccessByUserIdAndZoiId(checkedUserId, zoiIds[i]);

                    if (userZoiAccess == null && userZoiAccesses[i].intValue() != 0) {
                        GeoFence zoi = settingsService.getGeoFenceById(zoiIds[i]);

                        // Add new User zoi Access
                        userZoiAccess = new UserZoiAccess();

                        userZoiAccess.setZoi(zoi);
                        userZoiAccess.setUserId(checkedUserId);
                        userZoiAccess.setPermission(userZoiAccesses[i].intValue());
                        userZoiAccess.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        userZoiAccess.setRegDate(new Timestamp(System.currentTimeMillis()));

                        saveUserZoiAccess(userZoiAccess);
                    } else if (userZoiAccess != null) {
                        // Core Update for User zoi Access

                        if (userZoiAccess.getPermission() != userZoiAccesses[i].intValue()) {
                            userZoiAccess.setPermission(userZoiAccesses[i].intValue());
                            userZoiAccess.setModDate(new Timestamp(System.currentTimeMillis()));

                            saveUserZoiAccess(userZoiAccess);
                        }
                    }
                }

            }
        }

    }

    private void saveUserPoiAccess(UserPoiAccess userPoiAccess) {
        settingsService.saveUserPoiAccess(userPoiAccess);
        coreMain.coreUpdater.updateUserPoiAccessById(userPoiAccess.getId());
    }

    private void saveUserZoiAccess(UserZoiAccess userZoiAccess) {
        settingsService.saveUserZoiAccess(userZoiAccess);
        coreMain.coreUpdater.updateUserZoiAccessById(userZoiAccess.getId());
    }
}
