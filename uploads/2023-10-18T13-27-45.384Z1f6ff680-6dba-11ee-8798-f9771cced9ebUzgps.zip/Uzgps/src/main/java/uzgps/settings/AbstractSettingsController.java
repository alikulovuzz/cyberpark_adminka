package uzgps.settings;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import uz.netex.routing.core.CoreTripRoutingControl;
import uzgps.main.MainController;
import uzgps.persistence.UserAccessList;

import javax.servlet.http.HttpSession;

/**
 * Created by Gayratjon on 9/8/2015.
 */
public abstract class AbstractSettingsController {

    @Autowired
    MainController mainController;

    @Autowired
    ObjectMapper jsonMapper;

    /**
     * Get current user's access list
     *
     * @param session
     * @return UserAccessList
     */
    @ModelAttribute("userAccessList")
    private UserAccessList getUserAccessList(HttpSession session) {
        // Get user access list in session
        UserAccessList userAccessList = mainController.getUserAccessList(session);

        return userAccessList;
    }

    /**
     * Get current user's access list
     *
     * @param session
     * @return getUserAccessList
     */
    @ModelAttribute("userAccess")
    private UserAccessList getUserAccess(HttpSession session) {
        return getUserAccessList(session);
    }

    /**
     * Check whether system has an access for routing module
     *
     * @return
     */
    @ModelAttribute("hasRoutingAccess")
    private Boolean getRoutingAccess() {
        return CoreTripRoutingControl.hasAccess();
    }
}
