package uzgps.settings;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.main.MainController;
import uzgps.persistence.User;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

@Controller
public class SettingsExternalServices extends AbstractSettingsController {

    private final static String URL_SETTINGS_EXTERNAL_SERVICES = "/settings/external-services.htm";
    private final static String VIEW_SETTINGS_EXTERNAL_SERVICES = "settings/settings-external-services";

    private final static String URL_SETTINGS_TELEGRAM_BOT_MANAGE = "/settings/tg-bot-manage.htm";
    private final static String VIEW_SETTINGS_TELEGRAM_BOT_MANAGE = "settings/settings-tg-bot-manage";

    private final static Long ONE_DAY_IN_MILLISECONDS = 86400000L;

    @Autowired
    CoreMain coreMain;

    @Autowired
    private SettingsService settingsService;

    @RequestMapping(value = URL_SETTINGS_EXTERNAL_SERVICES)
    public ModelAndView processSettings(HttpSession session,
                                        @RequestParam(value = "cmd", required = false) String cmd
    ) {

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_EXTERNAL_SERVICES);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        List<User> users = settingsService.getUserByContractIdAndApiTokenNotNull(MainController.getUserContractId(session));
        modelAndView.addObject("users", users);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        modelAndView.addObject("selectedLeftMenu", "external-services");
        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_TELEGRAM_BOT_MANAGE)
    public ModelAndView processSettingsTGBotManage(HttpSession session,
                                                   @RequestParam(value = "cmd", required = false) String cmd,
                                                   @RequestParam(value = "user-id", required = false) Long id,
                                                   @RequestParam(value = "exp-date", required = false) String expDate,
                                                   @RequestParam(value = "date",required = false,defaultValue = "") String date
    ) {

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_TELEGRAM_BOT_MANAGE);

        if (cmd != null && id != null) {
            User user = settingsService.getUserByUserId(id);
            if (cmd.equals("save")) {

                if (!expDate.equals("")) {
                    if (expDate.equals("7")
                                    || expDate.equals("30")
                                    || expDate.equals("60")
                                    || expDate.equals("90")
                    ) {

                        long milliseconds = (Long.parseLong(expDate) * ONE_DAY_IN_MILLISECONDS)
                                + System.currentTimeMillis();

                        user.setTokenExpDate(new Timestamp(milliseconds));
                    }
                    else if (expDate.equals("none")){
                        user.setTokenExpDate(null);
                    }
                    else if (expDate.equals("custom") && !date.equals("")){
                        try {
                            long milliseconds = new SimpleDateFormat("yyyy-MM-dd").parse(date).getTime();
                            user.setTokenExpDate(new Timestamp(milliseconds));
                        }catch (Exception e){
                            return new ModelAndView("redirect:" + URL_SETTINGS_TELEGRAM_BOT_MANAGE);
                        }
                    }else {
                        return new ModelAndView("redirect:" + URL_SETTINGS_TELEGRAM_BOT_MANAGE);
                    }

                    String newToken = UUID.randomUUID().toString();
                    user.setApiToken(newToken);
                    settingsService.saveUser(user);
                }

            } else if (cmd.equals("remove")) {
                settingsService.disableTgUsersByApiToken(user.getApiToken());
                user.setTokenExpDate(null);
                user.setApiToken(null);
                settingsService.saveUser(user);
            }

            return new ModelAndView("redirect:" + URL_SETTINGS_EXTERNAL_SERVICES);
        }

        Date defaultDate = new Date(System.currentTimeMillis() + ONE_DAY_IN_MILLISECONDS);
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        modelAndView.addObject("defaultDate", dateFormat.format(defaultDate));

        List<User> users = settingsService.getUserByContractIdAndApiTokenEqNull(MainController.getUserContractId(session));
        modelAndView.addObject("users", users);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        modelAndView.addObject("selectedLeftMenu", "external-services");
        return modelAndView;
    }

}
