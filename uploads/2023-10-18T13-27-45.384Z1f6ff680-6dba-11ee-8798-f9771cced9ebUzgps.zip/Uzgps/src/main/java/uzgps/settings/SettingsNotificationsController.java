package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreSensorNotification;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.SensorNotification;
import uz.netex.uzgps.core.models.sensor.SensorDataType;
import uz.netex.uzgps.core.models.sensor.SensorType;
import uzgps.common.Converters;
import uzgps.common.FileStorageService;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.persistence.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.*;

import static uzgps.common.CommonUtils.getPages;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsNotificationsController extends AbstractSettingsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_NOTIFICATION = "/settings/notifications.htm";
    private final static String VIEW_SETTINGS_NOTIFICATION = "settings/settings-notifications";

//    private final static String URL_APPLY_MOBJECT_NOTIFICATION_SETTINGS = "/settings/apply-mobject-notifications.htm";
//    private final static String URL_APPLY_MOBJECT_POI_NOTIFICATION_SETTINGS = "/settings/apply-mobject-poi-notifications.htm";
//    private final static String URL_APPLY_MOBJECT_ZONE_NOTIFICATION_SETTINGS = "/settings/apply-mobject-zone-notifications.htm";
//    private final static String URL_APPLY_POI_MOBJECT_NOTIFICATION_SETTINGS = "/settings/apply-poi-mobject-notifications.htm";
//    private final static String URL_APPLY_ZONE_MOBJECT_NOTIFICATION_SETTINGS = "/settings/apply-zone-mobject-notifications.htm";


    private final static int CORE_UPDATE_TYPE_POI = 1;
    private final static int CORE_UPDATE_TYPE_ZONE = 2;

    @Autowired
    private SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @Autowired
    FileStorageService storageService;

    @RequestMapping(value = URL_SETTINGS_NOTIFICATION)
    public ModelAndView processSettingsNotification(HttpSession session,
                                                    @RequestParam(value = "cmd", required = false) String cmd,
                                                    @RequestParam(value = "type", required = true) String type,
                                                    @RequestParam(value = "n-object-id", required = false) Long nObjectId,
                                                    @RequestParam(value = "id-list", required = false) Long[] idList,
                                                    @RequestParam(value = "poi-id", required = false) Long nPoiId,
                                                    @RequestParam(value = "zone-id", required = false) Long nZoneId,
                                                    @RequestParam(value = "panic-button", defaultValue = "false") Boolean panicButton,
                                                    @RequestParam(value = "min-speed", required = false) Integer minSpeed,
                                                    @RequestParam(value = "max-speed", required = false) Integer maxSpeed,
                                                    @RequestParam(value = "send-sms", defaultValue = "false") Boolean sendSms,
                                                    @RequestParam(value = "send-mail", defaultValue = "false") Boolean sendMail,
                                                    @RequestParam(value = "phone-mobile", required = false) String phoneMobile,
                                                    @RequestParam(value = "email-first", required = false) String emailFirst,
                                                    @RequestParam(value = "email-second", required = false) String emailSecond,
                                                    @RequestParam(value = "email-third", required = false) String emailThird,
                                                    @RequestParam(value = "pop-up-window", defaultValue = "false") Boolean popUpWindow,
                                                    @RequestParam(value = "n-pop-up-window", defaultValue = "false") Boolean nPopUpWindow,
                                                    @RequestParam(value = "register-database", defaultValue = "false") Boolean registerDatabase,
                                                    @RequestParam(value = "register-database-violation", defaultValue = "false") Boolean registerDatabaseViolation,
                                                    @RequestParam(value = "PoI[]", required = false) Long[] rPoiList,
                                                    @RequestParam(value = "MobjectPoIId[]", required = false) Long[] rMobjectPoIIdList,
                                                    @RequestParam(value = "poi-in[]", required = false) Long[] rPoiInList,
                                                    @RequestParam(value = "poi-out[]", required = false) Long[] rPoiOutList,
                                                    @RequestParam(value = "Zone[]", required = false) Long[] rZoneList,
                                                    @RequestParam(value = "MobjectZoneId[]", required = false) Long[] rMobjectZoneIdList,
                                                    @RequestParam(value = "zone-in[]", required = false) Long[] rZoneInList,
                                                    @RequestParam(value = "zone-out[]", required = false) Long[] rZoneOutList,
                                                    @RequestParam(value = "MObjectID[]", required = false) Long[] rMObjectIDList,
                                                    @RequestParam(value = "mobject-in[]", required = false) Long[] rMObjectInList,
                                                    @RequestParam(value = "mobject-out[]", required = false) Long[] rMObjectOutList,
                                                    @RequestParam(value = "filterText", required = false, defaultValue = "") String filterText,
                                                    @RequestParam(value = "page-number", required = false, defaultValue = "0") String pageNumberStr,

                                                    @RequestParam(value = "u-sos", required = false, defaultValue = "false") Boolean uSos,
                                                    @RequestParam(value = "u-engine", required = false, defaultValue = "false") Boolean uEngine,
                                                    @RequestParam(value = "u-external-power", required = false, defaultValue = "false") Boolean uExternalPower,
                                                    @RequestParam(value = "u-speed-min", required = false, defaultValue = "false") Boolean uSpeedMin,
                                                    @RequestParam(value = "u-speed-max", required = false, defaultValue = "false") Boolean uSpeedMax,
                                                    @RequestParam(value = "u-online", required = false, defaultValue = "false") Boolean uOnline,
                                                    @RequestParam(value = "u-staff", required = false, defaultValue = "false") Boolean uStaff,
                                                    @RequestParam(value = "u-settings", required = false, defaultValue = "false") Boolean uSettings,
                                                    @RequestParam(value = "u-poi", required = false, defaultValue = "false") Boolean uPoi,
                                                    @RequestParam(value = "u-zoi", required = false, defaultValue = "false") Boolean uZoi,
                                                    @RequestParam(value = "u-audiocall", required = false, defaultValue = "false") Boolean uAudioCall,
                                                    @RequestParam(value = "u-dooropen", required = false, defaultValue = "false") Boolean uDoorOpen,

                                                    @RequestParam(value = "u-sos-sound", required = false) Integer uSosSound,
                                                    @RequestParam(value = "u-engine-sound", required = false) Integer uEngineSound,
                                                    @RequestParam(value = "u-external-power-sound", required = false) Integer uExternalPowerSound,
                                                    @RequestParam(value = "u-speed-min-sound", required = false) Integer uSpeedMinSound,
                                                    @RequestParam(value = "u-speed-max-sound", required = false) Integer uSpeedMaxSound,
                                                    @RequestParam(value = "u-online-sound", required = false) Integer uOnlineSound,
                                                    @RequestParam(value = "u-staff-sound", required = false) Integer uStaffSound,
                                                    @RequestParam(value = "u-settings-sound", required = false) Integer uSettingsSound,
                                                    @RequestParam(value = "u-poi-sound", required = false) Integer uPoiSound,
                                                    @RequestParam(value = "u-zoi-sound", required = false) Integer uZoiSound,
                                                    @RequestParam(value = "u-audio-call-sound", required = false) Integer uAudioCallSound,
                                                    @RequestParam(value = "u-door-open-sound", required = false) Integer uDoorOpenSound,

                                                    @RequestParam(value = "u-sos-color", required = false) String uSosColor,
                                                    @RequestParam(value = "u-engine-color", required = false) String uEngineColor,
                                                    @RequestParam(value = "u-external-power-color", required = false) String uExternalPowerColor,
                                                    @RequestParam(value = "u-speed-min-color", required = false) String uSpeedMinColor,
                                                    @RequestParam(value = "u-speed-max-color", required = false) String uSpeedMaxColor,
                                                    @RequestParam(value = "u-online-color", required = false) String uOnlineColor,
                                                    @RequestParam(value = "u-staff-color", required = false) String uStaffColor,
                                                    @RequestParam(value = "u-settings-color", required = false) String uSettingsColor,
                                                    @RequestParam(value = "u-poi-color", required = false) String uPoiColor,
                                                    @RequestParam(value = "u-zoi-color", required = false) String uZoiColor,
                                                    @RequestParam(value = "u-audio-call-color", required = false) String uAudioCallColor,
                                                    @RequestParam(value = "u-door-open-color", required = false) String uDoorOpenColor,

                                                    @RequestParam(value = "s-sos", required = false, defaultValue = "false") Boolean sSos,
                                                    @RequestParam(value = "s-engine", required = false, defaultValue = "false") Boolean sEngine,
                                                    @RequestParam(value = "s-external-power", required = false, defaultValue = "false") Boolean sExternalPower,
                                                    @RequestParam(value = "s-speed-min", required = false, defaultValue = "false") Boolean sSpeedMin,
                                                    @RequestParam(value = "s-speed-max", required = false, defaultValue = "false") Boolean sSpeedMax,
                                                    @RequestParam(value = "s-online", required = false, defaultValue = "false") Boolean sOnline,
                                                    @RequestParam(value = "s-staff", required = false, defaultValue = "false") Boolean sStaff,
                                                    @RequestParam(value = "s-settings", required = false, defaultValue = "false") Boolean sSettings,
                                                    @RequestParam(value = "s-poi", required = false, defaultValue = "false") Boolean sPoi,
                                                    @RequestParam(value = "s-zoi", required = false, defaultValue = "false") Boolean sZoi,
                                                    @RequestParam(value = "s-audiocall", required = false, defaultValue = "false") Boolean sAudioCall,
                                                    @RequestParam(value = "s-dooropen", required = false, defaultValue = "false") Boolean sDoorOpen,

                                                    @RequestParam(value = "n-sos", required = false, defaultValue = "false") Boolean nSos,
                                                    @RequestParam(value = "n-engine", required = false, defaultValue = "false") Boolean nEngine,
                                                    @RequestParam(value = "n-external-power", required = false, defaultValue = "false") Boolean nExternalPower,
                                                    @RequestParam(value = "n-speed-min", required = false, defaultValue = "false") Boolean nSpeedMin,
                                                    @RequestParam(value = "n-speed-max", required = false, defaultValue = "false") Boolean nSpeedMax,
                                                    @RequestParam(value = "n-online", required = false, defaultValue = "false") Boolean nOnline,
//                                                    @RequestParam(value = "n-staff", required = false, defaultValue = "false") Boolean nStaff,
//                                                    @RequestParam(value = "n-settings", required = false, defaultValue = "false") Boolean nSettings,
                                                    @RequestParam(value = "n-poi", required = false, defaultValue = "false") Boolean nPoi,
                                                    @RequestParam(value = "n-zoi", required = false, defaultValue = "false") Boolean nZoi,
                                                    @RequestParam(value = "n-audiocall", required = false, defaultValue = "false") Boolean nAudioCall,
                                                    @RequestParam(value = "n-dooropen", required = false, defaultValue = "false") Boolean nDoorOpen,

                                                    @RequestParam(value = "e-sos", required = false, defaultValue = "false") Boolean eSos,
                                                    @RequestParam(value = "e-engine", required = false, defaultValue = "false") Boolean eEngine,
                                                    @RequestParam(value = "e-external-power", required = false, defaultValue = "false") Boolean eExternalPower,
                                                    @RequestParam(value = "e-speed-min", required = false, defaultValue = "false") Boolean eSpeedMin,
                                                    @RequestParam(value = "e-speed-max", required = false, defaultValue = "false") Boolean eSpeedMax,
                                                    @RequestParam(value = "e-online", required = false, defaultValue = "false") Boolean eOnline,
                                                    @RequestParam(value = "e-staff", required = false, defaultValue = "false") Boolean eStaff,
                                                    @RequestParam(value = "e-settings", required = false, defaultValue = "false") Boolean eSettings,
                                                    @RequestParam(value = "e-poi", required = false, defaultValue = "false") Boolean ePoi,
                                                    @RequestParam(value = "e-zoi", required = false, defaultValue = "false") Boolean eZoi,
                                                    @RequestParam(value = "e-audiocall", required = false, defaultValue = "false") Boolean eAudioCall,
                                                    @RequestParam(value = "e-dooropen", required = false, defaultValue = "false") Boolean eDoorOpen,

                                                    @RequestParam(value = "m-sos", required = false, defaultValue = "false") Boolean mSos,
                                                    @RequestParam(value = "m-engine", required = false, defaultValue = "false") Boolean mEngine,
                                                    @RequestParam(value = "m-external-power", required = false, defaultValue = "false") Boolean mExternalPower,
                                                    @RequestParam(value = "m-speed-min", required = false, defaultValue = "false") Boolean mSpeedMin,
                                                    @RequestParam(value = "m-speed-max", required = false, defaultValue = "false") Boolean mSpeedMax,
                                                    @RequestParam(value = "m-online", required = false, defaultValue = "false") Boolean mOnline,
                                                    @RequestParam(value = "m-staff", required = false, defaultValue = "false") Boolean mStaff,
                                                    @RequestParam(value = "m-settings", required = false, defaultValue = "false") Boolean mSettings,
                                                    @RequestParam(value = "m-poi", required = false, defaultValue = "false") Boolean mPoi,
                                                    @RequestParam(value = "m-zoi", required = false, defaultValue = "false") Boolean mZoi,
                                                    @RequestParam(value = "m-audiocall", required = false, defaultValue = "false") Boolean mAudioCall,
                                                    @RequestParam(value = "m-dooropen", required = false, defaultValue = "false") Boolean mDoorOpen,

                                                    @RequestParam(value = "snIds", required = false) Long[] snIds,
                                                    @RequestParam(value = "snSensorNames", required = false) String[] snSensorNames,
                                                    @RequestParam(value = "snSensorDataTypes", required = false) String[] snSensorDataTypes,
                                                    @RequestParam(value = "snMaxValues", required = false) Double[] snMaxValues,
                                                    @RequestParam(value = "snMinValues", required = false) Double[] snMinValues,
                                                    @RequestParam(value = "snOnChanges", required = false) Boolean[] snOnChanges,
                                                    @RequestParam(value = "snNotificationColors", required = false) String[] snNotificationColors,
                                                    @RequestParam(value = "snNotificationSounds", required = false) Integer[] snNotificationSounds,
                                                    @RequestParam(value = "snAsEvents", required = false) Boolean[] snAsEvents,
                                                    @RequestParam(value = "snAsNotifications", required = false) Boolean[] snAsNotifications,
                                                    @RequestParam(value = "snAsViolations", required = false) Boolean[] snAsViolations,
                                                    @RequestParam(value = "snSendEmails", required = false) Boolean[] snSendEmails,
                                                    @RequestParam(value = "snSendSmss", required = false) Boolean[] snSendSmss
    )
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsStaffManage cmd={}, type={}, object-id={}, panic-button={}, min-speed={}, max-speed={}," +
                            " send-sms={}, send-mail={}, phone-mobile={}, mail={}, pop-up-window={}, register-database={}, register-database-violation={}",
                    cmd, type, nObjectId, panicButton, minSpeed, maxSpeed,
                    sendSms, sendMail, phoneMobile, emailFirst, popUpWindow, registerDatabase, registerDatabaseViolation);
        }

        ModelAndView modelAndView = null;

        int pageNumber = Converters.strToInt(pageNumberStr, 0);

        if (cmd != null) {
            if (cmd.equalsIgnoreCase("notifications")) {
                //check Speeds limit
                // Check Min speed limits
                if (minSpeed == null) {
                    minSpeed = UZGPS_CONST.NOTIFICATION_MIN_SPEED_MIN;
                } else if (minSpeed < UZGPS_CONST.NOTIFICATION_MIN_SPEED_MIN) {
                    minSpeed = UZGPS_CONST.NOTIFICATION_MIN_SPEED_MIN;
                } else if (minSpeed > UZGPS_CONST.NOTIFICATION_MIN_SPEED_MAX) {
                    minSpeed = UZGPS_CONST.NOTIFICATION_MIN_SPEED_MAX;
                }

                // Check Max speed limits
                if (maxSpeed == null) {
                    maxSpeed = UZGPS_CONST.NOTIFICATION_MAX_SPEED_MIN;
                } else if (maxSpeed < UZGPS_CONST.NOTIFICATION_MAX_SPEED_MIN) {
                    maxSpeed = UZGPS_CONST.NOTIFICATION_MAX_SPEED_MIN;
                } else if (maxSpeed > UZGPS_CONST.NOTIFICATION_MAX_SPEED_MAX) {
                    maxSpeed = UZGPS_CONST.NOTIFICATION_MAX_SPEED_MAX;
                }

                // Check values of Min and Max
                if (minSpeed > maxSpeed) {
                    minSpeed = maxSpeed - 1;
                } else if (minSpeed < UZGPS_CONST.NOTIFICATION_MIN_SPEED_MIN) {
                    minSpeed = UZGPS_CONST.NOTIFICATION_MIN_SPEED_MIN;
                    maxSpeed = minSpeed + 1;
                }

                // object notification settings
                MObjectNotifications mObjectNotifications = settingsService.getMObjectNotificationsByObjectId(nObjectId);
                mObjectNotifications.setPanicButton(panicButton);
                mObjectNotifications.setMinSpeed(minSpeed);
                mObjectNotifications.setMaxSpeed(maxSpeed);
                mObjectNotifications.setSendSms(sendSms);
                mObjectNotifications.setSendMail(sendMail);
                mObjectNotifications.setPhoneNumber(phoneMobile);
                mObjectNotifications.setMail(emailFirst);
                mObjectNotifications.setMailSecond(emailSecond);
                mObjectNotifications.setMailThird(emailThird);
                mObjectNotifications.setPopUpWindow(popUpWindow);
                mObjectNotifications.setnPopUpWindow(nPopUpWindow);
                mObjectNotifications.setRegisterDatabase(registerDatabase);
                mObjectNotifications.setRegisterDatabaseViolation(registerDatabaseViolation);

                mObjectNotifications.setuSos(uSos);
                mObjectNotifications.setuEngine(uEngine);
                mObjectNotifications.setuExternalPower(uExternalPower);
                mObjectNotifications.setuSpeedMin(uSpeedMin);
                mObjectNotifications.setuSpeedMax(uSpeedMax);
                mObjectNotifications.setuOnline(uOnline);
                mObjectNotifications.setuStaff(uStaff);
                mObjectNotifications.setuSettings(uSettings);
                mObjectNotifications.setuPoi(uPoi);
                mObjectNotifications.setuZoi(uZoi);
                mObjectNotifications.setuAudioCall(uAudioCall);
                mObjectNotifications.setuDoorOpen(uDoorOpen);

                mObjectNotifications.setuSosSound(uSosSound);
                mObjectNotifications.setuEngineSound(uEngineSound);
                mObjectNotifications.setuExternalPowerSound(uExternalPowerSound);
                mObjectNotifications.setuSpeedMinSound(uSpeedMinSound);
                mObjectNotifications.setuSpeedMaxSound(uSpeedMaxSound);
                mObjectNotifications.setuOnlineSound(uOnlineSound);
                mObjectNotifications.setuStaffSound(uStaffSound);
                mObjectNotifications.setuSettingsSound(uSettingsSound);
                mObjectNotifications.setuPoiSound(uPoiSound);
                mObjectNotifications.setuZoiSound(uZoiSound);
                mObjectNotifications.setuAudioCallSound(uAudioCallSound);
                mObjectNotifications.setuDoorOpenSound(uDoorOpenSound);

                mObjectNotifications.setuSosColor(uSosColor);
                mObjectNotifications.setuEngineColor(uEngineColor);
                mObjectNotifications.setuExternalPowerColor(uExternalPowerColor);
                mObjectNotifications.setuSpeedMinColor(uSpeedMinColor);
                mObjectNotifications.setuSpeedMaxColor(uSpeedMaxColor);
                mObjectNotifications.setuOnlineColor(uOnlineColor);
                mObjectNotifications.setuStaffColor(uStaffColor);
                mObjectNotifications.setuSettingsColor(uSettingsColor);
                mObjectNotifications.setuPoiColor(uPoiColor);
                mObjectNotifications.setuZoiColor(uZoiColor);
                mObjectNotifications.setuAudioCallColor(uAudioCallColor);
                mObjectNotifications.setuDoorOpenColor(uDoorOpenColor);

                mObjectNotifications.setsSos(sSos);
                mObjectNotifications.setsEngine(sEngine);
                mObjectNotifications.setsExternalPower(sExternalPower);
                mObjectNotifications.setsSpeedMin(sSpeedMin);
                mObjectNotifications.setsSpeedMax(sSpeedMax);
                mObjectNotifications.setsOnline(sOnline);
                mObjectNotifications.setsStaff(sStaff);
                mObjectNotifications.setsSettings(sSettings);
                mObjectNotifications.setsPoi(sPoi);
                mObjectNotifications.setsZoi(sZoi);
                mObjectNotifications.setsAudioCall(sAudioCall);
                mObjectNotifications.setsDoorOpen(sDoorOpen);

                mObjectNotifications.setnSos(nSos);
                mObjectNotifications.setnEngine(nEngine);
                mObjectNotifications.setnExternalPower(nExternalPower);
                mObjectNotifications.setnSpeedMin(nSpeedMin);
                mObjectNotifications.setnSpeedMax(nSpeedMax);
                mObjectNotifications.setnOnline(nOnline);

                mObjectNotifications.setnPoi(nPoi);
                mObjectNotifications.setnZoi(nZoi);
                mObjectNotifications.setnAudioCall(nAudioCall);
                mObjectNotifications.setnDoorOpen(nDoorOpen);

                mObjectNotifications.seteSos(eSos);
                mObjectNotifications.seteEngine(eEngine);
                mObjectNotifications.seteExternalPower(eExternalPower);
                mObjectNotifications.seteSpeedMin(eSpeedMin);
                mObjectNotifications.seteSpeedMax(eSpeedMax);
                mObjectNotifications.seteOnline(eOnline);
                mObjectNotifications.seteStaff(eStaff);
                mObjectNotifications.seteSettings(eSettings);
                mObjectNotifications.setePoi(ePoi);
                mObjectNotifications.seteZoi(eZoi);
                mObjectNotifications.seteAudioCall(eAudioCall);
                mObjectNotifications.seteDoorOpen(eDoorOpen);

                mObjectNotifications.setmSos(mSos);
                mObjectNotifications.setmEngine(mEngine);
                mObjectNotifications.setmExternalPower(mExternalPower);
                mObjectNotifications.setmSpeedMin(mSpeedMin);
                mObjectNotifications.setmSpeedMax(mSpeedMax);
                mObjectNotifications.setmOnline(mOnline);
                mObjectNotifications.setmStaff(mStaff);
                mObjectNotifications.setmSettings(mSettings);
                mObjectNotifications.setmPoi(mPoi);
                mObjectNotifications.setmZoi(mZoi);
                mObjectNotifications.setmAudioCall(mAudioCall);
                mObjectNotifications.setmDoorOpen(mDoorOpen);

                settingsService.savemMObjectNotifications(mObjectNotifications);

                // Update in core
                coreMain.coreUpdater.updateMobjectNotificationsById(mObjectNotifications.getId());

                // Save SensorNotifications
                try {
                    for (int i = 0; i < snSensorNames.length; i++) {
                        if (!"0".equals(snSensorNames[i]) && !"0".equals(snSensorDataTypes[i])) {
                            SensorNotification sn = new SensorNotification();
                            sn.setId(snIds[i]);
                            sn.setMobjectId(nObjectId);
                            sn.setSensorName(snSensorNames[i]);
                            sn.setSensorDataType(SensorDataType.valueOf(snSensorDataTypes[i]));
                            sn.setMaxValue(snMaxValues[i]);
                            sn.setMinValue(snMinValues[i]);
                            sn.setOnChange(snOnChanges[i]);
                            sn.setAsNotification(snAsNotifications[i]);
                            sn.setAsEvent(snAsEvents[i]);
                            sn.setAsViolation(snAsViolations[i]);
                            sn.setSendEmail(snSendEmails[i]);
                            sn.setSendSms(snSendSmss[i]);
                            sn.setNotificationSound(snNotificationSounds[i]);
                            sn.setNotificationColor(snNotificationColors[i]);

                            CoreSensorNotification.getInstance().saveOrUpdate(sn);
                        } else if (snIds[i] != null) {
                            CoreSensorNotification.getInstance().deleteById(snIds[i]);
                        }
                    }
                } catch (Exception e) {
                    logger.error("Failed sensorNotification.save: " + e.getMessage());
                }

                applyMobjectNotificationSettings(nObjectId, idList);

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_NOTIFICATION + "?type=object&n-object-id=" + nObjectId);
            }
            // Object  to Poi settings section
            else if (cmd.equalsIgnoreCase("object-poi")) {

                Map<Long, MobjectAccessObj> mobjectAccessPoiMap = makeMobjectAccessZoneMap(rPoiList, rMobjectPoIIdList);

                // Poi access to mobject - goes Inside Poi
                if (rPoiInList != null) {
                    for (Long poiId : rPoiInList) {
                        if (mobjectAccessPoiMap.containsKey(poiId)) {
                            mobjectAccessPoiMap.get(poiId).value += 1;
                        }
                    }
                }

                // Poi access to mobject - goes Out of Poi
                if (rPoiOutList != null) {
                    for (Long poiId : rPoiOutList) {
                        if (mobjectAccessPoiMap.containsKey(poiId)) {
                            mobjectAccessPoiMap.get(poiId).value += 2;
                        }
                    }
                }

                Map<Long, MObjectPoI> mobjectPoiMap = new HashMap<>();

                // Add Poi to DataBase
                for (Long poiId : rPoiList) {
                    if (mobjectAccessPoiMap.containsKey(poiId)) {
                        MobjectAccessObj mobjectAccessPoi = mobjectAccessPoiMap.get(poiId);

                        if (mobjectAccessPoi.newUpdate == 0 && mobjectAccessPoi.value > 0) {
                            POI poi = settingsService.getPOIById(poiId);

                            MObjectPoI mObjectPoI = new MObjectPoI();
                            mObjectPoI.setmObjectId(nObjectId);
                            mObjectPoI.setPoi(poi);
                            mObjectPoI.setControlType(mobjectAccessPoi.value);
                            mObjectPoI.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                            mObjectPoI.setRegDate(new Timestamp(System.currentTimeMillis()));

                            mobjectPoiMap.put(poiId, mObjectPoI);

                            saveMobjectPoi(mObjectPoI);
                        } else if (mobjectAccessPoi.newUpdate == 1) {
                            MObjectPoI mObjectPoI = settingsService.getMObjectPoIById(mobjectAccessPoi.mobjectOiId);
                            mobjectPoiMap.put(poiId, mObjectPoI);

                            if (mObjectPoI.getControlType() != mobjectAccessPoi.value) {
                                mObjectPoI.setControlType(mobjectAccessPoi.value);
                                mObjectPoI.setModDate(new Timestamp(System.currentTimeMillis()));

                                saveMobjectPoi(mObjectPoI);
                            }
                        }
                    }
                }

                applyMobjectPoiNotificationSettings(mobjectPoiMap, nObjectId, idList, rPoiList);

                // Update Poi Information in Core
                updateCorePoiZoi(session, CORE_UPDATE_TYPE_POI);

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_NOTIFICATION + "?type=object-poi&n-object-id=" + nObjectId + "&page-number=" + pageNumber);
            } else if (cmd.equalsIgnoreCase("object-zone")) {

                Map<Long, MobjectAccessObj> mobjectAccessZoneMap = makeMobjectAccessZoneMap(rZoneList, rMobjectZoneIdList);

                // Zoi access to mobject - goes Inside Poi
                if (rZoneInList != null) {
                    for (Long zoneId : rZoneInList) {
                        if (mobjectAccessZoneMap.containsKey(zoneId)) {
                            mobjectAccessZoneMap.get(zoneId).value += 1;
                        }
                    }
                }

                // Zoi access to mobject - goes Out of Poi
                if (rZoneOutList != null) {
                    for (Long zoneId : rZoneOutList) {
                        if (mobjectAccessZoneMap.containsKey(zoneId)) {
                            mobjectAccessZoneMap.get(zoneId).value += 2;
                        }
                    }
                }

                Map<Long, MObjectGeoFence> mobjectZoiMap = new HashMap<>();

                // Add Zoi to DataBase
                for (Long zoneId : rZoneList) {
                    if (mobjectAccessZoneMap.containsKey(zoneId)) {
                        MobjectAccessObj mobjectAccessZone = mobjectAccessZoneMap.get(zoneId);

                        if (mobjectAccessZone.newUpdate == 0 && mobjectAccessZone.value > 0) {
                            GeoFence geoFence = settingsService.getGeoFenceById(zoneId);

                            MObjectGeoFence mObjectGeoFence = new MObjectGeoFence();
                            mObjectGeoFence.setmObjectId(nObjectId);
                            mObjectGeoFence.setGeoFence(geoFence);
                            mObjectGeoFence.setControlType(mobjectAccessZone.value);
                            mObjectGeoFence.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                            mObjectGeoFence.setRegDate(new Timestamp(System.currentTimeMillis()));

                            mobjectZoiMap.put(zoneId, mObjectGeoFence);

                            saveMobjectGeoFence(mObjectGeoFence);
                        } else if (mobjectAccessZone.newUpdate == 1) {
                            MObjectGeoFence mObjectGeoFence = settingsService.getMObjectGeoFenceById(mobjectAccessZone.mobjectOiId);
                            mobjectZoiMap.put(zoneId, mObjectGeoFence);

                            if (mObjectGeoFence.getControlType() != mobjectAccessZone.value) {
                                mObjectGeoFence.setControlType(mobjectAccessZone.value);
                                mObjectGeoFence.setModDate(new Timestamp(System.currentTimeMillis()));

                                saveMobjectGeoFence(mObjectGeoFence);
                            }
                        }

                    }
                }

                applyMobjectZoneNotificationSettings(mobjectZoiMap, nObjectId, idList, rZoneList);

                // Update Poi Information in Core
                updateCorePoiZoi(session, CORE_UPDATE_TYPE_ZONE);

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_NOTIFICATION + "?type=object-zone&n-object-id=" + nObjectId + "&page-number=" + pageNumber);
            } else if (cmd.equalsIgnoreCase("poi")) {

                Map<Long, MobjectAccessObj> accessMObjetPoiMap = makeMobjectAccessZoneMap(rMObjectIDList, rMobjectPoIIdList);

                // Poi access to mobject - goes Inside Poi
                if (rMObjectInList != null) {
                    for (Long objectId : rMObjectInList) {
                        if (accessMObjetPoiMap.containsKey(objectId)) {
                            accessMObjetPoiMap.get(objectId).value += 1;
                        }
                    }
                }

                // Poi access to mobject - goes Out of Poi
                if (rMObjectOutList != null) {
                    for (Long objectId : rMObjectOutList) {
                        if (accessMObjetPoiMap.containsKey(objectId)) {
                            accessMObjetPoiMap.get(objectId).value += 2;
                        }
                    }
                }

                Map<Long, MObjectPoI> MObjectPoIMap = new HashMap<>();

                // Add Poi to DataBase
                for (Long MObjectID : rMObjectIDList) {
                    if (accessMObjetPoiMap.containsKey(MObjectID)) {
                        MobjectAccessObj mobjectAccessPoi = accessMObjetPoiMap.get(MObjectID);

                        if (mobjectAccessPoi.newUpdate == 0 && mobjectAccessPoi.value > 0) {
                            POI poi = settingsService.getPOIById(nPoiId);

                            MObjectPoI mObjectPoI = new MObjectPoI();
                            mObjectPoI.setmObjectId(MObjectID);
                            mObjectPoI.setPoi(poi);
                            mObjectPoI.setControlType(mobjectAccessPoi.value);
                            mObjectPoI.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                            mObjectPoI.setRegDate(new Timestamp(System.currentTimeMillis()));

                            MObjectPoIMap.put(MObjectID, mObjectPoI);

                            saveMobjectPoi(mObjectPoI);
                        } else if (mobjectAccessPoi.newUpdate == 1) {
                            MObjectPoI mObjectPoI = settingsService.getMObjectPoIById(mobjectAccessPoi.mobjectOiId);
                            MObjectPoIMap.put(MObjectID, mObjectPoI);

                            if (mObjectPoI.getControlType() != mobjectAccessPoi.value) {
                                mObjectPoI.setControlType(mobjectAccessPoi.value);
                                mObjectPoI.setModDate(new Timestamp(System.currentTimeMillis()));

                                saveMobjectPoi(mObjectPoI);
                            }
                        }
                    }
                }

                applyPoiMobjectNotificationSettings(MObjectPoIMap, nPoiId, idList, rMObjectIDList);

                // Update Poi Information in Core
                updateCorePoiZoi(session, CORE_UPDATE_TYPE_POI);

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_NOTIFICATION + "?type=poi&poi-id=" + nPoiId + "&page-number=" + pageNumber);
            } else if (cmd.equalsIgnoreCase("zone")) {

                Map<Long, MobjectAccessObj> accessMObjetZoneMap = makeMobjectAccessZoneMap(rMObjectIDList, rMobjectZoneIdList);

                // Zoi access to mobject - goes Inside Zoi
                if (rMObjectInList != null) {
                    for (Long objectId : rMObjectInList) {
                        if (accessMObjetZoneMap.containsKey(objectId)) {
                            accessMObjetZoneMap.get(objectId).value += 1;
                        }
                    }
                }

                // Zoi access to mobject - goes Out of Poi
                if (rMObjectOutList != null) {
                    for (Long objectId : rMObjectOutList) {
                        if (accessMObjetZoneMap.containsKey(objectId)) {
                            accessMObjetZoneMap.get(objectId).value += 2;
                        }
                    }
                }

                Map<Long, MObjectGeoFence> mObjectZoIMap = new HashMap<>();

                // Add Zoi to DataBase
                for (Long MObjectID : rMObjectIDList) {
                    if (accessMObjetZoneMap.containsKey(MObjectID)) {
                        MobjectAccessObj mobjectAccessZone = accessMObjetZoneMap.get(MObjectID);

                        if (mobjectAccessZone.newUpdate == 0 && mobjectAccessZone.value > 0) {
                            GeoFence geoFence = settingsService.getGeoFenceById(nZoneId);

                            MObjectGeoFence mObjectGeoFence = new MObjectGeoFence();
                            mObjectGeoFence.setmObjectId(MObjectID);
                            mObjectGeoFence.setGeoFence(geoFence);
                            mObjectGeoFence.setControlType(mobjectAccessZone.value);
                            mObjectGeoFence.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                            mObjectGeoFence.setRegDate(new Timestamp(System.currentTimeMillis()));

                            mObjectZoIMap.put(MObjectID, mObjectGeoFence);

                            saveMobjectGeoFence(mObjectGeoFence);
                        } else if (mobjectAccessZone.newUpdate == 1) {
                            MObjectGeoFence mObjectGeoFence = settingsService.getMObjectGeoFenceById(mobjectAccessZone.mobjectOiId);
                            mObjectZoIMap.put(MObjectID, mObjectGeoFence);

                            if (mObjectGeoFence.getControlType() != mobjectAccessZone.value) {
                                mObjectGeoFence.setControlType(mobjectAccessZone.value);
                                mObjectGeoFence.setModDate(new Timestamp(System.currentTimeMillis()));

                                saveMobjectGeoFence(mObjectGeoFence);
                            }
                        }
                    }
                }

                applyZoneMobjectNotificationSettings(mObjectZoIMap, nZoneId, idList, rMObjectIDList);

                // Update Poi Information in Core
                updateCorePoiZoi(session, CORE_UPDATE_TYPE_ZONE);

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_NOTIFICATION + "?type=zone&zone-id=" + nZoneId + "&page-number=" + pageNumber);
            }
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_NOTIFICATION);

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);

            MobjectBig mobjectBigSelected = null;

            // If object not selected, take first
            if (mobjectList != null && mobjectList.size() > 0) {
                if (nObjectId == null) {
                    if (mobjectList.get(0) != null) {
                        mobjectBigSelected = mobjectList.get(0);
                        nObjectId = mobjectBigSelected.getId();
                    }
                }

                // Select MobjectBig
                if (mobjectBigSelected == null) {
                    for (MobjectBig mobjectBig : mobjectList) {
                        if (mobjectBig != null &&
                                mobjectBig.getId() != null &&
                                mobjectBig.getId().equals(nObjectId)) {
                            mobjectBigSelected = mobjectBig;
                        }
                    }
                }
            }

            List<Integer> pagination;

            int pageCount;

            if (type.equalsIgnoreCase("object")) {
                MObjectNotifications mObjectNotifications = settingsService.getMObjectNotificationsByObjectId(nObjectId);

                modelAndView.addObject("mObjectNotifications", mObjectNotifications);
                modelAndView.addObject("nObjectId", nObjectId);
                modelAndView.addObject("cmd", "notifications");

                List<SensorNotification> snList = CoreSensorNotification.getInstance().getListByMobjectId(nObjectId);
                modelAndView.addObject("snList", snList);
                modelAndView.addObject("sensorTypes", SensorType.values());

            } else if (type.equalsIgnoreCase("object-poi") && nObjectId != null) {
//                Long notificationObjectPoIListCount = settingsService.getObjectPoICount(session, nObjectId);
//                List<NotificationConnector> notificationObjectPoIList = settingsService.getObjectPoI(session, nObjectId, pageNumber);
                List<NotificationConnector> notificationObjectPoIList = settingsService.getObjectPoI(session, nObjectId);

                modelAndView.addObject("nObjectId", nObjectId);
                modelAndView.addObject("cmd", "object-poi");
                modelAndView.addObject("notificationObjectPoIList", notificationObjectPoIList);
                modelAndView.addObject("mobjectList", mobjectList);

//                pageCount = (notificationObjectPoIListCount.intValue() + UZGPS_CONST.LIST_PER_PAGE - 1) / UZGPS_CONST.LIST_PER_PAGE;
//                pagination = getPages(pageNumber, pageCount);
//
//                modelAndView.addObject("pagination", pagination);
//                modelAndView.addObject("pageNumber", pageNumber);
//                modelAndView.addObject("pageCount", pageCount);
//                modelAndView.addObject("paginationUrl", URL_SETTINGS_NOTIFICATION + "?type=poi&zone-id=" + nZoneId + "&page-number=");
            } else if (type.equalsIgnoreCase("object-zone") && nObjectId != null) {
//                Long notificationObjectZoneListCount = settingsService.getObjectZoneCount(session, nObjectId);
//                List<NotificationConnector> notificationObjectZoneList = settingsService.getObjectZone(session, nObjectId, pageNumber);
                List<NotificationConnector> notificationObjectZoneList = settingsService.getObjectZone(session, nObjectId);

                modelAndView.addObject("notificationObjectZoneList", notificationObjectZoneList);
                modelAndView.addObject("nObjectId", nObjectId);
                modelAndView.addObject("cmd", "object-zone");
                modelAndView.addObject("mobjectList", mobjectList);
//                pageCount = (notificationObjectZoneListCount.intValue() + UZGPS_CONST.LIST_PER_PAGE - 1) / UZGPS_CONST.LIST_PER_PAGE;
//                pagination = getPages(pageNumber, pageCount);
//
//                modelAndView.addObject("pagination", pagination);
//                modelAndView.addObject("pageNumber", pageNumber);
//                modelAndView.addObject("pageCount", pageCount);
//                modelAndView.addObject("paginationUrl", URL_SETTINGS_NOTIFICATION + "?type=zone&zone-id=" + nZoneId + "&page-number=");

            } else if (type.equalsIgnoreCase("poi")) {
                Long poiListCount = settingsService.getPOIByContractIdAndStatusCount(MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE);
                List<POI> poiList = settingsService.getPOIByContractIdAndStatus(MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE, pageNumber);

                POI poiSelected = null;
                if (poiList != null && poiList.size() > 0) {
                    if (nPoiId == null) {
                        poiSelected = poiList.get(0);
                        if (poiSelected != null) {
                            nPoiId = poiSelected.getId();
                        }
                    }
                }

                // Select poiSelected
                if (poiList != null && poiSelected == null) {
                    for (POI poi : poiList) {
                        if (poi != null &&
                                poi.getId() != null &&
                                poi.getId().equals(nPoiId)) {
                            poiSelected = poi;
                        }
                    }

                    if (poiList.size() > 0 && poiSelected == null) {
                        poiSelected = poiList.get(0);
                        if (poiSelected != null) {
                            nPoiId = poiSelected.getId();
                        }
                    }
                }

                modelAndView.addObject("poiList", poiList);
                if (nPoiId != null) {
                    modelAndView.addObject("cmd", "poi");
                    modelAndView.addObject("nPoiId", nPoiId);
                    modelAndView.addObject("poiSelected", poiSelected);

                    List<NotificationConnector> notificationPoIObjectList = settingsService.getPoIObject(session, nPoiId, isShowSuspendedObjects);

                    modelAndView.addObject("notificationPoIObjectList", notificationPoIObjectList);
                }

                pageCount = (poiListCount.intValue() + UZGPS_CONST.LIST_PER_PAGE - 1) / UZGPS_CONST.LIST_PER_PAGE;
                pagination = getPages(pageNumber, pageCount);

                modelAndView.addObject("pagination", pagination);
                modelAndView.addObject("pageNumber", pageNumber);
                modelAndView.addObject("pageCount", pageCount);
                modelAndView.addObject("paginationUrl", URL_SETTINGS_NOTIFICATION + "?type=poi&poi-id=" + nPoiId + "&page-number=");

            } else if (type.equalsIgnoreCase("zone")) {
//                List<GeoFence> geoFenceList = settingsService.getGeoFenceByContractIdAndStatus(MainController.getUserContractId(session), UZGPS_CONST.STATUS_ACTIVE);

                Long geoFenceListCount = settingsService.getGeoFenceByContractIdAndFilterCount(MainController.getUserContractId(session), filterText);

                List<GeoFence> geoFenceList = settingsService.getGeoFenceByContractIdAndFilter(MainController.getUserContractId(session), filterText, pageNumber);

                GeoFence geoFenceSelected = null;
                if (geoFenceList != null && geoFenceList.size() > 0) {
                    if (nZoneId == null) {
                        geoFenceSelected = geoFenceList.get(0);
                        if (geoFenceSelected != null) {
                            nZoneId = geoFenceSelected.getId();
                        }
                    }
                }

                // Select geoFenceSelected
                if (geoFenceList != null && geoFenceSelected == null) {
                    for (GeoFence geoFence : geoFenceList) {
                        if (geoFence != null &&
                                geoFence.getId() != null &&
                                geoFence.getId().equals(nZoneId)) {
                            geoFenceSelected = geoFence;
                        }
                    }

                    if (geoFenceList.size() > 0 && geoFenceSelected == null) {
                        geoFenceSelected = geoFenceList.get(0);
                        if (geoFenceSelected != null) {
                            nZoneId = geoFenceSelected.getId();
                        }
                    }
                }

                modelAndView.addObject("geoFenceList", geoFenceList);
                if (nZoneId != null) {
                    modelAndView.addObject("cmd", "zone");
                    modelAndView.addObject("nZoneId", nZoneId);
                    modelAndView.addObject("geoFenceSelected", geoFenceSelected);


                    List<NotificationConnector> notificationZoneObjectList = settingsService.getZoneObject(session, nZoneId, isShowSuspendedObjects);
                    modelAndView.addObject("notificationZoneObjectList", notificationZoneObjectList);
                }

                pageCount = (geoFenceListCount.intValue() + UZGPS_CONST.LIST_PER_PAGE - 1) / UZGPS_CONST.LIST_PER_PAGE;
                pagination = getPages(pageNumber, pageCount);

                modelAndView.addObject("pagination", pagination);
                modelAndView.addObject("pageNumber", pageNumber);
                modelAndView.addObject("pageCount", pageCount);
                modelAndView.addObject("paginationUrl", URL_SETTINGS_NOTIFICATION + "?type=zone&zone-id=" + nZoneId + "&page-number=");
            }

            modelAndView.addObject("type", type);
            modelAndView.addObject("mobjectBigSelected", mobjectBigSelected);

            modelAndView.addObject("mobjectList", mobjectList);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

            modelAndView.addObject("selectedLeftMenu", "notifications");
        }

        return modelAndView;
    }


    private void applyMobjectNotificationSettings(Long objectId, Long[] objectIdList) {

        if (objectId != null && objectIdList != null) {
            MObjectNotifications objectNotifications = settingsService.getMObjectNotificationsByObjectId(objectId);

            if (objectNotifications != null) {
                for (Long mobjectId : objectIdList) {
                    if (objectId.equals(mobjectId)) {
                        continue;
                    }

                    MObjectNotifications mObjectNotifications = settingsService.getMObjectNotificationsByObjectId(mobjectId);

                    if (mObjectNotifications != null) {

                        mObjectNotifications.setPanicButton(objectNotifications.getPanicButton());
                        mObjectNotifications.setMinSpeed(objectNotifications.getMinSpeed());
                        mObjectNotifications.setMaxSpeed(objectNotifications.getMaxSpeed());
                        mObjectNotifications.setSendSms(objectNotifications.getSendSms());
                        mObjectNotifications.setSendMail(objectNotifications.getSendMail());
                        mObjectNotifications.setPhoneNumber(objectNotifications.getPhoneNumber());
                        mObjectNotifications.setMail(objectNotifications.getMail());
                        mObjectNotifications.setPopUpWindow(objectNotifications.getPopUpWindow());
                        mObjectNotifications.setnPopUpWindow(objectNotifications.getnPopUpWindow());
                        mObjectNotifications.setRegisterDatabase(objectNotifications.getRegisterDatabase());
                        mObjectNotifications.setRegisterDatabaseViolation(objectNotifications.getRegisterDatabaseViolation());

                        mObjectNotifications.setuSos(objectNotifications.getuSos());
                        mObjectNotifications.setuEngine(objectNotifications.getuEngine());
                        mObjectNotifications.setuExternalPower(objectNotifications.getuExternalPower());
                        mObjectNotifications.setuSpeedMin(objectNotifications.getuSpeedMin());
                        mObjectNotifications.setuSpeedMax(objectNotifications.getuSpeedMax());
                        mObjectNotifications.setuOnline(objectNotifications.getuOnline());
                        mObjectNotifications.setuStaff(objectNotifications.getuStaff());
                        mObjectNotifications.setuSettings(objectNotifications.getuSettings());
                        mObjectNotifications.setuPoi(objectNotifications.getuPoi());
                        mObjectNotifications.setuZoi(objectNotifications.getuZoi());
                        mObjectNotifications.setuAudioCall(objectNotifications.getuAudioCall());
                        mObjectNotifications.setuDoorOpen(objectNotifications.getuDoorOpen());

                        mObjectNotifications.setuSosSound(objectNotifications.getuSosSound());
                        mObjectNotifications.setuEngineSound(objectNotifications.getuEngineSound());
                        mObjectNotifications.setuExternalPowerSound(objectNotifications.getuExternalPowerSound());
                        mObjectNotifications.setuSpeedMinSound(objectNotifications.getuSpeedMinSound());
                        mObjectNotifications.setuSpeedMaxSound(objectNotifications.getuSpeedMaxSound());
                        mObjectNotifications.setuOnlineSound(objectNotifications.getuOnlineSound());
                        mObjectNotifications.setuStaffSound(objectNotifications.getuStaffSound());
                        mObjectNotifications.setuSettingsSound(objectNotifications.getuSettingsSound());
                        mObjectNotifications.setuPoiSound(objectNotifications.getuPoiSound());
                        mObjectNotifications.setuZoiSound(objectNotifications.getuZoiSound());
                        mObjectNotifications.setuAudioCallSound(objectNotifications.getuAudioCallSound());
                        mObjectNotifications.setuDoorOpenSound(objectNotifications.getuDoorOpenSound());

                        mObjectNotifications.setuSosColor(objectNotifications.getuSosColor());
                        mObjectNotifications.setuEngineColor(objectNotifications.getuEngineColor());
                        mObjectNotifications.setuExternalPowerColor(objectNotifications.getuExternalPowerColor());
                        mObjectNotifications.setuSpeedMinColor(objectNotifications.getuSpeedMinColor());
                        mObjectNotifications.setuSpeedMaxColor(objectNotifications.getuSpeedMaxColor());
                        mObjectNotifications.setuOnlineColor(objectNotifications.getuOnlineColor());
                        mObjectNotifications.setuStaffColor(objectNotifications.getuStaffColor());
                        mObjectNotifications.setuSettingsColor(objectNotifications.getuSettingsColor());
                        mObjectNotifications.setuPoiColor(objectNotifications.getuPoiColor());
                        mObjectNotifications.setuZoiColor(objectNotifications.getuZoiColor());
                        mObjectNotifications.setuAudioCallColor(objectNotifications.getuAudioCallColor());
                        mObjectNotifications.setuDoorOpenColor(objectNotifications.getuDoorOpenColor());

                        mObjectNotifications.setsSos(objectNotifications.getsSos());
                        mObjectNotifications.setsEngine(objectNotifications.getsEngine());
                        mObjectNotifications.setsExternalPower(objectNotifications.getsExternalPower());
                        mObjectNotifications.setsSpeedMin(objectNotifications.getsSpeedMin());
                        mObjectNotifications.setsSpeedMax(objectNotifications.getsSpeedMax());
                        mObjectNotifications.setsOnline(objectNotifications.getsOnline());
                        mObjectNotifications.setsStaff(objectNotifications.getsStaff());
                        mObjectNotifications.setsSettings(objectNotifications.getsSettings());
                        mObjectNotifications.setsPoi(objectNotifications.getsPoi());
                        mObjectNotifications.setsZoi(objectNotifications.getsZoi());
                        mObjectNotifications.setsAudioCall(objectNotifications.getsAudioCall());
                        mObjectNotifications.setsDoorOpen(objectNotifications.getsDoorOpen());

                        mObjectNotifications.setnSos(objectNotifications.getnSos());
                        mObjectNotifications.setnEngine(objectNotifications.getnEngine());
                        mObjectNotifications.setnExternalPower(objectNotifications.getnExternalPower());
                        mObjectNotifications.setnSpeedMin(objectNotifications.getnSpeedMin());
                        mObjectNotifications.setnSpeedMax(objectNotifications.getnSpeedMax());
                        mObjectNotifications.setnOnline(objectNotifications.getnOnline());
                        //mObjectNotifications.setnStaff(nStaff);
                        //mObjectNotifications.setnSettings(nSettings);
                        mObjectNotifications.setnPoi(objectNotifications.getnPoi());
                        mObjectNotifications.setnZoi(objectNotifications.getnZoi());
                        mObjectNotifications.setnAudioCall(objectNotifications.getnAudioCall());
                        mObjectNotifications.setnDoorOpen(objectNotifications.getnDoorOpen());

                        mObjectNotifications.seteSos(objectNotifications.geteSos());
                        mObjectNotifications.seteEngine(objectNotifications.geteEngine());
                        mObjectNotifications.seteExternalPower(objectNotifications.geteExternalPower());
                        mObjectNotifications.seteSpeedMin(objectNotifications.geteSpeedMin());
                        mObjectNotifications.seteSpeedMax(objectNotifications.geteSpeedMax());
                        mObjectNotifications.seteOnline(objectNotifications.geteOnline());
                        mObjectNotifications.seteStaff(objectNotifications.geteStaff());
                        mObjectNotifications.seteSettings(objectNotifications.geteSettings());
                        mObjectNotifications.setePoi(objectNotifications.getePoi());
                        mObjectNotifications.seteZoi(objectNotifications.geteZoi());
                        mObjectNotifications.seteAudioCall(objectNotifications.geteAudioCall());
                        mObjectNotifications.seteDoorOpen(objectNotifications.geteDoorOpen());

                        mObjectNotifications.setmSos(objectNotifications.getmSos());
                        mObjectNotifications.setmEngine(objectNotifications.getmEngine());
                        mObjectNotifications.setmExternalPower(objectNotifications.getmExternalPower());
                        mObjectNotifications.setmSpeedMin(objectNotifications.getmSpeedMin());
                        mObjectNotifications.setmSpeedMax(objectNotifications.getmSpeedMax());
                        mObjectNotifications.setmOnline(objectNotifications.getmOnline());
                        mObjectNotifications.setmStaff(objectNotifications.getmStaff());
                        mObjectNotifications.setmSettings(objectNotifications.getmSettings());
                        mObjectNotifications.setmPoi(objectNotifications.getmPoi());
                        mObjectNotifications.setmZoi(objectNotifications.getmZoi());
                        mObjectNotifications.setmAudioCall(objectNotifications.getmAudioCall());
                        mObjectNotifications.setmDoorOpen(objectNotifications.getmDoorOpen());

                        settingsService.savemMObjectNotifications(objectNotifications);

                        // SensorNotification: remove old
                        CoreSensorNotification coreSN = CoreSensorNotification.getInstance();
                        coreSN.deleteByMobjectId(mobjectId);

                        // SensorNotification: add new
                        List<SensorNotification> snList = coreSN.getListByMobjectId(objectId);
                        if (snList != null) {
                            for (SensorNotification sn : snList) {
                                SensorNotification newSn = new SensorNotification();
                                newSn.clone(sn);
                                newSn.setId(null);
                                newSn.setMobjectId(mobjectId);
                                coreSN.saveOrUpdate(newSn);
                            }
                        }

                        // Update in core
                        coreMain.coreUpdater.updateMobjectNotificationsById(mObjectNotifications.getId());
                    }
                }
            }
        }
    }

    private void applyMobjectPoiNotificationSettings(Map<Long, MObjectPoI> baseMobjectPoiMap, Long baseObjectId, Long[] objectIdList, Long[] poiIdList) {
        if (baseObjectId != null && objectIdList != null && poiIdList != null) {
            Map<Long, POI> poiMap = new HashMap<>();

            for (Long poiId : poiIdList) {
//                MObjectPoI objectPoI = settingsService.getMObjectPoIByPoIIdAndObjectId(poiId, baseObjectId);
                MObjectPoI baseObjectPoi = baseMobjectPoiMap.get(poiId);

//                if (baseObjectId != null) {
                for (Long mobjectId : objectIdList) {
                    if (baseObjectId.equals(mobjectId)) {
                        continue;
                    }
                    if (baseObjectPoi == null) {
                        baseObjectPoi = new MObjectPoI();
                        baseObjectPoi.setControlType(0);
                    }

                    MObjectPoI mObjectPoI = settingsService.getMObjectPoIByPoIIdAndObjectId(poiId, mobjectId);

                    if (mObjectPoI == null && baseObjectPoi.getControlType() != 0) {
                        POI poi;
                        POI savedPoi = poiMap.get(poiId);
                        if (savedPoi != null) {
                            poi = savedPoi;
                        } else {
                            poi = settingsService.getPOIById(poiId);
                            poiMap.put(poi.getId(), poi);
                        }

                        mObjectPoI = new MObjectPoI();
                        mObjectPoI.setmObjectId(mobjectId);
                        mObjectPoI.setPoi(poi);
                        mObjectPoI.setControlType(baseObjectPoi.getControlType());
                        mObjectPoI.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        mObjectPoI.setRegDate(new Timestamp(System.currentTimeMillis()));

                        settingsService.saveMObjectPoI(mObjectPoI);
                    } else if (mObjectPoI != null) {
                        if (!mObjectPoI.getControlType().equals(baseObjectPoi.getControlType())) {
                            mObjectPoI.setControlType(baseObjectPoi.getControlType());
                            mObjectPoI.setModDate(new Timestamp(System.currentTimeMillis()));

                            settingsService.saveMObjectPoI(mObjectPoI);
                        }
                    }
                }
//                }
            }

        }
    }

    private void applyMobjectZoneNotificationSettings(Map<Long, MObjectGeoFence> baseMobjectZoiMap, Long baseObjectId, Long[] objectIdList, Long[] zoneIdList) {
        if (baseObjectId != null && objectIdList != null && zoneIdList != null) {
            Map<Long, GeoFence> geofenceMap = new HashMap<>();

            for (Long zoiId : zoneIdList) {
//                MObjectGeoFence objectGeoFence = settingsService.getMObjectGeoFenceByGeoFenceIdAndObjectId(zoiId, baseObjectId);
                MObjectGeoFence baseObjectZoi = baseMobjectZoiMap.get(zoiId);

//                if (objectGeoFence != null) {
                for (Long mobjectId : objectIdList) {
                    if (baseObjectId.equals(mobjectId)) {
                        continue;
                    }
                    if (baseObjectZoi == null) {
                        baseObjectZoi = new MObjectGeoFence();
                        baseObjectZoi.setControlType(0);
                    }

                    MObjectGeoFence mObjectGeoFence = settingsService.getMObjectGeoFenceByGeoFenceIdAndObjectId(zoiId, mobjectId);

                    if (mObjectGeoFence == null && baseObjectZoi.getControlType() != 0) {
                        GeoFence geoFence;
                        GeoFence savedGeoFence = geofenceMap.get(zoiId);
                        if (savedGeoFence != null) {
                            geoFence = savedGeoFence;
                        } else {
                            geoFence = settingsService.getGeoFenceById(zoiId);
                            geofenceMap.put(geoFence.getId(), geoFence);
                        }

                        mObjectGeoFence = new MObjectGeoFence();
                        mObjectGeoFence.setmObjectId(mobjectId);
                        mObjectGeoFence.setGeoFence(geoFence);
                        mObjectGeoFence.setControlType(baseObjectZoi.getControlType());
                        mObjectGeoFence.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        mObjectGeoFence.setRegDate(new Timestamp(System.currentTimeMillis()));
                        settingsService.saveMObjectGeoFence(mObjectGeoFence);
                    } else if (mObjectGeoFence != null) {
                        if (!mObjectGeoFence.getControlType().equals(baseObjectZoi.getControlType())) {
                            mObjectGeoFence.setControlType(baseObjectZoi.getControlType());
                            mObjectGeoFence.setModDate(new Timestamp(System.currentTimeMillis()));
                            settingsService.saveMObjectGeoFence(mObjectGeoFence);
                        }
                    }
                }
//                }
            }

        }
    }

    private void applyPoiMobjectNotificationSettings(Map<Long, MObjectPoI> baseMobjectPoiMap, Long basePoiId, Long[] poiIdList, Long[] objectIdList) {

        if (basePoiId != null && poiIdList != null && objectIdList != null) {
            Map<Long, POI> poiMap = new HashMap<>();

            for (Long mobjectId : objectIdList) {
//                MObjectPoI baseObjectPoI = settingsService.getMObjectPoIByPoIIdAndObjectId(basePoiId, mobjectId);
                MObjectPoI baseObjectPoi = baseMobjectPoiMap.get(mobjectId);

//                if (baseObjectPoI != null) {
                for (Long poiId : poiIdList) {
                    if (basePoiId.equals(poiId)) {
                        continue;
                    }
                    if (baseObjectPoi == null) {
                        baseObjectPoi = new MObjectPoI();
                        baseObjectPoi.setControlType(0);
                    }

                    MObjectPoI mObjectPoI = settingsService.getMObjectPoIByPoIIdAndObjectId(poiId, mobjectId);

                    if (mObjectPoI == null && baseObjectPoi.getControlType() != 0) {
                        POI poi;
                        POI savedPoi = poiMap.get(poiId);
                        if (savedPoi != null) {
                            poi = savedPoi;
                        } else {
                            poi = settingsService.getPOIById(poiId);
                            poiMap.put(poi.getId(), poi);
                        }

                        mObjectPoI = new MObjectPoI();
                        mObjectPoI.setmObjectId(mobjectId);
                        mObjectPoI.setPoi(poi);
                        mObjectPoI.setControlType(baseObjectPoi.getControlType());
                        mObjectPoI.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        mObjectPoI.setRegDate(new Timestamp(System.currentTimeMillis()));

                        settingsService.saveMObjectPoI(mObjectPoI);
                    } else if (mObjectPoI != null) {
                        if (!mObjectPoI.getControlType().equals(baseObjectPoi.getControlType())) {
                            mObjectPoI.setControlType(baseObjectPoi.getControlType());
                            mObjectPoI.setModDate(new Timestamp(System.currentTimeMillis()));
                            settingsService.saveMObjectPoI(mObjectPoI);
                        }
                    }
//                    }

                }
            }

        }
    }

    private void applyZoneMobjectNotificationSettings(Map<Long, MObjectGeoFence> baseMobjectZoiMap, Long baseZoiId, Long[] zoneIdList, Long[] objectIdList) {

        if (baseZoiId != null && zoneIdList != null && objectIdList != null) {
            Map<Long, GeoFence> geofenceMap = new HashMap<>();

            for (Long mobjectId : objectIdList) {
//                MObjectGeoFence objectGeoFence = settingsService.getMObjectGeoFenceByGeoFenceIdAndObjectId(baseZoneId, mobjectId);
                MObjectGeoFence baseObjectZoi = baseMobjectZoiMap.get(mobjectId);

//                if (objectGeoFence != null) {
                for (Long zoiId : zoneIdList) {
                    if (baseZoiId.equals(zoiId)) {
                        continue;
                    }
                    if (baseObjectZoi == null) {
                        baseObjectZoi = new MObjectGeoFence();
                        baseObjectZoi.setControlType(0);
                    }
                    MObjectGeoFence mObjectGeoFence = settingsService.getMObjectGeoFenceByGeoFenceIdAndObjectId(zoiId, mobjectId);

                    if (mObjectGeoFence == null && baseObjectZoi.getControlType() != 0) {
                        GeoFence geoFence;
                        GeoFence savedGeoFence = geofenceMap.get(zoiId);
                        if (savedGeoFence != null) {
                            geoFence = savedGeoFence;
                        } else {
                            geoFence = settingsService.getGeoFenceById(zoiId);
                            geofenceMap.put(geoFence.getId(), geoFence);
                        }

                        mObjectGeoFence = new MObjectGeoFence();
                        mObjectGeoFence.setmObjectId(mobjectId);
                        mObjectGeoFence.setGeoFence(geoFence);
                        mObjectGeoFence.setControlType(baseObjectZoi.getControlType());
                        mObjectGeoFence.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                        mObjectGeoFence.setRegDate(new Timestamp(System.currentTimeMillis()));
                        settingsService.saveMObjectGeoFence(mObjectGeoFence);
                    } else if (mObjectGeoFence != null) {
                        if (!mObjectGeoFence.getControlType().equals(baseObjectZoi.getControlType())) {
                            mObjectGeoFence.setControlType(baseObjectZoi.getControlType());
                            mObjectGeoFence.setModDate(new Timestamp(System.currentTimeMillis()));
                            settingsService.saveMObjectGeoFence(mObjectGeoFence);
                        }
                    }
                }
//                }
            }

        }
    }

    private void updateCorePoiZoi(HttpSession session, int type) {
        switch (type) {
            case CORE_UPDATE_TYPE_POI ->
                    coreMain.coreUpdater.updatePoiByContract(MainController.getUserContractId(session));
            case CORE_UPDATE_TYPE_ZONE ->
                    coreMain.coreUpdater.updateGeofenceByContract(MainController.getUserContractId(session));
        }

    }

    public class MobjectAccessObj {
        public Long id;
        public Long mobjectId;
        public Long mobjectOiId;
        public Long oiId;
        public int newUpdate;
        public int value;

        public MobjectAccessObj() {
            this.id = null;
            this.mobjectId = null;
            this.mobjectOiId = null;
            this.oiId = null;
            this.newUpdate = -1;
            this.value = 0;
        }

    }

    /**
     * Makes list of corresponding Mobject and Zone.
     * if selected, puts 1 for update.
     * if not listed, puts 0 to remove selection.
     *
     * @param zoneList          selected zones
     * @param mobjectZoneIdList selected mobjectZone correspondence
     * @return map of correspondence.
     */
    private Map<Long, MobjectAccessObj> makeMobjectAccessZoneMap(Long[] zoneList, Long[] mobjectZoneIdList) {
        Map<Long, MobjectAccessObj> mobjectAccessZoneMap = new HashMap<>();

        // Make map with all poi elements
        for (int i = 0; i < zoneList.length; i++) {
            MobjectAccessObj mobjectAccessPoi = new MobjectAccessObj();
            mobjectAccessPoi.oiId = zoneList[i];
            if (mobjectZoneIdList != null && mobjectZoneIdList.length > 0) {
                mobjectAccessPoi.mobjectOiId = mobjectZoneIdList[i];
                if (mobjectZoneIdList[i] == null)
                    mobjectAccessPoi.newUpdate = 0;
                else
                    mobjectAccessPoi.newUpdate = 1;
            } else {
                mobjectAccessPoi.mobjectOiId = null;
                mobjectAccessPoi.newUpdate = 0;
            }
            mobjectAccessZoneMap.put(mobjectAccessPoi.oiId, mobjectAccessPoi);
        }
        return mobjectAccessZoneMap;
    }

    private void saveMobjectGeoFence(MObjectGeoFence mObjectGeoFence) {
        settingsService.saveMObjectGeoFence(mObjectGeoFence);

        // Update core for GeoFence by Mobject
        coreMain.coreUpdater.updateGeofenceById(mObjectGeoFence.getGeoFenceId());

        coreMain.coreUpdater.updateGeofenceAccessByMobject(mObjectGeoFence.getmObjectId());
    }

    private void saveMobjectPoi(MObjectPoI mObjectPoi) {
        settingsService.saveMObjectPoI(mObjectPoi);

        // Update core for GeoFence by Mobject
        coreMain.coreUpdater.updatePoiById(mObjectPoi.getPoiId());

        coreMain.coreUpdater.updatePoiAccessByMobject(mObjectPoi.getmObjectId());
    }

}
