package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.Geofence;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsGroupZoiController extends AbstractSettingsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_ZOI_GROUP = "/settings/zoi-group.htm";
    private final static String VIEW_SETTINGS_ZOI_GROUP = "settings/settings-zoi-group";

    private final static String URL_SETTINGS_ZOI_GROUP_MANAGE = "/settings/zoi-group-manage.htm";
    private final static String VIEW_SETTINGS_ZOI_GROUP_MANAGE = "settings/settings-zoi-group-manage";

    private final static String URL_SETTINGS_ZOI_GROUP_ITEM = "/settings/zoi-group-item.htm";
    private final static String VIEW_SETTINGS_ZOI_GROUP_ITEM = "settings/settings-zoi-group-item";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTINGS_ZOI_GROUP)
    public ModelAndView processAdminMain(HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_ZOI_GROUP);

        List<ZoiGroup> zoiGroups = settingsService.getZoiGroupByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("zoiGroups", zoiGroups);
        modelAndView.addObject("groupCountZoi", (zoiGroups != null) ? zoiGroups.size() : 0);
        modelAndView.addObject("groupZoiId", "0");

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        modelAndView.addObject("selectedLeftMenu", "zoiGroup");

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_ZOI_GROUP_MANAGE)
    public ModelAndView processSettingsZoiGroup(HttpSession session,
                                                @RequestParam(value = "cmd", required = false) String cmd,
                                                @RequestParam(value = "group-name", required = false) String groupName,
                                                @RequestParam(value = "id", required = false) Long groupId,
                                                @RequestParam(value = "r-id[]", required = false) Long[] rGroupIdList)
            throws ServletException, IOException {

        ModelAndView modelAndView = null;

        if (cmd != null) {

            if (cmd.equalsIgnoreCase("save")) {
                ZoiGroup zoiGroup = new ZoiGroup();
                zoiGroup.setContractId(MainController.getUserContractId(session));
                zoiGroup.setName(groupName);
                zoiGroup.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                zoiGroup.setRegDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveZoIGroup(zoiGroup);
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_ZOI_GROUP);
            } else if (cmd.equalsIgnoreCase("edit")) {
                modelAndView = new ModelAndView(VIEW_SETTINGS_ZOI_GROUP_MANAGE);
                ZoiGroup zoiGroup = settingsService.getZoiGroupById(groupId);
                modelAndView.addObject("group", zoiGroup);
                modelAndView.addObject("cmd", "update");
                modelAndView.addObject("id", groupId);
                modelAndView.addObject("groupZoiId", "0");

                boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
                List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
                modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

                Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

                Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

                Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

            } else if (cmd.equalsIgnoreCase("update")) {
                ZoiGroup zoiGroup = settingsService.getZoiGroupById(groupId);
                zoiGroup.setName(groupName);
                zoiGroup.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveZoIGroup(zoiGroup);

                // Update group name in core
                List<MObject> mObjectList = settingsService.getObjectByContractIdAndGroupId(MainController.getUserContractId(session), groupId);
                for (MObject mObject : mObjectList) {
                    if (mObject != null) {
                        // Update core Cloud : GpsUnitBig and Mobject must be updated
                        coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                    }
                }

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_ZOI_GROUP);
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rGroupId : rGroupIdList) {
                    ZoiGroup zoiGroup = settingsService.getZoiGroupById(rGroupId);
                    ZoiGroup zoiGroupZero = settingsService.getZoiGroupById(0L);

                    List<GeoFence> geoFenceList = settingsService.getZoiByContractIdAndGroupId(MainController.getUserContractId(session), rGroupId);
                    for (GeoFence geoFence : geoFenceList) {
                        if (geoFence != null) {
                            geoFence.setGroup(zoiGroupZero);
                            settingsService.saveGeoFence(geoFence);

                            // Update core Cloud : GpsUnitBig and Mobject must be updated
                            coreMain.coreUpdater.updateGeofenceById(geoFence.getId());
                        }
                    }

                    zoiGroup.setExpDate(new Timestamp(System.currentTimeMillis()));
                    zoiGroup.setStatus(UZGPS_CONST.STATUS_DELETE);
                    settingsService.saveZoIGroup(zoiGroup);
                }
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_ZOI_GROUP);
            }
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_ZOI_GROUP_MANAGE);
            modelAndView.addObject("cmd", "save");

            List<ZoiGroup> group = settingsService.getZoiGroupByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("zoiGroups", group);
            modelAndView.addObject("groupCountZoi", (group != null) ? group.size() : 0);
            modelAndView.addObject("groupZoiId", "0");

        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_ZOI_GROUP_ITEM)
    public ModelAndView processSettingsZoiGroupItem(HttpSession session,
                                                    @RequestParam(value = "cmd", required = false) String cmd,
                                                    @RequestParam(value = "object-id-list", required = false) String objectIdList,
                                                    @RequestParam(value = "group-id", required = false) Long groupId)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsGroup cmd={}, object-id-list={}, id={}, r-id[]",
                    cmd, objectIdList, groupId);
        }

        ModelAndView modelAndView;

        // cmd exists. if save - saves elements of ZoiGroup
        if (cmd != null) {
            List<GeoFence> geoFenceList = settingsService.getZoiByContractIdAndGroupId(MainController.getUserContractId(session), groupId);
            ZoiGroup zoiGroup = settingsService.getZoiGroupById(0L);

            // Put all geoFenceList into ZoiGroup 0 - empty group
            for (GeoFence geoFence : geoFenceList) {
                geoFence.setGroup(zoiGroup);
                geoFence.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveGeoFence(geoFence);

                // Update core Cloud : GeoFence must be updated
                coreMain.coreUpdater.updateGeofenceById(geoFence.getId());
            }

            if (!objectIdList.equalsIgnoreCase("")) {
                List<String> newGroupZoiIdList = new ArrayList<>(Arrays.asList(objectIdList.split(",")));
                ZoiGroup selectZoiGroup = settingsService.getZoiGroupById(groupId);

                // Set new ZoiGroup Id for each GeoFence
                for (String newGroupZoiId : newGroupZoiIdList) {
                    GeoFence geoFence = settingsService.getGeoFenceById(Long.parseLong(newGroupZoiId));
                    geoFence.setGroup(selectZoiGroup);
                    geoFence.setModDate(new Timestamp(System.currentTimeMillis()));
                    settingsService.saveGeoFence(geoFence);

                    // Update core Cloud : Mobject must be updated
                    coreMain.coreUpdater.updateGeofenceById(geoFence.getId());
                }
            }
            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_ZOI_GROUP_ITEM + "?group-id=" + groupId);
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_ZOI_GROUP_ITEM);
            List<MObject> mObject = settingsService.getObjectByContractIdAndGroupIdAndWithOutGroup(MainController.getUserContractId(session),
                    groupId);
            modelAndView.addObject("mObjects", mObject);
            modelAndView.addObject("cmd", "save");
            modelAndView.addObject("groupZoiId", groupId);

            List<Geofence> geofenceList = coreMain.getZoiListByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("geofenceList", geofenceList);
            modelAndView.addObject("geofencesCount", (geofenceList != null) ? geofenceList.size() : 0);

            List<ZoiGroup> groups = settingsService.getZoiGroupByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("zoiGroups", groups);
            modelAndView.addObject("groupCountZoi", (groups != null) ? groups.size() : 0);

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

            modelAndView.addObject("selectedLeftMenu", "zoiGroup");
        }

        return modelAndView;
    }


}
