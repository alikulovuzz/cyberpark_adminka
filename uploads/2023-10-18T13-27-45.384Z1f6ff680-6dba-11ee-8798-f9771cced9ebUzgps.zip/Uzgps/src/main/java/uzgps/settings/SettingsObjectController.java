package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.common.Converters;
import uzgps.common.FileStorageService;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.TrackingController;
import uzgps.persistence.*;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.util.List;


/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsObjectController extends AbstractSettingsController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_OBJECT = "/settings/object.htm";
    private final static String URL_SETTINGS_OBJECT_PART_1_SAVE = "/settings/object-part-1-save.htm";
    private final static String URL_SETTINGS_OBJECT_PART_2_SAVE = "/settings/object-part-2-save.htm";
    private final static String URL_SETTINGS_OBJECT_PART_3_SAVE = "/settings/object-part-3-save.htm";
    private final static String URL_SETTINGS_OBJECT_PART_4_SAVE = "/settings/object-part-4-save.htm";
    private final static String URL_SETTINGS_MOBILE_TRACKER_SAVE = "/settings/mobile-tracker-save.htm";
    private final static String VIEW_SETTINGS_OBJECT = "settings/settings-object";

    private final static String URL_SETTINGS_PIN_MASK_LIST = "/settings/ajax-pin-mask-list.htm";
    private final static String VIEW_SETTINGS_PIN_MASK_LIST = "settings/ajax-pin-mask-list";

    private final static int MOBJECT_SETTINGS_PART_1 = 1;
    private final static int MOBJECT_SETTINGS_PART_2 = 2;
    private final static int MOBJECT_SETTINGS_PART_3 = 3;
    private final static int MOBJECT_SETTINGS_PART_4 = 4;

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    FileStorageService storageService;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTINGS_OBJECT)
    public ModelAndView processSettingsObject(HttpSession session,
                                              @RequestParam(value = "object-id", required = false) Long objectId) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractEqualsMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_SETTINGS_OBJECT);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsObject: ");
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_OBJECT);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);

        if (mobjectList != null && mobjectList.size() > 0) {
            if (objectId == null) {
                if (mobjectList.get(0) != null) {
                    objectId = mobjectList.get(0).getId();
                }
            }
        }

        MObjectGPSUnit mObjectGPSUnit = settingsService.getObjectGPSUnitByObjectId(objectId);
        MObjectSettings mObjectSettings = settingsService.getObjectSettingsByObjectId(objectId);

        List<MObjectType> mObjectTypes = settingsService.getObjectTypesByContractId(MainController.getUserContractId(session));
        List<MObjectState> mObjectStates = settingsService.getObjectStates();
        List<MObjectAppointment> mObjectAppointments = settingsService.getObjectAppointmentsByContractId(MainController.getUserContractId(session));

        MobileTrackerSettings mobileTrackerSettings = settingsService.getMobileTrackerSettingsByObjectId(objectId);

        modelAndView.addObject("mObjectGPSUnit", mObjectGPSUnit);
        modelAndView.addObject("settings", mObjectSettings);
        modelAndView.addObject("mobileTrackerSettings", mobileTrackerSettings);
        modelAndView.addObject("cmd", "edit");
        modelAndView.addObject("objectId", objectId);
        modelAndView.addObject("mObjectTypes", mObjectTypes);
        modelAndView.addObject("mObjectStates", mObjectStates);
        modelAndView.addObject("mObjectAppointments", mObjectAppointments);

        modelAndView.addObject("mobjectList", mobjectList);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        addPinBaseToView(modelAndView);
        addPinMaskToView(modelAndView, "");

        modelAndView.addObject("selectedLeftMenu", "objects");

        return modelAndView;
    }

    /**
     * Adds base pins to view
     *
     * @param modelAndView
     */
    private void addPinBaseToView(ModelAndView modelAndView) {
        if (modelAndView != null) {
            List<MObjectPins> pinBaseList = settingsService.getPinBaseList();
            modelAndView.addObject("pinBaseList", pinBaseList);
        }
    }

    /**
     * Adds Mask-pins to view
     *
     * @param modelAndView
     */
    private void addPinMaskToView(ModelAndView modelAndView, String iconBase) {
        if (modelAndView != null) {
//            List<MObjectPins> mObjectPinsId = settingsService.getMObjectPinsId();
            List<MObjectPins> mObjectPinsId = settingsService.getPinMaskList(iconBase);
            modelAndView.addObject("mObjectPinsList", mObjectPinsId);
        }
    }

    @RequestMapping(value = URL_SETTINGS_PIN_MASK_LIST)
    public ModelAndView getPinMaskList(HttpSession session,
                                       @RequestParam(value = "id", required = false) String pinIdStr,
                                       @RequestParam(value = "text", required = false) String pinText) {

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_PIN_MASK_LIST);

        long pinId = Converters.strToLong(pinIdStr, 0L);

        if (pinId > 0) {
            // Here Pin by MASK list
            MObjectPins mObjectPin = settingsService.getMObjectPinById(pinId);

            if (mObjectPin != null)
                addPinMaskToView(modelAndView, mObjectPin.getIconBase());
        } else if (pinText != null && !pinText.isEmpty()) {

            // Create Pin by pinText
            settingsService.createMObjectPinByPinText(pinText);

            // Here pin by text
            List<MObjectPins> pinList = settingsService.getPinListByText(pinText);
            modelAndView.addObject("mObjectPinsList", pinList);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_OBJECT_PART_1_SAVE)
    public ModelAndView processSettingsObjectPart1Save(HttpSession session,
                                                       @RequestParam(value = "cmd", required = false) String cmd,
                                                       @RequestParam(value = "object-id", required = false) Long objectId,
                                                       @RequestParam(value = "id-list", required = false) Long[] idList,
                                                       @RequestParam(value = "object-name", required = false) String objectName,
                                                       @RequestParam(value = "object-type", required = false) String objectType,
                                                       @RequestParam(value = "object-plate-number", required = false) String objectPlateNumber,
                                                       @RequestParam(value = "object-capacity", required = false) String objectCapacity,
                                                       @RequestParam(value = "object-fuel", required = false) String objectFuel,
                                                       @RequestParam(value = "object-type-id", required = false, defaultValue = "1") String objectTypeIdStr,
                                                       @RequestParam(value = "object-state-id", required = false, defaultValue = "1") String objectStateIdStr,
                                                       @RequestParam(value = "object-appointment-id", required = false) String objectAppointmentIdStr,
                                                       @RequestParam(value = "object-additional-info", required = false) String objectAdditionalInfoStr) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractEqualsMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_SETTINGS_OBJECT);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsObject cmd={}, object-id={}, object-name={}, object-type={}, object-plate-number={}, object-capacity={}, object-fuel={}" +
                    cmd, objectId, objectName, objectType, objectPlateNumber, objectCapacity, objectFuel);
        }

        ModelAndView modelAndView;

        if (cmd != null) {
            long objectTypeId = Converters.strToLong(objectTypeIdStr, 1L);
            long objectStateId = Converters.strToLong(objectStateIdStr, 1L);
            Long objectAppointmentId = Converters.strToLong(objectAppointmentIdStr, null);

            MObject mObject = settingsService.getObjectByObjectId(objectId);

            if (mObject != null) {

                mObject.setmObjectName(objectName);
                mObject.setmObjectType(objectType);
                mObject.setmObjectPlateNumber(objectPlateNumber);
                mObject.setModDate(new Timestamp(System.currentTimeMillis()));
                mObject.setAdditionalInfo(objectAdditionalInfoStr);

                settingsService.saveMObject(mObject);

                // Change tracker name too
                MObjectGPSUnit mObjectGPSUnit = settingsService.getObjectGPSUnitByObjectId(mObject.getId());
                if (mObjectGPSUnit != null) {
                    GPSUnit gpsUnit = mObjectGPSUnit.getGpsUnit();
                    if (gpsUnit != null) {
                        gpsUnit.setName(mObject.getmObjectName());
                        settingsService.saveGPSUnit(gpsUnit);

                        coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    }
                }
            }

            MObjectType mObjectType = settingsService.getObjectTypeById(objectTypeId);
            MObjectState mObjectState = settingsService.getObjectStateById(objectStateId);

            MObjectSettings mObjectSettings = settingsService.getObjectSettingsByObjectId(objectId);
            mObjectSettings.setObjectCapacity(objectCapacity);
            mObjectSettings.setObjectFuel(objectFuel);

            mObjectSettings.setMObjectTypeId(objectTypeId);
            mObjectSettings.setmObjectType(mObjectType);

            mObjectSettings.setMObjectStateId(objectStateId);
            mObjectSettings.setmObjectState(mObjectState);

            if (objectAppointmentId != null) {
                MObjectAppointment mObjectAppointment = settingsService.getObjectAppointmentById(objectAppointmentId);

                mObjectSettings.setMObjectAppointmentId(objectAppointmentId);
                mObjectSettings.setmObjectAppointment(mObjectAppointment);

            }

            saveMObjectSettings(mObjectSettings, session, objectId);
            updateMobjectInCoreById(objectId);
            applySettingsToSelectedMobjects(session, null, objectId, idList, MOBJECT_SETTINGS_PART_1);

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_OBJECT + "?object-id=" + objectId + "#objects");
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_OBJECT);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_OBJECT_PART_2_SAVE)
    public ModelAndView processSettingsObjectPart2Save(HttpSession session,
                                                       @RequestParam(value = "cmd", required = false) String cmd,
                                                       @RequestParam(value = "file", required = false) MultipartFile file,
                                                       @RequestParam(value = "default-icon", required = false, defaultValue = "false") Boolean defaultIcon,
                                                       @RequestParam(value = "selected-pin", required = false) Long selectedPinIcon,
                                                       @RequestParam(value = "object-id", required = false) Long objectId,
                                                       @RequestParam(value = "id-list", required = false) Long[] idList
    ) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractEqualsMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_SETTINGS_OBJECT);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsObject cmd={}, object-id={}, default-icon={}",
                    cmd, objectId, defaultIcon);
        }

        ModelAndView modelAndView;

        if (cmd != null) {

            MObject mObject = settingsService.getObjectByObjectId(objectId);
            mObject.setDefaultIcon(defaultIcon);
            mObject.setPinId(selectedPinIcon);
            mObject.setModDate(new Timestamp(System.currentTimeMillis()));

            Long fileStorageId = null;

            if (file != null && file.getSize() > 0) {
                if (mObject.getPhoto() != null) {
                    // Remove the image of Profile if exists
                    FileStorage oldFileStorage = mObject.getPhoto();
                    mObject.setPhoto(null);
                    settingsService.saveMObject(mObject);
                    storageService.removeFileFromStorage(oldFileStorage);
                }

                FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                if (fileStorage != null)
                    fileStorageId = fileStorage.getId();
                mObject.setPhoto(fileStorage);
            } else if (file == null) {
                // Remove the image of Profile if exists
                FileStorage fileStorage = mObject.getPhoto();
                if (fileStorage != null) {
                    fileStorageId = fileStorage.getId();
                    mObject.setPhoto(null);
                    settingsService.saveMObject(mObject);
                    storageService.removeFileFromStorage(fileStorage);
                }
            }

            settingsService.saveMObject(mObject);

            try {
                // Update core object
                coreMain.coreUpdater.updateUzgpsFileById(fileStorageId);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }

            updateMobjectInCoreById(objectId);
            applySettingsToSelectedMobjects(session, file, objectId, idList, MOBJECT_SETTINGS_PART_2);

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_OBJECT + "?object-id=" + objectId + "#objects");
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_OBJECT);

        }


        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_OBJECT_PART_3_SAVE)
    public ModelAndView processSettingsObjectPart3Save(HttpSession session,
                                                       @RequestParam(value = "cmd", required = false) String cmd,
                                                       @RequestParam(value = "object-id", required = false) Long objectId,
                                                       @RequestParam(value = "id-list", required = false) Long[] idList,
                                                       @RequestParam(value = "default-track-color", required = false) String defaultTrackColor,
                                                       @RequestParam(value = "speed-color1", required = false) String speedColor1,
                                                       @RequestParam(value = "speed-value1", required = false) Long speedvalue1,
                                                       @RequestParam(value = "speed-color2", required = false) String speedColor2,
                                                       @RequestParam(value = "speed-value2", required = false) Long speedvalue2,
                                                       @RequestParam(value = "speed-color3", required = false) String speedColor3,
                                                       @RequestParam(value = "speed-value3", required = false) Long speedvalue3,
                                                       @RequestParam(value = "speed-color4", required = false) String speedColor4,
                                                       @RequestParam(value = "speed-value4", required = false) Long speedvalue4,
                                                       @RequestParam(value = "speed-color5", required = false) String speedColor5,
                                                       @RequestParam(value = "speed-value5", required = false) Long speedvalue5,
                                                       @RequestParam(value = "speed-color6", required = false) String speedColor6,
                                                       @RequestParam(value = "speed-value6", required = false) Long speedvalue6,
                                                       @RequestParam(value = "label-size", required = false) Long labelSize) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractEqualsMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_SETTINGS_OBJECT);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsObject cmd={}, object-id={}, default-track-color={}," +
                            "speed-color1={}, speed-value1={}, speed-color2={}, speed-value2={}, speed-color3={}, speed-value3={}, speed-color4={}, speed-value4={}," +
                            "speed-color5={}, speed-value6={},  speed-color6={}, speed-value6={}, label-size={}",
                    cmd, objectId, defaultTrackColor,
                    speedColor1, speedvalue1, speedColor2, speedvalue2, speedColor3, speedvalue3, speedColor4, speedvalue4, speedColor5, speedvalue5,
                    speedColor6, speedvalue6, labelSize);
        }

        ModelAndView modelAndView;

        if (cmd != null) {

            // check Speeds limit
            //check spedValue1
            if (speedvalue1 == null) {
                speedvalue1 = UZGPS_CONST.MOBJECT_SPEED1_MIN;
            } else if (speedvalue1 < UZGPS_CONST.MOBJECT_SPEED1_MIN) {
                speedvalue1 = UZGPS_CONST.MOBJECT_SPEED1_MIN;
            } else if (speedvalue1 > UZGPS_CONST.MOBJECT_SPEED1_MAX) {
                speedvalue1 = UZGPS_CONST.MOBJECT_SPEED1_MAX;
            }
            //check speedValue2
            if (speedvalue2 == null) {
                speedvalue2 = UZGPS_CONST.MOBJECT_SPEED2_MIN;
            } else if (speedvalue2 < UZGPS_CONST.MOBJECT_SPEED2_MIN) {
                speedvalue2 = UZGPS_CONST.MOBJECT_SPEED2_MIN;
            } else if (speedvalue2 > UZGPS_CONST.MOBJECT_SPEED2_MAX) {
                speedvalue2 = UZGPS_CONST.MOBJECT_SPEED2_MAX;
            } else if (speedvalue2.equals(speedvalue1)) {
                speedvalue2 = speedvalue1 + 1;
            }
            //check speedvalue3
            if (speedvalue3 == null) {
                speedvalue3 = UZGPS_CONST.MOBJECT_SPEED3_MIN;
            } else if (speedvalue3 < UZGPS_CONST.MOBJECT_SPEED3_MIN) {
                speedvalue3 = UZGPS_CONST.MOBJECT_SPEED3_MIN;
            } else if (speedvalue3 > UZGPS_CONST.MOBJECT_SPEED3_MAX) {
                speedvalue3 = UZGPS_CONST.MOBJECT_SPEED3_MAX;
            } else if (speedvalue3.equals(speedvalue2)) {
                speedvalue3 = speedvalue2 + 1;
                //check speedvalue4
                if (speedvalue4 == null) {
                    speedvalue4 = UZGPS_CONST.MOBJECT_SPEED4_MIN;
                } else if (speedvalue4 < UZGPS_CONST.MOBJECT_SPEED4_MIN) {
                    speedvalue4 = UZGPS_CONST.MOBJECT_SPEED4_MIN;
                } else if (speedvalue4 > UZGPS_CONST.MOBJECT_SPEED4_MAX) {
                    speedvalue4 = UZGPS_CONST.MOBJECT_SPEED4_MAX;
                } else if (speedvalue4.equals(speedvalue3)) {
                    speedvalue4 = speedvalue3 + 1;
                }
            }
            //check speedValue5 limit
            if (speedvalue5 == null) {
                speedvalue5 = UZGPS_CONST.MOBJECT_SPEED5_MIN;
            } else if (speedvalue5 < UZGPS_CONST.MOBJECT_SPEED5_MIN) {
                speedvalue5 = UZGPS_CONST.MOBJECT_SPEED5_MIN;
            } else if (speedvalue5 > UZGPS_CONST.MOBJECT_SPEED5_MAX) {
                speedvalue5 = UZGPS_CONST.MOBJECT_SPEED5_MAX;
            } else if (speedvalue5.equals(speedvalue4)) {
                speedvalue5 = speedvalue4 + 1;
            }

            MObjectSettings mObjectSettings = settingsService.getObjectSettingsByObjectId(objectId);

            mObjectSettings.setDefaultTrackColor(defaultTrackColor);
            mObjectSettings.setSpeedColor1(speedColor1);
            mObjectSettings.setSpeedColor2(speedColor2);
            mObjectSettings.setSpeedColor3(speedColor3);
            mObjectSettings.setSpeedColor4(speedColor4);
            mObjectSettings.setSpeedColor5(speedColor5);
            mObjectSettings.setSpeedColor6(speedColor6);
            mObjectSettings.setSpeedValue1(speedvalue1);
            mObjectSettings.setSpeedValue2(speedvalue2);
            mObjectSettings.setSpeedValue3(speedvalue3);
            mObjectSettings.setSpeedValue4(speedvalue4);
            mObjectSettings.setSpeedValue5(speedvalue5);
            mObjectSettings.setSpeedValue6(speedvalue6);
            mObjectSettings.setLabelSize(labelSize);

            saveMObjectSettings(mObjectSettings, session, objectId);
            updateMobjectInCoreById(objectId);
            applySettingsToSelectedMobjects(session, null, objectId, idList, MOBJECT_SETTINGS_PART_3);

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_OBJECT + "?object-id=" + objectId + "#objects");
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_OBJECT);

        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_OBJECT_PART_4_SAVE)
    public ModelAndView processSettingsObjectPart4Save(HttpSession session,
                                                       @RequestParam(value = "cmd", required = false) String cmd,
                                                       @RequestParam(value = "object-id", required = false) Long objectId,
                                                       @RequestParam(value = "id-list", required = false) Long[] idList,
                                                       @RequestParam(value = "max-speed", required = false) Long maxSpeed,
                                                       @RequestParam(value = "average-speed", required = false) Long averageSpeed,
                                                       @RequestParam(value = "online-time", required = false) Long onlineTime,
                                                       @RequestParam(value = "parking-time", required = false) Long parkingTime) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractEqualsMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_SETTINGS_OBJECT);
        }

        logger.debug("processSettingsObject cmd={}, object-id={}, max-speed={}," +
                        "average-speed={}, online-time={}, parking-time={}",
                cmd, objectId, maxSpeed, averageSpeed, onlineTime, parkingTime);

        ModelAndView modelAndView;

        if (cmd != null) {

            MObject mObject = settingsService.getObjectByObjectId(objectId);
            mObject.setModDate(new Timestamp(System.currentTimeMillis()));

            settingsService.saveMObject(mObject);

            //check maxspeed limit
            if (maxSpeed == null) {
                maxSpeed = UZGPS_CONST.MOBJECT_MIN_SPEED;
            } else if (maxSpeed < UZGPS_CONST.MOBJECT_MIN_SPEED) {
                maxSpeed = UZGPS_CONST.MOBJECT_MIN_SPEED;
            } else if (maxSpeed > UZGPS_CONST.MOBJECT_MAX_SPEED) {
                maxSpeed = UZGPS_CONST.MOBJECT_MAX_SPEED;
            }
            //check averagespeed limit
            if (averageSpeed == null) {
                averageSpeed = UZGPS_CONST.MOBJECT_MIN_SPEED;
            } else if (averageSpeed < UZGPS_CONST.MOBJECT_MIN_SPEED) {
                averageSpeed = UZGPS_CONST.MOBJECT_MIN_SPEED;
            } else if (averageSpeed > UZGPS_CONST.MOBJECT_MAX_SPEED) {
                averageSpeed = UZGPS_CONST.MOBJECT_MAX_SPEED;
            }

            //check onlineTime limit
            if (onlineTime == null) {
                onlineTime = UZGPS_CONST.MOBJECT_ONLINETIME;
            } else if (onlineTime < UZGPS_CONST.MOBJECT_ONLINETIME_MIN) {
                onlineTime = UZGPS_CONST.MOBJECT_ONLINETIME_MIN;
            } else if (onlineTime > UZGPS_CONST.MOBJECT_ONLINETIME_MAX) {
                onlineTime = UZGPS_CONST.MOBJECT_ONLINETIME_MAX;
            }

            //check parkingTime limit
            if (parkingTime == null) {
                parkingTime = UZGPS_CONST.MOBJECT_PARKINGTIME_MIN;
            } else if (parkingTime < UZGPS_CONST.MOBJECT_PARKINGTIME_MIN) {
                parkingTime = UZGPS_CONST.MOBJECT_PARKINGTIME_MIN;
            } else if (parkingTime > UZGPS_CONST.MOBJECT_PARKINGTIME_MAX) {
                parkingTime = UZGPS_CONST.MOBJECT_PARKINGTIME_MAX;
            }

            MObjectSettings mObjectSettings = settingsService.getObjectSettingsByObjectId(objectId);

            mObjectSettings.setMaxSpeed(maxSpeed);
            mObjectSettings.setAverageSpeed(averageSpeed);
            mObjectSettings.setOnlineTime(onlineTime);
            mObjectSettings.setParkingTime(parkingTime);

            saveMObjectSettings(mObjectSettings, session, objectId);
            updateMobjectInCoreById(objectId);
            applySettingsToSelectedMobjects(session, null, objectId, idList, MOBJECT_SETTINGS_PART_4);

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_OBJECT + "?object-id=" + objectId + "#objects");
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_OBJECT);

        }

        return modelAndView;
    }


    @RequestMapping(value = URL_SETTINGS_MOBILE_TRACKER_SAVE)
    public ModelAndView saveSettingsMobileTracker(HttpSession session,
                                                  @RequestParam(value = "object-id", required = false) Long objectId,
                                                  @RequestParam(value = "id-list", required = false) Long[] idList,
                                                  @RequestParam(value = "mobile-serial", required = false) String mobileSerial,
                                                  @RequestParam(value = "hide-icon", required = false, defaultValue = "0") Integer hideIcon,
                                                  @RequestParam(value = "settings-update-time", required = false, defaultValue = "900") Integer settingsUpdateTime,
                                                  @RequestParam(value = "server-ip", required = false, defaultValue = "default") String serverIp,
                                                  @RequestParam(value = "server-port", required = false, defaultValue = "default") String serverPort,
                                                  @RequestParam(value = "has-password", required = false, defaultValue = "false") Boolean hasPassword,
                                                  @RequestParam(value = "password", required = false) Integer password,
                                                  @RequestParam(value = "location-update-time", required = false) Integer locationUpdateTime,
                                                  @RequestParam(value = "location-update-distance", required = false) Integer locationUpdateDistance,
                                                  @RequestParam(value = "location-update-accuracy", required = false) Integer locationUpdateAccuracy,
                                                  @RequestParam(value = "location-update-angle", required = false) Integer locationUpdateAngle,
                                                  @RequestParam(value = "should-change-status", required = false, defaultValue = "false") Boolean shouldChangeStatus,
                                                  @RequestParam(value = "record-limit", required = false) Integer recordLimit,
                                                  @RequestParam(value = "location-send-time", required = false) Integer locationSendTime,
                                                  @RequestParam(value = "should-send-3g", required = false, defaultValue = "false") Boolean shouldSend3G,
                                                  @RequestParam(value = "should-send-wifi", required = false, defaultValue = "false") Boolean shouldSendWiFi,
                                                  @RequestParam(value = "track-length", required = false) Integer trackLength,
                                                  @RequestParam(value = "sos-number1", required = false) String sosNumber1,
                                                  @RequestParam(value = "sos-number2", required = false) String sosNumber2,
                                                  @RequestParam(value = "sos-number3", required = false) String sosNumber3,
                                                  @RequestParam(value = "sos-number4", required = false) String sosNumber4,
                                                  @RequestParam(value = "sos-number5", required = false) String sosNumber5,
                                                  @RequestParam(value = "sos-number6", required = false) String sosNumber6,
                                                  @RequestParam(value = "sos-number7", required = false) String sosNumber7,
                                                  @RequestParam(value = "map-type", required = false, defaultValue = "1") Integer mapType) {

        // Check user Access to mobject
        if (objectId != null &&
                !MainController.getUserContractEqualsMobjectContract(session, settingsService.getObjectContractIdByObjectId(objectId))) {
//            logger.warn("Attempt to change an entity that cannot be accessed, objectId: " + objectId);
            return new ModelAndView(VIEW_SETTINGS_OBJECT);
        }

        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_OBJECT + "?object-id=" + objectId + "#objects");

        if (logger.isDebugEnabled()) {
            logger.debug("Mobile tracker settings: object-id={}, mobile-serial={}, hide-icon={}, settings-update-time={}, server-ip={}, server-port={}, has-password={}, password={}, location-update-time={}, location-update-distance={}, location-update-accuracy={}, location-update-angle={}, should-change-status={}, " +
                            "record-limit={}, location-send-time={}, should-send-3g={}, should-send-wifi={}, track-length={}, " +
                            "sos-number1={}, sos-number2={}, sos-number3={}, sos-number4={}, sos-number5={}, sos-number6={}, sos-number7={}, map-type={}",
                    objectId, mobileSerial, hideIcon, settingsUpdateTime, serverIp, serverPort, hasPassword, password, locationUpdateTime, locationUpdateDistance, locationUpdateAccuracy, locationUpdateAngle, shouldChangeStatus,
                    recordLimit, locationSendTime, shouldSend3G, shouldSendWiFi, trackLength,
                    sosNumber1, sosNumber2, sosNumber3, sosNumber4, sosNumber5, sosNumber6, sosNumber7, mapType);
        }

        // Change some params for constants
        if (serverIp.equalsIgnoreCase("default")) serverIp = UZGPS_CONST.MTRACKER_DEFAULT_SERVER_IP;
        if (serverPort.equalsIgnoreCase("default")) serverPort = "" + UZGPS_CONST.MTRACKER_DEFAULT_SERVER_PORT;

        if (objectId != null && mobileSerial != null && mobileSerial.length() > 0) {
            MobileTrackerSettings mobileTrackerSettings = settingsService.getMobileTrackerSettingsByObjectId(objectId);

            if (mobileTrackerSettings != null) {
                locationUpdateTime = getMobileTrackerSpinnerValue(locationUpdateTime, UZGPS_CONST.LOCATION_UPDATE_TIME_MIN, UZGPS_CONST.LOCATION_UPDATE_TIME_MAX);
                locationUpdateDistance = getMobileTrackerSpinnerValue(locationUpdateDistance, UZGPS_CONST.LOCATION_UPDATE_DICTANSE_MIN, UZGPS_CONST.LOCATION_UPDATE_DICTANSE_MAX);
                locationUpdateAngle = getMobileTrackerSpinnerValue(locationUpdateAngle, UZGPS_CONST.LOCATION_UPDATE_ANGLE_MIN, UZGPS_CONST.LOCATION_UPDATE_ANGLE_MAX);
                recordLimit = getMobileTrackerSpinnerValue(recordLimit, UZGPS_CONST.RECORD_LIMIT_MIN, UZGPS_CONST.RECORD_LIMIT_MAX);
                locationSendTime = getMobileTrackerSpinnerValue(locationSendTime, UZGPS_CONST.LOCATION_UPDATE_SEND_TIME_MIN, UZGPS_CONST.LOCATION_UPDATE_SEND_TIME_MAX);
                trackLength = getMobileTrackerSpinnerValue(trackLength, UZGPS_CONST.TRACK_LENGTH_MIN, UZGPS_CONST.TRACK_LENGTH_MAX);

                if (password != null) mobileTrackerSettings.setPassword(password);
                mobileTrackerSettings.setHasPassword(hasPassword);
                mobileTrackerSettings.setLocationUpdateTime(locationUpdateTime);
                mobileTrackerSettings.setLocationUpdateDistance(locationUpdateDistance);
                mobileTrackerSettings.setLocationUpdateAccuracy(locationUpdateAccuracy);
                mobileTrackerSettings.setLocationUpdateAngle(locationUpdateAngle);
                mobileTrackerSettings.setShouldChangeStatus(shouldChangeStatus);
                mobileTrackerSettings.setRecordLimit(recordLimit);
                mobileTrackerSettings.setLocationSendTime(locationSendTime);
                mobileTrackerSettings.setShouldSend3G(shouldSend3G);
                mobileTrackerSettings.setShouldSendWiFi(shouldSendWiFi);
                mobileTrackerSettings.setTrackLength(trackLength);
                mobileTrackerSettings.setSosNumber1(sosNumber1);
                mobileTrackerSettings.setSosNumber2(sosNumber2);
                mobileTrackerSettings.setSosNumber3(sosNumber3);
                mobileTrackerSettings.setSosNumber4(sosNumber4);
                mobileTrackerSettings.setSosNumber5(sosNumber5);
                mobileTrackerSettings.setSosNumber6(sosNumber6);
                mobileTrackerSettings.setSosNumber7(sosNumber7);
                mobileTrackerSettings.setMapType(mapType);
                mobileTrackerSettings.setHideIcon(hideIcon);
                mobileTrackerSettings.setServerIp(serverIp);
                mobileTrackerSettings.setServerPort(Converters.strToInt(serverPort, UZGPS_CONST.MTRACKER_DEFAULT_SERVER_PORT));
                mobileTrackerSettings.setSettingsUpdateTime(settingsUpdateTime);
                mobileTrackerSettings.setModDate(new Timestamp(System.currentTimeMillis()));

                settingsService.saveMobileTrackerSettings(mobileTrackerSettings);

                applyMobileTrackerSettings(objectId, idList);
            }
        }

        return modelAndView;
    }

    private Integer getMobileTrackerSpinnerValue(Integer spinnerValue, Integer valueMinConst, Integer valueMaxConst) {
        if (spinnerValue == null) {
            spinnerValue = valueMinConst;
        } else if (spinnerValue <= valueMinConst) {
            spinnerValue = valueMinConst;
        } else if (spinnerValue >= valueMaxConst) {
            spinnerValue = valueMaxConst;
        }

        return spinnerValue;
    }

    private void applySettingsToSelectedMobjects(HttpSession session, MultipartFile file, Long originalObjectId, Long[] objectIdList, Integer settingsPartNumber) {
        if (originalObjectId != null && objectIdList != null) {
            MObject originalObject = settingsService.getObjectByObjectId(originalObjectId);
            MObjectSettings originalObjectSettings = settingsService.getObjectSettingsByObjectId(originalObjectId);

            if (originalObject != null && originalObjectSettings != null) {
                for (Long mobjectId : objectIdList) {
                    if (originalObjectId.equals(mobjectId)) {
                        continue;
                    }

                    MObject mObject = settingsService.getObjectByObjectId(mobjectId);
                    MObjectSettings mObjectSettings = settingsService.getObjectSettingsByObjectId(mobjectId);

                    switch (settingsPartNumber) {
                        case MOBJECT_SETTINGS_PART_1:
                            MObjectType originalMObjectType = settingsService.getObjectTypeById(originalObjectSettings.getmObjectType().getId());
                            MObjectState originalMObjectState = settingsService.getObjectStateById(originalObjectSettings.getmObjectState().getId());
                            MObjectAppointment originalMObjectAppointment = settingsService.getObjectAppointmentById(originalObjectSettings.getmObjectAppointment().getId());

                            if (mObjectSettings != null) {
                                mObjectSettings.setObjectCapacity(originalObjectSettings.getObjectCapacity());
                                mObjectSettings.setObjectFuel(originalObjectSettings.getObjectFuel());
                                mObjectSettings.setmObjectType(originalMObjectType);
                                mObjectSettings.setmObjectState(originalMObjectState);
                                mObjectSettings.setmObjectAppointment(originalMObjectAppointment);

                                saveMObjectSettings(mObjectSettings, session, mobjectId);
                                updateMobjectInCoreById(mobjectId);
                            }

                            break;
                        case MOBJECT_SETTINGS_PART_2:
                            Long fileStorageId = null;

                            if (file != null && file.getSize() > 0) {
                                if (mObject.getPhoto() != null) {
                                    // Remove the image of Profile if exists
                                    FileStorage oldFileStorage = mObject.getPhoto();
                                    mObject.setPhoto(null);
                                    settingsService.saveMObject(mObject);
                                    storageService.removeFileFromStorage(oldFileStorage);
                                }

                                FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                                if (fileStorage != null)
                                    fileStorageId = fileStorage.getId();
                                mObject.setPhoto(fileStorage);
                            } else if (file == null) {
                                // Remove the image of Profile if exists
                                FileStorage fileStorage = mObject.getPhoto();
                                if (fileStorage != null) {
                                    fileStorageId = fileStorage.getId();
                                    mObject.setPhoto(null);
                                    settingsService.saveMObject(mObject);
                                    storageService.removeFileFromStorage(fileStorage);
                                }
                            }

                            mObject.setDefaultIcon(originalObject.getDefaultIcon());
                            mObject.setPinId(originalObject.getPinId());

                            mObject.setModDate(new Timestamp(System.currentTimeMillis()));
                            settingsService.saveMObject(mObject);
                            try {
                                // Update core object
                                coreMain.coreUpdater.updateUzgpsFileById(fileStorageId);
                            } catch (Exception e) {
                                logger.error(e.getMessage());
                            }
                            updateMobjectInCoreById(mobjectId);
                            break;
                        case MOBJECT_SETTINGS_PART_3:

                            if (mObjectSettings != null) {
                                mObjectSettings.setDefaultTrackColor(originalObjectSettings.getDefaultTrackColor());
                                mObjectSettings.setSpeedColor1(originalObjectSettings.getSpeedColor1());
                                mObjectSettings.setSpeedColor2(originalObjectSettings.getSpeedColor2());
                                mObjectSettings.setSpeedColor3(originalObjectSettings.getSpeedColor3());
                                mObjectSettings.setSpeedColor4(originalObjectSettings.getSpeedColor4());
                                mObjectSettings.setSpeedColor5(originalObjectSettings.getSpeedColor5());
                                mObjectSettings.setSpeedColor6(originalObjectSettings.getSpeedColor6());
                                mObjectSettings.setSpeedValue1(originalObjectSettings.getSpeedValue1());
                                mObjectSettings.setSpeedValue2(originalObjectSettings.getSpeedValue2());
                                mObjectSettings.setSpeedValue3(originalObjectSettings.getSpeedValue3());
                                mObjectSettings.setSpeedValue4(originalObjectSettings.getSpeedValue4());
                                mObjectSettings.setSpeedValue5(originalObjectSettings.getSpeedValue5());
                                mObjectSettings.setSpeedValue6(originalObjectSettings.getSpeedValue6());
                                mObjectSettings.setLabelSize(originalObjectSettings.getLabelSize());

                                saveMObjectSettings(mObjectSettings, session, mobjectId);
                                updateMobjectInCoreById(mobjectId);
                            }

                            break;
                        case MOBJECT_SETTINGS_PART_4:
                            if (mObjectSettings != null) {
                                mObjectSettings.setMaxSpeed(originalObjectSettings.getMaxSpeed());
                                mObjectSettings.setAverageSpeed(originalObjectSettings.getAverageSpeed());
                                mObjectSettings.setOnlineTime(originalObjectSettings.getOnlineTime());
                                mObjectSettings.setParkingTime(originalObjectSettings.getParkingTime());

                                saveMObjectSettings(mObjectSettings, session, mobjectId);
                                updateMobjectInCoreById(mobjectId);
                            }

                            break;
                    }


                }
            }
        }
    }

    /**
     * Set mobject settings to all selected mobjects
     *
     * @param objectId
     * @param objectIdList
     */
    private void applyMobileTrackerSettings(Long objectId, Long[] objectIdList) {

        if (objectId != null && objectIdList != null) {
            MobileTrackerSettings mTrackerSettings = settingsService.getMobileTrackerSettingsByObjectId(objectId);

            if (mTrackerSettings != null) {
                for (Long mobjectId : objectIdList) {
                    MobileTrackerSettings mobileTrackerSettings = settingsService.getMobileTrackerSettingsByObjectId(mobjectId);

                    if (mobileTrackerSettings != null) {
                        mobileTrackerSettings.setPassword(mTrackerSettings.getPassword());
                        mobileTrackerSettings.setHasPassword(mTrackerSettings.getHasPassword());
                        mobileTrackerSettings.setLocationUpdateTime(mTrackerSettings.getLocationUpdateTime());
                        mobileTrackerSettings.setLocationUpdateDistance(mTrackerSettings.getLocationUpdateDistance());
                        mobileTrackerSettings.setLocationUpdateAccuracy(mTrackerSettings.getLocationUpdateAccuracy());
                        mobileTrackerSettings.setLocationUpdateAngle(mTrackerSettings.getLocationUpdateAngle());
                        mobileTrackerSettings.setShouldChangeStatus(mTrackerSettings.getShouldChangeStatus());
                        mobileTrackerSettings.setRecordLimit(mTrackerSettings.getRecordLimit());
                        mobileTrackerSettings.setLocationSendTime(mTrackerSettings.getLocationSendTime());
                        mobileTrackerSettings.setShouldSend3G(mTrackerSettings.getShouldSend3G());
                        mobileTrackerSettings.setShouldSendWiFi(mTrackerSettings.getShouldSendWiFi());
                        mobileTrackerSettings.setTrackLength(mTrackerSettings.getTrackLength());
                        mobileTrackerSettings.setSosNumber1(mTrackerSettings.getSosNumber1());
                        mobileTrackerSettings.setSosNumber2(mTrackerSettings.getSosNumber2());
                        mobileTrackerSettings.setSosNumber3(mTrackerSettings.getSosNumber3());
                        mobileTrackerSettings.setSosNumber4(mTrackerSettings.getSosNumber4());
                        mobileTrackerSettings.setSosNumber5(mTrackerSettings.getSosNumber5());
                        mobileTrackerSettings.setSosNumber6(mTrackerSettings.getSosNumber6());
                        mobileTrackerSettings.setSosNumber7(mTrackerSettings.getSosNumber7());
                        mobileTrackerSettings.setMapType(mTrackerSettings.getMapType());
                        mobileTrackerSettings.setHideIcon(mTrackerSettings.getHideIcon());
                        mobileTrackerSettings.setSettingsUpdateTime(mTrackerSettings.getSettingsUpdateTime());
                        mobileTrackerSettings.setModDate(new Timestamp(System.currentTimeMillis()));

                        settingsService.saveMobileTrackerSettings(mobileTrackerSettings);
                    }
                }
            }
        }
    }

    /**
     * Save Mobject settings
     *
     * @param mObjectSettings
     * @param session
     * @param objectId
     */
    private void saveMObjectSettings(MObjectSettings mObjectSettings, HttpSession session, Long objectId) {
        mObjectSettings.setModDate(new Timestamp(System.currentTimeMillis()));
        settingsService.saveMObjectSettings(mObjectSettings);

        session.setAttribute(TrackingController.SESSION_OBJECT_SETTINGS + objectId, mObjectSettings);
    }


    /**
     * Update Mobject in core by Id
     *
     * @param objectId
     */
    private void updateMobjectInCoreById(Long objectId) {
        try {
            // Update core object
            coreMain.coreUpdater.updateMobjectBigById(objectId);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

    }

}
