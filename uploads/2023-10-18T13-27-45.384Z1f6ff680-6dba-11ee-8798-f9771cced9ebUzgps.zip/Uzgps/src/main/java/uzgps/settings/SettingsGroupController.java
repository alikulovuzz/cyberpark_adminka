package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.Group;
import uzgps.persistence.MObject;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsGroupController extends AbstractSettingsController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_GROUP = "/settings/group.htm";
    private final static String VIEW_SETTINGS_GROUP = "settings/settings-group";

    private final static String URL_SETTINGS_GROUP_MANAGE = "/settings/group-manage.htm";
    private final static String VIEW_SETTINGS_GROUP_MANAGE = "settings/settings-group-manage";

    private final static String URL_SETTINGS_GROUP_ITEM = "/settings/group-item.htm";
    private final static String VIEW_SETTINGS_GROUP_ITEM = "settings/settings-group-item";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTINGS_GROUP)
    public ModelAndView processAdminMain(HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_GROUP);

        List<Group> groups = settingsService.getGroupsByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groups", groups);
        modelAndView.addObject("groupCount", (groups != null) ? groups.size() : 0);

        modelAndView.addObject("groupId", "0");

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        modelAndView.addObject("selectedLeftMenu", "group");

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_GROUP_MANAGE)
    public ModelAndView processSettingsGroup(HttpSession session,
                                             @RequestParam(value = "cmd", required = false) String cmd,
                                             @RequestParam(value = "group-name", required = false) String groupName,
                                             @RequestParam(value = "id", required = false) Long groupId,
                                             @RequestParam(value = "r-id[]", required = false) Long[] rGroupIdList)
            throws ServletException, IOException {

        ModelAndView modelAndView = null;

        if (cmd != null) {

            if (cmd.equalsIgnoreCase("save")) {
                Group group = new Group();
                group.setContractId(MainController.getUserContractId(session));
                group.setGroupName(groupName);
                group.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                group.setRegDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveGroup(group);
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_GROUP);
            } else if (cmd.equalsIgnoreCase("edit")) {
                modelAndView = new ModelAndView(VIEW_SETTINGS_GROUP_MANAGE);
                Group group = settingsService.getGroupById(groupId);
                modelAndView.addObject("group", group);
                modelAndView.addObject("cmd", "update");
                modelAndView.addObject("id", groupId);
                modelAndView.addObject("groupId", "0");

                boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
                List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
                modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

                List<Group> groups = settingsService.getGroupsByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("groups", groups);
                modelAndView.addObject("groupCount", (groups != null) ? groups.size() : 0);

                Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

                Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

            } else if (cmd.equalsIgnoreCase("update")) {
                Group group = settingsService.getGroupById(groupId);
                group.setGroupName(groupName);
                group.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveGroup(group);

                // Update group name in core
                List<MObject> mObjectList = settingsService.getObjectByContractIdAndGroupId(MainController.getUserContractId(session), groupId);
                for (MObject mObject : mObjectList) {
                    if (mObject != null) {
                        // Update core Cloud : GpsUnitBig and Mobject must be updated
                        coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                    }
                }

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_GROUP);
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rGroupId : rGroupIdList) {
                    Group group = settingsService.getGroupById(rGroupId);
                    Group groupZero = settingsService.getGroupById(0L);

                    List<MObject> mObjectList = settingsService.getObjectByContractIdAndGroupId(MainController.getUserContractId(session), rGroupId);
                    for (MObject mObject : mObjectList) {
                        if (mObject != null) {
                            mObject.setGroup(groupZero);
                            settingsService.saveMObject(mObject);

                            // Update core Cloud : GpsUnitBig and Mobject must be updated
                            coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                        }
                    }

                    group.setExpDate(new Timestamp(System.currentTimeMillis()));
                    group.setStatus(UZGPS_CONST.STATUS_DELETE);
                    settingsService.saveGroup(group);
                }
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_GROUP);
            }
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_GROUP_MANAGE);
            modelAndView.addObject("cmd", "save");

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);
            List<Group> groups = settingsService.getGroupsByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groups", groups);
            modelAndView.addObject("groupCount", (groups != null) ? groups.size() : 0);
            modelAndView.addObject("groupId", "0");

        }


        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_GROUP_ITEM)
    public ModelAndView processSettingsGroupItem(HttpSession session,
                                                 @RequestParam(value = "cmd", required = false) String cmd,
                                                 @RequestParam(value = "object-id-list", required = false) String objectIdList,
                                                 @RequestParam(value = "group-id", required = false) Long groupId)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsGroup cmd={}, object-id-list={}, id={}, r-id[]",
                    cmd, objectIdList, groupId);
        }

        ModelAndView modelAndView;

        // cmd exists. if save - saves elements of group
        if (cmd != null) {
            List<MObject> mObjects = settingsService.getObjectByContractIdAndGroupId(MainController.getUserContractId(session), groupId);
            Group group = settingsService.getGroupById(0L);

            // Put all Mobjects into Group 0 - empty group
            for (MObject mObject : mObjects) {
                mObject.setGroup(group);
                mObject.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveMObject(mObject);

                // Update core Cloud : Mobject must be updated
                coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
            }

            if (!objectIdList.equalsIgnoreCase("")) {
                List<String> newGroupObjectIdList = new ArrayList<>(Arrays.asList(objectIdList.split(",")));
                Group selectGgroup = settingsService.getGroupById(groupId);

                // Set new Group Id for each Mobject
                for (String newGroupObjectId : newGroupObjectIdList) {
                    MObject mObject = settingsService.getObjectByObjectId(Long.parseLong(newGroupObjectId));
                    mObject.setGroup(selectGgroup);
                    mObject.setModDate(new Timestamp(System.currentTimeMillis()));
                    settingsService.saveMObject(mObject);

                    // Update core Cloud : Mobject must be updated
                    coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                }
            }
            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_GROUP_ITEM + "?group-id=" + groupId);
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_GROUP_ITEM);
            List<MObject> mObject = settingsService.getObjectByContractIdAndGroupIdAndWithOutGroup(MainController.getUserContractId(session),
                    groupId);
            modelAndView.addObject("mObjects", mObject);
            modelAndView.addObject("cmd", "save");
            modelAndView.addObject("groupId", groupId);

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            List<Group> groups = settingsService.getGroupsByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groups", groups);
            modelAndView.addObject("groupCount", (groups != null) ? groups.size() : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);
        }

        return modelAndView;
    }


}
