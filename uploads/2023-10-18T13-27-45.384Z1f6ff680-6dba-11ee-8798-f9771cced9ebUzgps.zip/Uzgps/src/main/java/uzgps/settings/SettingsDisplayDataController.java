package uzgps.settings;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uz.netex.uzgps.core.models.sensor.SensorDataType;
import uz.netex.uzgps.core.models.sensor.SensorType;
import uzgps.common.Converters;
import uzgps.main.MainController;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.SensorDisplay;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sarvar on 27.01.16.
 */
@Controller
public class SettingsDisplayDataController extends AbstractSettingsController {

    private final static String URL_SETTING_DISPLAY_DATA = "/settings/display-data.htm";
    private final static String VIEW_SETTING_DISPLAY_DATA = "settings/settings-display-data";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTING_DISPLAY_DATA)
    public ModelAndView processSettingsDisplayData(HttpSession session,
                                                   @RequestParam(value = "cmd", required = false) String cmd,
                                                   @RequestParam(value = "tracking-values-part1[]", required = false) Integer[] trackingValuesPart1,
                                                   @RequestParam(value = "tracking-values-part2[]", required = false) Integer[] trackingValuesPart2,
                                                   @RequestParam(value = "tracking-values-part3[]", required = false) Integer[] trackingValuesPart3,
                                                   @RequestParam(value = "tracking-values-part4[]", required = false) Integer[] trackingValuesPart4,
                                                   @RequestParam(value = "tracking-values-part5[]", required = false) Integer[] trackingValuesPart5,
                                                   @RequestParam(value = "message-values-part1[]", required = false) Integer[] messageValuesPart1,
                                                   @RequestParam(value = "message-values-part2[]", required = false) Integer[] messageValuesPart2,
                                                   @RequestParam(value = "message-values-part3[]", required = false) Integer[] messageValuesPart3,
                                                   @RequestParam(value = "message-values-part4[]", required = false) Integer[] messageValuesPart4,
                                                   @RequestParam(value = "message-values-part5[]", required = false) Integer[] messageValuesPart5,
                                                   @RequestParam(value = "monitoring-values-part1[]", required = false) Integer[] monitoringValuesPart1,
                                                   @RequestParam(value = "monitoring-values-part2[]", required = false) Integer[] monitoringValuesPart2,
                                                   @RequestParam(value = "monitoring-values-part3[]", required = false) Integer[] monitoringValuesPart3,
                                                   @RequestParam(value = "monitoring-values-part4[]", required = false) Integer[] monitoringValuesPart4,
                                                   @RequestParam(value = "track-popup-values-part1[]", required = false) Integer[] trackPopupValuesPart1,
                                                   @RequestParam(value = "track-popup-values-part2[]", required = false) Integer[] trackPopupValuesPart2,
                                                   @RequestParam(value = "track-popup-values-part3[]", required = false) Integer[] trackPopupValuesPart3,
                                                   @RequestParam(value = "track-popup-values-part4[]", required = false) Integer[] trackPopupValuesPart4,
                                                   @RequestParam(value = "parking-popup-values-part1[]", required = false) Integer[] parkingPopupValuesPart1,
                                                   @RequestParam(value = "sos-popup-values-part1[]", required = false) Integer[] sosPopupValuesPart1,
                                                   @RequestParam(value = "sos-popup-values-part2[]", required = false) Integer[] sosPopupValuesPart2,
                                                   @RequestParam(value = "sos-popup-values-part3[]", required = false) Integer[] sosPopupValuesPart3,
                                                   @RequestParam(value = "sos-popup-values-part4[]", required = false) Integer[] sosPopupValuesPart4,

                                                   @RequestParam(value = "sd-name[]", required = false) String[] sdNames,
                                                   @RequestParam(value = "sd-type[]", required = false) String[] sdTypes,
                                                   @RequestParam(value = "sd-message[]", required = false) Boolean[] sdMessage,
                                                   @RequestParam(value = "sd-tracking[]", required = false) Boolean[] sdTracking,
                                                   @RequestParam(value = "sd-monitoring[]", required = false) Boolean[] sdMonitoring) {

        if (cmd != null && cmd.equals("edit")) {

            ContractSettings contractSettings = mainController.getContractSettings(session);

            if (contractSettings != null) {
                // Save tracking display data values
                contractSettings.setTrackingValuesPart1(getTotalDisplayDataSettingsValue(trackingValuesPart1));
                contractSettings.setTrackingValuesPart2(getTotalDisplayDataSettingsValue(trackingValuesPart2));
                contractSettings.setTrackingValuesPart3(getTotalDisplayDataSettingsValue(trackingValuesPart3));
                contractSettings.setTrackingValuesPart4(getTotalDisplayDataSettingsValue(trackingValuesPart4));
                contractSettings.setTrackingValuesPart5(getTotalDisplayDataSettingsValue(trackingValuesPart5));

                // Save message display data values
                contractSettings.setMessageValuesPart1(getTotalDisplayDataSettingsValue(messageValuesPart1));
                contractSettings.setMessageValuesPart2(getTotalDisplayDataSettingsValue(messageValuesPart2));
                contractSettings.setMessageValuesPart3(getTotalDisplayDataSettingsValue(messageValuesPart3));
                contractSettings.setMessageValuesPart4(getTotalDisplayDataSettingsValue(messageValuesPart4));
                contractSettings.setMessageValuesPart5(getTotalDisplayDataSettingsValue(messageValuesPart5));

                // Save monitoring display data values
                contractSettings.setMonitoringValuesPart1(getTotalDisplayDataSettingsValue(monitoringValuesPart1));
                contractSettings.setMonitoringValuesPart2(getTotalDisplayDataSettingsValue(monitoringValuesPart2));
                contractSettings.setMonitoringValuesPart3(getTotalDisplayDataSettingsValue(monitoringValuesPart3));
                contractSettings.setMonitoringValuesPart4(getTotalDisplayDataSettingsValue(monitoringValuesPart4));

                // Save track popup display data values
                contractSettings.setTrackPopupValuesPart1(getTotalDisplayDataSettingsValue(trackPopupValuesPart1));
                contractSettings.setTrackPopupValuesPart2(getTotalDisplayDataSettingsValue(trackPopupValuesPart2));
                contractSettings.setTrackPopupValuesPart3(getTotalDisplayDataSettingsValue(trackPopupValuesPart3));
                contractSettings.setTrackPopupValuesPart4(getTotalDisplayDataSettingsValue(trackPopupValuesPart4));

                // Save parking popup display data values
                contractSettings.setParkingPopupValuesPart1(getTotalDisplayDataSettingsValue(parkingPopupValuesPart1));

                // Save sos popup display data values
                contractSettings.setSosPopupValuesPart1(getTotalDisplayDataSettingsValue(sosPopupValuesPart1));
                contractSettings.setSosPopupValuesPart2(getTotalDisplayDataSettingsValue(sosPopupValuesPart2));
                contractSettings.setSosPopupValuesPart3(getTotalDisplayDataSettingsValue(sosPopupValuesPart3));
                contractSettings.setSosPopupValuesPart4(getTotalDisplayDataSettingsValue(sosPopupValuesPart4));

                List<SensorDisplay> sdList = new ArrayList<>();
                for (int i = 0; i < sdNames.length; i++) {
                    if (!"0".equals(sdNames[i]) && !"0".equals(sdTypes[i])) {
                        SensorDisplay display = new SensorDisplay();
                        display.setName(sdNames[i]);
                        display.setType(SensorDataType.valueOf(sdTypes[i]));
                        display.setMessage(sdMessage[i]);
                        display.setTracking(sdTracking[i]);
                        display.setMonitoring(sdMonitoring[i]);
                        sdList.add(display);
                    }
                }
                contractSettings.setSensorDisplayList(sdList);

                settingsService.saveContractSettings(contractSettings);
                session.setAttribute(MainController.SESSION_CONTRACT_SETTINGS, contractSettings);
            }

            return new ModelAndView("redirect:" + URL_SETTING_DISPLAY_DATA);
        } else {
            ModelAndView modelAndView = new ModelAndView(VIEW_SETTING_DISPLAY_DATA);

            modelAndView.addObject("selectedLeftMenu", "display-data");

            ContractSettings contractSettings = mainController.getContractSettings(session);
            modelAndView.addObject("contractSettings", contractSettings);
            modelAndView.addObject("cmd", "edit");

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

            modelAndView.addObject("sensorTypes", SensorType.values());

            if (cmd != null && cmd.equals("default")) {
                if (contractSettings != null) {
                    // Set default tracking values
                    contractSettings.setTrackingValuesPart1(ContractSettings.TRACKING_VALUES_PART1_DEFAULT);
                    contractSettings.setTrackingValuesPart2(ContractSettings.TRACKING_VALUES_PART2_DEFAULT);
                    contractSettings.setTrackingValuesPart3(ContractSettings.TRACKING_VALUES_PART3_DEFAULT);
                    contractSettings.setTrackingValuesPart5(0);

                    // Set default message values
                    contractSettings.setMessageValuesPart1(ContractSettings.MESSAGE_VALUES_PART1_DEFAULT);
                    contractSettings.setMessageValuesPart2(ContractSettings.MESSAGE_VALUES_PART2_DEFAULT);
                    contractSettings.setMessageValuesPart3(ContractSettings.MESSAGE_VALUES_PART3_DEFAULT);
                    contractSettings.setMessageValuesPart5(0);

                    // Set default monitoring values
                    contractSettings.setMonitoringValuesPart1(ContractSettings.MONITORING_VALUES_PART1_DEFAULT);
                    contractSettings.setMonitoringValuesPart2(ContractSettings.MONITORING_VALUES_PART2_DEFAULT);
                    contractSettings.setMonitoringValuesPart3(ContractSettings.MONITORING_VALUES_PART3_DEFAULT);

                    // Set default track popup values
                    contractSettings.setTrackPopupValuesPart1(ContractSettings.TRACK_POPUP_VALUES_PART1_DEFAULT);
                    contractSettings.setTrackPopupValuesPart2(ContractSettings.TRACK_POPUP_VALUES_PART2_DEFAULT);
                    contractSettings.setTrackPopupValuesPart3(ContractSettings.TRACK_POPUP_VALUES_PART3_DEFAULT);

                    // Set default parking popup values
                    contractSettings.setParkingPopupValuesPart1(ContractSettings.PARKING_POPUP_VALUES_PART1_DEFAULT);

                    // Set default sos popup values
                    contractSettings.setSosPopupValuesPart1(ContractSettings.SOS_POPUP_VALUES_PART1_DEFAULT);
                    contractSettings.setSosPopupValuesPart2(ContractSettings.SOS_POPUP_VALUES_PART2_DEFAULT);
                    contractSettings.setSosPopupValuesPart3(ContractSettings.SOS_POPUP_VALUES_PART3_DEFAULT);

                    modelAndView.addObject("contractSettings", contractSettings);
                }
            }

            return modelAndView;
        }
    }

    /**
     * Get total value of display data settings
     *
     * @param settingsValues
     * @return int
     */
    private int getTotalDisplayDataSettingsValue(Integer[] settingsValues) {
        int totalValue = 0;

        if (settingsValues != null) {
            for (Integer value : settingsValues) {
                if (value != null) {
                    totalValue = Converters.setBitValue(totalValue, value, 1);
                }
            }
        }

        return totalValue;
    }
}
