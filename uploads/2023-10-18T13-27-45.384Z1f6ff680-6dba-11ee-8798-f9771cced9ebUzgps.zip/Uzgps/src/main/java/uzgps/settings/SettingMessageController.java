package uzgps.settings;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.main.MainController;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.Group;
import uzgps.persistence.Staff;
import uzgps.persistence.User;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * Created by G'ayrat on 18.11.15.
 */
@Controller
public class SettingMessageController extends AbstractSettingsController {

    private final static String URL_SETTING_MESSAGE = "/settings/message.htm";
    private final static String VIEW_SETTING_MESSAGE = "settings/settings-message";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTING_MESSAGE)
    public ModelAndView processSettingsMessage(HttpSession session,
                                               @RequestParam(value = "cmd", required = false) String cmd,
                                               @RequestParam(value = "track-date", required = false, defaultValue = "0") Integer trackDate,
                                               @RequestParam(value = "message-date", required = false, defaultValue = "0") Integer messageDate,
                                               @RequestParam(value = "track-time", required = false, defaultValue = "0") Integer trackTime,
                                               @RequestParam(value = "message-time", required = false, defaultValue = "0") Integer messageTime,
//                                               @RequestParam(value = "track-speed", required = false, defaultValue = "0") Integer trackSpeed,
                                               @RequestParam(value = "track-speed-track", required = false, defaultValue = "0") Integer trackSpeedTrack,
                                               @RequestParam(value = "track-speed-io", required = false, defaultValue = "0") Integer trackSpeedIo,
                                               @RequestParam(value = "message-speed", required = false, defaultValue = "0") Integer messageSpeed,
                                               @RequestParam(value = "message-speed-track", required = false, defaultValue = "0") Integer messageSpeedTrack,
                                               @RequestParam(value = "message-speed-io", required = false, defaultValue = "0") Integer messageSpeedIo,
                                               @RequestParam(value = "track-height", required = false, defaultValue = "0") Integer trackHeight,
                                               @RequestParam(value = "message-height", required = false, defaultValue = "0") Integer messageHeight,
                                               @RequestParam(value = "track-odometr", required = false, defaultValue = "0") Integer trackOdometr,
                                               @RequestParam(value = "message-odometr", required = false, defaultValue = "0") Integer messageOdomert,
                                               @RequestParam(value = "track-movementValue", required = false, defaultValue = "0") Integer trackMovementValue,
                                               @RequestParam(value = "message-movementValue", required = false, defaultValue = "0") Integer messageMovementValue,
                                               @RequestParam(value = "track-angle", required = false, defaultValue = "0") Integer trackAngle,
                                               @RequestParam(value = "message-angle", required = false, defaultValue = "0") Integer messageAngle,
                                               @RequestParam(value = "track-digital-1", required = false, defaultValue = "0") Integer trackDigital1,
                                               @RequestParam(value = "track-digital-2", required = false, defaultValue = "0") Integer trackDigital2,
                                               @RequestParam(value = "track-digital-3", required = false, defaultValue = "0") Integer trackDigital3,
                                               @RequestParam(value = "track-digital-4", required = false, defaultValue = "0") Integer trackDigital4,
                                               @RequestParam(value = "message-digital-1", required = false, defaultValue = "0") Integer messageDigital1,
                                               @RequestParam(value = "message-digital-2", required = false, defaultValue = "0") Integer messageDigital2,
                                               @RequestParam(value = "message-digital-3", required = false, defaultValue = "0") Integer messageDigital3,
                                               @RequestParam(value = "message-digital-4", required = false, defaultValue = "0") Integer messageDigital4,
                                               @RequestParam(value = "track-analog-1", required = false, defaultValue = "0") Integer trackAnalog1,
                                               @RequestParam(value = "track-analog-2", required = false, defaultValue = "0") Integer trackAnalog2,
                                               @RequestParam(value = "track-analog-3", required = false, defaultValue = "0") Integer trackAnalog3,
                                               @RequestParam(value = "track-analog-4", required = false, defaultValue = "0") Integer trackAnalog4,
                                               @RequestParam(value = "message-analog-1", required = false, defaultValue = "0") Integer messageAnalog1,
                                               @RequestParam(value = "message-analog-2", required = false, defaultValue = "0") Integer messageAnalog2,
                                               @RequestParam(value = "message-analog-3", required = false, defaultValue = "0") Integer messageAnalog3,
                                               @RequestParam(value = "message-analog-4", required = false, defaultValue = "0") Integer messageAnalog4,
                                               @RequestParam(value = "track-int-bat-v", required = false, defaultValue = "0") Integer trackIntBatV,
                                               @RequestParam(value = "track-int-bat-ma", required = false, defaultValue = "0") Integer trackIntBatmA,
                                               @RequestParam(value = "message-int-bat-v", required = false, defaultValue = "0") Integer messageIntBatV,
                                               @RequestParam(value = "message-int-bat-ma", required = false, defaultValue = "0") Integer messageIntBatmA,
                                               @RequestParam(value = "track-ext-bat", required = false, defaultValue = "0") Integer trackExtBat,
                                               @RequestParam(value = "message-ext-bat", required = false, defaultValue = "0") Integer messageExtBat,
                                               @RequestParam(value = "track-operator", required = false, defaultValue = "0") Integer trackOperator,
                                               @RequestParam(value = "message-operator", required = false, defaultValue = "0") Integer messageOperator,
                                               @RequestParam(value = "track-gsm", required = false, defaultValue = "0") Integer trackGsm,
                                               @RequestParam(value = "message-gsm", required = false, defaultValue = "0") Integer messageGsm,
                                               @RequestParam(value = "track-cell", required = false, defaultValue = "0") Integer trackCell,
                                               @RequestParam(value = "message-cell", required = false, defaultValue = "0") Integer messageCall,
                                               @RequestParam(value = "track-lac", required = false, defaultValue = "0") Integer trackLac,
                                               @RequestParam(value = "message-lac", required = false, defaultValue = "0") Integer messageLac,
                                               @RequestParam(value = "track-sat", required = false, defaultValue = "0") Integer trackSat,
                                               @RequestParam(value = "message-sat", required = false, defaultValue = "0") Integer messageSat,
                                               @RequestParam(value = "track-gnss", required = false, defaultValue = "0") Integer trackGnss,
                                               @RequestParam(value = "message-gnss", required = false, defaultValue = "0") Integer messageGnss,
                                               @RequestParam(value = "track-pdop", required = false, defaultValue = "0") Integer trackPdop,
                                               @RequestParam(value = "message-pdop", required = false, defaultValue = "0") Integer messagePdop,
                                               @RequestParam(value = "track-hdop", required = false, defaultValue = "0") Integer trackHdop,
                                               @RequestParam(value = "message-hdop", required = false, defaultValue = "0") Integer messageHdop,
                                               @RequestParam(value = "track-pcb", required = false, defaultValue = "0") Integer trackPcb,
                                               @RequestParam(value = "message-pcb", required = false, defaultValue = "0") Integer messagePcb,
                                               @RequestParam(value = "track-p", required = false, defaultValue = "0") Integer trackP,
                                               @RequestParam(value = "message-p", required = false, defaultValue = "0") Integer messageP,
                                               @RequestParam(value = "track-deep-sleep", required = false, defaultValue = "0") Integer trackDeppSleep,
                                               @RequestParam(value = "message-deep-sleep", required = false, defaultValue = "0") Integer messageDeepSleep,
                                               @RequestParam(value = "track-level-fuel-1", required = false, defaultValue = "0") Integer trackLevelFuel1,
                                               @RequestParam(value = "track-level-fuel-2", required = false, defaultValue = "0") Integer trackLevelFuel2,
                                               @RequestParam(value = "message-level-fuel-1", required = false, defaultValue = "0") Integer messageLevelFuel1,
                                               @RequestParam(value = "message-level-fuel-2", required = false, defaultValue = "0") Integer messageLevelFuel2,
                                               @RequestParam(value = "track-can-speed", required = false, defaultValue = "0") Integer trackCanSpeed,
                                               @RequestParam(value = "message-can-speed", required = false, defaultValue = "0") Integer messageCanSpeed,
                                               @RequestParam(value = "track-engine-rpm", required = false, defaultValue = "0") Integer trackEngineRpm,
                                               @RequestParam(value = "message-engine-rpm", required = false, defaultValue = "0") Integer messageEngineRpm,
                                               @RequestParam(value = "track-accelerator", required = false, defaultValue = "0") Integer trackAccelerator,
                                               @RequestParam(value = "message-accelerator", required = false, defaultValue = "0") Integer messageAcclerator,
                                               @RequestParam(value = "track-engine-hour", required = false, defaultValue = "0") Integer trackEngineHour,
                                               @RequestParam(value = "message-engine-hour", required = false, defaultValue = "0") Integer messageEngineHour,
                                               @RequestParam(value = "track-total-distance", required = false, defaultValue = "0") Integer trackTotalDistance,
                                               @RequestParam(value = "message-total-distance", required = false, defaultValue = "0") Integer messegaTotalDistance,
                                               @RequestParam(value = "track-service", required = false, defaultValue = "0") Integer trackService,
                                               @RequestParam(value = "message-service", required = false, defaultValue = "0") Integer messageService,
                                               @RequestParam(value = "track-fuel-consumption", required = false, defaultValue = "0") Integer trackFuelConsumption,
                                               @RequestParam(value = "message-fuel-consumption", required = false, defaultValue = "0") Integer messageFuelComsumption,
                                               @RequestParam(value = "track-high-resolition", required = false, defaultValue = "0") Integer trackHighResolition,
                                               @RequestParam(value = "message-high-resolition", required = false, defaultValue = "0") Integer messageHighResolition,
                                               @RequestParam(value = "track-can-level-fuel-1", required = false, defaultValue = "0") Integer trackCanLevelFuel1,
                                               @RequestParam(value = "track-can-level-fuel-2", required = false, defaultValue = "0") Integer trackCanLevelFuel2,
                                               @RequestParam(value = "message-can-level-fuel-1", required = false, defaultValue = "0") Integer messageCanLevelFuel1,
                                               @RequestParam(value = "message-can-level-fuel-2", required = false, defaultValue = "0") Integer messageCanLevelFuel2,
                                               @RequestParam(value = "track-fuel-economy-1", required = false, defaultValue = "0") Integer trackFuleEconomy1,
                                               @RequestParam(value = "track-fuel-economy-2", required = false, defaultValue = "0") Integer trackFuleEconomy2,
                                               @RequestParam(value = "message-fuel-economy-1", required = false, defaultValue = "0") Integer messageFuleEonomy1,
                                               @RequestParam(value = "message-fuel-economy-2", required = false, defaultValue = "0") Integer messageFuleEonomy2,
                                               @RequestParam(value = "track-engine-temperature", required = false, defaultValue = "0") Integer trackEngineTemperature,
                                               @RequestParam(value = "message-engine-temperature", required = false, defaultValue = "0") Integer messageEngineTemperature,
                                               @RequestParam(value = "track-ambient-air", required = false, defaultValue = "0") Integer trackAmbientAir,
                                               @RequestParam(value = "message-ambient-air", required = false, defaultValue = "0") Integer messageAbinietAir,
                                               @RequestParam(value = "track-vin", required = false, defaultValue = "0") Integer trackVin,
                                               @RequestParam(value = "message-vin", required = false, defaultValue = "0") Integer messageVin,
                                               @RequestParam(value = "track-date-received", required = false, defaultValue = "0") Integer trackDateReceived,
                                               @RequestParam(value = "message-date-received", required = false, defaultValue = "0") Integer messageDateReceived,
                                               @RequestParam(value = "track-time-received", required = false, defaultValue = "0") Integer trackTimeReceived,
                                               @RequestParam(value = "message-time-received", required = false, defaultValue = "0") Integer messageTimeReceived,
                                               @RequestParam(value = "track-com1-1", required = false, defaultValue = "0") Integer trackCom11,
                                               @RequestParam(value = "track-com1-2", required = false, defaultValue = "0") Integer trackCom12,
                                               @RequestParam(value = "message-com1-1", required = false, defaultValue = "0") Integer messageCom11,
                                               @RequestParam(value = "message-com1-2", required = false, defaultValue = "0") Integer messageCom12,
                                               @RequestParam(value = "track-com2-1", required = false, defaultValue = "0") Integer trackCom21,
                                               @RequestParam(value = "track-com2-2", required = false, defaultValue = "0") Integer trackCom22,
                                               @RequestParam(value = "message-com2-1", required = false, defaultValue = "0") Integer messageCom21,
                                               @RequestParam(value = "message-com2-2", required = false, defaultValue = "0") Integer messageCom22,
                                               @RequestParam(value = "track-latitude", required = false, defaultValue = "0") Integer trackLatitude,
                                               @RequestParam(value = "message-latitude", required = false, defaultValue = "0") Integer messageLatitude,
                                               @RequestParam(value = "track-longitude", required = false, defaultValue = "0") Integer trackLongitude,
                                               @RequestParam(value = "message-longitude", required = false, defaultValue = "0") Integer messageLongitude

    ) {


        ModelAndView modelAndView;

        if (cmd != null && cmd.equals("edit")) {
            ContractSettings contractSettings = mainController.getContractSettings(session);
            contractSettings.setVtValue(ContractSettings.VT_DATE, trackDate);
            contractSettings.setVmValue(ContractSettings.VM_DATE, messageDate);
            contractSettings.setVtValue(ContractSettings.VT_TIME, trackTime);
            contractSettings.setVmValue(ContractSettings.VM_TIME, messageTime);
            contractSettings.setVtValue(ContractSettings.VT_HIEGHT, trackHeight);
            contractSettings.setVmValue(ContractSettings.VM_HIEGHT, messageHeight);
            contractSettings.setVtValue(ContractSettings.VT_ODOMETR, trackOdometr);
            contractSettings.setVmValue(ContractSettings.VM_ODOMETR, messageOdomert);
            contractSettings.setVtValue(ContractSettings.VT_MOVEMENT_VALUE, trackMovementValue);
            contractSettings.setVmValue(ContractSettings.VM_MOVEMENT_VALUE, messageMovementValue);
            contractSettings.setVtValue(ContractSettings.VT_ANGLE, trackAngle);
            contractSettings.setVmValue(ContractSettings.VM_ANGLE, messageAngle);
            contractSettings.setVtValue(ContractSettings.VT_INT_BAT_V, trackIntBatV);
            contractSettings.setVmValue(ContractSettings.VM_INT_BAT_V, messageIntBatV);
            contractSettings.setVtValue(ContractSettings.VT_INT_BAT_MA, trackIntBatmA);
            contractSettings.setVmValue(ContractSettings.VM_INT_BAT_MA, messageIntBatmA);
            contractSettings.setVtValue(ContractSettings.VT_EXT_BAT, trackExtBat);
            contractSettings.setVmValue(ContractSettings.VM_EXT_BAT, messageExtBat);
            contractSettings.setVtValue(ContractSettings.VT_OPERATOR, trackOperator);
            contractSettings.setVmValue(ContractSettings.VM_OPERATOR, messageOperator);
            contractSettings.setVtValue(ContractSettings.VT_GSM, trackGsm);
            contractSettings.setVmValue(ContractSettings.VM_GSM, messageGsm);
            contractSettings.setVtValue(ContractSettings.VT_CELL, trackCell);
            contractSettings.setVmValue(ContractSettings.VM_CELL, messageCall);
            contractSettings.setVtValue(ContractSettings.VT_LAC, trackLac);
            contractSettings.setVmValue(ContractSettings.VM_LAC, messageLac);
            contractSettings.setVtValue(ContractSettings.VT_SAT, trackSat);
            contractSettings.setVmValue(ContractSettings.VM_SAT, messageSat);
            contractSettings.setVtValue(ContractSettings.VT_GNSS, trackGnss);
            contractSettings.setVmValue(ContractSettings.VM_GNSS, messageGnss);
            contractSettings.setVtValue(ContractSettings.VT_PDOP, trackPdop);
            contractSettings.setVmValue(ContractSettings.VM_PDOP, messagePdop);
            contractSettings.setVtValue(ContractSettings.VT_HDOP, trackHdop);
            contractSettings.setVmValue(ContractSettings.VM_HDOP, messageHdop);
            contractSettings.setVtValue(ContractSettings.VT_PCB, trackPcb);
            contractSettings.setVmValue(ContractSettings.VM_PCB, messagePcb);
            contractSettings.setVtValue(ContractSettings.VT_P, trackP);
            contractSettings.setVmValue(ContractSettings.VM_P, messageP);
            contractSettings.setVtValue(ContractSettings.VT_DEEP_SLEEP, trackDeppSleep);
            contractSettings.setVmValue(ContractSettings.VM_DEEP_SLEEP, messageDeepSleep);
            contractSettings.setVtValue(ContractSettings.VT_LEVEL_FUEL1, trackLevelFuel1);
            contractSettings.setVmValue(ContractSettings.VM_LEVEL_FUEL1, messageLevelFuel1);
            contractSettings.setVtValue(ContractSettings.VT_CAN_SPEED, trackCanSpeed);
            contractSettings.setVmValue(ContractSettings.VM_CAN_SPEED, messageCanSpeed);
            contractSettings.setVtValue(ContractSettings.VT_ENGINE_RPM, trackEngineRpm);
            contractSettings.setVmValue(ContractSettings.VM_ENGINE_RPM, messageEngineRpm);
            contractSettings.setVtValue(ContractSettings.VT_ACCELERATOR, trackAccelerator);
            contractSettings.setVmValue(ContractSettings.VM_ACCELERATOR, messageAcclerator);
            contractSettings.setVtValue(ContractSettings.VT_ENGINE_HOUR, trackEngineHour);
            contractSettings.setVmValue(ContractSettings.VM_ENGINE_HOUR, messageEngineHour);
            contractSettings.setVtValue(ContractSettings.VT_TOTAL_DISTANCE, trackTotalDistance);
            contractSettings.setVmValue(ContractSettings.VM_TOTAL_DISTANCE, messegaTotalDistance);
            contractSettings.setVtValue(ContractSettings.VT_SERVICE, trackService);
            contractSettings.setVmValue(ContractSettings.VM_SERVICE, messageService);
            contractSettings.setVtValue(ContractSettings.VT_FUEL_CONSUPTION, trackFuelConsumption);
            contractSettings.setVmValue(ContractSettings.VM_FUEL_CONSUPTION, messageFuelComsumption);
            contractSettings.setNextVtValue(ContractSettings.VT_HEGH_RESOLITION, trackHighResolition);
            contractSettings.setNextVmValue(ContractSettings.VM_HEGH_RESOLITION, messageHighResolition);
            contractSettings.setNextVtValue(ContractSettings.VT_CAN_LEVEL_FUEL, trackCanLevelFuel1);
            contractSettings.setNextVmValue(ContractSettings.VM_CAN_LEVEL_FUEL, messageCanLevelFuel1);
            contractSettings.setNextVtValue(ContractSettings.VT_FUEL_ECONOMY, trackFuleEconomy1);
            contractSettings.setNextVmValue(ContractSettings.VM_FUEL_ECONOMY, messageFuleEonomy1);
            contractSettings.setNextVtValue(ContractSettings.VT_FUEL_ECONOMY2, trackFuleEconomy2);
            contractSettings.setNextVmValue(ContractSettings.VM_FUEL_ECONOMY2, messageFuleEonomy2);
            contractSettings.setNextVtValue(ContractSettings.VT_ENGINE_TEMPERATURE, trackEngineTemperature);
            contractSettings.setNextVmValue(ContractSettings.VM_ENGINE_TEMPERATURE, messageEngineTemperature);
            contractSettings.setNextVtValue(ContractSettings.VT_AMBIENT_AIR, trackAmbientAir);
            contractSettings.setNextVmValue(ContractSettings.VM_AMBIENT_AIR, messageAbinietAir);
            contractSettings.setNextVtValue(ContractSettings.VT_VIN, trackVin);
            contractSettings.setNextVmValue(ContractSettings.VM_VIN, messageVin);
            contractSettings.setNextVtValue(ContractSettings.VT_DATE_RECEIVED, trackDateReceived);
            contractSettings.setNextVmValue(ContractSettings.VM_DATE_RECEIVED, messageDateReceived);
            contractSettings.setNextVtValue(ContractSettings.VT_TIME_RECEIVED, trackTimeReceived);
            contractSettings.setNextVmValue(ContractSettings.VM_TIME_RECEIVED, messageTimeReceived);
            contractSettings.setNextVtValue(ContractSettings.VT_COM1, trackCom11);
            contractSettings.setNextVmValue(ContractSettings.VM_COM1, messageCom11);
            contractSettings.setNextVtValue(ContractSettings.VT_COM2, trackCom21);
            contractSettings.setNextVmValue(ContractSettings.VM_COM2, messageCom21);
            contractSettings.setNextVtValue(ContractSettings.VT_LATITUDE, trackLatitude);
            contractSettings.setNextVmValue(ContractSettings.VM_LATITUDE, messageLatitude);
            contractSettings.setNextVtValue(ContractSettings.VT_LONGITUDE, trackLongitude);
            contractSettings.setNextVmValue(ContractSettings.VM_LONGITUDE, messageLongitude);
            contractSettings.setNextVtValue(ContractSettings.VT_SPEED_TRACK, trackSpeedTrack);
            contractSettings.setNextVmValue(ContractSettings.VM_SPEED_TRACK, messageSpeedTrack);
            contractSettings.setNextVtValue(ContractSettings.VT_SPEED_IO, trackSpeedIo);
            contractSettings.setNextVmValue(ContractSettings.VM_SPEED_IO, messageSpeedIo);
            contractSettings.setNextVtValue(ContractSettings.VT_DIGITAL1, trackDigital1);
            contractSettings.setNextVtValue(ContractSettings.VT_DIGITAL2, trackDigital2);
            contractSettings.setNextVtValue(ContractSettings.VT_DIGITAL3, trackDigital3);
            contractSettings.setNextVtValue(ContractSettings.VT_DIGITAL4, trackDigital4);
            contractSettings.setNextVmValue(ContractSettings.VM_DIGITAL1, messageDigital1);
            contractSettings.setNextVmValue(ContractSettings.VM_DIGITAL2, messageDigital2);
            contractSettings.setNextVmValue(ContractSettings.VM_DIGITAL3, messageDigital3);
            contractSettings.setNextVmValue(ContractSettings.VM_DIGITAL4, messageDigital4);
            contractSettings.setNextVtValue(ContractSettings.VT_ANALOG1, trackAnalog1);
            contractSettings.setNextVtValue(ContractSettings.VT_ANALOG2, trackAnalog2);
            contractSettings.setNextVtValue(ContractSettings.VT_ANALOG3, trackAnalog3);
            contractSettings.setNextVtValue(ContractSettings.VT_ANALOG4, trackAnalog4);
            contractSettings.setNextVmValue(ContractSettings.VM_ANALOG1, messageAnalog1);
            contractSettings.setNextVmValue(ContractSettings.VM_ANALOG2, messageAnalog2);
            contractSettings.setNextVmValue(ContractSettings.VM_ANALOG3, messageAnalog3);
            contractSettings.setNextVmValue(ContractSettings.VM_ANALOG4, messageAnalog4);
            contractSettings.setNextVtValue(ContractSettings.VT_LEVEL_FUEL2, trackLevelFuel2);
            contractSettings.setNextVmValue(ContractSettings.VM_LEVEL_FUEL2, messageLevelFuel2);
            contractSettings.setNextVtValue(ContractSettings.VT_COM12, trackCom12);
            contractSettings.setNextVtValue(ContractSettings.VT_COM22, trackCom22);
            contractSettings.setNextVmValue(ContractSettings.VM_COM12, messageCom12);
            contractSettings.setNextVmValue(ContractSettings.VM_COM22, messageCom22);
            contractSettings.setNextVtValue(ContractSettings.VT_CAN_LEVEL_FUEL2, trackCanLevelFuel2);
            contractSettings.setNextVmValue(ContractSettings.VM_CAN_LEVEL_FUEL2, messageCanLevelFuel2);


            settingsService.saveContractSettings(contractSettings);
            session.setAttribute(MainController.SESSION_CONTRACT_SETTINGS, contractSettings);

            modelAndView = new ModelAndView("redirect:" + URL_SETTING_MESSAGE);
        } else if (cmd != null && cmd.equals("default")) {

            ContractSettings contractSettings = mainController.getContractSettings(session);

            contractSettings.setViewTrack(77798);
            contractSettings.setViewNextTrack(106880);
            contractSettings.setViewMessage(2965478);
            contractSettings.setViewNextMessage(129408);

            settingsService.saveContractSettings(contractSettings);
            session.setAttribute(MainController.SESSION_CONTRACT_SETTINGS, contractSettings);


            modelAndView = new ModelAndView("redirect:" + URL_SETTING_MESSAGE);

        } else {

            modelAndView = new ModelAndView(VIEW_SETTING_MESSAGE);

            ContractSettings contractSettings = mainController.getContractSettings(session);
            modelAndView.addObject("contractSettings", contractSettings);
            modelAndView.addObject("cmd", "edit");

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        }

        return modelAndView;
    }

}
