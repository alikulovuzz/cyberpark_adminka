package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminService;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.mobile.MobileUserController;
import uzgps.mobile.data.Errors;
import uzgps.mobile.data.MobileInfo;
import uzgps.persistence.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;

/**
 * Created by G'ayrat on 09.12.14.
 */

@Controller
public class SettingsMobileController extends AbstractSettingsController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    CoreMain coreMain;

    @Autowired
    MobileUserController mobileUserController;

    @Autowired
    AdminService adminService;

    @Autowired
    SettingsService settingsService;

    private static final String URL_SETTINGS_MOBILE = "/settings/mobile.htm";
    private static final String VIEW_SETTINGS_MOBILE = "settings/settings-mobile";

    private static final String URL_SETTINGS_MOBILE_ADD = "/settings/mobile-add.htm";
    private static final String URL_SETTINGS_MOBILE_REMOVE = "/settings/mobile-remove.htm";
    private static final String URL_SETTINGS_MOBILE_REPLACE = "/settings/mobile-replace.htm";


    @RequestMapping(value = URL_SETTINGS_MOBILE)
    public ModelAndView processSettingsMobile(HttpSession session,
                                              @RequestParam(value = "errorCode", required = false) String errorCode,
                                              @RequestParam(value = "rserialNumber", required = false) String rserialNumber,
                                              @RequestParam(value = "rmObjectId", required = false) Long rmObjectId,
                                              @RequestParam(value = "rmObjectName", required = false) String rmObjectName,
                                              @RequestParam(value = "rErrorCode", required = false) Integer rErrorCode)


            throws ServletException, IOException {
        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsMobile: rErrorCode={}", rErrorCode);
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_MOBILE);
        long userMaxCount = 0;
        long mobjectMaxCount = 0;
        long staffMaxCount = 0;
        String display = "none";
        String errorMessage = null;
        if (rErrorCode == null || rErrorCode == 0) {
            display = "none";
        } else if (rErrorCode == 1) {
            display = "block";
            errorMessage = "mobile.replace.error";

        }
        modelAndView.addObject("userMaxCount", userMaxCount);
        modelAndView.addObject("mobjectMaxCount", mobjectMaxCount);
        modelAndView.addObject("staffMaxCount", staffMaxCount);
        modelAndView.addObject("errorCode", errorCode);
        modelAndView.addObject("display", display);
        modelAndView.addObject("rserialNumber", rserialNumber);
        modelAndView.addObject("rmObjectId", rmObjectId);
        modelAndView.addObject("rmObjectName", rmObjectName);
        modelAndView.addObject("errorMessage", errorMessage);

        modelAndView.addObject("objectId", "0");

        // Get Mobject list for this contract
        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);

//        List<MObjectGPSUnit> mObjectGPSUnitList = adminService.getMObjectGPSUnitByContractId(MainController.getUserContractId(session));
        List<MObjectGPSUnit> mObjectGPSUnitList = adminService.getMObjectGPSUnitMobileByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("mObjectGPSUnitList", mObjectGPSUnitList);

        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_MOBILE_ADD)
    public ModelAndView processSettingsAddMobile(HttpSession session,
                                                 @RequestParam(value = "serial-number", required = false) String serialNumber)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsAddMobile: serial-number={}", serialNumber);
        }

        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_MOBILE + "?errorCode=" + 2);

        if (serialNumber != null && serialNumber.trim().length() > 0) {
            // User user = adminService.getUserByContractId(MainController.getUserContractId(session));
            User user = settingsService.getUserByUserId(MainController.getInterfaceUserId());

            if (user != null) {
                int errorCode = mobileUserController.processMobileInfo(user.getLogin(), serialNumber, session);
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_MOBILE + "?errorCode=" + errorCode);
            }
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_MOBILE_REMOVE)
    public ModelAndView processSettingsRemoveMobile(HttpSession session,
                                                    @RequestParam(value = "mobject-id[]", required = false) Long[] mObjectIdList)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsRemoveMobile: mobject-id[]={}", (Object) mObjectIdList);
        }

        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_MOBILE);

        if (mObjectIdList != null) {
            for (Long mObjectId : mObjectIdList) {
                Timestamp modDate = new Timestamp(System.currentTimeMillis());
                MObject mObject = adminService.getMObjectById(mObjectId);

                if (mObject != null) {

                    MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mObject.getId());
                    if (mObjectGPSUnit != null) {

                        GPSUnit gpsUnit = mObjectGPSUnit.getGpsUnit();

                        if (gpsUnit != null) {
                            GPSUnitSim gpsUnitSim = adminService.getGPSUnitSimByGPSUnitId(gpsUnit.getId());

                            Sim sim = gpsUnitSim.getSim();
                            sim.setExpDate(modDate);
                            sim.setStatus(UZGPS_CONST.STATUS_DELETE);
                            adminService.saveSim(sim);

                            gpsUnitSim.setExpDate(modDate);
                            gpsUnitSim.setStatus(UZGPS_CONST.STATUS_DELETE);
                            adminService.saveGPSUnitSim(gpsUnitSim);

                            gpsUnit.setExpDate(modDate);
                            gpsUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                            adminService.saveGPSUnit(gpsUnit);

                            // Update gpsUnit in core
                            coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                        }

                        mObjectGPSUnit.setExpDate(modDate);
                        mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                        adminService.saveMObjectGPSUnit(mObjectGPSUnit);
                    }

                    MobileTrackerSettings mobileTrackerSettings = settingsService.getMobileTrackerSettingsByObjectId(mObject.getId());
                    if (mobileTrackerSettings != null) {
                        mobileTrackerSettings.setExpDate(modDate);
                        mobileTrackerSettings.setStatus(UZGPS_CONST.STATUS_DELETE);
                        settingsService.saveMobileTrackerSettings(mobileTrackerSettings);
                    }

                    // Delete MObjectNotifications
                    MObjectNotifications mObjectNotifications = settingsService.getMObjectNotificationsByObjectId(mObject.getId());
                    if (mObjectNotifications != null) {
                        mObjectNotifications.setExpDate(modDate);
                        mObjectNotifications.setStatus(UZGPS_CONST.STATUS_DELETE);
                        settingsService.savemMObjectNotifications(mObjectNotifications);
                    }
                    // Delete MObjectSettings
                    MObjectSettings mObjectSettings = settingsService.getObjectSettingsByObjectId(mObject.getId());
                    if (mObjectSettings != null) {
                        mObjectSettings.setExpDate(modDate);
                        mObjectSettings.setStatus(UZGPS_CONST.STATUS_DELETE);
                        settingsService.saveMObjectSettings(mObjectSettings);
                    }

                    mObject.setExpDate(modDate);
                    mObject.setStatus(UZGPS_CONST.STATUS_DELETE);
                    adminService.saveMObject(mObject);

                    Contract contract = adminService.getContractById(MainController.getUserContractId(session));
                    if (contract != null) {
                        // Save Mobject count for Contract
                        contract.setExistUnitCount(adminService.getMobjectCountByContractId(contract.getId()));
                        adminService.saveContract(contract);
                    }

                    // Update mobject in core
                    coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                }
            }
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_MOBILE_REPLACE)
    public ModelAndView processSettingsMobileReplace(@RequestParam(value = "mobject-id", required = false) Long mObjectId,
                                                     @RequestParam(value = "mobject-name", required = false) String mObjectName,
                                                     @RequestParam(value = "serial-number", required = false) String serialNumber)
            throws ServletException, IOException {
        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsMobileReplace: mobject-id={}, serial-number={}", mObjectId, serialNumber);
        }


        MObject mObject = adminService.getMObjectById(mObjectId);
        Integer rErrorCode = 1;

        if (mObjectId != null && serialNumber != null && serialNumber.trim().length() > 0) {
            MobileInfo mobileInfo = mobileUserController.getMobileInfo(serialNumber);

            if (mobileInfo != null) {
                Timestamp modDate = new Timestamp(System.currentTimeMillis());

                if (mObject != null) {
                    MObjectGPSUnit mObjectGPSUnit = adminService.getMObjectGPSUnitByMObjectId(mObject.getId());

                    if (mObjectGPSUnit != null) {
                        GPSUnit gpsUnit = mObjectGPSUnit.getGpsUnit();
                        GPSUnitSim gpsUnitSim = adminService.getGPSUnitSimByGPSUnitId(gpsUnit.getId());
                        if (gpsUnitSim != null) {
                            Sim sim = gpsUnitSim.getSim();
                            if (sim != null) {
                                sim.setExpDate(modDate);
                                sim.setStatus(UZGPS_CONST.STATUS_DELETE);
                                adminService.saveSim(sim);
                            }
                            gpsUnitSim.setExpDate(modDate);
                            gpsUnitSim.setStatus(UZGPS_CONST.STATUS_DELETE);
                            adminService.saveGPSUnitSim(gpsUnitSim);

                            // Update gpsUnit in core
                            coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                        }
                        gpsUnit.setExpDate(modDate);
                        gpsUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                        adminService.saveGPSUnit(gpsUnit);

                        mObjectGPSUnit.setExpDate(modDate);
                        mObjectGPSUnit.setStatus(UZGPS_CONST.STATUS_DELETE);
                        adminService.saveMObjectGPSUnit(mObjectGPSUnit);

                        coreMain.coreUpdater.updateGpsUnit(gpsUnit.getId());
                    }

                    MobileTrackerSettings mobileTrackerSettings = settingsService.getMobileTrackerSettingsByObjectId(mObject.getId());
                    rErrorCode = mobileUserController.processMObjectSerialReplacement(mObject, serialNumber);

                    if (rErrorCode == Errors.CODE_SUCCESS) {
                        if (mobileTrackerSettings != null) {
                            mobileTrackerSettings.setMobileSerial(serialNumber);
                            mobileTrackerSettings.setModDate(modDate);
                        }
                    } else {
                        if (mobileTrackerSettings != null) {
                            mobileTrackerSettings.setStatus(UZGPS_CONST.STATUS_DELETE);
                            mobileTrackerSettings.setExpDate(modDate);
                        }
                    }

                    settingsService.saveMobileTrackerSettings(mobileTrackerSettings);
                }
            }
        }

        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_MOBILE + "?rmObjectId=" + mObjectId + "&rmObjectName="
                + mObjectName + "&rserialNumber=" + serialNumber + "&rErrorCode=" + rErrorCode);

        return modelAndView;
    }

}
