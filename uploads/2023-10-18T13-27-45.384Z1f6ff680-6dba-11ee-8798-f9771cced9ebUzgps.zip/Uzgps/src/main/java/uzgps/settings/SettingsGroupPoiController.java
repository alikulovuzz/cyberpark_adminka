package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.Poi;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsGroupPoiController extends AbstractSettingsController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_POI_GROUP = "/settings/poi-group.htm";
    private final static String VIEW_SETTINGS_POI_GROUP = "settings/settings-poi-group";

    private final static String URL_SETTINGS_POI_GROUP_MANAGE = "/settings/poi-group-manage.htm";
    private final static String VIEW_SETTINGS_POI_GROUP_MANAGE = "settings/settings-poi-group-manage";

    private final static String URL_SETTINGS_POI_GROUP_ITEM = "/settings/poi-group-item.htm";
    private final static String VIEW_SETTINGS_POI_GROUP_ITEM = "settings/settings-poi-group-item";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTINGS_POI_GROUP)
    public ModelAndView processSettingsPoiGroup(HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_POI_GROUP);

        List<PoiGroup> poiGroupList = settingsService.getPoiGroupByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("poiGroupList", poiGroupList);
        modelAndView.addObject("groupCountPoi", (poiGroupList != null) ? poiGroupList.size() : 0);
        modelAndView.addObject("groupPoiId", "0");

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        modelAndView.addObject("selectedLeftMenu", "poiGroup");

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_POI_GROUP_MANAGE)
    public ModelAndView processSettingsPoiGroupManage(HttpSession session,
                                                      @RequestParam(value = "cmd", required = false) String cmd,
                                                      @RequestParam(value = "group-name", required = false) String groupName,
                                                      @RequestParam(value = "id", required = false) Long groupId,
                                                      @RequestParam(value = "r-id[]", required = false) Long[] rGroupIdList)
            throws ServletException, IOException {

        ModelAndView modelAndView = null;

        if (cmd != null) {

            if (cmd.equalsIgnoreCase("save")) {
                PoiGroup poiGroup = new PoiGroup();
                poiGroup.setContractId(MainController.getUserContractId(session));
                poiGroup.setName(groupName);
                poiGroup.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                poiGroup.setRegDate(new Timestamp(System.currentTimeMillis()));
                settingsService.savePoIGroup(poiGroup);
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_POI_GROUP);
            } else if (cmd.equalsIgnoreCase("edit")) {
                modelAndView = new ModelAndView(VIEW_SETTINGS_POI_GROUP_MANAGE);
                PoiGroup poiGroup = settingsService.getPoiGroupById(groupId);
                modelAndView.addObject("group", poiGroup);
                modelAndView.addObject("cmd", "update");
                modelAndView.addObject("id", groupId);
                modelAndView.addObject("groupPoiId", "0");

                boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
                List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
                modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

                Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

                Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

                Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

            } else if (cmd.equalsIgnoreCase("update")) {
                PoiGroup poiGroup = settingsService.getPoiGroupById(groupId);
                poiGroup.setName(groupName);
                poiGroup.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.savePoIGroup(poiGroup);

                // Update group name in core
                List<MObject> mObjectList = settingsService.getObjectByContractIdAndGroupId(MainController.getUserContractId(session), groupId);
                for (MObject mObject : mObjectList) {
                    if (mObject != null) {
                        // Update core Cloud : GpsUnitBig and Mobject must be updated
                        coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                    }
                }

                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_POI_GROUP);
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rGroupId : rGroupIdList) {
                    PoiGroup poiGroup = settingsService.getPoiGroupById(rGroupId);
                    PoiGroup poiGroupZero = settingsService.getPoiGroupById(0L);

                    List<POI> poiList = settingsService.getPoiByContractIdAndGroupId(MainController.getUserContractId(session), rGroupId);
                    for (POI poi : poiList) {
                        if (poi != null) {
                            poi.setGroup(poiGroupZero);
                            settingsService.savePOI(poi);

                            // Update core Cloud : GpsUnitBig and Mobject must be updated
                            coreMain.coreUpdater.updatePoiById(poi.getId());
                        }
                    }

                    poiGroup.setExpDate(new Timestamp(System.currentTimeMillis()));
                    poiGroup.setStatus(UZGPS_CONST.STATUS_DELETE);
                    settingsService.savePoIGroup(poiGroup);
                }
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_POI_GROUP);
            }
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_POI_GROUP_MANAGE);
            modelAndView.addObject("cmd", "save");

            List<PoiGroup> groups = settingsService.getPoiGroupByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("poiGroupList", groups);
            modelAndView.addObject("groupCountPoi", (groups != null) ? groups.size() : 0);
            modelAndView.addObject("groupPoiId", "0");

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);
        }


        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_POI_GROUP_ITEM)
    public ModelAndView processSettingsPoiGroupItem(HttpSession session,
                                                    @RequestParam(value = "cmd", required = false) String cmd,
                                                    @RequestParam(value = "object-id-list", required = false) String objectIdList,
                                                    @RequestParam(value = "group-id", required = false) Long groupId)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsGroup cmd={}, object-id-list={}, id={}, r-id[]",
                    cmd, objectIdList, groupId);
        }

        ModelAndView modelAndView;

        // cmd exists. if save - saves elements of group
        if (cmd != null) {
            List<POI> poiList = settingsService.getPoiByContractIdAndGroupId(MainController.getUserContractId(session), groupId);
            PoiGroup poiGroup = settingsService.getPoiGroupById(0L);

            // Put all geoFenceList into PoiGroup 0 - empty group
            for (POI poi : poiList) {
                poi.setGroup(poiGroup);
                poi.setModDate(new Timestamp(System.currentTimeMillis()));
                settingsService.savePOI(poi);

                // Update core Cloud : POI must be updated
                coreMain.coreUpdater.updatePoiById(poi.getId());
            }

            if (!objectIdList.equalsIgnoreCase("")) {
                List<String> newGroupPoiIdList = new ArrayList<>(Arrays.asList(objectIdList.split(",")));
                PoiGroup selectPoiGroup = settingsService.getPoiGroupById(groupId);

                // Set new PoiGroup Id for each POI
                for (String newGroupPoiId : newGroupPoiIdList) {
                    POI poi = settingsService.getPOIById(Long.parseLong(newGroupPoiId));
                    poi.setGroup(selectPoiGroup);
                    poi.setModDate(new Timestamp(System.currentTimeMillis()));
                    settingsService.savePOI(poi);

                    // Update core Cloud : POI must be updated
                    coreMain.coreUpdater.updatePoiById(poi.getId());
                }
            }
            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_POI_GROUP_ITEM + "?group-id=" + groupId);
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_POI_GROUP_ITEM);
            modelAndView.addObject("cmd", "save");
            modelAndView.addObject("groupPoiId", groupId);

            List<Poi> poiList = coreMain.getPoiListByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("poiList", poiList);
            modelAndView.addObject("poiListCount", (poiList != null) ? poiList.size() : 0);

            List<PoiGroup> groups = settingsService.getPoiGroupByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("poiGroupList", groups);
            modelAndView.addObject("groupCountPoi", (groups != null) ? groups.size() : 0);

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);
        }

        return modelAndView;
    }


}
