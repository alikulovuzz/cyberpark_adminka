package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.common.Converters;
import uzgps.common.FileStorageService;
import uzgps.common.UZGPS_CONST;
import uzgps.excel.data.ExcelStaff;
import uzgps.main.MainController;
import uzgps.persistence.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14
 */

@Controller
public class SettingsStaffController extends AbstractSettingsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_STAFF = "/settings/staff.htm";
    private final static String VIEW_SETTINGS_STAFF = "settings/settings-staff";

    private final static String URL_SETTINGS_STAFF_MANAGE = "/settings/staff-manage.htm";
    private final static String VIEW_SETTINGS_STAFF_MANAGE = "settings/settings-staff-manage";

    public static final String URL_AJAX_SUBDIVISION_LIST = "/settings/ajax-subdivision-list.htm";
    public static final String VIEW_AJAX_SUBDIVISION_LIST = "/settings/ajax-subdivision-select";

    private final static String URL_SETTINGS_STAFF_PROFILE = "/settings/staff-profile.htm";
    private final static String URL_SETTINGS_STAFF_PROFILE_MANAGE = "/settings/staff-profile-manage.htm";
    private final static String URL_SETTINGS_STAFF_PROFILE_SCHEDULE = "/settings/staff-schedule-manage.htm";
    private final static String VIEW_SETTINGS_STAFF_PROFILE = "settings/settings-staff-profile";
    private final static String SESSION_STAFF_TEXT_SEARCH = "sessionStaffTextSearch";
    private final static String SESSION_STAFF_SHOW_ONLY_WITH_MOBJECT = "sessionStaffShowOnlyWithMobjects";

    private final static String URL_SETTINGS_STAFF_DOWNLOAD_EXCEL = "/settings/staff/download-excel.htm";


    @Autowired
    private SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @Autowired
    FileStorageService storageService;

    @RequestMapping(value = URL_SETTINGS_STAFF)
    public ModelAndView processSettingsStaff(HttpSession session, @RequestParam(value = "errorNumber", required = false) String errorNumber,
                                             @RequestParam(value = "textSearch", required = false, defaultValue = "") String textSearch,
                                             @RequestParam(value = "show_only_with_mobjects", defaultValue = "false") Boolean showOnlyWithMobjects,
                                             @RequestParam(value = "cmd", required = false) String cmd) {
        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_STAFF);

        if (cmd != null) {
            if (cmd.equalsIgnoreCase("clear")) {
                session.removeAttribute(SESSION_STAFF_TEXT_SEARCH);
                session.removeAttribute(SESSION_STAFF_SHOW_ONLY_WITH_MOBJECT);
            }
        }

        if (textSearch.length() == 0) {
            textSearch = (String) session.getAttribute(SESSION_STAFF_TEXT_SEARCH);
        }

        modelAndView.addObject("staffId", "0");
        modelAndView.addObject("errorNumber", errorNumber);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        List<Staff> staffList = settingsService.getStaffByContractIdAndText(MainController.getUserContractId(session), textSearch, showOnlyWithMobjects);
        modelAndView.addObject("staffList", staffList);
        modelAndView.addObject("staffCount", (staffList != null) ? staffList.size() : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        modelAndView.addObject("contractId", MainController.getUserContractId(session));

        session.setAttribute(SESSION_STAFF_TEXT_SEARCH, textSearch);
        session.setAttribute(SESSION_STAFF_SHOW_ONLY_WITH_MOBJECT, showOnlyWithMobjects);

        modelAndView.addObject("textSearch", textSearch);
        modelAndView.addObject("showOnlyWithMobjects", showOnlyWithMobjects);
        modelAndView.addObject("selectedLeftMenu", "staff");

        return modelAndView;
    }


    @RequestMapping(value = URL_SETTINGS_STAFF_MANAGE)
    public ModelAndView processSettingsStaffManage(HttpSession session,
                                                   @RequestParam(value = "cmd", required = false) String cmd,
                                                   @RequestParam(value = "sur-name", required = false) String surName,
                                                   @RequestParam(value = "name", required = false) String name,
                                                   @RequestParam(value = "middle-name", required = false) String middleName,
                                                   @RequestParam(value = "id", required = false) Long staffId,
                                                   @RequestParam(value = "r-id[]", required = false) Long[] rStaffIdList) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsStaffManage cmd={}, sur-name={}, name={}, middle-name={},id={}",
                    cmd, surName, name, middleName, staffId);
        }

        ModelAndView modelAndView = null;

        if (cmd != null) {

            if (cmd.equalsIgnoreCase("save")) {
                Staff staff = new Staff();
                staff.setContractId(MainController.getUserContractId(session));
                staff.setSurName(surName);
                staff.setName(name);
                staff.setMiddleName(middleName);
                staff.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                staff.setRegDate(new Timestamp(System.currentTimeMillis()));
                settingsService.saveStaff(staff);

                // Core Update for staff
                coreMain.coreUpdater.updateStaffById(staff.getId());

                // After Save Redirect to Staff Profile to next edit
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_STAFF_PROFILE + "?staff-id=" + staff.getId());
            } else if (cmd.equalsIgnoreCase("edit")) {
                // Redirect to Staff Profile to edit
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_STAFF_PROFILE + "?staff-id=" + staffId);
            } else if (cmd.equalsIgnoreCase("remove")) {
                for (Long rStaffId : rStaffIdList) {
                    Staff staff = settingsService.getStaffById(rStaffId);
                    staff.setExpDate(new Timestamp(System.currentTimeMillis()));
                    staff.setStatus(UZGPS_CONST.STATUS_DELETE);
                    settingsService.saveStaff(staff);

                    // Core Update for staff
                    coreMain.coreUpdater.updateStaffById(staff.getId());

                    // Core update - delete mobject staff connections
                    List<MObjectStaff> mObjectStaffList = settingsService.getObjectStaffByStaffId(staff.getId());
                    if (mObjectStaffList != null)
                        for (MObjectStaff mObjectStaff : mObjectStaffList) {
                            mObjectStaff.setExpDate(new Timestamp(System.currentTimeMillis()));
                            mObjectStaff.setStatus(UZGPS_CONST.STATUS_DELETE);
                            settingsService.saveMObjectStaff(mObjectStaff);

                            if (coreMain.coreUpdater != null)
                                coreMain.coreUpdater.updateMobjectStaffById(mObjectStaff.getId());
                        }

                }
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_STAFF);
            }
        } else {
            Long counter = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            Long maxStaffCount = MainController.getUserContract(session).getActiveMaxStaffCount();

            if (counter != null
                    && counter.equals(maxStaffCount)) {
                modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_STAFF + "?errorNumber=1");
            } else {
                modelAndView = new ModelAndView(VIEW_SETTINGS_STAFF_MANAGE);
                modelAndView.addObject("cmd", "save");

                boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
                List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);

                modelAndView.addObject("mobjectList", mobjectList);
                modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

                Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

                List<Staff> staffList = settingsService.getStaffByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("staffList", staffList);
                modelAndView.addObject("staffCount", (staffList != null) ? staffList.size() : 0);

                Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
                modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

                modelAndView.addObject("staffId", "0");

            }
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_STAFF_PROFILE)
    public ModelAndView processSettingsStaffProfile(HttpSession session,
                                                    @RequestParam(value = "staff-id", required = false) Long staffId) {

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_STAFF_PROFILE);

        return processSettingsStaffProfileView(session, modelAndView, staffId);
    }

    private ModelAndView processSettingsStaffProfileView(HttpSession session, ModelAndView modelAndView, Long staffId) {

        Staff staff = settingsService.getStaffById(staffId);
        modelAndView.addObject("staff", staff);
        modelAndView.addObject("cmd", "save");
        modelAndView.addObject("staffId", staffId);

        List<MObjectStaff> mObjectStaffList = settingsService.getObjectStaffByStaffId(staffId);
        modelAndView.addObject("mObjectStaffList", mObjectStaffList);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("mobjectList", mobjectList);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        List<Staff> staffList = settingsService.getStaffByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffList", staffList);
        modelAndView.addObject("staffCount", (staffList != null) ? staffList.size() : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        List<CatalogCompany> catalogCompanyList = settingsService.getCatalogCompanyByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("catalogCompanyList", catalogCompanyList);

        if (staff.getCatalogCompany() != null) {
            Long catalogCompanyId = staff.getCatalogCompany().getId();
            List<CatalogSubdivision> catalogSubdivisionList = settingsService.getCatalogSubdivisionListByCompanyId(catalogCompanyId);
            modelAndView.addObject("catalogSubdivisionList", catalogSubdivisionList);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_STAFF_PROFILE_MANAGE)
    public ModelAndView processSettingsStaffProfile(@RequestParam(value = "cmd", required = false) String cmd,
                                                    @RequestParam(value = "file", required = false) MultipartFile file,
                                                    @RequestParam(value = "sur-name", required = false) String surName,
                                                    @RequestParam(value = "name", required = false) String name,
                                                    @RequestParam(value = "middle-name", required = false) String middleName,
                                                    @RequestParam(value = "position", required = false) String position,
                                                    @RequestParam(value = "phone-mobile", required = false) String phoneMobile,
                                                    @RequestParam(value = "phone-line", required = false) String phoneLine,
                                                    @RequestParam(value = "subdivision-id", required = false) String subdivisionIdStr,
                                                    @RequestParam(value = "company-id", required = false) String companyIdStr,
                                                    @RequestParam(value = "staff-id", required = false) Long staffId) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsStaffProfile cmd={}, sur-name={}, name={}, middle-name={}, position={}, phone-mobile={}, phone-line={}, staff-id={}",
                    cmd, surName, name, middleName, position, phoneMobile, phoneLine, staffId);
        }

        ModelAndView modelAndView;

        if (cmd != null) {
            Staff staff = settingsService.getStaffById(staffId);
            Long fileStorageId = null; // for update photo

            if (file != null && file.getSize() > 0) {
                if (staff.getPhoto() != null) {
                    // Remove the image of Profile if exists
                    FileStorage oldFileStorage = staff.getPhoto();
                    staff.setPhoto(null);
                    settingsService.saveStaff(staff);
                    storageService.removeFileFromStorage(oldFileStorage);
                }

                FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                staff.setPhoto(fileStorage);
                if (fileStorage != null)
                    fileStorageId = fileStorage.getId(); // for update in core
            } else if (file == null) {
                // Remove the image of Profile if exists
                FileStorage fileStorage = staff.getPhoto();
                if (fileStorage != null) {
                    fileStorageId = fileStorage.getId(); // for update in core
                    staff.setPhoto(null);
                    settingsService.saveStaff(staff);
                    storageService.removeFileFromStorage(fileStorage);
                }
            }
            Long subdivisionId = Converters.strToLong(subdivisionIdStr, 0L);
            Long companyId = Converters.strToLong(companyIdStr, 0L);

            if (companyId != 0) {
                CatalogCompany catalogCompany = settingsService.getCatalogCompanyById(companyId);
                staff.setCatalogCompany(catalogCompany);
            } else {
                staff.setCatalogCompany(null);
            }

            if (companyId != 0 && subdivisionId != 0) {
                CatalogSubdivision catalogSubdivision = settingsService.getCatalogSubdivisionById(subdivisionId);
                staff.setCatalogSubdivision(catalogSubdivision);
            } else {
                staff.setCatalogSubdivision(null);
            }


            staff.setSurName(surName);
            staff.setName(name);
            staff.setMiddleName(middleName);
            staff.setPosition(position);
            staff.setPhoneMobile(phoneMobile);
            staff.setPhoneLine(phoneLine);
            staff.setModDate(new Timestamp(System.currentTimeMillis()));
            settingsService.saveStaff(staff);

            // Core Update for staff
            coreMain.coreUpdater.updateUzgpsFileById(fileStorageId);
            coreMain.coreUpdater.updateStaffById(staff.getId());

        }
        modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_STAFF_PROFILE + "?staff-id=" + staffId);

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_STAFF_PROFILE_SCHEDULE)
    public ModelAndView processSettingsStaffProfileSchedule(HttpSession session,
                                                            @RequestParam(value = "cmd", required = false, defaultValue = "") String cmd,
                                                            @RequestParam(value = "id", required = false, defaultValue = "0") Long id,
                                                            @RequestParam(value = "staff-id", required = false, defaultValue = "0") Long staffId,
                                                            @RequestParam(value = "object-id", required = false, defaultValue = "0") Long objectId,
                                                            @RequestParam(value = "start-date", required = false, defaultValue = "") String startDate,
                                                            @RequestParam(value = "end-date", required = false, defaultValue = "") String endDate,
                                                            @RequestParam(value = "always-date", defaultValue = "false") Boolean alwaysDate) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsStaffProfileSchedule cmd={}, staff-id={}, object-id={}, start-date={}, end-date={}, always-date={}, id={}",
                    cmd, staffId, objectId, startDate, endDate, alwaysDate, id);
        }

        ModelAndView modelAndView;

        if (cmd != null) {

            Long mobjectStaffId = null; // for update photo

            if (cmd.equalsIgnoreCase("save")) {

                if (objectId != null && objectId != 0 && !startDate.equalsIgnoreCase("") && (!endDate.equalsIgnoreCase("") || alwaysDate)) {
                    MObjectStaff mObjectStaff = new MObjectStaff();
                    MObject mObject = settingsService.getObjectByObjectId(objectId);

//                    mobjectStaffId = mObjectStaff.getId(); // for update photo

                    mObjectStaff.setmObject(mObject);
                    mObjectStaff.setStaffId(staffId);

                    // for Old Staff list
                    List<MObjectStaff> mObjectStaffList;

                    // Get start date to sDate variable
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
                    Date sDate = null;
                    try {
                        sDate = dateFormat.parse(startDate);
                    } catch (ParseException e) {
                        logger.error("Error in SettingsStaffController - processSettingsStaffProfileSchedule: " + e.getMessage());
                    }

                    // check sDate to be today or later
                    long curtime = System.currentTimeMillis();
                    long millis = curtime % 86400000; // hour, minute, second
                    curtime -= millis; // time 0:00
                    curtime -= 18000000; // Tashkent timezone
                    Timestamp tsToday = new Timestamp(curtime);

                    if (sDate != null && sDate.before(tsToday)) {
                        ModelAndView modelAndViewError = new ModelAndView(VIEW_SETTINGS_STAFF_PROFILE);

                        modelAndViewError.addObject("mObjectId", objectId);
                        modelAndViewError.addObject("fromDate", startDate);
                        modelAndViewError.addObject("toDate", endDate);

                        modelAndViewError.addObject("errorStartDateLessCurrentTime", true);
                        return processSettingsStaffProfileView(session, modelAndViewError, staffId);
                    }

                    if (alwaysDate) {
                        mObjectStaff.setStartDate(new Timestamp(sDate.getTime()));
                        mObjectStaff.setEndDate(new Timestamp(sDate.getTime()));
                        mObjectStaff.setEndless(true);

                        // Get exist staff list
                        Timestamp dateFrom = mObjectStaff.getStartDate();
                        mObjectStaffList = settingsService.getObjectStaffByStartDate(objectId, dateFrom);
                    } else {

                        Date eDate = null;
                        try {
                            sDate = Converters.dateFormatterStringToDateFull(startDate);
                            eDate = Converters.dateFormatterStringToDateFull(endDate);
                        } catch (ParseException e) {
                            logger.error("Error in processSettingsStaffProfileSchedule", e);
                        }
                        mObjectStaff.setStartDate(new Timestamp(sDate.getTime()));
                        mObjectStaff.setEndDate(new Timestamp(eDate.getTime()));
                        mObjectStaff.setEndless(false);

                        // Get existence staff list
                        Timestamp dateFrom = mObjectStaff.getStartDate();
                        Timestamp dateTo = mObjectStaff.getEndDate();
                        mObjectStaffList = settingsService.getObjectStaffByDatesStaff(objectId, staffId, sDate, eDate);
                    }

                    mObjectStaff.setStatus(UZGPS_CONST.STATUS_ACTIVE);
                    mObjectStaff.setRegDate(new Timestamp(System.currentTimeMillis()));

                    if ((mObjectStaffList != null) && (mObjectStaffList.size() > 0)) {
                        ModelAndView modelAndViewError = new ModelAndView(VIEW_SETTINGS_STAFF_PROFILE);

                        // Put Staff names for each MobjectStaff object
                        for (MObjectStaff ms : mObjectStaffList) {
                            if (ms != null && ms.getStaffId() != null) {
                                Staff staff = settingsService.getStaffById(ms.getStaffId());
                                if (staff != null)
                                    ms.setStaffName(staff.getName() + " " + staff.getSurName() + " " + staff.getMiddleName());
                            }
                        }

                        // Error if staff set to mobject for existing period
                        // Set to view and show in display

                        modelAndViewError.addObject("mObjectId", objectId);
                        modelAndViewError.addObject("fromDate", startDate);
                        modelAndViewError.addObject("toDate", endDate);

                        modelAndViewError.addObject("existStaffList", mObjectStaffList);
                        return processSettingsStaffProfileView(session, modelAndViewError, staffId);

                    } else {
                        // Save new time for staff
                        settingsService.saveMObjectStaff(mObjectStaff);
                        mobjectStaffId = mObjectStaff.getId(); // For core update
                    }
                } else if (objectId == null || objectId == 0) {
                    // Error when mobject is not select
                    ModelAndView modelAndViewError = new ModelAndView(VIEW_SETTINGS_STAFF_PROFILE);

                    // SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");

                    modelAndViewError.addObject("isAlwaysPeriod", alwaysDate);
                    modelAndViewError.addObject("isAlwaysPeriod2", 1);
                    modelAndViewError.addObject("isAlwaysPeriod3", 0);

                    modelAndViewError.addObject("fromDate", startDate);
                    modelAndViewError.addObject("toDate", endDate);

                    modelAndViewError.addObject("errorMobjectIsNotSelect", true);
                    return processSettingsStaffProfileView(session, modelAndViewError, staffId);
                } else if (startDate.equalsIgnoreCase("") || (endDate.equalsIgnoreCase("") && !alwaysDate)) {
                    // Error when set not valid time period
                    ModelAndView modelAndViewError = new ModelAndView(VIEW_SETTINGS_STAFF_PROFILE);

                    modelAndViewError.addObject("mObjectId", objectId);
                    modelAndViewError.addObject("fromDate", startDate);
                    modelAndViewError.addObject("toDate", endDate);

                    modelAndViewError.addObject("errorPeriodIsNotValid", true);
                    return processSettingsStaffProfileView(session, modelAndViewError, staffId);
                } else {
                    // Error if mobject is not select on saving
                    ModelAndView modelAndViewError = new ModelAndView(VIEW_SETTINGS_STAFF_PROFILE);
                    modelAndViewError.addObject("errorMobjectIsNotSelect", true);
                    return processSettingsStaffProfileView(session, modelAndViewError, staffId);
                }
            } else if (cmd.equalsIgnoreCase("remove")) {
                MObjectStaff mObjectStaff = settingsService.getObjectStaffById(id);
                mObjectStaff.setExpDate(new Timestamp(System.currentTimeMillis()));
                mObjectStaff.setStatus(UZGPS_CONST.STATUS_DELETE);
                settingsService.saveMObjectStaff(mObjectStaff);

                // Core update
                mobjectStaffId = mObjectStaff.getId(); // for update photo

            }

            // Core update
            coreMain.coreUpdater.updateMobjectStaffById(mobjectStaffId);

        }
        modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_STAFF_PROFILE + "?staff-id=" + staffId);

        return modelAndView;
    }

    @RequestMapping(value = URL_AJAX_SUBDIVISION_LIST)
    public ModelAndView ajaxSubdivisionList(
            @RequestParam(value = "company-id", defaultValue = "0", required = true) String companyIdStr
    ) {
        Long companyId = Converters.strToLong(companyIdStr, 0L);

        ModelAndView modelAndView = new ModelAndView(VIEW_AJAX_SUBDIVISION_LIST);

        List<CatalogSubdivision> catalogSubdivisionList = settingsService.getCatalogSubdivisionListByCompanyId(companyId);
        modelAndView.addObject("catalogSubdivisionList", catalogSubdivisionList);

        return modelAndView;
    }

    @RequestMapping(value = URL_SETTINGS_STAFF_DOWNLOAD_EXCEL, method = RequestMethod.GET)
    public void ajaxStaffExcel(
            HttpServletResponse response,
            @RequestParam(value = "contract-id", defaultValue = "0", required = false) String contractIdStr
    ) throws Exception {
        Long contractId = Converters.strToLong(contractIdStr, 0L);

        List<Staff> staffList = settingsService.getStaffByContractId(contractId);

        ExcelStaff excelStaffData = new ExcelStaff();
        excelStaffData.setDbList(staffList);
        excelStaffData.downloadXLS(response);

    }

}
