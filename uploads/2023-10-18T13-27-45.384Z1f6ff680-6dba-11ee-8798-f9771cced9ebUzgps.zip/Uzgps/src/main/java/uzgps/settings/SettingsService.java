package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.admin.AdminJournal;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.*;
import uzgps.rest.smpov2.users.dto.UserDTO;

import javax.persistence.*;
import javax.servlet.http.HttpSession;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by Zoxir on 25.01.14.
 */

@Service
@Component
public class SettingsService {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private AdminJournal adminJournal;

    @Transactional
    public ContractSettings saveContractSettings(ContractSettings contractSettings) {
        if (contractSettings.getId() != null)
            entityManager.merge(contractSettings);
        else
            entityManager.persist(contractSettings);

        return contractSettings;
    }

    //log
    @Transactional
    public MObjectSettings saveMObjectSettings(MObjectSettings mObjectSettings) {

        if (mObjectSettings.getId() != null) {
            entityManager.merge(mObjectSettings);
        } else {
            entityManager.persist(mObjectSettings);
        }

        return mObjectSettings;
    }

    //log
    @Transactional
    public MObject saveMObject(MObject mObject) {
        if (mObject.getId() != null) {
            entityManager.merge(mObject);
        } else {
            entityManager.persist(mObject);
        }

        return mObject;
    }

    //log
    @Transactional
    public GeoFence saveGeoFence(GeoFence geoFence) {
        if (geoFence.getId() != null) {
            entityManager.merge(geoFence);
        } else {
            entityManager.persist(geoFence);
        }

        return geoFence;
    }

    //log
    @Transactional
    public POI savePOI(POI poi) {
        if (poi.getId() != null) {
            entityManager.merge(poi);
        } else {
            entityManager.persist(poi);
        }

        return poi;
    }

    //log
    @Transactional
    public MobileTrackerSettings saveMobileTrackerSettings(MobileTrackerSettings mobileTrackerSettings) {
        if (mobileTrackerSettings.getId() != null) {
            entityManager.merge(mobileTrackerSettings);
        } else {
            entityManager.persist(mobileTrackerSettings);
        }

        return mobileTrackerSettings;
    }

    @Transactional
    public MobileTrackerStatus saveMobileTrackerStatus(MobileTrackerStatus mobileTrackerStatus) {
        if (mobileTrackerStatus.getId() != null) {
            entityManager.merge(mobileTrackerStatus);
        } else {
            entityManager.persist(mobileTrackerStatus);
        }

        return mobileTrackerStatus;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public ContractSettings getContractSettingsByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<ContractSettings> query;
            query = entityManager.createNamedQuery("ContractSettings.findByContractId", ContractSettings.class);
            query.setParameter("contractId", contractId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Group> getGroupsByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Group> query;
            query = entityManager.createNamedQuery("Group.findByContractId", Group.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getGroupCountByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("Group.findCountByContractId", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<ZoiGroup> getZoiGroupByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<ZoiGroup> query;
            query = entityManager.createNamedQuery("ZoiGroup.findByContractId", ZoiGroup.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<PoiGroup> getPoiGroupByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<PoiGroup> query;
            query = entityManager.createNamedQuery("PoiGroup.findByContractId", PoiGroup.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public void createMObjectPinByPinText(String pinText) {

        Query query;
        query = entityManager.createNativeQuery("SELECT public.uzgps_mobjectpin_add_with_innertext(:pintext)");
        query.setParameter("pintext", pinText);
        query.getSingleResult();


    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Group getGroupById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<Group> query;
            query = entityManager.createNamedQuery("Group.findById", Group.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public ZoiGroup getZoiGroupById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<ZoiGroup> query;
            query = entityManager.createNamedQuery("ZoiGroup.findById", ZoiGroup.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public PoiGroup getPoiGroupById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<PoiGroup> query;
            query = entityManager.createNamedQuery("PoiGroup.findById", PoiGroup.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectPins> getMObjectPinsId() {

        try {
            TypedQuery<MObjectPins> query;
            query = entityManager.createNamedQuery("MObjectPins.list", MObjectPins.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectPins getMObjectPinById(Long id) {

        try {
            TypedQuery<MObjectPins> query;
            query = entityManager.createNamedQuery("MObjectPins.findById", MObjectPins.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectPins> getPinBaseList() {
        try {
            TypedQuery<MObjectPins> query;
            query = entityManager.createNamedQuery("PinBase.list", MObjectPins.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("iconType", MObjectPins.ICON_TYPE_BASE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectPins> getPinMaskList(String iconBase) {
        try {
            TypedQuery<MObjectPins> query;
            query = entityManager.createNamedQuery("PinMask.list", MObjectPins.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("iconType", MObjectPins.ICON_TYPE_MASK);
            query.setParameter("iconBase", iconBase);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectPins> getPinListByText(String iconText) {
        try {
            TypedQuery<MObjectPins> query;
            query = entityManager.createNamedQuery("Pin.listByText", MObjectPins.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("iconType", MObjectPins.ICON_TYPE_TEXT);
            query.setParameter("text", iconText);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObject getObjectByObjectId(Long objectId) {
        if (objectId == null)
            return null;
        try {
            TypedQuery<MObject> query;
            query = entityManager.createNamedQuery("MObject.findByObjectId", MObject.class);
            query.setParameter("objectId", objectId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getObjectContractIdByObjectId(Long objectId) {
        if (objectId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("MObject.findMobjectContractId", Long.class);
            query.setParameter("objectId", objectId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObject> getObjectByContractIdAndGroupIdAndWithOutGroup(Long contractId, Long groupId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<MObject> query;
            query = entityManager.createNamedQuery("MObject.findByContractIdAndGroupIdAndWithOutGroup", MObject.class);
            query.setParameter("contractId", contractId);
            query.setParameter("groupId", groupId);
            query.setParameter("withOutGroupId", 0L);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObject> getObjectByContractIdAndGroupId(Long contractId, Long groupId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<MObject> query;
            query = entityManager.createNamedQuery("MObject.findByContractIdAndGroupId", MObject.class);
            query.setParameter("contractId", contractId);
            query.setParameter("groupId", groupId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<GeoFence> getZoiByContractIdAndGroupId(Long contractId, Long groupId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<GeoFence> query;
            query = entityManager.createNamedQuery("GeoFence.findByContractIdAndGroupId", GeoFence.class);
            query.setParameter("contractId", contractId);
            query.setParameter("groupId", groupId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<POI> getPoiByContractIdAndGroupId(Long contractId, Long groupId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<POI> query;
            query = entityManager.createNamedQuery("POI.findByContractIdAndGroupId", POI.class);
            query.setParameter("contractId", contractId);
            query.setParameter("groupId", groupId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectGPSUnit getObjectGPSUnitByObjectId(Long objectId) {
        if (objectId == null)
            return null;
        try {
            TypedQuery<MObjectGPSUnit> query;
            query = entityManager.createNamedQuery("MObjectGPSUnit.findByObjectId", MObjectGPSUnit.class);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectSettings getObjectSettingsByObjectId(Long objectId) {
        if (objectId == null)
            return null;
        try {
            TypedQuery<MObjectSettings> query;
            query = entityManager.createNamedQuery("MObjectSettings.findByObjectId", MObjectSettings.class);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectType> getObjectTypes() {
        try {
            TypedQuery<MObjectType> query;
            query = entityManager.createNamedQuery("MObjectType.findAll", MObjectType.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectType> getObjectTypesByContractId(Long contractId) {
        try {
            if (contractId != null) {

                String sqlQuery = "select umt.*, uc.id as contract_id from uzgps_mobject_type umt " +
                        "                        left join uzgps_contract uc on umt.uzgps_company_id = uc.company_id " +
                        "                        where (uc.id = ? or umt.uzgps_company_id IS NULL) and umt._status = ?";

                Query query = entityManager.createNativeQuery(sqlQuery, MObjectType.class);
                query.setParameter(1, contractId);
                query.setParameter(2, UZGPS_CONST.STATUS_ACTIVE);
                return query.getResultList();
            }
        } catch (NoResultException ignored) {
            return null;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectType getObjectTypeById(Long id) {
        try {
            TypedQuery<MObjectType> query;
            query = entityManager.createNamedQuery("MObjectType.findById", MObjectType.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectState> getObjectStates() {
        try {
            TypedQuery<MObjectState> query;
            query = entityManager.createNamedQuery("MObjectState.findAll", MObjectState.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectState getObjectStateById(Long id) {
        try {
            TypedQuery<MObjectState> query;
            query = entityManager.createNamedQuery("MObjectState.findById", MObjectState.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectAppointment> getObjectAppointments() {
        try {
            TypedQuery<MObjectAppointment> query;
            query = entityManager.createNamedQuery("MObjectAppointment.findAll", MObjectAppointment.class);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectAppointment> getObjectAppointmentsByContractId(Long contractId) {
        try {
            if (contractId != null) {

                String sqlQuery = "select uma.*, uc.id as contract_id from uzgps_mobject_appointment uma " +
                        "                        left join uzgps_contract uc on uma.uzgps_company_id = uc.company_id " +
                        "                        where (uc.id = ? or uma.uzgps_company_id IS NULL) and uma.status = ?";

                Query query = entityManager.createNativeQuery(sqlQuery, MObjectAppointment.class);
                query.setParameter(1, contractId);
                query.setParameter(2, UZGPS_CONST.STATUS_ACTIVE);
                return query.getResultList();
            }
        } catch (NoResultException ignored) {
            return null;
        }
        return null;
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectAppointment getObjectAppointmentById(Long id) {
        try {
            TypedQuery<MObjectAppointment> query;
            query = entityManager.createNamedQuery("MObjectAppointment.findById", MObjectAppointment.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MobileTrackerSettings getMobileTrackerSettingsByObjectId(Long objectId) {
        if (objectId == null)
            return null;
        try {
            TypedQuery<MobileTrackerSettings> query;
            query = entityManager.createNamedQuery("MobileTrackerSettings.findByObjectId", MobileTrackerSettings.class);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MobileTrackerSettings getMobileTrackerSettingsBySerial(String serial) {
        if (serial == null)
            return null;
        try {
            TypedQuery<MobileTrackerSettings> query;
            query = entityManager.createNamedQuery("MobileTrackerSettings.findBySerial", MobileTrackerSettings.class);
            query.setParameter("serial", serial);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MobileTrackerStatus getMobileTrackerStatusByIndexAndSerial(Integer index, String serial) {
        if (index == null || serial == null)
            return null;

        try {
            TypedQuery<MobileTrackerStatus> query;
            query = entityManager.createNamedQuery("MobileTrackerStatus.findByIndexAndSerial", MobileTrackerStatus.class);
            query.setParameter("index", index);
            query.setParameter("serial", serial);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MobileTrackerStatus getMobileTrackerStatusBySerial(String serial) {
        if (serial == null)
            return null;

        try {
            TypedQuery<MobileTrackerStatus> query;
            query = entityManager.createNamedQuery("MobileTrackerStatus.findBySerial", MobileTrackerStatus.class);
            query.setParameter("serial", serial);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public Group saveGroup(Group group) {
        if (group.getId() != null)
            entityManager.merge(group);
        else
            entityManager.persist(group);

        return group;
    }

    @Transactional
    public ZoiGroup saveZoIGroup(ZoiGroup zoiGroup) {
        if (zoiGroup.getId() != null)
            entityManager.merge(zoiGroup);
        else
            entityManager.persist(zoiGroup);

        return zoiGroup;
    }

    @Transactional
    public PoiGroup savePoIGroup(PoiGroup poiGroup) {
        if (poiGroup.getId() != null)
            entityManager.merge(poiGroup);
        else
            entityManager.persist(poiGroup);

        return poiGroup;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Staff> getStaffByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Staff> query;
            query = entityManager.createNamedQuery("Staff.findByContractId", Staff.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getStaffCountByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("Staff.findCountByContractId", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Staff> getStaffByContractIdAndHasMobject(Long contractId, boolean showOnlyWithMobjects) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Staff> query;
            query = entityManager.createNamedQuery("Staff.findByContractIdAndHasMobject", Staff.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("showOnlyWithMobjects", showOnlyWithMobjects);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getUsersCountByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("Staff.getUsersCountByContractId", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_USER);
            return (Long) query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Staff getStaffById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<Staff> query;
            query = entityManager.createNamedQuery("Staff.findById", Staff.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public Staff saveStaff(Staff staff) {
        if (staff.getId() != null)
            entityManager.merge(staff);
        else
            entityManager.persist(staff);

        return staff;
    }

    @Transactional
    public MObjectStaff saveMObjectStaff(MObjectStaff mObjectStaff) {
        if (mObjectStaff.getId() != null)
            entityManager.merge(mObjectStaff);
        else
            entityManager.persist(mObjectStaff);

        return mObjectStaff;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectStaff getObjectStaffById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<MObjectStaff> query;
            query = entityManager.createNamedQuery("MObjectStaff.findById", MObjectStaff.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    /**
     * @param mobjectId
     * @param dateFrom
     * @param dateTo
     * @return
     * @deprecated use {@link #getObjectStaffByDatesStaff(Long, Long, java.util.Date, java.util.Date)}
     */
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectStaff> getObjectStaffByDates(Long mobjectId, Timestamp dateFrom, Timestamp dateTo) {
        if (mobjectId == null)
            return null;
        if (dateFrom == null)
            return null;
        if (dateTo == null)
            return null;
        try {

            String sqlQuery = "SELECT * " +
                    " FROM uzgps_mobject_staff " +
                    " where so_status = ?4 " +
                    " and mobject_id = ?3" +
                    " and not ( " +
                    " (so_endless = true and (so_start_date > ?2  )) " +
                    " or (so_endless = false  and ( so_end_date < ?1 or so_start_date > ?2 )) " +
                    " ) " +
                    " order by so_start_date, so_end_date";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectStaff.class);
            Date dateFromDate = new Date(dateFrom.getTime());
            Date dateToDate = new Date(dateTo.getTime());

            q.setParameter(1, dateFromDate);
            q.setParameter(2, dateToDate);
            q.setParameter(3, mobjectId);
            q.setParameter(4, UZGPS_CONST.STATUS_ACTIVE);

            List<MObjectStaff> rows = q.getResultList();
            return rows;

        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectStaff> getObjectStaffByDatesStaff(Long mobjectId, Long staffId, java.util.Date dateFrom, java.util.Date dateTo) {
        if (mobjectId == null || staffId == null || dateFrom == null || dateTo == null)
            return null;
        try {

            String sqlQuery = "SELECT * " +
                    " FROM uzgps_mobject_staff " +
                    " where so_status = ?4 " +
                    " and (mobject_id = ?3 or staff_id = ?5)" +
                    " and not ( " +
                    " (so_endless = true and (so_start_date >= ?2  )) " +
                    " or (so_endless = false  and ( so_end_date < ?1 or so_start_date > ?2 )) " +
                    " ) " +
                    " order by so_start_date, so_end_date";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectStaff.class);

            q.setParameter(1, dateFrom);
            q.setParameter(2, dateTo);
            q.setParameter(3, mobjectId);
            q.setParameter(4, UZGPS_CONST.STATUS_ACTIVE);
            q.setParameter(5, staffId);

            return (List<MObjectStaff>) q.getResultList();

        } catch (NoResultException e) {
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectStaff> getObjectStaffByStartDate(Long mobjectId, Timestamp dateFrom) {
        if (mobjectId == null)
            return null;
        if (dateFrom == null)
            return null;
        try {

            String sqlQuery = "SELECT * " +
                    " FROM uzgps_mobject_staff " +
                    " where so_status = ?3 " +
                    " and mobject_id = ?2 " +
                    " and not (so_endless = false and (so_end_date < ?1)) " +
                    " order by so_start_date, so_end_date";

            Query q = entityManager.createNativeQuery(sqlQuery, MObjectStaff.class);
            Date dateFromDate = new Date(dateFrom.getTime());

            q.setParameter(1, dateFromDate);
            q.setParameter(2, mobjectId);
            q.setParameter(3, UZGPS_CONST.STATUS_ACTIVE);

            List<MObjectStaff> rows = q.getResultList();
            return rows;
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectStaff> getObjectStaffByStaffId(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<MObjectStaff> query;
            query = entityManager.createNamedQuery("MObjectStaff.findByStaffId", MObjectStaff.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getCustomerUsersByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByContractIdAndStatus", User.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getCustomerUsersCountByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("User.findCountByContractIdAndStatus", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getUsersByContractIdAndNotEqCurrentUserContractId(Long contractId, Long userContractId) {
        if (contractId == null || userContractId == null)
            return null;

        try {

            String sqlQuery = "select uu.* from uzgps_user_role ur " +
                    "inner join uzgps_user uu on uu.id = ur.user_id " +
                    "            where ur.status = 'A' " +
                    "            and " +
                    "            ur.contract_id = :contractId " +
                    "            and " +
                    "            (uu.contract_id = :contractId or uu.contract_id is null) " +
                    "            and " +
                    "            uu.u_status = :status " +
                    "            and " +
                    "            ur.role_id = 1 " +
                    "            and 0 = ( " +
                    "              select count(*) from uzgps_user_role uur " +
                    "                  where uur.contract_id = :userContractId " +
                    "                  and uur.user_id = uu.id " +
                    "                  and uur.status = 'A' " +
                    "              ) " +
                    "            order by uu.id";

            Query q = entityManager.createNativeQuery(sqlQuery, User.class);
            q.setParameter("contractId", contractId);
            q.setParameter("userContractId", userContractId);
            q.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return q.getResultList();

        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<UserDTO> getCustomerUsersModelByContractId(Long contractId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<UserDTO> query;
            query = entityManager.createNamedQuery("User.findByContractIdAndStatus", UserDTO.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getUsersByContractIdAndRole(Long contractId, Long roleId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findUserByContractIdAndRoleAndStatus", User.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("roleId", roleId);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Long> getFmsUsersIdByContractId(Long contractId) {
        if (contractId == null)
            return Collections.emptyList();
        try {
            String sqlQuery = "select ur.user_id  " +
                    " from public.uzgps_user_role ur  " +
                    "         inner join uzgps_user u on u.id = ur.user_id and u.u_status = 'A'  " +
                    "         inner join uzgps_user_access_list ual on ual.ual_user_id = u.id  " +
                    " where ur.contract_id = :contractId  " +
                    "  and ual.ual_contractid = :contractId  " +
                    "  and ual.ual_fms > 0  " +
                    "  and ur.role_id in (1, 2)  " +
                    "  and ur.status = 'A';";

            Query q = entityManager.createNativeQuery(sqlQuery);
            q.setParameter("contractId", contractId);

            return q.getResultList();
        } catch (NoResultException e) {
            return Collections.emptyList();
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getFmsUsersByContractId(Long contractId) {
        if (contractId == null)
            return Collections.emptyList();
        try {

            String sqlQuery = "select ur.user_id id, u.login," +
                    " trim(u.surname) \"surname\", trim(u.name) \"name\", trim(u.middlename) \"middlename\", password, " +
                    " u.role_id, api_token, auth_token, manager_id, profile_id, user_type_id, photo_id, " +
                    " ur.contract_id, last_logged_in, u_recovery_key, u_recovery_exp, u_block, u_login_attemp," +
                    " u_status, u_reg_date, u_mod_date, u_mod_date, u_exp_date, auth_token, sys_admin_note," +
                    " api_token, token_exp_date " +
                    " from public.uzgps_user_role ur  " +
                    "         inner join uzgps_user u on u.id = ur.user_id and u.u_status = 'A'  " +
                    "         inner join uzgps_user_access_list ual on ual.ual_user_id = u.id  " +
                    " where ur.contract_id = :contractId  " +
                    "  and ual.ual_contractid = :contractId   " +
                    "  and ual.ual_fms > 0  " +
                    "  and ur.role_id in (1, 2)  " +
                    "  and ur.status = 'A';";

            Query q = entityManager.createNativeQuery(sqlQuery, User.class);
            q.setParameter("contractId", contractId);

            return q.getResultList();
        } catch (NoResultException e) {
            return Collections.emptyList();
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getCustomerAdminByContractUserId(Long contractId, Long userId) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByContractUserIdAndStatusAndRoleId", User.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN);
            query.setParameter("userId", userId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }


    @Transactional
    public Profile saveProfile(Profile profile) {
        if (profile.getId() != null)
            entityManager.merge(profile);
        else
            entityManager.persist(profile);

        return profile;
    }

    @Transactional
    public User saveUser(User user) {
        if (user.getId() != null) {
            entityManager.merge(user);
        } else {
            entityManager.persist(user);
        }
        return user;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findById", User.class);
            query.setParameter("id", id);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_USER);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByUserId(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByUserId", User.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByIdAndContractId(Long id, Long contractId) {
        if (id == null || contractId == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByIdAndContractId", User.class);
            query.setParameter("id", id);
            query.setParameter("contractId", contractId);
            query.setParameter("roleId", UZGPS_CONST.USER_ROLE_USER);
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByIdAndPassword(Long id, String oldPassword) {
        if (id == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByIdAndPassword", User.class);
            query.setParameter("id", id);
            query.setParameter("oldPassword", oldPassword);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Contract getContractById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<Contract> query;
            query = entityManager.createNamedQuery("Contract.findById", Contract.class);
            query.setParameter("id", id);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public UserRole saveUseRole(UserRole userRole) {

        if (userRole.getId() != null) {
            entityManager.merge(userRole);
        } else {
            entityManager.persist(userRole);
        }

        return userRole;
    }

    @Transactional
    public UserRole findUserRoleByUserIdAndContractId(Long userId, Long contractId) {
        if (userId == null || contractId == null) {
            return null;
        }

        TypedQuery<UserRole> query = entityManager.createNamedQuery("UserRole.findByUserIdAndContractId", UserRole.class);
        query.setParameter("userId", userId);
        query.setParameter("contractId", contractId);
        query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);

        return query.getSingleResult();
    }

    @Transactional
    public UserAccessList saveUserAccessList(UserAccessList userAccessList) {
        if (userAccessList.getId() != null)
            entityManager.merge(userAccessList);
        else
            entityManager.persist(userAccessList);

        return userAccessList;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserAccessList getUserAccessListByUserId(Long userId) {
        if (userId == null)
            return null;
        try {
            TypedQuery<UserAccessList> query;
            query = entityManager.createNamedQuery("UserAccessList.findByUserId", UserAccessList.class);
            query.setParameter("userId", userId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserAccessList getUserAccessListByUserContractId(Long userId, Long contractId) {
        if (userId != null && contractId != null)
            try {
                TypedQuery<UserAccessList> query;
                query = entityManager.createNamedQuery("UserAccessList.findByUserContractId", UserAccessList.class);
                query.setParameter("userId", userId);
                query.setParameter("contractId", contractId);
                return query.getSingleResult();
            } catch (NoResultException e) {
                logger.error("Error in getUserAccessListByUserContractId", e.getCause());
            }
        return null;
    }


    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<UserMObjectAccessList> getUserMObjectAccessListByUserIdAndContractId(Long userId, long contractId) {
        if (userId == null)
            return null;
        try {

            String sqlQuery = "SELECT " +
                    "row_number() OVER () as id, " +
                    "coalesce(a.id,0) as aid, " +
                    "m.id as mobjectID, " +
                    "coalesce(a.user_id, ?1)  as  user_id, " +
                    "coalesce(a.permission, 0) as per, " +
                    "m.mo_name mobjectName " +
                    "FROM uzgps_user_mobject_access_list a " +
                    "Right Join uzgps_mobject m on  a.mobject_id = m.id and ( a.user_id = ?1 or a.user_id is null)  " +
                    "where " +
                    "m.mo_contract_id = ?2 " +
                    "and " +
                    "m.mo_status = ?3 " +
                    "order by m.mo_name";

            Query q = entityManager.createNativeQuery(sqlQuery, UserMObjectAccessListTemp.class);
            q.setParameter(1, userId);
            q.setParameter(2, contractId);
            q.setParameter(3, UZGPS_CONST.STATUS_ACTIVE);

            List<UserMObjectAccessListTemp> rows = q.getResultList();

            List<UserMObjectAccessList> userMObjectAccessLists = new ArrayList<>();

            for (UserMObjectAccessListTemp row : rows) {
                UserMObjectAccessList userMObjectAccessList = new UserMObjectAccessList();
                userMObjectAccessList.setId(row.getAid());

                MObject mObject = new MObject();
                mObject.setId(row.getMobjectID());
                mObject.setmObjectName("" + row.getMobjectName());

                userMObjectAccessList.setmObjectId(mObject.getId());
                userMObjectAccessList.setmObject(mObject);

                userMObjectAccessList.setUserId(row.getUser_id());
                userMObjectAccessList.setPermission(row.getPer());
                userMObjectAccessLists.add(userMObjectAccessList);
            }

            return userMObjectAccessLists;
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<UserPoiAccess> getUserPoiAccessListByUserIdAndContractId(Long userId, long contractId) {
        if (userId == null)
            return null;
        try {

            String sqlQuery = " SELECT row_number() OVER ()         as id, " +
                    "       coalesce(upal.id, 0)         as aid, " +
                    "       coalesce(upal.user_id, ?1)   as user_id, " +
                    "       p.id                         as poi_id, " +
                    "       p.name                          poi_name, " +
                    "       coalesce(upal.permission, 0) as permission " +
                    " FROM uzgps_user_poi_access upal " +
                    "         right Join uzgps_poi p on upal.poi_id = p.id and (upal.user_id = ?1 or upal.user_id is null) " +
                    " where p.contract_id = ?2 " +
                    " and p.status = ?3 " +
                    " order by p.name ";

            Query q = entityManager.createNativeQuery(sqlQuery, UserPoiAccessTemp.class);
            q.setParameter(1, userId);
            q.setParameter(2, contractId);
            q.setParameter(3, UZGPS_CONST.STATUS_ACTIVE);

            List<UserPoiAccessTemp> rows = q.getResultList();

            List<UserPoiAccess> userPoiAccesses = new ArrayList<>();

            for (UserPoiAccessTemp row : rows) {
                UserPoiAccess userPoiAccess = new UserPoiAccess();
                userPoiAccess.setId(row.getAid());

                POI poi = new POI();
                poi.setId(row.getPoi_id());
                poi.setName("" + row.getPoi_name());

                userPoiAccess.setPoiId(poi.getId());
                userPoiAccess.setPoi(poi);

                userPoiAccess.setUserId(row.getUser_id());
                userPoiAccess.setPermission(row.getPermission());

                userPoiAccesses.add(userPoiAccess);
            }

            return userPoiAccesses;
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<UserZoiAccess> getUserZoiAccessListByUserIdAndContractId(Long userId, long contractId) {
        if (userId == null)
            return null;
        try {

            String sqlQuery = " SELECT row_number() OVER ()         as id, " +
                    "       coalesce(uzal.id, 0)         as aid, " +
                    "       coalesce(uzal.user_id, ?1)   as user_id, " +
                    "       z.id                         as zoi_id, " +
                    "       z.name                          zoi_name, " +
                    "       coalesce(uzal.permission, 0) as permission " +
                    " FROM uzgps_user_zoi_access uzal " +
                    "         right Join uzgps_geo_fence z on uzal.zoi_id = z.id and (uzal.user_id = ?1 or uzal.user_id is null) " +
                    " where z.contract_id = ?2 " +
                    " and z.status = ?3 " +
                    " order by z.name ";

            Query q = entityManager.createNativeQuery(sqlQuery, UserZoiAccessTemp.class);
            q.setParameter(1, userId);
            q.setParameter(2, contractId);
            q.setParameter(3, UZGPS_CONST.STATUS_ACTIVE);

            List<UserZoiAccessTemp> rows = q.getResultList();

            List<UserZoiAccess> userZoiAccesses = new ArrayList<>();

            for (UserZoiAccessTemp row : rows) {
                UserZoiAccess userZoiAccess = new UserZoiAccess();
                userZoiAccess.setId(row.getAid());

                GeoFence zoi = new GeoFence();
                zoi.setId(row.getZoi_id());
                zoi.setName("" + row.getZoi_name());

                userZoiAccess.setZoiId(zoi.getId());
                userZoiAccess.setZoi(zoi);

                userZoiAccess.setUserId(row.getUser_id());
                userZoiAccess.setPermission(row.getPermission());

                userZoiAccesses.add(userZoiAccess);
            }

            return userZoiAccesses;
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserMObjectAccessList getUserMObjectAccessById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<UserMObjectAccessList> query;
            query = entityManager.createNamedQuery("UserMObjectAccessList.findByUserId", UserMObjectAccessList.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<UserMObjectAccessList> getUserMObjectAccessByMobjectId(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<UserMObjectAccessList> query;
            query = entityManager.createNamedQuery("UserMObjectAccessList.findByMobjectId", UserMObjectAccessList.class);
            query.setParameter("id", id);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserPoiAccess getUserPoiAccessById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<UserPoiAccess> query;
            query = entityManager.createNamedQuery("UserPoiAccess.findById", UserPoiAccess.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserPoiAccess getUserPoiAccessByUserIdAndPoiId(Long userId, Long poiId) {
        if (userId == null || poiId == null)
            return null;
        try {
            TypedQuery<UserPoiAccess> query;
            query = entityManager.createNamedQuery("UserPoiAccess.findByUserIdAndPoiId", UserPoiAccess.class);
            query.setParameter("userId", userId);
            query.setParameter("poiId", poiId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserZoiAccess getUserZoiAccessById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<UserZoiAccess> query;
            query = entityManager.createNamedQuery("UserZoiAccess.findById", UserZoiAccess.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public UserZoiAccess getUserZoiAccessByUserIdAndZoiId(Long userId, Long zoiId) {
        if (userId == null || zoiId == null)
            return null;
        try {
            TypedQuery<UserZoiAccess> query;
            query = entityManager.createNamedQuery("UserZoiAccess.findByUserIdAndZoiId", UserZoiAccess.class);
            query.setParameter("userId", userId);
            query.setParameter("zoiId", zoiId);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public UserMObjectAccessList saveUserMObjectAccess(UserMObjectAccessList userMObjectAccessList) {
        if (userMObjectAccessList.getId() != null)
            entityManager.merge(userMObjectAccessList);
        else
            entityManager.persist(userMObjectAccessList);

        return userMObjectAccessList;
    }

    @Transactional
    public UserPoiAccess saveUserPoiAccess(UserPoiAccess userPoiAccess) {
        if (userPoiAccess.getId() != null)
            entityManager.merge(userPoiAccess);
        else
            entityManager.persist(userPoiAccess);

        return userPoiAccess;
    }

    @Transactional
    public UserZoiAccess saveUserZoiAccess(UserZoiAccess userZoiAccess) {
        if (userZoiAccess.getId() != null)
            entityManager.merge(userZoiAccess);
        else
            entityManager.persist(userZoiAccess);

        return userZoiAccess;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectNotifications getMObjectNotificationsByObjectId(Long mobjectId) {
        if (mobjectId == null)
            return null;
        try {
            TypedQuery<MObjectNotifications> query;
            query = entityManager.createNamedQuery("MObjectNotifications.findByMObjectId", MObjectNotifications.class);
            query.setParameter("mobjectId", mobjectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);

            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public MObjectNotifications savemMObjectNotifications(MObjectNotifications mObjectNotifications) {
        if (mObjectNotifications.getId() != null)
            entityManager.merge(mObjectNotifications);
        else
            entityManager.persist(mObjectNotifications);

        return mObjectNotifications;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<GeoFence> getGeoFenceByContractIdAndStatus(Long contractId, String status) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<GeoFence> query;
            query = entityManager.createNamedQuery("GeoFence.getListByContractIdAndStatus", GeoFence.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<GeoFence> getGeoFenceByContractIdAndFilter(Long contractId, String filterText, int pageNumber) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<GeoFence> query;
            query = entityManager.createNamedQuery("GeoFence.getListByContractIdAndFilter", GeoFence.class);
            query.setParameter("contractId", contractId);
            query.setParameter("filterText", "%" + filterText + "%");

            query.setMaxResults(UZGPS_CONST.LIST_PER_PAGE);
            query.setFirstResult(UZGPS_CONST.LIST_PER_PAGE * pageNumber);

            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getGeoFenceByContractIdAndFilterCount(Long contractId, String filterText) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("GeoFence.getListByContractIdAndFilterCount", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("filterText", "%" + filterText + "%");
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public GeoFence getGeoFenceById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<GeoFence> query;
            query = entityManager.createNamedQuery("GeoFence.findById", GeoFence.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public MObjectGeoFence saveMObjectGeoFence(MObjectGeoFence mObjectGeoFence) {
        if (mObjectGeoFence.getId() != null)
            entityManager.merge(mObjectGeoFence);
        else
            entityManager.persist(mObjectGeoFence);

        return mObjectGeoFence;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectGeoFence getMObjectGeoFenceById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<MObjectGeoFence> query;
            query = entityManager.createNamedQuery("MObjectGeoFence.findById", MObjectGeoFence.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectGeoFence> getMObjectGeoFenceByObjectId(Long objectId) {
        if (objectId == null)
            return null;
        try {
            TypedQuery<MObjectGeoFence> query;
            query = entityManager.createNamedQuery("MObjectGeoFence.getListByContractId", MObjectGeoFence.class);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectGeoFence getMObjectGeoFenceByGeoFenceIdAndControlTypeAndObjectId(Long geoFenceId, Integer controlType, Long objectId) {
        if (geoFenceId == null || controlType == null || objectId == null)
            return null;
        try {
            TypedQuery<MObjectGeoFence> query;
            query = entityManager.createNamedQuery("MObjectGeoFence.findByPoIIdAndControlTypeAndObjectId", MObjectGeoFence.class);
            query.setParameter("geoFenceId", geoFenceId);
            query.setParameter("controlType", controlType);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectGeoFence getMObjectGeoFenceByGeoFenceIdAndObjectId(Long geoFenceId, Long objectId) {
        if (geoFenceId == null || objectId == null)
            return null;
        try {
            TypedQuery<MObjectGeoFence> query;
            query = entityManager.createNamedQuery("MObjectGeoFence.findByGeoFenceIdAndObjectId", MObjectGeoFence.class);
            query.setParameter("geoFenceId", geoFenceId);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectGeoFence> getMObjectGeoFenceListByGeoFenceId(Long geoFenceId) {
        if (geoFenceId == null)
            return null;
        try {
            TypedQuery<MObjectGeoFence> query;
            query = entityManager.createNamedQuery("MObjectGeoFence.findByGeoFenceId", MObjectGeoFence.class);
            query.setParameter("geoFenceId", geoFenceId);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public void updateUserMObjectAccessList(Long userId) {
        if (userId != null) {
            Query query;
            query = entityManager.createNamedQuery("UserMObjectAccessList.updatePermission");
            query.setParameter("userId", userId);
            query.executeUpdate();
        }
    }

    @Transactional
    public void updateUserPoiAccess(Long userId) {
        if (userId != null) {
            Query query;
            query = entityManager.createNamedQuery("UserPoiAccess.updatePermission");
            query.setParameter("userId", userId);
            query.executeUpdate();
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<POI> getPOIByContractIdAndStatus(Long contractId, String status, int pageNumber) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<POI> query;
            query = entityManager.createNamedQuery("POI.getListByContractIdAndStatus", POI.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            query.setMaxResults(UZGPS_CONST.LIST_PER_PAGE);
            query.setFirstResult(UZGPS_CONST.LIST_PER_PAGE * pageNumber);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getPOIByContractIdAndStatusCount(Long contractId, String status) {
        if (contractId == null)
            return null;
        try {
            TypedQuery<Long> query;
            query = entityManager.createNamedQuery("POI.getListByContractIdAndStatusCount", Long.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", status);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public POI getPOIById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<POI> query;
            query = entityManager.createNamedQuery("POI.findById", POI.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional
    public MObjectPoI saveMObjectPoI(MObjectPoI mObjectPoI) {
        if (mObjectPoI.getId() != null)
            entityManager.merge(mObjectPoI);
        else
            entityManager.persist(mObjectPoI);

        return mObjectPoI;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectPoI getMObjectPoIById(Long id) {
        if (id == null)
            return null;
        try {
            TypedQuery<MObjectPoI> query;
            query = entityManager.createNamedQuery("MObjectPoI.findById", MObjectPoI.class);
            query.setParameter("id", id);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectPoI> getMObjectPoIByObjectId(Long objectId) {
        if (objectId == null)
            return null;
        try {
            TypedQuery<MObjectPoI> query;
            query = entityManager.createNamedQuery("MObjectPoI.getListByContractId", MObjectPoI.class);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectPoI getMObjectPoIByPoIIdAndControlTypeAndObjectId(Long poiId, Integer controlType, Long objectId) {
        if (poiId == null || controlType == null || objectId == null)
            return null;
        try {
            TypedQuery<MObjectPoI> query;
            query = entityManager.createNamedQuery("MObjectPoI.findByPoIIdAndControlTypeAndObjectId", MObjectPoI.class);
            query.setParameter("poiId", poiId);
            query.setParameter("controlType", controlType);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public MObjectPoI getMObjectPoIByPoIIdAndObjectId(Long poiId, Long objectId) {
        if (poiId == null || objectId == null)
            return null;
        try {
            TypedQuery<MObjectPoI> query;
            query = entityManager.createNamedQuery("MObjectPoI.findByPoIIdAndObjectId", MObjectPoI.class);
            query.setParameter("poiId", poiId);
            query.setParameter("objectId", objectId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<MObjectPoI> getMObjectPoIListByPoIId(Long poiId) {
        if (poiId == null)
            return null;
        try {
            TypedQuery<MObjectPoI> query;
            query = entityManager.createNamedQuery("MObjectPoI.findByPoIId", MObjectPoI.class);
            query.setParameter("poiId", poiId);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByLogin(String login) {
        if (login == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByLogin", User.class);
            query.setParameter("login", login);
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public User getUserByToken(String token) {
        if (token == null)
            return null;
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByToken", User.class);
            query.setParameter("token", token);
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

//    @SuppressWarnings("unchecked")
//    @Transactional(readOnly = true)
//    public List<NotificationConnector> getObjectPoI(HttpSession session, Long mObjectId, int pageNumber) {
//        if (mObjectId == null)
//            return null;
//        try {
//
//            String sqlQuery = "SELECT row_number() OVER () as id, m.id as cid, p.name as cname, p.id as cobj2id, control_type as ctype " +
//                    " FROM uzgps_mobject_poi m " +
//                    " right join uzgps_poi p on m.poi_id = p.id and m.mobject_id=? " +
//                    " where ( m.mp_status = 'A' or m.mp_status is null ) " +
//                    " and p.status = 'A' " +
//                    " and contract_id = ? " +
//                    " order by p.name";
//
//            Query q = entityManager.createNativeQuery(sqlQuery, NotificationConnector.class);
//            q.setParameter(1, mObjectId);
//            q.setParameter(2, MainController.getUserContractId(session));
//            q.setMaxResults(UZGPS_CONST.LIST_PER_PAGE);
//            q.setFirstResult(UZGPS_CONST.LIST_PER_PAGE * pageNumber);
//
//            return q.getResultList();
//
//        } catch (NoResultException e) {
//            return null;
//        }
//    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<NotificationConnector> getObjectPoI(HttpSession session, Long mObjectId) {
        if (mObjectId == null)
            return null;
        try {

            String sqlQuery = "SELECT row_number() OVER () as id, m.id as cid, p.name as cname, p.id as cobj2id, control_type as ctype " +
                    " FROM uzgps_mobject_poi m " +
                    " right join uzgps_poi p on m.poi_id = p.id and m.mobject_id=? " +
                    " where ( m.mp_status = 'A' or m.mp_status is null ) " +
                    " and p.status = 'A' " +
                    " and contract_id = ? " +
                    " order by p.name";

            Query q = entityManager.createNativeQuery(sqlQuery, NotificationConnector.class);
            q.setParameter(1, mObjectId);
            q.setParameter(2, MainController.getUserContractId(session));

            return q.getResultList();

        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getObjectPoICount(HttpSession session, Long mObjectId) {
        if (mObjectId == null)
            return null;
        try {
            long countRow = 0L;

            String sqlQuery = "SELECT count(*) " +
                    " FROM uzgps_mobject_poi m " +
                    " right join uzgps_poi p on m.poi_id = p.id and m.mobject_id=? " +
                    " where ( m.mp_status = 'A' or m.mp_status is null ) " +
                    " and p.status = 'A' " +
                    " and contract_id = ? ";

            Query q = entityManager.createNativeQuery(sqlQuery);
            q.setParameter(1, mObjectId);
            q.setParameter(2, MainController.getUserContractId(session));

            countRow = Long.parseLong(q.getSingleResult().toString());

            return countRow;

        } catch (NoResultException e) {
            return null;
        }
    }

    //    @SuppressWarnings("unchecked")
//    @Transactional(readOnly = true)
//    public List<NotificationConnector> getObjectZone(HttpSession session, Long mObjectId, int pageNumber) {
//        if (mObjectId == null)
//            return null;
//        try {
//            String sqlQuery = "SELECT row_number() OVER () as id, m.id as cid, p.name as cname, p.id as cobj2id, control_type as ctype " +
//                    "  FROM  uzgps_mobject_geo_fence m " +
//                    " right join uzgps_geo_fence p on m.geo_fence_id = p.id and m.mobject_id=? " +
//                    " where ( m.mgf_status = 'A' or m.mgf_status is null ) " +
//                    "   and p.status = 'A' " +
//                    "   and contract_id = ? " +
//                    " order by p.name";
//
//            Query q = entityManager.createNativeQuery(sqlQuery, NotificationConnector.class);
//            q.setParameter(1, mObjectId);
//            q.setParameter(2, MainController.getUserContractId(session));
//            q.setMaxResults(UZGPS_CONST.LIST_PER_PAGE);
//            q.setFirstResult(UZGPS_CONST.LIST_PER_PAGE * pageNumber);
//
//            return q.getResultList();
//
//        } catch (NoResultException e) {
//            return null;
//        }
//    }
//

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<NotificationConnector> getObjectZone(HttpSession session, Long mObjectId) {
        if (mObjectId == null)
            return null;
        try {
            String sqlQuery = "SELECT row_number() OVER () as id, m.id as cid, p.name as cname, p.id as cobj2id, control_type as ctype " +
                    "  FROM  uzgps_mobject_geo_fence m " +
                    " right join uzgps_geo_fence p on m.geo_fence_id = p.id and m.mobject_id=? " +
                    " where ( m.mgf_status = 'A' or m.mgf_status is null ) " +
                    "   and p.status = 'A' " +
                    "   and contract_id = ? " +
                    " order by p.name";

            Query q = entityManager.createNativeQuery(sqlQuery, NotificationConnector.class);
            q.setParameter(1, mObjectId);
            q.setParameter(2, MainController.getUserContractId(session));
//            q.setMaxResults(UZGPS_CONST.LIST_PER_PAGE);
//            q.setFirstResult(UZGPS_CONST.LIST_PER_PAGE * pageNumber);

            return q.getResultList();

        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public Long getObjectZoneCount(HttpSession session, Long mObjectId) {
        if (mObjectId == null)
            return null;
        try {
            long countRow = 0;

            String sqlQuery = "SELECT count(*) " +
                    "  FROM  uzgps_mobject_geo_fence m " +
                    " right join uzgps_geo_fence p on m.geo_fence_id = p.id and m.mobject_id=? " +
                    " where ( m.mgf_status = 'A' or m.mgf_status is null ) " +
                    "   and p.status = 'A' " +
                    "   and contract_id = ?";

            Query q = entityManager.createNativeQuery(sqlQuery);
            q.setParameter(1, mObjectId);
            q.setParameter(2, MainController.getUserContractId(session));

            countRow = Long.parseLong(q.getSingleResult().toString());

            return countRow;
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<NotificationConnector> getPoIObject(HttpSession session, Long nPoiId, boolean isShowSuspendedObjects) {
        if (nPoiId == null)
            return null;
        try {

            String sqlQuery = "SELECT row_number() OVER () as id, mp.id as cid, m.mo_name as cname, m.id as cobj2id, control_type as ctype " +
                    "FROM uzgps_mobject_poi mp " +
                    "         right join uzgps_mobject m on m.id = mp.mobject_id and mp.poi_id = ? " +
                    "         JOIN public.uzgps_mobject_gps_units mgu " +
                    "              ON mgu.mogu_mobject_id = m.id AND mgu.mogu_status = 'A' " +
                    "         JOIN public.uzgps_gps_unit gu " +
                    "              ON gu.id = mgu.mogu_gps_unit_id AND gu.gu_status = 'A' " +
                    "where m.mo_status = 'A' " +
                    "  and (mp.mp_status = 'A' or mp.mp_status is null) " +
                    "  and m.mo_contract_id = ? " +
                    "  AND (case " +
                    "           when ? = false then gu.gu_block = 'A' " +
                    "           else gu.gu_block is not null " +
                    "    end) " +
                    "order by m.mo_name; ";

            Query q = entityManager.createNativeQuery(sqlQuery, NotificationConnector.class);
            q.setParameter(1, nPoiId);
            q.setParameter(2, MainController.getUserContractId(session));
            q.setParameter(3, isShowSuspendedObjects);
            return q.getResultList();

        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<NotificationConnector> getZoneObject(HttpSession session, Long nPoiId, boolean isShowSuspendedObjects) {
        if (nPoiId == null)
            return null;
        try {

            String sqlQuery = " SELECT row_number() OVER () as id, mg.id as cid, m.mo_name as cname, m.id as cobj2id, control_type as ctype " +
                    "FROM uzgps_mobject_geo_fence mg " +
                    "         right join uzgps_mobject m on mg.mobject_id = m.id and mg.geo_fence_id = ? " +
                    "         JOIN public.uzgps_mobject_gps_units mgu " +
                    "              ON mgu.mogu_mobject_id = m.id AND mgu.mogu_status = 'A' " +
                    "         JOIN public.uzgps_gps_unit gu " +
                    "              ON gu.id = mgu.mogu_gps_unit_id AND gu.gu_status = 'A' " +
                    "where m.mo_status = 'A' " +
                    "  and (mg.mgf_status = 'A' or mg.mgf_status is null) " +
                    "  and m.mo_contract_id = ? " +
                    "  AND (case " +
                    "           when ? = false then gu.gu_block = 'A' " +
                    "           else gu.gu_block is not null " +
                    "    end) " +
                    "order by m.mo_name; ";

            Query q = entityManager.createNativeQuery(sqlQuery, NotificationConnector.class);
            q.setParameter(1, nPoiId);
            q.setParameter(2, MainController.getUserContractId(session));
            q.setParameter(3, isShowSuspendedObjects);

            return q.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    //log
    @Transactional
    public GPSUnit saveGPSUnit(GPSUnit gpsUnit) {
        if (gpsUnit.getId() != null) {
            entityManager.merge(gpsUnit);
        } else {
            entityManager.persist(gpsUnit);
        }
        return gpsUnit;
    }

    public List<Staff> getStaffByContractIdAndText(Long userContractId, String txtSearch, boolean showOnlyWithMobjects) {
        if (userContractId == null)
            return null;

        if (txtSearch == null || txtSearch.trim().length() == 0) {
            return getStaffByContractIdAndHasMobject(userContractId, showOnlyWithMobjects);
        }

        String searchText = txtSearch.trim();
        String[] words = searchText.split(" ");
        String[] wordSelected = new String[3];
        String text1 = "";
        String text2 = "";
        String text3 = "";

        int h = 0;
        for (String s : words) {
            if (s != null) {
                s = s.trim();
                if (s.length() > 2 && h < 3) {
                    wordSelected[h] = s;
                    h++;
                }
            }
        }

        if (h == 1) {
            text1 = wordSelected[0];
            try {
                TypedQuery<Staff> query;
                query = entityManager.createNamedQuery("Staff.findByContractIdAndText1", Staff.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                query.setParameter("showOnlyWithMobjects", showOnlyWithMobjects);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        if (h == 2) {
            text1 = wordSelected[0];
            text2 = wordSelected[1];
            try {
                TypedQuery<Staff> query;
                query = entityManager.createNamedQuery("Staff.findByContractIdAndText2", Staff.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                query.setParameter("text2", text2);
                query.setParameter("showOnlyWithMobjects", showOnlyWithMobjects);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        if (h >= 3) {
            text1 = wordSelected[0];
            text2 = wordSelected[1];
            text3 = wordSelected[2];

            try {
                TypedQuery<Staff> query;
                query = entityManager.createNamedQuery("Staff.findByContractIdAndText", Staff.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                query.setParameter("text2", text2);
                query.setParameter("text3", text3);
                query.setParameter("showOnlyWithMobjects", showOnlyWithMobjects);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        return null;
    }

    public List<User> getCustomerUsersByContractIdAndText(Long userContractId, String textSearch) {
        if (userContractId == null)
            return null;

        if (textSearch == null || textSearch.trim().length() == 0) {
            return getCustomerUsersByContractId(userContractId);
        }

        String searchText = textSearch.trim();
        String[] words = searchText.split(" ");
        String[] wordSelected = new String[3];
        String text1 = "";
        String text2 = "";
        String text3 = "";

        int h = 0;
        for (String s : words) {
            if (s != null) {
                s = s.trim();
                if (s.length() > 2 && h < 3) {
                    wordSelected[h] = s;
                    h++;
                }
            }
        }

        if (h == 1) {
            text1 = wordSelected[0];
            try {
                TypedQuery<User> query;
                query = entityManager.createNamedQuery("User.findUsersByContractIdAndText1", User.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        if (h == 2) {
            text1 = wordSelected[0];
            text2 = wordSelected[1];
            try {
                TypedQuery<User> query;
                query = entityManager.createNamedQuery("User.findUsersByContractIdAndText2", User.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                query.setParameter("text2", text2);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        if (h >= 3) {
            text1 = wordSelected[0];
            text2 = wordSelected[1];
            text3 = wordSelected[2];

            try {
                TypedQuery<User> query;
                query = entityManager.createNamedQuery("User.findUsersByContractIdAndText", User.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                query.setParameter("text2", text2);
                query.setParameter("text3", text3);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        return null;

    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getThirdPartyUsersByContractIdAndText(Long userContractId, String textSearch) {
        if (userContractId == null)
            return null;

        if (textSearch == null || textSearch.trim().length() == 0) {
            return getThirdPartyUsersByContractId(userContractId);
        }

        String searchText = textSearch.trim();
        String[] words = searchText.split(" ");
        String[] wordSelected = new String[3];
        String text1 = "";
        String text2 = "";
        String text3 = "";

        int h = 0;
        for (String s : words) {
            if (s != null) {
                s = s.trim();
                if (s.length() > 2 && h < 3) {
                    wordSelected[h] = s;
                    h++;
                }
            }
        }

        if (h == 1) {
            text1 = wordSelected[0];
            try {
                TypedQuery<User> query;
                query = entityManager.createNamedQuery("User.findThirdPartyUsersByContractIdAndText1", User.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        if (h == 2) {
            text1 = wordSelected[0];
            text2 = wordSelected[1];
            try {
                TypedQuery<User> query;
                query = entityManager.createNamedQuery("User.findThirdPartyUsersByContractIdAndText2", User.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                query.setParameter("text2", text2);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        if (h >= 3) {
            text1 = wordSelected[0];
            text2 = wordSelected[1];
            text3 = wordSelected[2];

            try {
                TypedQuery<User> query;
                query = entityManager.createNamedQuery("User.findThirdPartyUsersByContractIdAndText3", User.class);
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                query.setParameter("text1", text1);
                query.setParameter("text2", text2);
                query.setParameter("text3", text3);
                return query.getResultList();
            } catch (NoResultException e) {
                return null;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getThirdPartyUsersByContractId(Long contractId) {
        if (contractId == null)
            return null;

        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findThirdPartyUsersByContractId", User.class);
            query.setParameter("contractId", contractId);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<Contract> getUserContractsByUserId(Long userId) {
        if (userId == null)
            return null;
        try {
            TypedQuery<Contract> query;
            query = entityManager.createNamedQuery("Contract.getUserContractsByUserId", Contract.class);
            query.setParameter("userId", userId);
            return query.getResultList();
        } catch (NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<User> getUsersByContractIdList(List<Long> userContractIds, Long currentUserContractId) {
        if (userContractIds == null)
            return null;

        List<User> usersList = new ArrayList<>();

        for (Long contractId : userContractIds) {
            List<User> users = getUsersByContractIdAndNotEqCurrentUserContractId(contractId, currentUserContractId);

            if (users != null && users.size() > 0) {
                usersList.addAll(users);
            }
        }

        return usersList;
    }

    @Transactional
    public void disableTgUsersByApiToken(String apiToken) {
        if (apiToken != null) {
            Query query;
            query = entityManager.createNamedQuery("TgUser.updateStatusByApiToken");
            query.setParameter("apiToken", apiToken);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            query.executeUpdate();
        }
    }

    @Transactional
    public List<User> getUserByContractIdAndApiTokenNotNull(Long userContractId) {
        try {
            if (userContractId != null) {
                Query query;
                query = entityManager.createNamedQuery("User.findUsersByContractIdAndApiTokenNotNull");
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                return query.getResultList();
            }
        } catch (NoResultException ignored) {
            return null;
        }
        return null;
    }

    @Transactional
    public List<User> getUserByContractIdAndApiTokenEqNull(Long userContractId) {
        try {
            if (userContractId != null) {
                Query query;
                query = entityManager.createNamedQuery("User.findUsersByContractIdAndApiTokenEqNull");
                query.setParameter("contractId", userContractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                return query.getResultList();
            }
        } catch (NoResultException ignored) {
            return null;
        }
        return null;
    }

    @Transactional
    public List<MonitoredZoi> getMonitoredZoiByContractId(Long contractId) {
        try {
            if (contractId != null) {
                TypedQuery<MonitoredZoi> query;
                query = entityManager.createNamedQuery("MonitoredZoi.findByContractId", MonitoredZoi.class);
                query.setParameter("contractId", contractId);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                return query.getResultList();
            }
        } catch (NoResultException ignored) {
            return null;
        }
        return null;
    }

    @Transactional
    public void deleteMonitoredZoiById(Long id) {
        try {
            if (id != null) {
                Query query;
                query = entityManager.createNamedQuery("MonitoredZoi.deleteById");
                query.setParameter("id", id);
                query.executeUpdate();
            }
        } catch (Exception ex) {
            logger.error("Error in MonitoredZoiById", ex);
        }

    }

    @Transactional
    public MonitoredZoi saveMonitoredZoi(MonitoredZoi monitoredZoi) {
        if (monitoredZoi.getId() != null) {
            entityManager.merge(monitoredZoi);
        } else {
            entityManager.persist(monitoredZoi);
        }
        return monitoredZoi;
    }

    @Transactional
    public List<CatalogCompany> getCatalogCompanyByContractId(Long contractId) {
        try {
            if (contractId != null) {

                String sqlQuery = "select bcc.* from billing_catalog_company bcc " +
                        "inner join uzgps_company uc on uc.id = bcc.uzgps_company_id " +
                        "inner join uzgps_contract u on uc.id = u.company_id " +
                        "where u.id = ? and bcc._status = ?";

                Query query = entityManager.createNativeQuery(sqlQuery, CatalogCompany.class);
                query.setParameter(1, contractId);
                query.setParameter(2, UZGPS_CONST.STATUS_ACTIVE);
                return query.getResultList();
            }
        } catch (NoResultException ignored) {
            return null;
        }
        return null;
    }

    @Transactional
    public List<CatalogSubdivision> getCatalogSubdivisionListByCompanyId(Long id) {
        try {
            if (id != null) {
                Query query;
                query = entityManager.createNamedQuery("CatalogSubdivision.findByCompanyId");
                query.setParameter("catalogCompanyId", id);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);

                return query.getResultList();
            }
        } catch (Exception ex) {
            logger.error("Error in getCatalogSubdivisionListByCompanyId", ex);
        }

        return null;
    }

    @Transactional
    public CatalogSubdivision getCatalogSubdivisionById(Long id) {
        try {
            if (id != null) {
                TypedQuery<CatalogSubdivision> query;
                query = entityManager.createNamedQuery("CatalogSubdivision.getById", CatalogSubdivision.class);
                query.setParameter("id", id);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                return query.getSingleResult();
            }
        } catch (Exception ex) {
            logger.error("Error in getCatalogSubdivisionById", ex);
        }

        return null;
    }

    @Transactional
    public CatalogCompany getCatalogCompanyById(Long id) {
        try {
            if (id != null) {
                TypedQuery<CatalogCompany> query;
                query = entityManager.createNamedQuery("CatalogCompany.getById", CatalogCompany.class);
                query.setParameter("id", id);
                query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
                return query.getSingleResult();
            }
        } catch (Exception ex) {
            logger.error("Error in getCatalogSubdivisionById", ex);
        }

        return null;
    }

}

