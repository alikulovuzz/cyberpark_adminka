package uzgps.settings;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminService;
import uzgps.main.MainController;
import uzgps.persistence.Group;
import uzgps.persistence.Staff;
import uzgps.persistence.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

/**
 * Created by G'ayrat on 10.12.14.
 */


@Controller
public class SettingsMobilePropertiesController extends AbstractSettingsController {

    @Autowired
    CoreMain coreMain;

    @Autowired
    AdminService adminService;

    @Autowired
    SettingsService settingsService;

    private static final String URL_SETTING_PROPERITES_MOBILE = "/settings/properties-mobile.htm";
    private static final String VIEW_SETTINGS_MOBILE_PROPERITES = "settings/settings-properties-mobile";


    @RequestMapping(value = URL_SETTING_PROPERITES_MOBILE)
    public ModelAndView getMobileProperetspage(HttpSession session,
                                               @RequestParam(value = "errorCode", required = false) String errorCode)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_SETTINGS_MOBILE_PROPERITES);


        long userMaxCount = 0;
        long mobjectMaxCount = 0;
        long staffMaxCount = 0;

        modelAndView.addObject("userMaxCount", userMaxCount);
        modelAndView.addObject("mobjectMaxCount", mobjectMaxCount);
        modelAndView.addObject("staffMaxCount", staffMaxCount);
        modelAndView.addObject("errorCode", errorCode);
//        modelAndView.addObject("poiMaxCount", poiMaxCount);
//        modelAndView.addObject("zoiMaxCount", zoiMaxCount);

        modelAndView.addObject("userId", "0");
//        modelAndView.addObject("errorNumber", errorCode);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        return modelAndView;
    }
}
