package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminService;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.*;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.util.*;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsMonitoringController extends AbstractSettingsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_MONITORING = "/settings/monitoring.htm";
    private final static String VIEW_SETTINGS_MONITORING = "settings/settings-monitoring";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    AdminService adminService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTINGS_MONITORING)
    public ModelAndView processSettingsMap(HttpSession session,
                                           @RequestParam(value = "cmd", required = false) String cmd,
                                           @RequestParam(value = "object-status-view", defaultValue = "false") Boolean objectStatusView,
                                           @RequestParam(value = "object-status-position", required = false) Integer objectStatusPosition,
                                           @RequestParam(value = "ignition-sensor-view", defaultValue = "false") Boolean ignitionSensorView,
                                           @RequestParam(value = "ignition-sensor-position", required = false) Integer ignitionSensorPosition,
                                           @RequestParam(value = "object-link-view", defaultValue = "false") Boolean objectLinkView,
                                           @RequestParam(value = "object-link-position", required = false) Integer objectLinkPosition,
                                           @RequestParam(value = "satellite-visibility-view", defaultValue = "false") Boolean satelliteVisibilityView,
                                           @RequestParam(value = "satellite-visibility-position", required = false) Integer satelliteVisibilityPosition,
                                           @RequestParam(value = "object-driver-view", defaultValue = "false") Boolean objectDriverView,
                                           @RequestParam(value = "object-driver-position", required = false) Integer objectDriverPosition,
                                           @RequestParam(value = "sensor-state-view", defaultValue = "false") Boolean sensorStateView,
                                           @RequestParam(value = "sensor-state-position", required = false) Integer sensorStatePosition,
                                           @RequestParam(value = "object-massage-view", defaultValue = "false") Boolean objectMassageView,
                                           @RequestParam(value = "object-massage-position", required = false) Integer objectMassagePosition,
                                           @RequestParam(value = "build-track-view", defaultValue = "false") Boolean buildTrackView,
                                           @RequestParam(value = "build-track-position", required = false) Integer buildTrackPosition,
                                           @RequestParam(value = "report-view", defaultValue = "false") Boolean reportView,
                                           @RequestParam(value = "report-position", required = false) Integer reportPosition,
                                           @RequestParam(value = "sms-send-view", defaultValue = "false") Boolean smsSendView,
                                           @RequestParam(value = "sms-send-position", required = false) Integer smsSendPosition,
                                           @RequestParam(value = "object-properties-view", defaultValue = "false") Boolean objectPropertiesView,
                                           @RequestParam(value = "object-properties-position", required = false) Integer objectPropertiesPosition,
                                           @RequestParam(value = "bak-status-view", defaultValue = "false") Boolean bakStatusPositionView,
                                           @RequestParam(value = "bak-status-position", required = false) Integer bakStatusPosition,
                                           @RequestParam(value = "epv-object-view", defaultValue = "false") Boolean evpObjectPositionView,
                                           @RequestParam(value = "epv-object-position", required = false) Integer evpObjectPosition,
                                           @RequestParam(value = "obj-battery-view", defaultValue = "false") Boolean objBatteryPositionView,
                                           @RequestParam(value = "obj-battery-position", required = false) Integer objBatteryPosition,
                                           @RequestParam(value = "last-msg-time-view", defaultValue = "false") Boolean lastMsgTimeView,
                                           @RequestParam(value = "last-msg-time-position", required = false) Integer lastMsgTimePosition,

                                           @RequestParam(value = "fast-track-type", required = false) Long fastTrackType,
                                           @RequestParam(value = "fast-track-value1", required = false) Long fastTrackvalue1,
                                           @RequestParam(value = "fast-track-value2", required = false) Long fastTrackValue2,
                                           @RequestParam(value = "delete-prev-track", defaultValue = "false") Boolean deletePrevTrack,
                                           @RequestParam(value = "dotted-line-thickness", required = false) Integer dottedLineThickness,
                                           @RequestParam(value = "linear-line-thickness", required = false) Integer linearLineThickness,
                                           @RequestParam(value = "refresh-interval", required = false) Integer refreshInterval,
                                           @RequestParam(value = "track-length-type", required = false) Long trackLengthType,
                                           @RequestParam(value = "track-length-value", required = false) Long trackLengthValue,
                                           @RequestParam(value = "track-length-color", required = false) String trackLengthColor,
                                           @RequestParam(value = "mapping-object-type", required = false) Long mappingObjectType,
                                           @RequestParam(value = "object-movement-type", required = false) Integer objectMovementType,
                                           @RequestParam(value = "is-show-suspended-objects", required = false) Boolean isShowSuspendedObjects,
                                           @RequestParam(value = "is_show_tracking_table", required = false, defaultValue = "false") Boolean isShowTrackingTable,
                                           @RequestParam(value = "is_show_tracking_chart", required = false, defaultValue = "false") Boolean isShowTrackingChart,
                                           @RequestParam(value = "tooltips-view-quantity", required = false) Long tooltipsViewQuantity,
                                           @RequestParam(value = "tooltips-massages-view", defaultValue = "false") Boolean tooltipsMassagesView,
                                           @RequestParam(value = "tooltips-massages-color", required = false) String tooltipsMassagesColor,
                                           @RequestParam(value = "tooltips-sms-view", defaultValue = "false") Boolean tooltipsSMSView,
                                           @RequestParam(value = "tooltips-sms-color", required = false) String tooltipsSMSColor,
                                           @RequestParam(value = "tooltips-command-view", defaultValue = "false") Boolean tooltipsCommandView,
                                           @RequestParam(value = "tooltips-command-color", required = false) String tooltipsCommandColor,
                                           @RequestParam(value = "tooltips-event-view", defaultValue = "false") Boolean tooltipsEventView,
                                           @RequestParam(value = "tooltips-event-color", required = false) String tooltipsEventColor,
                                           @RequestParam(value = "object-id-list", required = false) String objectIdList,
                                           @RequestParam(value = "minimum-scale", required = false) Integer trackedObjectsMinimumScale,
                                           @RequestParam(value = "maximum-scale", required = false) Integer trackedObjectsMaximumScale) {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsMap cmd={}, object-status-view={}, object-status-position={}, ignition-sensor-view={}, ignition-sensor-position={}, object-link-view={}, object-link-position={}, satellite-visibility-view={}, satellite-visibility-position={}," +
                            "object-driver-view={}, object-driver-position={}, sensor-state-view={}, sensor-state-position={}, object-massage-view={}, object-massage-position={}, build-track-view={}, build-track-position={}, report-view={}, report-position={}," +
                            "sms-send-view={}, sms-send-position={}, object-properties-view={}, object-properties-position={}, fast-track-type={},fast-track-value1={}, fast-track-value2={}, track-length-type={}, track-length-value={}, track-length-color={}, mapping-object-type={}," +
                            "tooltips-view-quantity={}, tooltips-massages-view={}, tooltips-massages-color={}, tooltips-sms-view={}, tooltips-sms-color={}, tooltips-command-view={}, tooltips-command-color={}, tooltips-event-view={}, tooltips-event-color={}, tracked-obj-min-scale={}, tracked-obj-max-scale={}",
                    cmd, objectStatusView, objectStatusPosition, ignitionSensorView, ignitionSensorPosition, objectLinkView, objectLinkPosition, satelliteVisibilityView, satelliteVisibilityPosition,
                    objectDriverView, objectDriverPosition, sensorStateView, sensorStatePosition, objectMassageView, objectMassagePosition, buildTrackView, buildTrackPosition, reportView, reportPosition,
                    smsSendView, smsSendPosition, objectPropertiesView, objectPropertiesPosition, fastTrackType, fastTrackvalue1, fastTrackValue2, trackLengthType, trackLengthValue, trackLengthColor, mappingObjectType,
                    tooltipsViewQuantity, tooltipsMassagesView, tooltipsMassagesColor, tooltipsSMSView, tooltipsSMSColor, tooltipsCommandView, tooltipsCommandColor, tooltipsEventView, tooltipsEventColor, trackedObjectsMinimumScale,
                    trackedObjectsMaximumScale);
        }
        Long fastTrackValue;

        ModelAndView modelAndView;

        if (cmd != null) {

            if (fastTrackType == 1) fastTrackValue = fastTrackvalue1;
            else fastTrackValue = fastTrackValue2;
            // check refresh-interval limit
            if (refreshInterval == null) {
                refreshInterval = UZGPS_CONST.MONITORING_REFRESHINTERVAL_MIN;
            } else if (refreshInterval < UZGPS_CONST.MONITORING_REFRESHINTERVAL_MIN) {
                refreshInterval = UZGPS_CONST.MONITORING_REFRESHINTERVAL_MIN;
            } else if (refreshInterval > UZGPS_CONST.MONITORING_REFRESHINTERVAL_MAX) {
                refreshInterval = UZGPS_CONST.MONITORING_REFRESHINTERVAL_MAX;
            }
            // check tooltipsViewQuantity limit
            if (tooltipsViewQuantity == null) {
                tooltipsViewQuantity = UZGPS_CONST.MONITORING_TOOLTIPISVIEWQUANTITY_MIN;
            } else if (tooltipsViewQuantity < UZGPS_CONST.MONITORING_TOOLTIPISVIEWQUANTITY_MIN) {
                tooltipsViewQuantity = UZGPS_CONST.MONITORING_TOOLTIPISVIEWQUANTITY_MIN;
            } else if (tooltipsViewQuantity > UZGPS_CONST.MONITORING_TOOLTIPISVIEWQUANTITY_MAX) {
                tooltipsViewQuantity = UZGPS_CONST.MONITORING_TOOLTIPISVIEWQUANTITY_MAX;
            }
            //check trackLengthType value=1 limit
            if (trackLengthType == 1) {
                if (trackLengthValue == null) {
                    trackLengthValue = UZGPS_CONST.MONITORING_TRECKLENGHTVALUE1_MIN;
                } else if (trackLengthValue < UZGPS_CONST.MONITORING_TRECKLENGHTVALUE1_MIN) {
                    trackLengthValue = UZGPS_CONST.MONITORING_TRECKLENGHTVALUE1_MIN;
                } else if (trackLengthValue > UZGPS_CONST.MONITORING_TRECKLENGHTVALUE1_MAX) {
                    trackLengthValue = UZGPS_CONST.MONITORING_TRECKLENGHTVALUE1_MAX;
                }
            }
            //check trackLengthType value=2 limit
            if (trackLengthType == 2) {
                if (trackLengthValue == null) {
                    trackLengthValue = UZGPS_CONST.MONITORING_TRECKLENGHTVALUE2_MIN;
                } else if (trackLengthValue < UZGPS_CONST.MONITORING_TRECKLENGHTVALUE2_MIN) {
                    trackLengthValue = UZGPS_CONST.MONITORING_TRECKLENGHTVALUE2_MIN;
                } else if (trackLengthValue > UZGPS_CONST.MONITORING_TRECKLENGHTVALUE2_MAX) {
                    trackLengthValue = UZGPS_CONST.MONITORING_TRECKLENGHTVALUE2_MAX;
                }
            }

            ContractSettings contractSettings = mainController.getContractSettings(session);
            contractSettings.setObjectStatusView(objectStatusView);
            contractSettings.setObjectStatusPosition(objectStatusPosition);
            contractSettings.setIgnitionSensorView(ignitionSensorView);
            contractSettings.setIgnitionSensorPosition(ignitionSensorPosition);
            contractSettings.setObjectLinkView(objectLinkView);
            contractSettings.setObjectLinkPosition(objectLinkPosition);
            contractSettings.setSatelliteVisibilityView(satelliteVisibilityView);
            contractSettings.setSatelliteVisibilityPosition(satelliteVisibilityPosition);
            contractSettings.setObjectDriverView(objectDriverView);
            contractSettings.setObjectDriverPosition(objectDriverPosition);
            contractSettings.setSensorStateView(sensorStateView);
            contractSettings.setSensorStatePosition(sensorStatePosition);
            contractSettings.setObjectMassageView(objectMassageView);
            contractSettings.setObjectMassagePosition(objectMassagePosition);
            contractSettings.setBuildTrackView(buildTrackView);
            contractSettings.setBuildTrackPosition(buildTrackPosition);
            contractSettings.setReportView(reportView);
            contractSettings.setReportPosition(reportPosition);
            contractSettings.setSmsSendView(smsSendView);
            contractSettings.setSmsSendPosition(smsSendPosition);
            contractSettings.setObjectPropertiesView(objectPropertiesView);
            contractSettings.setObjectPropertiesPosition(objectPropertiesPosition);
            contractSettings.setFastTrackType(fastTrackType);
            contractSettings.setFastTrackValue(fastTrackValue);
            contractSettings.setDeletePrevTrack(deletePrevTrack);
            contractSettings.setDottedLineThickness(dottedLineThickness);
            contractSettings.setLinearLineThickness(linearLineThickness);
            contractSettings.setMonitoringRefreshInterval(refreshInterval);
            contractSettings.setTrackLengthType(trackLengthType);
            contractSettings.setTrackLengthValue(trackLengthValue);
            contractSettings.setTrackLengthColor(trackLengthColor);
//            contractSettings.setTrackedObjectsMinZoom(trackedObjectsMinimumScale);
            contractSettings.setTrackedObjectsMaxZoom(trackedObjectsMaximumScale);
            contractSettings.setMappingObjectType(mappingObjectType);
            contractSettings.setObjectMovementType(objectMovementType);
            contractSettings.setIsShowSuspendedObjects(isShowSuspendedObjects);
            contractSettings.setIsShowTrackingTable(isShowTrackingTable);
            contractSettings.setIsShowTrackingChart(isShowTrackingChart);
            contractSettings.setTooltipsViewQuantity(tooltipsViewQuantity);
            contractSettings.setTooltipsMassagesView(tooltipsMassagesView);
            contractSettings.setTooltipsMassagesColor(tooltipsMassagesColor);
            contractSettings.setTooltipsSmsView(tooltipsSMSView);
            contractSettings.setTooltipsSmsColor(tooltipsSMSColor);
            contractSettings.setTooltipsCommandView(tooltipsCommandView);
            contractSettings.setTooltipsCommandColor(tooltipsCommandColor);
            contractSettings.setTooltipsEventView(tooltipsEventView);
            contractSettings.setTooltipsEventColor(tooltipsEventColor);
            contractSettings.setBakPosition(bakStatusPosition);
            contractSettings.setBakPositionView(bakStatusPositionView);
            contractSettings.setExternalPowerVoltagePosition(evpObjectPosition);
            contractSettings.setExternalPowerVoltageView(evpObjectPositionView);
            contractSettings.setObjBatteryPosition(objBatteryPosition);
            contractSettings.setObjBatteryView(objBatteryPositionView);
            contractSettings.setLastMsgTimePosition(lastMsgTimePosition);
            contractSettings.setLastMsgTimeView(lastMsgTimeView);

            // Set all Mobjects to untracked
            List<MobjectBig> mObjects = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);

            for (MobjectBig mObjectBig : mObjects) {
                if (mObjectBig.getIsTracked() == 1) {
                    MObject mObject = adminService.getMObjectById(mObjectBig.getId());

                    mObject.setIsTracked(0);
                    mObject.setModDate(new Timestamp(System.currentTimeMillis()));
                    settingsService.saveMObject(mObject);

                    mObjectBig.setIsTracked(0);
                    // Update core Cloud : Mobject must be updated
                    coreMain.coreUpdater.updateMobjectBigById(mObjectBig.getId());
                }
            }

            // save tracked Mobjects
            if (!objectIdList.equalsIgnoreCase("")) {
                List<String> newGroupObjectIdList = new ArrayList<>(Arrays.asList(objectIdList.split(",")));

                // Set new Group Id for each Mobject
                for (String newGroupObjectId : newGroupObjectIdList) {
                    MObject mObject = settingsService.getObjectByObjectId(Long.parseLong(newGroupObjectId));

                    if (mObject.getIsTracked() == 0) {
                        mObject.setIsTracked(1);

                        settingsService.saveMObject(mObject);

                        // Update core Cloud : Mobject must be updated
                        coreMain.coreUpdater.updateMobjectBigById(mObject.getId());
                    }

                }
            }

            settingsService.saveContractSettings(contractSettings);

            session.setAttribute(MainController.SESSION_CONTRACT_SETTINGS, contractSettings);

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_MONITORING);
        } else {
            modelAndView = new ModelAndView(VIEW_SETTINGS_MONITORING);

            ContractSettings contractSettings = mainController.getContractSettings(session);
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), contractSettings.getIsShowSuspendedObjects());

            modelAndView.addObject("settings", contractSettings);
            modelAndView.addObject("mObjects", mobjectList);
            modelAndView.addObject("cmd", "edit");

            List<IconColumn> iconColumns = new ArrayList<>();
            iconColumns.add(new IconColumn(contractSettings.getObjectStatusPosition(), "object-status", "state.object", "state-span", contractSettings.getObjectStatusView()));
            iconColumns.add(new IconColumn(contractSettings.getIgnitionSensorPosition(), "ignition-sensor", "ignition.sensor", "icon-dashboard", contractSettings.getIgnitionSensorView()));
            iconColumns.add(new IconColumn(contractSettings.getObjectLinkPosition(), "object-link", "connection.object", "icon-signal", contractSettings.getObjectLinkView()));
            iconColumns.add(new IconColumn(contractSettings.getSatelliteVisibilityPosition(), "satellite-visibility", "satellite.visibility", "icon-rss", contractSettings.getSatelliteVisibilityView()));
            iconColumns.add(new IconColumn(contractSettings.getObjectDriverPosition(), "object-driver", "staff.object", "icon-user", contractSettings.getObjectDriverView()));
            iconColumns.add(new IconColumn(contractSettings.getSensorStatePosition(), "sensor-state", "state.sensor", "icon-off", contractSettings.getSensorStateView()));
            iconColumns.add(new IconColumn(contractSettings.getObjectMassagePosition(), "object-massage", "object.massage", "icon-envelope", contractSettings.getObjectMassageView()));
            iconColumns.add(new IconColumn(contractSettings.getBuildTrackPosition(), "build-track", "object.track", "icon-road", contractSettings.getBuildTrackView()));
            iconColumns.add(new IconColumn(contractSettings.getReportPosition(), "report", "report.object", "icon-list-alt", contractSettings.getReportView()));
            iconColumns.add(new IconColumn(contractSettings.getSmsSendPosition(), "sms-send", "sms.message", "icon-comment", contractSettings.getSmsSendView()));
            iconColumns.add(new IconColumn(contractSettings.getObjectPropertiesPosition(), "object-properties", "edit.object", "icon-edit", contractSettings.getObjectPropertiesView()));
            iconColumns.add(new IconColumn(contractSettings.getBakPosition(), "bak-status", "state.bak", "bac-icon", contractSettings.getBakPositionView()));
            iconColumns.add(new IconColumn(contractSettings.getExternalPowerVoltagePosition(), "epv-object", "epv.object", "fa fa-calendar-plus-o", contractSettings.getExternalPowerVoltageView()));
            iconColumns.add(new IconColumn(contractSettings.getLastMsgTimePosition(), "last-msg-time", "last.msg.time", "fa fa-clock-o", contractSettings.getLastMsgTimeView()));
            iconColumns.add(new IconColumn(contractSettings.getObjBatteryPosition(), "obj-battery", "battery.percent", "fa fa-battery-full", contractSettings.getObjBatteryView()));

            Collections.sort(iconColumns, new Comparator<IconColumn>() {
                @Override
                public int compare(IconColumn o1, IconColumn o2) {
                    return o1.index - o2.index;
                }
            });

            modelAndView.addObject("iconColumns", iconColumns);

            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);
        }

        return modelAndView;
    }

    public static class IconColumn {
        private Integer index;
        private String id;
        private String name;
        private String icon;
        private Boolean status;

        public IconColumn(Integer index, String id, String name, String icon, boolean status) {
            this.index = index;
            this.id = id;
            this.name = name;
            this.status = status;
            this.icon = icon;
        }

        public Integer getIndex() {
            return index;
        }

        public void setIndex(Integer index) {
            this.index = index;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getIcon() {
            return icon;
        }

        public void setIcon(String icon) {
            this.icon = icon;
        }

        public Boolean getStatus() {
            return status;
        }

        public void setStatus(Boolean status) {
            this.status = status;
        }


    }


}
