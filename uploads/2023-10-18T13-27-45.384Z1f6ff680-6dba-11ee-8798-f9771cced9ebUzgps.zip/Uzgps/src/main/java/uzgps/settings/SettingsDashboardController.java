package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.core.helper.CoreGeofence;
import uz.netex.datatype.MobjectBig;
import uz.netex.dbtables.Geofence;
import uzgps.admin.AdminService;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.persistence.Contract;
import uzgps.persistence.GeoFence;
import uzgps.persistence.MonitoredZoi;

import javax.servlet.http.HttpSession;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Created by Stanislav on 12.04.22
 */

@Controller
public class SettingsDashboardController extends AbstractSettingsController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private static final String URL_SETTINGS_DASHBOARD = "/settings/dashboard.htm";
    private static final String VIEW_SETTINGS_DASHBOARD = "settings/settings-dashboard";

    private static final short MAX_MONITORED_ZONES = 5;

    @Autowired
    private SettingsService settingsService;

    @Autowired
    AdminService adminService;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTINGS_DASHBOARD)
    public ModelAndView processSettingsDashboard(HttpSession session,
                                                 @RequestParam(value = "cmd", required = false) String cmd,
                                                 @RequestParam(value = "object-id-list", required = false) String zoiIdsStr) {
        ModelAndView modelAndView;

        if (cmd != null) {
            // save tracked Mobjects
            if (!zoiIdsStr.equalsIgnoreCase("")) {
                List<String> zoiIdList = new ArrayList<>(Arrays.asList(zoiIdsStr.split(",")));

                // Validate Max zones
                if (zoiIdList.size() > MAX_MONITORED_ZONES) {
                    modelAndView = fillModelAndView(session);
                    modelAndView.addObject("error_max_zones", true);
                    return modelAndView;
                }

                List<MonitoredZoi> monitoredZoiList = settingsService.getMonitoredZoiByContractId(MainController.getUserContractId(session));
                Contract contract = adminService.getContractById(MainController.getUserContractId(session));

                List<Long> notMonitoredZoiIdList = monitoredZoiList
                        .stream()
                        .map(MonitoredZoi::getZoiId)
                        .collect(Collectors.toList());

                for (String zoiIdStr : zoiIdList) {
                    try {
                        Long zoiId = Converters.strToLong(zoiIdStr, 0L);
                        notMonitoredZoiIdList.remove(zoiId);

                        MonitoredZoi monitoredZoi = monitoredZoiList.stream().filter(
                                mzl -> Objects.equals(mzl.getZoiId(), zoiId)).collect(Collectors.toList()).stream().findFirst().orElse(null);

                        // add if zoi is not monitored for dashboard
                        if (monitoredZoi == null) {
                            GeoFence zoi = settingsService.getGeoFenceById(zoiId);
                            addMonitoredZoi(contract, zoi);
                        }
                    } catch (Exception e) {
                        logger.error("Error in processSettingsDashboard", e);
                    }
                }

                for (long notMonitoredZoiId : notMonitoredZoiIdList) {
                    // remove deleted monitored zoi
                    monitoredZoiList.stream().filter(
                            mzl -> Objects.equals(mzl.getZoiId(), notMonitoredZoiId)).collect(Collectors.toList()).stream().findFirst().ifPresent(monitoredZoi -> deleteMonitoredZoi(monitoredZoi.getId()));
                }
            } else {
                // remove monitored zones
                List<MonitoredZoi> monitoredZoiList = settingsService.getMonitoredZoiByContractId(MainController.getUserContractId(session));

                for (MonitoredZoi monitoredZoi : monitoredZoiList) {
                    // remove deleted monitored zoi
                    deleteMonitoredZoi(monitoredZoi.getId());
                }
            }

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_DASHBOARD);
        } else {
            modelAndView = fillModelAndView(session);
        }

        return modelAndView;
    }

    private ModelAndView fillModelAndView(HttpSession session) {
        ModelAndView modelAndView;
        modelAndView = new ModelAndView(VIEW_SETTINGS_DASHBOARD);
        List<MonitoredZoi> monitoredZoiList = settingsService.getMonitoredZoiByContractId(MainController.getUserContractId(session));
        List<Geofence> zoiListTemp = CoreGeofence.getInstance().getListByContractId(MainController.getUserContractId(session));

        List<GeoFence> zoiListWithMonitoredData = getZoiListWithMonitoredData(zoiListTemp, monitoredZoiList);

        modelAndView.addObject("cmd", "edit");
        modelAndView.addObject("selectedLeftMenu", "dashboard");
        modelAndView.addObject("zoiList", zoiListWithMonitoredData);

        boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
        List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

        Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

        Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

        Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
        modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        return modelAndView;
    }

    /**
     * Add MonitoredZoi
     *
     * @param contract Contract
     * @param zoi      GeoFence
     */
    private void addMonitoredZoi(Contract contract, GeoFence zoi) {
        MonitoredZoi monitoredZoi = new MonitoredZoi();
        monitoredZoi.setContract(contract);
        monitoredZoi.setZoi(zoi);
        monitoredZoi.setStatus(UZGPS_CONST.STATUS_ACTIVE);
        monitoredZoi.setRegDate(new Timestamp(System.currentTimeMillis()));

        settingsService.saveMonitoredZoi(monitoredZoi);
    }

    /**
     * Delete MonitoredZoi
     *
     * @param id monitoredZoiId
     */
    private void deleteMonitoredZoi(Long id) {
        settingsService.deleteMonitoredZoiById(id);
    }

    private List<GeoFence> getZoiListWithMonitoredData(List<Geofence> zoiTempList, List<MonitoredZoi> monitoredZoiList) {
        List<GeoFence> zoiListWithMonitoredData = new ArrayList<>();

        if (zoiTempList != null) {
            for (Geofence zoiTemp : zoiTempList) {
                GeoFence zoi = new GeoFence();
                zoi.setId(zoiTemp.getId());
                zoi.setContractId(zoiTemp.getContractId());
                zoi.setName(zoiTemp.getName());

                zoiListWithMonitoredData.add(zoi);
            }

            for (MonitoredZoi monitoredZoi : monitoredZoiList) {
                GeoFence zoiWithMonitoredData = zoiListWithMonitoredData.stream().filter(
                        a -> Objects.equals(a.getId(), monitoredZoi.getZoiId())).collect(Collectors.toList()).stream().findFirst().orElse(null);

                if (zoiWithMonitoredData != null) {
                    zoiWithMonitoredData.setMonitored(true);
                }
            }
        }

        return zoiListWithMonitoredData;
    }


}
