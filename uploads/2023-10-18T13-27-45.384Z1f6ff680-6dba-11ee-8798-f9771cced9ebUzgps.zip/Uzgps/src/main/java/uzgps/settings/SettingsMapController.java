package uzgps.settings;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.admin.AdminController;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.Group;
import uzgps.persistence.Staff;
import uzgps.persistence.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

import static uzgps.main.MainController.getUser;
import static uzgps.main.MainController.isContractBlocked;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class SettingsMapController extends AbstractSettingsController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_SETTINGS_MAP = "/settings/main.htm";
    private final static String VIEW_SETTINGS_MAP = "settings/settings-map";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    CoreMain coreMain;

    @RequestMapping(value = URL_SETTINGS_MAP)
    public ModelAndView processSettingsMap(HttpSession session,
                                           @RequestParam(value = "cmd", required = false) String cmd,
                                           @RequestParam(value = "map-type", required = false) Long mapType,
                                           @RequestParam(value = "save-current-position", defaultValue = "false") Boolean saveCurrentPosition,
                                           @RequestParam(value = "show-name-poi", defaultValue = "false") Boolean showNamePoi,
                                           @RequestParam(value = "show-objects-in-cluster", defaultValue = "false") Boolean showObjectsInCluster,
                                           @RequestParam(value = "poi-load-startup", defaultValue = "false") Boolean poiLoadStartup,
                                           @RequestParam(value = "geozone-load-startup", defaultValue = "false") Boolean geozoneLoadStartup,
                                           @RequestParam(value = "binding-tracks-to-map", defaultValue = "false") Boolean bindingTracksToMap,
                                           @RequestParam(value = "show-name-geozone", defaultValue = "false") Boolean showNameGeoZone,
                                           @RequestParam(value = "object-label", required = false) Long objectLabel,
                                           @RequestParam(value = "object-name-monitoring", defaultValue = "false") Boolean objectNameMonitoring,
                                           @RequestParam(value = "object-name-tracking", defaultValue = "false") Boolean objectNameTracking,
                                           @RequestParam(value = "type-tracker-monitoring", defaultValue = "false") Boolean typeTrackerMonitoring,
                                           @RequestParam(value = "type-tracker-tracking", defaultValue = "false") Boolean typeTrackerTracking,
                                           @RequestParam(value = "tracker-id-monitoring", defaultValue = "false") Boolean trackerIdMonitoring,
                                           @RequestParam(value = "tracker-id-tracking", defaultValue = "false") Boolean trackerIdTracking,
                                           @RequestParam(value = "tracker-phone-number-monitoring", defaultValue = "false") Boolean trackerPhoneNumberMonitoring,
                                           @RequestParam(value = "tracker-phone-number-tracking", defaultValue = "false") Boolean trackerPhoneNumberTracking,
                                           @RequestParam(value = "object-type-monitoring", defaultValue = "false") Boolean objectTypeMonitoring,
                                           @RequestParam(value = "object-type-tracking", defaultValue = "false") Boolean objectTypeTracking,
                                           @RequestParam(value = "object-plate-number-monitoring", defaultValue = "false") Boolean objectPlateNumberMonitoring,
                                           @RequestParam(value = "object-plate-number-tracking", defaultValue = "false") Boolean objectPlateNumberTracking,
                                           @RequestParam(value = "object-additional-info-monitoring", defaultValue = "false") Boolean objectAdditionalInfoMonitoring,
                                           @RequestParam(value = "object-capacity-monitoring", defaultValue = "false") Boolean objectCapacityMonitoring,
                                           @RequestParam(value = "object-capacity-tracking", defaultValue = "false") Boolean objectCapacityTracking,
                                           @RequestParam(value = "object-fuel-monitoring", defaultValue = "false") Boolean objectFuelMonitoring,
                                           @RequestParam(value = "object-fuel-tracking", defaultValue = "0") Boolean objectFuelTracking,
                                           @RequestParam(value = "object-address-monitoring", defaultValue = "false") Boolean objectAddressMonitoring,
                                           @RequestParam(value = "object-address-tracking", defaultValue = "false") Boolean objectAddressTracking,
                                           @RequestParam(value = "object-coordinates-monitoring", defaultValue = "false") Boolean objectCoordinatesMonitoring,
                                           @RequestParam(value = "object-coordinates-tracking", defaultValue = "false") Boolean objectCoordinatesTracking,
                                           @RequestParam(value = "object-speed-monitoring", defaultValue = "false") Boolean objectSpeedMonitoring,
                                           @RequestParam(value = "object-speed-tracking", defaultValue = "false") Boolean objectSpeedTracking,
                                           @RequestParam(value = "object-satellite-monitoring", defaultValue = "false") Boolean objectSatelliteMonitoring,
                                           @RequestParam(value = "object-satellite-tracking", defaultValue = "false") Boolean objectSatelliteTracking,
                                           @RequestParam(value = "object-odometer-monitoring", defaultValue = "false") Boolean objectOdometerMonitoring,
                                           @RequestParam(value = "object-odometer-tracking", defaultValue = "false") Boolean objectOdometerTracking,
                                           @RequestParam(value = "object-hourmeter-monitoring", defaultValue = "false") Boolean objectHourmeterMonitoring,
                                           @RequestParam(value = "object-hourmeter-tracking", defaultValue = "false") Boolean objectHourmeterTracking,
                                           @RequestParam(value = "being-geozon-monitoring", defaultValue = "false") Boolean beingGeozonMonitoring,
                                           @RequestParam(value = "being-geozon-tracking", defaultValue = "false") Boolean beingGeozonTracking,
                                           @RequestParam(value = "design-rout-monitoring", defaultValue = "false") Boolean designRoutMonitoring,
                                           @RequestParam(value = "design-rout-tracking", defaultValue = "false") Boolean designRoutTracking,
                                           @RequestParam(value = "name-staff-monitoring", defaultValue = "false") Boolean nameStaffMonitoring,
                                           @RequestParam(value = "name-staff-tracking", defaultValue = "false") Boolean nameStaffTracking,
                                           @RequestParam(value = "photo-staff-monitoring", defaultValue = "false") Boolean photoStaffMonitoring,
                                           @RequestParam(value = "photo-staff-tracking", defaultValue = "false") Boolean photoStaffTracking,
                                           @RequestParam(value = "phone-staff-monitoring", defaultValue = "false") Boolean phoneStaffMonitoring,
                                           @RequestParam(value = "phone-staff-tracking", defaultValue = "false") Boolean phoneStaffTracking,
                                           @RequestParam(value = "last-track-timestamp", defaultValue = "false") Boolean lastTrackTimestamp,
                                           @RequestParam(value = "fuel-monitoring", defaultValue = "false") Boolean fuelMonitoring,
                                           @RequestParam(value = "fuel-tracking", defaultValue = "false") Boolean fuelTracking,
                                           @RequestParam(value = "assigned-route-monitoring", defaultValue = "false") Boolean assignedRouteMonitoring,
                                           @RequestParam(value = "assigned-route-tracking", defaultValue = "false") Boolean assignedRouteTracking)
            throws ServletException, IOException {

        if (logger.isDebugEnabled()) {
            logger.debug("processSettingsMap cmd={}, map-type={}, save-current-position={}, show-name-poi={}, show-objects-in-cluster={}, poi-load-startup={}, geozone-load-startup={}, binding-tracks-to-map={}, show-name-geozone={}, object-label={}, object-name-monitoring={}," +
                            "object-name-tracking={}, type-tracker-monitoring={}, type-tracker-tracking={}, tracker-id-monitoring={}, tracker-id-tracking={}, tracker-phone-number-monitoring={}, tracker-phone-number-tracking={}," +
                            "object-type-monitoring={}, object-type-tracking={}, object-plate-number-monitoring={}, object-plate-number-tracking={}, object-capacity-monitoring={}, object-capacity-tracking={}, object-fuel-monitoring={}," +
                            "object-fuel-tracking={}, object-address-monitoring={}, object-address-tracking={}, object-coordinates-monitoring={}, object-coordinates-tracking={}, object-speed-monitoring={}, object-speed-tracking={}," +
                            "object-satellite-monitoring={}, object-satellite-tracking={}, object-odometer-monitoring={}, object-odometer-tracking={}, object-hourmeter-monitoring={}, object-hourmeter-tracking={}, being-geozon-monitoring={}," +
                            "being-geozon-tracking={}, design-rout-monitoring={}, design-rout-tracking={}, name-staff-monitoring={}, name-staff-tracking={}, photo-staff-monitoring={}, photo-staff-tracking={}, phone-staff-monitoring={}, phone-staff-tracking={}",
                    cmd, mapType, saveCurrentPosition, showNamePoi, showObjectsInCluster, poiLoadStartup, geozoneLoadStartup, bindingTracksToMap, showNameGeoZone, objectLabel, objectNameMonitoring,
                    objectNameTracking, typeTrackerMonitoring, typeTrackerTracking, trackerIdMonitoring, trackerIdTracking, trackerPhoneNumberMonitoring, trackerPhoneNumberTracking,
                    objectTypeMonitoring, objectTypeTracking, objectPlateNumberMonitoring, objectPlateNumberTracking, objectCapacityMonitoring, objectCapacityTracking, objectFuelMonitoring,
                    objectFuelTracking, objectAddressMonitoring, objectAddressTracking, objectCoordinatesMonitoring, objectCoordinatesTracking, objectSpeedMonitoring, objectSpeedTracking,
                    objectSatelliteMonitoring, objectSatelliteTracking, objectOdometerMonitoring, objectOdometerTracking, objectHourmeterMonitoring, objectHourmeterTracking, beingGeozonMonitoring,
                    beingGeozonTracking, designRoutMonitoring, designRoutTracking, nameStaffMonitoring, nameStaffTracking, photoStaffMonitoring, photoStaffTracking, phoneStaffMonitoring, phoneStaffTracking);
        }

        if (isContractBlocked(session, MainController.getUserContractId(session))) {
//            return new ModelAndView("redirect:" + "../" + URL_CONTRACT_DETERMINED);

            String cabinetUrl = (String) session.getAttribute("url_cabinet");
            String authToken;
            if (MainController.getUser().getRoleId().equals(UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN)) {
                authToken = getUser().getAuthToken();
            } else {
                authToken = getUser().getInterfaceAuthToken();
            }

            String lang = LocaleContextHolder.getLocale().getLanguage();

            return new ModelAndView("redirect:" + cabinetUrl +
                    "?code=" + authToken +
                    "&cid=" + MainController.getUserContractId(session) +
                    "&lang=" + lang
            );
        }

        ModelAndView modelAndView;

        if (MainController.getUserContractId(session) == null) {
            modelAndView = new ModelAndView("redirect:" + AdminController.URL_ADMIN_MAIN);
            return modelAndView;
        }

        if (cmd != null) {

            ContractSettings contractSettings = mainController.getContractSettings(session);
            contractSettings.setMapType(mapType);
            contractSettings.setSaveCurrentPosition(saveCurrentPosition);
            contractSettings.setShowNamePoi(showNamePoi);
            contractSettings.setShowObjectsInCluster(showObjectsInCluster);
            if (!showObjectsInCluster){
                contractSettings.setObjectMovementType(0);
            }
            contractSettings.setPoiLoadStartup(poiLoadStartup);
            contractSettings.setGeozoneLoadStartup(geozoneLoadStartup);
            contractSettings.setBindingTracksToMap(bindingTracksToMap);
            contractSettings.setShowNameGeoZone(showNameGeoZone);
            contractSettings.setObjectLabel(objectLabel);
            contractSettings.setObjectNameMonitoring(objectNameMonitoring);
            contractSettings.setObjectNameTracking(objectNameTracking);
            contractSettings.setTypeTrackerMonitoring(typeTrackerMonitoring);
            contractSettings.setTypeTrackerTracking(typeTrackerTracking);
            contractSettings.setTrackerIdMonitoring(trackerIdMonitoring);
            contractSettings.setTrackerIdTracking(trackerIdTracking);
            contractSettings.setTrackerPhoneNumberMonitoring(trackerPhoneNumberMonitoring);
            contractSettings.setTrackerPhoneNumberTracking(trackerPhoneNumberTracking);
            contractSettings.setObjectTypeMonitoring(objectTypeMonitoring);
            contractSettings.setObjectTypeTracking(objectTypeTracking);
            contractSettings.setObjectPlateNumberMonitoring(objectPlateNumberMonitoring);
            contractSettings.setObjectPlateNumberTracking(objectPlateNumberTracking);
            contractSettings.setObjectAdditionalInfoMonitoring(objectAdditionalInfoMonitoring);
            contractSettings.setObjectCapacityMonitoring(objectCapacityMonitoring);
            contractSettings.setObjectCapacityTracking(objectCapacityTracking);
            contractSettings.setObjectFuelMonitoring(objectFuelMonitoring);
            contractSettings.setObjectFuelTracking(objectFuelTracking);
            contractSettings.setObjectAddressMonitoring(objectAddressMonitoring);
            contractSettings.setObjectAddressTracking(objectAddressTracking);
            contractSettings.setObjectCoordinatesMonitoring(objectCoordinatesMonitoring);
            contractSettings.setObjectCoordinatesTracking(objectCoordinatesTracking);
            contractSettings.setObjectSpeedMonitoring(objectSpeedMonitoring);
            contractSettings.setObjectSpeedTracking(objectSpeedTracking);
            contractSettings.setObjectSatelliteMonitoring(objectSatelliteMonitoring);
            contractSettings.setObjectSatelliteTracking(objectSatelliteTracking);
            contractSettings.setObjectOdometerMonitoring(objectOdometerMonitoring);
            contractSettings.setObjectOdometerTracking(objectOdometerTracking);
            contractSettings.setObjectHourmeterMonitoring(objectHourmeterMonitoring);
            contractSettings.setObjectHourmeterTracking(objectHourmeterTracking);
            contractSettings.setBeingGeozonMonitoring(beingGeozonMonitoring);
            contractSettings.setBeingGeozonTracking(beingGeozonTracking);
            contractSettings.setDesignRoutMonitoring(designRoutMonitoring);
            contractSettings.setDesignRoutTracking(designRoutTracking);
            contractSettings.setNameStaffMonitoring(nameStaffMonitoring);
            contractSettings.setNameStaffTracking(nameStaffTracking);
            contractSettings.setPhotoStaffMonitoring(photoStaffMonitoring);
            contractSettings.setPhotoStaffTracking(photoStaffTracking);
            contractSettings.setPhoneStaffMonitoring(phoneStaffMonitoring);
            contractSettings.setPhoneStaffTracking(phoneStaffTracking);
            contractSettings.setLastTrackTimestamp(lastTrackTimestamp);
            contractSettings.setFuelMonitoring(fuelMonitoring);
            contractSettings.setFuelTracking(fuelTracking);
            contractSettings.setAssignedRouteMonitoring(assignedRouteMonitoring);
            contractSettings.setAssignedRouteTracking(assignedRouteTracking);

            settingsService.saveContractSettings(contractSettings);

            session.setAttribute(MainController.SESSION_CONTRACT_SETTINGS, contractSettings);

            modelAndView = new ModelAndView("redirect:" + URL_SETTINGS_MAP);
        } else {

            modelAndView = new ModelAndView(VIEW_SETTINGS_MAP);
            ContractSettings contractSettingses = mainController.getContractSettings(session);
            modelAndView.addObject("settings", contractSettingses);
            modelAndView.addObject("cmd", "edit");

            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            List<MobjectBig> mobjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
            modelAndView.addObject("objectsCount", (mobjectList != null) ? mobjectList.size() : 0);

            Long groupCount = settingsService.getGroupCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("groupCount", (groupCount != null) ? groupCount : 0);

            Long staffCount = settingsService.getStaffCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("staffCount", (staffCount != null) ? staffCount : 0);

            Long userCount = settingsService.getCustomerUsersCountByContractId(MainController.getUserContractId(session));
            modelAndView.addObject("usersCount", (userCount != null) ? userCount : 0);

        }


        return modelAndView;
    }


}
