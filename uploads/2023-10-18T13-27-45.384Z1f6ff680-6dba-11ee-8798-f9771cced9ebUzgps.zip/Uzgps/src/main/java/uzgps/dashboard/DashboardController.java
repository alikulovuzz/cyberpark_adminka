package uzgps.dashboard;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import uzgps.common.CommonUtils;
import uzgps.main.AppLastStatus;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.persistence.Contract;
import uzgps.persistence.Region;
import uzgps.settings.SettingsService;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static uzgps.common.Converters.strToInt;
import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

/**
 * Created by Abdurahmon on 25/03/2022
 */

@Controller
public class DashboardController extends AbstractDashboardController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    DashboardService dashboardService;

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    SettingsService settingsService;

    public static final String URL_DASHBOARD_MAIN = "/dashboard.htm";
    private static final String VIEW_DASHBOARD_MAIN = "dashboard/dashboard";

    private static final String URL_DASHBOARD_DATA_JSON = "/dashboard/data-json.htm";

    /**
     * Return
     *
     * @return ModelAndView
     */
    @RequestMapping(value = URL_DASHBOARD_MAIN)
    public ModelAndView dashboardMain(@CookieValue(value = MainController.COOKIE_APP_LAST_STATUS, defaultValue = "") String appStatus,
                                      HttpSession session, Locale locale,
                                      @RequestParam(value = "regionId", required = false, defaultValue = "0") String regionIdStr) {
        ModelAndView modelAndView = new ModelAndView(VIEW_DASHBOARD_MAIN);
        try {
            Integer regionId = strToInt(regionIdStr, 0);

            fillBaseDashboardData(session, locale, modelAndView, appStatus);

            locale = LocaleContextHolder.getLocale();

            List<Long> contractIds = new ArrayList<>();

            if (MainController.getIsShowObjectsOfAllContracts(session)) {
                contractIds = MainController.getUserContractsIds(session);
            } else {
                Long contractId = MainController.getUserContractId(session);
                contractIds.add(contractId);
            }

        } catch (Exception e) {
            logger.error("Error in dashboardMain", e);
        }

        return modelAndView;
    }

    private void fillBaseDashboardData(HttpSession session, Locale locale, ModelAndView modelAndView, String appStatus) {
        AppLastStatus appLastStatus;
        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        List<Contract> contracts = new ArrayList<>();

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            contracts = MainController.getUserContracts(session);
        } else {
            Contract contract = MainController.getUserContract(session);
            contracts.add(contract);
        }

        modelAndView.addObject("appLastStatus", appLastStatus);

        String lang = "ru";
        if (locale != null && locale.getLanguage() != null) {
            lang = locale.getLanguage();
        }
        modelAndView.addObject("lang", lang);

        List<Region> regions = dashboardService.getRegions();
        modelAndView.addObject("regions", regions);

        modelAndView.addObject("isShowObjectsOfAllContracts", MainController.getIsShowObjectsOfAllContracts(session));

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            modelAndView.addObject("contractsIds", MainController.getUserContractsIds(session));
        }

        modelAndView.addObject("contractId", MainController.getUserContractId(session));

        modelAndView.addObject("contracts", contracts);

        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            modelAndView.addObject("userId", MainController.getInterfaceUserId());
        } else {
            modelAndView.addObject("userId", MainController.getUserId());
        }
    }



}
