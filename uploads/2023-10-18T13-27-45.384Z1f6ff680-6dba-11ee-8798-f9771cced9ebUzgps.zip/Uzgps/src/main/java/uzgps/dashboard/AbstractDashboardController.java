package uzgps.dashboard;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import uz.netex.routing.core.CoreTripRoutingControl;
import uzgps.main.MainController;
import uzgps.persistence.User;
import uzgps.persistence.UserAccessList;

import javax.servlet.http.HttpSession;

/**
 * Created by Stanislav on 28/03/2022
 */
public abstract class AbstractDashboardController {

    @Autowired
    MainController mainController;

    @Autowired
    ObjectMapper jsonMapper;

    /**
     * Get current user's access list
     *
     * @param session
     * @return UserAccessList
     */
    @ModelAttribute("userAccessList")
    private UserAccessList getUserAccessList(HttpSession session) {
        // Get user access list in session
        UserAccessList userAccessList = mainController.getUserAccessList(session);

        return userAccessList;
    }

    /**
     * Check whether system has an access for routing module
     *
     * @return
     */
    @ModelAttribute("hasRoutingAccess")
    private Boolean getRoutingAccess() {
        return CoreTripRoutingControl.hasAccess();
    }

    /**
     * Get active top menu in order to add active class to menu in html
     *
     * @return String
     */
    @ModelAttribute("activeTopMenu")
    private String getActiveTopMenu() {
        return "dashboard";
    }
    /**
     * Get current user's company name
     *
     * @return String
     */
    @ModelAttribute("companyName")
    private String getCompanyName(HttpSession session) {

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            return MainController.getUserContract(session).getCompany().getName();
        } else {
            return MainController.getUserContract(session).getCustomerCompanyName();
        }
    }

    /**
     * Get current user's login
     *
     * @return String
     */
    @ModelAttribute("userLogin")
    private String getUserLogin() {
        // Get current logged in user
        User user = MainController.getUser();
        return user.getLogin();
    }

}
