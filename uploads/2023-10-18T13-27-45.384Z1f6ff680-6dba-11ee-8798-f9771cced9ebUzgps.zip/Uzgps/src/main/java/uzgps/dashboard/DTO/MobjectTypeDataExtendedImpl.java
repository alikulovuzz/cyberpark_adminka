package uzgps.dashboard.DTO;

import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Immutable
@Table(schema = "dashboard")
public class MobjectTypeDataExtendedImpl  {
    @Id
    private Long id;

    private String name;

    private Integer count;

    private Long contract_id;
    private Long mobject_type_id;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
    public Long getContractId() {
        return contract_id;
    }

    public void setContract_id(Long contract_id) {
        this.contract_id = contract_id;
    }

    public Long getMobjectTypeId() {
        return mobject_type_id;
    }

    public void setMobject_type_id(Long mobject_type_id) {
        this.mobject_type_id = mobject_type_id;
    }
}
