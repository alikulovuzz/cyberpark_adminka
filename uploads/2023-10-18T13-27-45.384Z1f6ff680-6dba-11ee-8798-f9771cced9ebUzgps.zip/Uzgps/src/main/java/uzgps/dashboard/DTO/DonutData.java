package uzgps.dashboard.DTO;

public interface DonutData {

    String getName();

    void setName(String name);

    Integer getCount();

    void setCount(Integer count);
}
