package uzgps.dashboard.DTO;

import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Immutable
@Table(schema = "dashboard")
public class DashboardData {

    @Id
    private Long id;

    private Double distance;

    private Integer max_speed;
    private Integer max_speed_violations_count;
    private Integer max_speed_violations_passenger_count;
    private Integer max_speed_violations_cargo_count;
    private Integer max_speed_violations_special_count;
    private Integer max_speed_violations_other_count;
    private String parking_time;

    private String engine_on_in_motion;
    private String engine_on_in_idling;

    private Double fuel_filling;
    private Integer fuel_filling_count;
    private Double fuel_drain;
    private Integer fuel_drain_count;

    private String mobject_category_passenger_name;
    private String mobject_category_cargo_name;
    private String mobject_category_special_name;
    private String mobject_category_other_name;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Integer getMax_speed() {
        return max_speed;
    }

    public void setMax_speed(Integer max_speed) {
        this.max_speed = max_speed;
    }

    public Integer getMax_speed_violations_count() {
        return max_speed_violations_count;
    }

    public void setMax_speed_violations_count(Integer max_speed_violations_count) {
        this.max_speed_violations_count = max_speed_violations_count;
    }


    public Integer getMax_speed_violations_passenger_count() {
        return max_speed_violations_passenger_count;
    }

    public void setMax_speed_violations_passenger_count(Integer max_speed_violations_passenger_count) {
        this.max_speed_violations_passenger_count = max_speed_violations_passenger_count;
    }

    public Integer getMax_speed_violations_cargo_count() {
        return max_speed_violations_cargo_count;
    }

    public void setMax_speed_violations_cargo_count(Integer max_speed_violations_cargo_count) {
        this.max_speed_violations_cargo_count = max_speed_violations_cargo_count;
    }

    public Integer getMax_speed_violations_special_count() {
        return max_speed_violations_special_count;
    }

    public void setMax_speed_violations_special_count(Integer max_speed_violations_special_count) {
        this.max_speed_violations_special_count = max_speed_violations_special_count;
    }

    public Integer getMax_speed_violations_other_count() {
        return max_speed_violations_other_count;
    }

    public void setMax_speed_violations_other_count(Integer max_speed_violations_other_count) {
        this.max_speed_violations_other_count = max_speed_violations_other_count;
    }

    public String getParking_time() {
        return parking_time;
    }

    public void setParking_time(String parking_time) {
        this.parking_time = parking_time;
    }

    public String getEngine_on_in_motion() {
        return engine_on_in_motion;
    }

    public void setEngine_on_in_motion(String engine_on_in_motion) {
        this.engine_on_in_motion = engine_on_in_motion;
    }

    public String getEngine_on_in_idling() {
        return engine_on_in_idling;
    }

    public void setEngine_on_in_idling(String engine_on_in_idling) {
        this.engine_on_in_idling = engine_on_in_idling;
    }

    public Double getFuel_filling() {
        return fuel_filling;
    }

    public void setFuel_filling(Double fuel_filling) {
        this.fuel_filling = fuel_filling;
    }

    public Integer getFuel_filling_count() {
        return fuel_filling_count;
    }

    public void setFuel_filling_count(Integer fuel_filling_count) {
        this.fuel_filling_count = fuel_filling_count;
    }

    public Double getFuel_drain() {
        return fuel_drain;
    }

    public void setFuel_drain(Double fuel_drain) {
        this.fuel_drain = fuel_drain;
    }

    public Integer getFuel_drain_count() {
        return fuel_drain_count;
    }

    public void setFuel_drain_count(Integer fuel_drain_count) {
        this.fuel_drain_count = fuel_drain_count;
    }


    public String getMobject_category_passenger_name() {
        return mobject_category_passenger_name;
    }

    public void setMobject_category_passenger_name(String mobject_category_passenger_name) {
        this.mobject_category_passenger_name = mobject_category_passenger_name;
    }

    public String getMobject_category_cargo_name() {
        return mobject_category_cargo_name;
    }

    public void setMobject_category_cargo_name(String mobject_category_cargo_name) {
        this.mobject_category_cargo_name = mobject_category_cargo_name;
    }

    public String getMobject_category_special_name() {
        return mobject_category_special_name;
    }

    public void setMobject_category_special_name(String mobject_category_special_name) {
        this.mobject_category_special_name = mobject_category_special_name;
    }

    public String getMobject_category_other_name() {
        return mobject_category_other_name;
    }

    public void setMobject_category_other_name(String mobject_category_other_name) {
        this.mobject_category_other_name = mobject_category_other_name;
    }
}
