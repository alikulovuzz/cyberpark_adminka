package uzgps.dashboard;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.dashboard.DTO.*;
import uzgps.persistence.MObject;
import uzgps.persistence.MObjectSettings;
import uzgps.persistence.Region;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import static uzgps.common.Converters.formatListToStr;

/**
 * Created by Saidolim on 03.04.14.
 */

@SuppressWarnings("unchecked")
@Service
@Transactional
public class DashboardService {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @Transactional(readOnly = true)
    public List<Region> getRegions() {
        try {
            TypedQuery<Region> query;
            query = entityManager.createNamedQuery("Dashboard.findRegion", Region.class);
            return query.getResultList();
        } catch (Exception e) {
            logger.error("Error in getRegions", e);
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<DonutData> getMobjectTypeData(Integer regionId, List<Long> contractIds) {
        try {
            Query query;
            String queryStr = "SELECT row_number() OVER () AS  id, CASE when mot.name_ru is null then 'Не определено' " +
                    "            else mot.name_ru End  \"name\", " +
                    "       count(mo.id) " +
                    " from uzgps_mobject mo " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join uzgps_mobject_settings mos on mos.mobject_id = mo.id and mos.status = 'A' " +
                    "         join uzgps_mobject_type mot on mot.id = mos.mobject_type_id and mot._status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mo.mo_status = 'A' " +
                    " group by mot.name_ru " +
                    " order by count(mo.id) desc;";

            query = entityManager.createNativeQuery(queryStr, MobjectTypeDataImpl.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<MObject> getMobjectWithGasTypesData(Integer regionId, List<Long> contractIds, List<Long> mobjectTypesId) {
        try {
            Query query;
            String queryStr = "SELECT * " +
                    " from uzgps_mobject mo " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join uzgps_mobject_settings mos on mos.mobject_id = mo.id and mos.status = 'A' " +
                    "         join uzgps_mobject_type mot on mot.id = mos.mobject_type_id and mot._status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and mot.id in (:mobjectTypesIds) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mo.mo_status = 'A' ";

            query = entityManager.createNativeQuery(queryStr, MObject.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);
            query.setParameter("mobjectTypesIds", mobjectTypesId);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<MObjectSettings> getMobjectSettingsWithGasTypesData(Integer regionId, List<Long> contractIds, List<Long> mobjectTypesId) {
        try {
            Query query;
            String queryStr = " SELECT mos.* " +
                    " from uzgps_mobject_settings mos " +
                    "         join uzgps_mobject mo on mo.id = mos.mobject_id and mo.mo_status = 'A' " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join uzgps_mobject_type mot on mot.id = mos.mobject_type_id and mot._status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and mot.id in (:mobjectTypesIds) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mos.status = 'A' ";

            query = entityManager.createNativeQuery(queryStr, MObjectSettings.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);
            query.setParameter("mobjectTypesIds", mobjectTypesId);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<DonutData> getMobjectAppointmentData(Integer regionId, List<Long> contractIds) {
        try {
            Query query;
            String queryStr = " SELECT row_number() OVER () AS  id, " +
                    "       CASE " +
                    "           when moa.name_ru is null then 'Не определено' " +
                    "           else moa.name_ru End \"name\", " +
                    "       count(mo.id) " +
                    " from uzgps_mobject mo " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join uzgps_mobject_settings mos on mos.mobject_id = mo.id and mos.status = 'A' " +
                    "         join uzgps_mobject_appointment moa on moa.id = mos.mobject_appointment_id and moa.status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mo.mo_status = 'A' " +
                    " group by moa.name_ru " +
                    " order by count(mo.id) desc; ";

            query = entityManager.createNativeQuery(queryStr, MobjectAppointmentDataImpl.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<DonutData> getMobjectStateData(Integer regionId, List<Long> contractIds) {
        try {
            Query query;
            String queryStr = " SELECT row_number() OVER () AS  id, " +
                    "       CASE " +
                    "           when mos.name_ru is null then 'Не определено' " +
                    "           else mos.name_ru End \"name\", " +
                    "       count(mo.id) " +
                    "from uzgps_mobject mo " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join uzgps_mobject_settings moset on moset.mobject_id = mo.id and moset.status = 'A' " +
                    "         join uzgps_mobject_state mos on mos.id = moset.mobject_state_id and mos._status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mo.mo_status = 'A' " +
                    "group by mos.name_ru " +
                    "order by count(mo.id) desc; ";

            query = entityManager.createNativeQuery(queryStr, MobjectStateDataImpl.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<DonutData> getMobjectBrandData(Integer regionId, List<Long> contractIds) {
        try {
            Query query;
            String queryStr = " SELECT row_number() OVER () AS  id, " +
                    "       CASE " +
                    "           when mo.mo_type is null or mo.mo_type = '' then 'Не определено' " +
                    "           else mo.mo_type End \"name\", count(mo.id) " +
                    "from uzgps_mobject mo " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mo.mo_status = 'A' " +
                    "group by mo.mo_type " +
                    "order by count(mo.id) desc; ";

            query = entityManager.createNativeQuery(queryStr, MobjectStateDataImpl.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * @param contractId contract id
     * @return List<MonitoredZoiData>
     * @deprecated use {@link #getMobjectLocationData(String)}
     */
    @Transactional()
    public List<MonitoredZoiData> getMonitoredZoiDataOld(Long contractId) {
        try {
            Query query;
            String queryStr = " SELECT row_number() OVER () AS  id, mz.zoi_id, gf.name, day_data.count day_count, week_data.count week_count, month_data.count month_count " +
                    " from public.uzgps_monitored_zoi mz " +
                    "         inner join public.uzgps_geo_fence gf on gf.id = mz.zoi_id and gf.status = 'A' " +
                    "         inner join public.uzgps_contract cntr on cntr.id = gf.contract_id and cntr.c_status = 'A' " +
                    "         LEFT JOIN (select geofence_id, count(geofence_id) count " +
                    "                    from dashboard.get_monitored_zoi_exists(:contractId, 'day') " +
                    "                    group by geofence_id) day_data ON day_data.geofence_id = mz.zoi_id " +
                    "         LEFT JOIN (select geofence_id, count(geofence_id) count " +
                    "                    from dashboard.get_monitored_zoi_exists(:contractId, 'week') " +
                    "                    group by geofence_id) week_data ON week_data.geofence_id = mz.zoi_id " +
                    "         LEFT JOIN (select geofence_id, count(geofence_id) count " +
                    "                    from dashboard.get_monitored_zoi_exists(:contractId, 'month') " +
                    "                    group by geofence_id) month_data ON month_data.geofence_id = mz.zoi_id " +
                    " where  cntr.id = :contractId " +
                    "  and mz.status = 'A' " +
                    " order by cntr.id, gf.name; ";

            query = entityManager.createNativeQuery(queryStr, MonitoredZoiData.class);

            query.setParameter("contractId", contractId);
            query.setParameter("contractId", contractId);
            query.setParameter("contractId", contractId);
            query.setParameter("contractId", contractId);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional()
    public List<MonitoredZoiData> getMonitoredZoiData(List<Long> contractIds) {
        try {
            String contractIdsStr = formatListToStr(contractIds);

            Query query;
            String queryStr = "select row_number() OVER () AS id,  " +
                    "       mz.zoi_id zoi_id,  " +
                    "       zoi.name,  " +
                    "       m.day_count,  " +
                    "       m.week_count,  " +
                    "       m.month_count  " +
                    "from public.uzgps_monitored_zoi mz  " +
                    "         left join (select * from dashboard.view_datas_mobjects_monitored_zoi(:contractIdsStr)) m on m.mz_zone_id = mz.zoi_id  " +
                    "         left join public.uzgps_geo_fence zoi on zoi.id = mz.zoi_id  " +
                    "where mz.contract_id  in (:contractIds)  " +
                    "  and zoi.status = 'A'  " +
                    "  and mz.status = 'A'  " +
                    "order by zoi.name; ";

            query = entityManager.createNativeQuery(queryStr, MonitoredZoiData.class);

            query.setParameter("contractIdsStr", contractIdsStr);
            query.setParameter("contractIds", contractIds);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<DonutData> getMobjectTypeGasCarsTotalData(Integer regionId, List<Long> contractIds, List<Long> mobjectTypesId) {
        try {
            Query query;

            String queryStr = "SELECT row_number() OVER () AS  id, CASE when mot.name_ru is null then 'Не определено' " +
                    "            else mot.name_ru End  \"name\", " +
                    "       count(mo.id) " +
                    " from uzgps_mobject mo " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join uzgps_mobject_settings mos on mos.mobject_id = mo.id and mos.status = 'A' " +
                    "         join uzgps_mobject_type mot on mot.id = mos.mobject_type_id and mot._status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and mot.id in (:mobjectTypesIds) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mo.mo_status = 'A' " +
                    " group by mot.name_ru " +
                    " order by count(mo.id) desc;";

            query = entityManager.createNativeQuery(queryStr, MobjectTypeDataImpl.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);
            query.setParameter("mobjectTypesIds", mobjectTypesId);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<MobjectTypeDataExtendedImpl> getMobjectTypeGasCarsByContractsData(Integer regionId, List<Long> contractIds, List<Long> mobjectTypesId) {
        try {
            Query query;

            String queryStr = "SELECT row_number() OVER () AS  id," +
                    " cntr.id contract_id, " +
                    " mobject_type_id, " +
                    " CASE when mot.name_ru is null then 'Не определено' " +
                    "            else mot.name_ru End  \"name\", " +
                    "       count(mo.id) " +
                    " from uzgps_mobject mo " +
                    "         join uzgps_contract cntr on cntr.id = mo.mo_contract_id and cntr.c_status = 'A' " +
                    "         join uzgps_mobject_settings mos on mos.mobject_id = mo.id and mos.status = 'A' " +
                    "         join uzgps_mobject_type mot on mot.id = mos.mobject_type_id and mot._status = 'A' " +
                    "         join public.uzgps_mobject_gps_units mgu ON mo.id = mgu.mogu_mobject_id AND mgu.mogu_status = 'A' " +
                    "         join public.uzgps_gps_unit gu ON gu.id = mgu.mogu_gps_unit_id and gu.gu_status = 'A' " +
                    " where (cntr.customer_region = :regionId or :regionId = 0) " +
                    "  and (cntr.id in (:contractIds)) " +
                    "  and mot.id in (:mobjectTypesIds) " +
                    "  and gu.gu_block = 'A' " +
                    "  and mo.mo_status = 'A' " +
                    " group by mot.name_ru, cntr.id, mobject_type_id " +
                    " order by cntr.id, mobject_type_id;";

            query = entityManager.createNativeQuery(queryStr, MobjectTypeDataExtendedImpl.class);
            query.setParameter("regionId", regionId);
            query.setParameter("regionId", regionId);
            query.setParameter("contractIds", contractIds);
            query.setParameter("mobjectTypesIds", mobjectTypesId);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public List<DonutData> getMobjectLocationData(String contractIds, Integer regionId) {
        try {
            Query query;

            String queryStr = " SELECT id_region as       id, " +
                    "       name_region                   \"name\", " +
                    "       mobjects_in_region            count " +
                    "FROM dashboard.view_dashboard_mobjects_location_in_region( " +
                    "             :contractIds, :regionId) m " +
                    "where id_region > 0 " +
                    "order by id_region;";

            query = entityManager.createNativeQuery(queryStr, MobjectStateDataImpl.class);
            query.setParameter("contractIds", contractIds);
            query.setParameter("regionId", regionId);

            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<>();
        } catch (Exception e) {
            return null;
        }
    }

    @Transactional()
    public List<DashboardData> getOverallData(Integer regionId, String contractIds, String startDate, String endDate) {
        try {
            Query query;

            String queryStr = "SELECT row_number() OVER () AS  id, ROUND(sum(cast(m.d_distance / 1000.0 as numeric)), 2) distance, " +
                    "       max(m.ro_max_speed)   max_speed," +
                    "       max(mtc_p.name_ru) mobject_category_passenger_name, " +
                    "       max(mtc_c.name_ru) mobject_category_cargo_name, " +
                    "       max(mtc_s.name_ru) mobject_category_special_name, " +
                    "       'Остальные' mobject_category_other_name, " +
                    "       CASE when SUM(m.ro_rec_count) FILTER (WHERE category_id = 1) is not null then  SUM(m.ro_rec_count) FILTER (WHERE category_id = 1) else 0 end AS max_speed_violations_passenger_count, " +
                    "       CASE when SUM(m.ro_rec_count) FILTER (WHERE category_id = 4) is not null then  SUM(m.ro_rec_count) FILTER (WHERE category_id = 4) else 0 end AS max_speed_violations_cargo_count, " +
                    "       CASE when SUM(m.ro_rec_count) FILTER (WHERE category_id = 9) is not null then  SUM(m.ro_rec_count) FILTER (WHERE category_id = 9) else 0 end AS max_speed_violations_special_count, " +
                    "       CASE when SUM(m.ro_rec_count) FILTER (WHERE category_id not in (1, 4, 9)) is not null then  SUM(m.ro_rec_count) FILTER (WHERE category_id not in (1, 4, 9))   else 0 end AS max_speed_violations_other_count, " +
                    "       sum(m.ro_rec_count)                                                      max_speed_violations_count,        " +
                    "       to_char(CAST(sum(m.parking_time_sum) / 1000 / 60 || ' minutes' as interval)  , 'HH24:MI:SS') parking_time,  " +
                    "       to_char(CAST(sum(m.engine_on_in_motion) / 1000 / 60 || ' minutes' as interval), 'HH24:MI:SS') engine_on_in_motion,  " +
                    "       to_char(CAST(sum(m.engine_on_in_idling) / 1000 / 60 || ' minutes' as interval), 'HH24:MI:SS') engine_on_in_idling,  " +
                    "       sum(m.filling_sum)             fuel_filling, " +
                    "       sum(m.amount_filling) fuel_filling_count, " +
                    "       sum(m.drain_sum)               fuel_drain, " +
                    "       sum(m.amount_drain)   fuel_drain_count" +
                    " FROM dashboard.view_dashboard_datas_from_reports( " +
                    "             :contractIds, " +
                    "             :regionId, " +
                    "             :startDate, " +
                    "             :endDate " +
                    "         ) m inner join uzgps_mobject_type_category mtc_p on mtc_p.id = 1 " +
                    "             inner join uzgps_mobject_type_category mtc_c on mtc_c.id = 4 " +
                    "             inner join uzgps_mobject_type_category mtc_s on mtc_s.id = 9;";

            query = entityManager.createNativeQuery(queryStr, DashboardData.class);
            query.setParameter("contractIds", contractIds);
            query.setParameter("regionId", regionId);
            query.setParameter("startDate", startDate);
            query.setParameter("endDate", endDate);

            return query.getResultList();
        } catch (Exception e) {
            return null;
        }
    }

//    @Transactional(readOnly = true)
//    public List<Company> getCompanyNames(Integer regionId) {
//        try {
//            TypedQuery<Company> query;
//            query = entityManager.createNamedQuery("Dashboard.findMobjectType", Company.class);
//            query.setParameter("regionId", regionId);
//
//            return query.getResultList();
//        } catch (NoResultException e) {
//            return null;
//        }
//    }
}
