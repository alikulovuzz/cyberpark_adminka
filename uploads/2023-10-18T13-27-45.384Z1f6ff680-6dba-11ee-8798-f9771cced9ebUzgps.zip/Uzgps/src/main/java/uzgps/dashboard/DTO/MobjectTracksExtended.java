package uzgps.dashboard.DTO;

import uz.netex.datatype.MobjectTracks;

public class MobjectTracksExtended extends MobjectTracks {

    private Long mobjectTypeId;
    private String mobjectTypeName;


    public Long getMobjectTypeId() {
        return mobjectTypeId;
    }

    public void setMobjectTypeId(Long mobjectTypeId) {
        this.mobjectTypeId = mobjectTypeId;
    }

    public String getMobjectTypeName() {
        return mobjectTypeName;
    }

    public void setMobjectTypeName(String mobjectTypeName) {
        this.mobjectTypeName = mobjectTypeName;
    }

    @Override
    public String toString() {
        return "MobjectTracksExtended{" +
                "mobjectTypeId=" + mobjectTypeId +
                ", mobjectTypeName='" + mobjectTypeName + '\'' +
                '}';
    }
}
