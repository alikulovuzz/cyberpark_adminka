package uzgps.dashboard.DTO;

import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Immutable
@Table(schema = "dashboard")
public class MonitoredZoiData {

    @Id
    private Long id;

    private Long zoi_id;

    private String name;

    private Integer day_count;
    private Integer week_count;
    private Integer month_count;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getZoi_id() {
        return zoi_id;
    }

    public void setZoi_id(Long zoi_id) {
        this.zoi_id = zoi_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getDay_count() {
        return day_count;
    }

    public void setDay_count(Integer day_count) {
        this.day_count = day_count;
    }

    public Integer getWeek_count() {
        return week_count;
    }

    public void setWeek_count(Integer week_count) {
        this.week_count = week_count;
    }

    public Integer getMonth_count() {
        return month_count;
    }

    public void setMonth_count(Integer month_count) {
        this.month_count = month_count;
    }
}
