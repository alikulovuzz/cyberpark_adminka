package uzgps.main;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.routing.core.CoreTripRoutingControl;
import uz.netex.uzgps.billing.lib.BillingController;
import uzgps.admin.AdminController;
import uzgps.admin.AdminReportController;
import uzgps.admin.AdminService;
import uzgps.common.CommonUtils;
import uzgps.common.Converters;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.UrlConfiguration;
import uzgps.dashboard.DashboardController;
import uzgps.map.GeoFenceController;
import uzgps.map.MonitoringController;
import uzgps.map.POIController;
import uzgps.map.TrackingController;
import uzgps.message.MessageController;
import uzgps.persistence.*;
import uzgps.report.ReportController;
import uzgps.route.RouteControlController;
import uzgps.security.AuthToBilling;
import uzgps.security.SecurityLoggedUser;
import uzgps.settings.SettingsService;
import uzgps.trafficSchedule.TrafficScheduleController;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import static uzgps.common.UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN_STR;
import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

/**
 * Created by Gayratjon on 3/20/14 12:22 12:22.
 */
@Controller
public class MainController {

    private final Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    MonitoringController monitoringController;

    @Autowired
    TrackingController trackingController;

    @Autowired
    POIController poiController;

    @Autowired
    GeoFenceController geoFenceController;

    @Autowired
    MessageController messageController;

    @Autowired
    ReportController reportController;

    @Autowired
    TrafficScheduleController trafficScheduleController;

    @Autowired
    SettingsService settingsService;

    @Autowired
    CoreMain coreMain;

    @Autowired
    ObjectMapper jsonMapper;

    @Autowired
    AdminService adminService;

    @Autowired
    BillingController billingController;

    public final static String URL_MAIN = "/main.htm";
    public final static String URL_MAP = "/map.htm";
    public final static String URL_MESSAGE = "/message.htm";
    public final static String URL_REPORT = "/report.htm";
    public final static String VIEW_MAIN = "main/main";

    public final static String URL_ACCESS_BLOCKED = "security/accessBlocked.htm";
    public final static String VIEW_ACCESS_BLOCKED = "security/accessBlocked";

    public final static String URL_CONTRACT_DETERMINED = "security/contractDetermined.htm";
    public final static String VIEW_CONTRACT_DETERMINED = "security/contractDetermined";

    private final static String SESSION_ACTIVE_TOP_MENU = "sessionActiveTopMenu";
    private final static String SESSION_ACTIVE_MESSAGE_TAB_MENU = "sessionActiveMessageTabMenu";
    public final static String SESSION_CONTRACT_SETTINGS = "sessionContractSettings";
    public final static String SESSION_USER_ACCESS_LIST = "sessionUserAccessList";
    private final static String SESSION_CONTRACT_ID = "sessionContractId";
    private final static String SESSION_CONTRACT = "sessionContract";
    public final static String SESSION_CONTRACTS = "sessionContracts";
    public final static String SESSION_SHOW_OBJECTS_OF_ALL_CONTRACTS = "sessionShowObjectsOfAllContracts";
    public final static String SESSION_ACCESS_TO_DASHBOARD_BY_ALL_CONTRACTS = "sessionAccessToDashboardByAllContracts";

    private final static String URL_SELECT_USER_CONTRACT = "/main/select-contract.htm";
    private final static String VIEW_SELECT_USER_CONTRACT = "select-contract/select-contract";

    //    public final static String COOKIE_DOMAIN = "uzgps.uz";
    public final static String COOKIE_APP_LAST_STATUS = "status";
    private final static int COOKIE_APP_LAST_STATUS_EXPIRE_DAY = 14 * 24 * 60 * 60; // 14 days in seconds

    public final static int REQUEST_INTERVAL_MIN = 1; // in seconds
    public final static int REQUEST_INTERVAL_MAX = 300; // in seconds

    @RequestMapping(value = URL_MAIN)
    public ModelAndView processMain(@CookieValue(value = COOKIE_APP_LAST_STATUS, defaultValue = "") String appStatus,
                                    HttpSession session, HttpServletResponse response, Locale locale,
                                    @RequestParam(value = "contract-id", required = false) String selectedContractIdStr,
                                    @RequestParam(value = "monitoring-all-contracts", required = false, defaultValue = "0") String isShowObjectsOfAllContractsStr,
                                    @RequestParam(value = "dashboard-all-contracts", required = false, defaultValue = "0") String accessToDashboardByAllContractsStr,
                                    @RequestParam(value = "build-track", required = false, defaultValue = "0") String buildTrackStr,
                                    @RequestParam(value = "object-id", required = false, defaultValue = "0") String objectIdStr
    )
            throws ServletException, IOException {

//        if (currentSession == null) {
//            currentSession = session;
//        } else if (!getSessionIsValid()) {
//            // if session is not null and invalidated after logout - set new session
////            currentSession = session;
//            setCurrentSession(session);
//        }

        String redirectUrl = getRedirectUrl();
        if (redirectUrl != null) {
            return new ModelAndView("redirect:" + redirectUrl);
        }

        // Redirect to Billing System if user in not in role CustomerAdmin and User
        if (!MainController.getUser().getRoleId().equals(UZGPS_CONST.USER_ROLE_USER) &&
                !MainController.getUser().getRoleId().equals(UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN) &&
                getUserContractId(session) == null) {
            return new ModelAndView("redirect:" + AuthToBilling.URL_AUTH_TO_BILLING_MAIN);
        }

        User user = getUser();

        if (logger.isDebugEnabled())
            logger.debug("authenticated user id: {}, login: {}", user.getId(), user.getLogin());

        // Get User's objects in core
        coreMain.makeUserMobjectAccessMapByUserId(user.getId());

        // Get User's objects in core
        coreMain.makeUserPoiAccessMapByUserId(user.getId());

        // Get User's objects in core
        coreMain.makeUserZoiAccessMapByUserId(user.getId());

        Long selectedContractId = Converters.strToLong(selectedContractIdStr, 0L);
        Integer isShowObjectsOfAllContracts = Converters.strToInt(isShowObjectsOfAllContractsStr, 0);
        Integer accessToDashboardByAllContracts = Converters.strToInt(accessToDashboardByAllContractsStr, 0);
        Integer buildTrack = Converters.strToInt(buildTrackStr, 0);
        Integer objectId = Converters.strToInt(objectIdStr, 0);

        Long contractId = null;
        if (selectedContractId.equals(0L) && getUserContractId(session) != null) {
            contractId = getUserContractId(session);
        } else {
            if (selectedContractId.equals(0L)) {
                int userContractsCount = getUserContractsCount(user.getId());
                // if a logged user have access to more than 1 contract, he must choose one of contract
                if (userContractsCount > 1) {
                    return new ModelAndView("redirect:" + URL_SELECT_USER_CONTRACT + "?user-id=" + user.getId());
                } else if (userContractsCount == 1) {
                    List<Contract> contracts = getUserContracts(user.getId());
                    if (contracts != null && contracts.size() == 1) {
                        contractId = contracts.get(0).getId();
                    }
                }
            } else {
                contractId = selectedContractId;
            }

            // Add contractId to session
            setUserContractId(contractId, session);
            // Add contract to session
            setUserContract(adminService.getContractById(contractId), session);

            if (isShowObjectsOfAllContracts.equals(1)) {
                // Add contracts to session
                setUserContracts(getUserContracts(user.getId()), session);
                // Add ShowObjectsOfAllContracts value to session
                setIsShowObjectsByAllContracts(isShowObjectsOfAllContracts, session);
            }

            if (accessToDashboardByAllContracts.equals(1)) {
                // Add contracts to session
                setUserContracts(getUserContracts(user.getId()), session);
                // Add ShowObjectsOfAllContracts  to session and redirect to dashboard
                setAccessToDashboardByAllContracts(accessToDashboardByAllContracts, session);
            }

        }

        // if a logged user doesn't have contract id, that means it's Admin user
        if (contractId == null) {
            return new ModelAndView("redirect:" + AdminController.URL_ADMIN_MAIN);
        } else {
            // Check contract status
            if (isContractBlocked(session, contractId)) {
                if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
                    return new ModelAndView("redirect:" + URL_CONTRACT_DETERMINED);
                } else {
                    String authToken;
                    String cabinetUrl = (String) session.getAttribute("url_cabinet");

                    if (cabinetUrl == null) {
                        cabinetUrl = UrlConfiguration.getUrlCabinetPublic();
                    }

                    if (MainController.getUser().getRoleId().equals(UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN)) {
                        authToken = getUser().getAuthToken();
                    } else {
                        authToken = getUser().getInterfaceAuthToken();
                    }

                    String lang = LocaleContextHolder.getLocale().getLanguage();

                    return new ModelAndView("redirect:" + cabinetUrl +
                            "?code=" + authToken +
                            "&cid=" + contractId +
                            "&lang=" + lang
                    );
                }

            }
        }

        ContractSettings contractSettings = getContractSettings(session);
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);

            if (!isAppLastStatusSaveEnabled(contractSettings)) {
                appLastStatus.setActiveAppTab(null);
                appLastStatus.setActiveMapTab(null);
                appLastStatus.setActiveMessageTab(null);
                appLastStatus.setMapMobjectListType(MonitoringController.MonitoringObjectSelectionOption.KEY_MONITORING_OBJECTS_ALL);
                appLastStatus.setMessageMobjectListType(MonitoringController.MonitoringObjectSelectionOption.KEY_MONITORING_OBJECTS_ALL);

                if (appLastStatus.getMapUnselectedMobjectList() != null)
                    appLastStatus.getMapUnselectedMobjectList().clear();

                if (appLastStatus.getMapUnselectedGroupedMobjectList() != null)
                    appLastStatus.getMapUnselectedGroupedMobjectList().clear();

                if (appLastStatus.getMapUnselectedZonedMobjectList() != null)
                    appLastStatus.getMapUnselectedZonedMobjectList().clear();

                if (appLastStatus.getMessageUnselectedMobjectList() != null)
                    appLastStatus.getMessageUnselectedMobjectList().clear();

                if (appLastStatus.getMessageUnselectedGroupedMobjectList() != null)
                    appLastStatus.getMessageUnselectedGroupedMobjectList().clear();

                if (appLastStatus.getPoiList() != null)
                    appLastStatus.getPoiList().clear();

                if (appLastStatus.getGeoFenceList() != null)
                    appLastStatus.getGeoFenceList().clear();
            }
        }

        ModelAndView modelAndView = null;
        String activeMapTabMenu;

        String activeTopMenu = (String) session.getAttribute(SESSION_ACTIVE_TOP_MENU);
        session.removeAttribute(SESSION_ACTIVE_TOP_MENU);

        String activeMessageTabMenu = (String) session.getAttribute(SESSION_ACTIVE_MESSAGE_TAB_MENU);
        session.removeAttribute(SESSION_ACTIVE_MESSAGE_TAB_MENU);

        if (activeTopMenu == null)
            activeTopMenu = appLastStatus.getActiveAppTab();

        activeMapTabMenu = appLastStatus.getActiveMapTab();

        if (activeMessageTabMenu == null)
            activeMessageTabMenu = appLastStatus.getActiveMessageTab();

        UserAccessList userAccessList = getUserAccessList(session);

        if (userAccessList != null && contractSettings != null) {

            if (accessToDashboardByAllContracts == 1) {
                String lang = LocaleContextHolder.getLocale().getLanguage();

                String dashboardUrl = (String) session.getAttribute("url_uzgps_bus");
                return new ModelAndView("redirect:" + dashboardUrl +
                        "?code=" + getUser().getAuthToken() +
                        "&cid=-1" +
                        "&lang=" + lang
                );
            }

            if (buildTrack.equals(1) && (objectId != null && objectId > 0)) {
                activeTopMenu = "map";
                activeMapTabMenu = "tracking";
            }

            // If in top tab menu routing is selected previously,
            // then we should redirect the view
            if (activeTopMenu != null
                    && activeTopMenu.equalsIgnoreCase("route")
                    && userAccessList.getRouting() > 0) {
                return new ModelAndView("redirect:" + RouteControlController.URL_ROUTE_CONTROL_MAIN);
            }

            // If in top tab menu dashboard is selected previously,
            // then we should redirect the view
            if (activeTopMenu != null
                    && activeTopMenu.equalsIgnoreCase("dashboard")
                    && userAccessList.getDashboard() > 0) {
                return new ModelAndView("redirect:" + DashboardController.URL_DASHBOARD_MAIN);
            }

            int fullAccess = userAccessList.getMap() | userAccessList.getMessage() | userAccessList.getReport() | userAccessList.getRouting() | userAccessList.getDashboard();

            if (fullAccess > 0) {
                modelAndView = new ModelAndView(VIEW_MAIN);

                int fullMonitoringAccess = userAccessList.getMap();

                int numNotification = 0;

                if (appLastStatus.getActiveAppTab() != null) {
                    if (appLastStatus.getActiveAppTab().equalsIgnoreCase("map") && fullMonitoringAccess == 0) {
                        activeTopMenu = null;
                    } else if (appLastStatus.getActiveAppTab().equalsIgnoreCase("message") && userAccessList.getMessage() == 0) {
                        activeTopMenu = null;
                    } else if (appLastStatus.getActiveAppTab().equalsIgnoreCase("report") && userAccessList.getReport() == 0) {
                        activeTopMenu = null;
                    } else if (appLastStatus.getActiveAppTab().equalsIgnoreCase("trafficSchedule") && userAccessList.getTrafficSchedule() == 1) {
                        activeTopMenu = null;
                    } else if (appLastStatus.getActiveAppTab().equalsIgnoreCase("route") && userAccessList.getRouting() == 0 ||
                            appLastStatus.getActiveAppTab().equalsIgnoreCase("dashboard") && userAccessList.getDashboard() == 0) {
                        activeTopMenu = null;
                        activeMapTabMenu = null;
                    }
                }

                if (fullMonitoringAccess > 0) {
                    if (appLastStatus.getActiveMapTab() != null) {
                        if (appLastStatus.getActiveMapTab().equalsIgnoreCase("monitoring") && userAccessList.getMonitoring() == 0)
                            activeMapTabMenu = null;
                        else if (appLastStatus.getActiveMapTab().equalsIgnoreCase("tracking") && userAccessList.getTracker() == 0)
                            activeMapTabMenu = null;
                        else if (appLastStatus.getActiveMapTab().equalsIgnoreCase("poi") && userAccessList.getPoi() == 0)
                            activeMapTabMenu = null;
                        else if (appLastStatus.getActiveMapTab().equalsIgnoreCase("geozone") && userAccessList.getGeoZone() == 0)
                            activeMapTabMenu = null;
                    }

                    if (activeTopMenu == null)
                        activeTopMenu = "map";

                    if (userAccessList.getMonitoring() > 0) {
                        if (activeMapTabMenu == null)
                            activeMapTabMenu = "monitoring";

                        if (appLastStatus.getMapMobjectListType() == null) {
                            appLastStatus.setMapMobjectListType(MonitoringController.MonitoringObjectSelectionOption.KEY_MONITORING_OBJECTS_ALL);
                        }
                        numNotification = contractSettings.getTooltipsViewQuantity().intValue();
                        monitoringController.processMapMonitoringModel(session, modelAndView, appLastStatus.getMapMobjectListType());
                    }

                    if (userAccessList.getTracker() > 0) {
                        if (activeMapTabMenu == null)
                            activeMapTabMenu = "tracking";
                        trackingController.processMapTrackingModel(modelAndView, session);
                    }
                    Boolean poiLoadStartup = contractSettings.getPoiLoadStartup();
                    Boolean geozoneLoadStartup = contractSettings.getGeozoneLoadStartup();
                    if (userAccessList.getPoi() > 0) {
                        if (activeMapTabMenu == null) {
                            activeMapTabMenu = "poi";
                        }
                        if (poiLoadStartup) {
                            poiController.processMapPOIModel(modelAndView, session);
                        }
                    }
                    if (userAccessList.getGeoZone() > 0) {
                        if (activeMapTabMenu == null) {
                            activeMapTabMenu = "geozone";
                        }
                        if (geozoneLoadStartup) {
                            geoFenceController.processMapGeoFenceModel(modelAndView, session);
                        }
                    }

                    modelAndView.addObject("mapType", contractSettings.getMapType());
                } else {
                    activeMapTabMenu = null;
                }

                if (userAccessList.getMessage() > 0) {
                    if (activeTopMenu == null)
                        activeTopMenu = "message";

                    if (activeMessageTabMenu == null)
                        activeMessageTabMenu = "message";

                    if (appLastStatus.getMessageMobjectListType() == null)
                        appLastStatus.setMessageMobjectListType(MonitoringController.MonitoringObjectSelectionOption.KEY_MONITORING_OBJECTS_ALL);

                    numNotification = contractSettings.getTooltipsViewQuantity().intValue();

                    if (userAccessList.getMonitoring() <= 0) {
                        monitoringController.processMapMonitoringModel(session, modelAndView, appLastStatus.getMessageMobjectListType());
                    }

                    messageController.processMessageModel(modelAndView);

                    if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)
                            || MainController.getUserRole().equalsIgnoreCase(USER_ROLE_CUSTOMER_ADMIN_STR)) {
                        if (appLastStatus.getUnseenNotificationsLastTime() > 0) {
                            modelAndView.addObject("lastAlertNotificationTime", appLastStatus.getUnseenNotificationsLastTime());
                        }
                    }
                } else {
                    activeMessageTabMenu = null;

                    if (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                            || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                            || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                            || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                            || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                            || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                            || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                            || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")) {

                        // Long lastTime = coreMain.getNotificationUnitLastTime(getUser().getContractId());
                        long lastTime = System.currentTimeMillis();
                        if (lastTime > 0)
                            modelAndView.addObject("lastAlertNotificationTime", lastTime);
                        else
                            modelAndView.addObject("lastAlertNotificationTime", null);

                    } else {
                        if (!modelAndView.getModel().containsKey("lastAlertNotificationTime")) {
                            modelAndView.addObject("lastAlertNotificationTime", appLastStatus.getUnseenNotificationsLastTime());
                        }
                    }
                }

                if (userAccessList.getReport() > 0) {
                    if (activeTopMenu == null)
                        activeTopMenu = "report";
                    reportController.processReportModel(session, modelAndView, locale, AdminReportController.REPORT_CATEGORY_COMMON);
                }

                if (userAccessList.getTrafficSchedule() > 0) {
                    if (activeTopMenu != null
                            && activeTopMenu.equalsIgnoreCase("trafficSchedule")
                            && userAccessList.getTrafficSchedule() > 0) {
                        return new ModelAndView("redirect:" + TrafficScheduleController.URL_TRAFFIC_SCHEDULE_MAIN);
                    }

//                    trafficScheduleController.processTrafficScheduleModel(session, modelAndView, locale, AdminReportController.REPORT_CATEGORY_COMMON);
                }

                modelAndView.addObject("userAccessList", userAccessList);
                modelAndView.addObject("numNotification", numNotification);
                modelAndView.addObject("appLastStatus", appLastStatus);

                int requestIntervalTime = REQUEST_INTERVAL_MIN;

                if (contractSettings.getMonitoringRefreshInterval() > REQUEST_INTERVAL_MIN) {
                    requestIntervalTime = contractSettings.getMonitoringRefreshInterval();
                }

                if (contractSettings.getMonitoringRefreshInterval() >= REQUEST_INTERVAL_MAX) {
                    requestIntervalTime = REQUEST_INTERVAL_MAX;
                }

                requestIntervalTime *= 1000;

                modelAndView.addObject("requestIntervalTime", requestIntervalTime);
            } else {
                activeTopMenu = null;
            }
        }

        if (modelAndView == null) {
            session.removeAttribute(SESSION_CONTRACT_SETTINGS);
            session.removeAttribute(SESSION_USER_ACCESS_LIST);
            modelAndView = new ModelAndView("redirect:" + URL_ACCESS_BLOCKED);
        } else {

            addBillingInfo(modelAndView, contractId);

            if (user.getPhotoId() != null) {
                if (user.getPhoto() != null)
                    modelAndView.addObject("avatarFileUrl", user.getPhoto().getFileUrl());
                modelAndView.addObject("userFullName", user.getName() + " " + user.getSurName());
            }

            appLastStatus.setActiveAppTab(activeTopMenu);
            appLastStatus.setActiveMapTab(activeMapTabMenu);
            appLastStatus.setActiveMessageTab(activeMessageTabMenu);

            modelAndView.addObject("activeTopMenu", activeTopMenu);
            modelAndView.addObject("activeMapTabMenu", activeMapTabMenu);
            modelAndView.addObject("activeMessageTabMenu", activeMessageTabMenu);

            if (isShowObjectsOfAllContracts.equals(1)) {
                modelAndView.addObject("companyName", getUserContract(session).getCompany().getName());
            } else {
                modelAndView.addObject("companyName", getUserContract(session).getCustomerCompanyName());
            }

            modelAndView.addObject("userLogin", user.getLogin());
            modelAndView.addObject("hasRoutingAccess", CoreTripRoutingControl.hasAccess());

            if (buildTrack.equals(1) && (objectId != null && objectId > 0)) {
                modelAndView.addObject("objectId", objectId);
                modelAndView.addObject("needBuildTrack", 1);
            }

            Cookie cookie = new Cookie(COOKIE_APP_LAST_STATUS, CommonUtils.serializeStatus(jsonMapper, appLastStatus));
            cookie.setMaxAge(COOKIE_APP_LAST_STATUS_EXPIRE_DAY);
            response.addCookie(cookie);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_MAP)
    public ModelAndView processMainViaMap(HttpSession session) throws ServletException, IOException {
        session.setAttribute(SESSION_ACTIVE_TOP_MENU, "map");
        return new ModelAndView("redirect:" + URL_MAIN);
    }

    @RequestMapping(value = URL_MESSAGE)
    public ModelAndView processMainViaMessage(HttpSession session, @RequestParam(value = "tab", required = false) String activeTab) throws
            ServletException, IOException {
        if (activeTab == null)
            activeTab = "message";

        session.setAttribute(SESSION_ACTIVE_TOP_MENU, "message");
        session.setAttribute(SESSION_ACTIVE_MESSAGE_TAB_MENU, activeTab);
        return new ModelAndView("redirect:" + URL_MAIN);
    }

    @RequestMapping(value = URL_REPORT)
    public ModelAndView processMainViaReport(HttpSession session) {
        session.setAttribute(SESSION_ACTIVE_TOP_MENU, "report");
        return new ModelAndView("redirect:" + URL_MAIN);
    }

    @RequestMapping(value = URL_ACCESS_BLOCKED)
    public ModelAndView processAccessBlocker() throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_ACCESS_BLOCKED);
        modelAndView.addObject("urlBilling", UrlConfiguration.getUrlBilling());

        return modelAndView;
    }

    @RequestMapping(value = URL_CONTRACT_DETERMINED)
    public ModelAndView processContractDetermined() throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_CONTRACT_DETERMINED);
        modelAndView.addObject("urlBilling", UrlConfiguration.getUrlBilling());

        return modelAndView;
    }

    @RequestMapping(value = URL_SELECT_USER_CONTRACT)
    public ModelAndView selectContract(@RequestParam(value = "user-id", required = false) String userIdStr)
            throws ServletException, IOException {
        ModelAndView modelAndView = new ModelAndView(VIEW_SELECT_USER_CONTRACT);

        Long userId = Converters.strToLong(userIdStr, 0L);

        List<Contract> userContracts = getUserContracts(userId);

        modelAndView.addObject("userContracts", userContracts);
        modelAndView.addObject("userRoleId", getUser().getRoleId());
        return modelAndView;
    }

    private static String getRedirectUrl() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();
        String redirectTo = securityLoggedUser.getRedirectTo();

        securityLoggedUser.setRedirectTo(null);

        if (redirectTo != null && !redirectTo.isEmpty()) {
            return redirectTo;
        }

        return null;
    }

    public static void replaceUserInSession(Contract contract, Long interfaceUserId, FileStorage photo, String name, String
            surname, String middleName) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();

        securityLoggedUser.setUserData(contract, interfaceUserId, photo, name, surname, middleName);
    }

    public static void replaceCustomerAdminInSession(User customerAdmin) {
        if (customerAdmin != null && customerAdmin.getId() != null) {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();

            User user = securityLoggedUser.getUser();
            if (user != null) {
                user.setInterfaceContractId(customerAdmin.getContractId());
                user.setContract(customerAdmin.getContract());
                user.setInterfaceAuthToken(customerAdmin.getAuthToken());
            }

        }
    }

    public ContractSettings getContractSettings(HttpSession session) {
        ContractSettings contractSettings = null;

        if (session != null) {
            contractSettings = (ContractSettings) session.getAttribute(SESSION_CONTRACT_SETTINGS);

            if (contractSettings == null) {
                if (logger.isDebugEnabled())
                    logger.debug("ContractSettings is not available in session, then getting it from DB...");
                contractSettings = settingsService.getContractSettingsByContractId(getUserContractId(session));
                session.setAttribute(SESSION_CONTRACT_SETTINGS, contractSettings);
            }
        }

        return contractSettings;
    }

    public UserAccessList getUserAccessList(HttpSession session) {
        UserAccessList userAccessList = (UserAccessList) session.getAttribute(SESSION_USER_ACCESS_LIST);
        if (userAccessList == null) {
            userAccessList = settingsService.getUserAccessListByUserContractId(getUser().getInterfaceUserId(),
                    getUserContractId(session));

            if (getUser().getRoleId() > 2) {
                UserRole defaultCustomerAdmin = adminService.getDefaultCustomerAdminByContractId(getUserContractId(session));
                UserAccessList customerAdminAccessList = null;

                if (defaultCustomerAdmin != null) {
                    customerAdminAccessList = settingsService.getUserAccessListByUserContractId(defaultCustomerAdmin.getUserId(),
                            defaultCustomerAdmin.getContractId());
                }

                if (userAccessList != null && customerAdminAccessList != null) {
                    userAccessList.setMap(userAccessList.getMap() & customerAdminAccessList.getMap());
                    userAccessList.setMonitoring(userAccessList.getMonitoring() & customerAdminAccessList.getMonitoring());
                    userAccessList.setTracker(userAccessList.getTracker() & customerAdminAccessList.getTracker());
                    userAccessList.setPoi(userAccessList.getPoi() & customerAdminAccessList.getPoi());
                    userAccessList.setGeoZone(userAccessList.getGeoZone() & customerAdminAccessList.getGeoZone());
//                    userAccessList.setTrackStatistics(userAccessList.getTrackStatistics() & customerAdminAccessList.getTrackStatistics());
                    userAccessList.setMessage(userAccessList.getMessage() & customerAdminAccessList.getMessage());
                    userAccessList.setReport(userAccessList.getReport() & customerAdminAccessList.getReport());
                    userAccessList.setDashboard(customerAdminAccessList.getDashboard());
                    userAccessList.setFms(customerAdminAccessList.getFms());
                    userAccessList.setRouting(customerAdminAccessList.getRouting());

                    userAccessList.setSettings(customerAdminAccessList.getSettings());
                    userAccessList.setSettingsMap(customerAdminAccessList.getSettingsMap());
                    userAccessList.setSettingsMonitoring(customerAdminAccessList.getSettingsMonitoring());
                    userAccessList.setSettingsObject(customerAdminAccessList.getSettingsObject());
                    userAccessList.setSettingsGroup(customerAdminAccessList.getSettingsGroup());
                    userAccessList.setSettingsStaff(customerAdminAccessList.getSettingsStaff());
                    userAccessList.setSettingsUsers(customerAdminAccessList.getSettingsUsers());
                    userAccessList.setSettingsNotifications(customerAdminAccessList.getSettingsNotifications());
                    userAccessList.setSettingsDisplayData(customerAdminAccessList.getSettingsDisplayData());
                    userAccessList.setSettingsDashboard(customerAdminAccessList.getSettingsDashboard());
                    userAccessList.setSettingsUserPoiZoiAccess(customerAdminAccessList.getSettingsUserPoiZoiAccess());
                    userAccessList.setSettingsExternalServices(customerAdminAccessList.getSettingsExternalServices());

                }
            }
            session.setAttribute(SESSION_USER_ACCESS_LIST, userAccessList);
        }
        return userAccessList;
    }

    private boolean isAppLastStatusSaveEnabled(ContractSettings contractSettings) {
        if (contractSettings != null) {
            if (MainController.getUserRole().equalsIgnoreCase("ROLE_SYSADMIN")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_OPERATOR")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_CUSTOMER_CARE")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_INSTALLER")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_SALE")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_AGENT")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_ACCOUNTANT")
                    || MainController.getUserRole().equalsIgnoreCase("ROLE_ADMIN")) {
                return false;
            }

            return contractSettings.getSaveCurrentPosition();
        }

        return false;
    }

    public static Long getUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();
            User user = securityLoggedUser.getUser();
            return user.getId();
        }

        return null;
    }

    public static Long getInterfaceUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();
            User user = securityLoggedUser.getUser();
            return user.getInterfaceUserId();
        }

        return null;
    }

    public static User getUser() {
        SecurityLoggedUser securityLoggedUser = null;
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();
        } catch (Exception e) {
            return null;
        }

        return securityLoggedUser.getUser();
    }

    public static String getUserRole() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        SecurityLoggedUser securityLoggedUser = (SecurityLoggedUser) authentication.getPrincipal();
        Iterator<GrantedAuthority> authorityIterator = securityLoggedUser.getAuthorities().iterator();
        String role = null;

        while (authorityIterator.hasNext()) {
            GrantedAuthority grantedAuthority = authorityIterator.next();
            role = grantedAuthority.getAuthority();
            break;
        }

        return role;
    }

    public static boolean getIsShowObjectsOfAllContracts(HttpSession session) {
        if (session != null) {
            Boolean isShowObjectsOfAllContracts = (Boolean) session.getAttribute(SESSION_SHOW_OBJECTS_OF_ALL_CONTRACTS);

            if (isShowObjectsOfAllContracts == null) {
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    public static boolean getAccessToDashboardByAllContracts(HttpSession session) {
        if (session != null) {
            Boolean accessToDashboardByAllContracts = (Boolean) session.getAttribute(SESSION_ACCESS_TO_DASHBOARD_BY_ALL_CONTRACTS);

            if (accessToDashboardByAllContracts == null) {
                return false;
            } else {
                return true;
            }
        }
        return false;
    }

    public static void setIsShowObjectsByAllContracts(Integer isShowObjectsOfAllContracts, HttpSession session) {
        if (session != null) {
            if (isShowObjectsOfAllContracts.equals(0)) {
                session.setAttribute(SESSION_SHOW_OBJECTS_OF_ALL_CONTRACTS, false);
            } else if (isShowObjectsOfAllContracts.equals(1)) {
                session.setAttribute(SESSION_SHOW_OBJECTS_OF_ALL_CONTRACTS, true);
            }
        }
    }

    private static void setAccessToDashboardByAllContracts(Integer accessToDashboardByAllContracts, HttpSession session) {
        if (session != null) {
            if (accessToDashboardByAllContracts.equals(0)) {
                session.setAttribute(SESSION_ACCESS_TO_DASHBOARD_BY_ALL_CONTRACTS, false);
            } else if (accessToDashboardByAllContracts.equals(1)) {
                session.setAttribute(SESSION_ACCESS_TO_DASHBOARD_BY_ALL_CONTRACTS, true);
            }
        }
    }

    /**
     * Get count of user contracts
     */
    private int getUserContractsCount(Long userId) {
        return adminService.getUserContractsCount(userId).intValue();
    }

    /**
     * Get user contracts
     *
     * @return List<Contract>
     */
    private List<Contract> getUserContracts(Long userId) {
        return adminService.getUserContractsByUserId(userId);
    }


    /**
     * Get user contractId from session
     */
    public static Long getUserContractId(HttpSession session) {
        if (session != null) {
            return (Long) session.getAttribute(SESSION_CONTRACT_ID + getInterfaceUserId());
        }
        return null;
    }

    /**
     * Set user contractId to session
     */
    public static void setUserContractId(Long contractId, HttpSession session) {
        if (session != null) {
            session.setAttribute(SESSION_CONTRACT_ID + getInterfaceUserId(), contractId);
        }
    }

    /**
     * Get user contract from session
     */
    public static Contract getUserContract(HttpSession session) {
        if (session != null) {
            return (Contract) session.getAttribute(SESSION_CONTRACT);
        }
        return null;
    }

    /**
     * Get contract from session
     */
    public static void setUserContract(Contract contract, HttpSession session) {
        if (session != null) {
            session.setAttribute(SESSION_CONTRACT, contract);
        }
    }

    public static List<Long> getUserContractsIds(HttpSession session) {
        if (session != null && getUserContracts(session) != null) {
            List<Long> contractsIds = new ArrayList<>();
            List<Contract> contracts = MainController.getUserContracts(session);
            for (Contract contract : contracts) {
                contractsIds.add(contract.getId());
            }
            return contractsIds;
        }
        return null;
    }


    /**
     * Get contracts from session
     */
    public static void setUserContracts(List<Contract> contracts, HttpSession session) {
        if (session != null) {
            session.setAttribute(SESSION_CONTRACTS, contracts);
        }
    }

    /**
     * Get user contracts from session
     */
    @SuppressWarnings("unchecked")
    public static List<Contract> getUserContracts(HttpSession session) {
        if (session != null) {
            return (List<Contract>) session.getAttribute(SESSION_CONTRACTS);
        }
        return null;
    }

    /**
     * Return is user contractId equals mobject contractId
     */
    public static Boolean getUserContractEqualsMobjectContract(HttpSession session, Long mobjectContractId) {
        if (session != null) {
            return getUserContractId(session).equals(mobjectContractId);
        }
        return false;
    }

    /**
     * Return is user accessed contract ids equals mobject contractId
     */
    public static Boolean getUserContractsHasMobjectContract(HttpSession session, Long mobjectContractId) {
        if (session != null) {
            List<Contract> userContracts = getUserContracts(session);
            for (Contract contract : userContracts) {
                if (contract.getId().equals(mobjectContractId)) return true;
            }
        }
        return false;
    }

    /**
     * Add billing data to model
     * Current account balance
     * Expected days to block
     *
     * @param modelAndView what to show in screen
     * @param contractId
     */
    private void addBillingInfo(ModelAndView modelAndView, Long contractId) {

        if (contractId > 0) {
//            uz.netex.uzgps.billing.lib.database.tables.ContractSettings contractSettings = billingController.dbContractSettings.getContractSettingsByContractId(contractId);
//        String expectedBlockDate = billingController.helper.getExpectedCustomerBlockDate(contractId);

//            if (getUserRole().equalsIgnoreCase(ROLE_CUSTOMER_ADMIN_STR)) {

//                Timestamp expectedBlockDate = billingController.dbContract.getExpectedBlockDate(contractId, LocaleContextHolder.getLocale().getLanguage());
//                String expectedBlockDateStr = Converters.dateFormatterTimestampToStringSimple(expectedBlockDate);

            Long daysBeforeBlock = billingController.dbContract.getDaysToBlockDate(contractId);

            if (daysBeforeBlock != null && daysBeforeBlock >= 0) {
                modelAndView.addObject("hasDaysBeforeBlock", true);
                modelAndView.addObject("daysBeforeBlock", daysBeforeBlock);
            } else {
                modelAndView.addObject("hasDaysBeforeBlock", false);
//                modelAndView.addObject("daysBeforeBlock", "");
            }

//            } else {
//                modelAndView.addObject("hasDaysBeforeBlock", false);
//                modelAndView.addObject("daysBeforeBlock", "");
//            }

            Double contractCurrentBalance = billingController.helper.getCutomerBalance(contractId);
            modelAndView.addObject("contractCurrentBalance", contractCurrentBalance);
        }
    }

    /**
     * Check contract is blocked
     *
     * @param session
     * @param contractId
     * @return
     */
    public static boolean isContractBlocked(HttpSession session, Long contractId) {
        // Check contract status
        if (getUserContract(session) != null) {
            if (getUserContract(session).getContractStatus() != null && getUserContract(session).getContractStatus().getId() != null) {
                Long contractStatusId = getUserContract(session).getContractStatus().getId();

                // if contract status not "Elementary" or not "Active" then redirect to block page
                return !contractStatusId.equals(1L) && !contractStatusId.equals(2L);
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

}
