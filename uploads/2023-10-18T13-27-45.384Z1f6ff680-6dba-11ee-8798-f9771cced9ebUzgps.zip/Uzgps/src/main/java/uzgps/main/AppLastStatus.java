package uzgps.main;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by Gayratjon on 7/24/14.
 */
public class AppLastStatus {
    @JsonProperty("appt")
    private String activeAppTab;
    @JsonProperty("mapt")
    private String activeMapTab;
    @JsonProperty("msgt")
    private String activeMessageTab;
    @JsonProperty("maplt")
    private String mapMobjectListType;
    @JsonProperty("msglt")
    private String messageMobjectListType;
    @JsonProperty("mapunol")
    private List<Long> mapUnselectedMobjectList;
    @JsonProperty("mapungol")
    private List<Long> mapUnselectedGroupedMobjectList;
    @JsonProperty("mapunzol")
    private List<Long> mapUnselectedZonedMobjectList;
    @JsonProperty("msgunol")
    private List<Long> messageUnselectedMobjectList;
    @JsonProperty("msgungol")
    private List<Long> messageUnselectedGroupedMobjectList;
    @JsonProperty("poil")
    private List<Long> poiList;
    @JsonProperty("gfl")
    private List<Long> geoFenceList;
    @JsonProperty("unsntm")
    private Long unseenNotificationsLastTime;

    public AppLastStatus() {
        this.activeAppTab = null;
        this.activeMapTab = null;
        this.activeMessageTab = null;
        this.mapMobjectListType = null;
        this.messageMobjectListType = null;
        this.mapUnselectedMobjectList = new ArrayList<>();
        this.mapUnselectedGroupedMobjectList = new ArrayList<>();
        this.mapUnselectedZonedMobjectList = new ArrayList<>();
        this.messageUnselectedMobjectList = new ArrayList<>();
        this.messageUnselectedGroupedMobjectList = new ArrayList<>();
        this.poiList = new ArrayList<>();
        this.geoFenceList = new ArrayList<>();
        this.unseenNotificationsLastTime = System.currentTimeMillis();
    }

    public String getActiveAppTab() {
        return activeAppTab;
    }

    public void setActiveAppTab(String activeAppTab) {
        this.activeAppTab = activeAppTab;
    }

    public String getActiveMapTab() {
        return activeMapTab;
    }

    public void setActiveMapTab(String activeMapTab) {
        this.activeMapTab = activeMapTab;
    }

    public String getActiveMessageTab() {
        return activeMessageTab;
    }

    public void setActiveMessageTab(String activeMessageTab) {
        this.activeMessageTab = activeMessageTab;
    }

    public String getMapMobjectListType() {
        return mapMobjectListType;
    }

    public void setMapMobjectListType(String mapMobjectListType) {
        this.mapMobjectListType = mapMobjectListType;
    }

    public String getMessageMobjectListType() {
        return messageMobjectListType;
    }

    public void setMessageMobjectListType(String messageMobjectListType) {
        this.messageMobjectListType = messageMobjectListType;
    }

    public List<Long> getMapUnselectedMobjectList() {
        return mapUnselectedMobjectList;
    }

    public void setMapUnselectedMobjectList(List<Long> mapUnselectedMobjectList) {
        this.mapUnselectedMobjectList = mapUnselectedMobjectList;
    }

    public List<Long> getMapUnselectedGroupedMobjectList() {
        return mapUnselectedGroupedMobjectList;
    }

    public void setMapUnselectedGroupedMobjectList(List<Long> mapUnselectedGroupedMobjectList) {
        this.mapUnselectedGroupedMobjectList = mapUnselectedGroupedMobjectList;
    }

    public List<Long> getMessageUnselectedMobjectList() {
        return messageUnselectedMobjectList;
    }

    public void setMessageUnselectedMobjectList(List<Long> messageUnselectedMobjectList) {
        this.messageUnselectedMobjectList = messageUnselectedMobjectList;
    }

    public List<Long> getMessageUnselectedGroupedMobjectList() {
        return messageUnselectedGroupedMobjectList;
    }

    public void setMessageUnselectedGroupedMobjectList(List<Long> messageUnselectedGroupedMobjectList) {
        this.messageUnselectedGroupedMobjectList = messageUnselectedGroupedMobjectList;
    }

    public List<Long> getPoiList() {
        return poiList;
    }

    public void setPoiList(List<Long> poiList) {
        this.poiList = poiList;
    }

    public List<Long> getGeoFenceList() {
        return geoFenceList;
    }

    public void setGeoFenceList(List<Long> geoFenceList) {
        this.geoFenceList = geoFenceList;
    }

    public Long getUnseenNotificationsLastTime() {
        return unseenNotificationsLastTime;
    }

    public void setUnseenNotificationsLastTime(Long unseenNotificationsLastTime) {
        this.unseenNotificationsLastTime = unseenNotificationsLastTime;
    }

    public List<Long> getMapUnselectedZonedMobjectList() {
        return mapUnselectedZonedMobjectList;
    }

    public void setMapUnselectedZonedMobjectList(List<Long> mapUnselectedZonedMobjectList) {
        this.mapUnselectedZonedMobjectList = mapUnselectedZonedMobjectList;
    }
}
