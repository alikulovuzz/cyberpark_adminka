package uzgps.camera;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class CameraController extends AbstractCameraController {

    private final static String URL_CAMERA_PANEL = "/camera/main.html";
    private final static String VIEW_CAMERA_PANEL = "camera/main";

    @RequestMapping(value = URL_CAMERA_PANEL)
    public ModelAndView showCameraPanel(HttpSession session) {
        ModelAndView modelAndView = new ModelAndView(VIEW_CAMERA_PANEL);
        return modelAndView;
    }


    /**
     * Get active route tab menu in order to add active class to tab menu in html
     *
     * @return String
     */
    @Override
    protected String getActiveTabMenu() {
        return "camera";
    }
}
