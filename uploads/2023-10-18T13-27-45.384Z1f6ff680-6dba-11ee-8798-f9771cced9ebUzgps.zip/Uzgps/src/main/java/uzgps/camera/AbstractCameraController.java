package uzgps.camera;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uzgps.common.CommonUtils;
import uzgps.main.AppLastStatus;
import uzgps.main.MainController;
import uzgps.persistence.ContractSettings;
import uzgps.persistence.User;
import uzgps.persistence.UserAccessList;

import javax.servlet.http.HttpSession;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static uzgps.common.UZGPS_CONST.USER_ROLE_USER_STR;

/**
 * Created by Gayratjon on 5/13/2015
 */
public abstract class AbstractCameraController {

    @Autowired
    MainController mainController;

    @Autowired
    ObjectMapper jsonMapper;

    @Autowired
    CoreMain coreMain;

    @Autowired
    InternalResourceViewResolver htmlViewResolver;

    /**
     * Get active route tab menu in order to add active class to tab menu in html
     *
     * @return String
     */
    @ModelAttribute("activeTabMenu")
    abstract protected String getActiveTabMenu();

    /**
     * Check whether system has an access for routing module
     *
     * @return
     */
    @ModelAttribute("hasAccess")
    private Boolean getAccess() {
        return true; // CoreTripRoutingControl.hasAccess();
    }

    /**
     * Get active top menu in order to add active class to menu in html
     *
     * @return String
     */
    @ModelAttribute("activeTopMenu")
    private String getActiveTopMenu() {
        return "camera";
    }

    /**
     * Get current user's company name
     *
     * @return String
     */
    @ModelAttribute("companyName")
    private String getCompanyName(HttpSession session) {

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            return MainController.getUserContract(session).getCompany().getName();
        } else {
            return MainController.getUserContract(session).getCustomerCompanyName();
        }
    }

    /**
     * Get current user's login
     *
     * @return String
     */
    @ModelAttribute("userLogin")
    private String getUserLogin() {
        // Get current logged in user
        User user = MainController.getUser();
        return user.getLogin();
    }

    /**
     * Get current user's access list
     *
     * @param session
     * @return UserAccessList
     */
    @ModelAttribute("userAccessList")
    public UserAccessList getUserAccessList(HttpSession session) {
        // Get user access list in session
        return mainController.getUserAccessList(session);
    }

    /**
     * Get map type
     *
     * @return Integer
     */
    @ModelAttribute("mapType")
    private Integer getMapType(HttpSession session) {
        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        return contractSettings.getMapType().intValue();
    }

    /**
     * Make common map models for all routing sections
     *
     * @param appStatus
     * @param session
     * @return Map<String, Object>
     */
    protected Map<String, Object> getCommonMapModel(String appStatus, HttpSession session) {
        AppLastStatus appLastStatus;

        if (appStatus.length() == 0) {
            appLastStatus = new AppLastStatus();
        } else {
            appLastStatus = CommonUtils.deserializeStatus(jsonMapper, appStatus);
        }

        // Get contract settings in session
        ContractSettings contractSettings = mainController.getContractSettings(session);

        // Get user access list in session
        UserAccessList userAccessList = mainController.getUserAccessList(session);

        // Get current logged in user
        User user = MainController.getUser();

        // Map keeps all models
        Map<String, Object> mapModels = new HashMap<>();

        Long lastAlertNotificationTime = System.currentTimeMillis();

        Integer requestIntervalTime = contractSettings.getMonitoringRefreshInterval();
        if (requestIntervalTime > MainController.REQUEST_INTERVAL_MAX) {
            requestIntervalTime = MainController.REQUEST_INTERVAL_MAX;
        } else if (requestIntervalTime < MainController.REQUEST_INTERVAL_MIN) {
            requestIntervalTime = MainController.REQUEST_INTERVAL_MIN;
        }

        mapModels.put("activeTopMenu", getActiveTabMenu());
        mapModels.put("numNotification", 0); // if zero, any notifications won't be showed coming from bottom
        mapModels.put("userAccessList", userAccessList);
        mapModels.put("lastAlertNotificationTime", lastAlertNotificationTime);
        mapModels.put("requestIntervalTime", requestIntervalTime * 1000); // in milliseconds
        mapModels.put("companyName", user.getContract().getCompany().getName());
        mapModels.put("userLogin", user.getLogin());

        return mapModels;
    }

    /**
     * Get list of MobjectBig by current user id or contract id
     *
     * @return List<MobjectBig>
     */
    protected List<MobjectBig> getMobjectList(HttpSession session) {
        List<MobjectBig> mObjectList;
        if (MainController.getUserRole().equalsIgnoreCase(USER_ROLE_USER_STR)) {
            mObjectList = coreMain.getMobjectListByUser(MainController.getInterfaceUserId());
        } else {
            boolean isShowSuspendedObjects = mainController.getContractSettings(session).getIsShowSuspendedObjects();
            mObjectList = coreMain.getMobjectListByContract(MainController.getUserContractId(session), isShowSuspendedObjects);
        }

        // Sort list of objects
        if (mObjectList != null && mObjectList.size() > 0)
            Collections.sort(mObjectList);

        return mObjectList;
    }

    /**
     * Check whether user has access to edit given mobject
     *
     * @param mobjectId
     * @return boolean return true if has access otherwise false
     */
    protected boolean hasAccessEditForMobject(HttpSession session, Long mobjectId) {
        List<MobjectBig> mObjectList = getMobjectList(session);

        if (mObjectList != null && mobjectId != null) {
            MobjectBig mobjectBig = new MobjectBig();
            mobjectBig.setId(mobjectId);

            return mObjectList.contains(mobjectBig);
        }

        return false;
    }

}
