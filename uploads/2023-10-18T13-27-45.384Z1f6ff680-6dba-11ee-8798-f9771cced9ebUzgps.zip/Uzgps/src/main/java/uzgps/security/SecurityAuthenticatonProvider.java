package uzgps.security;

/**
 * User: Sheroz Khaydarov
 * Date: 29.08.2010
 * Time: 20:43
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import uzgps.common.RoleInfo;
import uzgps.common.UZGPS_CONST;
import uzgps.common.configuration.AppConfiguration;
import uzgps.common.configuration.RoleConfiguration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.Collection;

@Component
public class SecurityAuthenticatonProvider  implements AuthenticationProvider {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @Autowired
    private AppConfiguration appConfiguration;

    @Autowired
    private SecurityService securityService;

    @Autowired
    private AdminJournalSignIn adminJournalSignIn;

    public void setAppConfiguration(AppConfiguration appConfiguration) {
        this.appConfiguration = appConfiguration;
    }

    public void setSecurityService(SecurityService securityService) {
        this.securityService = securityService;
    }

    public void setAdminJournalSignIn(AdminJournalSignIn adminJournalSignIn) {
        this.adminJournalSignIn = adminJournalSignIn;
    }

    public void setAdminJournalSignInRest(AdminJournalSignIn adminJournalSignInRest) {
        this.adminJournalSignIn = adminJournalSignInRest;
    }

    public Authentication authenticate(Authentication authentication)
            throws AuthenticationException {
        String login = null;
        String password = null;

        String captcha = null;
        String captchaMd5 = null;
        Integer loginAttempts = null;
        boolean loginWithoutCaptchaOK = true;
        String authToken = null;
        String redirect = null;

        // Get captcha info
        try {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            HttpServletRequest request = attributes.getRequest();
            captcha = request.getParameter("j_captcha");
            authToken = request.getParameter("auth_token");
            redirect = request.getParameter("redirect");
            if (captcha != null) {
                captcha = captcha.toUpperCase();
            }

            HttpSession session = request.getSession(true);
            captchaMd5 = (String) session.getAttribute("captcha");
            loginAttempts = (Integer) session.getAttribute("loginAttempts");

            if (loginAttempts != null && loginAttempts > 2) {

                // assume that, captcha must be entered
                loginWithoutCaptchaOK = false;

                // login attempt more than one, check captcha
                MD5 md5 = new MD5();
                String captchaHere = md5.getMD5(captcha);
                if (captchaHere.equals(captchaMd5)) {
                    loginWithoutCaptchaOK = true;
                    loginAttempts = 1;
                    session.setAttribute("loginAttempts", loginAttempts);
                } else {
                    loginWithoutCaptchaOK = false;
                    loginAttempts++;
                    session.setAttribute("loginAttempts", loginAttempts);
                }

            } else {
                // captcha no need to check
                loginWithoutCaptchaOK = true;
                if (loginAttempts == null) loginAttempts = 1;
                session.setAttribute("loginAttempts", loginAttempts);
            }
        } catch (Exception e) {
            captcha = null;
        }

        SecurityLoggedUser securityLoggedUser;

        Collection<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();
        if (authentication.getPrincipal() != null)
            login = authentication.getPrincipal().toString();

        if (login == null)
            login = "";

        if (authentication.getCredentials() != null)
            password = authentication.getCredentials().toString();
        if (password == null)
            password = "";

        boolean authenticated = false;
        login = login.toLowerCase();
        if (!login.isEmpty() && loginWithoutCaptchaOK) {
            uzgps.persistence.User user = securityService.getUserByLogin(login);
            if (user != null) {
                boolean isNeedUpdateToken = true;

                if (user.getAuthToken() != null && user.getAuthToken().equals(authToken)) {
                    // if has token. login with token
                    // Success
                    authenticated = true;
                    isNeedUpdateToken = false;
                } else {
                    // login with password
                    MD5 md5 = new MD5();
                    password = md5.getMD5(password);
                    authenticated = user.getLogin().equalsIgnoreCase(login) && user.getPassword() != null && user.getPassword().equals(password);
                }

                if (authenticated) {
                    logger.info("Authentication SUCCESS, login: {}", login);

                    adminJournalSignIn.logSingIn(
                            UZGPS_CONST.JOURNAL_ACT_LOGIN,
                            UZGPS_CONST.JOURNAL_LOGIN_SUCCESS,
                            UZGPS_CONST.JOURNAL_LOGIN,
                            user);// todo put userId

                    // Save last login
                    securityService.updateUserLastLogin(user, isNeedUpdateToken);

                    RoleConfiguration roleConfiguration = appConfiguration.getRoleConfiguration();
                    for (RoleInfo roleInfo : roleConfiguration.getRoleInfo()) {
                        if (roleInfo.getId() == user.getRoleId()) {
                            String strAuthType = roleInfo.getType();
                            grantedAuthorities.add(new SimpleGrantedAuthority(strAuthType));
                            break;
                        }
                    }

                    // check is there at least one role
                    if (grantedAuthorities.isEmpty()) {
                        grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_ANONYMOUS"));
                    }

                    securityLoggedUser = new SecurityLoggedUser(login, password, grantedAuthorities, user);
                    if (authToken != null && !authToken.isEmpty() && redirect != null && !redirect.isEmpty()) {
                        securityLoggedUser.setRedirectTo(redirect);
                    }
                    UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(securityLoggedUser, authentication, grantedAuthorities);
                    result.setDetails((authentication.getDetails() != null) ? authentication.getDetails() : null);
                    return result;
                }
            }
        }

        logger.info("Authentication FAILED, login: {}", login);
        adminJournalSignIn.logSingInError(
                UZGPS_CONST.JOURNAL_ACT_LOGIN,
                UZGPS_CONST.JOURNAL_LOGIN_FAIL,
                UZGPS_CONST.JOURNAL_LOGIN,
                login);
        throw new BadCredentialsException("Bad credentials presented");
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }

}
