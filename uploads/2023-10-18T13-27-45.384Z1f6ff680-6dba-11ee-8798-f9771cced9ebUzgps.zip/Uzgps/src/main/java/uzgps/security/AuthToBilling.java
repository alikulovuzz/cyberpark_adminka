package uzgps.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import uzgps.common.configuration.UrlConfiguration;
import uzgps.main.MainController;
import uzgps.persistence.User;

/**
 * Created by Stanislav on 12.10.2016 15:16.
 */
@Controller
public class AuthToBilling {

//    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public final static String URL_AUTH_TO_BILLING_MAIN = "/security/auth-to-billing-main.htm";
    private final static String VIEW_AUTH_TO_BILLING_MAIN = "security/auth-to-billing-main";

//    @Autowired
//    private AdminService adminService;

    @Autowired
    private SecurityService securityService;

    @RequestMapping(value = URL_AUTH_TO_BILLING_MAIN)
    public ModelAndView goToMain() {

        ModelAndView modelAndView = new ModelAndView(VIEW_AUTH_TO_BILLING_MAIN);

        User user = MainController.getUser();
        User userToLogin = user;

        if (user != null) {
            if (user.getLogin() != null) {
                userToLogin = securityService.getUserByLogin(user.getLogin());
            }
        }

        modelAndView.addObject("user", userToLogin);
        modelAndView.addObject("urlBilling", UrlConfiguration.getUrlBilling());

        return modelAndView;
    }

}
