package uzgps.security;

import org.springframework.security.core.GrantedAuthority;
import uzgps.persistence.Contract;
import uzgps.persistence.FileStorage;
import uzgps.persistence.User;

import java.util.Collection;

/**
 * @author Sheroz Khaydarov
 * @since Date: 27.09.2007 Time: 16:03:58
 */

public class SecurityLoggedUser extends org.springframework.security.core.userdetails.User {

    private Collection<GrantedAuthority> authorities;
    private uzgps.persistence.User user;

    public Collection<GrantedAuthority> getAuthorities() {
        return authorities;
    }

    public User getUser() {
        return user;
    }

    public String redirectTo = "";

    public void setUserData(Contract contract, Long interfaceUserId, FileStorage photo, String name, String surname, String middleName) {
        if (contract != null) {
          this.user.setContract(contract);
        }
        if (interfaceUserId != null){
            this.user.setInterfaceUserId(interfaceUserId);
        }
        if (photo != null) {
            this.user.setPhoto(photo);
        }
        if (name != null)
            this.user.setName(name);
        if (surname != null)
            this.user.setSurName(surname);
        if (middleName != null)
            this.user.setMiddleName(middleName);
    }

    public void setInterfaceUserData(Contract contract, Long interfaceUserId, FileStorage photo, String name, String surname, String middleName) {
    }

    public SecurityLoggedUser(String login, String password, Collection<GrantedAuthority> authorities, User user)
            throws IllegalArgumentException {
        super(login, password, true /*enabled*/, true /*accountNonExpired*/, true /*credentialsNonExpired*/, true /*accountNonLocked*/, authorities);
        this.authorities = authorities;
        this.user = user;
    }

    public String getRedirectTo() {
        return redirectTo;
    }

    public void setRedirectTo(String redirectTo) {
        this.redirectTo = redirectTo;
    }
}
