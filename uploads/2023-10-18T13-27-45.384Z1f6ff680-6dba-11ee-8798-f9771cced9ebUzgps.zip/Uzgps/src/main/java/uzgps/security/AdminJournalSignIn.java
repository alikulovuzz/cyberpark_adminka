package uzgps.security;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.common.UZGPS_CONST;
import uzgps.dto.UserDTO;
import uzgps.persistence.Journal;
import uzgps.persistence.User;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.sql.Timestamp;
import java.util.logging.Logger;

/**
 * Created by Saidolim on 02.04.14.
 */

@Service
@Transactional
public class AdminJournalSignIn {

//    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    @PersistenceContext
    EntityManager entityManager;

    @Transactional
    public void logSingIn(int action, int comment, int type, User user) {
        String callerName = "";
//        try {
//            // Determine, who called this function. Get Classname, Method and Line number
//            StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
//            callerName = stackTraceElements[3].getClassName() + ":" + stackTraceElements[1].getMethodName() + ":" + stackTraceElements[1].getLineNumber();
//        } catch (Exception e) {
//            callerName = "unknown";
//        }

        Journal journal = new Journal();
        journal.setClassName(callerName);
        journal.setAction(action);
        journal.setComment(comment);
        journal.setDate(new Timestamp(System.currentTimeMillis()));
        journal.setRegDate(new Timestamp(System.currentTimeMillis()));
        journal.setStatus("A");
        journal.setType(type);
        journal.setUserId(user.getId());

        String obj = "";

        try {
            ObjectMapper mapper = new ObjectMapper();
            obj                 = mapper.writeValueAsString(new UserDTO(user));
        } catch (JsonProcessingException e) {}
        journal.setJobject(obj);

        //journal.setJobject(user.toString());
        journal.setObjectId(user.getId());
        entityManager.persist(journal);

        user.setLoginAttemp(0);
        entityManager.merge(user);

    }


    @Transactional
    public void logSingInError(int action, int comment, int type, String login) {
        String callerName = "";

        Journal journal = new Journal();
        journal.setClassName(callerName);
        journal.setAction(action);
        journal.setComment(comment);
        journal.setDate(new Timestamp(System.currentTimeMillis()));
        journal.setRegDate(new Timestamp(System.currentTimeMillis()));
        journal.setStatus("A");
        journal.setUserId(0);
        journal.setJobject(login);
        journal.setObjectId(0L);
        journal.setType(type);
        entityManager.persist(journal);

        // Check user login attemp
        try {
            TypedQuery<User> query;
            query = entityManager.createNamedQuery("User.findByLogin", User.class);
            query.setParameter("login", login);
            query.setParameter("status", UZGPS_CONST.USER_STATUS_ACTIVE);
            User user = query.getSingleResult();

            if (user != null) {
                if (user.getLoginAttemp() == null)
                    user.setLoginAttemp(0);
                user.setLoginAttemp(user.getLoginAttemp() + 1);

                entityManager.merge(user);

                // If attamps more than 7 , make log
                if (user.getLoginAttemp() >= 7) {

//                    journal = new Journal();
                    journal.setClassName("");
                    journal.setAction(UZGPS_CONST.JOURNAL_LOGIN);
                    journal.setComment(UZGPS_CONST.JOURNAL_LOGIN_TRY_LIMIT);

                    String obj = "";

                    try {
                        ObjectMapper mapper = new ObjectMapper();
                        obj                 = mapper.writeValueAsString(user);
                    } catch (JsonProcessingException e) {}
                    journal.setJobject(obj);

                    //journal.setJobject(user.toString());
                    journal.setDate(new Timestamp(System.currentTimeMillis()));
                    journal.setRegDate(new Timestamp(System.currentTimeMillis()));
                    journal.setStatus("A");
                    journal.setType(type);

                    // Save log to journal
                    entityManager.persist(journal);
                }
            }


        } catch (Exception e) {

        }
    }


}

