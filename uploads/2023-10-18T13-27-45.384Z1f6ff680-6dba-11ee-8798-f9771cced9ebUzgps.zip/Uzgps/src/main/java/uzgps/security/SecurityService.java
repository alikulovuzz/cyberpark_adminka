package uzgps.security;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import uzgps.common.CommonUtils;
import uzgps.common.UZGPS_CONST;
import uzgps.persistence.User;
import uzgps.persistence.UserRole;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * @author Sheroz Khaydarov
 * @since 03.04.13 12:19
 */

@Service
@Transactional
public class SecurityService {

    @PersistenceContext
    private EntityManager em;

    @Transactional(readOnly = true)
    public uzgps.persistence.User getUserByLogin(String login) {
        if (login == null)
            return null;

        try {
            TypedQuery<uzgps.persistence.User> query;
            query = em.createNamedQuery("User.findByLogin", uzgps.persistence.User.class);
            query.setParameter("login", login);
            query.setParameter("status", UZGPS_CONST.STATUS_ACTIVE);
            return query.getSingleResult();
        } catch (javax.persistence.NoResultException e) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public List<UserRole> getUserRoles(Long userId) {
        if (userId == null)
            return null;

        Query query;
        query = em.createNamedQuery("UserRole.findByUserId");
        query.setParameter("userId", userId);
        return query.getResultList();
    }

    @Transactional
    public uzgps.persistence.User saveUser(uzgps.persistence.User user) {
        if (user.getId() != null) {
            em.merge(user);
        } else {
            em.persist(user);
        }
        return user;
    }

    @Transactional
    public List<UserRole> saveUserRoles(List<UserRole> userRoles) {
        if (userRoles == null)
            return null;

        for (UserRole userRole : userRoles) {
            if (userRole.getId() != null) {
                em.merge(userRole);
            } else {
                em.persist(userRole);
            }
        }
        return userRoles;
    }

    @Transactional
    public void updateUserLastLogin(User user, boolean updateToken) {
        if (user != null && user.getId() != null) {
            String sql;
            if (updateToken) {
                String token = CommonUtils.generateRandomString();
                user.setAuthToken(token);
                // Update last_logged_in and token
                sql = "UPDATE uzgps_user SET last_logged_in=now(), auth_token = '" + token + "' WHERE id=" + user.getId() + " and u_status='A';";
            } else {
                // Update last_logged_in and token
                sql = "UPDATE uzgps_user SET last_logged_in=now() WHERE id=" + user.getId() + " and u_status='A';";
            }

            em.createNativeQuery(sql).executeUpdate();
        }
    }

}
