package uzgps.profile;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.routing.core.CoreTripRoutingControl;
import uzgps.common.FileStorageService;
import uzgps.common.UZGPS_CONST;
import uzgps.main.MainController;
import uzgps.persistence.FileStorage;
import uzgps.persistence.User;
import uzgps.persistence.UserAccessList;
import uzgps.security.MD5;
import uzgps.settings.SettingsService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Locale;

import static uzgps.main.MainController.*;

/**
 * Created by Zoxir on 25.01.14.
 */

@Controller
public class ProfileController {

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    private final static String URL_PROFILE = "/profile/main.htm";
    private final static String URL_PROFILE_MANAGE = "/profile/main-manage.htm";
    private final static String VIEW_PROFILE = "profile/main";

    private final static String URL_PROFILE_PASSWORD = "/profile/profile-password.htm";
    private final static String VIEW_PROFILE_PASSWORD = "profile/profile-password";

    @Autowired
    private SettingsService settingsService;

    @Autowired
    FileStorageService storageService;

    @Autowired
    MainController mainController;

    /**
     * Check whether system has an access for routing module
     *
     * @return
     */
    @ModelAttribute("hasRoutingAccess")
    private Boolean getRoutingAccess() {
        return CoreTripRoutingControl.hasAccess();
    }

    @RequestMapping(value = URL_PROFILE)
    public ModelAndView processProfile(HttpSession session) {

        if (isContractBlocked(session, MainController.getUserContractId(session))) {
//            return new ModelAndView("redirect:" + "../" + URL_CONTRACT_DETERMINED);

            String cabinetUrl = (String) session.getAttribute("url_cabinet");
            String authToken;
            if (MainController.getUser().getRoleId().equals(UZGPS_CONST.USER_ROLE_CUSTOMER_ADMIN)) {
                authToken = getUser().getAuthToken();
            } else {
                authToken = getUser().getInterfaceAuthToken();
            }

            String lang = LocaleContextHolder.getLocale().getLanguage();

            return new ModelAndView("redirect:" + cabinetUrl +
                    "?code=" + authToken +
                    "&cid=" + MainController.getUserContractId(session) +
                    "&lang=" + lang
            );
        }

        ModelAndView modelAndView = new ModelAndView(VIEW_PROFILE);

        Long userId;
        if (MainController.getInterfaceUserId() != null) {
            userId = MainController.getInterfaceUserId();
        } else {
            userId = MainController.getUserId();
        }
        User user = settingsService.getUserByUserId(userId);
        UserAccessList userAccessList = mainController.getUserAccessList(session);

        if (user.getPhotoId() != null) {
            modelAndView.addObject("avatarFileUrl", user.getPhoto().getFileUrl());
            modelAndView.addObject("userFullName", user.getName() + " " + user.getSurName());
        }

        modelAndView.addObject("userAccessList", userAccessList);
        modelAndView.addObject("user", user);

        return modelAndView;
    }

    @RequestMapping(value = URL_PROFILE_MANAGE)
    public ModelAndView processProfileManage(@RequestParam(value = "cmd", required = false) String cmd,
                                             @RequestParam(value = "file", required = false) MultipartFile file,
                                             @RequestParam(value = "login", required = false) String login,
                                             @RequestParam(value = "sur-name", required = false) String surName,
                                             @RequestParam(value = "name", required = false) String name,
                                             @RequestParam(value = "middle-name", required = false) String middleName,
                                             @RequestParam(value = "position", required = false) String position,
                                             @RequestParam(value = "phone-mobile", required = false) String phoneMobile,
                                             @RequestParam(value = "phone-line", required = false) String phoneLine)
            throws ServletException, IOException {


        if (logger.isDebugEnabled()) {
            logger.debug("processProfileManage cmd={}, sur-name={}, name={}, middle-name={}, position={}, phone-mobile={}, phone-line={}",
                    cmd, surName, name, middleName, position, phoneMobile, phoneLine);
        }

        if (cmd != null) {
            Long userId;
            if (MainController.getInterfaceUserId() != null) {
                userId = MainController.getInterfaceUserId();
            } else {
                userId = MainController.getUserId();
            }

            User user = settingsService.getUserByUserId(userId);

            if (file != null && file.getSize() > 0) {
                if (user.getPhoto() != null) {
                    // Remove the image of Profile if exists
                    FileStorage oldFileStorage = user.getPhoto();
                    user.setPhoto(null);
                    settingsService.saveUser(user);
                    storageService.removeFileFromStorage(oldFileStorage);
                }

                FileStorage fileStorage = storageService.saveMultipartFileToStorage(file);
                user.setPhoto(fileStorage);
            } else if (file == null) {
                // Remove the image of Profile if exists
                FileStorage fileStorage = user.getPhoto();
                if (fileStorage != null) {
                    user.setPhoto(null);
                    settingsService.saveUser(user);
                    storageService.removeFileFromStorage(fileStorage);
                }
            }

//            user.setLogin(login.toLowerCase());
            user.setSurName(surName);
            user.setName(name);
            user.setMiddleName(middleName);
            user.getProfile().setPosition(position);
            user.getProfile().setMobilePhone(phoneMobile);
            user.getProfile().setLinePhone(phoneLine);
            user.setModDate(new Timestamp(System.currentTimeMillis()));
            settingsService.saveUser(user);

            MainController.replaceUserInSession(null, null, user.getPhoto(), name, surName, middleName);
        }
        ModelAndView modelAndView = new ModelAndView("redirect:" + URL_PROFILE);

        return modelAndView;
    }

    @RequestMapping(value = URL_PROFILE_PASSWORD)
    public ModelAndView processProfilePassword(@RequestParam(value = "cmd", required = false) String cmd,
                                               @RequestParam(value = "old-password", required = false) String oldPassword,
                                               @RequestParam(value = "new-password", required = false) String newPassword,
                                               @RequestParam(value = "confirm-new-password", required = false) String confirmNewPassword)
            throws ServletException, IOException {

        ModelAndView modelAndView;

        if (logger.isDebugEnabled()) {
            logger.debug("processProfilePassword cmd={}, old-password={}, new-password={}, confirm-new-password={}",
                    cmd, oldPassword, newPassword, confirmNewPassword);
        }

        if (cmd != null) {

            oldPassword = (oldPassword.length() < 1) ? null : oldPassword;
            newPassword = (newPassword.length() < 1) ? null : newPassword;
            confirmNewPassword = (confirmNewPassword.length() < 1) ? null : confirmNewPassword;


            MD5 md5 = new MD5();
            oldPassword = (oldPassword == null) ? "" : md5.getMD5(oldPassword);
            newPassword = (newPassword == null) ? "" : md5.getMD5(newPassword);
            confirmNewPassword = (confirmNewPassword == null) ? "" : md5.getMD5(confirmNewPassword);

            Integer errorNum = null;
            // Old password not entered
            if (errorNum == null && oldPassword.length() < 1) {
                errorNum = UZGPS_CONST.LOGIN_PASSWORD_OLD_NONE;
            }
            // New password not entered
            if (errorNum == null && newPassword.length() < 1) {
                errorNum = UZGPS_CONST.LOGIN_PASSWORD_NEW_NONE;
            }
            // Confirm password not entered
            if (errorNum == null && confirmNewPassword.length() < 1) {
                errorNum = UZGPS_CONST.LOGIN_PASSWORD_VERIFY_NONE;
            }

            if (errorNum == null &&
                    newPassword != null && newPassword.length() > 4 &&
                    confirmNewPassword != null && confirmNewPassword.length() > 4 &&
                    confirmNewPassword.equals(newPassword)) {

                Long userId;
                if (MainController.getInterfaceUserId() != null) {
                    userId = MainController.getInterfaceUserId();
                } else {
                    userId = MainController.getUserId();
                }

                User user = settingsService.getUserByIdAndPassword(userId, oldPassword);
                if (user != null) {
                    user.setPassword(newPassword);
                    settingsService.saveUser(user);
                    errorNum = UZGPS_CONST.LOGIN_PASSWORD_SUCCESS;
                } else {
                    // Old password not correct
                    if (errorNum == null) {
                        errorNum = UZGPS_CONST.LOGIN_PASSWORD_OLD_INCORRECT;
                    }
                }
            } else {
                // New password and Confirm not same
                if (errorNum == null) {
                    errorNum = UZGPS_CONST.LOGIN_PASSWORD_VERIFY_INCORRECT;
                }
            }

            // modelAndView = new ModelAndView("redirect:" + URL_PROFILE);
            modelAndView = new ModelAndView(VIEW_PROFILE_PASSWORD);
            modelAndView.addObject("errorMsg", "error." + errorNum);
            if (errorNum == UZGPS_CONST.LOGIN_PASSWORD_SUCCESS) {
                modelAndView.addObject("errorMsgType", 0);
            }
        } else
            modelAndView = new ModelAndView(VIEW_PROFILE_PASSWORD);


        return modelAndView;
    }

}
