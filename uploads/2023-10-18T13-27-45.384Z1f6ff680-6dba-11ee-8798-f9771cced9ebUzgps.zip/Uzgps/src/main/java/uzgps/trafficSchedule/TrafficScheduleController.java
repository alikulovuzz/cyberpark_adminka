package uzgps.trafficSchedule;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import uz.netex.core.CoreMain;
import uz.netex.datatype.MobjectBig;
import uz.netex.routing.core.CoreTripRoutingControl;
import uzgps.main.MainController;
import uzgps.map.MonitoringController;
import uzgps.map.POIController;
import uzgps.persistence.POI;
import uzgps.persistence.UserAccessList;
import uzgps.report.ReportService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * Created by Stanislav on 19/02/2018.
 */
@Controller
public class TrafficScheduleController {

    @Autowired
    MainController mainController;

    @Autowired
    private ReportService reportService;

    @Autowired
    private CoreMain coreMain;

    @Autowired
    private MonitoringController monitoringController;

    @Autowired
    POIController poiController;

    private Logger logger = LoggerFactory.getLogger(this.getClass().getName());

    public final static String URL_TRAFFIC_SCHEDULE_MAIN = "/traffic-schedule.htm";
    public final static String VIEW_TRAFFIC_SCHEDULE_MAIN = "traffic-schedule/traffic-schedule";


    private static final String URL_TRAFFIC_SCHEDULE_VIEW = "/traffic-schedule/ajax-view.htm";
    private static final String VIEW_TRAFFIC_SCHEDULE = "traffic-schedule/ajax-view";

    @RequestMapping(value = URL_TRAFFIC_SCHEDULE_MAIN)
    private ModelAndView trafficScheduleMain(HttpSession session,
                                             @RequestParam(value = "wkt", required = false) String wkt)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_TRAFFIC_SCHEDULE_MAIN);

        // Start and finish dates
        String todayAsString = new SimpleDateFormat("dd.MM.yyyy").format(new Date());

        modelAndView.addObject("dateStart", todayAsString + " 08:00");

        modelAndView.addObject("contractId", MainController.getUserContractId(session));
        modelAndView.addObject("userId", MainController.getInterfaceUserId());

        UserAccessList userAccessList = mainController.getUserAccessList(session);
        modelAndView.addObject("userAccessList", userAccessList);
        modelAndView.addObject("hasRoutingAccess", CoreTripRoutingControl.hasAccess());

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            modelAndView.addObject("contractsIds", MainController.getUserContractsIds(session));
        }

        modelAndView.addObject("activeTopMenu", "trafficSchedule");

        String language = "ru";

        String trafficScheduleReportName = "GIT";
        List<String> list = new ArrayList<>();
        list.add(trafficScheduleReportName);

        if (list.size() > 0) {
            modelAndView.addObject("trafficScheduleReportList", list);
        }

        return modelAndView;
    }

    @RequestMapping(value = URL_TRAFFIC_SCHEDULE_VIEW)
    public ModelAndView viewReport(HttpSession session,
                                   HttpServletRequest httpServletRequest,
                                   HttpServletResponse httpServletResponse,
                                   Locale locale,
                                   @RequestParam(value = "datestart", defaultValue = "2021-01-01 00:00") String dateStart)
            throws ServletException, IOException {

        ModelAndView modelAndView = new ModelAndView(VIEW_TRAFFIC_SCHEDULE);

        Long contractId = MainController.getUserContractId(session);
        modelAndView.addObject("contractId", contractId);

        if (MainController.getIsShowObjectsOfAllContracts(session)) {
            modelAndView.addObject("contractsIds", MainController.getUserContractsIds(session));
        }

        dateStart = dateStart + " 08:00";
        String dateEnd = dateStart;

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(dateFormat.parse(dateStart));
        } catch (ParseException e) {
           logger.error("Error in viewReport", e);
        }
        c.add(Calendar.DATE, -1);  // number of days to add
        dateStart = dateFormat.format(c.getTime());  // dt is now the new date

        List<MobjectInPoiDetail> mobjectInPoiDetails = reportService.getMobjectInPoiDetails(contractId, dateStart, dateEnd);

        Collections.sort(mobjectInPoiDetails);

        List<POI> poiList = poiController.getPoiList(session);
        HashMap<Long, POI> poiListMap = new HashMap<>();

        long k = poiList.size() * 30;
        for (POI poi : poiList) {
            k -= 30;
            poi.setTempId(k);
            poiListMap.put(poi.getId(), poi);
        }

        List<MobjectBig> mobjectList = monitoringController.getMobjects(session, false);

        List<TrafficScheduleData> trafficScheduleDataList = new ArrayList<>();
//        TrafficScheduleData trafficScheduleData = new TrafficScheduleData(mobjectList, mobjectInPoiWithTimeData);

        PoiTime poiTime;
        List<PoiTime> poiTimes;

        for (MobjectBig mobject : mobjectList) {
            poiTimes = new ArrayList<>();

            for (MobjectInPoiDetail mobjectInPoiDetail : mobjectInPoiDetails) {
                if (Objects.equals(mobjectInPoiDetail.getMobject_id(), mobject.getId())) {

                    poiTime = new PoiTime(mobjectInPoiDetail.getPoi_id(), mobjectInPoiDetail.getDateInPoiFormatted());
                    poiTimes.add(poiTime);

                    if (mobjectInPoiDetail.getDate_out_poi() != null) {
                        poiTime = new PoiTime(mobjectInPoiDetail.getPoi_id(), mobjectInPoiDetail.getDateOutPoiFormatted());
                        poiTimes.add(poiTime);
                    }
                }
            }

            Collections.sort(poiTimes);
            trafficScheduleDataList.add(new TrafficScheduleData(mobject.getId(), mobject.getName(), poiTimes));
        }

        modelAndView.addObject("poiList", poiList);
        modelAndView.addObject("poiListMap", poiListMap);
        modelAndView.addObject("mobjectList", mobjectList);
        modelAndView.addObject("trafficScheduleDataList", trafficScheduleDataList);

        return modelAndView;
    }
}
