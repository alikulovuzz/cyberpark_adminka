package uzgps.trafficSchedule;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.sql.Timestamp;

/**
 * Created by Stanislav on 22.02.2018 10:49.
 */
@Entity
public class MobjectInPoiDetail implements Comparable<MobjectInPoiDetail> {

    @Id
    private Long id;

    private Long contract_id;
    private Long mobject_id;
    private Long poi_id;
    private Timestamp date_in_poi;
    private Timestamp date_out_poi;

    @Override
    public int compareTo(MobjectInPoiDetail mpd) {
        return this.date_in_poi.compareTo(mpd.date_in_poi);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getContract_id() {
        return contract_id;
    }

    public void setContract_id(Long contract_id) {
        this.contract_id = contract_id;
    }

    public Long getMobject_id() {
        return mobject_id;
    }

    public void setMobject_id(Long mobject_id) {
        this.mobject_id = mobject_id;
    }

    public Long getPoi_id() {
        return poi_id;
    }

    public void setPoi_id(Long poi_id) {
        this.poi_id = poi_id;
    }

    public Timestamp getDate_in_poi() {
        return date_in_poi;
    }

    public int getDateInPoiFormatted() {
        return (int) (((date_in_poi.getTime() / 60000L) + 540) % 1440);
    }

    public void setDate_in_poi(Timestamp date_in_poi) {
        this.date_in_poi = date_in_poi;
    }

    public Timestamp getDate_out_poi() {
        return date_out_poi;
    }

    public int getDateOutPoiFormatted() {
        return (int) (((date_out_poi.getTime() / 60000L) + 540) % 1440);
    }

    public void setDate_out_poi(Timestamp date_out_poi) {
        this.date_out_poi = date_out_poi;
    }

    @Override
    public String toString() {
        return "MobjectInPoiDetail{" +
                "id=" + id +
                ", contract_id=" + contract_id +
                ", mobject_id=" + mobject_id +
                ", poi_id=" + poi_id +
                ", date_in_poi=" + date_in_poi +
                ", date_out_poi=" + date_out_poi +
                '}';
    }
}
