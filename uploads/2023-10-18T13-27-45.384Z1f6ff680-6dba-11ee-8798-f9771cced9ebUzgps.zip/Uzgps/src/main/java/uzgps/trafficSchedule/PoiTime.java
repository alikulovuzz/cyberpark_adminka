package uzgps.trafficSchedule;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * Created by Stanislav on 22.02.2018 10:49.
 */
@Entity
public class PoiTime implements Comparable<PoiTime> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private Long poiId;
    private int poiTime;

    PoiTime(Long poiId, int poiTime) {
        this.poiId = poiId;
        this.poiTime = poiTime;
    }

    public PoiTime() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPoiId() {
        return poiId;
    }

    public void setPoiId(Long poiId) {
        this.poiId = poiId;
    }

    public int getPoiTime() {
        return poiTime;
    }

    public void setPoiTime(int poiTime) {
        this.poiTime = poiTime;
    }

    @Override
    public int compareTo(PoiTime p) {
        return (this.poiTime < p.poiTime) ? -1 : 1;
    }
}
