package uzgps.trafficSchedule;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.List;

/**
 * Created by Stanislav on 22.02.2018 10:49.
 */
public class TrafficScheduleData {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private Long mObjectId;
    private String mObjectName;
    private List<PoiTime> poiTimes;

    TrafficScheduleData(Long mObjectId, String mObjectName, List<PoiTime> poiTimes) {
        this.mObjectId = mObjectId;
        this.mObjectName = mObjectName;
        this.poiTimes = poiTimes;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getmObjectId() {
        return mObjectId;
    }

    public void setmObjectId(Long mObjectId) {
        this.mObjectId = mObjectId;
    }

    public String getmObjectName() {
        return mObjectName;
    }

    public void setmObjectName(String mObjectName) {
        this.mObjectName = mObjectName;
    }

    public List<PoiTime> getPoiTimes() {
        return poiTimes;
    }

    public void setPoiTimes(List<PoiTime> poiTimes) {
        this.poiTimes = poiTimes;
    }

    @Override
    public String toString() {
        return "TrafficScheduleData{" +
                "id=" + id +
                ", mObjectId=" + mObjectId +
                ", mObjectName='" + mObjectName + '\'' +
                ", poiTimes=" + poiTimes +
                '}';
    }
}
